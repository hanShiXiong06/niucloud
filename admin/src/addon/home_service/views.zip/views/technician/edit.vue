<template>
	<div class="main-container">
		<el-card class="card !border-none mb-[15px]" shadow="never">
			<el-page-header :content="id ? t('editTechnician') : t('addTechnician')" :icon="ArrowLeft" @back="back" />
		</el-card>

		<el-card class="box-card !border-none" shadow="never" v-loading="loading">
			<el-form :model="formData" label-width="90px" ref="formRef" :rules="formRules" class="page-form">
				<el-form-item :label="t('technicianName')" prop="real_name">
					<el-input v-model.trim="formData.real_name" clearable :placeholder="t('technicianNamePlaceholder')"
						class="input-width !w-[220px]" />
				</el-form-item>
				<el-form-item :label="t('mobile')" prop="mobile">
					<el-input v-model.trim="formData.mobile" clearable :placeholder="t('mobilePlaceholder')"
						class="input-width !w-[220px]" />
				</el-form-item>
				<el-form-item :label="t('headimg')" prop="headimg">
					<upload-image v-model="formData.headimg" @change="clearFieldError('headimg')" />
				</el-form-item>
				<el-form-item :label="t('status')">
					<el-radio-group v-model="formData.status">
						<el-radio label="1">在职</el-radio>
						<el-radio label="-1">离职</el-radio>
						<el-radio label="0">休息中</el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item :label="t('store')">
					<div class="!w-[200px] border-[1px] border-[#e4e4e4] border-solid px-[11px] h-[30px]">
						{{ formData.store_name || '' }}
					</div>
					<el-button class="ml-[10px]" type="primary" @click="storeDialog = true">选择门店</el-button>
				</el-form-item>
				<el-form-item :label="t('member')" prop="member_id">
					<div class="!w-[200px] border-[1px] border-[#e4e4e4] border-solid px-[11px] h-[30px]">
						{{ formData.member_nickname || '' }}
					</div>
					<el-button class="ml-[10px]" type="primary" v-if="!formData.member_nickname" @click="dialogMemberVisible = true">选择会员</el-button>
				</el-form-item>
				<el-form-item :label="t('level')" prop="level_id">
					<el-select v-model="formData.level_id" :placeholder="t('levelPlaceholder')" clearable @change="clearFieldError('level_id')">
						<el-option v-for="item in levelList" :key="item.level_id" :label="item.level_name"
							:value="item.level_id" />
					</el-select>
					<div class="ml-[10px]">
						<span class="cursor-pointer text-primary mr-[10px]"
							@click="refreshLevel()">{{ t('refresh') }}</span>
						<span class="cursor-pointer text-primary" @click="toLevelEvent">{{ t('addLevel') }}</span>
					</div>
				</el-form-item>
				<el-form-item :label="t('category')" prop="category_id">
					<el-cascader :options="levelTree" :props="props" v-model="formData.category_id" collapse-tags="true" 
						:placeholder="t('categoryPlaceholder')" @change="clearFieldError('category_id')">
					</el-cascader>
					<div class="ml-[10px]">
						<span class="cursor-pointer text-primary mr-[10px]"
							@click="refreshCategory()">{{ t('refresh') }}</span>
						<span class="cursor-pointer text-primary" @click="toCategoryEvent">{{ t('addCategory') }}</span>
					</div>
				</el-form-item>
				<el-form-item :label="t('proportion')">
					<el-radio-group v-model="formData.distribute_type">
						<el-radio :label="item.key" v-for="(item,index) in distributetypeList"
							:key="index">{{item.title}}</el-radio>
					</el-radio-group>
				</el-form-item>
				<el-form-item :label="t('oneRate')" prop="order_rate" v-if="formData.distribute_type != 'default'">
					<div>
						<el-input v-model.trim="formData.order_rate" maxlength="6" clearable class="input-width !w-[150px]"
							max="100" @keyup="filterDigit($event)">
							<template #append>%</template>
						</el-input>
					</div>
				</el-form-item>

				<el-form-item :label="t('certificate')" prop="certificate">
					<upload-image v-model="formData.certificate" :limit="5" @change="clearFieldError('certificate')" />
				</el-form-item>

				<!-- 地址选择区域 -->
				<el-form-item :label="t('technicianAddress')" prop="address_area">
					<el-select v-model="formData.province_info" value-key="id" clearable class="w-[200px]"
						@change="checkCity">
						<el-option :label="t('provincePlaceholder')" value="" />
						<el-option v-for="(province, index) in areaList.province" :key="index" :label="province.name"
							:value="province" />
					</el-select>
					<el-select v-model="formData.city_info" value-key="id" clearable class="w-[200px] ml-3"
						@change="checkDistrict">
						<el-option :label="t('cityPlaceholder')" value="" />
						<el-option v-for="(city, index) in areaList.city" :key="index" :label="city.name"
							:value="city" />
					</el-select>
					<el-select v-model="formData.district_info" value-key="id" clearable class="w-[200px] ml-3"
						@change="check">
						<el-option :label="t('districtPlaceholder')" value="" />
						<el-option v-for="(district, index) in areaList.district" :key="index" :label="district.name"
							:value="district" />
					</el-select>
				</el-form-item>
				<el-form-item :label="t('chooseMap')" prop="address">
					<div>
						<div>
							<el-input v-model.trim="formData.address" clearable
								:placeholder="t('addressDetailPlaceholder')" class="input-width" />
							<el-button class="ml-3" @click="searchOn">{{ t('search') }}</el-button>
						</div>
						<div class="mt-4">
							<div id="TxMap" class="map-item w-[800px] h-[500px]"></div>
						</div>
					</div>
				</el-form-item>
			</el-form>
		</el-card>
		<div class="fixed-footer-wrap ">
			<div class="fixed-footer">
				<el-button type="primary" @click="onSave(formRef)">{{ t('save') }}</el-button>
				<el-button @click="back()">{{ t('cancel') }}</el-button>
			</div>
		</div>
	</div>

	<!-- 会员选择对话框 -->
	<el-dialog v-model="dialogMemberVisible" title="请选择会员" width="720px">
		<el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
			<el-form :inline="true" :model="technicianTable" ref="searchFormRef">
				<el-form-item :label="t('keyword')" prop="keyword">
					<el-input v-model.trim="technicianTable.keyword" :placeholder="t('keywordPlaceholder')" />
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="getMemberListFn()">{{ t('search') }}</el-button>
					<el-button @click="resetForm(searchFormRef)">{{ t('reset') }}</el-button>
				</el-form-item>
			</el-form>
		</el-card>
		<el-table :data="memberList.data" v-loading="memberList.loading" class="member-table">
			<template #empty>
				<span>{{ !memberList.loading ? t('emptyData') : '' }}</span>
			</template>
			<el-table-column prop="nickname" label="昵称" width="180" />
			<el-table-column prop="username" label="用户名" />
			<el-table-column prop="mobile" label="手机号" width="180" />
			<el-table-column :label="t('operation')" fixed="right" min-width="50" align="right">
				<template #default="{ row }">
					<el-button type="primary" link @click="confirmEvent(row)">确定</el-button>
				</template>
			</el-table-column>
		</el-table>
		<div class="mt-[16px] flex justify-end">
			<el-pagination v-model:current-page="memberList.page" v-model:page-size="memberList.limit"
				layout="total, sizes, prev, pager, next, jumper" :total="memberList.total"
				@size-change="getMemberListFn" @current-change="getMemberListFn" />
		</div>
	</el-dialog>

	<!-- 门店选择对话框 -->
	<el-dialog v-model="storeDialog" title="请选择门店" width="720px">
		<el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
			<el-form :inline="true" :model="storeSearchForm" ref="searchStoreFormRef">
				<el-form-item :label="t('stroeKeyword')" prop="store_name">
					<el-input v-model.trim="storeSearchForm.store_name" :placeholder="t('stroeKeywordPlaceholder')" />
				</el-form-item>
				<el-form-item>
					<el-button type="primary" @click="getStoreListFn()">{{ t('search') }}</el-button>
					<el-button @click="resetStoreForm(searchStoreFormRef)">{{ t('reset') }}</el-button>
				</el-form-item>
			</el-form>
		</el-card>
		<el-table :data="storeList.data" v-loading="storeList.loading" class="member-table">
			<template #empty>
				<span>{{ !storeList.loading ? t('emptyData') : '' }}</span>
			</template>
			<el-table-column prop="store_name" label="门店名称" width="180" />
			<el-table-column prop="status" label="会员信息" min-width="120">
				<template #default="{ row }">
				    <div class="flex items-center">
				        <div class="w-[60px] max-h-[60px] mr-[10px]">
				            <img class="max-w-[60px] w-[60px] max-h-[60px] flex-shrink-0" :src="img(row.member.headimg)" v-if="row.member.headimg_mid"/>
				            <img class="w-[60px] h-[60px] " v-else src="@/addon/home_service/assets/default_headimg.png" alt="">
				        </div>
				        <div class="flex flex-wrap">
				            <p class="w-[100%] truncate">{{ row.member.username }}</p>
				        </div>
				    </div>
				</template>
			</el-table-column>
			<el-table-column prop="mobile" label="联系电话" width="180" />
			<el-table-column :label="t('operation')" fixed="right" min-width="50" align="right">
				<template #default="{ row }">
					<el-button type="primary" link @click="confirmStoreEvent(row)">确定</el-button>
				</template>
			</el-table-column>
		</el-table>
		<div class="mt-[16px] flex justify-end">
			<el-pagination v-model:current-page="storeList.page" v-model:page-size="storeList.limit"
				layout="total, sizes, prev, pager, next, jumper" :total="storeList.total" @size-change="getStoreListFn"
				@current-change="getStoreListFn" />
		</div>
	</el-dialog>

</template>

<script lang="ts" setup>
	import { ref, reactive, computed, nextTick, onMounted, onUnmounted, watch } from 'vue'
	import { t } from '@/lang'
	import { ArrowLeft } from "@element-plus/icons-vue"
	import { ElMessage, type FormInstance } from 'element-plus'
	import {
		getTechnicianDetail,
		editTechnician,
		addTechnician,
		getPositionListTo,
		getMemberList,
		getdistributetype
	} from '@/addon/home_service/api/technician'
	import { getLevelList, getLevelTree } from '@/addon/home_service/api/level'
	import { getStoreListTo } from '@/addon/home_service/api/technician'
	import cloneDeep from 'lodash-es/cloneDeep'
	import { filterDigit, filterNumber } from '@/utils/common'
	import { useRoute, useRouter } from 'vue-router'
	import { getAreaListByPid, getAreatree, getAddressInfo, getContraryAddress, getMap } from '@/app/api/sys'


	// 地图相关变量
	let mapFn : any = null
	let mapScriptLoaded = false

	// 地区列表
	interface areaType {
		province : any[],
		city : any[],
		district : any[]
	}
	const areaList = reactive<areaType>({
		province: [],
		city: [],
		district: []
	})
	const distributetypeList = ref([])
	const getdistributetypeFn = () => {
		getdistributetype().then((res) => {
			Object.keys(res.data).forEach((item, index) => {
				let obj = { title: res.data[item], key: item }
				distributetypeList.value.push(obj)
			})
		})
	}
	getdistributetypeFn()

	// 初始化地区数据
	const checkAreatress = () => {
		getAreatree(1).then(res => {
			areaList.province = res.data
		})
	}
	checkAreatress()
	// 地区选择逻辑 - 调整为酒店页面同款逻辑
	const checkCity = (province : any = {}) => {
		// 若未传参（回显时触发），用formData中已有的province_id
		if (Object.keys(province).length === 0) {
			province.id = formData.province_id;
		} else {
			// 正常选择时更新formData
			formData.province_id = province.id;
			formData.province_name = province.name;
			formData.province_info = province; // 绑定选项列表中的对象（关键）
		}

		if (!province.id) {
			// 清空下级数据
			formData.city_info = null;
			formData.city_id = '';
			formData.city_name = '';
			formData.district_info = null;
			formData.district_id = '';
			formData.district_name = '';
			areaList.city = [];
			areaList.district = [];
			return;
		}

		// 加载城市列表并更新到areaList（确保选项列表是最新的）
		getAreaListByPid(province.id).then(res => {
			areaList.city = res.data;
			// 回显时自动匹配城市
			if (formData.city_id && res.data.length) {
				const matchedCity = res.data.find((item : any) => item.id === Number(formData.city_id));
				if (matchedCity) {
					formData.city_info = matchedCity; // 绑定选项列表中的对象
				}
			}
		});
	};

	const checkDistrict = (city : any = {}) => {
		// 若未传参（回显时触发），用formData中已有的city_id
		if (Object.keys(city).length === 0) {
			city.id = formData.city_id;
		} else {
			// 正常选择时更新formData
			formData.city_id = city.id;
			formData.city_name = city.name;
			formData.city_info = city; // 绑定选项列表中的对象（关键）
		}

		if (!city.id) {
			// 清空下级数据
			formData.district_info = null;
			formData.district_id = '';
			formData.district_name = '';
			areaList.district = [];
			return;
		}

		// 加载区县列表并更新到areaList
		getAreaListByPid(city.id).then(res => {
			areaList.district = res.data;
			// 回显时自动匹配区县
			if (formData.district_id && res.data.length) {
				const matchedDistrict = res.data.find((item : any) => item.id === Number(formData.district_id));
				if (matchedDistrict) {
					formData.district_info = matchedDistrict; // 绑定选项列表中的对象
				}
			}
		});
	};

	const check = (district : any) => {
		if (!district) {
			formData.district_id = '';
			formData.district_name = '';
			return;
		}
		formData.district_id = district.id;
		formData.district_name = district.name;
		formData.district_info = district; // 绑定选项列表中的对象（关键）
			// 清除地址验证错误
		clearFieldError('address_area')
	};

	// 地址搜索逻辑
	const searchOn = () => {
		if (formData.province_id && formData.city_id && formData.district_id && formData.address) {
			formData.full_address = `${formData.province_name}${formData.city_name}${formData.district_name}${formData.address}`
			getAddressInfo({ address: formData.full_address }).then(res => {
				if(res.data.result){
					formData.lat = res.data.result.location.lat
					formData.lng = res.data.result.location.lng
				}else{
					ElMessage.error(res.data.message)
				}
				
			})
		}
	}

	// 地图初始化
	const initMap = () => {
		if (mapScriptLoaded) {
			createMapInstance()
			return
		}

		getMap().then(res => {
			const mapScript = document.createElement('script')
			mapScript.type = 'text/javascript'
			mapScript.src = 'https://map.qq.com/api/gljs?v=1.exp&key=' + res.data.key
			document.body.appendChild(mapScript)

			mapScript.onload = () => {
				mapScriptLoaded = true
				createMapInstance()
			}

			mapScript.onerror = () => {
				console.error('地图脚本加载失败')
				ElMessage.error('地图加载失败，请重试')
			}
		})
	}

	// 地图实例创建
	let markerLayer : any = null
	const createMapInstance = () => {
		if (mapFn) {
			mapFn.destroy()
		}

		let latitude = formData.lat || '39.90469'
		let longitude = formData.lng || '116.40717'
		const center = new window.TMap.LatLng(latitude, longitude)

		mapFn = new window.TMap.Map('TxMap', {
			center: center,
			zoom: 17,
			viewMode: '2D',
			showControl: true
		})

		markerLayer = new window.TMap.MultiMarker({
			id: 'marker-layer',
			map: mapFn,
			minimumClusterSize: 1
		})

		markerLayer.updateGeometries({
			id: 'technician',
			position: center
		})

		// 地图点击事件
		mapFn.on('click', (evt : any) => {
			const evtModel = {
				lat: evt.latLng.getLat().toFixed(6),
				lng: evt.latLng.getLng().toFixed(6)
			}

			markerLayer.updateGeometries({
				id: 'technician',
				position: evt.latLng
			})

			checkAddressInfo(evtModel.lat, evtModel.lng, 1)
		})

		// 地图 idle 事件
		mapFn.on('idle', () => {
			watch(() => [formData.lat, formData.lng], (newVal) => {
				if (newVal[0] && newVal[1]) {
					const latLng = new window.TMap.LatLng(newVal[0], newVal[1])
					mapFn.panTo(latLng)
					markerLayer.updateGeometries({
						id: 'technician',
						position: latLng
					})
				}
			})
		})
	}

	// 逆地址解析
	const checkAddressInfo = (lat : any, lng : any, type : any) => {
		getContraryAddress({
			location: lat + ',' + lng
		}).then(res => {
			if (res.data.result) {
				const addressComponent = res.data.result.address_component
				formData.province_name = addressComponent.province || ''
				formData.city_name = addressComponent.city || ''
				formData.district_name = addressComponent.district || ''

				// 根据名称匹配ID
				if (formData.province_name) {
					const matchedProvince = areaList.province.find(item => item.name === formData.province_name)
					if (matchedProvince) {
						formData.province_info = matchedProvince
						formData.province_id = matchedProvince.id
						getAreaListByPid(matchedProvince.id).then(res => {
							areaList.city = res.data
							const matchedCity = areaList.city.find(item => item.name === formData.city_name)
							if (matchedCity) {
								formData.city_info = matchedCity
								formData.city_id = matchedCity.id
								getAreaListByPid(matchedCity.id).then(res => {
									areaList.district = res.data
									const matchedDistrict = areaList.district.find(item => item.name === formData.district_name)
									if (matchedDistrict) {
										formData.district_info = matchedDistrict
										formData.district_id = matchedDistrict.id
									}
								})
							}
						})
					}
				}

				if (type == 1) {
					formData.address = res.data.result.formatted_addresses.recommend
					formData.full_address = formData.province_name + formData.city_name + formData.district_name + formData.address
					formData.lat = lat
					formData.lng = lng
				}
			} else {
				ElMessage({
					type: 'warning',
					message: res.data.message || '获取地址信息失败'
				})
			}
		}).catch(err => {
			console.error('地址解析失败:', err)
			ElMessage.error('获取地址信息失败')
		})
	}

	// 组件挂载时初始化地图
	onMounted(async () => {
		if (id) {
			await setFormData(id) // 等待数据加载
		}
		nextTick(() => {
			initMap() // 初始化地图
		})
	})

	// 组件卸载时清理地图
	onUnmounted(() => {
		if (mapFn) {
			mapFn.destroy()
			mapFn = null
		}
	})

	// 师傅业务逻辑
	const route = useRoute()
	const router = useRouter()
	const id : number = parseInt(route.query.id as string) || 0
	const loading = ref(false)
	const props = { multiple: true, value: 'category_id', label: 'category_name' }

	/**
	 * 表单数据
	 */
	const initialFormData = {
		id: id ?? '',
		real_name: '',
		headimg: '',
		status: '1',
		member_nickname: '',
		member_id: '',
		mobile: '',
		// 门店相关字段
		store_id: '',
		store_name: '',
		category_id: [],
		distribute_type: 'default',
		order_rate: '',
		additional_rate: '',
		certificate: '',
		// 地址相关字段
		province_info: null,
		province_id: '',
		province_name: '',
		city_info: null,
		city_id: '',
		city_name: '',
		district_info: null,
		district_id: '',
		district_name: '',
		address: '',
		full_address: '',
		lng: 0,
		lat: 0,
	}
	const formData : Record<string, any> = reactive({ ...initialFormData })
	const technicianTable : Record<string, any> = reactive({})
	const storeSearchForm : Record<string, any> = reactive({})
	const searchFormRef = ref()
	const resetForm = (formEl : any) => {
		if (!formEl) return
		formEl.resetFields()
		getMemberListFn()
	}

	const levelList = ref([])
	const getLevelListFn = () => {
		getLevelList().then((res) => {
			levelList.value = res.data.data
		})
	}
	const levelTree = ref([])
	const getLevelTreeFn = () => {
		getLevelTree().then((res) => {
			levelTree.value = res.data
		})
	}
	getLevelTreeFn()
	const refreshCategory = () => {
		getLevelTree().then((res) => {
			levelTree.value = res.data
		})
	}
	const refreshLevel = () => {
		getLevelList().then((res) => {
			levelList.value = res.data.data
		})
	}
	getLevelListFn()
	const searchStoreFormRef = ref()
	const resetStoreForm = (formEl : any) => {
		if (!formEl) return
		formEl.resetFields()
		getStoreListFn()
	}
	const toLevelEvent = () => {
		const url = router.resolve({
			path: '/home_service/technician/level_edit'
		})
		window.open(url.href)
	}
	const toCategoryEvent = () => {
		const url = router.resolve({
			path: '/home_service/goods/category'
		})
		window.open(url.href)
	}
	const inputStatus = ref(false)
	const inputTag = ref('')
	const InputRef = ref()
	const handleClose = (tag : string) => {
		formData.label.splice(formData.label.indexOf(tag), 1)
	}
	const showInput = () => {
		inputStatus.value = true
		nextTick(() => {
			InputRef.value!.input!.focus()
		})
	}
	const handleInputConfirm = () => {
		if (inputTag.value) {
			if (formData.label.includes(inputTag.value)) {
				ElMessage.error('添加的标签已存在')
			} else {
				formData.label.push(inputTag.value)
			}
		}
		inputStatus.value = false
		inputTag.value = ''
	}

	// 初始化表单数据 - 修复省市区ID回显
	const setFormData = async (id : number = 0) => {
		loading.value = true
		Object.assign(formData, initialFormData)
		const data = await (await getTechnicianDetail(id)).data
		Object.keys(formData).forEach((key : string) => {
			if (data[key] != undefined) formData[key] = data[key]
			if (data[key] != undefined && key == 'label') {
				if (data[key] != '') {
					formData[key] = data[key].split(',')
				} else {
					formData[key] = []
				}
			}
		})
		formData.member_nickname = data.member?.nickname || ''
		if(data.store){
			formData.store_id = data.store.store_id || ''
			formData.store_name = data.store.store_name || ''
		}
		formData.level_id = data.level.level_id || ''
		formData.level_name = data.level.level_name || ''
		formData.address = data.full_address || ''
		formData.distribute_type = data.distribute_type
		formData.category_id = data.category_id.split(',').map(Number)
		console.log(formData)
		let posterParams = {
			goods_id: 10
		};
		loading.value = false
		// 关键：回显时主动触发地区列表加载（与酒店页面逻辑一致）
		if (formData.province_id) {
			// 先加载省份列表（确保选项列表存在）
			const provRes = await getAreaListByPid(0);
			areaList.province = provRes.data;
			// 匹配省份对象并触发城市加载
			const matchedProvince = areaList.province.find(p => p.id === Number(formData.province_id));
			if (matchedProvince) {
				formData.province_info = matchedProvince; // 绑定选项列表中的对象
				checkCity(); // 主动触发城市列表加载

				// 延迟触发区县加载（等待城市列表加载完成）
				setTimeout(() => {
					if (formData.city_id) {
						checkDistrict(); // 主动触发区县列表加载
					}
				}, 300);
			}
		}

		// 地图定位
		if (formData.lat && formData.lng) {
			nextTick(() => {
				if (mapFn) {
					const center = new window.TMap.LatLng(formData.lat, formData.lng)
					mapFn.panTo(center)
					markerLayer.updateGeometries({
						id: 'technician',
						position: center
					})
				}
			})
		}
	}
	if (id) setFormData(id)

	// 会员列表
	const memberList = reactive({
		page: 1,
		limit: 10,
		total: 0,
		loading: false,
		data: []
	})
	const getMemberListFn = (page : number = 1) => {
		memberList.loading = true
		memberList.page = page
		getMemberList({
			page: memberList.page,
			limit: memberList.limit,
			...technicianTable
		}).then((res : any) => {
			memberList.loading = false
			memberList.total = res.data.total
			memberList.data = res.data.data
		})
	}
	getMemberListFn()

	// 门店列表
	const storeList = reactive({
		page: 1,
		limit: 10,
		total: 0,
		loading: false,
		data: []
	})
	const getStoreListFn = (page : number = 1) => {
		storeList.loading = true
		storeList.page = page
		getStoreListTo({
			page: storeList.page,
			limit: storeList.limit,
			...storeSearchForm
		}).then((res : any) => {
			storeList.loading = false
			storeList.total = res.data.total
			storeList.data = res.data.data
		}).catch(() => {
			storeList.loading = false
		})
	}
	// 初始化加载门店列表
	getStoreListFn()

	const storeDialog = ref(false)
	const confirmStoreEvent = (val : any) => {
		formData.store_id = val.store_id
		formData.store_name = val.store_name
		storeDialog.value = false
		// 清除门店字段的验证错误
		clearFieldError('store_id')
		console.log(formData.store_id)
	}

	const dialogMemberVisible = ref(false)
	const confirmEvent = (val : any) => {
		formData.member_id = val.member_id
		formData.member_nickname = val.nickname
		dialogMemberVisible.value = false
		// 清除会员字段的验证错误
		clearFieldError('member_id')
	}

	const formRef = ref<FormInstance>()
	// 正则表达式
	const regExp = {
		required: /[\S]+/,
		number: /^\d{0,10}$/,
		digit: /^\d{0,10}(.?\d{0,2})$/,
		special: /^\d{0,10}(.?\d{0,3})$/
	}
	// 表单验证规则
	const validatePhone = (rule, value, callback) => {
		const phonePattern = /^1[3456789]\d{9}$/
		if (!value) {
			return callback(new Error('请输入联系电话'))
		} else if (!phonePattern.test(value)) {
			return callback(new Error('联系电话格式不正确'))
		} else {
			return callback()
		}
	}


	const oneRateCheck = (rule : any, value : any, callback : any) => {
		if (!value) {
			return callback(new Error(t('oneRatePlaceholderOne')))
		} else if (!regExp.digit.test(value)) {
			return callback(new Error(t('oneRatePlaceholderTwo')))
		} else if (value >= 100) {
			return callback(new Error(t('oneRatePlaceholderThree')))
		} else if (value < 0) {
			return callback(new Error(t('oneRatePlaceholderFour')))
		} else {
			return callback()
		}
	}
	const twoRateCheck = (rule : any, value : any, callback : any) => {
		if (!value) {
			return callback(new Error(t('twoRatePlaceholderOne')))
		} else if (!regExp.digit.test(value)) {
			return callback(new Error(t('twoRatePlaceholderTwo')))
		} else if (value >= 100) {
			return callback(new Error(t('twoRatePlaceholderThree')))
		} else if (value < 0) {
			return callback(new Error(t('twoRatePlaceholderFour')))
		} else {
			return callback()
		}
	}

	// 地址验证规则
	const validatePass = (rule : any, value : any, callback : any) => {
		if (formData.province_id == '' || formData.city_id == '' || formData.district_id == '') {
			callback(new Error(t('technicianAddressPlaceholder')))
		}
		callback()
	}
	const formRules = computed(() => {
		return {
			real_name: [{ required: true, message: t('technicianNamePlaceholder'), trigger: 'blur' }],
			headimg: [{ required: true, message: t('headimgPlaceholder'), trigger: 'change' }],
			certificate: [{ required: false, message: t('certificatePlaceholder'), trigger: 'change' }],
			mobile: [{ required: true, validator: validatePhone, trigger: 'blur' }],
			level_id: [{ required: true, message: t('levelPlaceholder'), trigger: 'blur' }],
			store_id: [{ required: true, message: t('storePlaceholder'), trigger: 'blur' }],
			member_id: [{ required: true, message: t('memberPlaceholder'), trigger: 'blur' }],
			category_id: [{ required: true, message: t('categoryPlaceholder'), trigger: 'change' }],
			order_rate: [{ required: true, validator: oneRateCheck, trigger: 'blur' }],
			// 地址相关验证
			address_area: [{ required: true, validator: validatePass, trigger: 'blur' }],
			address: [{ required: true, message: t('technicianAddressDetailPlaceholder'), trigger: 'blur' }]
		}
	})

	// 保存前检查省市区ID
	const onSave = async (formEl : FormInstance | undefined) => {
		// 防止重复提交和表单实例不存在的情况
		if (loading.value || !formEl) return


		// 执行表单验证
		await formEl.validate(async (valid) => {
			if (valid) {
				loading.value = true
				try {
					// 深拷贝表单数据，避免修改原始数据
					const submitData = cloneDeep(formData)

					// 处理分类ID：数组转逗号分隔字符串
					if (Array.isArray(submitData.category_id)) {
						// 扁平化数组并过滤空值
						submitData.category_id = submitData.category_id
							.flat()
							.filter(Boolean)
							.join(',')
					}

					// 处理费率默认值
					submitData.additional_rate = submitData.additional_rate || '0'
					submitData.order_rate = submitData.order_rate || '0'

					// 确保经纬度字段正确（与接口参数匹配）
					submitData.lng = submitData.lng || ''
					submitData.lat = submitData.lat || ''
					// 过滤不需要提交的辅助字段
					const {
						province_info,
						city_info,
						district_info,
						province_name,
						city_name,
						district_name,
						member_nickname,
						store_name,
						...params
					} = submitData
					// 根据是否有ID判断是新增还是编辑
					const saveFunction = formData.id ? editTechnician : addTechnician
					// 提交数据
					const response = await saveFunction(params)

					// 处理成功结果
					history.back()
				} catch (error : any) {
					// 处理错误
				} finally {
					// 无论成功失败都关闭加载状态
					loading.value = false
				}
			}
		})
	}

	const back = () => {
		history.back()
	}

	const topositionEvent = () => {
		const url = router.resolve({
			path: '/site/home_service/technician/position_list'
		})
		window.open(url.href)
	}
	const topositionEvent2 = () => {
		const url = router.resolve({
			path: '/site/home_service/goods/list'
		})
		window.open(url.href)
	}
	// 清除字段验证错误
const clearFieldError = (fieldName: string) => {
	if (formRef.value) {
		formRef.value.clearValidate(fieldName)
	}
}

</script>

<style lang="scss" scoped>
	.member-table :deep(.cell) {
		padding: 0 12px !important;
	}

	#TxMap {
		border: 1px solid #e4e4e4;
		border-radius: 4px;
	}

	.dialog-footer {
		display: flex;
		justify-content: flex-end;
		gap: 10px;
		margin-top: 20px;
	}

	.input-width {
		width: 500px;
	}

	.fixed-footer-wrap .fixed-footer {
		z-index: 1999 !important;
	}
</style>