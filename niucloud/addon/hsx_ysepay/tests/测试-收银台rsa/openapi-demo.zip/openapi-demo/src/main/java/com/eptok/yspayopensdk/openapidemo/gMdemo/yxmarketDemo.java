package com.eptok.yspayopensdk.openapidemo.gMdemo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.eptok.yspayopensdk.openapidemo.util.*;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.tomcat.util.codec.binary.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author yangx
 * @description TODO
 * @date 2021/10/9
 */
public class yxmarketDemo {

    private static final String ALLCHAR = "0123456789ABCDEF";

    /**
     * 发起方商户号 服务商在银盛给自己开设的商户号，即可当作发起方商户号
     * 生产环境需要使用自己的发起发商户号，并找相应的对接人员开通所需要的接口权限，并告知是国密还是RSA
     */
    private static final String CERT_ID = "826341457228011";

    /**
     * 银盛端公钥证书
     * 生产环境需要自行去开放平台上下载银盛公钥证书，也可以找对接人提供
     */
    private static final String YS_PUBLIC_CER_PATH = "D:/datas/SM2-test/sm2businessgate.cer";

    /**
     * 商户端私钥证书
     * 生产环境需要使用自己生产的私钥证书
     */
    private static final String MERC_PRIVATE_FILE= "D:/datas/SM2-test/826341457228011.sm2";

    /**
     * 商户端私钥证书密码
     * 生产环境需要使用自己私钥的密码
     */
    private static final String MERC_PRIVATE_FILE_PASSWORD = "a1234567";

    /**
     * 请求地址域名
     */
    private static final String HTTP_NET = "https://appdev.ysepay.com";
    //测试 https://appdev.ysepay.com
    //生产 https://ysgate.ysepay.com

    public static void main(String[] args) throws Exception {
        //批量解绑/绑定商户
        uploadMercActiveRelationDemo();

        // 绑定解绑活动
        //bindOrUnbindActive();
    }

    /**
     * 图片上传demo
     */
    public static void uploadMercActiveRelationDemo() throws Exception {
        String HTTP_URL = HTTP_NET + "/openapi/file/ysMarket/uploadMercActiveRelation";

        File file = new File("C:\\Users\\MI\\Downloads\\1.txt");

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String, String> reqMap = new HashMap<String, String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "file.ysMarket.uploadMercActiveRelation");
        //请求时间
        reqMap.put("timeStamp", getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset", "utf-8");
        //请求流水号
        reqMap.put("reqId", String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version", "1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        String check = GMSignUtils.encryptData(YS_PUBLIC_CER_PATH, key);
        reqMap.put("check", check);//加密后的密钥

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String, Object> bizContentMap = new HashMap<>();
        //meta媒体文件元素信息
        Map<String, String> metaJSONObject = new HashMap<>();
        FileInputStream fileInputStream = new FileInputStream(file);
        String sha256 = DigestUtils.sha256Hex(fileInputStream);
        metaJSONObject.put("sha256", sha256);
        //图片类型， A001-营业执照 A002-法人身份证正面(头像面) A003-法人身份证反面(国徽面) A004-结算账户正面(卡号面) A005-结算账户反面 A006-商户门头照片 A007-内景照片 A008-收银台照片 A009-手持身份证合影照片 A010-收单协议盖章页 A011-开户许可证 A012-收单协议首页 A013-非法人身份证头像面 A014-非法人身份证国徽面 B001-租赁合同 第一页 B002-租赁合同 第二页 B003-租赁合同 第三页 B004-法人/非法人手持授权书 B005-法人/非法人结算授权书 B006-租赁面积图片 B007-经营业务图片 B008-其他1 B009-其他2
        metaJSONObject.put("url", "http://localhost:8080");
        //设置媒体元素信息
        bizContentMap.put("meta", metaJSONObject);

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte = AESUtil.encrypt(JSONObject.toJSONBytes(bizContentMap, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for (String k : keys) {
            if ("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if (sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign = GMSignUtils.signMsgSM2(MERC_PRIVATE_FILE, MERC_PRIVATE_FILE_PASSWORD, sb1.toString());
        reqMap.put("sign", sign);

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            //云商服图片上传接口调用的发送文件接口和支付宝实名认证的文件上传接口调用的方法不一样，请注意！！！
            String result = HttpRequestUtil.sendPostFile(HTTP_URL, reqMap, file);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res, "UTF-8"));
            System.out.println("http请求返回的结果为:" + JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = GMSignUtils.getSignDataStr1(resMap).getBytes("UTF-8");
                GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(YS_PUBLIC_CER_PATH);
                boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code、subCode、businessData 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if (StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_, ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data, "UTF-8"));
                System.out.println("解密后的业务参数:" + new String(data, "UTF-8"));
            }
            System.out.println("解密后的完整参数为:" + JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("图片上传demo失败:" + e);
        }
    }

    public static void bindOrUnbindActive() throws Exception{

        String HTTP_URL = HTTP_NET + "/openapi/ysMarket/bindOrUnbindActive";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "ysMarket.bindOrUnbindActive");
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //银盛商户号
        reqMap.put("certId","zh_test001");//zh_test001测试环境可用商户号
        //reqMap.put("certId", "826584847220016");//826584847220016  生产环境测试可用商户号
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        String check = GMSignUtils.encryptData(YS_PUBLIC_CER_PATH,key);
        reqMap.put("check",check);//加密后的密钥

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        List<String> list=new ArrayList<String>();
        list.add("826392253310127");
        bizContentMap.put("mercIdList", "826392253310127");//银盛商户号最多100个
        bizContentMap.put("operateType", "1");//操作类型  1 绑定 2解绑
        bizContentMap.put("activId", "1604412");//活动编号
        bizContentMap.put("url", "http://120.26.198.71/input/yseNotify");//绑定结果通知地址

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign = GMSignUtils.signMsgSM2(MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD, sb1.toString());
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            byte[] srcData = GMSignUtils.getSignDataStr1(resMap).getBytes("UTF-8");
            GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(YS_PUBLIC_CER_PATH);
            boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo,Base64.decodeBase64(resMap.get("sign")),srcData);

            if(!validateSignResult){
                System.out.println("验签失败");
                return;
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/
            if(!"00000".equals(resMap.get("code"))){
                System.out.println("请求失败，code不为00000");
                return;
            }
            if(!"101".equals(resMap.get("subCode"))){
                System.out.println("业务失败，错误信息为:"+resMap.get("subMsg"));
                return;
            }
            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            byte[] dataEncode=Base64.decodeBase64(resMap.get("businessData"));
            byte[] data= AESUtil.decrypt(dataEncode, ByteUtil.hexStringToBytes(key));
            String businessData=new String(data,"UTF-8");
            System.out.println("返回的业务参数为:"+businessData);
        } catch (Exception e) {
            e.printStackTrace();
            throw  e;
        }
    }

    /**
     * 格式化当前日期时间字符串
     * @return
     */
    private static  String getCurrentDateTime(String pattern){
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(new Date());
    }

}
