package com.eptok.yspayopensdk.openapidemo.util;

import sun.misc.BASE64Encoder;

import java.io.File;
import java.io.FileInputStream;

public interface FileUtil {

    /**
     * file转base64
     * @param file
     * @return
     * @throws Exception
     */
    public static String encodeBase64File(File file) throws Exception {
        FileInputStream inputFile = null;
        try{
            inputFile = new FileInputStream(file);
            byte[] buffer = new byte[(int) file.length()];
            inputFile.read(buffer);
            return new BASE64Encoder().encode(buffer);
        }catch (Exception e){
            System.out.println("文件转换BASE64失败:"+e);
        }finally {
            if(inputFile !=null){
                inputFile.close();
            }
        }
        return null;
    }
}
