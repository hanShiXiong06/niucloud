package com.eptok.yspayopensdk.openapidemo.util;

import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;


public class RSA256Util {
	
	private static final String ALGORITHM = "SHA256withRSA";
	
	private static final String ALGORITHM_PKCS1PADDING = "RSA/ECB/PKCS1Padding";

	private static final String CHARSET = "utf-8";

	/**
	 * 签名算法
	 * @param data 待签名的数据
	 * @return
	 */
	public static String sign(String data,String pfxPath,String pfxPwd) throws Exception {
		PrivateKey privateKey = CertUtil.getSignCertPrivateKey(pfxPath,pfxPwd);
		String stringSign = new BASE64Encoder().encode(RSA256Util.signBySoft(privateKey, data.getBytes(CHARSET)));
		return stringSign;
	}

	/**
	 * 签名算法
	 * @param data 待签名的数据
	 * @return
	 */
	public static String signCrtStr(String data,String pfxStr,String pfxPwd) throws Exception {
		PrivateKey privateKey = CertUtil.getPriKeyObj(pfxStr);
		String stringSign = new BASE64Encoder().encode(RSA256Util.signBySoft(privateKey, data.getBytes(CHARSET)));
		return stringSign;
	}

	/**
	 * @param privateKey  私钥
	 * @param data 待签名的数据
	 * @return
	 * @throws Exception
	 */
	public static byte[] signBySoft(PrivateKey privateKey, byte[] data) throws Exception {
		Signature st = Signature.getInstance(ALGORITHM);
		st.initSign(privateKey);
		st.update(data);
		byte[] result = st.sign();
		return result;
	}

	/**
	 * 根据公钥证书路径去验证签名
	 */
	public static boolean validateSign(String crtPath,byte[] signData, byte[] srcData) throws Exception {
		return RSA256Util.validateSignBySoft(CertUtil.getValidateCert(crtPath).getPublicKey(), signData, srcData);
	}
	
	/**
	 * @Author 胡兴铭
	 * @Description 通过公钥字符串进行验签
	 * @Date 13:50 2021/10/20
	 * @Param 
	 * @return 
	*/
	public static boolean validateSignCrtStr(String crtStr,byte[] signData, byte[] srcData) throws Exception {
		return RSA256Util.validateSignBySoft(CertUtil.getPubKeyObj(crtStr), signData, srcData);
	}
	/**
	 * 软验证签名
	 * 
	 * @param publicKey
	 *            公钥
	 * @param signData
	 *            签名数据
	 * @param srcData
	 *            摘要
	 *            签名方法.
	 * @return
	 * @throws Exception
	 */
	public static boolean validateSignBySoft(PublicKey publicKey,byte[] signData, byte[] srcData) throws Exception {
		Signature st = Signature.getInstance(ALGORITHM);
		st.initVerify(publicKey);
		st.update(srcData);
		return st.verify(signData);
	}
	
	/**
	 * @Author 胡兴铭
	 * @Description 根据证书路径获取加密
	 * @Date 11:39 2021/10/20
	 * @Param
	 * @return
	*/
	public static byte[] encrypt(String crtPath,byte[] content) throws Exception{
		Cipher cipher=Cipher.getInstance(ALGORITHM_PKCS1PADDING);
		cipher.init(Cipher.ENCRYPT_MODE, CertUtil.getValidateCert(crtPath).getPublicKey());
		return cipher.doFinal(content);
	}


	/**
	 * @Author 胡兴铭
	 * @Description 根据公钥字符串加密
	 * @Date 11:41 2021/10/20
	 * @Param
	 * @return
	*/
	public static byte[] encryptCrtStr(String crtStr,byte[] content) throws Exception{
		Cipher cipher=Cipher.getInstance(ALGORITHM_PKCS1PADDING);
		cipher.init(Cipher.ENCRYPT_MODE, CertUtil.getPubKeyObj(crtStr));
		return cipher.doFinal(content);
	}
}

