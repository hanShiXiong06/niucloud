package com.eptok.yspayopensdk.openapidemo.gMdemo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.eptok.yspayopensdk.openapidemo.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.tomcat.util.codec.binary.Base64;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 单笔代付api
 * @author zhulongling
 * @Description
 * @create 2022-12-30 9:43
 */
public class BillPaySingleDemo {

    private static final String ALLCHAR = "0123456789ABCDEF";

    /**
     * 发起方商户号 服务商在银盛给自己开设的商户号，即可当作发起方商户号
     * 生产环境需要使用自己的发起发商户号，并找相应的对接人员开通所需要的接口权限，并告知是国密还是RSA
     */
    private static final String CERT_ID = "826341457228011";

    /**
     * 银盛端公钥证书
     * 生产环境需要自行去开放平台上下载银盛公钥证书，也可以找对接人提供
     */
    private static final String YS_PUBLIC_CER_PATH = "D:/datas/SM2-test/sm2businessgate.cer";


    /**
     * 商户端私钥证书
     * 生产环境需要使用自己生产的私钥证书
     */
    private static final String MERC_PRIVATE_FILE= "D:/datas/SM2-test/826341457228011.sm2";


    /**
     * 商户端私钥证书密码
     * 生产环境需要使用自己私钥的密码
     */
    private static final String MERC_PRIVATE_FILE_PASSWORD = "a1234567";

    /**
     * 请求地址域名
     */
//    private static final String HTTP_NET = "http://127.0.0.1:8089";
    private static final String HTTP_NET = "https://appdev.ysepay.com";
    //测试 https://appdev.ysepay.com
    //生产 https://ysgate.ysepay.com

    public static void main(String[] args) throws Exception {
        /** 1、单笔代付（平台内）API*/
//        singleTransactionInPlat();

        /** 2、单笔代付（银行卡）API*/
//        singleTransactionBankCard();

        /** 3、单笔代付查询API*/
//        singleTransactionQuery();

        /** 4、代付对账单下载API*/
        singleTransactionDownload();
    }

    /**
     * 单笔代付（平台内）API
     */
    public static void singleTransactionInPlat() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/unify/singleTransaction/inPlat";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "unify.singleTransaction.inPlat");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        String check = GMSignUtils.encryptData(YS_PUBLIC_CER_PATH,key);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //付款方商户号
        bizContentMap.put("payerMercId",CERT_ID);
        //收款方商户号
        bizContentMap.put("payeeMercId","zh_test001");
        //商户订单号
        bizContentMap.put("orderId","202212301611020211");
        //订单日期
        bizContentMap.put("shopDate","20221230");
        //业务代码
        bizContentMap.put("busiCode","00050000");
        //币种
        bizContentMap.put("currency","CNY");
        //订单金额
        bizContentMap.put("amount","10");
        //订单备注
        bizContentMap.put("note","测试数据");
        //电话号码
        bizContentMap.put("phoneNo","18575594510");
        //发起方IP
        bizContentMap.put("srcIP","10.12.115");
        //⼆级商户信息
        bizContentMap.put("subMerchantInfo","");
        //通知回调地址
        bizContentMap.put("notifyUrl","www.baidu.com");

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign = GMSignUtils.signMsgSM2(MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD, sb1.toString());
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = GMSignUtils.getSignDataStr1(resMap).getBytes("UTF-8");
                GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(YS_PUBLIC_CER_PATH);
                boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    return;
                }
            }else{
                System.out.println("验签失败,未返回加签信息,可能是未配置发起方或者未配置发起方的证书类型,返回结果提示为:{}"+resMap.get("msg"));
                return;
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("单笔代付（平台内）API失败:"+e.getMessage());
        }
    }

    /**
     * 单笔代付（银行卡）API
     */
    public static void singleTransactionBankCard() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/unify/singleTransaction/bankCard";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "unify.singleTransaction.bankCard");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        String check = GMSignUtils.encryptData(YS_PUBLIC_CER_PATH,key);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //付款方商户号
        bizContentMap.put("payerMercId","pinganyinhang02");
        //商户订单号
        bizContentMap.put("orderId","202212301611023311");
        //订单日期
        bizContentMap.put("shopDate","20221230");
        //业务代码
        bizContentMap.put("busiCode","00050000");
        //币种
        bizContentMap.put("currency","CNY");
        //订单金额
        bizContentMap.put("amount","100");
        //订单备注
        bizContentMap.put("note","测试数据");
        //发起方IP
        bizContentMap.put("srcIP","10.12.115");
        //银行名称
        bizContentMap.put("bankName","招商银行深圳分行");
        //开户行所在省份名称
        bizContentMap.put("bankProvinceName","");
        //开户行所在省份编码
        bizContentMap.put("bankProvinceCode","");
        //开户行所在城市名称
        bizContentMap.put("bankCityName","4210");
        //开户行所在城市编码
        bizContentMap.put("bankCityCode","4210");
        //银行帐号
        bizContentMap.put("bankAccountNo","6226090000000048");
        //银行帐号用户名
        bizContentMap.put("bankAccountName","张三");
        //收款方银行账户类型
        bizContentMap.put("bankAccountType","11");
        //支持卡类型
        bizContentMap.put("bankCardType","debit");
        //银行预留手机号码
        bizContentMap.put("bankPhoneNo","13812301230");
        //收款方证件类型
        bizContentMap.put("certType","00");
        //收款方证件号码
        bizContentMap.put("certNo","360718199310113915");
        //款方证件有效期
        bizContentMap.put("certExpire","20221110");
        //⼆级商户信息
        bizContentMap.put("subMerchantInfo","");
        //通知回调地址
        bizContentMap.put("notifyUrl","10.12.669");

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign = GMSignUtils.signMsgSM2(MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD, sb1.toString());
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = GMSignUtils.getSignDataStr1(resMap).getBytes("UTF-8");
                GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(YS_PUBLIC_CER_PATH);
                boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    return;
                }
            }else{
                System.out.println("验签失败,未返回加签信息,可能是未配置发起方或者未配置发起方的证书类型,返回结果提示为:{}"+resMap.get("msg"));
                return;
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("单笔代付（银行卡）API失败:"+e.getMessage());
        }
    }

    /**
     * 单笔代付查询API
     */
    public static void singleTransactionQuery() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/unify/singleTransaction/query";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "unify.singleTransaction.query");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        String check = GMSignUtils.encryptData(YS_PUBLIC_CER_PATH,key);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //商户订单号
        bizContentMap.put("orderId","202212301611023311");
        //订单日期
        bizContentMap.put("shopDate","20221230");

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign = GMSignUtils.signMsgSM2(MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD, sb1.toString());
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = GMSignUtils.getSignDataStr1(resMap).getBytes("UTF-8");
                GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(YS_PUBLIC_CER_PATH);
                boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    return;
                }
            }else{
                System.out.println("验签失败,未返回加签信息,可能是未配置发起方或者未配置发起方的证书类型,返回结果提示为:{}"+resMap.get("msg"));
                return;
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("单笔代付查询失败:"+e.getMessage());
        }
    }

    /**
     * 代付对账单下载API
     */
    public static void singleTransactionDownload() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/unify/singleTransaction/download";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "unify.singleTransaction.download");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        String check = GMSignUtils.encryptData(YS_PUBLIC_CER_PATH,key);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //订单日期
        bizContentMap.put("shopDate","20221230");

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign = GMSignUtils.signMsgSM2(MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD, sb1.toString());
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = GMSignUtils.getSignDataStr1(resMap).getBytes("UTF-8");
                GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(YS_PUBLIC_CER_PATH);
                boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    return;
                }
            }else{
                System.out.println("验签失败,未返回加签信息,可能是未配置发起方或者未配置发起方的证书类型,返回结果提示为:{}"+resMap.get("msg"));
                return;
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("代付对账单下载失败:"+e.getMessage());
        }
    }


    /**
     * 格式化当前日期时间字符串
     * @return
     */
    private static  String getCurrentDateTime(String pattern){
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(new Date());
    }
}
