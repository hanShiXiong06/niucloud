package com.eptok.yspayopensdk.openapidemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenapiDemoApplicationTests {

    @Test
    void contextLoads() {
    }

}
