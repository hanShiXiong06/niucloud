package com.eptok.yspayopensdk.openapidemo.demo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.eptok.yspayopensdk.openapidemo.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.tomcat.util.codec.binary.Base64;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 报备demo
 */
public class ReportDemo {

    private static final String ALLCHAR = "0123456789ABCDEF";

    /**
     * 发起方商户号 服务商在银盛给自己开设的商户号，即可当作发起方商户号
     * 生产环境需要使用自己的发起发商户号，并找相应的对接人员开通所需要的接口权限，并告知是国密还是RSA
     */
    private static final String CERT_ID = "826440345119153";

    /**
     * 银盛端公钥证书
     * 生产环境需要自行去开放平台上下载银盛公钥证书，也可以找对接人提供
     */
    private static final String YS_PUBLIC_CER_PATH = "D:/datas/SHA-test/service.cer";

    /**
     * 商户端的私钥证书
     * 生产环境需要使用自己生产的私钥证书
     */
    private static final String MERC_PRIVATE_FILE = "D:/datas/SHA-test/826440345119153/client.pfx";

    /**
     * 商户端私钥证书密码
     * 生产环境需要使用自己私钥的密码
     */
    private static final String MERC_PRIVATE_FILE_PASSWORD = "123456";

    /**
     * 请求地址域名
     */
    private static final String HTTP_NET = "https://appdev.ysepay.com";
    //测试 https://appdev.ysepay.com
    //生产 https://ysgate.ysepay.com

    public static void main(String[] args) throws Exception {
        /** 1、新增报备信息*/
        //reportAdd();

        /** 2、查询报备信息*/
        //queryReport();

        /** 3、邮储数字人民币报备*/
        //psbcReportDemo();

        /** 4、兴业数字人民币报备*/
        //cibReportDemo();

        /** 5、数字人民币报备查询*/
        //digitalRmbSerchDemo();

        /** 6、数字人民币报备撤销*/
        digitalRmbRevokeDemo();
    }

    /**
     * 数字人民币报备查询接口
     */
    public static void digitalRmbRevokeDemo() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/report/digitalRmb/revoke";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "report.scan.digitalRmb.revoke");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        byte[] byte1= RSA256Util.encrypt(YS_PUBLIC_CER_PATH, ByteUtil.hexStringToBytes(key));
        String check = Base64.encodeBase64String(byte1);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //商户号
        bizContentMap.put("mercId","shanghu_test");
        //报备渠道 目前仅支持邮储
        bizContentMap.put("reportChannel","PSBC");

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign= RSA256Util.sign(sb1.toString(),MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD);
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = SignUtil.getSignDataStr1(resMap).getBytes("UTF-8");
                boolean validateSignResult= RSA256Util.validateSign(YS_PUBLIC_CER_PATH,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("商户入网申请失败:"+e.getMessage());
        }
    }

    /**
     * 数字人民币报备查询接口
     */
    public static void digitalRmbSerchDemo() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/report/digitalRmb/search";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "report.scan.digitalRmb.search");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        byte[] byte1= RSA256Util.encrypt(YS_PUBLIC_CER_PATH, ByteUtil.hexStringToBytes(key));
        String check = Base64.encodeBase64String(byte1);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //商户号
        bizContentMap.put("mercId","shanghu_test");
        //报备渠道
        bizContentMap.put("reportChannel","CIB");

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign= RSA256Util.sign(sb1.toString(),MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD);
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = SignUtil.getSignDataStr1(resMap).getBytes("UTF-8");
                boolean validateSignResult= RSA256Util.validateSign(YS_PUBLIC_CER_PATH,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("商户入网申请失败:"+e.getMessage());
        }
    }

    /**
     * 兴业数字人民币报备
     */
    public static void cibReportDemo() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/report/digitalRmb/cib";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "report.scan.digitalRmb.cib");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        byte[] byte1= RSA256Util.encrypt(YS_PUBLIC_CER_PATH, ByteUtil.hexStringToBytes(key));
        String check = Base64.encodeBase64String(byte1);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //商户号
        bizContentMap.put("mercId","shanghu_test");

        //邮储报备个性化信息
        HashMap<String,Object> personalReportParamMap = new HashMap<>();
        personalReportParamMap.put("mercAttribute","01");
        personalReportParamMap.put("mercUrl","http://www.baidu.com");
        personalReportParamMap.put("mercICP","sdfaoh11");
        personalReportParamMap.put("mercIp","127.0.0.1");
        personalReportParamMap.put("walletId","0111120026000648");
        personalReportParamMap.put("walletType","WT01");
        personalReportParamMap.put("walletName","测贰六");
        personalReportParamMap.put("paySingleLimit","10");
        personalReportParamMap.put("dayAmountLimit","100");
        personalReportParamMap.put("monthAmountLimit","10000");
        personalReportParamMap.put("mercMcc","8651");
        personalReportParamMap.put("registerAddr","广东深圳");
        //邮储报备个性化信息
        bizContentMap.put("personalReportParam",personalReportParamMap);

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign= RSA256Util.sign(sb1.toString(),MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD);
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = SignUtil.getSignDataStr1(resMap).getBytes("UTF-8");
                boolean validateSignResult= RSA256Util.validateSign(YS_PUBLIC_CER_PATH,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("商户入网申请失败:"+e.getMessage());
        }
    }

    /**
     * 邮储数字人民币报备
     */
    public static void psbcReportDemo() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/report/digitalRmb/psbc";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "report.scan.digitalRmb.psbc");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        byte[] byte1= RSA256Util.encrypt(YS_PUBLIC_CER_PATH, ByteUtil.hexStringToBytes(key));
        String check = Base64.encodeBase64String(byte1);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //商户号
        bizContentMap.put("mercId","826440353119BJG");
        //商户信息-营业执照营业执照复印件(盖公章)
        bizContentMap.put("riskGradeInfo","{\"001\":\"01\",\"002\":\"01\",\"003\":\"01\",\"004\":\"01\",\"005\":\"01\",\"006\":\"01\",\"007\":\"01\",\"008\":\"02\",\"009\":\"01\"}");

        //邮储报备个性化信息
        HashMap<String,Object> personalReportParamMap = new HashMap<>();
        personalReportParamMap.put("mercMcc","5943");
        personalReportParamMap.put("longitude","110.065019");
        personalReportParamMap.put("latitude","33.234254");
        personalReportParamMap.put("mercProvinceCode","7901");
        personalReportParamMap.put("mercCityCode","7902");
        personalReportParamMap.put("mercAreaCode","7903");
        personalReportParamMap.put("legalProvinceCode","0001");
        personalReportParamMap.put("legalCityCode","0002");
        personalReportParamMap.put("legalAreaCode","0003");
        personalReportParamMap.put("certImg","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("digitalAgreement","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("busLincenceBegin","19930520");
        personalReportParamMap.put("busLincenceEnd","20230520");
        personalReportParamMap.put("sfzfrontphoto","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("sfzbackphoto","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("certBusScope","省内旅游");
        personalReportParamMap.put("storeIndoorImg","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("storeOutsidePic","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("extraImg","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("inspectPicImg","group1,M00/3C/93/CtUiI2LXoW-AZME0AAKqH-Bx_bs414.jpg");
        personalReportParamMap.put("txnCode","9001");
        personalReportParamMap.put("walletId","0081000000210635");
        personalReportParamMap.put("walletType","WT01");
        personalReportParamMap.put("walletName","测试钱包");
        personalReportParamMap.put("openChildWallet","0");
        personalReportParamMap.put("mercBusinessType","758");
        personalReportParamMap.put("mercSalType","00");
        //邮储报备个性化信息
        bizContentMap.put("personalReportParam",personalReportParamMap);

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign= RSA256Util.sign(sb1.toString(),MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD);
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = SignUtil.getSignDataStr1(resMap).getBytes("UTF-8");
                boolean validateSignResult= RSA256Util.validateSign(YS_PUBLIC_CER_PATH,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("商户入网申请失败:"+e.getMessage());
        }
    }

    /**
     * 新增报备信息
     */
    public static void reportAdd() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/report/scan/union/reportAdd";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "report.scan.union.reportAdd");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        byte[] byte1= RSA256Util.encrypt(YS_PUBLIC_CER_PATH, ByteUtil.hexStringToBytes(key));
        String check = Base64.encodeBase64String(byte1);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //交易报备渠道编号 CUPS_WECHAT-银联微信；CUPS_ALIPAY-银联支付宝；NUCC_WECHAT-网联微信；NUCC_ALIPAY-网联支付宝
        bizContentMap.put("channelCode","CUPS_ALIPAY");
        //商户号
        bizContentMap.put("mercId","826440357229B5S");
        //商户信息-营业执照营业执照复印件(盖公章)
        bizContentMap.put("linencePhoto","");
        //商户信息-法人身份证复印件（盖私章，签字）/原件扫描件
        bizContentMap.put("indentityPhoto","");
        //商户信息-服务协议复印件（盖公章）/原件扫描件
        bizContentMap.put("protocolPhoto","");
        //商户信息-组织机构代码证（盖公章）/原件扫描件
        bizContentMap.put("cocc","");
        //商户信息-法人身份证正面照
        bizContentMap.put("sfzFrontPhoto","");
        //商户信息-法人身份证反面照
        bizContentMap.put("sfzBackPhoto","");
        //商户信息法人身份证号码
        bizContentMap.put("idcarNo","");
        //商户信息-银盛商户类型
        bizContentMap.put("mccSubCd","001");
        //业务类型0-微信 1-支付宝
        bizContentMap.put("busiType","0");
        //商户信息-商户简称
        bizContentMap.put("mercShortName","佩奇不是猪");
        //商户信息-商户归属省
        bizContentMap.put("mercProv","5800");
        //商户信息-商户归属市
        bizContentMap.put("mercCity","6020");
        //商户信息-商户归属区
        bizContentMap.put("mercArea","6020");
        //商户信息-营业地址（联系地址）
        bizContentMap.put("busAddr","海街道99号");
        //商户信息-联系人姓名
        bizContentMap.put("contactsName","小猪佩奇");
        //商户信息-联系人手机号
        bizContentMap.put("contactsTel","19901212345");
        //商户信息-联系人邮箱
        bizContentMap.put("contactsEmail","123@qq.com");
        //商户信息-法人姓名
        bizContentMap.put("crpNm","小猪佩奇");
        //商户信息-法人证件号
        bizContentMap.put("certNo","430626119301215716");
        //商户信息-代理商名称
        bizContentMap.put("agentName","");
        //商户信息-代理商编号
        bizContentMap.put("agtMercId","");
        //商户信息-开户行行别
        bizContentMap.put("bankType","1021000");
        //商户信息-开户行名称
        bizContentMap.put("bankName","中国工商银行股份有限公司深圳民治支行");
        //商户信息-账户类型
        bizContentMap.put("accountType","11");
        //商户信息-账户名称
        bizContentMap.put("accountName","佩奇");
        //商户信息-账户账号
        bizContentMap.put("accountNo","622700201181296");
        //商户信息-客户号
        bizContentMap.put("custId","1000");
        //商户信息-报备行业类型
        bizContentMap.put("mchType","404");
        bizContentMap.put("mercName","");
        bizContentMap.put("reportName","");
        //商户信息-商户类别 0或null：普通企业商户，1：小微商户,2：个体商户,3：事业单位，4：社会组织（原其他组织）， 5：政府机关
        bizContentMap.put("mercType","0");
        bizContentMap.put("certType","");
        bizContentMap.put("pId","");
        bizContentMap.put("shopPhoto","");
        bizContentMap.put("storeEnvirPhoto","");
        bizContentMap.put("idImgHand","");
        bizContentMap.put("bankCardImg","");
        bizContentMap.put("bdShopPhoto","");
        bizContentMap.put("bdPosterPhoto","");
        bizContentMap.put("wxPlatform","");
        bizContentMap.put("idValidDateBegin","");
        bizContentMap.put("idValidDateEnd","");
        bizContentMap.put("busLincenceBegin","");
        bizContentMap.put("busLincenceEnd","");
        bizContentMap.put("managementType","");
        bizContentMap.put("storeName","");
        bizContentMap.put("wechatCheckStandPhoto","");
        bizContentMap.put("alipayCheckStandPhoto","");
        bizContentMap.put("aliPayStoreCashierPhoto","");
        bizContentMap.put("bookType","");
        bizContentMap.put("unitPhoto","");
        bizContentMap.put("hotLine","");
        //商户信息-证照类型 0:营业执照;1:事业单位法人证书;2:小微商户负责人身份证;3:社会信用等级证书
        bizContentMap.put("businessLicenseType","0");
        //商户信息-证件编号
        bizContentMap.put("businessLicense","9111234567891234");
        bizContentMap.put("appletAppId","");
        bizContentMap.put("appId1","");
        bizContentMap.put("appId2","");
        bizContentMap.put("appId3","");
        bizContentMap.put("appId4","");
        bizContentMap.put("applyServices","");
        bizContentMap.put("picType","");
        //商户信息-商户归属机构
        bizContentMap.put("orgNo","3221000002");

        //组装商户终端信息
        List<Map<String,Object>> lterminalInfoList = new ArrayList<>();
        Map<String,Object> lterminalInfoListMap = new HashMap<>();
        //终端操作标识 00-新增;01-修改;02-注销;不填默认为00
        lterminalInfoListMap.put("operationType","00");
        //终端类型 01 自动柜员机（含 ATM 和 CDM）和多媒体自助终端、02 传统 POS、03 mPOS、04 智能 POS、05 II 型固定电话、 06 云闪付终端、07 保留使用、08 手机 POS、09 刷脸付终端、10 条码支付受理终端、11 辅助受理终端、12 行业终端（公交、地铁用于指定行业的终端）、13 MIS 终端
        lterminalInfoListMap.put("terminalType","02");
        //终端编号
        lterminalInfoListMap.put("terminalNo","V2000000");
        //终端序列号
        lterminalInfoListMap.put("serialNum","00001");
        //终端布放地址
        lterminalInfoListMap.put("terminalAddr","广东省-深圳市-南山区-粤海");
        //终端状态 00启用,99 注销;此字段在终端操作标识、(operationType)为修改(01)时有效,为空默认为 启用(00);当终端操作标识(operationType)为新增(00)或注销(02)时， 此选项值无效
        lterminalInfoListMap.put("terminalState","");
        //终端机具型号 （除终端序列为07和11都必填）终端厂商的终端机具类型编号
        lterminalInfoListMap.put("terminalDevcMdl","00001");
        //终端定位功能标识 00:可定位；01：不可定位
        lterminalInfoListMap.put("terminalGpsFlg","00");
        lterminalInfoList.add(lterminalInfoListMap);
        //商户信息-终端信息列表
        bizContentMap.put("lterminalInfoList",lterminalInfoList);

        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign= RSA256Util.sign(sb1.toString(),MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD);
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = SignUtil.getSignDataStr1(resMap).getBytes("UTF-8");
                boolean validateSignResult= RSA256Util.validateSign(YS_PUBLIC_CER_PATH,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            System.out.println("商户入网申请失败:"+e.getMessage());
        }
    }


    /**
     * 查询报备信息
     */
    public static void queryReport() throws Exception {
        //请求接口
        String HTTP_URL = HTTP_NET + "/openapi/report/scan/union/repAndAppIdQry";

        /** 1、封装请求参数，bizContent（业务参数，需要加密）和check（需要生成密钥并加密）后面设置值*/
        Map<String,String> reqMap = new HashMap<String,String>();
        //接口方法名，根据接口文档取值
        reqMap.put("method", "report.scan.union.repAndAppIdQry");
        //请求时间
        reqMap.put("timeStamp",getCurrentDateTime("yyyy-MM-dd HH:mm:dd"));
        //固定utf-8
        reqMap.put("charset","utf-8");
        //请求流水号
        reqMap.put("reqId",String.valueOf(System.currentTimeMillis()));
        //发起方商户号，服务商在银盛给自己开设的商户号，即可当作发起方商户号，由银盛生成并下发。 注意：不同于子商户号，服务商发展的商户即为子商户号
        reqMap.put("certId", CERT_ID);
        //版本号，默认1.0，按接口文档来
        reqMap.put("version","1.0");

        /** 2、生成对业务参数加密的密钥*/
        StringBuilder sb = new StringBuilder();
        Random random = new Random();
        for (int i = 0; i < 16; i++) {
            sb.append(ALLCHAR.charAt(random.nextInt(ALLCHAR.length())));
        }
        String key = ByteUtil.toHexString(sb.toString());

        /** 3、使用银盛公钥对密钥key进行加密，得到加密的key并设置到请求参数check中。publicFilePath为存放银盛公钥的地址*/
        byte[] byte1= RSA256Util.encrypt(YS_PUBLIC_CER_PATH, ByteUtil.hexStringToBytes(key));
        String check = Base64.encodeBase64String(byte1);
        //加密后的密钥
        reqMap.put("check", check);

        /** 4、封装业务参数,具体参数见文档，这里只是举例子*/
        Map<String,Object> bizContentMap = new HashMap<>();
        //商戶号
        bizContentMap.put("mercId","826440357229B5S");
        //渠道号
        bizContentMap.put("channelId","CUPS_ALIPAY");
        JSONObject bizJSONObj = JSONObject.parseObject(JSON.toJSONString(bizContentMap));

        /** 5、使用生成的密钥key对业务参数进行加密，并将加密后的业务参数放入请求参数bizContent中*/
        byte[] bte= AESUtil.encrypt(JSONObject.toJSONBytes(bizJSONObj, SerializerFeature.WriteNullStringAsEmpty), ByteUtil.hexStringToBytes(key));
        String msgBizContent = Base64.encodeBase64String(bte);
        reqMap.put("bizContent", msgBizContent);

        /** 6、将请求参数进行sort排序，生成拼接的字符床，并使用接入方私钥对请求参数进行加签，并将加签的值存入请求参数sign中*/
        //6.1 排序生成拼接字符串
        List<String> keys = new ArrayList<String>(reqMap.keySet());
        Collections.sort(keys);
        StringBuilder sb1 = new StringBuilder();
        for(String k : keys){
            if("sign".equals(k)) {
                continue;
            }
            sb1.append(k).append("=");
            sb1.append(reqMap.get(k));
            sb1.append("&");
        }
        if(sb1.length() > 0) {
            sb1.setLength(sb1.length() - 1);
        }
        //6.2使用接入方私钥对排序的请求参数加签，并存放到请求参数里面.privateFilePath:私钥地址，prvatePassword:私钥密钥
        String sign= RSA256Util.sign(sb1.toString(),MERC_PRIVATE_FILE,MERC_PRIVATE_FILE_PASSWORD);
        reqMap.put("sign",sign );

        /** 7、发送http请求获取返回结果，请求地址以文档为准*/
        try {
            String result = HttpRequestUtil.getDoPostResponse(HTTP_URL, reqMap, "UTF-8", null, 20*1000);
            byte[] res = Base64.decodeBase64(result);
            Map<String, String> resMap = (Map<String, String>) JSONObject.parse(new String(res,"UTF-8"));
            System.out.println("http请求返回的结果为:"+JSONObject.toJSONString(resMap));

            /** 8、对结果进行解密，并使用银盛公钥验签*/
            if(StringUtils.isNotBlank(resMap.get("sign"))) {
                byte[] srcData = SignUtil.getSignDataStr1(resMap).getBytes("UTF-8");
                boolean validateSignResult= RSA256Util.validateSign(YS_PUBLIC_CER_PATH,Base64.decodeBase64(resMap.get("sign")),srcData);
                if(!validateSignResult){
                    System.out.println("验签失败");
                    throw new Exception("验签失败");
                }
            }else{
                throw new Exception("验签失败,未返回加签信息,可能是银盛未配置发起方或者发起方证书类型配置有误,返回结果提示为:{}"+resMap.get("msg"));
            }

            /** 9、针对自己的业务，根据返回的结果的code 和 subCode 做接入方的业务处理*/


            /** 10、使用上面生成的加密密钥key，解密返回的业务参数*/
            if(StringUtils.isNotBlank(resMap.get("businessData"))) {
                byte[] data_ = Base64.decodeBase64(resMap.get("businessData"));
                byte[] data = AESUtil.decrypt(data_,ByteUtil.hexStringToBytes(key));
                resMap.put("businessData", new String(data,"UTF-8"));
                System.out.println("解密后的业务参数:"+new String(data,"UTF-8"));
            }
            System.out.println("解密后的完整参数为:"+JSONObject.toJSONString(resMap));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * 格式化当前日期时间字符串
     * @return
     */
    private static  String getCurrentDateTime(String pattern){
        SimpleDateFormat sdf = new SimpleDateFormat(pattern);
        return sdf.format(new Date());
    }
}
