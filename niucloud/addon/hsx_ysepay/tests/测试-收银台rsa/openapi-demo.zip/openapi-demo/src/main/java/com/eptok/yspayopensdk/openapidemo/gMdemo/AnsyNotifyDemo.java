package com.eptok.yspayopensdk.openapidemo.gMdemo;

import com.alibaba.fastjson.JSONObject;
import com.eptok.yspayopensdk.openapidemo.util.GMCertInfo;
import com.eptok.yspayopensdk.openapidemo.util.GMSignUtils;
import com.eptok.yspayopensdk.openapidemo.util.HttpRequestUtil;
import org.apache.tomcat.util.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.HashMap;
import java.util.Map;

/**
 * @author yangx
 * @description TODO
 * @date 2021/10/9
 */
public class AnsyNotifyDemo {

    private static final Logger LOGGER = LoggerFactory.getLogger(AnsyNotifyDemo.class);

    @RequestMapping(value="notify/fat",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    public String notifyDemo(@RequestBody Map<String,String> param) throws Exception {
        /*1、打印异步通知参数*/
        LOGGER.info("异步通知接收的参数为:{}",JSONObject.toJSONString(param));
        if(param == null){
            //失败返回fail 字符串
            return "fail";
        }
        //设置银盛公钥证书，路径例如本地:C:/cert/openapi/fat/server/service.cer
        String certValue = "C:/cert/openapi/fat/server/service.cer";

        /*2、调用异步通知验签方法*/
        byte[] srcData = GMSignUtils.getSignDataStr1(param).getBytes("UTF-8");
        GMCertInfo verifyCertInfo = GMSignUtils.getVerifyCertInfo(certValue);
        boolean validateSignResult = GMSignUtils.verifyMsgSignSM2(verifyCertInfo, Base64.decodeBase64(param.get("sign")),srcData);
        LOGGER.info("异步通知结果验签为:{}",validateSignResult);
        if(!validateSignResult){
            LOGGER.error("验签失败，非法的异步通知");
            return "fail";
        }

        /*4、获取业务参数,具体业务参数详见文档，实现自己的逻辑代码*/
        String bizContent = param.get("bizContent");
        LOGGER.info("业务参数为:{}",bizContent);

        /*5、返回，成功返回success字符串*/
        return "success";
    }
}
