package com.eptok.yspayopensdk.openapidemo.util;


public class ApiResultCodeBean implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	public String code;

	public String subCode;

	public String msg;

	public String subMsg;

	private Object businessData;

	public ApiResultCodeBean() {
		super();
	}

	public ApiResultCodeBean(String msg) {
		this.msg = msg;
	}

	public ApiResultCodeBean(String code, String subCode, String msg) {
		this.code = code;
		this.subCode = subCode;
		this.msg = msg;
	}

	public ApiResultCodeBean(String code, String subCode, String subMsg, Object businessData) {
		this.code = code;
		this.subCode = subCode;
		this.subMsg = subMsg;
		this.businessData = businessData;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getSubCode() {
		return subCode;
	}

	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getSubMsg() {
		return subMsg;
	}

	public void setSubMsg(String subMsg) {
		this.subMsg = subMsg;
	}

	public Object getBusinessData() {
		return businessData;
	}

	public void setBusinessData(Object businessData) {
		this.businessData = businessData;
	}
}
