# 支付、退款、自动关单、通知与体验回归

日期：2026-11-09。对象：当前 hsx_lead 源码增量修复。未部署服务器、未上传小程序，未真实扣款、退款或发送通知。

## 1. 本轮实际修复

### 支付与自动关单

- 支付渠道或本地流水已收款，但权益因门店停用等原因未开通时，不再提示“权益已更新”。区分“已收款”和“业务已完成”，保留实际冲突原因，不诱导再次付款。
- 自动任务遇到本地已成功付款、业务回调尚未完成时，核对唯一流水的站点、付款人、业务和金额，再重放已有幂等业务确认。不会只是每分钟阻塞等待人工，也不重复入账或开通。
- 渠道曾返回成功、当时本地监听失败的临时状态，只对原流水查询恢复。后续返回 NOTPAY/CLOSED/超时均不能反过来授权取消这笔曾确认收款的原单。
- 门店封禁、权益冲突、多笔成功流水等真实核对标记不由自动任务清除。未知结果不强关、不另建收费、不自动退款。
- 关闭的是未付支付单，不撤销已成交线索的付佣责任。保持一次付款、费用分项记账，分佣边界不变；没有启用虚拟支付或改换网关。

### 退款与通知补偿

- 将押金原退款核对接入已有退款补偿任务。只核对已经提交的原 refund_no；不自动审批退出，不新建、不重发退款。
- 原退款成功已持久化、后续业务监听中断时，事务内补齐原成功事件；异常继续待核对，恢复后不重复退钱、入账或记审计。
- 一条通知对应的工单不存在、快照损坏或处理异常时，记录该条结果，其余任务继续，不再中断整轮补偿。
- 尚未提交的外层事务里禁止直接发送或管理员重发，避免业务回滚但消息已外发。事务内先保存意图，由已有队列／定时任务在提交后处理。
- 通知轮转游标是可重建的运行提示，改用牛云缓存，不再写 config；清缓存不丢通知意图或每渠道去重记录。
- 三个任务均将数量和结果保存到牛云计划任务日志，不再仅返回笼统的 true。“事件已处理”与“渠道已受理”“用户已收到”不混用。

### 移动端与后台

- 门店资料草稿由整对象深度监听同步写入改为约 400ms 去抖和字段白名单；最多数千项的交付能力只保存选项 ID。保留退出时补存，避免输入时反复序列化大量完整选项。
- 草稿按站点／账号／主体隔离并有有效期；不保存营业执照私密令牌、ERP 密码、私密补充表单答案或整份会员业务状态。账号变化后旧计时器和选择器回调不能写入新账号。
- 门店表单 API 的静默错误参数改到请求配置位置，不再附加无意义查询参数、同时弹全局错误和页内错误；仍保留明确页内错误、重试和禁存。
- 后台按等级筛选主体时，复用已有权益账本批量投影、分段读取候选，只展开当前页。退款、退出及真实付款仍参与判断，不用 partner 中可能过期的等级缓存冒充权益事实。
- 这不是“等级筛选已经完全改成 SQL 条件”：为保留账本推导口径，仍需扫描候选，但去除了逐店权益查询和为全站生成主体码的副作用。是否做物化查询模型应另行评估和显式升级。

## 2. 数据库设计与变更

本轮新增：**表 0、字段 0、索引 1**。已在实施前说明索引变更。

| 数据 | 本轮使用位置 | 不放在哪里 |
| --- | --- | --- |
| 支付、退款流水 | 牛云 pay、pay_refund | 不放 config、不用缓存当到账事实 |
| 收费快照、业务及原退款关联 | 现有 hsx_lead_coop_order | 不新增 config 动态键 |
| 邀请佣金、成员、业务审计 | 现有业务及审计表 | 不改成全局配置 |
| 通知意图与每渠道去重／回执 | 现有 audit 的有类型记录、唯一键和查询索引 | 不以缓存替代持久化事实 |
| 通知轮转游标 | 可丢弃的牛云缓存 | 不再写 config |
| 规则、开关、表单选项 | 原配置机制 | 不冒充订单或流水 |

在现有订单表增加 `idx_status_expiry(status, create_time, site_id, id)`，服务到期未付订单扫描。新安装 SQL 同步声明；已安装环境使用独立命令，不在 API、登录、任务中自动执行 DDL。

升级命令仅对目标 InnoDB 表添加索引：

- `--check` 只读，展示待执行项与表规模估计，不写缓存或备份。
- `--apply` 先私有备份原建表与索引结构，校验后执行 INPLACE、LOCK=NONE。不支持时失败，不自动降级为锁表建索引。
- 等效可见索引已存在则跳过；同名结构不同或同名不可见索引明确拒绝，不覆盖管理员设置。
- 元数据锁等待约 5 秒；DDL 独立提交，失败后重新 check，不声称事务已回滚。
- 在线建索引仍有磁盘和 I/O 成本，不等于零影响。先备份数据库，查看规模，在低峰执行。脚本备份是结构记录，不代替数据库备份。

现存历史债务：商户交付能力和大目录仍有原分片配置存储。这类可检索、多对多业务数据适合后续独立目录／能力关联表；本轮未新增此类 config 写入，也未借修支付暗中迁移、删除已上线资料。若继续处理，必须单列结构、显式迁移、核对与回退方案，不能把“不改表”当作设计目标。

## 3. 回归范围和证据

测试使用随机创建、自动清理的本机 MySQL 库，以及合成支付渠道／通知 HTTP 传输；不是线上或微信真机资金验收。

| 关键异常 | 核验标准 |
| --- | --- |
| 取消微信后续付／换方式 | 原单先核对，未知不新扣；保留可恢复入口 |
| 119／120／121 秒关单 | 不因刷新延期；到期才进入扫描；每分钟轮询不承诺第120秒精确关闭 |
| 关单与支付成功竞争 | 已收款优先，不伪造取消；只按原单补业务 |
| 本地成功、业务回调缺失 | 自动幂等补齐；重复回调不重复佣金、经验或期限 |
| 已收款、门店被停用 | 显示待核对，不误报开通；保留真实原因 |
| 已关闭订单迟到账 | 保留真实收款，核对新旧单，不擅自重开、开通或重复分账 |
| 押金／服务费／经验费退款 | 原金额和身份匹配；按分项回退，推广只计算服务费 |
| 原退款结果未知 | 查原 refund_no，不重发新退款 |
| 成功退款监听中断 | 自动补原业务事件，失败可再核对，不重复退钱 |
| 通知工单缺失／坏快照 | 单条失败可见，后续意图继续处理 |
| 部分渠道已提交／结果未知 | 只补缺失项，不盲目重发；双方、跨站和店内成员身份隔离 |
| 外层事务未提交 | 不直接推送，提交后由持久化意图恢复 |
| 数千交付项与长表单 | ID 化草稿、去抖、作用域隔离；错误后保留输入且不无效保存 |
| 索引升级 | 真实 EXPLAIN、在线升级、重复执行、同名异常和不可见索引 |

最终结果：

| 验证 | 结果 |
| --- | --- |
| PHP 8.0.30 本轮运行时／脚本语法 | 12／12 文件通过 |
| 纯逻辑回归 | 27／27 套通过 |
| 隔离数据库回归 | 82／82 套通过 |
| Vue／UI 行为回归 | 103／103 套通过 |
| 实际编译 H5 的浏览器交互／布局 | 7 项通过 |
| mp-weixin 原生构建产物检查 | 568 项通过 |
| 最终 H5／小程序隔离编译 | 均通过，未发布 |

全量合计 212 套；专项检查已包含于全量套件，不重复累加。后台 Vue 本轮未改，沿用前轮管理端编译结果，不冒称本轮又做了全后台视觉重设计。

专项包括支付网关恢复 42 项、119／120／121 秒关单及重复流水 42 项、付款恢复 28 项、押金补偿 60 项、普通订单退款 54 项、通知 Outbox 65 项、渠道／重发 57 项、双方身份 401 项、框架回执 125 项、实际 SDK 假 HTTP 168 项、草稿 35 项、等级筛选分页 18 项、在线索引 15 项，以及真实牛云三个任务日志 11 项。

回归过程也记录不稳定项，不用单次 PASS 掩盖：中途出现过本机连接地址不足、临时授权缓存未读到，以及一项 UI 输出 PASS 但进程结果非通过。已给测试运行器补退出码／信号／启动错误诊断；草稿测试连续五次自然退出、无遗留 Timeout。会员只读快照补主键排序，避免 SQL 无序结果被误判成财务变更。最后整轮已通过；临时环境问题未被扩展成对生产支付或 ERP 策略的改动，也不据此保证线上无故障。

本地实际 H5 记录：`output/hsx-lead-profile-mobile-20261109/report.json`；截图包括 `profile-mobile-320.png`、`profile-mobile-390.png`、`profile-mobile-430.png`、`profile-mobile-short-390.png`、`profile-mobile-error-320.png`、`profile-mobile-error-390.png`。

真实编译 H5 的 320／390／430px 与短屏检查，使用浏览器拦截的合成 API。原生输入法、系统授权、微信返回、真实上传、实际付款退款及通知终端送达未据此验收。离线环境拦截了原有 uview 外部字体，截图不作为图标完整性证明。

布局沿用牛云组件；参考转转样本 R11 的状态／搜索层级和 R14 的业务分组，保留本项目蓝色主题，不复制竞品素材或重写页面体系。

## 4. 本轮替换文件

以下相对项目根目录；补丁包只含本轮增量源码，依赖此前已同步的完整最新插件，不是独立安装包。

### 后端：niucloud/addon/hsx_lead/

```text
app/service/cooperation/PaymentOrderRecovery.php
app/service/cooperation/PaymentGatewayReconciler.php
app/service/cooperation/PaymentOrderLifecycle.php
app/service/cooperation/MembershipDepositService.php
app/service/cooperation/CooperationNoticeOutbox.php
app/service/cooperation/CooperationNoticeService.php
app/service/cooperation/TeamService.php
app/job/CloseUnpaidOrders.php
app/job/ReconcileOrderRefunds.php
app/job/RecoverCooperationNotices.php
app/dict/schedule/schedule.php
scripts/upgrade-runtime-indexes.php
sql/install.sql
install.sql
```

`install.sql` 是新安装声明，**已上线环境不要直接执行整份安装 SQL**。仅运行下节增量索引命令。

### 用户端：插件交付源及项目镜像，两组配套

```text
niucloud/addon/hsx_lead/uni-app/api/cooperation.ts
niucloud/addon/hsx_lead/uni-app/components/cooperation/CoopProfilePanel.vue
niucloud/addon/hsx_lead/uni-app/utils/profile-draft.ts
uni-app/src/addon/hsx_lead/api/cooperation.ts
uni-app/src/addon/hsx_lead/components/cooperation/CoopProfilePanel.vue
uni-app/src/addon/hsx_lead/utils/profile-draft.ts
```

本轮没有新增框架文件改动，也没有改管理端 Vue 源码；后台筛选改善在后端。前一轮万能表单的三个框架文件仍须保留，不能用“本轮无新增”理解为可以还原它们。

## 5. 更新顺序与命令

先备份当前源码和数据库，覆盖配套文件。下面命令都在服务器 **niucloud 后端目录** 执行，并使用网站相同的 PHP 8.0+ 二进制；不要在 admin/src 目录执行。

```bash
php addon/hsx_lead/scripts/upgrade-runtime-indexes.php --check
```

核对输出的目标表与规模，低峰执行索引升级并回读：

```bash
php addon/hsx_lead/scripts/upgrade-runtime-indexes.php --apply
php addon/hsx_lead/scripts/upgrade-runtime-indexes.php --check
php addon/hsx_lead/scripts/upgrade.php --check
php addon/hsx_lead/scripts/upgrade.php --apply
php addon/hsx_lead/scripts/configure-payment-timeout.php --enable
php think clear
```

上述命令不编译／发布客户端，不真实执行一次付款、退款或通知，不自动启动新进程。普通升级保留已有任务开关，新任务默认关闭；不能仅覆盖 Job 文件就宣称生产任务已运行。

平台后台“设置／工具 → 计划任务”（路由 `/admin/tools/schedule`）核对以下任务已启用：

| 任务 key | 周期 | 作用 |
| --- | --- | --- |
| hsx_lead_unpaid_order_close | 1 分钟 | 满2分钟的原支付核对、关闭或补收款业务 |
| hsx_lead_order_refund_reconcile | 2 分钟 | 普通退款及押金原退款补偿，不新退钱 |
| hsx_lead_notice_recover | 1 分钟 | 原通知意图补偿，不盲目重发 |

先确认当前项目原来使用哪种守护方式，只重载既有方式，不同时另启两套：

```bash
# 原来是合并 Workerman：
php think workerman status
php think workerman reload
```

```bash
# 原来是独立调度／队列，才使用这一组：
php think cron:schedule status
php think cron:schedule reload
php think queue:listen status
php think queue:listen reload
```

若状态显示未运行或模式不明，先按原 Supervisor／宝塔守护配置核对，不直接重复 start。重启 PHP-FPM 不等于 CLI 调度进程已加载新任务。

更新后可只读检查：

```bash
php addon/hsx_lead/scripts/configure-payment-timeout.php --check
```

在任务执行记录中确认 count／last_time 推进，并看日志中的 examined、closed、reconciled、blocked 及退款、通知分项。调度心跳存在不等于本任务已执行；blocked 也不是已关闭。

用户端按原项目流程重新构建。H5 替换服务器静态包；微信小程序需要你上传新版开发／体验包，新草稿性能和错误提示不能靠只更新后端立即作用于旧小程序。此次不自动上传、提审或发布。
