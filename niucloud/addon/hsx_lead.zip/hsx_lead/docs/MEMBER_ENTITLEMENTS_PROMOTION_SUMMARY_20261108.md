# 门店权益统一与推广人汇总更新（2026-11-08）

## 已完成的业务入口

1. **会员管理 → 会员列表／详情**：保留个人等级，另显示“门店会员权益”、门店名称、负责人／店员、生效状态及有效期。与“主体与成员”共用真实付款／退款账本计算出的权益，不复制改写 `member.member_level`。
2. **主体与成员**：退款核对中显示“待核对”，已过期显示“已到期”，退出协作不再表现为正常可用。展示字段不改变原有支付、授权及退款规则；分页参数也已对齐组件的真实接口。
3. **推广管理 → 推广人汇总**：普通会员、服务商均按人显示直属邀请人数、其中本人有效付费人数，以及待结算、已结算、暂缓／待核对、取消／已退回金额。
4. 点人数进入对应邀请名单；点“查看台账”进入该推广人的分佣台账，可再按收益来源、状态和产生时间筛选。精确人员条件可一键清除。

## 统计口径

- 邀请人数是当前 `member.pid` 直属关系，不是店员名额。店员加入门店不产生新的推广关系。
- 有效付费人数仅计受邀账号本人实际付款且仍有有效服务费的会员订单；共享门店权益不等于本人付费。多笔购买按人去重，待核对单单独提示。
- 收益按奖励原记录的 `provider_member_id` 累计。邀请人后来变化，不迁移历史分佣。
- “已结算”是奖励台账的结算状态，不等于已提现或银行卡到账。提现仍使用牛云现有账户／提现功能，不另建钱包。
- 退回的奖励保留在取消／已退回分桶，不算有效奖励。不会自动恢复、改价、补分佣或修复历史资金。
- 汇总默认累计；不要把本页金额相加冒充全站合计。按时间查某人的钱，请进入其台账。
- 原个人等级筛选仍筛个人等级；按门店会员等级筛选，使用“主体与成员”。

## 必须替换的框架文件（6 个）

这些不是插件文件，单独覆盖 `addon/hsx_lead` 不够。框架中只提供通用可选展示事件与渲染组件，不写插件名称或业务路由：

| 路径（项目根目录起） | 用途 |
| --- | --- |
| `niucloud/app/service/admin/member/MemberService.php` | 会员列表／详情批量接入只读扩展 |
| `niucloud/app/service/core/member/CoreMemberEntitlementDisplayService.php` | 通用 `MemberAdminEntitlementDisplay` 事件汇聚与安全字段投影 |
| `admin/src/app/views/member/member.vue` | 列表显示扩展权益，区分个人等级 |
| `admin/src/app/views/member/components/detail-member.vue` | 详情复用展示；切换账号不残留上人的数据 |
| `admin/src/app/views/member/components/member-entitlements.vue` | 紧凑、通用的权益展示组件 |
| `admin/src/app/utils/member-entitlements.ts` | 通用展示规范化和有效期／状态处理 |

## 插件关键更新文件

包内 `niucloud/addon/hsx_lead` 对应服务器后端目录下的 `addon/hsx_lead`。建议先备份，再覆盖包中的同名路径；不要在后端目录里再多套一层 `niucloud`。

- `app/event.php`
- `app/listener/member/MemberAdminEntitlementDisplay.php`
- `app/service/cooperation/MemberEntitlementDisplayService.php`
- `app/service/cooperation/EntityMembershipService.php`
- `app/service/cooperation/InviterSummaryReadService.php`
- `app/service/cooperation/PromotionRelationsReadService.php`
- `app/adminapi/controller/Promotion.php`
- `admin/api/promotion.ts`
- `admin/composables/entity.ts`
- `admin/views/cooperation/Entities.vue`
- `admin/views/promotion/PromotionInviters.vue`
- `admin/views/promotion/PromotionRelations.vue`
- `admin/views/promotion/index.vue`

推广汇总复用原 `GET promotion/relations?view=inviters`，沿用邀请关系和全站数据查看权限，没有新增隐藏路由或绕开权限。台账入口另核对原奖励读取权限。

## 更新命令

在服务器**后端目录（包含 `think` 文件）**执行：

```sh
php -l app/service/admin/member/MemberService.php
php -l app/service/core/member/CoreMemberEntitlementDisplayService.php
php addon/hsx_lead/scripts/upgrade.php --check
php addon/hsx_lead/scripts/upgrade.php --apply
php think clear
```

检查不通过先按列出的缺项处理，不要卸载重装。此次没有新增表、字段或迁移 SQL，也不批量改历史会员等级。升级命令同步插件前端及注册资料，不会自动替换上面列出的 6 个框架文件，也不会替代管理端编译。

然后在同级的管理端目录执行：

```sh
cd ../admin
npm run build
```

使用服务器原有的受保护构建／发布流程；不要同时启动多份打包。若站点启用了不自动更新的 OPcache 或常驻 HTTP 服务，按原部署方式平滑重载站点 PHP。不要为这次展示更新重复启动队列。

这两项后台功能不要求重发小程序。如果上一轮推广扫码登录入口尚未发布，仍需按该轮说明单独打包发布用户端。

## 本轮回归结果

| 范围 | 结果 |
| --- | --- |
| 插件纯逻辑 | 25／25 套通过 |
| 插件隔离数据库回归 | 76／76 套通过 |
| 插件前端交互回归 | 98／98 套通过 |
| 官方会员列表／详情通用组件 | 9／9 组通过 |
| 管理端完整生产编译 | 通过；输出至临时目录，未发布线上 |

重点专项：官方会员接口＋真实插件事件 26 项；门店权益映射／权限／异常降级 38 项；支付、续费、到期、全额与部分退款、退款核对中、店员加入与退出等生命周期 97 项；推广人汇总 24 项；推广汇总前端 37 项。专项检查已包含在上述套件中，不重复累加成总数。

所有数据库测试使用随机自建本地库、合成官方收据，禁用外部网络并清理测试库；未真实付款／退款、未发送通知、未更改线上会员或财务数据。自动测试与编译通过，不代表线上部署、真实微信支付或手机真机验收已经完成。

全量回归还修正了上一轮邀请入口新增后两处过时的公开页测试清单，补齐了 ProfilePanel 自有样式和推广申请测试的真实编号工具依赖；受保护页面权限没有放宽。

## 建议下一阶段优先打磨（本轮未擅自扩展）

1. **推广转化分析**：邀请→完善门店→本人付费的转化漏斗，按推广人、地区、周期对照。缺失的历史邀请时间需明确标为未知，不能拿注册时间冒充。
2. **会员运营分组**：有效会员、即将到期、已到期、退款待核对等可操作名单，点图表可进入同口径明细。
3. **收入结构与异常待办**：服务费收入、押金负债、经验费分开；待结算、退款及追偿待核对单独列待办。所有图表必须能追溯到对应订单或台账，而不是只展示漂亮数字。
