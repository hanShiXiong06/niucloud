# 通知运行表：显式结构升级

本次新增三张结构化运行表：通知任务、单次投递尝试、用户渠道偏好。通知规则与模板仍复用牛云配置。不会将历史支付、余额流水重新补成通知，也不重放历史消息。

已安装环境先完整备份数据库，上传完整插件，在包含 `think` 的 PHP 根目录执行：

```sh
php addon/hsx_lead/scripts/upgrade-notice-runtime.php --check
php addon/hsx_lead/scripts/upgrade-notice-runtime.php --apply
php addon/hsx_lead/scripts/upgrade-menu-groups.php --check
php addon/hsx_lead/scripts/upgrade-menu-groups.php --apply
php addon/hsx_lead/scripts/upgrade.php --check
php addon/hsx_lead/scripts/upgrade.php --apply
```

`--check` 仅读取已安装标志及结构元数据，不创建文件、缓存、锁、表或业务记录。`--apply` 只为这三张表执行缺失的 `CREATE TABLE`。现有同名表的字段、主键、唯一键或必要索引不符合规范时，整次预检拒绝，不擅自补字段、补索引或替换表。一般升级不会隐式建表。

命令以当前数据库名和表前缀确定 advisory lock，防止同一部署并发升级。DDL 前结构元数据保存在 PHP 根目录下 `runtime/hsx_lead_upgrade/notice-runtime-*`，目录0700、文件0600；不导出账号凭据、客户内容、支付订单、资金流水或自增计数。重复执行不会重复建表或生成历史消息。

MySQL DDL 逐表提交，不支持整批事务回滚；命令会拒绝已有外层事务。中途断线或失败，不能假定三表都没创建，应先重新执行 `--check`，只补仍缺失的表，不卸载重装、不删现有消息。

普通升级导入的 `hsx_lead_financial_notice_recover`（商户业务通知补偿：资金与新接单计划）默认关闭。管理员须在牛云计划任务中主动开启，并确认原有调度进程与队列运行。完成结构升级、注册任务不等于渠道已开通；还需按通知中心显示的渠道、模板与用户授权状态核验一笔真实新业务。没有订阅额度或用户拒绝的情况不能靠自动重试制造授权。

新安装已包含全部14张插件表，不需要重复运行建表命令。独立测试 `tests/notice-runtime-upgrade.php --isolated-local-mysql` 仅在随机独占本机数据库验证缺表创建、事务/并发拒绝、幂等唯一约束、异常表拒绝与原资金流水不变。
