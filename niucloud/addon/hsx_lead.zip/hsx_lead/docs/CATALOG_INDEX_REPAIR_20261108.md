# 目录分片索引核对与修复

## 已确认的线上问题

商户列表提示“后台目录存储索引异常”时，不表示商户或目录已经丢失。
2026-11-08 只读核查确认，站点 **100006** 的 `HSX_LEAD_DEMAND_CATALOG`：

- 原始目录 845 条，JSON 142919 字节，分为 6 段保存。
- 分片结构、每段长度、完整 JSON 和原始 SHA256 全部通过。
- 根配置缺少新版读取所需的 `row_ids` 主键索引，因此被严格读取校验拒绝。

这不是 MySQL 的表索引故障，**不需要 ALTER TABLE、清空目录、卸载重装或重新导入**。
修复仅向原 manifest 增加经核实的分片主键列表，不重新计算或替换原内容校验和。

## 操作

将 `scripts/repair-catalog-index.php` 和 `scripts/check-catalog-storage.php` 放到服务器的同名插件目录。
在项目后端目录（含 `think`、`addon`、`vendor` 的目录）运行：

```sh
php addon/hsx_lead/scripts/repair-catalog-index.php --site=100006 --key=HSX_LEAD_DEMAND_CATALOG --check
```

只有返回 `repairable`，且目标站点和配置键正确，才执行：

```sh
php addon/hsx_lead/scripts/repair-catalog-index.php --site=100006 --key=HSX_LEAD_DEMAND_CATALOG --apply
php addon/hsx_lead/scripts/check-catalog-storage.php --site=100006
```

`--apply` 会先锁定本站和目标记录，复核当前分片，再生成私有备份，最后补索引并调用现有读取服务回读。
备份位置随结果返回，位于后端 `runtime/hsx_lead_catalog_index_repair` 下。请保留备份，不要放入公开下载目录。
重复执行时，完整索引返回 `no_repair_needed`，不会再次重写。

若分片缺失、重复、归属站点不符、原始校验和不匹配，或者已有索引但格式异常，脚本会拒绝修复；不要改哈希、填默认数据或清空配置来跳过检查。

最后刷新“合作商户”页面，确认列表恢复。此次操作不需要重新打包前端，不改框架和表结构，也不改商户、历史线索、会员、支付或财务记录。

## 本轮执行结果

- 经用户授权，已在线上执行，状态为 `repaired`，`database_writes=1`、`strict_read=passed`。
- 修复前后目录均为 142919 字节，原始 SHA256 不变，845 条目录完整保留。
- 原始根配置及 6 个分片已备份到 `runtime/hsx_lead_catalog_index_repair/site-100006-20261108-025748-0a4f3e5586e4/before.json`。
- 本站 112 份配置的只读服务核查全部通过，`failed_reads=[]`。
- 刷新线上商户列表，报错消失，本轮验收时显示 112 条商户。

## 同批标签布局修复

`admin/views/cooperation/MembershipSummary.vue` 复用牛云原生小号状态标签，供 `Partners.vue` 与 `Entities.vue` 共用。名称与标签同排、宽度随内容、有效期独立次行，未开通不再重复显示。插件源与 `admin/src/addon/hsx_lead` 已同步。

**该前端变更尚未发布线上**。增量包从项目根目录（同时含 `admin` 与 `niucloud` 的目录）覆盖，然后按项目现有流程重新构建、发布管理端即可；不是插件安装包，不要卸载重装。索引修复已经完成，无需重复执行 `--apply`。

验收：PHP 8.0.30；索引修复 36 项、只读诊断 33 项、原目录读写 186 项、并发锁范围 16 项；标签 SFC/样式编译及合成渲染 30 项、主体管理回归 177 项。前端检查不是线上新标签的视觉验收。
