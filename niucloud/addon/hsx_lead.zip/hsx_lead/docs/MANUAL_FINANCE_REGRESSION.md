# 支付帮助、人工收退款与会员重购回归

> 此报告保留上一轮直接offlinepay实现的验证记录。新收款已调整为余额充值并消费，关闭单不再重新报价或重建，金额不符禁止处理；当前验收及更新说明请看 `MANUAL_BALANCE_PAYMENT.md`，不能把下面的历史流程当成新版操作规则。

## 结果与边界

本地隔离回归覆盖手机号查单、支付帮助、管理员实际收款、原支付核对、退款/退押金、权益与分佣，以及退款后再次购买。没有部署线上，没有执行真实银行/微信转账、真实支付或消息发送。编译通过不能代替生产和微信真机验收。

会员可以在全额退款确认完成后重新选择等级、周期并开通；不需要删除旧订单或手工改个人会员等级。退款审批通过但实际结果尚未确认时，仍阻止新购买，防止新旧收费和权益交叉。退款失败保留原权益，按原退款处理流程恢复。

## 自动化记录

| 检查 | 结果 | 范围 |
| --- | --- | --- |
| PHP纯逻辑 | 28套通过 | 合成数据和传输，禁外网 |
| 数据库全回归 | 93套有通过证据 | 整轮92通过；1套本机PDO临时连接错误，未报业务断言失败；单独重跑189项通过，原日志保留 |
| 人工收款增量专项 | 106项通过 | 最终增加缺表提示后重跑；含真实双PHP进程/MySQL并发 |
| 人工退款与会员再购专项 | 56项通过 | 原线下/线上全退、低/高等级再购、失败补偿、离线凭据防伪与安全投影 |
| 实际控制器合同 | 25项通过 | 实际GET/POST控制器、独立请求身份、跨站拒绝、幂等、no-store、完整退款再报价 |
| 显式结构升级 | 23项通过 | 仅自建库创建一表，防重索引、重复执行、不兼容结构拒绝、财务数据不变 |
| 支付帮助服务 | 135项通过 | 图片归属/私有附件隔离、读写权限、关闭脱敏、失败回滚及恢复 |
| UI回归 | 110套通过 | 真实Vue状态/SFC/SCSS与合成接口；最终构建前完整复跑 |
| 小程序产物 | 650项通过 | 实际mp-weixin代码、组件依赖、独立样式、微信wcsc语法；不是手机真机视觉验证 |
| 打包合同 | 39项通过 | 实际源码白名单检查，无压缩包、凭据、测试数据或编译产物混入运行包 |

专项已包含在相应套件中，不把它们重复相加为总测试数。本机连接错误单独记录，不把重跑说成一次干净通过。

实际浏览器还覆盖8组用户端H5场景及8组管理端ElementPlus场景，均使用离线合成接口。支付帮助验证350/390窄屏、600字长文真实滚动、关闭按钮固定、二维码错误重试；收款表单验证空字段、错误态修复、确认取消、结果不明原请求恢复、只读角色及实际退款金额只读。

## 关键业务场景

| 场景 | 预期与核对结果 |
| --- | --- |
| 原价人工收款 | 正式offlinepay流水、权益开通和分佣，不制造余额充值/扣款 |
| 实收金额与原价不同 | 沿用原改价权限和安全新单链；会员仅调整服务费，押金/经验不被抹掉 |
| 报价过期/订单关闭 | 新标准报价、新关联订单，原单及原报价时间保留 |
| 客户已自行重建相同套餐订单 | 安全复用有效新单，不多建第三张单 |
| 两管理员重复或并发确认 | 原订单、请求、实际流水防重，仅一次成功入账 |
| 原微信已成功/结果未知 | 已成功不双开；未知保存线下实收待核对，不重复收费 |
| 原单晚到成功 | 替换链保留冲突并阻止重复权益/收益 |
| 收款回调中断/部署事件缓存未更新 | 原凭据保留；幂等补偿后才能报告业务入账完成 |
| 确认人权限撤销 | 自动入账暂停，当前有权财务可核对原记录，不冒充管理员 |
| 线下退款审核通过 | 只预留原退款与相应收益，明确待实际转账，不假定钱已退 |
| 财务确认实际退款 | 绑定原退款号/金额和真实凭据，再撤回权益、押金、经验及分佣 |
| 无实际凭据的offline成功回调 | 在会员、订单及推广退款入口拒绝，不能提前撤权益或改收益 |
| 退款完成后重新购买 | 可重新报价/支付，支持不同等级，原个人等级不变 |
| 新购等级仍需经验 | 按新经验缺口核算，可按配置购买经验；不保留已退掉的免费升级资格 |
| 退款失败 | 原权益不误撤，收益预留按原失败恢复，不误显示退款完成 |
| 押金多来源/单独退款 | 每笔关联原付款确认，不伪造余额返还，服务/经验边界保留 |
| 移动端待入账 | 立即禁重复支付，给安全提示，不泄露账户、外部流水或管理员备注 |
| 手机号查询 | 区分原付款会员/线索客户/门店联系人，精确匹配、站点隔离、保留组合筛选 |

## 本轮修复的交互问题

- 二维码素材被删除时后台仍可换图或关闭，不锁死编辑器。
- 旧的重新读取确认框不会覆盖其他站点或重新打开后的新草稿。
- 支付帮助长文采用确定高度链，实际可滚动到二维码与备注；不只依据scrollHeight宣称可用。
- 小程序virtualHost下间距由组件自身控制，不依赖宿主class穿透。
- 管理员从替换后的新订单打开收款记录时，可识别原单/目标单，不误报归属不符。
- 收款方式选择后清除对应必填错误；确认前字段更新会要求重新勾选实际到账。
- 结果不明先按原request_id查询，只有服务器明确没有保存记录时才允许原请求继续，不另造新流水。

界面保留牛云的表单、弹窗、图片上传/预览与权限能力；按转转式清晰层级突出重要提醒和一个主动作，没有引入另一套收银台或钱包。

## 替换文件

除《支付帮助与手机号查单》所列文件外，本次人工收退款涉及以下插件文件。已同时同步安装源码与挂载镜像；建议备份后上传完整配套插件，避免新旧服务、界面和路由混用。

后端新增：

- `app/service/cooperation/ManualPaymentService.php`
- `app/service/cooperation/ManualRefundService.php`
- `sql/manual-receipts.sql`
- `scripts/upgrade-manual-receipts.php`

后端更新：

- `app/service/cooperation/PaymentService.php`
- `app/service/cooperation/PaymentOrderLifecycle.php`
- `app/service/cooperation/PaymentRefundService.php`
- `app/service/cooperation/MembershipDepositService.php`
- `app/service/cooperation/OrderPaymentReadService.php`
- `app/service/cooperation/PromotionService.php`（实际退款凭据校验）
- `app/listener/pay/MembershipRefundSuccess.php`（实际退款凭据校验）
- `app/adminapi/controller/Cooperation.php`
- `app/adminapi/route/cooperation.php`
- `app/dict/menu/site.php`
- `app/dict/schedule/schedule.php`
- `app/job/CloseUnpaidOrders.php`
- `scripts/upgrade.php`
- `install.sql`、`sql/install.sql`

管理端新增/更新：

- `admin/api/manualReceipt.ts`
- `admin/composables/manualReceipt.ts`
- `admin/views/cooperation/ManualEvidenceFields.vue`
- `admin/views/cooperation/ManualReceiptDialog.vue`
- `admin/views/cooperation/ManualRefundDialog.vue`
- `admin/views/cooperation/Orders.vue`
- `admin/views/cooperation/OrderRefundDialog.vue`
- `admin/views/cooperation/DepositRequests.vue`

本轮没有为该功能修改框架文件。已有框架配套改动不在本清单中重新覆盖；同名文件中其他未提交改动需保留。新菜单操作权限不会自动授给普通员工。

## 更新与现场验收

先完整备份，再在PHP项目根目录执行：

```bash
php addon/hsx_lead/scripts/upgrade-manual-receipts.php --check
php addon/hsx_lead/scripts/upgrade-manual-receipts.php --apply
php addon/hsx_lead/scripts/upgrade.php --check
php addon/hsx_lead/scripts/upgrade.php --apply
```

这是新增一表的明确结构升级；普通升级不偷偷执行DDL。随后重建管理端，用户端支付帮助需发布新的H5/小程序；按既有进程管理方式重载队列/计划任务，不重复启动消费者。

生产仍需核对：财务角色授权、客服二维码/文案、真实收退款账户与流水、实际微信支付/退款回执、小程序真机返回与滚动、计划任务日志。异常不足额或重复转账只保留待核对，不自动补扣或自动打款；不能把管理员输入当成银行已经发生的事实。
