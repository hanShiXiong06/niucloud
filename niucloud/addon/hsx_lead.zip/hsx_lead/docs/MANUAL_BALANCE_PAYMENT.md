# 简化收款与余额支付

## 最新规则

后台「支付订单」按手机号找到原付款会员及订单，管理员确认已经实际收到线下微信扫码款，再执行：

1. 给该订单原付款会员的牛云 `balance` 充值。
2. 使用牛云余额支付，消费完全相同的金额，开通原订单权益或完成付佣。

两步使用同一事务：成功时各有一条真实账户流水，余额净变化为0；任一步失败，充值、消费及本次权益/分佣入账一起回滚。失败的实际收款登记保留待核对，不能要求客户再转一次。

管理员只需输入金额，初值固定99元。收款方式固定为线下微信扫码，不再要求填写方式、账户、外部流水、时间、备注。操作人、时间、系统登记号自动记录；系统登记号不是微信交易流水。最终仍需明确确认款项已经收到，软件不会代收微信款。

手机号只用于查单，最终资金归属以原订单的站点与唯一会员ID确定，不能用一个手机号随意找到其他账号充值。

## 不可越过的限制

- 金额必须与原订单应付金额完全一致。应付199元而填99元，直接拒绝，不充值、不扣款、不记成功收款、不修改价格。
- 已关闭订单禁止操作，不重开、不复制、不创建替代订单。
- 已超过支付有效期或当前权益条件不允许支付的订单，不自动延长报价或重新报价。
- 已支付订单不重复充值或消费。原微信支付结果不明时先核对原单，不盲目二付。
- 重复点击、网络中断和补偿沿用同一收款请求/记录，不能重复加余额。
- 普通余额支付仍沿用原收银台和站点支付配置；本功能不为客户端开放自行确认收款的权限，也不自动启用任何全站支付渠道。

管理员确认入口沿用原财务、全站业务范围和专用操作权限。新确认只支持简化后的四个字段：`amount`、`request_id`、`expected_fingerprint`、`confirm`，不接受客户端自行指定会员、站点、到账时间或收款方式。

## 退款与再次购买

新订单的正式支付类型是 `balancepay`，不是微信线上支付，也不是直接offlinepay。

退款沿用牛云余额原路退款：退回原付款会员余额，不会自动退回微信。成功后撤回对应权益、押金/经验和分佣影响；用户可以直接使用退回的余额重新选择会员并支付，不再让管理员额外充值一遍。

退款回调中断时按原退款号和真实账户日志恢复，不再多退一次。退款仍在处理中时不重复开通。会员重新购买仍按当前经验、价格、押金和可用周期核算，原个人会员等级不变。

此前已经真实入账的直接offlinepay记录保持可查看和原退款处理，不转换成余额充值、不删除原凭据。它们的实际线下退款说明仍见旧文档；不得拿旧线下退款按钮再给新balancepay订单转出第二笔钱。

## 更新

这次不新增表或字段，不改框架文件，继续使用已经建好的 `hsx_lead_manual_receipt` 表。此前建表、通知表、菜单目录升级已成功的无需重建。

上传配套插件后，从PHP项目根目录执行：

```bash
php addon/hsx_lead/scripts/upgrade.php --check
php addon/hsx_lead/scripts/upgrade.php --apply
```

然后重建并发布管理端，并按现有进程管理方式重载相关长期运行进程，不重复启动消费者。本次简化收款没有修改用户端源码，不需要仅为这一项重新上传小程序。

主要替换文件（相对于 `niucloud/addon/hsx_lead/`，建议备份后上传配套插件，勿混用新旧表单与服务）：

- `app/service/cooperation/ManualPaymentService.php`
- `app/dict/member/account_change_type.php`
- `app/service/cooperation/PaymentService.php`
- `app/service/cooperation/OrderPaymentReadService.php`
- `app/service/cooperation/PaymentRefundService.php`
- `app/service/cooperation/MembershipDepositService.php`
- `app/service/cooperation/PromotionService.php`
- `app/listener/pay/MembershipRefundSuccess.php`
- `admin/api/manualReceipt.ts`
- `admin/composables/manualReceipt.ts`
- `admin/views/cooperation/ManualReceiptDialog.vue`
- `admin/views/cooperation/Orders.vue`

安装源和 `admin/src/addon/hsx_lead/` 挂载副本需同步，不能只改一份。旧退款凭据/界面继续保留，不执行历史数据回填或转换。

## 回归要求与现场边界

必须覆盖99元及其他精确金额、存量余额、充值后扣款失败的整体回滚、并发/重复请求、错误会员/站点、支付已成功、关闭与超时、原回调中断、退款只回余额一次、退回余额直接重购、普通余额支付不受新增凭据校验影响，以及旧已入账offlinepay仍可退款。

本地测试使用随机隔离库和合成渠道响应。编译和本地测试不是线上实际到账确认；管理员应在真实收到钱后才点击，系统无法单凭按钮验证微信转账事实。

## 2026-11-10 本地回归结果

- 纯逻辑测试：28组全部通过。
- 数据库测试：94组中93组首次通过；`member-entitlement-projection.php` 在0条断言时遇到本机PDO端口资源错误，单独复跑38条断言全部通过。未忽略或放宽业务断言，未接触线上数据库。
- Vue组件测试：111组全部通过。
- 本次核心专项：真实余额充值与扣款123条、退款与余额重购40条、真实控制器29条、旧线下退款56条，均通过。
- 简化表单61条专项通过；真实Vue及ElementPlus离线浏览器9组场景通过，页面异常0、外部请求0。核验了默认99、应付199时禁止提交、取消不写入、切换站点后旧确认无效、关闭订单只读和未知结果恢复。
- 管理端Vite隔离输出构建退出码0。未执行线上发布，未覆盖运行中的管理端目录；仍有项目既有的深度选择器弃用及大分块提示。
- 源码包39条契约检查及`package.mjs --check`通过。本次没有新增数据库结构或修改框架文件，用户端源码没有因简化收款发生变更。

表单截图和浏览器报告位于项目 `output/hsx-lead-manual-receipt-compact-20261110/`。完整回归日志位于本机 `/private/tmp/hsx-lead-balance-{pure,database,ui}-final.log`，数据库单项复跑记录为 `/private/tmp/hsx-lead-balance-projection-retry.log`。
