import request from '@/utils/request'
import type { Row } from '../composables/useLeadUi'

const root = 'hsx_lead'
const quiet = { showErrorMessage: false }
export const getCatalog = (params: Row = {}) => request.get(`${root}/catalog`, { ...quiet, params })
export const saveCatalog = (data: { content: string, format: 'csv' | 'json' | 'xlsx', business_type?: string, preview?: boolean }) => request.put(`${root}/catalog`, data, quiet)
export const getMembers = (keyword = '') => request.get(`${root}/members`, { ...quiet, params: { keyword } })
export const getMerchants = (params: Row) => request.get(`${root}/merchants`, { ...quiet, params })
export const getMerchant = (id: number) => request.get(`${root}/merchants/${id}`, quiet)
export const saveMerchant = (data: Row) => data.id ? request.put(`${root}/merchants/${data.id}`, data, quiet) : request.post(`${root}/merchants`, data, quiet)
export const getProviders = () => request.get(`${root}/providers`, quiet)
export const getConnection = (id: number) => request.get(`${root}/merchants/${id}/connection`, quiet)
export const getAuthorizationChallenge = (id: number, data: Row) => request.post(`${root}/merchants/${id}/connection/auth/challenge`, data, quiet)
export const getCaptchaConfig = () => request.get(`${root}/captcha/config`, quiet)
export const saveCaptchaConfig = (data: Row) => request.put(`${root}/captcha/config`, data, quiet)
export const checkCaptchaBalance = () => request.post(`${root}/captcha/balance`, {}, { ...quiet, timeout: 45000 })
export const startAutomaticAuthorization = (id: number, data: Row) => request.post(`${root}/merchants/${id}/connection/auth/automatic`, data, quiet)
export const advanceAutomaticAuthorization = (id: number, data: Row) => request.post(`${root}/merchants/${id}/connection/auth/automatic/advance`, data, { ...quiet, timeout: 45000 })
export const cancelAutomaticAuthorization = (id: number, data: Row) => request.post(`${root}/merchants/${id}/connection/auth/automatic/cancel`, data, quiet)
export const probeConnection = (id: number, data: Row) => request.post(`${root}/merchants/${id}/connection/probe`, data, quiet)
export const activateConnection = (id: number, data: Row) => request.post(`${root}/merchants/${id}/connection/activate`, data, quiet)
export const saveSyncSettings = (id: number, data: Row) => request.put(`${root}/merchants/${id}/connection/settings`, data, quiet)
export const syncMerchant = (id: number) => request.post(`${root}/merchants/${id}/sync`, {}, quiet)
export const getSync = (id: number) => request.get(`${root}/sync/${id}`, quiet)
export const advanceSync = (id: number) => request.post(`${root}/sync/${id}/advance`, {}, quiet)
export const getInventory = (params: Row) => request.get(`${root}/inventory`, { ...quiet, params })
export const getNoticeConfig = () => request.get(`${root}/notice/config`, quiet)
export const saveNoticeConfig = (data: Row) => request.put(`${root}/notice/config`, data, quiet)
