<?php
declare(strict_types=1);
namespace addon\hsx_lead\app\service\cooperation;

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use app\service\core\pay\CorePayService;
use core\exception\CommonException;
use think\facade\Db;

/** Entity-owned rights. Member identity remains the real payer, never member_level. */
final class EntityMembershipService
{
    public const SNAPSHOT_SCHEMA='hsx_lead.entity_membership.v3';
    private const TTL=600;
    public function __construct(private Context $context) {}

    public static function state(int $site,int $merchant,array $config=[],?int $now=null,bool $lock=false): array
    {
        $rows=self::ledger($site,$merchant,$lock);$partner=Store::partner($site,$merchant,$lock);
        // Actual grants are independent of whether the sale catalog is now
        // edited, unavailable or disabled. Catalog checks belong to new sales.
        $state=self::stateFrom($rows,$partner,[],$now??time());
        // A renamed directory label is presentation, not a new entitlement.
        // Keep paid rights, capacity, amount and expiry frozen; never rewrite the receipt.
        foreach($config['membership_levels']??[] as $tier) if (($tier['code']??'')===$state['level_code']) {$state['level_name']=$tier['name'];$state['level_visual']=$tier['level_visual'];$state['level_color']=$tier['level_visual']['accent_color'];break;}
        return $state+['merchant_id'=>$merchant,'configuration_source'=>'framework_member_level'];
    }

    public function summary(): array
    {
        $m=TeamService::resolve($this->context);$site=$this->context->site;$id=(int)$m['id'];$config=(new ConfigService($this->context))->get();
        $state=self::state($site,$id,$config);$manage=(int)$m['member_id']===$this->context->memberId;
        $used=TeamService::usedAccounts($site,$m);
        $experience=EntityExperienceService::summary($site,$id);$tiers=[];
        foreach(EntityExperienceService::decorate($config['membership_levels']??[],$experience) as $tier) {$allowed=$manage&&$tier['experience_eligible'];$tier['cycles']=array_map(static fn(array $cycle):array=>$cycle+['can_purchase'=>$allowed&&!empty($cycle['enabled'])],$tier['cycles']);$tiers[]=$tier;}
        return $state+['used_accounts'=>$used,'can_manage'=>$manage,'is_owner'=>$manage,'tiers'=>$tiers,'experience'=>$experience,'next_level'=>EntityExperienceService::nextLevel($tiers,$state,$experience),'catalog_configured'=>count($tiers)>0,'entry_configured'=>in_array(true,array_column($tiers,'is_entry'),true),'renewable'=>$manage&&$state['level_code']!==''&&in_array($state['level_code'],array_column($tiers,'code'),true),'upgrade_available'=>$manage&&count($tiers)>0];
    }

    public function quote(string $code,string $cycle): array
    {
        $m=TeamService::assertOwner($this->context);$id=(int)$m['id'];$config=(new ConfigService($this->context))->get();$now=time();
        $quote=self::calculate(self::ledger($this->context->site,$id),Store::partner($this->context->site,$id),$config['membership_levels']??[],$code,$cycle,$now,EntityExperienceService::summary($this->context->site,$id));
        $quote['merchant_id']=$id;$quote['existing_order_id']=0;$quote['quote_token']='';
        $pending=Store::query('coop_order',$this->context->site)->where('merchant_id',$id)->where('purpose','membership')->where('status','unpaid')->order('id')->find();
        if ($pending) {
            $rule=Data::decode($pending['rule_json']);$quote['existing_order_id']=(int)$pending['id'];
            if (($rule['level_code']??'')===$code&&($rule['cycle']??'')===$cycle&&(int)$pending['member_id']===$this->context->memberId) {
                $quote=array_replace($quote,array_intersect_key($rule,array_flip(['level_code','level_name','level_id','rank','display_rank','cycle','cycle_name','months','entitlement_months','account_limit','unlimited','capabilities','benefits','period_start_at','period_end_at','full_amount','credit_amount','payable_amount'])),['can_purchase'=>true,'reason'=>'已有本套餐待支付订单，请继续核对原单','expires_at'=>0]);
                if ((int)($rule['quoted_at']??0)+self::TTL<$now) {$quote['can_purchase']=false;$quote['reason']='原会员报价已过期，请先取消未支付订单，再重新读取报价';}
                elseif (!self::catalogMatches($rule,$config['membership_levels']??[])) {$quote['can_purchase']=false;$quote['reason']='原套餐已调整或停售，请先取消未支付订单，再选择新套餐';}
                elseif (!$quote['experience_eligible']) {$quote['can_purchase']=false;$quote['reason']='当前门店经验'.$quote['experience_value'].'，本等级需要'.$quote['experience_required'].'；请先完成真实成交付佣，再核对原订单';}
            } else {$quote['can_purchase']=false;$quote['reason']='该主体已有待支付会员订单，请先处理原订单，不会重复收费';}
            return $quote;
        }
        if (empty($config['enabled'])) {$quote['can_purchase']=false;$quote['reason']='本站尚未启用商户协作';}
        if ((int)Store::partner($this->context->site,$id)['blocked_at']>0) {$quote['can_purchase']=false;$quote['reason']='该主体已停止合作，不能购买新的权益';}
        if ($quote['can_purchase']) $quote['quote_token']=$this->sign(['site'=>$this->context->site,'member'=>$this->context->memberId,'merchant'=>$id,'code'=>$code,'cycle'=>$cycle,'at'=>$now,'fingerprint'=>$quote['base_fingerprint'],'pricing'=>self::pricingFingerprint($config['membership_levels']??[])]);
        return $quote;
    }

    public function createOrder(array $input): array
    {
        $m=TeamService::assertOwner($this->context);$request=Store::requestId($input);$code=Data::text($input,'level_code',16,true);$cycle=Data::text($input,'cycle',24,true);
        $id=Db::transaction(function()use($m,$request,$code,$cycle,$input):int {
            PromotionService::lockSite($this->context->site);TeamService::assertOwner($this->context,(int)$m['id'],true);$partner=Store::partner($this->context->site,(int)$m['id'],true);
            $old=Store::query('coop_order',$this->context->site)->where('merchant_id',$m['id'])->where('request_id',$request)->lock(true)->find();
            if ($old) {$rule=Data::decode($old['rule_json']);if ($old['purpose']!=='membership'||(int)$old['member_id']!==$this->context->memberId||($rule['level_code']??'')!==$code||($rule['cycle']??'')!==$cycle) throw new CommonException('该请求已用于其他付款，请核对原订单');if($old['status']==='unpaid')self::assertOrderPayable($this->context->site,$old);return (int)$old['id'];}
            $pending=Store::query('coop_order',$this->context->site)->where('merchant_id',$m['id'])->where('purpose','membership')->where('status','unpaid')->lock(true)->find();
            if ($pending) {$rule=Data::decode($pending['rule_json']);if (($rule['level_code']??'')!==$code||($rule['cycle']??'')!==$cycle||(int)$pending['member_id']!==$this->context->memberId) throw new CommonException('该主体已有待支付会员订单，请先核对原单');self::assertOrderPayable($this->context->site,$pending);return (int)$pending['id'];}
            $config=(new ConfigService($this->context))->get(true);if (empty($config['enabled'])||(int)$partner['blocked_at']>0) throw new CommonException('该主体当前不能购买会员权益');
            $token=$this->verify(Data::text($input,'quote_token',2048,true));$now=time();
            if (($token['site']??0)!==$this->context->site||($token['member']??0)!==$this->context->memberId||($token['merchant']??0)!==(int)$m['id']||($token['code']??'')!==$code||($token['cycle']??'')!==$cycle||(int)($token['at']??0)>$now||(int)($token['at']??0)<$now-self::TTL||($token['pricing']??'')!==self::pricingFingerprint($config['membership_levels']??[])) throw new CommonException('会员报价已变化或不属于当前负责人，请重新读取报价');
            $quote=self::calculate(self::ledger($this->context->site,(int)$m['id'],true),$partner,$config['membership_levels']??[],$code,$cycle,(int)$token['at'],EntityExperienceService::summary($this->context->site,(int)$m['id'],true));
            if (!$quote['can_purchase']||!hash_equals((string)$token['fingerprint'],$quote['base_fingerprint'])) throw new CommonException($quote['reason']?:'主体权益或原付款已变化，请重新读取报价');
            $rule=$quote+['schema_version'=>self::SNAPSHOT_SCHEMA,'purpose'=>'membership'];unset($rule['can_purchase'],$rule['reason'],$rule['expires_at']);
            $key='membership:'.$m['id'].':'.substr(hash('sha256',$request),0,48);
            $id=(int)Store::query('coop_order',$this->context->site)->insertGetId(['site_id'=>$this->context->site,'order_no'=>Data::number('CO'),'purpose'=>'membership','lead_id'=>0,'merchant_id'=>$m['id'],'member_id'=>$this->context->memberId,'business_key'=>$key,'request_id'=>$request,'amount'=>$quote['payable_amount'],'fee_amount'=>'0.00','net_amount'=>'0.00','rule_json'=>Data::json($rule),'status'=>'unpaid','create_time'=>$now,'update_time'=>$now]);
            $this->context->audit('coop_order',$id,'created',['purpose'=>'membership','level_code'=>$code,'cycle'=>$cycle,'amount'=>$quote['payable_amount']]);return $id;
        });return (new PaymentService($this->context))->order($id);
    }

    /** Pure quote calculation; every credited period has a verified original receipt. */
    public static function calculate(array $rows,array $partner,array $tiers,string $code,string $cycle,int $now,array $experience=['value'=>'0.00']): array
    {
        $tier=null;foreach($tiers as $entry) if ($entry['code']===$code) $tier=$entry;
        if (!$tier||!MembershipCatalogService::validCode($code)) throw new CommonException('请选择会员等级中已启用商户协作权益的套餐');
        $period=null;foreach($tier['cycles'] as $entry) if ($entry['key']===$cycle) $period=$entry;
        if (!$period) throw new CommonException('请选择该会员套餐提供的购买周期');
        $months=(int)$period['months'];$state=self::stateFrom($rows,$partner,$tiers,$now);$segments=self::availableSegments($rows);$reservedRank=0;$sameEnd=0;
        foreach($segments as [$reserved,$a,$b]) if ($b>$now) {$reservedRank=max($reservedRank,(int)$reserved['rule']['rank']);if ($reserved['rule']['level_code']===$code) $sameEnd=max($sameEnd,$b);}
        $start=$sameEnd>0?max($now,$sameEnd):($state['active']&&$state['level_code']===$code?max($now,$state['expires_at']):$now);
        $full=Rules::cents($period['price']);$end=Rules::addMonths($start,$months);
        $required=(string)$tier['experience_required'];$value=(string)$experience['value'];$eligible=EntityExperienceService::eligible($experience,$tier);
        $out=['purpose'=>'membership','level_code'=>$code,'level_id'=>(int)$tier['level_id'],'level_name'=>$tier['name'],'level_color'=>$tier['level_color'],'rank'=>(int)$tier['rank'],'display_rank'=>(int)$tier['display_rank'],'capabilities'=>$tier['capabilities'],'benefits'=>$tier['benefits'],'cycle'=>$cycle,'cycle_name'=>$period['name'],'entitlement_months'=>$months,'months'=>$months,'account_limit'=>(int)$tier['account_limit'],'unlimited'=>(bool)$tier['unlimited'],'is_entry'=>(bool)$tier['is_entry'],'experience_required'=>$required,'experience_value'=>$value,'experience_eligible'=>$eligible,'experience_remaining'=>Rules::amount(max(0,Rules::cents($required)-Rules::cents($value))),'period_start_at'=>$start,'period_end_at'=>$end,'quoted_at'=>$now,'expires_at'=>$now+self::TTL,'full_amount'=>Rules::amount($full),'credit_amount'=>'0.00','payable_amount'=>Rules::amount($full),'credit_sources'=>[],'can_purchase'=>true,'reason'=>'','base_fingerprint'=>self::fingerprint($rows,$partner),'catalog_fingerprint'=>self::tierFingerprint($tier)];
        if (empty($tier['enabled'])||empty($period['enabled'])||$full<=0) {$out['can_purchase']=false;$out['reason']='该等级尚未开通当前付费周期，请重新选择';return $out;}
        if (!$eligible) {$out['can_purchase']=false;$out['reason']='当前门店经验'.$value.'，本等级需要'.$required.'；开通、升级和续费均需满足经验条件';return $out;}
        if (($state['active']&&(int)$tier['rank']<$state['rank'])||$reservedRank>(int)$tier['rank']) {$out['can_purchase']=false;$out['reason']='已有有效或预付的更高等级期间，不能用低等级订单覆盖；到期后再选择';return $out;}
        foreach($rows as $row) if (!empty($row['refund_pending'])||!empty($row['review'])) {$out['can_purchase']=false;$out['reason']='该主体存在退款或权益待核对记录，请先由平台处理，不会重复收费';return $out;}
        $credit=0;
        if (($state['active']&&(int)$tier['rank']>$state['rank'])||($reservedRank>0&&(int)$tier['rank']>$reservedRank)) {
            if (!$rows) {$out['can_purchase']=false;$out['reason']='原等级没有可核实的付款及期限记录，不能估算补差，请平台核对';return $out;}
            foreach($segments as $segment) {
                [$row,$a,$b]=$segment;$a=max($a,$now);if ($b<=$a) continue;
                $value=self::prorate(Rules::cents($row['rule']['full_amount']),$b-$a,(int)$row['rule']['period_end_at']-(int)$row['rule']['period_start_at']);
                if ($value<=0) continue;
                $out['credit_sources'][]=['order_id'=>(int)$row['id'],'start_at'=>$a,'end_at'=>$b,'amount'=>Rules::amount($value),'source_fingerprint'=>self::sourceFingerprint($row)];$credit+=$value;
            }
            if ($credit>=$full) {$out['can_purchase']=false;$out['reason']='原权益剩余价值不低于所选套餐价格，请选择更长周期或联系平台核对；不会丢弃差额';return $out;}
        }
        $out['credit_amount']=Rules::amount($credit);$out['payable_amount']=Rules::amount($full-$credit);return $out;
    }

    public static function assertSnapshot(array $order,array $rule): void
    {
        if (($rule['schema_version']??'')!==self::SNAPSHOT_SCHEMA||($rule['purpose']??'')!=='membership'||!MembershipCatalogService::validCode($rule['level_code']??null)||!is_string($rule['cycle']??null)||!preg_match('/^[A-Za-z][A-Za-z0-9_-]{0,23}$/D',$rule['cycle'])||!is_array($rule['credit_sources']??null)) throw new CommonException('主体会员订单快照不完整，请联系平台核对');
        if (!is_int($rule['level_id']??null)||$rule['level_code']!=='ML'.$rule['level_id']||!is_int($rule['rank']??null)||$rule['rank']<1||$rule['rank']>2147483647||!is_int($rule['display_rank']??null)||$rule['display_rank']<1||!is_string($rule['level_name']??null)||trim($rule['level_name'])===''||!is_string($rule['cycle_name']??null)||trim($rule['cycle_name'])===''||!is_bool($rule['unlimited']??null)||!is_int($rule['account_limit']??null)||$rule['account_limit']<1||$rule['account_limit']>99999||!is_int($rule['quoted_at']??null)||$rule['quoted_at']<=0) throw new CommonException('会员等级或账号权益快照无效，请平台核对');
        if (!is_array($rule['capabilities']??null)||!is_array($rule['benefits']??null)||!is_string($rule['catalog_fingerprint']??null)||!preg_match('/^[a-f0-9]{64}$/D',$rule['catalog_fingerprint'])) throw new CommonException('会员原单权益快照不完整');
        $required=Rules::cents($rule['experience_required']??'');
        if(!is_bool($rule['is_entry']??null)||$required!==($rule['is_entry']?0:$rule['rank']*100))throw new CommonException('会员入门档及经验门槛快照不一致');
        if(!is_string($rule['level_color']??null)||($rule['level_color']!==''&&!preg_match('/^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/iD',$rule['level_color'])))throw new CommonException('会员等级配色快照格式异常');
        foreach(MembershipCatalogService::CAPABILITIES as $key) if (!is_bool($rule['capabilities'][$key]??null)) throw new CommonException('会员原单权限快照不完整');
        // Keep original paid copy frozen too: a later UI title/icon change must
        // not revoke grants. Validate shape, trusted icon set and permissions.
        if (!\addon\hsx_lead\app\support\PhpRuntime::isList($rule['benefits'])||count($rule['benefits'])!==count(MembershipCatalogService::CAPABILITIES)) throw new CommonException('会员原单权益展示不完整');
        $seen=[];foreach($rule['benefits'] as $benefit) {
            $key=is_array($benefit)?($benefit['key']??null):null;
            if (!is_string($key)||!in_array($key,MembershipCatalogService::CAPABILITIES,true)||isset($seen[$key])||!is_string($benefit['title']??null)||trim($benefit['title'])===''||mb_strlen($benefit['title'])>80||!is_string($benefit['desc']??null)||mb_strlen($benefit['desc'])>200||!in_array($benefit['icon']??null,MembershipCatalogService::BENEFIT_ICONS,true)||($benefit['enabled']??null)!==$rule['capabilities'][$key]) throw new CommonException('会员原单权益展示与权限不一致');
            $seen[$key]=true;
        }
        $months=$rule['months']??0;if (!is_int($months)||$months<1||$months>120) throw new CommonException('会员原单购买月份无效');$start=(int)($rule['period_start_at']??0);$end=(int)($rule['period_end_at']??0);
        if (($rule['entitlement_months']??0)!==$months||$start<=0||$end!==Rules::addMonths($start,$months)||$end>4294967295) throw new CommonException('会员原单期限不一致，未开通权益');
        $full=Rules::cents($rule['full_amount']??'');$credit=Rules::cents($rule['credit_amount']??'');$cash=Rules::cents($rule['payable_amount']??'');
        if ($cash<=0||$cash>9999999999||$full-$credit!==$cash||$cash!==Rules::cents((string)$order['amount'])) throw new CommonException('会员原价、抵扣和真实付款金额不一致');
        $sum=0;foreach($rule['credit_sources'] as $source) {if (!is_array($source)||(int)($source['order_id']??0)<=0||(int)($source['end_at']??0)<=(int)($source['start_at']??0)||!is_string($source['source_fingerprint']??null)||!preg_match('/^[a-f0-9]{64}$/D',$source['source_fingerprint'])) throw new CommonException('会员抵扣来源不完整');$sum+=Rules::cents($source['amount']??'');}if ($sum!==$credit) throw new CommonException('会员抵扣合计不一致');
    }

    public static function assertOrderPayable(int $site,array $order): void
    {
        $ctx=new Context($site,0,(int)$order['member_id']);TeamService::assertOwner($ctx,(int)$order['merchant_id'],true);
        $rule=Data::decode($order['rule_json']);self::assertSnapshot($order,$rule);
        if (!self::catalogMatches($rule,MembershipCatalogService::levels($site,true))) throw new CommonException('原会员套餐已调整或停售，请先取消未支付单后重新选择；当前未发起支付');
        if ((int)($rule['quoted_at']??0)+self::TTL<time()) throw new CommonException('原会员报价已过期，请先取消未支付订单，再重新报价；当前未扣款');
        $rows=self::ledger($site,(int)$order['merchant_id'],true);$partner=Store::partner($site,(int)$order['merchant_id'],true);
        if (!hash_equals((string)($rule['base_fingerprint']??''),self::fingerprint($rows,$partner))) throw new CommonException('主体权益或原付款状态已变化，请平台核对原订单，不会重新扣款');
        foreach($rows as $row) if (!empty($row['refund_pending'])||!empty($row['review'])) throw new CommonException('原权益正在退款或核对，暂不能继续付款');
        self::assertExperience($site,(int)$order['merchant_id'],(string)$rule['experience_required']);
    }

    /** Called after framework receipt verification under site, order and partner locks. */
    public static function grant(int $site,array $order,array &$rule,int $paidAt): array
    {
        self::assertSnapshot($order,$rule);$partner=Store::partner($site,(int)$order['merchant_id'],true);
        $rows=self::ledger($site,(int)$order['merchant_id'],true);
        if (!hash_equals((string)($rule['base_fingerprint']??''),self::fingerprint($rows,$partner))) throw new CommonException('原权益状态已变化，已收款须人工核对，不能覆盖新权益');
        foreach($rows as $row) if (!empty($row['refund_pending'])||!empty($row['review'])) throw new CommonException('原权益正在退款或核对，暂未授予新等级');
        self::assertExperience($site,(int)$order['merchant_id'],(string)$rule['experience_required']);
        if ($paidAt<=0||$paidAt>time()+60||$paidAt<(int)$rule['quoted_at']||$paidAt>(int)$rule['quoted_at']+self::TTL) throw new CommonException('原会员付款时间超过报价有效期，请平台核对已收款');
        self::assertSources($rows,$rule);
        // Opening and upgrading start at the verified framework receipt time, not quotation/callback time.
        if ((int)$rule['period_start_at']<=(int)$rule['quoted_at']) {
            $rule['quoted_period_start_at']=$rule['period_start_at'];$rule['quoted_period_end_at']=$rule['period_end_at'];
            $rule['period_start_at']=$paidAt;$rule['period_end_at']=Rules::addMonths($paidAt,(int)$rule['months']);
        }
        return ['membership_level'=>$rule['level_code'],'membership_until'=>(int)$rule['period_end_at']];
    }

    public function closeUnpaid(int $id): array
    {
        $merchant=TeamService::assertOwner($this->context,null,true);$site=$this->context->site;
        $connection=Db::connect();$scope=(string)$connection->getConfig('database').':'.(string)$connection->getConfig('prefix');
        $key='lead_coop_pay:'.substr(hash('sha256',$scope.':'.$site.':'.$id),0,40);
        $locked=$connection->query('SELECT GET_LOCK(:lock_key, 3) AS acquired',['lock_key'=>$key],true);
        if ((int)($locked[0]['acquired']??0)!==1) throw new CommonException('该笔支付正在处理，请稍后刷新，不要重复操作');
        try {
            $order=Store::row('coop_order',$site,$id,true);
            if ($order['purpose']!=='membership'||(int)$order['merchant_id']!==(int)$merchant['id']||(int)$order['member_id']!==$this->context->memberId) throw new CommonException('只能关闭本人为当前主体创建的会员付款订单');
            if ($order['status']==='closed') return (new PaymentService($this->context))->order($id);
            if ($order['status']!=='unpaid') throw new CommonException('该订单已收款，不能取消；需要退款请联系平台');
            $pays=Db::name('pay')->where('site_id',$site)->where('trade_type',PaymentService::TRADE_TYPE)->where('trade_id',$id)->lock(true)->select()->toArray();
            foreach($pays as $pay) {
                if ($pay['main_type']!==PayDict::MEMBER||(int)$pay['main_id']!==$this->context->memberId||Rules::cents((string)$pay['money'])!==Rules::cents((string)$order['amount'])) throw new CommonException('原支付流水归属或金额异常，未关闭订单');
                if ((int)$pay['status']===(int)PayDict::STATUS_FINISH) throw new CommonException('原支付已经收款，请等待入账核对，不能取消或重新支付');
                if (!in_array((int)$pay['status'],[(int)PayDict::STATUS_WAIT,(int)PayDict::STATUS_CANCEL],true)) throw new CommonException('支付渠道仍在处理中，请先在原收银台核实取消结果，未关闭业务，请勿另开付款');
            }
            // WAIT is not yet sent to a provider. Never treat an uncertain ING result as cancellation.
            foreach($pays as $pay) if ((int)$pay['status']===(int)PayDict::STATUS_WAIT&&(new CorePayService())->close($site,(string)$pay['out_trade_no'])!==true) throw new CommonException('原支付尚未确认关闭，请勿重新下单');
            Db::transaction(function()use($site,$id):void {
                PromotionService::lockSite($site);$order=Store::row('coop_order',$site,$id,true);TeamService::assertOwner($this->context,(int)$order['merchant_id'],true);
                if ($order['status']!=='unpaid') throw new CommonException('原订单状态已变化，请刷新核对');
                if (Db::name('pay')->where('site_id',$site)->where('trade_type',PaymentService::TRADE_TYPE)->where('trade_id',$id)->where('status','<>',PayDict::STATUS_CANCEL)->lock(true)->field('id')->select()->toArray()) throw new CommonException('原支付未全部确认关闭，当前未关闭业务');
                Store::query('coop_order',$site)->where('id',$id)->update(['status'=>'closed','update_time'=>time()]);$this->context->audit('coop_order',$id,'closed',['purpose'=>'membership']);
            });return (new PaymentService($this->context))->order($id);
        } finally {try {$connection->query('SELECT RELEASE_LOCK(:lock_key) AS released',['lock_key'=>$key],true);}catch(\Throwable $ignored){}}
    }

    /** Verified successful refund only; partial refunds freeze affected rights, never guess days. */
    public static function refund(int $site,array $source,array $refund): void
    {
        $rule=Data::decode($source['rule_json']);self::assertSnapshot($source,$rule);
        $seen=$rule['refund_receipts']??[];if (in_array($refund['refund_no'],$seen,true)) return;$seen[]=$refund['refund_no'];$rule['refund_receipts']=$seen;
        $total=0;foreach(Db::name('pay_refund')->where('site_id',$site)->where('out_trade_no',$source['out_trade_no'])->where('status',RefundDict::SUCCESS)->lock(true)->field('money')->select()->toArray() as $receipt) $total+=Rules::cents((string)$receipt['money']);
        if ($total>Rules::cents((string)$source['amount'])) throw new CommonException('会员累计退款超过原实付，未修改权益，请核对');
        $full=$total===Rules::cents((string)$source['amount']);$rule['membership_refund_status']=$full?'refunded':'partial_review';
        if (!$full) $rule['requires_manual_review']='membership_partial_refund_review';
        elseif (in_array($rule['requires_manual_review']??'',['membership_partial_refund_review','membership_credit_refund_review','membership_receipt_conflict'],true)) {unset($rule['requires_manual_review']);$rule['membership_review_resolved_by_full_refund']=true;}
        Store::query('coop_order',$site)->where('id',$source['id'])->update(['rule_json'=>Data::json($rule),'update_time'=>time()]);
        $rows=self::ledger($site,(int)$source['merchant_id'],true);
        foreach($rows as $row) if (!empty($row['dependency_invalid'])&&$row['id']!==$source['id']) {$dependent=$row['rule'];$dependent['requires_manual_review']='membership_credit_refund_review';Store::query('coop_order',$site)->where('id',$row['id'])->update(['rule_json'=>Data::json($dependent),'update_time'=>time()]);}
        $state=self::stateFrom($rows,[],[],time());
        $partner=Store::partner($site,(int)$source['merchant_id'],true);Store::query('partner',$site)->where('id',$partner['id'])->update(['membership_level'=>$state['level_code']!==''?$state['level_code']:($partner['membership_level']?:$rule['level_code']),'membership_until'=>$state['expires_at'],'update_time'=>time()]);
        Data::audit($site,0,(int)$source['member_id'],'coop_order',(int)$source['id'],'membership_refund_processed',['refund_no'=>$refund['refund_no'],'status'=>$rule['membership_refund_status'],'level_code'=>$state['level_code'],'expires_at'=>$state['expires_at']]);
    }

    private static function ledger(int $site,int $merchant,bool $lock=false): array
    {
        $query=Store::query('coop_order',$site)->where('merchant_id',$merchant)->where('purpose','membership')->where('status','paid')->order('id');if ($lock) $query->lock(true);$rows=$query->select()->toArray();$out=[];
        foreach($rows as $row) {
            $rule=Data::decode($row['rule_json']);$row['rule']=$rule;$row['valid']=false;$row['refund_pending']=false;$row['review']=!empty($rule['requires_manual_review']);
            try {
                self::assertSnapshot($row,$rule);
                $payment=Db::name('pay')->where('site_id',$site)->where('trade_type',PaymentService::TRADE_TYPE)->where('trade_id',$row['id'])->where('out_trade_no',$row['out_trade_no'])->where('status',PayDict::STATUS_FINISH);if ($lock) $payment->lock(true);$pay=$payment->find();
                if (!$pay||$pay['main_type']!==PayDict::MEMBER||(int)$pay['main_id']!==(int)$row['member_id']||Rules::cents((string)$pay['money'])!==Rules::cents((string)$row['amount'])) throw new CommonException('原会员收款事实不完整');
                $refundQuery=Db::name('pay_refund')->where('site_id',$site)->where('out_trade_no',$row['out_trade_no']);if ($lock) $refundQuery->lock(true);$refunds=$refundQuery->select()->toArray();$refunded=0;
                foreach($refunds as $refund) {if ($refund['status']===RefundDict::SUCCESS) $refunded+=Rules::cents((string)$refund['money']);if (in_array($refund['status'],[RefundDict::WAIT,RefundDict::DEALING],true)) $row['refund_pending']=true;}
                $row['refunded']=$refunded;$row['valid']=$refunded===0&&!$row['review'];
                if ($row['valid']) self::assertSources($out,$rule);
            } catch(CommonException $error) {$row['valid']=false;$row['dependency_invalid']=!empty($rule['credit_sources']);if (empty($row['refunded'])) $row['review']=true;}
            $out[]=$row;
        }return $out;
    }

    private static function assertSources(array $rows,array $rule): void
    {
        $map=[];foreach($rows as $row) $map[(int)$row['id']]=$row;
        foreach($rule['credit_sources'] as $source) {
            $row=$map[(int)$source['order_id']]??null;
            if (!$row||empty($row['valid'])||!hash_equals((string)$source['source_fingerprint'],self::sourceFingerprint($row))) throw new CommonException('升级抵扣原收款已退款或变化，暂未开通高级权益');
            $a=(int)$source['start_at'];$b=(int)$source['end_at'];$raw=$row['rule'];
            if ($a<(int)$raw['period_start_at']||$b>(int)$raw['period_end_at']||Rules::cents($source['amount'])!==self::prorate(Rules::cents($raw['full_amount']),$b-$a,(int)$raw['period_end_at']-(int)$raw['period_start_at'])) throw new CommonException('会员抵扣期限或金额与原实付不符');
        }
    }

    /** Remaining grant portions, subtracting only verified, non-refunded dependent upgrades. */
    private static function availableSegments(array $rows): array
    {
        $out=[];foreach($rows as $row) {
            if (empty($row['valid'])) continue;$parts=[[(int)$row['rule']['period_start_at'],(int)$row['rule']['period_end_at']]];
            foreach($rows as $consumer) if (!empty($consumer['valid'])) foreach($consumer['rule']['credit_sources'] as $source) if ((int)$source['order_id']===(int)$row['id']) {
                $next=[];foreach($parts as [$a,$b]) {$s=(int)$source['start_at'];$e=(int)$source['end_at'];if ($e<=$a||$s>=$b) {$next[]=[$a,$b];continue;}if ($s>$a) $next[]=[$a,$s];if ($e<$b) $next[]=[$e,$b];}$parts=$next;
            }
            foreach($parts as [$a,$b]) $out[]=[$row,$a,$b];
        }return $out;
    }

    public static function stateFrom(array $rows,array $partner,array $tiers,int $now): array
    {
        $none=MembershipCatalogService::emptyCapabilities();
        $default=['level_code'=>'','level_id'=>0,'level_name'=>'普通会员','level_visual'=>MembershipCatalogService::visual([],0),'level_color'=>MembershipCatalogService::color(0),'rank'=>0,'display_rank'=>0,'active'=>false,'expires_at'=>0,'account_limit'=>1,'unlimited'=>false,'capabilities'=>$none,'benefits'=>MembershipCatalogService::benefits($none),'configuration_source'=>'framework_member_level'];$current=null;$end=0;$segments=self::availableSegments($rows);
        foreach($segments as [$row,$a,$b]) if ($a<=$now&&$b>$now&&(!$current||(int)$row['rule']['rank']>(int)$current['rank'])) {$current=$row['rule'];$end=$b;}
        if ($current) {
            do {$before=$end;foreach($segments as [$row,$a,$b]) if ($row['rule']['level_code']===$current['level_code']&&$a<=$end&&$b>$end) $end=$b;}while($before!==$end);
            // A deleted/edited sale definition cannot retrospectively remove
            // rights a merchant has already paid for. Only a verified refund
            // or grant expiry changes this frozen entitlement contract.
            return array_replace($default,['level_code'=>$current['level_code'],'level_id'=>(int)$current['level_id'],'level_name'=>$current['level_name'],'level_visual'=>MembershipCatalogService::visual([],(int)$current['display_rank']),'level_color'=>MembershipCatalogService::color((int)$current['display_rank']),'rank'=>(int)$current['rank'],'display_rank'=>(int)$current['display_rank'],'active'=>true,'expires_at'=>$end,'account_limit'=>(int)$current['account_limit'],'unlimited'=>(bool)$current['unlimited'],'capabilities'=>$current['capabilities'],'benefits'=>$current['benefits']]);
        }
        foreach($rows as $row) if (!empty($row['valid'])&&(int)$row['rule']['period_end_at']<=$now&&(int)$row['rule']['period_end_at']>$default['expires_at']) $default=array_replace($default,['level_code'=>$row['rule']['level_code'],'level_id'=>(int)$row['rule']['level_id'],'level_name'=>$row['rule']['level_name'],'level_visual'=>MembershipCatalogService::visual([],(int)$row['rule']['display_rank']),'level_color'=>MembershipCatalogService::color((int)$row['rule']['display_rank']),'rank'=>(int)$row['rule']['rank'],'display_rank'=>(int)$row['rule']['display_rank'],'expires_at'=>(int)$row['rule']['period_end_at']]);
        return $default;
    }

    private static function catalogMatches(array $rule,array $tiers): bool
    {
        foreach($tiers as $tier) if ($tier['code']===($rule['level_code']??'')) {
            if (empty($tier['enabled'])||!hash_equals((string)($rule['catalog_fingerprint']??''),self::tierFingerprint($tier))) return false;
            foreach($tier['cycles'] as $cycle) if ($cycle['key']===($rule['cycle']??'')) return !empty($cycle['enabled'])&&$cycle['months']===($rule['months']??0)&&Rules::cents($cycle['price'])===Rules::cents($rule['full_amount']??'');
        }return false;
    }
    /** Appearance edits never invalidate a payment quote or original grant. */
    private static function tierFingerprint(array $tier): string {unset($tier['level_visual'],$tier['level_color']);return hash('sha256',Data::json($tier));}
    private static function pricingFingerprint(array $tiers): string {foreach($tiers as &$tier)unset($tier['level_visual'],$tier['level_color']);unset($tier);return hash('sha256',Data::json($tiers));}
    private static function assertExperience(int $site,int $merchant,string $required): void
    {
        $experience=EntityExperienceService::summary($site,$merchant,true);
        if (!EntityExperienceService::eligible($experience,['experience_required'=>$required])) throw new CommonException('当前门店经验'.$experience['value'].'，本等级需要'.$required.'；尚未满足本次开通、升级或续费条件');
    }
    private static function sourceFingerprint(array $row): string {return hash('sha256',Data::json([(int)$row['id'],(string)$row['out_trade_no'],(int)$row['member_id'],(string)$row['amount'],$row['rule']['period_start_at']??0,$row['rule']['period_end_at']??0,$row['rule']['full_amount']??'',$row['rule']['credit_sources']??[],$row['rule']['level_id']??0,$row['rule']['level_code']??'',$row['rule']['rank']??0,$row['rule']['months']??0,$row['rule']['capabilities']??[],$row['rule']['benefits']??[]]));}
    private static function fingerprint(array $rows,array $partner): string {$facts=[];foreach($rows as $row) $facts[]=[(int)$row['id'],(bool)$row['valid'],(bool)$row['refund_pending'],(bool)$row['review'],(int)($row['refunded']??0),self::sourceFingerprint($row)];return hash('sha256',Data::json([$facts,$partner['membership_level']??'',(int)($partner['membership_until']??0)]));}
    private static function prorate(int $amount,int $covered,int $total): int {if ($covered<0||$total<=0||$covered>$total) throw new CommonException('会员剩余期限无效');return (int)bcdiv(bcmul((string)$amount,(string)$covered,0),(string)$total,0);}
    private function secret(): string {$key=(string)env('app.auth_key','');if (strlen($key)<16) throw new CommonException('平台尚未配置安全密钥');return hash('sha256','hsx_lead.entity_membership.quote.v3|'.$key,true);}
    private function sign(array $payload): string {$body=rtrim(strtr(base64_encode(Data::json($payload)),'+/','-_'),'=');return $body.'.'.hash_hmac('sha256',$body,$this->secret());}
    private function verify(string $token): array {if (strlen($token)>2048||substr_count($token,'.')!==1) throw new CommonException('会员报价无效，请重新读取');[$body,$mac]=explode('.',$token,2);if (!hash_equals(hash_hmac('sha256',$body,$this->secret()),$mac)) throw new CommonException('会员报价签名无效');$row=json_decode((string)base64_decode(strtr($body,'-_','+/'),true),true);if (!is_array($row)) throw new CommonException('会员报价无效');return $row;}
}
