<template>
    <view class="membership-page" :style="themeColor()">
        <CoopTaskSheet page :show="true" title="门店会员" :busy="state.busy.value" full @close="backCooperationTask">
            <CoopState v-if="state.loading.value && !state.ready.value" loading />
            <view v-else-if="state.error.value" class="membership-content"><CoopState :error="state.error.value" @retry="refresh" /></view>
            <view v-else-if="state.ready.value" class="membership-content">
                <view class="membership-current" :style="currentSkinStyle">
                    <view class="membership-current__hero">
                        <image v-if="currentSkin.cardImage" class="membership-card-art" :src="img(currentSkin.cardImage)" mode="aspectFill" aria-hidden="true" />
                        <view class="membership-current__head"><view class="membership-current__identity"><text class="membership-eyebrow">当前门店会员</text><text class="membership-current__title">{{ summary.level_name || '普通会员' }}</text><text class="membership-current__expiry">{{ summary.active ? '有效期至 ' + entityExpiry(summary.expires_at) : summary.level_code ? '权益已到期' : '尚未开通' }}</text></view><CoopLevelBadge v-if="membershipBadgeRank(summary)>0" :level="membershipBadgeRank(summary)" :appearance="summary.level_visual" :state="membershipState(summary)" variant="emblem" size="small" /></view>
                    </view>
                    <view v-if="summary.experience" class="membership-current__growth"><CoopExperienceProgress :experience="summary.experience" :next-level="summary.next_level" :maxed="experienceMaxed" :color="summary.level_color" /></view>
                </view>
                <view class="membership-seats" @tap="openTeam"><view><text class="membership-seats__label">门店账号</text><text class="membership-seats__count">{{ summary.used_accounts ?? '—' }}<text> / {{ entityAccounts(summary) }}</text></text></view><view class="membership-seats__manage"><text>{{ summary.can_manage ? '管理成员' : '查看成员' }}</text><u-icon name="arrow-right" size="13" color="#7b91ae" /></view></view>
                <view class="membership-heading"><text>选择会员等级</text><text class="membership-heading__hint">左右滑动查看</text></view>
                <swiper v-if="tiers.length" class="membership-swiper" :current="selectedIndex" :disable-touch="paymentLocked || state.busy.value" previous-margin="12rpx" next-margin="36rpx" @change="selectIndex(Number($event.detail.current))">
                    <swiper-item v-for="tier in tiers" :key="tier.code">
                        <view class="membership-tier" :style="tierStyle(tier)" :class="{ 'is-selected': selected === tier.code, 'is-disabled': !membershipCycles(tier).length }">
                            <image v-if="tierSkin(tier).cardImage" class="membership-card-art" :src="img(tierSkin(tier).cardImage)" mode="aspectFill" aria-hidden="true" />
                            <view class="membership-tier__content">
                                <view class="membership-tier__top"><view><text class="membership-tier__name">{{ tier.name }}</text></view><text class="membership-tier__state">{{ summary.level_code === tier.code ? summary.active ? '使用中' : '已到期' : !membershipCycles(tier).length ? '暂未开放' : '未开通' }}</text></view>
                                <view v-if="cycleFor(tier)" class="membership-tier__price"><text>{{ coopMoney(cycleFor(tier)?.price) }}</text><text> / {{ cycleFor(tier)?.name }}</text></view><view v-else class="membership-tier__unavailable">暂未开放购买</view>
                                <view class="membership-tier__accounts">{{ entityAccounts(tier) }}共同使用 · 包含负责人</view><view v-if="tier.is_entry" class="membership-tier__experience">入门等级 · 无成交经验门槛</view><view v-else-if="tier.experience_required !== undefined" class="membership-tier__experience" :class="{ 'is-met': tier.experience_eligible === true }"><u-icon :name="tier.experience_eligible === true ? 'checkmark-circle' : 'lock'" size="12" :color="tierSkin(tier).text" /><text>{{ tier.experience_eligible === false ? '还差 ' + experienceText(tier.experience_remaining) + ' 经验' : '需 ' + experienceText(tier.experience_required) + ' 经验' }}</text></view>
                            </view>
                        </view>
                    </swiper-item>
                </swiper>
                <CoopState v-else title="暂未开放会员等级" hint="请联系平台核对配置，当前不会创建付款单" />
                <view v-if="cycles.length > 1" class="membership-cycle"><button v-for="period in cycles" :key="period.key" :class="{ 'is-active': cycle === period.key }" :disabled="paymentLocked || state.busy.value" @tap="selectCycle(period.key)">{{ period.name }}</button></view>
                <view v-if="displayBenefits.length" class="membership-section"><view class="membership-section__title">{{ chosen?.name || summary.level_name }} 权益</view><view v-for="benefit in displayBenefits" :key="benefit.key" class="membership-right"><CoopBusinessIcon :name="benefitIcon(benefit.key)" :disabled="!benefit.enabled" size="small" /><view><text>{{ benefit.title }}</text><text>{{ benefit.desc }}</text></view><text v-if="!benefit.enabled" class="membership-right__excluded">不包含</text></view></view>
                <view v-if="chosen && summary.can_manage && !order.id" class="membership-section"><view class="membership-section__title">费用核对</view><CoopState v-if="quoting" loading /><template v-else-if="quote.can_purchase"><view class="membership-money-row"><text>套餐价格</text><text>{{ coopMoney(quote.full_amount) }}</text></view><view v-if="Number(quote.credit_amount) > 0" class="membership-money-row"><text>剩余有效期抵扣</text><text>−{{ coopMoney(quote.credit_amount) }}</text></view><view class="membership-money-row"><text>本次实付</text><text class="membership-money-row__total">{{ coopMoney(quote.payable_amount) }}</text></view><view class="membership-quote-period">{{ entityExpiry(quote.period_start_at) }} 至 {{ entityExpiry(quote.period_end_at) }}</view></template><view v-else class="membership-muted">{{ quoteError || quote.reason || '正在核对当前套餐费用' }}</view></view>
                <view v-if="quoteError && !order.id" class="membership-error" role="alert">{{ quoteError }}<button class="membership-refresh-payment" :disabled="quoting || state.busy.value" @tap="loadQuote">重新核对费用</button></view>
                <view v-if="order.id" class="membership-section"><view class="membership-section__title">原付款单</view><view class="membership-money-row"><text>{{ order.level_name || order.level_code || '会员开通' }}</text><text>{{ coopMoney(order.amount) }}</text></view><view class="membership-payment-message" :class="{ 'is-error': !!order.requires_manual_review }">{{ paymentMessage || '请核对原单支付结果，不要重复创建付款。' }}</view><button class="membership-refresh-payment" :disabled="checking || state.busy.value" @tap="verifyPayment">{{ checking ? '核对中…' : '刷新付款结果' }}</button><button v-if="order.status === 'unpaid' && summary.can_manage" class="membership-cancel-payment" :disabled="checking || state.busy.value || closing" @tap="closeOrder">取消待支付订单</button></view>
                <view v-if="state.writeError.value" class="membership-error" role="alert">{{ state.writeError.value }}</view>
                <view class="membership-section membership-help"><u-collapse :border="false"><u-collapse-item title="经验怎么累计、怎么升级？" name="experience"><view>门店每实际支付 1 元已确认的协作佣金，累计 1 点经验。会员费不计入；成功退款相应扣回。经验达标后可自主付费开通、补差升级或续费，不自动扣款；升级和续费时都会重新核验经验。退款后已购买的权益保留到期，不会静默降级。</view></u-collapse-item><u-collapse-item title="账号与会员如何共用？" name="account"><view>会员归属于当前门店，不需要每位同事重复购买。总账号数包含负责人；同事加入需负责人确认。</view></u-collapse-item><u-collapse-item title="到期或人数超过上限怎么办？" name="expiry"><view>到期不会删除成员或历史业务。新增成员和新业务按当前有效权益控制，已有记录仍可核对处理。</view></u-collapse-item></u-collapse></view>
            </view>
            <template v-if="state.ready.value" #footer><view v-if="!summary.can_manage" class="membership-footer-note">会员由门店负责人统一开通或续费</view><view v-else><view v-if="paymentLocked" class="membership-footer-note">{{ order.quote_expired ? '报价已过期，请取消原待支付单后重新核价' : order.requires_manual_review ? '款项已收到，等待平台核对权益' : '已有待核对的原付款单，请先处理原单' }}</view><u-button type="primary" shape="circle" :custom-style="cooperationButtonStyle" :text="mainLabel" :loading="state.busy.value || checking || quoting" :disabled="state.busy.value || checking || quoting || closing || (!chosen && !order.id) || (!order.id && !quote.can_purchase) || !!order.requires_manual_review || (order.status === 'unpaid' && !!order.quote_expired)" @click="submitMembershipPayment" /></view></template>
        </CoopTaskSheet>
        <view class="membership-cashier"><Pay ref="payRef" :ignore-pay="['friendspay']" :reformat="cashierReturn" @confirm="verifyPayment" @close="verifyPayment" /></view>
    </view>
</template>
<script setup lang="ts">
import { computed, ref } from 'vue'
import { onHide, onLoad, onShow } from '@dcloudio/uni-app'
import Pay from '@/components/pay/pay.vue'
import { img } from '@/utils/common'
import CoopTaskSheet from '../../components/cooperation/CoopTaskSheet.vue'
import CoopState from '../../components/cooperation/CoopState.vue'
import CoopLevelBadge from '../../components/cooperation/CoopLevelBadge.vue'
import CoopBusinessIcon from '../../components/cooperation/CoopBusinessIcon.vue'
import CoopExperienceProgress from '../../components/cooperation/CoopExperienceProgress.vue'
import { entityCloseOrder, entityMembership, entityQuote } from '../../api/entity'
import { cooperationOrder, createCooperationOrder, coopError, coopMoney, coopRequestId, type CoopRow } from '../../api/cooperation'
import { useEntityPage } from '../../composables/useEntityPage'
import { entityAccounts, entityExpiry, entityLevel, entityPageUrl, membershipPageUrl, membershipState, membershipCycles, membershipCycleKey, membershipBadgeRank, membershipBenefits, experienceText, quoteMatches } from '../../utils/entity-membership'
import { backCooperationTask } from '../../utils/cooperation-navigation'
import { cooperationButtonStyle } from '../../utils/mobile-ui'
import { membershipSkin, membershipSkinVars } from '../../utils/membership-skin'
const state = useEntityPage(entityMembership), summary = state.data, selected = ref(''), cycle = ref(''), quote = ref<CoopRow>({}), quoteError = ref(''), quoting = ref(false), order = ref<CoopRow>({}), paymentMessage = ref(''), checking = ref(false), closing = ref(false), payRef = ref<any>(null)
const tiers = computed<CoopRow[]>(() => (Array.isArray(summary.value.tiers) ? summary.value.tiers : []).filter((tier: CoopRow) => !!entityLevel(tier.code))), chosen = computed(() => tiers.value.find(tier => tier.code === selected.value)), selectedIndex = computed(() => Math.max(0, tiers.value.findIndex(tier => tier.code === selected.value))), paymentLocked = computed(() => !!order.value.id && (!!order.value.requires_manual_review || !['closed', 'refunded', 'paid'].includes(String(order.value.status)))), cashierReturn = computed(() => `${membershipPageUrl}?payment_order_id=${Number(order.value.id || 0)}`)
const mainLabel = computed(() => order.value.requires_manual_review ? '已收款，需平台核对' : order.value.membership_refund_status === 'refunded' || order.value.status === 'refunded' ? '退款已确认，返回' : order.value.status === 'unpaid' && order.value.quote_expired ? '原报价已过期' : order.value.id && order.value.status === 'unpaid' ? '继续原单付款' : order.value.status === 'paid' ? '支付已确认，返回' : chosen.value?.experience_eligible === false ? '经验未达标' : summary.value.level_code === selected.value && summary.value.active ? '确认续费' : summary.value.active && summary.value.level_code ? '确认补差升级' : '确认开通')
const cycles = computed(() => membershipCycles(chosen.value)), displayBenefits = computed(() => membershipBenefits(chosen.value || summary.value))
const experienceMaxed = computed(() => tiers.value.length > 0 && Number(summary.value.rank) > 0 && !tiers.value.some(tier => Number(tier.rank) > Number(summary.value.rank)))
const currentSkin = computed(() => membershipSkin(summary.value.active === true ? summary.value.level_visual : {}, summary.value.active === true ? membershipBadgeRank(summary.value) : 0))
const currentSkinStyle = computed(() => membershipSkinVars(summary.value.active === true ? summary.value.level_visual : {}, summary.value.active === true ? membershipBadgeRank(summary.value) : 0))
function tierSkin(tier: CoopRow) { return membershipSkin(tier.level_visual, membershipBadgeRank(tier)) }
function tierStyle(tier: CoopRow) { return membershipSkinVars(tier.level_visual, membershipBadgeRank(tier)) }
let pageActive = true, quoteEpoch = 0, incomingOrder = 0, requestId = '', requestKey = '', identity = ''
onLoad(options => { const id = Number(options?.payment_order_id || 0); incomingOrder = Number.isSafeInteger(id) && id > 0 ? id : 0 })
onShow(() => { pageActive = true; void refresh() })
onHide(() => { pageActive = false; quoteEpoch++; quoting.value = false; state.pause() })
function cycleFor(tier: CoopRow) { const available = membershipCycles(tier); return available.find((period: CoopRow) => period.key === cycle.value) || available[0] }
function benefitIcon(key: string): 'store' | 'customer' | 'stock' | 'member' { return ({ can_publish:'store',can_accept:'customer',can_view_inventory:'stock',all_models:'member' } as const)[key] || 'member' }
function ensureCycle() { if (!cycles.value.some((period: CoopRow) => period.key === cycle.value)) cycle.value = cycles.value[0]?.key || '' }
async function refresh() {
    const who = state.identity()
    if (who !== identity) { if (identity) incomingOrder = 0; identity = who; order.value = {}; quote.value = {}; requestId = ''; requestKey = ''; paymentMessage.value = '' }
    const ok = await state.refresh()
    if (!ok || !pageActive) return
    if (!selected.value || !tiers.value.some(tier => tier.code === selected.value)) selected.value = entityLevel(summary.value.level_code) || tiers.value[0]?.code || ''
    if (!tiers.value.some(tier => tier.code === selected.value)) selected.value = tiers.value[0]?.code || ''
    ensureCycle()
    if (incomingOrder) { const id = incomingOrder; incomingOrder = 0; order.value = { id }; await verifyPayment(); return }
    if (order.value.id) { await verifyPayment(); return }
    await loadQuote()
}
function selectIndex(index: number) { const tier = tiers.value[index]; if (!tier || selected.value === tier.code) return; if (paymentLocked.value || state.busy.value) { uni.showToast({ title: '请先核对原付款单', icon: 'none' }); return }; selected.value = tier.code; order.value = {}; ensureCycle(); void loadQuote() }
function selectCycle(value: string) { if (paymentLocked.value || state.busy.value || cycle.value === value || !cycles.value.some((period: CoopRow) => period.key === value)) return; cycle.value = value; order.value = {}; void loadQuote() }
async function loadQuote() {
    const turn = ++quoteEpoch, who = state.identity(), level = selected.value, period = cycle.value
    quote.value = {}; quoteError.value = ''
    if (!summary.value.can_manage || !level || !period) { quote.value = { can_purchase: false, reason: '当前等级暂未开放购买周期' }; return }
    quoting.value = true
    try {
        const response: any = await entityQuote(level, period)
        if (!pageActive || turn !== quoteEpoch || !state.current(who) || level !== selected.value || period !== cycle.value) return
        const value = response?.data || {}
        if (Number(value.merchant_id) !== Number(summary.value.merchant_id) || value.purpose !== 'membership') throw new Error('报价与当前门店不一致，请重新核对')
        if (Number(value.existing_order_id) > 0) { order.value = { id: Number(value.existing_order_id) }; await verifyPayment(); return }
        if (value.can_purchase && !quoteMatches(value, Number(summary.value.merchant_id), level, period)) throw new Error('报价未完整返回或已失效，请重新核对')
        quote.value = value
    } catch (cause) { if (pageActive && turn === quoteEpoch && state.current(who)) quoteError.value = coopError(cause, '费用未能核对，请刷新重试，当前未创建付款单') }
    finally { if (turn === quoteEpoch) quoting.value = false }
}
function validateOrder(value: CoopRow, id: number) { if (!Number.isSafeInteger(id) || id <= 0 || Number(value.id) !== id || value.purpose !== 'membership' || Number(value.merchant_id) !== Number(summary.value.merchant_id) || !entityLevel(value.level_code) || !membershipCycleKey(value.cycle) || !Number.isSafeInteger(value.entitlement_months) || value.entitlement_months < 1 || value.entitlement_months > 120) throw new Error('原付款单与当前门店或会员业务不一致，未打开收银台'); return value }
async function verifyPayment() {
    const id = Number(order.value.id), who = state.identity()
    if (!id || checking.value || !summary.value.merchant_id) return false
    checking.value = true
    try {
        const response: any = await cooperationOrder(id)
        if (!pageActive || !state.current(who) || id !== Number(order.value.id)) return false
        const value = validateOrder(response?.data || {}, id); order.value = value; selected.value = value.level_code; cycle.value = value.cycle
        if (value.requires_manual_review) { paymentMessage.value = value.review_message || '款项已收到，权益需平台核对，请勿重复付款'; return false }
        if (value.membership_refund_status === 'refunded') { paymentMessage.value = '原单已退款，请核对当前门店权益。'; await state.refresh(); return true }
        if (value.status === 'paid') { paymentMessage.value = '支付已确认，门店权益已更新'; await state.refresh() }
        else if (value.status === 'unpaid') paymentMessage.value = value.quote_expired ? '原报价已过期，不能继续付款。请取消这笔待支付订单，再核对新的费用。' : '原单尚未确认支付，可继续原单付款，或刷新核对。'
        else if (value.status === 'closed' || value.status === 'refunded') { paymentMessage.value = value.status === 'refunded' ? '原单已退款，请核对当前门店权益。' : '原单已关闭，重新开通需再次确认费用。'; requestId = ''; requestKey = ''; await state.refresh(); await loadQuote() }
        else paymentMessage.value = '原单状态待核实，暂不重复付款，请联系平台核对。'
        return value.status === 'paid' || (value.status === 'unpaid' && !value.quote_expired)
    } catch (cause) { if (pageActive && state.current(who)) paymentMessage.value = coopError(cause, '支付结果尚未确认，请刷新核对，勿重复付款'); return false }
    finally { checking.value = false }
}
async function submitMembershipPayment() {
    if (!summary.value.can_manage || state.busy.value || checking.value || quoting.value || closing.value || order.value.requires_manual_review || (order.value.status === 'unpaid' && order.value.quote_expired)) return
    if (order.value.id && (order.value.status === 'paid' || order.value.status === 'refunded' || order.value.membership_refund_status === 'refunded')) { backCooperationTask(); return }
    if (order.value.id && order.value.status === 'unpaid') { const who = state.identity(), verified = await verifyPayment(); if (verified && state.current(who) && order.value.status === 'unpaid' && !order.value.requires_manual_review && !order.value.quote_expired && pageActive) payRef.value?.open('hsx_lead_cooperation', Number(order.value.id), cashierReturn.value); return }
    if (!quoteMatches(quote.value, Number(summary.value.merchant_id), selected.value, cycle.value)) { await loadQuote(); return }
    const snapshot = { ...quote.value }, key = `${summary.value.merchant_id}:${selected.value}:${cycle.value}:${snapshot.quote_token}`
    if (requestKey !== key) { requestKey = key; requestId = coopRequestId() }
    const value = await state.write(() => createCooperationOrder({ purpose: 'membership', level_code: selected.value, cycle: cycle.value, quote_token: snapshot.quote_token, request_id: requestId }))
    if (!value) return
    const id = Number(value.id)
    try { validateOrder(value, id) } catch (cause) { state.writeError.value = coopError(cause); return }
    order.value = value; paymentMessage.value = '付款单已建立，等待支付结果确认。'
    if (String(value.amount) !== String(snapshot.payable_amount)) { paymentMessage.value = '已找到原付款单，请核对原单金额后继续，当前未打开收银台。'; return }
    if (value.status === 'paid') { await verifyPayment(); return }
    if (value.status === 'unpaid') payRef.value?.open('hsx_lead_cooperation', id, cashierReturn.value)
}
async function closeOrder() {
    if (closing.value || checking.value || state.busy.value || order.value.status !== 'unpaid') return
    closing.value = true
    try {
        const confirmed = await new Promise<boolean>(resolve => uni.showModal({ title: '取消待支付订单？', content: '仅取消这笔未支付的开通或续费订单，不影响现有有效权益。若支付结果待核实，系统会阻止取消。', confirmText: '确认取消', success: result => resolve(!!result.confirm), fail: () => resolve(false) }))
        if (!confirmed) return
        const result = await state.write(() => entityCloseOrder(Number(order.value.id)))
        if (result) { order.value = {}; requestId = ''; requestKey = ''; paymentMessage.value = ''; await refresh() }
    } finally { closing.value = false }
}
function openTeam() { uni.navigateTo({ url: entityPageUrl }) }
</script>
<style scoped lang="scss">
.membership-page { height:calc(100vh - var(--window-top,0px) - var(--window-bottom,0px));min-height:0;display:flex;flex-direction:column;overflow:hidden;box-sizing:border-box;background:#f6f6f6;color:#202124; }
/* #ifdef H5 */
@supports(height:100dvh){.membership-page{height:calc(100dvh - var(--window-top,0px) - var(--window-bottom,0px));}}
/* #endif */
.membership-content { padding:12px 12px 24px; }
.membership-current { background:#fff;border-radius:14px;overflow:hidden; }
.membership-current__hero { position:relative;padding:20px;background:var(--lead-member-gradient);color:var(--lead-member-text);overflow:hidden; }
.membership-current__hero::after { content:'';position:absolute;width:170px;height:170px;right:-65px;top:-100px;border:28px solid rgba(255,255,255,.17);border-radius:50%;pointer-events:none; }
.membership-current__head { position:relative;display:flex;align-items:center;justify-content:space-between;gap:12px; }
.membership-card-art { position:absolute;top:0;left:0;width:100%;height:100%;opacity:.55;pointer-events:none; }
.membership-current__growth { padding:0 16px 16px; }
.membership-current__identity { min-width:0;flex:1; }
.membership-eyebrow { display:block;font-size:12px;line-height:18px;opacity:.72; }
.membership-current__title { display:block;font-size:21px;line-height:29px;font-weight:650;margin:5px 0;overflow-wrap:break-word; }
.membership-current__expiry { display:block;font-size:12px;line-height:20px;opacity:.78; }
.membership-seats { display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:56px;background:#fff;margin:8px 0 20px;border-radius:8px;padding:12px 16px;box-sizing:border-box; }
.membership-seats>view:first-child { display:flex;align-items:baseline;gap:14px;min-width:0; }
.membership-seats__label { font-size:13px;color:#555;line-height:20px; }
.membership-seats__count { font-size:22px;line-height:28px;font-weight:650;white-space:nowrap; }
.membership-seats__count>text { font-size:12px;font-weight:400;color:#777; }
.membership-seats__manage { display:flex;align-items:center;gap:5px;flex:none;min-height:44px;color:#555;font-size:12px; }
.membership-heading { display:flex;justify-content:space-between;align-items:center;margin:0 2px 12px;gap:10px;font-size:17px;font-weight:650; }
.membership-heading__hint { font-size:12px;color:#888;font-weight:400; }
.membership-swiper { height:220px;margin:0 -6px; }
.membership-tier { position:relative;overflow:hidden;height:204px;margin:2px 8px 0 2px;padding:18px;box-sizing:border-box;border:1px solid transparent;border-radius:14px;background:var(--lead-member-gradient);color:var(--lead-member-text); }
.membership-tier.is-selected { border-color:var(--lead-member-accent);box-shadow:0 2px 8px rgba(32,36,42,.09); }
.membership-tier.is-disabled { opacity:.7; }
.membership-tier__content { position:relative; }
.membership-tier__top { display:flex;justify-content:space-between;align-items:flex-start;gap:10px; }
.membership-tier__top>view:first-child { min-width:0;flex:1; }
.membership-tier__name { display:block;font-size:17px;font-weight:650;line-height:24px;overflow-wrap:break-word; }
.membership-tier__state { flex:none;padding:3px 8px;border-radius:20px;background:rgba(255,255,255,.28);font-size:11px;line-height:18px; }
.membership-tier__price { display:flex;align-items:baseline;gap:4px;margin-top:12px;line-height:30px;white-space:nowrap; }
.membership-tier__price>text:first-child { font-size:25px;font-weight:700; }
.membership-tier__price>text:last-child:not(:first-child) { font-size:12px;font-weight:400;opacity:.72; }
.membership-tier__accounts { margin-top:3px;font-size:12px;line-height:20px;opacity:.78; }
.membership-tier__experience { display:flex;align-items:center;gap:5px;opacity:.8;font-size:12px;line-height:20px;margin-top:6px; }
.membership-tier__experience.is-met { opacity:1; }
.membership-tier__unavailable { font-size:13px;opacity:.72;line-height:30px;margin-top:12px; }
.membership-cycle { display:flex;flex-wrap:wrap;gap:8px;margin:0 0 16px; }
.membership-cycle>button { flex:1 0 27%;min-width:72px;margin:0;padding:0 8px;height:40px;line-height:40px;background:#fff;border:1px solid #e5e5e5;border-radius:6px;color:#555;font-size:14px;white-space:nowrap; }
.membership-cycle>button::after,.membership-refresh-payment::after,.membership-cancel-payment::after { border:0; }
.membership-cycle>button.is-active { color:var(--primary-color,#ff4444);border-color:var(--primary-color,#ff4444);font-weight:600; }
.membership-section { padding:16px;background:#fff;border-radius:8px;margin:12px 0; }
.membership-section__title { font-size:16px;font-weight:650;line-height:24px;margin-bottom:8px;overflow-wrap:break-word; }
.membership-right { display:flex;gap:12px;align-items:center;padding:13px 0;border-bottom:1px solid #f2f2f2; }
.membership-right:last-child { border-bottom:0;padding-bottom:4px; }
.membership-right>view:nth-child(2) { min-width:0;flex:1; }
.membership-right>view:nth-child(2)>text { display:block;font-size:12px;color:#777;line-height:19px; }
.membership-right>view:nth-child(2)>text:first-child { font-size:14px;color:#333;font-weight:500;line-height:22px;margin-bottom:2px; }
.membership-right__excluded { flex:none;font-size:11px;color:#999; }
.membership-money-row { display:flex;align-items:center;justify-content:space-between;gap:12px;margin:12px 0;font-size:13px;color:#666; }
.membership-money-row>text:last-child { color:#222;font-weight:600; }
.membership-money-row>text.membership-money-row__total { font-size:24px;color:var(--price-text-color,var(--primary-color,#ff4444)); }
.membership-quote-period { font-size:12px;color:#777;line-height:20px;text-align:right;padding-top:4px; }
.membership-muted { font-size:13px;color:#777;line-height:22px; }
.membership-help { padding:2px 8px;color:#777;font-size:12px;line-height:22px; }
.membership-payment-message { padding:12px;background:#f5f7fa;color:#4e5969;border-radius:6px;font-size:13px;line-height:21px; }
.membership-payment-message.is-error,.membership-error { color:#a34f34;background:#fff4ed; }
.membership-error { font-size:13px;line-height:21px;padding:12px;border-radius:6px; }
.membership-refresh-payment { font-size:13px;line-height:44px;color:var(--primary-color,#ff4444);background:transparent;margin:4px 0 0; }
.membership-footer-note { color:#777;font-size:12px;line-height:19px;text-align:center;margin:0 0 8px; }
.membership-footer-note:last-child { margin:0; }
.membership-cashier { height:0;flex:none; }
.membership-cancel-payment { background:transparent;color:#777;font-size:12px;line-height:44px; }
</style>
