<?php
declare(strict_types=1);

/** Real installed EasyWeChat/Symfony clients; only transport and token resolution are synthetic. */
require dirname(__DIR__, 3) . '/vendor/autoload.php';
require dirname(__DIR__, 3) . '/core/template/NoticeTransport.php';

use core\template\NoticeTransport;
use EasyWeChat\MiniApp\Application as MiniApp;
use EasyWeChat\OfficialAccount\Application as OfficialAccount;
use EasyWeChat\OpenPlatform\Application as OpenPlatform;
use EasyWeChat\OpenPlatform\AuthorizerAccessToken;
use Symfony\Component\HttpClient\Exception\TransportException;
use Symfony\Component\HttpClient\MockHttpClient;
use Symfony\Component\HttpClient\Response\MockResponse;

final class NoticeSyntheticOpenPlatform extends OpenPlatform
{
    public function getAuthorizerAccessToken(string $appId, string $refreshToken): string
    {
        // No credential refresh, cache write or network request is permitted in this test.
        return 'synthetic_authorizer_token';
    }
}

$checks = 0;
function transportCheck(bool $ok, string $message): void
{
    global $checks;
    $checks++;
    if (!$ok) throw new RuntimeException($message);
}

function noticeApplication(string $variant)
{
    $http = ['retry' => true, 'max_retries' => 2];
    if (str_starts_with($variant, 'authorized_')) {
        $provider = new NoticeSyntheticOpenPlatform([
            'app_id' => 'wx_synthetic_provider', 'secret' => 'synthetic',
            'token' => 'synthetic', 'aes_key' => str_repeat('A', 43), 'http' => $http,
        ]);
        return $variant === 'authorized_weapp'
            ? $provider->getMiniAppWithRefreshToken('wx_synthetic_authorizer', 'synthetic_refresh')
            : $provider->getOfficialAccountWithRefreshToken('wx_synthetic_authorizer', 'synthetic_refresh');
    }
    $app = $variant === 'direct_weapp'
        ? new MiniApp(['app_id' => 'wx_synthetic_direct', 'secret' => 'synthetic', 'http' => $http])
        : new OfficialAccount(['app_id' => 'wx_synthetic_direct', 'secret' => 'synthetic', 'http' => $http]);
    $app->setAccessToken(new AuthorizerAccessToken('wx_synthetic_direct', 'synthetic_direct_token'));
    return $app;
}

$variants = ['direct_weapp', 'direct_wechat', 'authorized_weapp', 'authorized_wechat'];
$cases = ['accepted', 'http_502', 'http_503', 'http_429', 'transport_failure', 'provider_rejected'];
foreach ($variants as $variant) {
    foreach ($cases as $case) {
        $app = noticeApplication($variant);
        $calls = 0;
        $mock = new MockHttpClient(function ($method, $url, $options) use (&$calls, $case) {
            $calls++;
            transportCheck($method === 'POST', 'Notice transport must submit a POST');
            transportCheck(str_contains($url, '/cgi-bin/message/'), 'Only the synthetic notice endpoint is called');
            if ($case === 'transport_failure') throw new TransportException('synthetic transport timeout');
            $status = str_starts_with($case, 'http_') ? (int) substr($case, 5) : 200;
            $body = $case === 'provider_rejected' ? '{"errcode":43101}' : '{"errcode":0}';
            // A second accepted response would expose a hidden retry, rather than hiding it in the final result.
            if ($calls > 1) { $status = 200; $body = '{"errcode":0}'; }
            return new MockResponse($body, ['http_code' => $status]);
        }, 'https://api.weixin.qq.com');
        $app->setHttpClient($mock);
        $cached = $app->getClient();
        $originalConfig = $app->getConfig();
        $beforeConfig = $originalConfig->all();
        $client = NoticeTransport::client($app);
        transportCheck($client !== $cached, $variant . ': helper must bypass the original cached retry client');
        transportCheck($app->getConfig() === $originalConfig && $originalConfig->all() === $beforeConfig,
            $variant . ': helper must not mutate the original configuration');
        transportCheck($app->getClient() === $cached && $originalConfig->get('http.retry') === true,
            $variant . ': unrelated original client and retry policy must be preserved');

        $endpoint = str_ends_with($variant, 'weapp') ? 'subscribe/send' : 'template/send';
        $failed = false;
        $body = null;
        try {
            $body = $client->postJson('cgi-bin/message/' . $endpoint, [
                'template_id' => 'synthetic_template', 'touser' => 'synthetic_recipient', 'data' => [],
            ])->toArray();
        } catch (Throwable $error) {
            $failed = true;
        }
        transportCheck($calls === 1, $variant . '/' . $case . ': one send must never replay its POST');
        if (str_starts_with($case, 'http_') || $case === 'transport_failure') {
            transportCheck($failed, $variant . '/' . $case . ': ambiguous HTTP/transport result must propagate');
        } else {
            transportCheck(!$failed && $body['errcode'] === ($case === 'provider_rejected' ? 43101 : 0),
                $variant . '/' . $case . ': preserve raw provider receipt for explicit validation');
        }
    }
}

echo json_encode([
    'passed' => true, 'checks' => $checks, 'sdk_variants' => count($variants), 'cases_per_variant' => count($cases),
    'scope' => 'Installed EasyWeChat and Symfony; fake HTTP and token resolution; no network, database writes or real notices',
], JSON_UNESCAPED_UNICODE) . PHP_EOL;
