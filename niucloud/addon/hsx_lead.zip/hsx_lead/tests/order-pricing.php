<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{OrderPricingService,ConfigService,PartnerService,CooperationService,PaymentService,EntityMembershipService,CapabilityService,Store,Rules};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{OnlinePayDict,PayDict};
use addon\hsx_lead\app\listener\pay\CooperationPaySuccess;
use core\exception\CommonException;
use think\facade\{Db,Event};
final class PricingSyntheticProvider
{
    public array $calls=[];
    public function __construct(private array $answers){}
    public function getOrder(string $no){$this->calls[]='query';return array_shift($this->answers);}
    public function close(string $no){$this->calls[]='close';return true;}
}
$checks=0;$pdo=null;$schema='';$failed=false;
function rpCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function rpDeny(callable $fn,string $label):void{try{$fn();}catch(CommonException $error){rpCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund']as$table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m);$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    $ctx=new Context($site,0,102);$pubCtx=new Context($site,0,101);$admin=new Context($site,1);$pricing=new OrderPricingService($admin);
    $config=(new ConfigService($admin))->get();$config['enabled']=true;$config['publishing_required']=false;$config['fee_confirmed']=true;$config['businesses'][0]['commission_minimum']='50.00';(new ConfigService($admin))->save($config);
    $profile=['name'=>'Synthetic receiving shop','contact_name'=>'Fixture','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture address'];
    $receiver=(new PartnerService($ctx))->saveProfile($profile);(new PartnerService($pubCtx))->saveProfile(array_replace($profile,['name'=>'Synthetic publisher','mobile'=>'19900000101']));
    $pub=new CooperationService($pubCtx);$receive=new CooperationService($ctx);$payments=new PaymentService($ctx);
    (new CapabilityService($ctx))->save((int)$receiver['id'],['business_capabilities'=>[['business_type'=>'purchase','option_ids'=>[$pub->catalog()[0]['id']]]]]);
    $makeCommission=static function(string $suffix)use($pub,$receive,$receiver,$payments):array{$model=$pub->catalog()[0];$lead=$pub->create(['request_id'=>'pricing-lead-'.$suffix,'customer_name'=>'Synthetic customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'consent'=>true,'attachments'=>[]]);$pub->assign((int)$lead['id'],['merchant_id'=>$receiver['id'],'assignment_version'=>0]);$receive->action((int)$lead['id'],['action'=>'accept','assignment_version'=>1]);$receive->action((int)$lead['id'],['action'=>'deal','assignment_version'=>1]);return $payments->createOrder(['purpose'=>'commission','lead_id'=>$lead['id'],'amount'=>'100.00','request_id'=>'pricing-source-'.$suffix]);};
    $payload=static fn(string $suffix,string $amount='120.00'):array=>['confirm'=>true,'request_id'=>'pricing-request-'.$suffix,'amount'=>$amount,'reason'=>'本地合成业务调整价格'];
    $receipt=static function(array $order,int $status)use($site):array{$no='PRICING_SYNTHETIC_'.bin2hex(random_bytes(8));Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>$order['member_id'],'from_main_id'=>$order['member_id'],'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>$status,'pay_time'=>time()]);return['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$no];};
    $old=$makeCommission('one');$before=Store::row('coop_order',$site,(int)$old['id']);
    rpDeny(fn()=>Db::transaction(fn()=>$pricing->reprice((int)$old['id'],$payload('one'))),'external transaction cannot surround gateway reconciliation');
    rpDeny(fn()=>$pricing->reprice((int)$old['id'],array_replace($payload('one'),['amount'=>'49.00'])),'frozen business minimum rejects discount before any closure');
    rpCheck(Store::row('coop_order',$site,(int)$old['id'])['status']==='unpaid','invalid price does not close the order');
    rpDeny(fn()=>(new OrderPricingService($ctx))->reprice((int)$old['id'],$payload('one')),'member cannot invoke administrator price adjustment');
    rpDeny(fn()=>(new OrderPricingService(new Context($site+1,1)))->reprice((int)$old['id'],$payload('one')),'cross-site admin cannot change order');
    $changed=$pricing->reprice((int)$old['id'],$payload('one'));
    rpCheck($changed['repriced']&&$changed['old_order']['status']==='closed'&&$changed['replacement_id']>(int)$old['id'],'reprice closes original and creates another trade ID');
    $next=$changed['replacement_order'];$rawOld=Store::row('coop_order',$site,(int)$old['id']);$rawNew=Store::row('coop_order',$site,(int)$next['id']);
    rpCheck($rawOld['amount']==='100.00'&&$rawOld['fee_amount']===$before['fee_amount']&&$rawOld['net_amount']===$before['net_amount'],'original amount and financial snapshot are immutable');
    rpCheck($next['amount']==='120.00'&&$next['fee_amount']==='12.00'&&$next['net_amount']==='108.00','replacement fee and publisher net use original frozen rules');
    rpCheck($changed['old_order']['replacement_order_id']==$next['id']&&$next['reprices_order_id']==$old['id']&&$changed['old_order']['replacement_order_no']===$next['order_no'],'presented old/new links are bidirectional and retain the actual order number');
    rpCheck(Store::row('collaboration',$site,(int)$old['lead_id'])['payment_order_id']==$next['id'],'current lead points only to the new unpaid trade');
    $count=Store::query('coop_order',$site)->count();$same=$pricing->reprice((int)$old['id'],$payload('one'));
    rpCheck($same['replacement_id']===$changed['replacement_id']&&Store::query('coop_order',$site)->count()===$count,'same request retry returns same replacement without duplicate trade');
    rpDeny(fn()=>$pricing->reprice((int)$old['id'],$payload('different','130.00')),'another request cannot silently change an already replaced source');
    $payments->assertPayable((int)$next['id']);rpCheck(true,'real payment guard accepts safely linked new commission trade');
    $newRule=Data::decode($rawNew['rule_json']);$cycle=$newRule;$cycle['reprices_order_id']=(int)$next['id'];Store::query('coop_order',$site)->where('id',$next['id'])->update(['rule_json'=>Data::json($cycle)]);rpDeny(fn()=>$payments->assertPayable((int)$next['id']),'self-referential predecessor chain cannot authorize payment');Store::query('coop_order',$site)->where('id',$next['id'])->update(['rule_json'=>Data::json($newRule)]);
    Store::query('coop_order',$site)->where('id',$old['id'])->update(['member_id'=>101]);rpDeny(fn()=>$payments->assertPayable((int)$next['id']),'predecessor payer mismatch cannot authorize payment');Store::query('coop_order',$site)->where('id',$old['id'])->update(['member_id'=>102]);
    $previous=0;$depthRule=Data::decode($before['rule_json']);for($depth=1;$depth<=21;$depth++){$r=$depthRule;if($previous)$r['reprices_order_id']=$previous;$previous=(int)Store::query('coop_order',$site)->insertGetId(['site_id'=>$site,'order_no'=>'SYNTHETIC-DEPTH-'.$depth,'purpose'=>'commission','lead_id'=>$old['lead_id'],'merchant_id'=>$receiver['id'],'member_id'=>102,'business_key'=>'pricing-depth-'.$depth,'request_id'=>'pricing-depth-'.$depth,'amount'=>'100.00','fee_amount'=>'10.00','net_amount'=>'90.00','status'=>'closed','rule_json'=>Data::json($r)]);}
    $tooDeep=$rawNew;$tooDeep['rule_json']=Data::json(['reprices_order_id'=>$previous]);rpDeny(fn()=>PaymentService::assertReplacementChain($site,$tooDeep),'predecessor traversal has a hard twenty-link limit');
    $logs=$pricing->logs((int)$old['id']);rpCheck($logs['total']>=3&&$logs['data'][0]['detail']['replacement_order_id']==$next['id'],'administrator can read who/why/old-new amounts from this order logs');
    rpCheck((new PaymentService($admin))->adminOrders(['id'=>$next['id']])['total']===1,'related detail query filters exact order under finance scope');
    $pending=$makeCommission('unknown');$pendingFact=$receipt($pending,(int)PayDict::STATUS_ING);$blocked=$pricing->reprice((int)$pending['id'],$payload('unknown'));
    rpCheck(!$blocked['repriced']&&$blocked['replacement_id']===0&&$blocked['old_order']['status']==='unpaid','unknown provider outcome never creates a replacement');
    Db::name('pay')->where('out_trade_no',$pendingFact['out_trade_no'])->update(['status'=>PayDict::STATUS_CANCEL]);
    $recovered=$pricing->reprice((int)$pending['id'],['confirm'=>true,'resume'=>true]);rpCheck($recovered['repriced']&&$recovered['replacement_order']['amount']==='120.00','persisted original intent can continue after original closure is verified');
    $fail=$makeCommission('recovery');$beforeCount=Store::query('coop_order',$site)->count();
    Db::execute("CREATE TRIGGER pricing_insert_failure BEFORE INSERT ON lt_hsx_lead_coop_order FOR EACH ROW BEGIN IF NEW.request_id LIKE 'reprice_%' THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='synthetic replacement insertion failure'; END IF; END");
    $partial=$pricing->reprice((int)$fail['id'],$payload('recovery'));
    rpCheck(!$partial['repriced']&&$partial['old_order']['status']==='closed'&&$partial['old_order']['can_resume_reprice'],'replacement DB failure retains committed old closure and a recoverable intent');
    rpCheck(Store::query('coop_order',$site)->count()===$beforeCount&&Store::row('collaboration',$site,(int)$fail['lead_id'])['payment_order_id']==$fail['id'],'failed replacement creates no orphan trade or wrong lead link');
    Db::execute('DROP TRIGGER pricing_insert_failure');$resumed=$pricing->reprice((int)$fail['id'],['confirm'=>true,'resume'=>true]);
    rpCheck($resumed['repriced']&&Store::query('coop_order',$site)->count()===$beforeCount+1,'continuation creates exactly one replacement after DB recovery');
    Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    $racing=$makeCommission('gateway-paid');$racingFact=$receipt($racing,(int)PayDict::STATUS_ING);Db::name('pay')->where('out_trade_no',$racingFact['out_trade_no'])->update(['type'=>PayDict::WECHATPAY,'channel'=>'weapp']);
    $provider=new PricingSyntheticProvider([['status'=>OnlinePayDict::NOTPAY],['status'=>OnlinePayDict::SUCCESS]]);$countBeforeRace=Store::query('coop_order',$site)->count();
    $race=(new OrderPricingService($admin,static fn()=>$provider))->reprice((int)$racing['id'],$payload('gateway-paid'));
    rpCheck(!$race['repriced']&&$race['replacement_id']===0&&$race['old_order']['status']==='paid','provider SUCCESS during close wins repricing and retains original paid order');
    rpCheck((int)Db::name('pay')->where('out_trade_no',$racingFact['out_trade_no'])->value('status')===(int)PayDict::STATUS_FINISH&&Store::query('coop_order',$site)->count()===$countBeforeRace,'real framework success persists without rollback or replacement charge');
    rpCheck(Db::name('member_account_log')->where('related_id',$racing['id'])->where('from_type',PaymentService::INCOME_TYPE)->count()===1,'racing success invokes original payout hook exactly once');
    $gatewayClose=$makeCommission('gateway-closed');$gatewayFact=$receipt($gatewayClose,(int)PayDict::STATUS_ING);Db::name('pay')->where('out_trade_no',$gatewayFact['out_trade_no'])->update(['type'=>PayDict::WECHATPAY,'channel'=>'weapp']);
    $closedProvider=new PricingSyntheticProvider([['status'=>OnlinePayDict::NOTPAY],['status'=>OnlinePayDict::CLOSED]]);$gatewayReplacement=(new OrderPricingService($admin,static fn()=>$closedProvider))->reprice((int)$gatewayClose['id'],$payload('gateway-closed'));
    rpCheck($gatewayReplacement['repriced']&&$closedProvider->calls===['query','close','query'],'new trade requires definitive provider CLOSED evidence, not merely close=true');
    $paid=$makeCommission('paid');$paidFact=$receipt($paid,(int)PayDict::STATUS_FINISH);PaymentService::confirm($paidFact);$paidBefore=Store::row('coop_order',$site,(int)$paid['id']);
    rpDeny(fn()=>$pricing->reprice((int)$paid['id'],$payload('paid')),'confirmed paid order cannot be repriced');rpCheck(Store::row('coop_order',$site,(int)$paid['id'])===$paidBefore,'paid financial fact remains byte-for-byte unchanged');
    $late=$receipt($old,(int)PayDict::STATUS_FINISH);PaymentService::confirm($late);
    rpDeny(fn()=>$payments->assertPayable((int)$next['id']),'late original receipt blocks charging the replacement');
    rpDeny(fn()=>PaymentService::paymentInfo($site,(int)$next['id']),'framework payment-info also checks predecessor receipt');
    $beforeIncome=Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->count();$nextFact=$receipt($next,(int)PayDict::STATUS_FINISH);PaymentService::confirm($nextFact);PaymentService::confirm($nextFact);$review=Store::row('coop_order',$site,(int)$next['id']);
    rpCheck($review['status']==='paid'&&Data::decode($review['rule_json'])['requires_manual_review']==='replacement_receipt_conflict','a genuine second receipt is retained as paid/manual review, never rolled back');
    rpCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->count()===$beforeIncome,'conflicted receipt does not distribute duplicate publisher earnings');
    // Membership repricing is the same workflow but only service money changes.
    $definition=leadMembershipDefinition(702,2,2,false,['deposit_amount'=>'200.00','experience_purchase_enabled'=>true,'experience_unit_price'=>'1.00']);Db::name('member_level')->where('site_id',$site)->where('level_id',702)->update(['level_benefits'=>$definition['level_benefits']]);
    $membership=new EntityMembershipService($ctx);$quote=$membership->quote('ML702','month',true);$memberOld=$payments->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','buy_experience'=>true,'quote_token'=>$quote['quote_token'],'request_id'=>'pricing-membership-one']);
    $memberInput=['confirm'=>true,'request_id'=>'pricing-membership-change','service_amount'=>'20.00','reason'=>'本地合成服务费优惠'];$memberChanged=$pricing->reprice((int)$memberOld['id'],$memberInput);
    rpCheck($memberChanged['repriced']&&$memberChanged['replacement_order']['service_amount']==='20.00','membership service-fee adjustment creates a new usable trade');
    $memberNew=$memberChanged['replacement_order'];foreach(['deposit_amount','experience_amount','experience_quantity','credit_amount','period_start_at','period_end_at']as$field)rpCheck($memberNew[$field]===$memberOld[$field],'membership repricing preserves '.$field);
    rpCheck($memberNew['amount']===Rules::amount(2000+Rules::cents($memberOld['deposit_amount'])+Rules::cents($memberOld['experience_amount']))&&$memberNew['promotion_base_amount']==='20.00','membership payable is service plus unchanged deposit/experience, promotion uses only adjusted service');
    $payments->assertPayable((int)$memberNew['id']);rpCheck(true,'actual membership guard accepts the repriced immutable-source proof');
    $memberRetry=$pricing->reprice((int)$memberOld['id'],$memberInput);rpCheck($memberRetry['replacement_id']===$memberNew['id'],'membership retry is idempotent even though a new pending membership exists');
    $memberFact=$receipt($memberNew,(int)PayDict::STATUS_FINISH);PaymentService::confirm($memberFact);rpCheck($membership->summary()['active'],'matching synthetic adjusted receipt grants membership through normal callback');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'owned random localhost schema; actual order repricing orchestration and synthetic receipts only; no real gateway, payment or deployment','remote_calls'=>0],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine()."\n".$error->getTraceAsString()."\n");}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
