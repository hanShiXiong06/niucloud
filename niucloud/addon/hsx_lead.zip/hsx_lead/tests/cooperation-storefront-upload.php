<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external HTTP/network functions before isolated testing\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,StorefrontService,UploadService};
use addon\hsx_lead\app\support\Data;
use app\service\core\sys\CoreConfigService;
use core\exception\CommonException;
use think\facade\Db;

$checks=0;$pdo=null;$schema='';$failed=false;
function uploadCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function uploadReject(callable $call,string $label):void{try{$call();}catch(CommonException$error){uploadCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
    // The framework's documented driver extension is the only double. The
    // actual request/file validation, CoreUploadService, attachment creation,
    // plugin audit and profile transaction all run unchanged. No object put,
    // file move, remote fetch or output file write can occur in this driver.
    class StorefrontNoNetworkUpload extends \core\upload\BaseUpload
    {
        public static array $uploads=[];
        public static bool $blankLocalUrl=false;
        private static int $sequence=0;
        public function createFileName(string $key='',string $ext=''){return parent::createFileName('synthetic-'.++self::$sequence,'png');}
        public function upload(string $dir){$this->validate();self::$uploads[]=['type'=>$this->storage_type,'key'=>$this->getFullPath($dir),'source'=>$this->getRealPath()];return true;}
        public function getUrl(string $path=''){return self::$blankLocalUrl&&$this->storage_type==='local'?'':parent::getUrl($path);}
        public function fetch(string $url,?string $key){throw new RuntimeException('Remote fetch forbidden in this test');}
        public function base64(string $base64_data,?string $key=null){throw new RuntimeException('File creation forbidden in this test');}
        public function delete(string $file_name){throw new RuntimeException('File deletion forbidden in this test');}
        public function thumb(string $file_path,$thumb_type){throw new RuntimeException('Image processing forbidden in this test');}
    }
    $app->config->set(['drivers'=>['tencent'=>['driver'=>StorefrontNoNetworkUpload::class],'local'=>['driver'=>StorefrontNoNetworkUpload::class]]],'upload');
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['sys_attachment','pay','pay_refund']as$table){
        preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$matches);
        if(!$matches)throw new RuntimeException('Missing official fixture DDL: '.$table);
        $pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$matches[0]));
    }
    $beforeTables=Db::query('SHOW TABLES');
    $admin=new Context($site,1);$owner=new Context($site,0,101);$other=new Context($site,0,102);
    $settings=new ConfigService($admin);$config=$settings->get();$config['enabled']=true;$settings->save($config);
    $configs=new CoreConfigService();
    $storage=static function(string $type,string $domain='')use($configs,$site):void{
        $configs->setConfig($site,'STORAGE',['default'=>$type,'tencent'=>['domain'=>$domain]]);
        // A site's "local" storage delegates to the platform default.
        if($type==='local')$configs->setConfig(0,'STORAGE',['default'=>'local']);
    };
    $asset=dirname(__DIR__).'/resource/diy/tabbar/home.png';$assetHash=hash_file('sha256',$asset);$assetSize=filesize($asset);
    $file=static function()use($app,$asset):void{
        // Supply the real $_FILES-shaped input: this framework version reads
        // ['name'] before its UploadedFile instanceof branch. It constructs
        // the UploadedFile itself; the synthetic driver never calls move().
        $request=new \app\Request();$request->withFiles(['file'=>['name'=>'storefront-fixture.png','tmp_name'=>$asset,'type'=>'image/png','error'=>UPLOAD_ERR_OK,'size'=>filesize($asset)]]);
        $app->instance('request',$request);
    };
    $audit=static fn(string $entity):int=>(int)Data::query('audit',$site)->where('entity_type',$entity)->where('action','uploaded')->count();
    $row=static fn(int $id):array=>Db::name('sys_attachment')->where('site_id',$site)->where('att_id',$id)->find();
    $storage('tencent','https://cdn.example.invalid');$file();
    $cloud=(new UploadService($owner))->storefront();$cloudRow=$row($cloud['att_id']);
    uploadCheck(str_starts_with($cloud['path'],'https://cdn.example.invalid/upload/hsx_lead/'.$site.'/m101/'),'published client gets the absolute driver URL in path, not a local object key');
    uploadCheck($cloud['path']===$cloud['url']&&$cloud['path']===$cloudRow['url'],'display path is exactly the framework-registered URL');
    uploadCheck($cloud['storage_path']===$cloudRow['path']&&$cloud['storage_path']!==$cloud['path'],'canonical object key remains separately available');
    uploadCheck(str_ends_with($cloud['storage_path'],'_tencent.png')&&$cloudRow['storage_type']==='tencent','actual framework filename and attachment retain storage type');
    uploadCheck($audit(StorefrontService::UPLOAD_ENTITY)===1,'successful storefront upload creates one owned public-media audit');
    uploadCheck(Data::query('audit',$site)->where('entity_type',StorefrontService::UPLOAD_ENTITY)->where('entity_id',$cloud['att_id'])->where('operator_member_id',101)->count()===1,'upload audit proves the original authenticated member');
    uploadCheck(count(StorefrontNoNetworkUpload::$uploads)===1&&StorefrontNoNetworkUpload::$uploads[0]['key']===$cloud['storage_path'],'actual framework driver saw the same canonical object key');
    $input=['name'=>'Actual upload test shop','contact_name'=>'Test contact','mobile'=>'13900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic local address','storefront_image'=>$cloud['path']];
    $profile=(new PartnerService($owner))->saveProfile($input);$merchantId=(int)$profile['id'];
    uploadCheck($profile['storefront_image']===$cloud['path'],'upload display value can round-trip through the real profile save');
    $saved=(new CoreConfigService())->getConfigValue($site,'HSX_LEAD_STOREFRONT_'.$merchantId);
    uploadCheck($saved['image']===$cloud['storage_path'],'saving a returned cloud URL persists the canonical key only');
    uploadCheck((new StorefrontService($owner))->image($merchantId)===$cloud['url'],'saved profile resolves correct cloud URL without a new upload');
    $otherInput=array_replace($input,['mobile'=>'13900000102']);
    uploadReject(fn()=>(new PartnerService($other))->saveProfile($otherInput),'cloud URL from another member cannot be attached to a new merchant');
    uploadCheck(Data::query('merchant',$site)->where('member_id',102)->count()===0,'foreign photo onboarding rolls back the new merchant');
    $file();$private=(new UploadService($owner))->image();$privateRow=$row($private['att_id']);
    uploadCheck($private['path']===$privateRow['path']&&str_starts_with($private['path'],'upload/'),'private lead screenshot keeps its canonical path contract');
    uploadCheck($private['url']===$privateRow['url']&&!isset($private['storage_path']),'private attachment response shape is not repurposed as storefront display');
    uploadCheck($audit('cooperation_attachment')===1&&$audit(StorefrontService::UPLOAD_ENTITY)===1,'private upload creates only the original private audit');
    uploadReject(fn()=>(new PartnerService($owner))->saveProfile(array_replace($input,['storefront_image'=>$private['url']])),'private screenshot cloud URL cannot be used as public storefront');
    uploadCheck((new StorefrontService($owner))->image($merchantId)===$cloud['url'],'private attachment rejection preserves the existing real-upload photo');
    $storage('local');$file();$local=(new UploadService($owner))->storefront();$localRow=$row($local['att_id']);
    uploadCheck($local['path']===$local['storage_path']&&$localRow['storage_type']==='local'&&str_starts_with($local['path'],'upload/'),'local driver continues returning the canonical relative image');
    uploadCheck($local['url']===$localRow['url']&&$local['url']===$local['path'],'local framework registration and response remain consistent');
    uploadCheck((new PartnerService($owner))->saveProfile(array_replace($input,['storefront_image'=>$local['path']]))['storefront_image']===$local['path'],'local uploaded photo still saves and displays');
    StorefrontNoNetworkUpload::$blankLocalUrl=true;$file();$localBlank=(new UploadService($owner))->storefront();
    uploadCheck($localBlank['url']===''&&$localBlank['path']===$localBlank['storage_path'],'empty local URL safely falls back to the registered canonical path');
    uploadCheck((new PartnerService($owner))->saveProfile(array_replace($input,['storefront_image'=>$localBlank['path']]))['storefront_image']===$localBlank['path'],'blank local URL fallback is accepted by normal profile save');
    StorefrontNoNetworkUpload::$blankLocalUrl=false;
    foreach(['','javascript:bad','//untrusted.example.invalid','https://user:secret@example.invalid']as$badDomain){
        $storage('tencent',$badDomain);$file();$beforeAudit=$audit(StorefrontService::UPLOAD_ENTITY);$previous=(new StorefrontService($owner))->image($merchantId);
        uploadReject(fn()=>(new UploadService($owner))->storefront(),'misconfigured cloud domain cannot be reported as a successful storefront upload');
        uploadCheck($audit(StorefrontService::UPLOAD_ENTITY)===$beforeAudit,'bad cloud URL never creates a successful public-storefront upload audit');
        uploadCheck((new StorefrontService($owner))->image($merchantId)===$previous,'bad cloud upload leaves the original merchant image unchanged');
    }
    uploadCheck(hash_file('sha256',$asset)===$assetHash&&filesize($asset)===$assetSize,'source PNG is never moved, replaced or modified');
    uploadCheck(Db::query('SHOW TABLES')===$beforeTables,'upload flow adds no tables or application schema');
    echo 'PASS storefront actual upload: '.$checks." checks; real CoreUpload/attachment/audit/profile with synthetic no-network driver, random localhost schema, source PNG unchanged\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL storefront actual upload after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
