import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {validateMobileApiBase} from '../scripts/mobile-api-env.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++}
for(const value of [undefined,null,'','/api','api/','//api.example.test/api/','ftp://api.example.test/api/','http:\\evil.test/api','https://user:password@api.example.test/api/','https://api.example.test/api?token=x','https://api.example.test/api/#x','https://api.example.test/a b/']){assert.throws(()=>validateMobileApiBase('mp-weixin',value));checks++}
for(const value of ['https://api.example.test/api','https://api.example.test/index.php/api/','http://192.168.1.3:8080/api/'])check(validateMobileApiBase('mp-weixin',value).absolute,'valid explicit http(s) API roots remain usable without prescribing a provider domain')
for(const value of ['http://localhost/api/','http://127.0.0.1:8080/api/','http://[::1]/api/']){const result=validateMobileApiBase('mp-weixin',value);check(result.local&&result.warning.includes('仅适用于本机微信开发者工具'),'explicit localhost is marked simulator-only, not a working real-device release')}
check(validateMobileApiBase('mp-weixin','http://api.example.test/api/').warning.includes('HTTPS'),'HTTP remote builds have an explicit release limitation')
check(validateMobileApiBase('h5','/api').baseUrl==='/api'&&validateMobileApiBase('h5','').baseUrl==='','H5 retains same-origin relative API support')
const {loadEnv}=require('vite'),key='VITE_APP_BASE_URL',previous=process.env[key]
try{process.env[key]='https://override.example.test/api/';const env=loadEnv('production',path.resolve(plugin,'../../../uni-app'),key);check(env[key]===process.env[key],'the actual installed Vite loader honors an explicit shell override over production env files');check(validateMobileApiBase('mp-weixin',env[key]).baseUrl===process.env[key],'preflight and compiler receive the same effective API base')}
finally{if(previous===undefined)delete process.env[key];else process.env[key]=previous}
const script=fs.readFileSync(path.join(plugin,'scripts/build-mobile.mjs'),'utf8')
check(script.indexOf('validateMobileApiBase(platform, loadEnv(')<script.indexOf('fs.mkdirSync(area'),'invalid MP env is checked before any generated build area mutation')
check(script.includes('VITE_APP_BASE_URL: mobileApi.baseUrl'),'the checked value is passed explicitly to the real uni compiler')
console.log(`PASS ${checks} mobile build API checks; pure URL fixtures and actual Vite environment precedence only; no build, request, database or saved env writes.`)
