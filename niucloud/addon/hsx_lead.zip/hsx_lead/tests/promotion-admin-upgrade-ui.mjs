import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Execute the real canonical setup scripts. All identities, dialogs and transports are synthetic.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../admin/package.json'))
const Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc')
let checks = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
const read = name => fs.readFileSync(path.join(plugin, name), 'utf8')
function execute(source, deps = {}) {
    const module = { exports: {} }
    const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`, { Date, Math, Number, String, Set, Map, JSON, Promise, console })(key => {
        if (key in deps) return deps[key]
        if (key.endsWith('.vue')) return { default: {} }
        throw Error('Unexpected dependency ' + key)
    }, module, module.exports)
    return module.exports
}
function script(name, names) {
    const source = read(name), parsed = compiler.parse(source, { filename: name })
    check(parsed.errors.length === 0, name + ' parses')
    compiler.compileScript(parsed.descriptor, { id: 'promotion-admin-upgrade' })
    check(compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: name, id: 'promotion-admin-upgrade', compilerOptions: { expressionPlugins: ['typescript'] } }).errors.length === 0, name + ' template compiles')
    for (const style of parsed.descriptor.styles) check(compiler.compileStyle({ source: style.content, filename: name, id: 'promotion-admin-upgrade', scoped: style.scoped }).errors.length === 0, name + ' styles compile')
    return parsed.descriptor.scriptSetup.content + `\nexport {${names}}`
}
const apiCalls = [], request = Object.fromEntries(['get', 'put', 'post'].map(method => [method, async (url, data) => { apiCalls.push({ method, url, data }); return { data: {} } }]))
const api = execute(read('admin/api/promotion.ts'), { '@/utils/request': { default: request } })
await api.reviewPromotionProvider(7, { decision: 'reject', version: 3, reason: '请完善门店资料' })
await api.retryPromotionPayment(19)
check(apiCalls[0].method === 'post' && apiCalls[0].url === 'hsx_lead/promotion/providers/7/review' && apiCalls[0].data.version === 3, 'review sends the precise member endpoint and original version')
check(apiCalls[1].method === 'post' && apiCalls[1].url === 'hsx_lead/promotion/orders/19/retry' && Object.keys(apiCalls[1].data).length === 0, 'payment recovery uses the existing paid order, not client-created reward facts')

const business = execute(read('admin/composables/business.ts'))
const entity = execute(read('admin/composables/entity.ts'))
const definition = () => ({ key: 'purchase', name: '二手机', enabled: true, dimension: 'model', selection_mode: 'multiple', selection_limit: 3, commission_minimum: 0.01, fields: [], options: [] })
check(business.businessValidation([definition()]) === '', 'a positive one-cent business minimum is allowed instead of a hard-coded fifty yuan')
check(business.businessValidation([{ ...definition(), commission_minimum: 0 }]).includes('大于0'), 'zero is not a payable business minimum')
for (const amount of [NaN, -1, '', '1e3', '0.001', 100000000]) check(business.businessAmountCents(amount) === null, 'invalid or out-of-account-range amount is rejected: ' + String(amount))
const fee = business.cooperationFeePreview('50.00', '10.00', '9.90')
check(fee.valid && fee.fee === 9.9 && fee.net === 40.1 && Math.round((fee.fee + fee.net) * 100) === 5000, 'cooperation preview uses the minimum fee and conserves all fifty yuan')
check(business.cooperationFeePreview('0.01', '0', '0').valid, 'one-cent commission with no platform fee is valid')
check(!business.cooperationFeePreview('0.01', '99.99', '0').valid, 'whole-cent rounding cannot consume the publisher entire income')

const allPermissions = ['hsx_lead_promotion_providers', 'hsx_lead_promotion_providers_save', 'hsx_lead_promotion_provider_review', 'hsx_lead_promotion_config', 'hsx_lead_promotion_config_save', 'hsx_lead_promotion_rewards', 'hsx_lead_promotion_settle', 'hsx_lead_promotion_retry']
const user = Vue.reactive({ rules: [...allPermissions] }), calls = [], messages = []
let dialogWork = async () => {}, providerReadWork = async () => ({ data: { data: [], total: 0 } })
let reviewWork, manualWork, configWork, retryWork, rewardReadWork = async () => ({ data: { data: [], total: 0, payment_reviews: { data: [], total: 0 } } })
const clone = data => JSON.parse(JSON.stringify(data))
const rules = () => ({ enabled: true, settlement_days: 3, eligibility_months: 0, sources: Object.fromEntries(['membership', 'maintenance'].map(key => [key, { enabled: true, normal_rate: '5.00', provider_rate: '10.00', renewal: key === 'maintenance' }])) })
const applicant = (status = 'pending', version = 3) => ({ member_id: 7, name: '合成会员', mobile_masked: '188****0001', merchant_name: '合成门店', city: '石家庄市', enabled: status === 'approved', role: status === 'approved' ? 'provider' : 'normal', application: { status, version, status_label: '合成状态', city: '石家庄市', merchant_name: '合成门店', contact_name: '合成人', mobile_masked: '188****0001', submitted_at: 1793836800, reviewed_at: 0, reason: '', disabled_mode: 'normal' }, provider: { status, version }, promotion_allowed: true })
const updated = (status, version = 4, disabled_mode = 'normal') => { const row = applicant(status, version); row.application.disabled_mode = disabled_mode; row.promotion_allowed = disabled_mode !== 'blocked'; return row }
reviewWork = async (id, data) => ({ data: updated(data.decision === 'approve' ? 'approved' : 'rejected', data.version + 1) })
manualWork = async (id, data) => ({ data: updated(data.status, data.version + 1, data.disabled_mode) })
configWork = async data => ({ data })
retryWork = async id => ({ data: { order_id: id, status: 'paid', promotion_review_required: false, reward_created: true } })
const deps = {
    vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} },
    'element-plus': { ElMessage: { success: value => messages.push(value), warning: value => messages.push(value) }, ElMessageBox: { confirm: (...args) => { calls.push({ type: 'dialog', args }); return dialogWork(...args) } } },
    '@element-plus/icons-vue': { Refresh: {}, Plus: {} }, '@/stores/modules/user': { default: () => user },
    '../../composables/navigation': { hasLeadPagePermission: (actor, key) => actor.rules.includes(key) },
    '../../composables/cooperation': { coopError: (cause, fallback) => cause?.msg || cause?.message || fallback, coopMoney: value => Number(value).toFixed(2), coopTime: value => value || '-' },
    '../../api/promotion': {
        getPromotionProviders: async data => { calls.push({ type: 'providers', data: clone(data) }); return providerReadWork(data) },
        reviewPromotionProvider: async (id, data) => { calls.push({ type: 'review', id, data: clone(data) }); return reviewWork(id, data) },
        savePromotionProvider: async (id, data) => { calls.push({ type: 'manual', id, data: clone(data) }); return manualWork(id, data) },
        getPromotionConfig: async () => ({ data: rules() }), savePromotionConfig: async data => { calls.push({ type: 'config', data: clone(data) }); return configWork(data) },
        getPromotionRewards: async data => rewardReadWork(data), retryPromotionPayment: async id => { calls.push({ type: 'retry', id }); return retryWork(id) }
    }
}
const state = execute(script('admin/views/promotion/index.vue', 'editProvider,reviewProvider,saveProvider,providerForm,providerMode,providerVisible,providerSaving,providerSaveError,providerReadRequired,selectedProvider,loadConfig,saveRules,config,configReady,configError,sourceRows,trialRows,trialError,trialSource,trialAmounts,showPendingProviders,providerQuery,loadRewards,paymentReviews,paymentReviewTotal,retryPayment,retryReadRequired,retrying,canRetry'), deps)
await state.showPendingProviders()
check(calls.at(-1).type === 'providers' && calls.at(-1).data.application_status === 'pending' && calls.at(-1).data.page === 1 && calls.at(-1).data.role === '', 'one-click pending filter resets page and does not retain a conflicting role filter')
state.editProvider(applicant())
const beforeReject = calls.length
await state.reviewProvider('reject')
check(calls.length === beforeReject && state.providerSaveError.value.includes('拒绝原因'), 'rejecting an application requires a visible human reason before any dialog or mutation')
let releaseDialog
dialogWork = () => new Promise(resolve => { releaseDialog = resolve })
const approval = state.reviewProvider('approve')
await state.reviewProvider('approve')
check(state.providerSaving.value && calls.filter(item => item.type === 'review').length === 0, 'review submit lock spans the confirmation dialog and blocks repeated clicks')
releaseDialog(); await approval
check(calls.filter(item => item.type === 'review').length === 1 && calls.find(item => item.type === 'review').data.version === 3, 'approval submits exactly once with the original server version')
check(!state.providerVisible.value && !state.providerSaving.value && state.selectedProvider.value.application.status === 'approved', 'only persisted expected status, role and incremented version complete approval')
dialogWork = async () => {}
state.editProvider(applicant('pending', 6)); state.providerForm.reason = '请核实门店联系人'
reviewWork = async () => { throw Error('申请已被其他管理员处理，请刷新') }
await state.reviewProvider('reject')
check(state.providerVisible.value && state.providerForm.reason === '请核实门店联系人' && state.providerReadRequired.value && state.providerSaveError.value.includes('其他管理员'), 'concurrent review failure keeps the draft and drawer open, requiring a read instead of blind resubmission')
const reviewCount = calls.filter(item => item.type === 'review').length
await state.reviewProvider('reject')
check(calls.filter(item => item.type === 'review').length === reviewCount, 'unknown/stale review result is not submitted again before rereading')
state.editProvider(applicant()); state.providerForm.reason = '合成拒绝原因'
reviewWork = async () => ({ data: updated('rejected', 3) })
const noticesBefore = messages.length; await state.reviewProvider('reject')
check(messages.length === noticesBefore && state.providerReadRequired.value && state.providerSaveError.value.includes('未完整返回'), 'an unchanged version response cannot masquerade as successful rejection')
user.rules = ['hsx_lead_promotion_providers']; state.editProvider(applicant())
const readsOnlyCount = calls.length; await state.reviewProvider('approve')
check(calls.length === readsOnlyCount, 'a read-only provider grant does not authorize approval')
user.rules = [...allPermissions]
state.editProvider(applicant('none', 0)); delete state.selectedProvider.value.application.version
await state.reviewProvider('approve')
state.providerMode.value = 'manual'; state.providerForm.reason = '人工开通'
state.providerForm.status = 'approved'; await state.saveProvider()
check(state.providerReadRequired.value && state.providerSaveError.value.includes('版本'), 'missing server version cannot be invented by the administrator UI')
state.editProvider(applicant('pending', 8)); state.providerMode.value = 'manual'; state.providerForm.reason = '不允许绕过待审'
const manualBefore = calls.filter(item => item.type === 'manual').length; await state.saveProvider()
check(calls.filter(item => item.type === 'manual').length === manualBefore, 'pending applications cannot bypass review through the manual save action')
for (const mode of ['normal', 'blocked']) {
    state.editProvider(applicant('approved', 11)); state.providerMode.value = 'manual'
    Object.assign(state.providerForm, { status: 'disabled', disabled_mode: mode, reason: '合成停用核实', remark: '仅后台可见' })
    await state.saveProvider()
    const write = calls.filter(item => item.type === 'manual').at(-1)
    check(write.data.version === 11 && write.data.disabled_mode === mode && write.data.reason === '合成停用核实' && !('enabled' in write.data), 'manual disable explicitly persists ' + mode + ' rather than an ambiguous switch')
    check(!state.providerVisible.value && state.selectedProvider.value.application.disabled_mode === mode, 'manual result verifies the persisted disable mode ' + mode)
}
await state.loadConfig(); state.trialSource.value = 'maintenance'; state.trialAmounts.maintenance = 9.9
const originalTableRows = state.sourceRows.value
state.config.sources.membership.normal_rate = 10
const normalTableRows = state.sourceRows.value
state.config.sources.membership.provider_rate = 30
const providerTableRows = state.sourceRows.value
check(normalTableRows !== originalTableRows && normalTableRows[0].normal_rate === 10, 'ordinary rate edits change the actual table data, not only the outer preview model')
check(providerTableRows !== normalTableRows && providerTableRows[0].provider_rate === 30 && providerTableRows[0].normal_rate === 10, 'provider rate edits replace the row snapshot while retaining the independently edited ordinary rate')
state.config.sources.membership.enabled = false
state.config.sources.membership.renewal = true
check(state.sourceRows.value[0].enabled === false && state.sourceRows.value[0].renewal === true && state.sourceRows.value[0].key === 'membership', 'table controls and current membership source identity receive the same enabled and renewal facts as the form model')
const promotionTemplate = read('admin/views/promotion/index.vue')
check(promotionTemplate.includes(':model-value="row.normal_rate"') && promotionTemplate.includes(':model-value="row.provider_rate"') && promotionTemplate.includes('@update:model-value="config.sources[row.key].normal_rate=$event"') && promotionTemplate.includes('@update:model-value="config.sources[row.key].provider_rate=$event"'), 'both controlled inputs read changing row props and explicitly write back to the sole config source')
const rows = state.trialRows.value
check(rows[0].reward === 0.49 && rows[1].reward === 0.99, 'normal and provider promotion use distinct rates and floor to whole cents')
for (const row of rows) check(Math.round((row.reward + row.retained) * 100) === 990, 'each identity independently conserves the platform fee base, not the whole collaboration commission')
check(rows[1].reward !== rows[0].reward + 0.99, 'normal and provider tiers are alternatives, never stacked')
state.config.sources.maintenance.normal_rate = 101
check(state.trialError.value.includes('0—100'), 'invalid percentage has an explicit trial error instead of fabricated zero')
const configCount = calls.filter(item => item.type === 'config').length; await state.saveRules()
check(calls.filter(item => item.type === 'config').length === configCount, 'invalid tier percentage cannot be saved')
state.config.sources.maintenance.normal_rate = 5; await state.saveRules()
const savedRule = calls.filter(item => item.type === 'config').at(-1).data.sources.maintenance
check(savedRule.normal_rate === '5.00' && savedRule.provider_rate === '10.00' && !('rate' in savedRule), 'save serializes the two explicit tiers without a redundant rate alias or changing historical records')
state.config.enabled = false
check(state.trialRows.value.every(row => row.reward === 0 && row.retained === 9.9), 'disabled promotion produces no hypothetical new reward while preserving the full base')

const payment = { id: 19, order_no: 'SYNTHETIC-19', purpose: 'commission', amount: '50.00', can_retry: true, message: '原推广记录待核对' }
rewardReadWork = async () => ({ data: { data: [], total: 0, payment_reviews: { data: [payment], total: 13 } } })
await state.loadRewards()
check(state.paymentReviewTotal.value === 13 && state.paymentReviews.value.length === 1, 'paid orders with no reward row still have their own visible recovery list and total')
user.rules = ['hsx_lead_promotion_retry']; const retryCount = calls.filter(item => item.type === 'retry').length
await state.retryPayment(payment)
check(!state.canRetry.value && calls.filter(item => item.type === 'retry').length === retryCount, 'recovery requires both retry and settlement permissions')
user.rules = [...allPermissions]; retryWork = async () => { throw Error('合成恢复结果待核对') }
await state.retryPayment(payment)
check(state.retryReadRequired.value && !state.retrying.value, 'unknown recovery outcome requires a read before retrying')
const failedRetryCount = calls.filter(item => item.type === 'retry').length; await state.retryPayment(payment)
check(calls.filter(item => item.type === 'retry').length === failedRetryCount, 'unknown paid-order recovery is not blindly repeated')
await state.loadRewards(); retryWork = async id => ({ data: { order_id: id, status: 'paid', promotion_review_required: false, reward_created: true } })
await state.retryPayment(payment)
check(messages.at(-1).includes('仍需按到期规则结算'), 'recovered reward is not falsely reported as credited or withdrawn')

const configSource = { enabled: true, publishing_required: true, fee_confirmed: true, commission_minimum: '1.00', fee_percent: '0.00', fee_minimum: '0.00', businesses: [{ ...definition(), commission_minimum: '1.00' }] }
let settingsWrite
const settings = execute(script('admin/views/cooperation/Settings.vue', 'form,ready,load,normalize,validation,save,preview,error'), { ...deps, '../../composables/business': business, '../../composables/entity': entity, '../../api/cooperation': { getCooperationConfig: async () => ({ data: clone(configSource) }), saveCooperationConfig: async data => { settingsWrite = clone(data); return { data } } } })
await settings.load()
check(settings.validation() === '' && !('publishing_price' in settings.form), 'business settings no longer own a second subscription price catalogue')
settings.form.commission_minimum = 1.2; await settings.save()
check(settingsWrite.commission_minimum === '1.20' && !('membership_levels' in settingsWrite), 'business fees save independently from framework membership configuration')
settings.form.fee_minimum = -1
check(settings.validation().includes('有效非负金额'), 'negative platform minimum cannot be silently clamped to zero')
settings.form.fee_minimum = 1.2
check(settings.validation().includes('小于通用最低佣金'), 'a platform floor equal to the full commission is blocked before save')
const membershipSettings = read('admin/views/cooperation/Settings.vue')
check(membershipSettings.includes('发单与接单需有效主体会员') && !membershipSettings.includes('原业务规则') && membershipSettings.includes('未开通或到期仍可完善资料'), 'framework subject membership is prominent, obsolete tiers are removed, and existing obligations remain available')
check(read('admin/views/cooperation/Orders.vue').includes('value="membership"') && !Object.keys(settingsWrite).some(key => /publishing_price|certification_price|registration_fee|receiving_fee|accepting_fee/.test(key)), 'only framework membership and commissions are presented without duplicate registration charges')

// Actual installed Element Plus InputNumber and Input mounted with Vue's renderer.
// The tiny host only supplies native element methods; this is not a browser visual test.
// A fill-style input->blur shortcut omits native change and is not equivalent to keyboard input.
const { ElInputNumber, ID_INJECTION_KEY } = require('element-plus')
const previousFocusEvent = globalThis.FocusEvent
if (!previousFocusEvent) globalThis.FocusEvent = class FocusEvent extends Event {}
const nativeNode = (tag, text = '') => ({ tag, text, children: [], props: {}, parent: null, value: '',
    setAttribute(key, value) { this.props[key] = value }, removeAttribute(key) { delete this.props[key] },
    addEventListener() {}, removeEventListener() {}, contains() { return false }, focus() {}, blur() {} })
const renderer = Vue.createRenderer({
    createElement: tag => nativeNode(tag), createText: text => nativeNode('#text', text), createComment: text => nativeNode('#comment', text),
    insert(node, parent, anchor) { if (node.parent) { const old = node.parent.children.indexOf(node); if (old >= 0) node.parent.children.splice(old, 1) }; node.parent = parent; const index = anchor ? parent.children.indexOf(anchor) : -1; if (index < 0) parent.children.push(node); else parent.children.splice(index, 0, node) },
    remove(node) { if (node.parent) { const index = node.parent.children.indexOf(node); if (index >= 0) node.parent.children.splice(index, 1) } },
    setText(node, value) { node.text = value }, setElementText(node, value) { node.text = value; node.children = [] },
    patchProp(node, key, _old, value) { node.props[key] = value; if (key === 'value') node.value = value },
    parentNode: node => node.parent, nextSibling: node => node.parent?.children[node.parent.children.indexOf(node) + 1] || null
})
const mountedValues = Vue.reactive({ normal_rate: 0, provider_rate: 0 })
const controls = Vue.defineComponent({ setup: () => () => Vue.h('div', ['normal_rate', 'provider_rate'].map(field => Vue.h(ElInputNumber, {
    modelValue: mountedValues[field], 'onUpdate:modelValue': value => { mountedValues[field] = value }, min: 0, max: 100, precision: 2, controls: false
}))) })
const mountedApp = renderer.createApp(controls), nativeTree = nativeNode('root')
mountedApp.provide(ID_INJECTION_KEY, { prefix: 1, current: 0 }); mountedApp.config.warnHandler = () => {}
const flatten = node => [node, ...node.children.flatMap(flatten)]
try {
    mountedApp.mount(nativeTree); await Vue.nextTick()
    const inputs = flatten(nativeTree).filter(node => node.tag === 'input')
    check(inputs.length === 2 && inputs.every(input => input.value === '0.00'), 'both actual installed numeric controls mount with the configured precision')
    // Input-only automation updates the model but does not commit the native change phase.
    inputs[0].value = '9'; await inputs[0].props.onInput({ target: inputs[0] }); await Vue.nextTick()
    inputs[0].props.onBlur(new FocusEvent('blur')); await Vue.nextTick()
    check(mountedValues.normal_rate === 9, 'input-only automation changes the draft model and must not alone be treated as committed keyboard acceptance')
    for (const [index, field, value] of [[0, 'normal_rate', 10], [1, 'provider_rate', 30]]) {
        const input = inputs[index]
        input.value = String(value); await input.props.onInput({ target: input }); await Vue.nextTick()
        input.props.onChange({ target: input }); await Vue.nextTick()
        input.props.onBlur(new FocusEvent('blur')); await Vue.nextTick()
        check(mountedValues[field] === value && input.value === value.toFixed(2) && input.props['aria-valuenow'] === String(value), 'native input->change->blur retains model, display and accessibility value for ' + field)
    }
} finally {
    mountedApp.unmount()
    if (!previousFocusEvent) delete globalThis.FocusEvent
}
console.log(`PASS ${checks} promotion/admin upgrade checks; actual SFC/setup/helper/API execution with synthetic responses only, no database or network mutations.`)
