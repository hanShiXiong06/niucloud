import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

// Real panel/ElementPlus/HsxTable, synthetic virtual transports. No tenant credentials or real sends.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..'),admin=path.join(workspace,'admin')
const require=createRequire(path.join(admin,'package.json')),{createServer}=require('vite'),vue=require('@vitejs/plugin-vue').default
const {chromium}=createRequire('/tmp/package.json')('playwright'),output=path.join(workspace,'output/hsx-lead-notice-20261109')
fs.mkdirSync(output,{recursive:true})
const importFile=file=>JSON.stringify('/@fs/'+path.join(plugin,file))
const states=['rejected','accepted','uncertain','submitted','disabled','pending_configuration','pending_recipient','dispatching']
const items=Array.from({length:24},(_,i)=>({id:901+i,channel:i===8?'sms':i%2?'wechat':'weapp',status:states[i%8],recipient_member_id:i%2?7:8,recipient_label:'合成门店 · '+(i%2?'虚构王五':'虚构李四'),event_action:'assigned',phase:'changed',notice_key:'hsx_lead_cooperation_changed',template_id:'SYNTHETIC_TEMPLATE',provider_code:i%8===0?'43101':i%8===1?'0':'',message:i%8===0?'接收用户未订阅，请用户重新订阅后再试':i%8===1?'服务商已受理，不代表用户已查看':'仅本地合成数据',retry_count:0,can_retry:[0,4,5,6].includes(i%8),retry_block_reason:[2,3,7].includes(i%8)?'结果未核实，不能重复发送':'',create_time:1794182400+i,update_time:1794182400+i}))
const api=`
const items=${JSON.stringify(items)}
window.__hsxNoticeFixture={reads:[],writes:[]}
export async function getCooperationNotices(id,q){
 window.__hsxNoticeFixture.reads.push({id,...q})
 const rows=items.filter(r=>(!q.recipient||r.recipient_label.includes(q.recipient))&&(!q.channel||r.channel===q.channel)&&(!q.status||r.status===q.status))
 return{data:{data:rows.slice((q.page-1)*q.limit,q.page*q.limit).map(r=>({...r})),total:rows.length,current_page:q.page,per_page:q.limit}}
}
export async function retryCooperationNotice(id,noticeId,data){
 window.__hsxNoticeFixture.writes.push({id,noticeId,...data})
 const row=items.find(r=>r.id===noticeId);Object.assign(row,{status:'accepted',can_retry:false,provider_code:'0',message:'服务商已受理，不代表用户已查看',retry_count:row.retry_count+1})
 return{data:{...row}}
}`
const mocks={
 'virtual:hsx-notice-api':api,
 'virtual:hsx-notice-store':"const user={siteInfo:{site_id:100005},token:'synthetic-only',rules:['hsx_lead_cooperation_notice_list','hsx_lead_cooperation_notice_retry']};export default()=>user",
 'virtual:hsx-notice-permission':"export const hasLeadPagePermission=(u,k)=>u.rules.includes(k)",
 'virtual:hsx-notice-format':"export const coopError=(e,f)=>e?.message||f;export const coopTime=t=>new Date(Number(t)*1000).toLocaleString('zh-CN',{hour12:false})"
}
const entry=`
import{createApp,h}from'vue'
import ElementPlus from'element-plus'
import zhCn from'element-plus/es/locale/lang/zh-cn'
import'element-plus/dist/index.css'
import ${importFile('../hsx_components/admin/styles/theme.scss')}
import ${importFile('admin/views/components/lead.css')}
import ${importFile('admin/views/cooperation/cooperation.css')}
import NoticeDeliveryPanel from ${importFile('admin/views/cooperation/NoticeDeliveryPanel.vue')}
createApp({render:()=>h('main',{class:'preview'},[h('h2','线索通知记录'),h('p',{class:'preview-label'},'本地合成数据验收 · 不连接真实账户'),h(NoticeDeliveryPanel,{leadId:21,active:true})])}).use(ElementPlus,{locale:zhCn}).mount('#app')
`
const virtual='virtual:hsx-notice-preview',resolved='\0'+virtual
const fixture={name:'hsx-notice-safe-preview',enforce:'pre',
 resolveId(id,importer){if(id===virtual)return resolved;if(id in mocks)return'\0'+id;if(importer?.includes('NoticeDeliveryPanel.vue')){const match=id.includes('/stores/modules/user')?'store':{'../../api/cooperation':'api','@/stores/modules/user':'store','../../composables/navigation':'permission','../../composables/cooperation':'format'}[id];if(match)return'\0virtual:hsx-notice-'+match}},
 load(id){if(id===resolved)return entry;if(id.startsWith('\0virtual:hsx-notice-'))return mocks[id.slice(1)]},
 configureServer(server){server.middlewares.use((req,res,next)=>{if(req.url!=='/')return next();res.setHeader('Content-Type','text/html;charset=utf-8');res.end('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>通知记录验收</title><style>body{margin:0;background:#f4f6f8;color:#303133;font-family:Arial,"PingFang SC",sans-serif}.preview{margin:20px auto;padding:22px 24px;max-width:1040px;box-sizing:border-box;background:white;border:1px solid #ebeef5;border-radius:10px}.preview h2{font-size:18px;margin:0 0 8px}.preview-label{font-size:12px;color:#909399;margin:0 0 20px}@media(max-width:760px){.preview{margin:10px;padding:16px}}</style></head><body><div id="app"></div><script type="module" src="/@id/'+virtual+'"></script></body></html>')})}}
const server=await createServer({configFile:false,root:admin,plugins:[fixture,vue()],css:{postcss:{plugins:[]}},resolve:{dedupe:['vue'],alias:[{find:'@/stores/modules/user',replacement:'virtual:hsx-notice-store'},{find:'@',replacement:path.join(admin,'src')},{find:'vue',replacement:path.join(admin,'node_modules/vue/dist/vue.runtime.esm-bundler.js')}]},optimizeDeps:{entries:[],include:['vue','element-plus']},server:{host:'127.0.0.1',port:0,strictPort:true,hmr:false,fs:{allow:[workspace]}}})
let browser,activePage
const errors=[],blocked=[],checks=[]
try{
 await server.listen();const origin='http://127.0.0.1:'+server.httpServer.address().port
 browser=await chromium.launch({headless:true,executablePath:process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disable-component-update','--no-first-run']})
 const context=await browser.newContext({viewport:{width:1100,height:820},deviceScaleFactor:1,reducedMotion:'reduce'})
 await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/')||url.startsWith('data:'))return route.continue();blocked.push(url);return route.abort('blockedbyclient')})
 const page=await context.newPage();activePage=page;page.on('pageerror',error=>errors.push(error.message))
 await page.goto(origin,{waitUntil:'networkidle',timeout:60000})
 const table=page.locator('.el-table'),rows=table.locator('.el-table__body-wrapper tbody tr')
 await rows.first().waitFor();assert.equal(await rows.count(),20);assert.ok(await page.getByText('共 24 条',{exact:true}).isVisible());checks.push('真实表格展示服务端20/24条')
 const initial=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth}))
 assert.ok(initial.document<=initial.viewport);checks.push('桌面表格内容在内部滚动，无文档溢出')
 await page.screenshot({path:path.join(output,'notification-panel-1100.png'),fullPage:false})
 await table.locator('.el-table__body-wrapper .el-scrollbar__wrap').evaluate(node=>{node.scrollLeft=node.scrollWidth})
 await page.screenshot({path:path.join(output,'notification-results-1100.png'),fullPage:false})
 await table.locator('.el-table__body-wrapper .el-scrollbar__wrap').evaluate(node=>{node.scrollLeft=0})
 await page.getByPlaceholder('姓名、会员编号或会员 ID').fill('虚构王五');await page.getByRole('button',{name:'查询',exact:true}).click()
 await page.getByText('共 12 条',{exact:true}).waitFor();assert.equal(await rows.count(),12);checks.push('输入接收人并查询立即刷新数据')
 await page.getByRole('button',{name:'重置',exact:true}).click()
 await rows.filter({hasText:'渠道明确拒绝'}).first().getByRole('button',{name:'重新检查并发送',exact:true}).click()
 const dialog=page.getByRole('dialog',{name:'重新检查并发送通知'});await dialog.waitFor()
 await dialog.getByPlaceholder('请说明本次重新检查并发送的原因').fill('合成渠道配置已核对');assert.equal(await page.evaluate(()=>window.__hsxNoticeFixture.writes.length),0)
 await dialog.getByText('已核对通知对象，确认重新检查并发送',{exact:true}).click();assert.equal(await dialog.getByRole('checkbox').isChecked(),true);await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));await page.screenshot({path:path.join(output,'notification-retry-confirm-1100.png'),fullPage:false})
 await dialog.getByRole('button',{name:'重新检查并发送',exact:true}).click();await dialog.waitFor({state:'hidden'})
 const writes=await page.evaluate(()=>window.__hsxNoticeFixture.writes);assert.equal(writes.length,1);assert.equal(writes[0].confirm,true);assert.equal(writes[0].reason,'合成渠道配置已核对');checks.push('复查需原因与主动确认，仅调用一次合成发送')
 assert.equal(await rows.filter({hasText:'结果待核实'}).first().getByRole('button',{name:'重新检查并发送',exact:true}).count(),0);checks.push('未知结果无重发入口')
 await rows.filter({hasText:'短信'}).first().getByRole('button',{name:'重新检查并发送',exact:true}).click();await dialog.waitFor()
 assert.ok(await dialog.getByText('短信提交后可能计费，请确认接收人和发送原因。',{exact:true}).isVisible())
 await dialog.getByRole('button',{name:'取消',exact:true}).click();await dialog.waitFor({state:'hidden'});assert.equal(await page.evaluate(()=>window.__hsxNoticeFixture.writes.length),1);checks.push('短信提示计费，取消不发送')
 await page.setViewportSize({width:760,height:820});const narrow=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth}))
 assert.ok(narrow.document<=narrow.viewport);checks.push('窄屏筛选换行，无文档横向溢出')
 await page.screenshot({path:path.join(output,'notification-panel-760.png'),fullPage:false})
 assert.deepEqual(errors,[]);assert.deepEqual(blocked,[])
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify({passed:true,checks,errors,blocked,initial,narrow,scope:'Real NoticeDeliveryPanel/ElementPlus/HsxTable with synthetic virtual transports; no backend/DB/real sends'},null,2))
 console.log(JSON.stringify({passed:true,checks,output,errors,blocked}))
}catch(error){console.error(JSON.stringify({errors,blocked,body:activePage?await activePage.locator('body').innerText():''}));throw error}finally{await browser?.close();await server.close()}
