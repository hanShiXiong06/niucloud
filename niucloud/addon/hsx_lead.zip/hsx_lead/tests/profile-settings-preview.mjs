import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

// Actual settings + ElementPlus + HsxDrawer, synthetic in-memory transport only.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..'),admin=path.join(workspace,'admin')
const require=createRequire(path.join(admin,'package.json')),{createServer}=require('vite'),vue=require('@vitejs/plugin-vue').default
const {chromium}=createRequire('/tmp/package.json')('playwright'),output=path.join(workspace,'output/hsx-lead-profile-20261109')
fs.mkdirSync(output,{recursive:true})
const importFile=file=>JSON.stringify('/@fs/'+path.join(plugin,file))
const initial={version:'synthetic-profile-v1',fields:{storefront_image:{visible:true,required:false,sort:10},business_license:{visible:true,required:true,sort:20}},extra_form:{enabled:false,form_id:0},forms:[{form_id:11,title:'经营补充资料',status:1,type:'DIY_FORM'},{form_id:12,title:'商户服务资料',status:1,type:'DIY_FORM'}],configuration_error:''}
const mocks={
 'virtual:hsx-profile-api':`
const clone=x=>JSON.parse(JSON.stringify(x));let data=${JSON.stringify(initial)}
window.__hsxProfileFixture={reads:0,writes:[],mode:'ok',delay:0,version:()=>data.version}
export async function getProfileFormSettings(){const fixture=window.__hsxProfileFixture;fixture.reads++;const mode=fixture.mode;await new Promise(r=>setTimeout(r,fixture.delay));if(mode==='fail')throw Error('合成配置读取失败，请重新读取');return{data:clone(data)}}
export async function saveProfileFormSettings(input){const fixture=window.__hsxProfileFixture;fixture.writes.push(clone(input));if(input.expected_version!==data.version)throw Error('合成版本已变化');data={...data,...clone(input),version:'synthetic-profile-v2'};return{data:clone(data)}}`,
 'virtual:hsx-profile-store':"export default()=>({siteInfo:{site_id:100005},token:'synthetic-only'})",
 'virtual:hsx-profile-format':"export const coopError=(error,fallback)=>error?.message||fallback",
 'virtual:hsx-profile-router':"export const useRouter=()=>({push:route=>window.__hsxProfileRoute=route})"
}
const entry=`
import{createApp,h,ref}from'vue';import ElementPlus from'element-plus';import zhCn from'element-plus/es/locale/lang/zh-cn';import'element-plus/dist/index.css'
import ${importFile('../hsx_components/admin/styles/theme.scss')}
import ProfileFormSettings from ${importFile('admin/views/cooperation/ProfileFormSettings.vue')}
createApp({setup(){const open=ref(true);window.__openProfile=()=>open.value=true;return()=>h('main',{class:'preview'},[h('h2','门店资料表单验收'),h('p','本地合成数据 · 不连接业务后端'),h('button',{onClick:()=>open.value=true},'打开表单要求'),h(ProfileFormSettings,{modelValue:open.value,canEdit:true,'onUpdate:modelValue':value=>open.value=value})])}}).use(ElementPlus,{locale:zhCn}).mount('#app')`
const virtual='virtual:hsx-profile-preview',resolved='\0'+virtual
const fixture={name:'hsx-profile-offline-preview',enforce:'pre',resolveId(id,importer){
 if(id===virtual)return resolved;if(id in mocks)return'\0'+id
 if(importer?.includes('ProfileFormSettings.vue')){const type=id.includes('/stores/modules/user')?'store':{'../../api/cooperation':'api','../../composables/cooperation':'format','vue-router':'router'}[id];if(type)return'\0virtual:hsx-profile-'+type}
},load(id){if(id===resolved)return entry;if(id.startsWith('\0virtual:hsx-profile-'))return mocks[id.slice(1)]},configureServer(server){server.middlewares.use((req,res,next)=>{
 if(req.url!=='/')return next();res.setHeader('Content-Type','text/html;charset=utf-8');res.end('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>门店资料表单验收</title><style>body{margin:0;background:#f5f7fa;color:#303133;font-family:Arial,"PingFang SC",sans-serif}.preview{padding:24px}.preview h2{font-size:18px}.preview p{font-size:12px;color:#909399}</style></head><body><div id="app"></div><script type="module" src="/@id/'+virtual+'"></script></body></html>')
})}}
const server=await createServer({configFile:false,root:admin,plugins:[fixture,vue()],css:{postcss:{plugins:[]}},resolve:{dedupe:['vue'],alias:[{find:'@/stores/modules/user',replacement:'virtual:hsx-profile-store'},{find:'@',replacement:path.join(admin,'src')},{find:'vue',replacement:path.join(admin,'node_modules/vue/dist/vue.runtime.esm-bundler.js')}]},optimizeDeps:{entries:[],include:['vue','element-plus']},server:{host:'127.0.0.1',port:0,strictPort:true,hmr:false,fs:{allow:[workspace]}}})
let browser,activePage;const checks=[],errors=[],blocked=[],sizes=[]
try{
 await server.listen();const origin='http://127.0.0.1:'+server.httpServer.address().port
 browser=await chromium.launch({headless:true,executablePath:process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disable-component-update','--no-first-run']})
 const context=await browser.newContext({viewport:{width:1366,height:900},deviceScaleFactor:1,reducedMotion:'reduce'})
 await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/')&&!/\/(?:adminapi|api)\//.test(url)||url.startsWith('data:'))return route.continue();blocked.push(url);return route.abort('blockedbyclient')})
 const page=await context.newPage();activePage=page;page.on('pageerror',error=>errors.push(error.message))
 await page.goto(origin,{waitUntil:'networkidle',timeout:60000})
 const dialog=page.getByRole('dialog',{name:'门店资料表单'}),save=dialog.getByRole('button',{name:'保存表单要求',exact:true})
 await dialog.waitFor();await save.waitFor();await page.waitForFunction(()=>window.__hsxProfileFixture.reads===1)
 const license=dialog.locator('.el-table__row').filter({hasText:'营业执照'}),licenseSwitches=license.getByRole('switch')
 assert.equal(await licenseSwitches.nth(1).isChecked(),true)
 await license.locator('.el-switch').nth(0).click();assert.equal(await licenseSwitches.nth(1).isChecked(),false);assert.equal(await licenseSwitches.nth(1).isDisabled(),true)
 await license.locator('.el-switch').nth(0).click();assert.equal(await licenseSwitches.nth(1).isDisabled(),false);assert.equal(await licenseSwitches.nth(1).isChecked(),false)
 await license.locator('.el-switch').nth(1).click();checks.push('隐藏自动取消必填，恢复显示不会偷偷恢复必填')
 await dialog.locator('.el-form-item').filter({hasText:'启用万能表单'}).locator('.el-switch').click()
 assert.equal(await dialog.locator('.el-select').evaluate(node=>node.textContent.includes('搜索并选择本站万能表单')||[...node.querySelectorAll('input')].some(input=>input.getAttribute('placeholder')==='搜索并选择本站万能表单')),true);checks.push('未选表单显示搜索提示，不显示原始数值0')
 await dialog.locator('.el-select').click();await page.getByRole('option',{name:'经营补充资料',exact:true}).click();await page.locator('.el-select-dropdown:visible').waitFor({state:'hidden'});checks.push('启用后选择真实ElementPlus表单选项，未启用不显示选择器')
 for(const width of[1366,768]){
  await page.setViewportSize({width,height:900});await page.evaluate(()=>new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r))))
  const size=await dialog.evaluate(node=>{const body=node.querySelector('.el-drawer__body'),footer=node.querySelector('.el-drawer__footer');return{viewport:innerWidth,document:document.documentElement.scrollWidth,width:node.getBoundingClientRect().width,bodyWidth:body.clientWidth,bodyScrollWidth:body.scrollWidth,footerBottom:footer.getBoundingClientRect().bottom,viewportHeight:innerHeight}})
  assert.ok(size.document<=width&&size.width<=width&&size.bodyScrollWidth<=size.bodyWidth&&size.footerBottom<=size.viewportHeight+1);sizes.push(size)
  await page.screenshot({path:path.join(output,'profile-settings-'+width+'.png'),fullPage:false})
 }
 checks.push('1366与768宽度均无文档或抽屉横向溢出，底部保存按钮不被遮挡')
 await save.click();await page.waitForFunction(()=>window.__hsxProfileFixture.writes.length===1)
 const written=await page.evaluate(()=>window.__hsxProfileFixture.writes[0]);assert.equal(written.expected_version,'synthetic-profile-v1');assert.deepEqual(written.extra_form,{enabled:true,form_id:11});assert.equal(written.fields.business_license.required,true)
 await save.click();await page.waitForFunction(()=>window.__hsxProfileFixture.writes.length===2);assert.equal(await page.evaluate(()=>window.__hsxProfileFixture.writes[1].expected_version),'synthetic-profile-v2');checks.push('合成保存仅携带已读取版本，下一次使用保存回读的新版本')
 await page.waitForFunction(()=>document.querySelectorAll('.el-message').length===0)
 await dialog.getByRole('button',{name:'关闭',exact:true}).click();await dialog.waitFor({state:'hidden'})
 await page.evaluate(()=>{window.__hsxProfileFixture.mode='fail';window.__hsxProfileFixture.delay=450;window.__openProfile()});await dialog.waitFor()
 assert.equal(await save.isDisabled(),true);await dialog.locator('.el-loading-mask').waitFor();await page.screenshot({path:path.join(output,'profile-settings-loading-768.png'),fullPage:false});checks.push('读取时真实loading覆盖并禁止保存')
 await dialog.getByText('合成配置读取失败，请重新读取',{exact:true}).waitFor();assert.equal(await save.isDisabled(),true);assert.equal(await dialog.locator('.el-table').count(),0)
 await page.screenshot({path:path.join(output,'profile-settings-error-768.png'),fullPage:false});checks.push('读取失败展示重试，不以默认值覆盖后台配置')
 await page.evaluate(()=>{window.__hsxProfileFixture.mode='ok';window.__hsxProfileFixture.delay=0});await dialog.getByRole('button',{name:'重新读取',exact:true}).click();await license.waitFor();assert.equal(await save.isDisabled(),false);checks.push('重新读取后保留服务端配置并恢复可保存状态')
 assert.deepEqual(errors,[]);assert.deepEqual(blocked,[])
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify({passed:true,checks,errors,blocked,sizes,scope:'Actual ProfileFormSettings/ElementPlus/HsxDrawer, synthetic in-memory transport only; no production, API, DB or real saves'},null,2))
 console.log(JSON.stringify({passed:true,checks,output,errors,blocked}))
}catch(error){console.error(JSON.stringify({errors,blocked,body:activePage?await activePage.locator('body').innerText():''}));throw error}finally{await browser?.close();await server.close()}
