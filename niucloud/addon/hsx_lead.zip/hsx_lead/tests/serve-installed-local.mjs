import fs from 'node:fs'
import path from 'node:path'
import http from 'node:http'
import { fileURLToPath } from 'node:url'

// Local acceptance proxy, not an application route or payment simulator.
// It serves the installed H5 and forwards only to the user's localhost PHP.
const workspace = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../../../..')
const port = Number(process.env.HSX_ACCEPTANCE_PORT || 18896)
const source = path.resolve(workspace, process.env.HSX_ACCEPTANCE_H5 || 'niucloud/public/wap')
if (!Number.isInteger(port) || port < 18896 || port > 18899) throw Error('Use a reserved local acceptance port, 18896..18899')
if (!source.startsWith(workspace + path.sep) || !fs.existsSync(path.join(source, 'index.html'))) throw Error('A current local H5 build is required')
const allowedWrite = /^\/(?:api\/(?:hsx_lead\/cooperation\/(?:profile|storefront|attachments|leads(?:\/\d+\/(?:assign|action))?|orders)|pay(?:\/close)?|member\/log|logout))$/
const mime = { '.html':'text/html; charset=utf-8', '.js':'application/javascript', '.css':'text/css', '.png':'image/png', '.webp':'image/webp', '.jpg':'image/jpeg', '.svg':'image/svg+xml', '.woff':'font/woff', '.woff2':'font/woff2', '.ttf':'font/ttf', '.json':'application/json' }
const server = http.createServer((req, res) => {
  let pathname
  try { pathname = decodeURIComponent(new URL(req.url, 'http://127.0.0.1').pathname) } catch { return res.writeHead(400).end() }
  res.setHeader('Cache-Control','no-store')
  res.setHeader('Content-Security-Policy',"connect-src 'self'; img-src 'self' data: blob:; font-src 'self' data:; script-src 'self' 'unsafe-inline' 'unsafe-eval' blob:")
  if (pathname.startsWith('/api/')) {
    if (req.headers['site-id'] && req.headers['site-id'] !== '100005') return res.writeHead(403).end('Local acceptance is restricted to site 100005')
    if (!['GET','HEAD','OPTIONS'].includes(req.method) && !allowedWrite.test(pathname)) return res.writeHead(403).end('Write not in the local cooperation acceptance scope')
    const chunks=[]
    let length=0
    req.on('data',chunk=>{length+=chunk.length; if(length>4*1024*1024)req.destroy();else chunks.push(chunk)})
    req.on('end',()=>{
      const body=Buffer.concat(chunks)
      if(pathname==='/api/pay') {
        let type
        try { type=JSON.parse(body.toString('utf8')).type } catch { type=new URLSearchParams(body.toString('utf8')).get('type') }
        if(type!=='balancepay')return res.writeHead(403).end('Only local test-balance payment is permitted; no external payment provider')
      }
      const upstream=http.request({hostname:'127.0.0.1',port:80,path:req.url,method:req.method,headers:{...req.headers,host:'localhost'}}, response=>{
        const headers={...response.headers};delete headers['content-security-policy'];delete headers['cache-control'];
        res.writeHead(response.statusCode,headers);response.pipe(res)
      })
      upstream.setTimeout(15000,()=>upstream.destroy())
      upstream.on('error',()=>{if(!res.headersSent)res.writeHead(502);res.end('Local PHP service did not respond')})
      upstream.end(body)
    })
    return
  }
  let base=source, relative=pathname.replace(/^\/wap\/(?:100005\/)?/,'').replace(/^\//,'')
  if(pathname.startsWith('/addon/')||pathname.startsWith('/upload/')||pathname.startsWith('/static/')) {base=path.join(workspace,'niucloud/public');relative=pathname.slice(1)}
  let file=path.resolve(base,relative)
  if(file!==base&&!file.startsWith(base+path.sep))return res.writeHead(403).end()
  if(!fs.existsSync(file)||!fs.statSync(file).isFile()) {
    if(path.extname(pathname))return res.writeHead(404).end('Local asset not found')
    file=path.join(source,'index.html')
  }
  res.setHeader('Content-Type',mime[path.extname(file)]||'application/octet-stream')
  if(/^index[-.][\w-]+\.js$/.test(path.basename(file))) {
    // The framework's publish.cjs::solve adds this tenant-aware router base.
    // Reuse that published behavior in this local response without invoking its
    // destructive publish step or changing the isolated compiler artifact.
    let content=fs.readFileSync(file,'utf8')
    const first='const match = location.href.match(/\\/wap\\/(\\d*)\\//);'
    if(!content.includes(first)&&/router:\{[^}]*\},darkmode/s.test(content)) {
      content=first+content.replace(/router:\{(.*?)\},darkmode/s,'router:{mode:"history",base:match?`/wap/${match[1]}/`:"/wap/",assets:"assets",routerBase:match?`/wap/${match[1]}/`:"/wap/"},darkmode')
    }
    return res.end(content)
  }
  fs.createReadStream(file).pipe(res)
})
server.listen(port,'127.0.0.1',()=>console.log(JSON.stringify({url:`http://127.0.0.1:${port}/wap/100005/addon/hsx_lead/pages/profile/index`,source,api:'actual localhost PHP, no mocked responses',scope:'site 100005 only; separate browser storage origin; external UI requests blocked; only test-balance cashier submissions permitted'})))
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>process.exit(0)))
