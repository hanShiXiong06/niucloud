<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,Store,TeamService,EntityMembershipService,Rules,CooperationService,PaymentService};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function teamCheck(bool $ok,string $label):void {if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function teamDeny(callable $call,string $label):void {try{$call();}catch(CommonException $e){teamCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try {
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    leadMembershipSeed($site);
    $admin=new Context($site,1);$owner=new Context($site,0,101);$employee=new Context($site,0,102);
    foreach([104,105,106]as$id)Db::name('member')->insert(['site_id'=>$site,'member_id'=>$id,'nickname'=>'Test '.$id,'mobile'=>'19900000'.$id]);
    $config=ConfigService::defaults();$config['enabled']=true;(new ConfigService($admin))->save($config);
    $input=['name'=>'Test subject','contact_name'=>'Owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Test street'];
    $profile=(new PartnerService($owner))->saveProfile($input);$merchant=(int)$profile['id'];
    $team=new TeamService($owner);$summary=$team->summary();$code=$summary['subject_code'];
    teamCheck(strlen($code)===10&&$summary['membership']['used_accounts']===1,'owner is included, generated subject code is readable');
    teamCheck($team->summary()['subject_code']===$code,'subject code is stable across reads');
    $staff=new TeamService($employee);$lookup=$staff->lookup(strtolower($code));
    teamCheck(array_keys($lookup)===['merchant_id','name','can_join','join_message']&&!$lookup['can_join'],'lookup exposes only store name and seat availability, not phone, members, ERP or rights');
    teamDeny(fn()=>(new TeamService(new Context($site+1,0,103)))->lookup($code),'cross tenant subject code never resolves');
    teamDeny(fn()=>$staff->join(['subject_code'=>$code]),'ordinary one-account subject cannot add another account');
    // Seat tests explicitly configure a zero-threshold entry; growth is covered separately.
    leadSetEntryDefinition($site,702);$partner=Store::partner($site,$merchant);$paid=leadMembershipGrant($site,101,'ML702');
    $joined=$staff->join(['subject_code'=>$code]);teamCheck($joined['merchant_id']===0&&$joined['pending_entity']['merchant_id']===$merchant,'join creates pending application only');
    teamCheck((int)Db::name('member')->where('site_id',$site)->where('member_id',102)->value('pid')===0,'staff invitation never establishes a commission inviter relationship');
    teamDeny(fn()=>$employee->merchant(),'pending member cannot read subject business');
    $staff->join(['subject_code'=>$code]);teamCheck(Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('member_id',102)->count()===1,'retrying join does not duplicate application');
    teamDeny(fn()=>(new PartnerService($employee))->saveProfile(array_replace($input,['name'=>'Bad overwrite','mobile'=>'19900000102'])),'pending application cannot be bypassed by creating another subject');
    (new TeamService(new Context($site,0,104)))->join(['subject_code'=>$code]);
    $team->review(102,true);teamCheck($employee->merchant()['id']===$merchant,'approved member resolves to same subject');
    teamCheck($employee->merchant()['team_role']==='member','employee does not inherit owner role');
    teamDeny(fn()=>TeamService::assertOwner($employee),'employee cannot become responsible owner');
    teamDeny(fn()=>$staff->remove(101),'employee cannot remove the owner');
    teamDeny(fn()=>$employee->connectionMerchant($merchant),'employee cannot authorize or reconfigure ERP');
    teamDeny(fn()=>(new PartnerService($employee))->saveProfile(array_replace($input,['name'=>'Bad profile'])),'employee cannot edit shared storefront through profile API');
    $boot=(new PartnerService($employee))->bootstrap();
    teamCheck($boot['profile']['is_owner']===false&&$boot['wallet']===null,'employee bootstrap does not leak owner wallet');
    teamCheck($boot['profile']['membership']['level_code']==='ML702'&&$boot['profile']['membership']['used_accounts']===2,'employee sees shared level and total seats');
    teamDeny(fn()=>$team->review(104,true),'second approval rechecks seats atomically under the subject lock');
    teamCheck($team->summary()['pending_count']===1&&$team->summary()['membership']['used_accounts']===2,'failed approval leaves pending request and seat count intact');
    $team->review(104,false);teamCheck((new TeamService(new Context($site,0,104)))->summary()['pending_entity']===null,'rejection clears pending onboarding');
    $staff->leave();teamDeny(fn()=>$employee->merchant(),'leaving immediately revokes member business access');
    teamCheck($team->summary()['membership']['used_accounts']===1,'leaving releases a seat without deleting original member');
    (new TeamService(new Context($site,0,104)))->join(['subject_code'=>$code]);
    (new TeamService(new Context($site,0,104)))->leave();teamCheck($team->summary()['pending_count']===0,'applicant can cancel before owner approval');
    $staff->join(['subject_code'=>$code]);$team->review(102,true);$team->remove(102);teamDeny(fn()=>$employee->merchant(),'owner removal revokes access on next request without waiting for token expiry');
    teamDeny(fn()=>$team->remove(101),'owner account cannot be removed');teamDeny(fn()=>$team->leave(),'owner cannot abandon responsible subject');
    $staff->join(['subject_code'=>$code]);
    // A genuine expired grant cannot be replaced by a cached partner flag.
    // Closing a paid business while retaining a FINISH receipt is a financial
    // conflict, not expiry; that distinct case is covered by late-receipt tests.
    $expiredOrder=Store::row('coop_order',$site,(int)$paid['id']);$expiredRule=Data::decode($expiredOrder['rule_json']);$expiredStart=time()-70*86400;
    $expiredRule['quoted_at']=$expiredStart;$expiredRule['period_start_at']=$expiredStart;$expiredRule['period_end_at']=Rules::addMonths($expiredStart,(int)$expiredRule['months']);
    foreach(['quoted_period_start_at','quoted_period_end_at']as$key)if(isset($expiredRule[$key]))$expiredRule[$key]=$key==='quoted_period_start_at'?$expiredRule['period_start_at']:$expiredRule['period_end_at'];
    Store::query('coop_order',$site)->where('id',$paid['id'])->update(['rule_json'=>Data::json($expiredRule),'pay_time'=>$expiredStart]);
    Db::name('pay')->where('site_id',$site)->where('out_trade_no',$expiredOrder['out_trade_no'])->update(['pay_time'=>$expiredStart]);
    teamDeny(fn()=>$team->review(102,true),'expiry before approval prevents newly exceeding ordinary account limit');
    $team->review(102,false);
    Db::name('member_level')->where('site_id',$site)->where('level_id',704)->update(['level_benefits'=>leadMembershipDefinition(704,4,10,true)['level_benefits']]);leadSetEntryDefinition($site,704);leadMembershipGrant($site,101,'ML704');
    foreach([102,104,105,106]as$id){$ctx=new Context($site,0,$id);(new TeamService($ctx))->join(['subject_code'=>$code]);$team->review($id,true);}
    teamCheck($team->summary()['membership']['unlimited']&&$team->summary()['membership']['used_accounts']===5,'configured unlimited tier is not hardcoded to ten accounts');
    $listed=(new TeamService($admin))->adminList(['keyword'=>$code]);teamCheck($listed['total']===1&&$listed['data'][0]['subject_code']===$code,'admin can search subject code and see totals');
    $detail=(new TeamService($admin))->adminDetail($merchant);teamCheck(count($detail['members'])===5,'admin sees owner and staff separately');
    (new TeamService($admin))->adminRemove($merchant,106);teamDeny(fn()=>(new Context($site,0,106))->merchant(),'platform removal also revokes access');
    teamCheck((int)Db::name('member')->where('site_id',$site)->where('member_id',102)->value('member_level')===0,'framework personal level remains untouched');
    $config=(new ConfigService($admin))->get();$config['fee_confirmed']=true;$config['publishing_required']=false;(new ConfigService($admin))->save($config);
    $ownerWork=new CooperationService($owner);$employeeWork=new CooperationService($employee);$catalog=$ownerWork->catalog();
    $internal=$ownerWork->create(['request_id'=>'internal-staff-delivery','customer_name'=>'Internal customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$catalog[0]['id']],'attachments'=>[],'remark'=>'Internal fixture','consent'=>true]);
    $choices=$ownerWork->stores([],(int)$internal['id']);teamCheck((int)$choices['data'][0]['id']===$merchant&&$choices['data'][0]['is_internal']===true,'same subject is first with a server-owned internal-delivery mark');
    teamCheck(array_column($choices['data'][0]['internal_assignees'],'member_id')===[102,104,105],'candidate list contains actual valid colleagues, excluding self and removed staff');
    $staffChoices=$employeeWork->stores([],(int)$internal['id']);teamCheck(array_column($staffChoices['data'][0]['internal_assignees'],'member_id')===[101,104,105],'staff may choose owner or a colleague, but never their own account');
    Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->update(['status'=>'pending']);
    teamCheck(!in_array($merchant,array_map('intval',array_column($ownerWork->stores([],(int)$internal['id'])['data'],'id')),true),'purchased unlimited seats and pending links do not make a one-account store assignable');
    foreach([102,104,105]as$memberId)Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->where('member_id',$memberId)->update(['status'=>'active']);
    foreach([0,101,103,106,999]as$memberId)teamDeny(fn()=>$ownerWork->assign((int)$internal['id'],['merchant_id'=>$merchant,'assignee_member_id'=>$memberId,'assignment_version'=>0]),'API rejects missing, self, foreign, removed or unknown recipient '.$memberId);
    Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->where('member_id',104)->update(['status'=>'pending']);
    teamDeny(fn()=>$ownerWork->assign((int)$internal['id'],['merchant_id'=>$merchant,'assignee_member_id'=>104,'assignment_version'=>0]),'pending member cannot bypass selection by API');
    Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->where('member_id',104)->update(['status'=>'active']);
    Db::name('member')->where('site_id',$site)->where('member_id',105)->update(['status'=>0]);
    teamDeny(fn()=>$ownerWork->assign((int)$internal['id'],['merchant_id'=>$merchant,'assignee_member_id'=>105,'assignment_version'=>0]),'disabled account is never a recipient');
    Db::name('member')->where('site_id',$site)->where('member_id',105)->update(['status'=>1]);
    $ownerWork->assign((int)$internal['id'],['merchant_id'=>$merchant,'assignee_member_id'=>102,'assignment_version'=>0]);
    $assignment=Data::decode(Store::row('collaboration',$site,(int)$internal['id'])['rule_json']);teamCheck($assignment['internal_publisher_member_id']===101&&$assignment['internal_assignee_member_id']===102,'snapshot records publisher actor and selected colleague without changing financial rules');
    teamDeny(fn()=>$team->remove(102),'owner cannot remove selected colleague before assignment is returned');
    teamDeny(fn()=>$staff->leave(),'selected colleague cannot leave with a pending internal assignment');
    teamCheck($ownerWork->lists(['direction'=>'incoming'])['total']===0&&$employeeWork->lists(['direction'=>'incoming'])['total']===1,'incoming total and rows are person-scoped for new internal handoffs');
    teamCheck((new PartnerService($owner))->bootstrap()['stats']['assigned']===0&&(new PartnerService($employee))->bootstrap()['stats']['assigned']===1,'pending counters use the same person scope as pagination');
    teamCheck(!$ownerWork->detail((int)$internal['id'])['can_accept']&&$employeeWork->detail((int)$internal['id'])['can_accept'],'only selected colleague receives actionable UI state');
    teamDeny(fn()=>$ownerWork->action((int)$internal['id'],['action'=>'accept','assignment_version'=>1]),'publishing actor cannot accept their own handoff');
    teamDeny(fn()=>(new CooperationService(new Context($site,0,104)))->action((int)$internal['id'],['action'=>'reject','assignment_version'=>1]),'unselected colleague cannot reject another person handoff');
    Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->where('member_id',102)->update(['status'=>'removed']);
    teamDeny(fn()=>$employeeWork->action((int)$internal['id'],['action'=>'accept','assignment_version'=>1]),'leaving immediately revokes a previously selected recipient');
    Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->where('member_id',102)->update(['status'=>'active']);
    $config['enabled']=false;(new ConfigService($admin))->save($config);
    teamDeny(fn()=>$employeeWork->action((int)$internal['id'],['action'=>'accept','assignment_version'=>1]),'closed business rejects internal acceptance through direct API as well');
    $config['enabled']=true;(new ConfigService($admin))->save($config);
    $employeeWork->action((int)$internal['id'],['action'=>'accept','assignment_version'=>1]);
    teamDeny(fn()=>$team->remove(102),'owner cannot remove the only handler of a following internal task');
    teamDeny(fn()=>$staff->leave(),'selected colleague cannot leave while following their internal task');
    teamDeny(fn()=>(new TeamService($admin))->adminRemove($merchant,102),'platform member removal also cannot orphan an in-progress internal task');
    teamCheck($employeeWork->detail((int)$internal['id'])['can_report'],'failed removal leaves the selected colleague able to complete the task');
    teamDeny(fn()=>$ownerWork->action((int)$internal['id'],['action'=>'deal','assignment_version'=>1]),'publisher cannot report completion on behalf of chosen colleague');
    teamDeny(fn()=>(new CooperationService(new Context($site,0,104)))->action((int)$internal['id'],['action'=>'no_deal','assignment_version'=>1]),'other colleague cannot report no-deal for selected recipient');
    $beforeOrders=Store::query('coop_order',$site)->count();$beforeAccounts=Db::name('member_account_log')->where('site_id',$site)->count();
    $finished=$employeeWork->action((int)$internal['id'],['action'=>'deal','assignment_version'=>1]);
    teamCheck($finished['status']==='paid'&&$finished['status_label']==='已完成 · 本店交付'&&$finished['is_internal']&&!$finished['can_pay'],'staff completes internal delivery without a cashier step');
    teamCheck($finished['commission_amount']==='0.00'&&$finished['fee_amount']==='0.00'&&$finished['payment_order_id']===0,'internal delivery has zero platform fee and no payment order');
    teamCheck(Store::query('coop_order',$site)->count()===$beforeOrders&&Db::name('member_account_log')->where('site_id',$site)->count()===$beforeAccounts,'internal handoff creates neither payment nor commission/growth ledger');
    teamDeny(fn()=>(new PaymentService($employee))->createOrder(['purpose'=>'commission','lead_id'=>$internal['id'],'amount'=>'100','request_id'=>'internal-forged-pay']),'direct client cannot create a paid referral for the same subject');
    $staff->leave();teamCheck((new TeamService($owner))->summary()['membership']['used_accounts']===3,'completed internal task no longer prevents voluntary leave');
    $staff->join(['subject_code'=>$code]);$team->review(102,true);$team->remove(102);teamCheck((new TeamService($owner))->summary()['membership']['used_accounts']===3,'completed internal task no longer prevents owner removal');
    $staff->join(['subject_code'=>$code]);$team->review(102,true);
    $next=$ownerWork->create(['request_id'=>'internal-reassignment','customer_name'=>'Another customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$catalog[0]['id']],'consent'=>true]);$nextId=(int)$next['id'];
    $ownerWork->assign($nextId,['merchant_id'=>$merchant,'assignee_member_id'=>102,'assignment_version'=>0]);$nextRule=Data::decode(Store::row('collaboration',$site,$nextId)['rule_json']);
    $assignedAudit=Data::query('audit',$site)->where('entity_type','collaboration')->where('entity_id',$nextId)->where('action','assigned')->find();teamCheck(Data::decode($assignedAudit['detail_json'])['assignee_member_id']===102&&$ownerWork->detail($nextId)['internal_assignee_name']!=='','new assignment audit and detail retain the selected person, not only the store');
    foreach(['102abc',102.5,null,-102,true]as$badTarget){
        Store::query('collaboration',$site)->where('id',$nextId)->update(['rule_json'=>Data::json(array_replace($nextRule,['internal_assignee_member_id'=>$badTarget]))]);
        teamCheck(!$employeeWork->detail($nextId)['can_accept']&&$employeeWork->lists(['direction'=>'incoming','status'=>'assigned'])['total']===0,'malformed new target is not a legacy queue or actionable recipient');
        teamDeny(fn()=>$employeeWork->action($nextId,['action'=>'accept','assignment_version'=>1]),'malformed target fails closed through direct API');
    }
    foreach([0,'101abc',null,102]as$badActor){
        Store::query('collaboration',$site)->where('id',$nextId)->update(['rule_json'=>Data::json(array_replace($nextRule,['internal_publisher_member_id'=>$badActor]))]);
        teamCheck(!$employeeWork->detail($nextId)['can_accept']&&$employeeWork->lists(['direction'=>'incoming','status'=>'assigned'])['total']===0,'invalid publisher actor and self-directed snapshot do not create an actionable inbox entry');
        teamDeny(fn()=>$employeeWork->action($nextId,['action'=>'accept','assignment_version'=>1]),'invalid publisher actor or self-directed snapshot is denied');
    }
    Store::query('collaboration',$site)->where('id',$nextId)->update(['rule_json'=>Data::json($nextRule)]);
    $employeeWork->action($nextId,['action'=>'reject','assignment_version'=>1]);$ownerWork->assign($nextId,['merchant_id'=>$merchant,'assignee_member_id'=>104,'assignment_version'=>2]);
    teamCheck(!$employeeWork->detail($nextId)['can_accept']&&(new CooperationService(new Context($site,0,104)))->detail($nextId)['can_accept'],'reject then reassignment revokes previous recipient and selects another person');
    $otherWork=new CooperationService(new Context($site,0,104));$otherWork->action($nextId,['action'=>'accept','assignment_version'=>3]);$otherWork->action($nextId,['action'=>'no_deal','assignment_version'=>3]);
    teamCheck(Store::row('collaboration',$site,$nextId)['status']==='no_deal','selected recipient can complete the no-deal internal branch');
    Store::query('collaboration',$site)->where('id',$nextId)->update(['rule_json'=>'{invalid legacy snapshot']);
    teamCheck($employeeWork->lists(['direction'=>'incoming','status'=>'no_deal'])['total']===1,'invalid historic JSON does not crash incoming pagination');
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['status'=>0]);
    teamDeny(fn()=>(new TeamService(new Context($site,0,106)))->lookup($code),'a subject without an active responsible owner cannot recruit members');
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['status'=>1]);
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'actual plugin services in owned localhost schema; no existing business rows or external network'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$e){$failed=true;fwrite(STDERR,get_class($e).': '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
