<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,Store,TeamService,EntityMembershipService};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function teamCheck(bool $ok,string $label):void {if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function teamDeny(callable $call,string $label):void {try{$call();}catch(CommonException $e){teamCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try {
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    leadMembershipSeed($site);
    $admin=new Context($site,1);$owner=new Context($site,0,101);$employee=new Context($site,0,102);
    foreach([104,105,106]as$id)Db::name('member')->insert(['site_id'=>$site,'member_id'=>$id,'nickname'=>'Test '.$id,'mobile'=>'19900000'.$id]);
    $config=ConfigService::defaults();$config['enabled']=true;(new ConfigService($admin))->save($config);
    $input=['name'=>'Test subject','contact_name'=>'Owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Test street'];
    $profile=(new PartnerService($owner))->saveProfile($input);$merchant=(int)$profile['id'];
    $team=new TeamService($owner);$summary=$team->summary();$code=$summary['subject_code'];
    teamCheck(strlen($code)===10&&$summary['membership']['used_accounts']===1,'owner is included, generated subject code is readable');
    teamCheck($team->summary()['subject_code']===$code,'subject code is stable across reads');
    $staff=new TeamService($employee);$lookup=$staff->lookup(strtolower($code));
    teamCheck(array_keys($lookup)===['merchant_id','name'],'lookup exposes no phone, members, ERP or rights');
    teamDeny(fn()=>(new TeamService(new Context($site+1,0,103)))->lookup($code),'cross tenant subject code never resolves');
    teamDeny(fn()=>$staff->join(['subject_code'=>$code]),'ordinary one-account subject cannot add another account');
    // Seat tests explicitly configure a zero-threshold entry; growth is covered separately.
    leadSetEntryDefinition($site,702);$partner=Store::partner($site,$merchant);$paid=leadMembershipGrant($site,101,'ML702');
    $joined=$staff->join(['subject_code'=>$code]);teamCheck($joined['merchant_id']===0&&$joined['pending_entity']['merchant_id']===$merchant,'join creates pending application only');
    teamDeny(fn()=>$employee->merchant(),'pending member cannot read subject business');
    $staff->join(['subject_code'=>$code]);teamCheck(Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('member_id',102)->count()===1,'retrying join does not duplicate application');
    teamDeny(fn()=>(new PartnerService($employee))->saveProfile(array_replace($input,['name'=>'Bad overwrite','mobile'=>'19900000102'])),'pending application cannot be bypassed by creating another subject');
    (new TeamService(new Context($site,0,104)))->join(['subject_code'=>$code]);
    $team->review(102,true);teamCheck($employee->merchant()['id']===$merchant,'approved member resolves to same subject');
    teamCheck($employee->merchant()['team_role']==='member','employee does not inherit owner role');
    teamDeny(fn()=>TeamService::assertOwner($employee),'employee cannot become responsible owner');
    teamDeny(fn()=>$staff->remove(101),'employee cannot remove the owner');
    teamDeny(fn()=>$employee->connectionMerchant($merchant),'employee cannot authorize or reconfigure ERP');
    teamDeny(fn()=>(new PartnerService($employee))->saveProfile(array_replace($input,['name'=>'Bad profile'])),'employee cannot edit shared storefront through profile API');
    $boot=(new PartnerService($employee))->bootstrap();
    teamCheck($boot['profile']['is_owner']===false&&$boot['wallet']===null,'employee bootstrap does not leak owner wallet');
    teamCheck($boot['profile']['membership']['level_code']==='ML702'&&$boot['profile']['membership']['used_accounts']===2,'employee sees shared level and total seats');
    teamDeny(fn()=>$team->review(104,true),'second approval rechecks seats atomically under the subject lock');
    teamCheck($team->summary()['pending_count']===1&&$team->summary()['membership']['used_accounts']===2,'failed approval leaves pending request and seat count intact');
    $team->review(104,false);teamCheck((new TeamService(new Context($site,0,104)))->summary()['pending_entity']===null,'rejection clears pending onboarding');
    $staff->leave();teamDeny(fn()=>$employee->merchant(),'leaving immediately revokes member business access');
    teamCheck($team->summary()['membership']['used_accounts']===1,'leaving releases a seat without deleting original member');
    (new TeamService(new Context($site,0,104)))->join(['subject_code'=>$code]);
    (new TeamService(new Context($site,0,104)))->leave();teamCheck($team->summary()['pending_count']===0,'applicant can cancel before owner approval');
    $staff->join(['subject_code'=>$code]);$team->review(102,true);$team->remove(102);teamDeny(fn()=>$employee->merchant(),'owner removal revokes access on next request without waiting for token expiry');
    teamDeny(fn()=>$team->remove(101),'owner account cannot be removed');teamDeny(fn()=>$team->leave(),'owner cannot abandon responsible subject');
    $staff->join(['subject_code'=>$code]);
    // Missing verified grant cannot be replaced by a cached partner flag.
    Store::query('coop_order',$site)->where('id',$paid['id'])->update(['status'=>'closed']);
    teamDeny(fn()=>$team->review(102,true),'expiry before approval prevents newly exceeding ordinary account limit');
    $team->review(102,false);
    Db::name('member_level')->where('site_id',$site)->where('level_id',704)->update(['level_benefits'=>leadMembershipDefinition(704,4,10,true)['level_benefits']]);leadSetEntryDefinition($site,704);leadMembershipGrant($site,101,'ML704');
    foreach([102,104,105,106]as$id){$ctx=new Context($site,0,$id);(new TeamService($ctx))->join(['subject_code'=>$code]);$team->review($id,true);}
    teamCheck($team->summary()['membership']['unlimited']&&$team->summary()['membership']['used_accounts']===5,'configured unlimited tier is not hardcoded to ten accounts');
    $listed=(new TeamService($admin))->adminList(['keyword'=>$code]);teamCheck($listed['total']===1&&$listed['data'][0]['subject_code']===$code,'admin can search subject code and see totals');
    $detail=(new TeamService($admin))->adminDetail($merchant);teamCheck(count($detail['members'])===5,'admin sees owner and staff separately');
    (new TeamService($admin))->adminRemove($merchant,106);teamDeny(fn()=>(new Context($site,0,106))->merchant(),'platform removal also revokes access');
    teamCheck((int)Db::name('member')->where('site_id',$site)->where('member_id',102)->value('member_level')===0,'framework personal level remains untouched');
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['status'=>0]);
    teamDeny(fn()=>(new TeamService(new Context($site,0,106)))->lookup($code),'a subject without an active responsible owner cannot recruit members');
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['status'=>1]);
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'actual plugin services in owned localhost schema; no existing business rows or external network'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$e){$failed=true;fwrite(STDERR,get_class($e).': '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
