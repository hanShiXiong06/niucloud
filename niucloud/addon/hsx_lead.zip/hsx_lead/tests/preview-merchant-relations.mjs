import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
// Local synthetic visual fixture. Actual Vue components/framework CSS only;
// transport is in-memory and refuses every write. No browser automation.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const workspace=path.resolve(plugin,'../../..'),admin=path.join(workspace,'admin')
const require=createRequire(path.join(admin,'package.json'))
const {createServer}=require('vite'),vue=require('@vitejs/plugin-vue').default
const importFile=relative=>JSON.stringify('/@fs/'+path.join(plugin,relative))
const requestSource=`
const people=[
{member:{member_id:202,member_no:'NIU000202',name:'张明',mobile_masked:'138****0002'},inviter:{member_id:101,member_no:'NIU000101',name:'李师傅',mobile_masked:'139****0001',direct_invite_count:3},merchant:{merchant_id:2,name:'张师傅数码·石家庄长安店',shared:false},membership:{status:'active',status_label:'生效中',level_name:'白银会员',expires_at:1825632000},payment:{status:'paid',status_label:'已付会员费',paid_order_count:1,unpaid_order_count:0,service_paid:'199.00',service_refunded:'0.00',service_net:'199.00',last_paid_at:1794096000},promotion:{pending:'19.90',settled:'0.00',held:'0.00',total:'19.90'},create_time:1794009600,bound_at:1794009600},
{member:{member_id:203,member_no:'NIU000203',name:'王静',mobile_masked:'138****0003'},inviter:{member_id:101,member_no:'NIU000101',name:'李师傅',mobile_masked:'139****0001',direct_invite_count:3},merchant:{merchant_id:3,name:'王静通信',shared:false},membership:{status:'not_opened',status_label:'未开通',level_name:'',expires_at:0},payment:{status:'unpaid',status_label:'尚未付费',paid_order_count:0,unpaid_order_count:1,service_paid:'0.00',service_refunded:'0.00',service_net:'0.00'},promotion:{pending:'0.00',settled:'0.00',held:'0.00',total:'0.00'},create_time:1794009600,bound_at:null},
{member:{member_id:204,member_no:'NIU000204',name:'陈小北',mobile_masked:'138****0004'},inviter:{member_id:102,member_no:'NIU000102',name:'周经理',mobile_masked:'139****0002',direct_invite_count:1},merchant:{merchant_id:4,name:'小北手机维修服务中心',shared:true},membership:{status:'active',status_label:'生效中',level_name:'黄金会员',expires_at:1825632000},payment:{status:'unpaid',status_label:'本人未付费',paid_order_count:0,unpaid_order_count:0,service_paid:'0.00',service_refunded:'0.00',service_net:'0.00'},promotion:{pending:'0.00',settled:'0.00',held:'0.00',total:'0.00'},create_time:1793923200,bound_at:1793923200},
{member:{member_id:205,member_no:'NIU000205',name:'刘畅',mobile_masked:'138****0005'},inviter:{member_id:101,member_no:'NIU000101',name:'李师傅',mobile_masked:'139****0001',direct_invite_count:3},merchant:{merchant_id:5,name:'刘畅通讯',shared:false},membership:{status:'review',status_label:'待核对',level_name:'青铜会员',expires_at:0},payment:{status:'review',status_label:'付款结果待核对',paid_order_count:1,unpaid_order_count:0,service_paid:'99.00',service_refunded:'0.00',service_net:'99.00'},promotion:{pending:'0.00',settled:'0.00',held:'9.90',total:'9.90'},create_time:1793836800,bound_at:1793836800}
]
for(const row of people){row.payment.paid_total=row.member.member_id===202?'699.00':row.payment.service_paid;row.payment.refunded_total='0.00';row.payment.paid_net=row.payment.paid_total;row.promotion.cancelled=row.member.member_id===202?'5.00':'0.00';if(row.payment.status==='review'){row.payment.review_required=true;row.payment.service_net=null;row.payment.service_paid=null;row.payment.service_refunded=null;row.payment.paid_total=null;row.payment.refunded_total=null;row.payment.paid_net=null}}
const definitions=[{key:'purchase',name:'二手机',enabled:true,dimension:'model',options:[{id:'iphone17',name:'iPhone 17',brand:'苹果',category_path:['手机','苹果','iPhone 17']},{id:'mate80',name:'华为 Mate 80',brand:'华为',category_path:['手机','华为','Mate 80']}]}]
const merchantRows=people.map((row,i)=>({id:i+1,name:row.merchant.name,contact_name:row.member.name,mobile:row.member.mobile_masked,province_name:'河北省',city_name:'石家庄市',district_name:'长安区',business_capabilities:[{business_type:'purchase',business_name:'二手机',option_count:i?845:43}],ready_state:i?'membership_required':'ready',ready_reason:i?'门店会员未开通或已到期':'',connection_id:i?0:1,provider:i?'':'S',provider_name:i?'':'S 平台',channel_enabled:true,last_sync_status:'completed',last_sync_at:1794096000,status:1}))
const filters={payment_states:[{value:'paid',label:'已付费'},{value:'unpaid',label:'尚未付费'},{value:'refunded',label:'已全额退款'},{value:'review',label:'待核对'}],membership_states:[{value:'active',label:'生效中'},{value:'expired',label:'已到期'},{value:'not_opened',label:'未开通'},{value:'inactive',label:'已暂停'},{value:'review',label:'待核对'}]}
export default {
async get(url,config={}){
const q=config.params||{}
await new Promise(resolve=>setTimeout(resolve,180))
if(url==='hsx_lead/promotion/relations'){
const includes=(person,term)=>!term||[person.name,person.member_no,person.member_id,person.mobile_masked].some(value=>String(value).includes(term))
const rows=people.filter(row=>(!q.inviter_member_id||row.inviter.member_id===Number(q.inviter_member_id))&&includes(row.member,q.keyword)&&includes(row.inviter,q.inviter_keyword)&&(!q.payment_state||row.payment.status===q.payment_state)&&(!q.membership_state||row.membership.status===q.membership_state))
return {data:{data:rows,total:rows.length,current_page:q.page||1,per_page:q.limit||20,filters,summary:{relation_count:rows.length,paid_count:rows.filter(row=>row.payment.status==='paid').length,review_count:rows.filter(row=>row.payment.status==='review').length,service_net:rows.some(row=>row.payment.service_net===null)?null:rows.reduce((n,row)=>n+Number(row.payment.service_net),0).toFixed(2),promotion_total:rows.reduce((n,row)=>n+Number(row.promotion.total),0).toFixed(2)}}}
}
if(url==='hsx_lead/merchants')return {data:q.definitions?{business_definitions:definitions}:{data:merchantRows.filter(row=>!q.keyword||JSON.stringify(row).includes(q.keyword)),total:merchantRows.length}}
if(/^hsx_lead\\/merchants\\/[0-9]+$/.test(url)){const id=Number(url.split('/').pop()),row=merchantRows.find(row=>row.id===id);return {data:{...row,member_id:people[id-1].member.member_id,province_id:1,city_id:2,district_id:3,business_definitions:definitions,business_capabilities:[{business_type:'purchase',option_ids:['iphone17'],items:[definitions[0].options[0]]}],service_areas:[]}}}
if(url==='hsx_lead/providers')return {data:{items:[]}}
if(url==='hsx_lead/members')return {data:[]}
if(url==='hsx_lead/promotion/providers'||url==='hsx_lead/promotion/rewards')return {data:{data:[],total:0}}
throw new Error('本地只读预览未提供该读取：'+url)
},post(){throw new Error('本地预览禁止写入')},put(){throw new Error('本地预览禁止写入')},delete(){throw new Error('本地预览禁止写入')}
}
`
const userSource=`export default()=>({rules:['hsx_lead_promotion_manage','hsx_lead_promotion_relations','hsx_lead_promotion_providers','hsx_lead_promotion_rewards'],routers:[]})`
const entry=`
import {createApp,h,ref} from 'vue'
import ElementPlus,{ElConfigProvider} from 'element-plus'
import zhCn from 'element-plus/es/locale/lang/zh-cn'
import 'element-plus/dist/index.css'
import ${importFile('../hsx_components/admin/styles/theme.scss')}
import ${importFile('admin/views/components/lead.css')}
import ${importFile('admin/views/cooperation/cooperation.css')}
import Promotion from ${importFile('admin/views/promotion/index.vue')}
import MerchantPanel from ${importFile('admin/views/components/MerchantPanel.vue')}
const view=ref(new URLSearchParams(location.search).get('view')==='merchants'?'merchants':'relations')
createApp({setup(){return()=>h(ElConfigProvider,{locale:zhCn},()=>h('main',{class:'preview-layout lead-workbench coop-space'},[
h('div',{class:'preview-notice'},'本地合成数据 · 不连接真实账户或后端 · 写入已禁用'),
h('nav',{class:'preview-navigation'},[h('button',{class:{active:view.value==='relations'},onClick:()=>view.value='relations'},'推广管理'),h('button',{class:{active:view.value==='merchants'},onClick:()=>view.value='merchants'},'合作商户')]),
view.value==='merchants'?h(MerchantPanel):h(Promotion)
]))}}).use(ElementPlus).mount('#app')
`
const virtual='virtual:hsx-merchant-relations-preview',request='virtual:hsx-merchant-relations-request',user='virtual:hsx-merchant-relations-user',sys='virtual:hsx-merchant-relations-sys'
const sourcePlugin={name:'hsx-merchant-relations-preview',resolveId(id){if([virtual,request,user,sys].includes(id))return '\0'+id},load(id){if(id==='\0'+virtual)return entry;if(id==='\0'+request)return requestSource;if(id==='\0'+user)return userSource;if(id==='\0'+sys)return 'export const getAreaListByPid=async(pid)=>({data:pid===0?[{id:1,name:"河北省"}]:pid===1?[{id:2,name:"石家庄市"}]:[{id:3,name:"长安区"}]})'},configureServer(server){server.middlewares.use((req,res,next)=>{if(req.url!=='/'&&!req.url?.startsWith('/?'))return next();res.setHeader('Content-Type','text/html;charset=utf-8');res.end('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>商户与邀请关系 · 本地验收</title><style>body{margin:0;background:#f5f7fa;font-family:Arial,"PingFang SC",sans-serif}.preview-layout{box-sizing:border-box;max-width:1600px;margin:auto;padding:18px}.preview-notice{font-size:12px;background:#fff7e6;color:#79551f;padding:9px 12px;margin-bottom:14px;border-radius:4px}.preview-navigation{display:flex;gap:10px;margin-bottom:18px}.preview-navigation button{border:0;background:transparent;color:#606266;font-size:14px;padding:8px 12px;cursor:pointer}.preview-navigation button.active{font-weight:600;color:#409eff;border-bottom:2px solid #409eff}.preview-layout .hsx-page{padding:0!important}</style></head><body><div id="app"></div><script type="module" src="/@vite/client"></script><script type="module" src="/@id/'+virtual+'"></script></body></html>')})}}
const server=await createServer({configFile:false,root:admin,cacheDir:path.join(workspace,'output/hsx-lead-relations-preview/.vite'),plugins:[sourcePlugin,vue()],css:{postcss:{plugins:[]}},resolve:{dedupe:['vue','element-plus','@element-plus/icons-vue'],alias:[{find:'@/utils/request',replacement:request},{find:'@/stores/modules/user',replacement:user},{find:'@/app/api/sys',replacement:sys},{find:'@',replacement:path.join(admin,'src')},{find:'vue',replacement:path.join(admin,'node_modules/vue/dist/vue.runtime.esm-bundler.js')}]},optimizeDeps:{entries:[],include:['vue','element-plus','@element-plus/icons-vue']},server:{host:'127.0.0.1',port:Number(process.env.HSX_LEAD_PREVIEW_PORT||0),strictPort:true,hmr:false,fs:{allow:[workspace]}}})
await server.listen()
console.log(JSON.stringify({origin:`http://127.0.0.1:${server.httpServer.address().port}`,fixture:true,realSfc:true,mutations:false,remoteApi:false}))
process.on('SIGTERM',async()=>{await server.close();process.exit(0)})
process.on('SIGINT',async()=>{await server.close();process.exit(0)})
