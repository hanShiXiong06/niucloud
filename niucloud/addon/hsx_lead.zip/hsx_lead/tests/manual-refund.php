<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';require __DIR__.'/manual-refund-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{CapabilityService,ConfigService,CooperationService,EntityExperienceService,EntityMembershipService,ManualPaymentService,ManualRefundService,MembershipCostService,MembershipDepositService,OrderPaymentReadService,PartnerService,PaymentOrderLifecycle,PaymentRefundService,PaymentService,PromotionRules,PromotionService,Store};
use addon\hsx_lead\app\listener\pay\{CooperationPayCreate,CooperationPaySuccess,MembershipRefundSuccess,CooperationOrderRefundSuccess,PromotionRefundSuccess};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use core\exception\CommonException;
use think\facade\{Db,Event};
$pdo=null;$schema='';$failed=false;$checks=0;
function mfCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function mfDeny(callable$run,string$label):void{try{$run();}catch(CommonException$e){mfCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
final class ManualRefundOnlineUnknownDriver
{
    public static int $sent=0;
    public function __construct(...$ignored){}
    public function refund(array$input):array{self::$sent++;throw new RuntimeException('Synthetic online result unknown');}
    public function getRefund($out,$no):array{return['refund_no'=>$no,'status'=>RefundDict::DEALING];}
}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund','pay_channel']as$table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m);$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    $app->config->set(['default'=>'balancepay','drivers'=>['balancepay'=>['driver'=>app\service\core\paytype\CoreBalanceService::class]]],'pay');$app->bind('think\\route\\Url',think\app\Url::class);
    Event::listen('PayCreate',CooperationPayCreate::class);Event::listen('PaySuccess',CooperationPaySuccess::class);
    Event::listen('RefundSuccess',MembershipRefundSuccess::class);Event::listen('RefundSuccess',CooperationOrderRefundSuccess::class);Event::listen('RefundSuccess',PromotionRefundSuccess::class);
    leadMembershipSeed($site);foreach([701=>100,702=>200]as$id=>$deposit)Db::name('member_level')->where('site_id',$site)->where('level_id',$id)->update(['level_benefits'=>leadMembershipDefinition($id,$id-700,$id-700,false,['deposit_amount'=>number_format($deposit,2,'.',''),'experience_purchase_enabled'=>true,'experience_unit_price'=>'1.00'])['level_benefits']]);
    $admin=new Context($site,1);$member=new Context($site,0,102);$promoter=new Context($site,0,101);
    $cfg=ConfigService::defaults();$cfg['enabled']=true;$cfg['fee_confirmed']=true;(new ConfigService($admin))->save($cfg);
    foreach([$member,$promoter]as$ctx)(new PartnerService($ctx))->saveProfile(['name'=>'Manual refund shop '.$ctx->memberId,'contact_name'=>'Synthetic owner','mobile'=>'19900000'.$ctx->memberId,'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);
    $merchant=(int)$member->merchant()['id'];$membership=new EntityMembershipService($member);$payment=new PaymentService($member);$manual=new ManualPaymentService($admin);$refunds=new PaymentRefundService($admin);$confirm=new ManualRefundService($admin);
    $pc=PromotionRules::defaults();$pc['enabled']=true;$pc['settlement_days']=0;$pc['sources']['membership']=['enabled'=>true,'normal_rate'=>'25.00','provider_rate'=>'25.00','renewal'=>true];(new PromotionService($admin))->saveConfig($pc);(new PromotionService($member))->bind(['mid'=>101,'confirm'=>true]);
    $sequence=0;$buy=static function(string$code,bool$experience=true)use(&$sequence,$membership,$payment,$admin):array{
        $sequence++;$q=$membership->quote($code,'month',$experience);if(!$q['can_purchase'])throw new RuntimeException('Quote blocked: '.$q['reason']);
        $order=$payment->createOrder(['purpose'=>'membership','level_code'=>$code,'cycle'=>'month','buy_experience'=>$experience,'quote_token'=>$q['quote_token'],'request_id'=>'manual-refund-buy-'.$sequence]);
        $receipt=mfLegacyReceipt($admin,$order,'RECEIVED-'.$sequence,'manual-refund-income-'.$sequence);
        if($receipt['status']!=='posted')throw new RuntimeException('Manual payment not posted: '.Data::json($receipt));return$receipt['order'];
    };
    $beforeBalance=(string)Db::name('member')->where('member_id',102)->value('balance');$order=$buy('ML702');$id=(int)$order['id'];PromotionService::settleSite($site);
    mfCheck($membership->summary()['active']&&$order['payment_type']===PayDict::OFFLINEPAY,'actual offline service and payment hook grant membership');
    mfCheck(MembershipCostService::balances($site,$merchant)['balance']==='200.00'&&EntityExperienceService::summary($site,$merchant)['purchased_value']==='200.00','manual receipt preserves explicit deposit and purchased-experience lots');
    $reward=Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$id)->find();mfCheck($reward&&$reward['base_amount']===$order['service_amount']&&$reward['status']==='settled','manual membership referral uses service fee only');
    $protected=static function()use($site,$id,$merchant):array{return[
        'source'=>Store::row('coop_order',$site,$id),'partner'=>Store::partner($site,$merchant),'members'=>Db::name('member')->where('site_id',$site)->order('member_id')->select()->toArray(),
        'account_logs'=>Db::name('member_account_log')->where('site_id',$site)->order('id')->select()->toArray(),'rewards'=>Db::name('hsx_lead_promotion_reward')->where('site_id',$site)->order('id')->select()->toArray(),'audit_count'=>Data::query('audit',$site)->count()];};
    $beforeForged=$protected();$rawSource=Store::row('coop_order',$site,$id);
    $fake=(int)Db::name('pay_refund')->insertGetId(['site_id'=>$site,'refund_no'=>'FORGED_OFFLINE_SUCCESS','out_trade_no'=>$rawSource['out_trade_no'],'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$id,'money'=>$order['amount'],'type'=>PayDict::OFFLINEPAY,'channel'=>'pc','refund_type'=>RefundDict::OFFLINE,'status'=>RefundDict::SUCCESS,'voucher'=>'FORGED_NO_TRANSFER','refund_time'=>time()]);
    $fakeEvent=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$id,'refund_no'=>'FORGED_OFFLINE_SUCCESS','out_trade_no'=>$rawSource['out_trade_no']];
    mfDeny(fn()=>(new MembershipRefundSuccess())->handle($fakeEvent),'direct membership listener rejects offline SUCCESS without typed actual refund evidence');
    mfDeny(fn()=>PromotionService::refund($fakeEvent),'direct promotion service rejects offline SUCCESS without typed actual refund evidence');
    mfCheck($protected()===$beforeForged,'forged offline callback cannot mutate original rights, deposit/experience snapshot, rewards, balances or audits');Db::name('pay_refund')->where('id',$fake)->delete();
    mfCheck($membership->summary()['active']&&MembershipCostService::balances($site,$merchant)['balance']==='200.00','rejected fake callback leaves the funded membership and deposit intact');
    $r=$refunds->apply($id,['confirm'=>true,'reason'=>'合成会员退款并重新开通','request_id'=>'manual-full-refund-one'],true);
    mfCheck($r['status']==='approved'&&$r['manual_refund_required']&&$r['can_confirm_manual_refund']&&!$r['can_continue'],'approval waits for a real human transfer and does not auto-refund');
    mfCheck(Db::name('pay_refund')->where('refund_no',$r['refund_no'])->value('status')===RefundDict::WAIT,'pending refund reserves the original source without pretending the actual transfer is finished');
    $q=$membership->quote('ML701','month');mfCheck(!$q['can_purchase'],'pending reviewed refund prevents creating new membership payment');
    mfCheck(Db::name('member')->where('member_id',102)->value('balance')===$beforeBalance,'refund approval does not fabricate balance credit');
    $refundPayload=['refund_no'=>$r['refund_no'],'amount'=>$r['amount'],'method'=>'bank','account_label'=>'Refund fixture bank','external_no'=>'REFUNDED-ONE','received_at'=>time(),'reason'=>'已核对实际线下退款成功','request_id'=>'manual-refund-confirm-one','confirm'=>true];
    mfDeny(fn()=>(new ManualRefundService($member))->confirm($id,$refundPayload),'member cannot confirm an actual platform refund');
    mfDeny(fn()=>(new ManualRefundService(new Context($site+1,1)))->confirm($id,$refundPayload),'another site cannot confirm original refund');
    (new app\service\core\menu\CoreMenuService())->refreshAddonMenu('hsx_lead');
    foreach([['hsx_lead_cooperation_finance','hsx_lead_manage_all_data'],['hsx_lead_cooperation_order_manual_refund','hsx_lead_manage_all_data'],['hsx_lead_cooperation_finance','hsx_lead_cooperation_order_manual_refund']]as$index=>$rules){
        $uid=11+$index;$role=(int)Db::name('sys_role')->insertGetId(['site_id'=>$site,'role_name'=>'Manual refund privilege '.$uid,'rules'=>Data::json($rules),'status'=>1]);Db::name('sys_user')->insert(['uid'=>$uid,'username'=>'manual-refund-'.$uid,'status'=>1]);Db::name('sys_user_role')->insert(['uid'=>$uid,'site_id'=>$site,'role_ids'=>Data::json([$role]),'status'=>1,'is_admin'=>0]);
        mfDeny(fn()=>(new ManualRefundService(new Context($site,$uid)))->confirm($id,$refundPayload),'manual refund requires finance, distinct confirmation and all-data permissions together');
    }
    foreach([['amount'=>'0.01'],['confirm'=>false],['refund_no'=>'UNKNOWN_REFUND'],['external_no'=>''],['received_at'=>time()+600],['amount'=>'1e2'],['member_id'=>101]]as$bad)mfDeny(fn()=>$confirm->confirm($id,array_replace($refundPayload,$bad)),'invalid, mismatched or forged refund data cannot complete');
    mfDeny(fn()=>Db::transaction(fn()=>$confirm->confirm($id,$refundPayload)),'outer transaction cannot roll back the durable attested transfer after business failure');
    Event::remove('RefundSuccess');
    $posted=$confirm->confirm($id,$refundPayload);mfCheck($posted['status']==='posted'&&$posted['refund_status']===RefundDict::SUCCESS,'explicit actual-transfer confirmation completes refund even before plugin event cache refresh');
    Event::listen('RefundSuccess',MembershipRefundSuccess::class);Event::listen('RefundSuccess',CooperationOrderRefundSuccess::class);Event::listen('RefundSuccess',PromotionRefundSuccess::class);
    mfCheck(!$membership->summary()['active']&&MembershipCostService::balances($site,$merchant)['balance']==='0.00'&&EntityExperienceService::summary($site,$merchant)['purchased_value']==='0.00','full offline refund withdraws only funded rights, deposit and purchased experience');
    $originalPaid=Store::row('coop_order',$site,$id);$sourceProof=ManualPaymentService::assertReceipt($site,$originalPaid,OrderPaymentReadService::payment($originalPaid),true);
    mfCheck($sourceProof['kind']==='payment'&&(int)$sourceProof['target_order_id']===$id,'refund metadata never invalidates the immutable original offline payment proof');
    mfCheck(Db::name('member')->where('member_id',102)->value('balance')===$beforeBalance&&Db::name('member_account_log')->where('from_type','order_refund')->count()===0,'offline refund never credits platform balance');
    $realEvent=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$id,'refund_no'=>$refundPayload['refund_no'],'out_trade_no'=>$originalPaid['out_trade_no']];
    mfCheck((new MembershipRefundSuccess())->handle($realEvent)&&PromotionService::refund($realEvent),'real typed offline proof remains accepted by independently invoked idempotent listeners');
    $reward=Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$id)->find();mfCheck($reward['status']==='held'&&(int)$reward['review_required']===0&&Db::name('member')->where('member_id',101)->value('commission')==='0.00','service referral reward is reclaimed from the frozen original, not paid a second time');
    $count=Db::name('member_account_log')->count();$again=$confirm->confirm($id,$refundPayload);$refunds->refresh($id,true);PaymentRefundService::tick();
    mfCheck($again['manual_receipt_id']===$posted['manual_receipt_id']&&Db::name('member_account_log')->count()===$count&&Db::name('hsx_lead_manual_receipt')->where('kind','refund')->count()===1,'confirm retry, reads and scheduler are idempotent');
    mfDeny(fn()=>$confirm->confirm($id,array_replace($refundPayload,['amount'=>'1.00'])),'same request cannot change confirmed amount');
    $second=$buy('ML701',false);mfCheck($second['status']==='paid'&&$membership->summary()['active']&&$membership->summary()['level_code']==='ML701','full refund permits a fresh requested lower plan without old active/order-key deadlock');
    // A callback interruption preserves the actual manual-transfer evidence and
    // recovers the original only. No second transfer or balance credit occurs.
    $two=(int)$second['id'];$pending=$refunds->apply($two,['confirm'=>true,'reason'=>'合成退款回调中断恢复','request_id'=>'manual-refund-callback'],true);
    $failure=static function():void{throw new CommonException('Synthetic refund callback interrupted');};Event::listen('RefundSuccess',$failure);
    $twoInput=array_replace($refundPayload,['refund_no'=>$pending['refund_no'],'amount'=>$pending['amount'],'external_no'=>'REFUNDED-TWO','received_at'=>time(),'request_id'=>'manual-refund-confirm-two']);
    mfDeny(fn()=>$confirm->confirm($two,array_replace($twoInput,['external_no'=>'REFUNDED-ONE'])),'actual refund external reference cannot fund another original refund');
    $attention=$confirm->confirm($two,$twoInput);mfCheck($attention['status']==='attention'&&Db::name('hsx_lead_manual_receipt')->where('id',$attention['manual_receipt_id'])->value('status')==='attention','failed business callback keeps durable actual-refund evidence for compensation');
    mfCheck(Db::name('pay_refund')->where('refund_no',$pending['refund_no'])->value('status')===RefundDict::WAIT,'callback rollback does not invent successful business refund');
    Event::remove('RefundSuccess');Event::listen('RefundSuccess',MembershipRefundSuccess::class);Event::listen('RefundSuccess',CooperationOrderRefundSuccess::class);Event::listen('RefundSuccess',PromotionRefundSuccess::class);
    $oldDatabase=Db::getConfig();$aliased=$oldDatabase;$aliased['connections']['manual_fixture']=$oldDatabase['connections']['mysql'];$aliased['default']='manual_fixture';Db::setConfig($aliased);
    $appDatabase=$app->config->get('database');$otherPrefix=$appDatabase;$otherPrefix['connections']['mysql']['prefix']='unused_connection_';$app->config->set($otherPrefix,'database');
    ManualRefundService::tick();$app->config->set($appDatabase,'database');Db::setConfig($oldDatabase);
    $recovered=$refunds->detail($two,true);
    mfCheck($recovered['status']==='refunded'&&!$membership->summary()['active'],'bounded scheduler replays the recorded transfer and restores complete refund closure: '.Data::json($recovered));
    mfCheck(Db::name('hsx_lead_manual_receipt')->where('id',$attention['manual_receipt_id'])->value('status')==='posted','manual refund compensation follows active connection table name, not a hardcoded mysql alias');
    $third=$buy('ML702');mfCheck($third['status']==='paid'&&$membership->summary()['level_code']==='ML702','recovered full refund can then purchase the desired upgraded plan');
    // Deposit-only exits share the exact same human-transfer confirmation, but
    // preserve service fee promotion and purchased experience.
    $deposit=new MembershipDepositService($member);$adminDeposit=new MembershipDepositService($admin);$application=$deposit->apply(['confirm'=>true,'request_id'=>'manual-deposit-exit-one']);$anchor=(int)$application['request']['id'];
    $approved=$adminDeposit->review($anchor,['decision'=>'approve','reason'=>'业务已结清，实际退押金','request_version'=>$application['request']['request_version']]);$source=$approved['sources'][0];
    mfCheck($approved['status']==='approved'&&$source['manual_refund_required']&&$source['can_confirm_manual_refund']&&!$approved['can_continue'],'offline deposit approval waits without automatic refund dispatch');
    $depositInput=array_replace($refundPayload,['refund_no'=>$source['refund_no'],'amount'=>$source['amount'],'external_no'=>'REFUNDED-DEPOSIT','received_at'=>time(),'request_id'=>'manual-deposit-confirm']);
    $done=$confirm->confirm((int)$source['order_id'],$depositInput);$summary=$adminDeposit->detail($anchor);
    mfCheck($done['status']==='posted'&&$summary['status']==='refunded'&&MembershipCostService::balances($site,$merchant)['balance']==='0.00','matching deposit refund confirms every actual source and closes exit');
    mfCheck(EntityExperienceService::summary($site,$merchant)['purchased_value']==='200.00'&&Db::name('pay_refund')->where('refund_no',$source['refund_no'])->value('money')==='200.00','deposit-only transfer does not refund service or purchased experience');
    mfCheck(Db::name('member')->where('member_id',102)->value('balance')===$beforeBalance,'complete offline lifecycle leaves customer stored balance unchanged');
    // Ordinary online/balance refunds retain their original behavior: pending
    // blocks another purchase, confirmed failure keeps rights, full success
    // removes the old funded lot and allows an independent desired purchase.
    Db::name('member')->insert(['site_id'=>$site,'member_id'=>104,'nickname'=>'Online refund repurchase owner','mobile'=>'19900000104']);$onlineCtx=new Context($site,0,104);
    $onlineShop=(new PartnerService($onlineCtx))->saveProfile(['name'=>'Online repurchase shop','contact_name'=>'Synthetic owner','mobile'=>'19900000104','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);$onlineMerchant=(int)$onlineShop['id'];
    $onlineMembership=new EntityMembershipService($onlineCtx);$onlinePayment=new PaymentService($onlineCtx);
    $onlineBuy=static function(string$code,bool$experience,string$request)use($site,$onlineMembership,$onlinePayment):array{
        $quote=$onlineMembership->quote($code,'month',$experience);if(!$quote['can_purchase'])throw new RuntimeException('Online repurchase blocked: '.$quote['reason']);
        $order=$onlinePayment->createOrder(['purpose'=>'membership','level_code'=>$code,'cycle'=>'month','buy_experience'=>$experience,'request_id'=>$request,'quote_token'=>$quote['quote_token']]);$no='ONLINE_REBUY_'.bin2hex(random_bytes(8));
        Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$no,'main_type'=>PayDict::MEMBER,'main_id'=>104,'from_main_id'=>104,'money'=>$order['amount'],'type'=>PayDict::BALANCEPAY,'channel'=>'h5','status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);
        PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$no]);return$onlinePayment->order((int)$order['id']);
    };
    $personalLevel=Db::name('member')->where('member_id',104)->value('member_level');
    $online=$onlineBuy('ML701',false,'online-before-full-refund');$onlineId=(int)$online['id'];
    $app->config->set(['default'=>'balancepay','drivers'=>['balancepay'=>['driver'=>ManualRefundOnlineUnknownDriver::class]]],'pay');
    $unknown=$refunds->apply($onlineId,['confirm'=>true,'reason'=>'合成在线退款结果未知','request_id'=>'online-refund-first-attempt'],true);
    mfCheck($unknown['status']==='attention'&&ManualRefundOnlineUnknownDriver::$sent===1&&!$onlineMembership->quote('ML702','month',true)['can_purchase'],'online submitted refund blocks another purchase and does not dispatch twice');
    Db::name('pay_refund')->where('site_id',$site)->where('refund_no',$unknown['refund_no'])->update(['status'=>RefundDict::FAIL]);$failedRefund=$refunds->refresh($onlineId,true);
    mfCheck($failedRefund['status']==='failed'&&$onlineMembership->summary()['active']&&$onlineMembership->quote('ML702','month',true)['can_purchase'],'online refund failure preserves original membership and releases purchase restrictions');
    $app->config->set(['default'=>'balancepay','drivers'=>['balancepay'=>['driver'=>app\service\core\paytype\CoreBalanceService::class]]],'pay');
    $onlineDone=$refunds->apply($onlineId,['confirm'=>true,'reason'=>'合成在线整笔实际退回','request_id'=>'online-refund-second-attempt'],true);
    mfCheck($onlineDone['status']==='refunded'&&!$onlineMembership->summary()['active']&&MembershipCostService::balances($site,$onlineMerchant)['balance']==='0.00'&&EntityExperienceService::summary($site,$onlineMerchant)['purchased_value']==='0.00','online full success retracts old rights, held deposit and purchased experience');
    $rebought=$onlineBuy('ML702',true,'online-after-full-refund');mfCheck((int)$rebought['id']!==$onlineId&&$rebought['status']==='paid'&&$onlineMembership->summary()['level_code']==='ML702'&&EntityExperienceService::summary($site,$onlineMerchant)['purchased_value']==='200.00','online full refund can purchase desired higher plan with newly funded experience and a fresh order identity');
    mfCheck(Db::name('member')->where('member_id',104)->value('member_level')===$personalLevel,'subject membership refunds and higher repurchase never modify original personal member level');
    $quotePending=$onlineMembership->quote('ML702','month');$waiting=$onlinePayment->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','quote_token'=>$quotePending['quote_token'],'request_id'=>'manual-pending-mobile-projection']);$waitingId=(int)$waiting['id'];
    $privateRow=(int)Db::name('hsx_lead_manual_receipt')->insertGetId(['site_id'=>$site,'kind'=>'payment','order_id'=>$waitingId,'target_order_id'=>$waitingId,'member_id'=>104,'request_id'=>'manual-private-test','method'=>'bank','account_label'=>'PRIVATE_BANK_ACCOUNT','external_no'=>'PRIVATE_EXTERNAL_NO','reference_hash'=>hash('sha256','private-mobile-fixture'),'amount'=>$waiting['amount'],'received_at'=>time(),'operator_uid'=>1,'status'=>'attention','reason'=>'PRIVATE_INTERNAL_REASON','message'=>'PRIVATE_DATABASE_REASON','snapshot_json'=>Data::json(['fixture'=>true]),'create_time'=>time(),'update_time'=>time()]);
    $mobileOrder=$onlinePayment->order($waitingId);mfCheck($mobileOrder['manual_payment_status']==='attention'&&$mobileOrder['can_pay']===false&&str_contains($mobileOrder['manual_payment_message'],'请勿再次付款'),'single mobile order disables repayment immediately when actual manual receipt is pending');
    $list=(new PaymentOrderLifecycle($onlineCtx))->orders(['limit'=>100]);$row=array_values(array_filter($list['data'],static fn(array$r):bool=>(int)$r['id']===$waitingId))[0];
    mfCheck($row['can_pay']===false&&$row['manual_payment_status']==='attention','mobile payment list uses the same pending-receipt projection');
    $safeJson=Data::json([$mobileOrder,$row]);mfCheck(!str_contains($safeJson,'PRIVATE_')&&!isset($row['manual_receipt_id'])&&!isset($row['account_label'])&&!isset($row['external_no']),'mobile pending status never exposes receipt identity, bank account, external reference or internal reason');
    $db=Db::getConfig();$db['connections'][$db['default']]['trigger_sql']=true;Db::setConfig($db);Db::connect(null,true);$pendingReads=0;
    Db::listen(static function(string$sql)use(&$pendingReads):void{if(preg_match('/^SELECT .*FROM `lt_hsx_lead_manual_receipt`/i',$sql))$pendingReads++;});
    $rawWaiting=Store::row('coop_order',$site,$waitingId);ManualPaymentService::withPendingScope($site,[$waitingId],static function()use($rawWaiting):void{for($i=0;$i<20;$i++)PaymentService::presentOrder($rawWaiting);});
    mfCheck($pendingReads===1,'twenty presented rows reuse one pending-receipt query instead of a new N+1');
    Db::name('hsx_lead_manual_receipt')->where('id',$privateRow)->delete();Store::query('coop_order',$site)->where('id',$waitingId)->delete();
    $cfg=(new ConfigService($admin))->get();$cfg['publishing_required']=false;$cfg['businesses'][0]['commission_minimum']='50.00';(new ConfigService($admin))->save($cfg);
    $publish=new CooperationService($promoter);$receive=new CooperationService($onlineCtx);$model=$publish->catalog()[0];(new CapabilityService($onlineCtx))->save($onlineMerchant,['business_capabilities'=>[['business_type'=>'purchase','option_ids'=>[$model['id']]]]]);
    $lead=$publish->create(['request_id'=>'manual-refund-real-lead','customer_name'=>'Synthetic handover customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'consent'=>true,'attachments'=>[]]);
    $publish->assign((int)$lead['id'],['merchant_id'=>$onlineMerchant,'assignment_version'=>0]);$receive->action((int)$lead['id'],['action'=>'accept','assignment_version'=>1]);$receive->action((int)$lead['id'],['action'=>'deal','assignment_version'=>1]);
    $co=$onlinePayment->createOrder(['purpose'=>'commission','lead_id'=>$lead['id'],'amount'=>'100.00','request_id'=>'manual-refund-commission']);$coid=(int)$co['id'];$beforePublisher=(string)Db::name('member')->where('member_id',101)->value('commission');
    $coReceipt=mfLegacyReceipt($admin,$co,'RECEIVED-COMMISSION','manual-refund-co-receipt');
    mfCheck($coReceipt['status']==='posted'&&Store::row('collaboration',$site,(int)$lead['id'])['status']==='paid','manual cooperation receipt completes actual lead and publisher settlement');
    $coRefund=$refunds->apply($coid,['confirm'=>true,'reason'=>'合成协作款退款核对完成','request_id'=>'manual-refund-co-approval'],true);
    mfCheck($coRefund['status']==='approved'&&Db::name('member')->where('member_id',101)->value('commission')===$beforePublisher,'manual cooperation approval freezes only original publisher proceeds before actual return');
    $coResult=$confirm->confirm($coid,['refund_no'=>$coRefund['refund_no'],'amount'=>$coRefund['amount'],'method'=>'bank','account_label'=>'Refund fixture bank','external_no'=>'REFUNDED-COMMISSION','received_at'=>time(),'reason'=>'合成协作款已实际退回','request_id'=>'manual-refund-co-confirm','confirm'=>true]);
    mfCheck($coResult['status']==='posted'&&Store::row('collaboration',$site,(int)$lead['id'])['status']==='cancelled'&&Db::name('member')->where('member_id',101)->value('commission')===$beforePublisher,'actual cooperation refund closes the original lead and does not reclaim publisher proceeds twice');
    $proofRefund=Db::name('pay_refund')->where('site_id',$site)->where('refund_no',$refundPayload['refund_no'])->find();
    $pdo->exec('ALTER TABLE lt_hsx_lead_manual_receipt CHANGE target_order_id target_order_unavailable BIGINT UNSIGNED NOT NULL DEFAULT 0');
    try{
        ManualRefundService::metadata($originalPaid,$proofRefund,true);throw new RuntimeException('Metadata silently ignored a database read failure');
    }catch(CommonException$e){mfCheck(str_contains($e->getMessage(),'读取失败')&&!str_contains($e->getMessage(),'Unknown column'),'metadata database failure is explicit and safe, never guessed as no manual receipt');}
    finally{$pdo->exec('ALTER TABLE lt_hsx_lead_manual_receipt CHANGE target_order_unavailable target_order_id BIGINT UNSIGNED NOT NULL DEFAULT 0');}
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'Actual framework offline voucher and refund-success hooks; random owned local DB; no transfers, gateways, notifications or existing data'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$e){$failed=true;fwrite(STDERR,'FAIL manual refund after '.$checks.': '.get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL.$e->getTraceAsString().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
