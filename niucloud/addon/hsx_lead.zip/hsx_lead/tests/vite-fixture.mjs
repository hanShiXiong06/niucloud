/** Resolve build-time values explicitly before executing real Vite sources in a CJS VM. */
export function viteFixture(source, { siteId = '100005', mode = 'production', env = {} } = {}) {
    if (!['production', 'development'].includes(mode)) throw new Error('Unexpected fixture build mode')
    const values = { VITE_SITE_ID: siteId, ...env }
    return source
        .replaceAll('import.meta.env', '(' + JSON.stringify(values) + ')')
        .replaceAll('process.env.NODE_ENV', JSON.stringify(mode))
}
