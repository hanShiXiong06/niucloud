<?php
declare(strict_types=1);

// Independent monetary review: actual pure service, no database or gateway.
require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\cooperation\MembershipCostService as Cost;
use app\dict\pay\RefundDict;
use core\exception\CommonException;

$checks=0;
function ciCheck(bool $ok,string $label):void {if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function ciDeny(callable $run,string $label):void {try{$run();}catch(CommonException $error){ciCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
foreach([true,1,'1'] as $value)ciCheck(Cost::flag($value,'购买经验'),'explicit true only');
foreach([false,0,'0'] as $value)ciCheck(!Cost::flag($value,'购买经验'),'explicit false only');
foreach([null,'false','true','yes',[],2,1.0] as $bad)ciDeny(fn()=>Cost::flag($bad,'购买经验'),'ambiguous request flag rejected');

$tier=['deposit_amount'=>'100.00','experience_purchase_enabled'=>true,'experience_unit_price'=>'0.03','experience_required'=>'200.00'];
$period=['price'=>'99.00'];$experience=['value'=>'199.99'];$deposit=['balance'=>'30.00'];
$quote=Cost::calculate($tier,$period,$experience,$deposit,true,2000);
ciCheck($quote['deposit_required']==='100.00'&&$quote['deposit_balance']==='30.00'&&$quote['deposit_amount']==='70.00','deposit tops up only the shortfall');
ciCheck($quote['service_full_amount']==='99.00'&&$quote['service_credit_amount']==='20.00'&&$quote['service_amount']==='79.00','unused service credit never reduces deposit or experience fees');
ciCheck($quote['experience_quantity']==='0.01'&&$quote['experience_amount']==='0.01','fractional experience purchase rounds a nonzero fee up to a whole cent');
ciCheck($quote['payable_amount']==='149.01'&&$quote['promotion_base_amount']==='79.00','sum equals three components and promotion uses service cash only');
$noBuy=Cost::calculate($tier,$period,$experience,$deposit,false);
ciCheck($noBuy['experience_quantity']==='0.00'&&$noBuy['experience_amount']==='0.00'&&$noBuy['payable_amount']==='169.00','optional purchase is never silently selected');
$alreadyMet=Cost::calculate($tier,$period,['value'=>'300.00'],['balance'=>'150.00'],true);
ciCheck($alreadyMet['experience_quantity']==='0.00'&&$alreadyMet['experience_amount']==='0.00'&&$alreadyMet['deposit_amount']==='0.00','sufficient prior experience and deposit are not charged again');
ciCheck($alreadyMet['payable_amount']==='99.00'&&$alreadyMet['promotion_base_amount']==='99.00','renewal service is distinct from held deposit');
$oneCent=Cost::calculate(array_replace($tier,['experience_required'=>'0.01','experience_unit_price'=>'0.01']),['price'=>'0.01'],['value'=>'0.00'],['balance'=>'100.00'],true);
ciCheck($oneCent['experience_amount']==='0.01'&&$oneCent['payable_amount']==='0.02','one hundredth of a point cannot be bought free through rounding');
$exact=Cost::calculate($tier,$period,['value'=>'0.00'],['balance'=>'0.00'],true);
ciCheck($exact['experience_quantity']==='200.00'&&$exact['experience_amount']==='6.00'&&$exact['payable_amount']==='205.00','integer points keep exact monetary arithmetic');
ciDeny(fn()=>Cost::calculate(array_replace($tier,['experience_purchase_enabled'=>false]),$period,$experience,$deposit,true),'disabled experience buying fails closed');
ciDeny(fn()=>Cost::calculate(array_replace($tier,['experience_unit_price'=>'0.00']),$period,$experience,$deposit,true),'enabled buying requires a positive unit price');
ciDeny(fn()=>Cost::calculate($tier,$period,$experience,$deposit,-1===0,-1),'negative service credit rejected');
ciDeny(fn()=>Cost::calculate($tier,$period,$experience,$deposit,true,9901),'credit cannot exceed service original price');
ciDeny(fn()=>Cost::calculate(array_replace($tier,['deposit_amount'=>'-1']),$period,$experience,$deposit,true),'negative deposit rejected');
ciDeny(fn()=>Cost::calculate(array_replace($tier,['deposit_amount'=>'99999999.99']),['price'=>'0.01'],$experience,['balance'=>'0.00'],true),'total respects framework payment precision');

$rule=$quote+['full_amount'=>'99.00','credit_amount'=>'20.00','experience_required'=>'200.00','experience_value'=>'199.99'];$order=['amount'=>'149.01'];
Cost::assertSnapshot($order,$rule);ciCheck(true,'original pure cost snapshot verifies exactly');
foreach(['deposit_amount','service_amount','experience_amount','promotion_base_amount','payable_amount','experience_quantity'] as $key){$forged=$rule;$forged[$key]='0.00';ciDeny(fn()=>Cost::assertSnapshot($order,$forged),'tampered component rejected: '.$key);}
$forged=$rule;$forged['buy_experience']=false;ciDeny(fn()=>Cost::assertSnapshot($order,$forged),'a caller cannot erase the frozen experience-purchase decision');

$full=[['refund_no'=>'FULL','money'=>'149.01','status'=>RefundDict::SUCCESS]];
$refund=Cost::refundedComponents($order,$rule,$full);
ciCheck($refund['deposit']===7000&&$refund['service']===7900&&$refund['experience']===1&&$refund['quantity']===1&&!$refund['review'],'genuine complete refund reverses each original component without guessing order');
$refund=Cost::refundedComponents($order,$rule,[['refund_no'=>'WAIT','money'=>'5.00','status'=>RefundDict::WAIT]]);
ciCheck($refund['pending']&&$refund['deposit']===0&&$refund['quantity']===0,'refund application is not successful returned money or revoked purchased points');
$partial=[['refund_no'=>'PART','money'=>'5.00','status'=>RefundDict::SUCCESS]];
$refund=Cost::refundedComponents($order,$rule,$partial);
ciCheck($refund['review']&&$refund['deposit']===0&&$refund['service']===0&&$refund['quantity']===0,'unallocated partial refund is held for review rather than called a deposit refund');
$allocated=$rule;$allocated['membership_refund_allocations']=['PART'=>['deposit'=>'5.00','service'=>'0.00','experience'=>'0.00','quantity'=>'0.00']];
$refund=Cost::refundedComponents($order,$allocated,$partial);
ciCheck(!$refund['review']&&$refund['deposit']===500&&$refund['service']===0&&$refund['quantity']===0,'explicit checked allocation can return deposit without reducing unrelated service or points');
$refund=Cost::refundedComponents($order,$allocated,array_merge($partial,$partial));
ciCheck($refund['deposit']===500,'duplicate successful rows for one refund number are counted once');
$conflict=$partial;$conflict[]=['refund_no'=>'PART','money'=>'6.00','status'=>RefundDict::SUCCESS];
ciDeny(fn()=>Cost::refundedComponents($order,$allocated,$conflict),'one refund identity cannot carry inconsistent real amounts');
ciDeny(fn()=>Cost::refundedComponents($order,$rule,[['refund_no'=>'OVER','money'=>'149.02','status'=>RefundDict::SUCCESS]]),'refund cannot exceed actual three-part receipt');
ciDeny(fn()=>Cost::refundedComponents($order,$rule,[['refund_no'=>'NEGATIVE','money'=>'-1.00','status'=>RefundDict::SUCCESS]]),'negative refund cannot manufacture deposit or purchased experience');
echo 'PASS '.$checks." independent three-part membership cost checks; actual integer-pricing service, no database or payment gateway.\n";
