<?php
declare(strict_types=1);

// One-process deterministic clock only. No production source, OS time or DB clock changes.
namespace addon\hsx_lead\app\service\cooperation {
    function time():int {return $GLOBALS['lead_timeout_fixture_now']??\time();}
}
namespace {
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,PaymentService,PaymentOrderLifecycle,EntityMembershipService,Store};
use addon\hsx_lead\app\support\Data;
use addon\hsx_lead\app\listener\pay\{CooperationPaySuccess,CooperationPayCloseGuard};
use app\dict\pay\{PayDict,OnlinePayDict,RefundDict};
use core\exception\CommonException;
use think\facade\{Db,Event};

final class TwoMinutePaymentProvider
{
    public array $calls=[];
    public function __construct(private array$answers,private $closeResult=true){}
    public function getOrder(string$number){$this->calls[]='query:'.$number;$answer=array_shift($this->answers);if($answer instanceof \Throwable)throw$answer;return$answer;}
    public function close(string$number){$this->calls[]='close:'.$number;if($this->closeResult instanceof \Throwable)throw$this->closeResult;return$this->closeResult;}
}
$checks=0;$pdo=null;$schema='';$failed=false;
function tmCheck(bool$condition,string$label):void{if(!$condition)throw new \RuntimeException($label);$GLOBALS['checks']++;}
function tmDeny(callable$fn,string$label):void{try{$fn();}catch(CommonException$e){tmCheck(true,$label);return;}throw new \RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();$now=\time();$GLOBALS['lead_timeout_fixture_now']=$now;
    foreach(['pay','pay_refund']as$table){$official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m))throw new \RuntimeException('Missing official receipt DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);Event::remove('PayClose');Event::listen('PayClose',CooperationPayCloseGuard::class);
    $ctx=new Context($site,0,102);$settings=ConfigService::defaults();$settings['enabled']=true;$settings['publishing_required']=false;$settings['fee_confirmed']=true;$settings['businesses'][0]['commission_minimum']='50.00';(new ConfigService(new Context($site,1)))->save($settings);
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2,false,['cycles'=>[['key'=>'year','name'=>'年付','months'=>12,'enabled'=>true,'price'=>'99.00']]])+['site_id'=>$site]);
    $profile=['name'=>'Synthetic receiver','contact_name'=>'Fixture','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture address'];
    $receiver=(new PartnerService($ctx))->saveProfile($profile);$publisher=(new PartnerService(new Context($site,0,101)))->saveProfile(array_replace($profile,['name'=>'Synthetic publisher','mobile'=>'19900000101']));
    $makeMembership=static function(string$label)use($ctx):array{$quote=(new EntityMembershipService($ctx))->quote('ML701','year');return(new PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'year','request_id'=>'two-minute-member-'.$label,'quote_token'=>$quote['quote_token']]);};
    $createCommission=static function(string$label)use($site,$publisher,$receiver,$ctx):array{
        $lead=(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'TWO_MIN_'.$label,'request_id'=>'two-minute-lead-'.$label,'publisher_id'=>$publisher['id'],'receiver_id'=>$receiver['id'],'status'=>'unpaid','rule_json'=>Data::json(['purpose'=>'commission','fee_percent'=>'10.00','fee_minimum'=>'9.90','commission_minimum'=>'50.00','fee_confirmed'=>true]),'create_time'=>$GLOBALS['lead_timeout_fixture_now'],'update_time'=>$GLOBALS['lead_timeout_fixture_now']]);
        return(new PaymentService($ctx))->createOrder(['purpose'=>'commission','lead_id'=>$lead,'amount'=>'50.00','request_id'=>'two-minute-commission-'.$label]);
    };
    $age=static function(array$order,int$seconds)use($site,$now):array{Store::query('coop_order',$site)->where('id',$order['id'])->update(['create_time'=>$now-$seconds,'update_time'=>$now-$seconds]);return Store::row('coop_order',$site,(int)$order['id']);};
    $receipt=static function(array$order,int$status,string$type='',string$channel='')use($site):array{$no='TWO_MIN_'.bin2hex(random_bytes(10));Db::name('pay')->insert(['site_id'=>$order['site_id'],'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>$order['member_id'],'from_main_id'=>$order['member_id'],'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>$status,'type'=>$type,'channel'=>$channel,'pay_time'=>$GLOBALS['lead_timeout_fixture_now']]);return Db::name('pay')->where('site_id',$order['site_id'])->where('out_trade_no',$no)->find();};
    $state=static fn(string$status):array=>['status'=>$status];

    $membership=$makeMembership('initial');$memberRaw=Store::row('coop_order',$site,(int)$membership['id']);
    tmCheck(PaymentOrderLifecycle::expiresAt($memberRaw)===(int)$memberRaw['create_time']+120,'membership lifetime is exactly creation plus 120 seconds');
    $quoteDifferent=$memberRaw;$quoteRule=Data::decode($quoteDifferent['rule_json']);$quoteRule['quoted_at']=$now-999;$quoteDifferent['rule_json']=Data::json($quoteRule);
    tmCheck(PaymentOrderLifecycle::expiresAt($quoteDifferent)===$quoteRule['quoted_at']+600&&PaymentOrderLifecycle::expiresAt($quoteDifferent)<=(int)$memberRaw['create_time']+120,'an old signed quote can expire earlier but never extends the creation deadline');
    $touched=$memberRaw;$touched['update_time']=$now+3600;tmCheck(PaymentOrderLifecycle::expiresAt($touched)===(int)$memberRaw['create_time']+120,'opening/checking an order does not extend expiry through update_time');
    $life=new PaymentOrderLifecycle($ctx);$age($membership,119);$before=Data::query('audit',$site)->count();$tick=PaymentOrderLifecycle::tick();
    tmCheck($tick['examined']===0&&Store::row('coop_order',$site,(int)$membership['id'])['status']==='unpaid','119 seconds: schedule does not pick membership');
    tmCheck($life->expireOwn((int)$membership['id'])['status']==='unpaid'&&Data::query('audit',$site)->count()===$before,'119 seconds: direct expiry guard also preserves the order');
    $age($membership,120);$tick=PaymentOrderLifecycle::tick();$closed=Store::row('coop_order',$site,(int)$membership['id']);
    tmCheck($tick['closed']===1&&$closed['status']==='closed','120-second boundary is inclusive for membership');
    $closeRule=Data::decode($closed['rule_json']);tmCheck($closeRule['closure']['by']==='timeout'&&$closeRule['closure']['at']===$now,'automatic closure is audited with deterministic time');
    $replacement=$makeMembership('replacement');tmCheck((int)$replacement['id']!==(int)$membership['id']&&$replacement['can_pay'],'verified timeout closure permits a fresh membership purchase');
    $memberTemplate=Store::row('coop_order',$site,(int)$replacement['id']);$age($replacement,121);tmCheck(PaymentOrderLifecycle::tick()['closed']===1,'121 seconds: membership also closes');
    tmCheck(PaymentOrderLifecycle::tick()['examined']===0,'a repeat schedule does not process already closed memberships');
    $memberGateway=$makeMembership('gateway-close');$memberGatewayRaw=$age($memberGateway,121);$memberGatewayPay=$receipt($memberGatewayRaw,(int)PayDict::STATUS_ING,PayDict::WECHATPAY,'weapp');$memberProvider=new TwoMinutePaymentProvider([$state(OnlinePayDict::NOTPAY),$state(OnlinePayDict::CLOSED)]);$memberTick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$memberProvider);
    tmCheck($memberTick['closed']===1&&Store::row('coop_order',$site,(int)$memberGateway['id'])['status']==='closed'&&$memberProvider->calls===['query:'.$memberGatewayPay['out_trade_no'],'close:'.$memberGatewayPay['out_trade_no'],'query:'.$memberGatewayPay['out_trade_no']],'membership prepay timeout also performs full gateway query-close-query');
    tmCheck(!EntityMembershipService::state($site,(int)$receiver['id'])['active'],'cancelled membership cashier does not accidentally grant rights');
    // Keep the synthetic receipt on the same frozen clock as business time.
    $memberPaid=leadMembershipGrant($site,102,'ML701','year',$now);$memberPaidRaw=$age($memberPaid,121);tmCheck(PaymentOrderLifecycle::tick()['examined']===0&&Store::row('coop_order',$site,(int)$memberPaid['id'])['status']==='paid'&&EntityMembershipService::state($site,(int)$receiver['id'])['active'],'already paid membership and granted rights are never timed out');
    $memberReceipt=Db::name('pay')->where('trade_id',$memberPaid['id'])->find();$memberRefund=['site_id'=>$site,'out_trade_no'=>$memberReceipt['out_trade_no'],'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>(string)$memberPaid['id'],'refund_no'=>'TWO_MIN_MEMBER_FULL_REFUND','money'=>$memberPaidRaw['amount'],'status'=>RefundDict::SUCCESS];Db::name('pay_refund')->insert($memberRefund);EntityMembershipService::refund($site,$memberPaidRaw,$memberRefund);
    tmCheck(PaymentOrderLifecycle::tick()['examined']===0&&Store::row('coop_order',$site,(int)$memberPaid['id'])['status']==='paid'&&!EntityMembershipService::state($site,(int)$receiver['id'])['active'],'successfully refunded membership keeps its financial history, not an unpaid timeout cancellation');

    $commission=$createCommission('boundary');$raw=Store::row('coop_order',$site,(int)$commission['id']);tmCheck(PaymentOrderLifecycle::expiresAt($raw)===(int)$raw['create_time']+120,'commission uses the same two-minute deadline');
    $originalLead=Store::row('collaboration',$site,(int)$commission['lead_id']);$age($commission,119);tmCheck(PaymentOrderLifecycle::tick()['examined']===0,'119 seconds: commission remains payable');
    $age($commission,120);$tick=PaymentOrderLifecycle::tick();tmCheck($tick['closed']===1,'120-second boundary is inclusive for commission');
    $afterLead=Store::row('collaboration',$site,(int)$commission['lead_id']);tmCheck($afterLead===$originalLead,'closing a payment does not cancel, delete or mutate the original delivered lead');
    $again=(new PaymentService($ctx))->createOrder(['purpose'=>'commission','lead_id'=>$commission['lead_id'],'amount'=>'50.00','request_id'=>'two-minute-commission-replacement']);
    tmCheck((int)$again['id']!==(int)$commission['id']&&$again['net_amount']===$commission['net_amount']&&$again['fee_amount']===$commission['fee_amount'],'a commission payment can be recreated at frozen price after safe closure');
    $age($again,121);$wait=$receipt(Store::row('coop_order',$site,(int)$again['id']),(int)PayDict::STATUS_WAIT);tmCheck(PaymentOrderLifecycle::tick()['closed']===1,'121-second commission WAIT closes through the framework');
    tmCheck((int)Db::name('pay')->where('id',$wait['id'])->value('status')===(int)PayDict::STATUS_CANCEL,'framework cashier wait record is actually cancelled, not merely hidden');
    tmCheck(Store::row('collaboration',$site,(int)$commission['lead_id'])['status']==='unpaid','original commission obligation remains after repeat timeout');

    $paid=$createCommission('already-paid');$pay=$receipt(Store::row('coop_order',$site,(int)$paid['id']),(int)PayDict::STATUS_FINISH);PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$paid['id'],'out_trade_no'=>$pay['out_trade_no']]);$age($paid,121);
    $paidBefore=Store::row('coop_order',$site,(int)$paid['id']);$tick=PaymentOrderLifecycle::tick();tmCheck($tick['examined']===0&&Store::row('coop_order',$site,(int)$paid['id'])===$paidBefore,'paid order never enters timeout candidates');
    $paidRule=Data::decode($paidBefore['rule_json']);$paidRule['order_refund']=['status'=>'refunding','refund_no'=>'SYNTHETIC_TIMEOUT_REFUND'];Store::query('coop_order',$site)->where('id',$paid['id'])->update(['rule_json'=>Data::json($paidRule)]);
    Db::name('pay_refund')->insert(['site_id'=>$site,'out_trade_no'=>$pay['out_trade_no'],'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>(string)$paid['id'],'refund_no'=>'SYNTHETIC_TIMEOUT_REFUND','money'=>'50.00','status'=>RefundDict::DEALING]);
    tmCheck(PaymentOrderLifecycle::tick()['examined']===0&&Store::row('coop_order',$site,(int)$paid['id'])['status']==='paid','refund processing does not become an unpaid timeout cancellation');

    $unknown=$createCommission('unknown');$unknownRaw=$age($unknown,121);$unknownPay=$receipt($unknownRaw,(int)PayDict::STATUS_ING,PayDict::WECHATPAY,'weapp');$provider=new TwoMinutePaymentProvider([new \RuntimeException('Synthetic provider unavailable')]);
    $tick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$provider);$uncertain=Store::row('coop_order',$site,(int)$unknown['id']);
    tmCheck($tick['closed']===0&&$tick['blocked']===1&&$uncertain['status']==='unpaid'&&Data::decode($uncertain['rule_json'])['close_check']['state']==='uncertain','unknown gateway result preserves original order and records reconciliation status');
    tmCheck($provider->calls===['query:'.$unknownPay['out_trade_no']]&&(int)Db::name('pay')->where('id',$unknownPay['id'])->value('status')===(int)PayDict::STATUS_ING,'unknown result does not send a close request or fabricate CANCEL');
    $provider=new TwoMinutePaymentProvider([$state(OnlinePayDict::NOTPAY),$state(OnlinePayDict::CLOSED)]);$tick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$provider);
    tmCheck($tick['closed']===1&&$provider->calls===['query:'.$unknownPay['out_trade_no'],'close:'.$unknownPay['out_trade_no'],'query:'.$unknownPay['out_trade_no']],'later schedule safely retries original trade and needs post-close CLOSED proof');
    $calls=count($provider->calls);tmCheck(PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$provider)['examined']===0&&count($provider->calls)===$calls,'repeat cron after verified close does not call the provider again');

    $race=$createCommission('payment-race');$raceRaw=$age($race,121);$racePay=$receipt($raceRaw,(int)PayDict::STATUS_ING,PayDict::WECHATPAY,'weapp');$provider=new TwoMinutePaymentProvider([$state(OnlinePayDict::NOTPAY),$state(OnlinePayDict::SUCCESS)]);
    $tick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$provider);tmCheck(Store::row('coop_order',$site,(int)$race['id'])['status']==='paid'&&(int)Db::name('pay')->where('id',$racePay['id'])->value('status')===(int)PayDict::STATUS_FINISH,'successful payment wins a timeout/close race');
    tmCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$race['id'])->count()===1,'timeout reconciliation credits an actual successful commission once');
    PaymentOrderLifecycle::tick();tmCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$race['id'])->count()===1,'repeated schedule cannot duplicate successful payment income');

    $lateReceipt=$createCommission('local-paid-before-callback');$lateRaw=$age($lateReceipt,121);$latePay=$receipt($lateRaw,(int)PayDict::STATUS_FINISH);$tick=PaymentOrderLifecycle::tick();
    tmCheck($tick['closed']===0&&$tick['blocked']===0&&$tick['reconciled']===1&&Store::row('coop_order',$site,(int)$lateReceipt['id'])['status']==='paid'&&(int)Db::name('pay')->where('id',$latePay['id'])->value('status')===(int)PayDict::STATUS_FINISH,'finished cashier receipt replays idempotent business confirmation instead of blocking forever; never cancel collected money');
    tmCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$lateReceipt['id'])->count()===1,'local successful receipt recovery credits publisher exactly once');
    PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$lateReceipt['id'],'out_trade_no'=>$latePay['out_trade_no']]);
    tmCheck(PaymentOrderLifecycle::tick()['reconciled']===0&&Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$lateReceipt['id'])->count()===1,'repeat cron and callback do not duplicate recovery or income');

    $mismatch=$createCommission('mismatched');$mismatchRaw=$age($mismatch,121);$mismatchPay=$receipt($mismatchRaw,(int)PayDict::STATUS_WAIT);Db::name('pay')->where('id',$mismatchPay['id'])->update(['main_id'=>101]);
    $tick=PaymentOrderLifecycle::tick();tmCheck($tick['blocked']===1&&Store::row('coop_order',$site,(int)$mismatch['id'])['status']==='unpaid','mismatched payer cannot authorize cancellation');
    // Repair only this synthetic fixture's receipt so the later bounded-batch test is isolated.
    Db::name('pay')->where('id',$mismatchPay['id'])->update(['main_id'=>102]);PaymentOrderLifecycle::tick();

    $cloneMember=static function(int$targetSite,int$owner,string$label,int$ageSeconds)use($memberTemplate,$now):int{$copy=$memberTemplate;unset($copy['id']);$copy['site_id']=$targetSite;$copy['member_id']=$owner;$copy['merchant_id']=0;$copy['order_no']='TWO_MIN_BATCH_'.$label;$copy['request_id']='two-minute-batch-'.$label;$copy['business_key']='two-minute-batch-'.$label;$copy['out_trade_no']='';$copy['status']='unpaid';$copy['create_time']=$now-$ageSeconds;$copy['update_time']=$now-$ageSeconds;return(int)Db::name('hsx_lead_coop_order')->insertGetId($copy);};
    $refundCount=Db::name('pay_refund')->count();
    $a1=$cloneMember($site,102,'a1',150);$a2=$cloneMember($site,102,'a2',149);$b1=$cloneMember($site+1,103,'b1',148);
    $batch=PaymentOrderLifecycle::tick(1,1);tmCheck($batch['examined']===1&&$batch['closed']===1,'site and order limits bound one cron tick');
    tmCheck(Store::row('coop_order',$site,$a1)['status']==='closed'&&Store::row('coop_order',$site,$a2)['status']==='unpaid'&&Store::row('coop_order',$site+1,$b1)['status']==='unpaid','bounded first site cannot close another site or additional page');
    $batch=PaymentOrderLifecycle::tick(2,1);tmCheck($batch['examined']===2&&$batch['closed']===2&&Store::row('coop_order',$site,$a2)['status']==='closed'&&Store::row('coop_order',$site+1,$b1)['status']==='closed','next bounded tick progresses independent tenant-scoped orders');
    tmCheck(Db::name('pay_refund')->count()===$refundCount,'timeout scheduler never creates a refund');tmCheck(Db::name('hsx_lead_promotion_reward')->count()===0,'timeouts alone create no referral rewards');
    $multiple=$createCommission('multiple-originals');$multipleRaw=$age($multiple,121);$receipt($multipleRaw,(int)PayDict::STATUS_FINISH);$receipt($multipleRaw,(int)PayDict::STATUS_ING,PayDict::WECHATPAY,'weapp');
    $multipleTick=PaymentOrderLifecycle::tick();$multipleCurrent=Store::row('coop_order',$site,(int)$multiple['id']);
    tmCheck($multipleTick['blocked']===1&&$multipleCurrent['status']==='unpaid'&&Data::decode($multipleCurrent['rule_json'])['requires_manual_review']==='multiple_payment_receipts','one paid receipt with another live trade is a real review conflict, not automatic fulfilment');
    tmCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$multiple['id'])->count()===0&&PaymentOrderLifecycle::tick()['reconciled']===0,'ambiguous sibling trades do not create income or have their real review marker cleared by a later sweep');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'deterministic 119/120/121-second local isolated lifecycle, real framework close/payment hooks with synthetic gateway doubles; no production data, real gateway or OS clock changes'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(\Throwable$e){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
finally{unset($GLOBALS['lead_timeout_fixture_now']);if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
}
