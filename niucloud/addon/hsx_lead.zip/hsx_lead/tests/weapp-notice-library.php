<?php
declare(strict_types=1);
require dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\WeappNoticeLibrary;
use core\exception\CommonException;
$checks=0;$calls=[];
function libraryCheck(bool $ok,string $label):void { if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++; }
function libraryDeny(callable $call,string $label):void { try{$call();}catch(CommonException $e){libraryCheck(!str_contains($e->getMessage(),'secret-token'),$label);return;}throw new RuntimeException('Not denied: '.$label); }
$reader=function(int $site,string $path,array $query)use(&$calls):array {
    $calls[]=[$site,$path,$query];
    if($path==='wxaapi/newtmpl/getcategory')return ['errcode'=>0,'data'=>[['id'=>612,'name'=>'信息查询'],['id'=>612,'name'=>'信息查询'],['id'=>null,'name'=>'bad']]];
    if($path==='wxaapi/newtmpl/getpubtemplatetitles')return ['errcode'=>0,'count'=>32,'data'=>[['tid'=>12345,'title'=>'合成工单通知','type'=>2],['tid'=>'bad','title'=>'invalid'],['tid'=>12346,'title'=>'<script>ignored</script>处理结果','type'=>2]]];
    if($path==='wxaapi/newtmpl/getpubtemplatekeywords')return ['errcode'=>0,'data'=>[['kid'=>1,'name'=>'工单编号','rule'=>'character_string','example'=>'TEST-1'],['kid'=>2,'name'=>'状态','rule'=>'phrase'],['kid'=>3,'name'=>'金额','rule'=>'amount'],['kid'=>1000,'name'=>'未知','rule'=>'thing']]];
    throw new RuntimeException('Unexpected path');
};
$library=new WeappNoticeLibrary($reader);
$categories=$library->read(100005);libraryCheck($categories['read_only']&&count($categories['items'])===1&&$categories['items'][0]['id']===612,'categories are account-owned public metadata and deduplicated');
$titles=$library->read(100005,['operation'=>'titles','category_id'=>612,'start'=>0,'limit'=>30]);
libraryCheck(count($titles['items'])===2&&$titles['items'][0]['tid']==='12345'&&$titles['total']===32,'public IDs and pagination are normalized without invented records');
libraryCheck($calls[count($calls)-1][2]===['ids'=>'612','start'=>0,'limit'=>30],'only the official category/title query parameters leave the server');
$fields=$library->read(100006,['operation'=>'keywords','tid'=>'12345']);
libraryCheck($fields['items'][0]['keyword']==='character_string1'&&$fields['items'][1]['keyword']==='phrase2','keyword fields come from official rule plus numeric kid');
libraryCheck(!$fields['items'][2]['supported']&&!$fields['items'][3]['supported'],'unhandled field types and IDs outside current schema remain explicitly unavailable');
libraryCheck($calls[count($calls)-1][0]===100006,'framework client receives explicit current site, not ambient request site');
foreach([['operation'=>'delete'],['operation'=>'keywords','tid'=>'https://bad'],['operation'=>'keywords','tid'=>['secret-token']],['operation'=>'titles','category_id'=>99],['operation'=>'titles','category_id'=>612,'limit'=>31],['operation'=>'titles','category_id'=>612,'start'=>-1],['operation'=>'titles','category_id'=>612,'start'=>'0 OR 1']]as$input)libraryDeny(fn()=>$library->read(100005,$input),'invalid path/ownership/page input is rejected');
libraryDeny(fn()=>$library->read(0),'missing current site is rejected before reading');
foreach([['errcode'=>40164,'errmsg'=>'secret-token'],['data'=>'secret-token'],null,['errcode'=>40013,'data'=>[]]]as$bad){
    $badReader=new WeappNoticeLibrary(fn()=>$bad);libraryDeny(fn()=>$badReader->read(100005),'bad provider reply is safe and never exposes credentials');
}
$failed=new WeappNoticeLibrary(function(){throw new RuntimeException('https://api.weixin.qq.com/?access_token=secret-token');});
libraryDeny(fn()=>$failed->read(100005),'transport exceptions expose no request URL or credential');
libraryCheck(count(array_filter($calls,fn($call)=>!in_array($call[1],['wxaapi/newtmpl/getcategory','wxaapi/newtmpl/getpubtemplatetitles','wxaapi/newtmpl/getpubtemplatekeywords'],true)))===0,'no add/delete/send/token override endpoint exists');
echo 'PASS '.$checks." official template-library adapter checks; synthetic transport only, no credentials, API or database calls.\n";
