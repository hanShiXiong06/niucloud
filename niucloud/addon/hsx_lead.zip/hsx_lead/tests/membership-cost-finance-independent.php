<?php
declare(strict_types=1);

// Independent review of the real services in a disposable owned schema only.
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityExperienceService,EntityMembershipService,MembershipCostService,PartnerService,PaymentService,PromotionRules,PromotionService,Rules,Store};
use addon\hsx_lead\app\listener\pay\MembershipRefundSuccess;
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use core\exception\CommonException;
use think\facade\Db;

$checks=0;$pdo=null;$schema='';$failed=false;
function cfCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function cfDeny(callable $run,string $label):void{try{$run();}catch(CommonException $error){cfCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['pay','pay_refund'] as $table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match);if(empty($match[0]))throw new RuntimeException('Missing checked-in DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));}
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2,false,['deposit_amount'=>'100.00','experience_purchase_enabled'=>true,'experience_unit_price'=>'0.03'])+['site_id'=>$site]);
    Db::name('member_level')->insert(leadMembershipDefinition(702,2,5,false,['deposit_amount'=>'150.00','experience_purchase_enabled'=>true,'experience_unit_price'=>'0.03'])+['site_id'=>$site]);
    $adminCtx=new Context($site,1);$cfg=ConfigService::defaults();$cfg['enabled']=true;$cfg['publishing_required']=true;$cfg['fee_confirmed']=true;(new ConfigService($adminCtx))->save($cfg);
    $owner=102;$ctx=new Context($site,0,$owner);$profile=(new PartnerService($ctx))->saveProfile(['name'=>'Independent cost review','contact_name'=>'Synthetic owner','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);$subject=(int)$profile['id'];
    $personalBefore=Db::name('member')->where('site_id',$site)->where('member_id',$owner)->field('member_id,member_level,growth,growth_get,commission')->find();
    $promotion=new PromotionService($adminCtx);$promotionConfig=PromotionRules::defaults();$promotionConfig['enabled']=true;$promotionConfig['settlement_days']=0;$promotionConfig['sources']['membership']=['enabled'=>true,'normal_rate'=>'25.00','provider_rate'=>'25.00','renewal'=>true];$promotion->saveConfig($promotionConfig);
    $promotion->saveProvider(101,['enabled'=>true,'version'=>PromotionService::provider($site,101)['version']??0,'disabled_mode'=>'blocked','city'=>'Synthetic city','reason'=>'Independent synthetic review']);
    (new PromotionService($ctx))->bind(['mid'=>101,'confirm'=>true]);
    $service=new EntityMembershipService($ctx);$payments=new PaymentService($ctx);
    $raw=static fn(int $id):array=>Store::row('coop_order',$site,$id);
    $receipt=static function(array $order,string $number)use($site,$owner):array{Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>$owner,'from_main_id'=>$owner,'out_trade_no'=>$number,'money'=>$order['amount'],'status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);return ['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$number];};
    $newOrder=static function(string $code,bool $buy,string $request)use($service,$payments):array{$q=$service->quote($code,'month',$buy);if(!$q['can_purchase'])throw new RuntimeException('Fixture quote refused: '.$q['reason']);return $payments->createOrder(['purpose'=>'membership','level_code'=>$code,'cycle'=>'month','buy_experience'=>$buy,'request_id'=>$request,'quote_token'=>$q['quote_token'],'amount'=>'0.01','deposit_amount'=>'0.00','experience_amount'=>'0.00']);};
    cfCheck(!$service->summary()['active']&&EntityExperienceService::summary($site,$subject)['value']==='0.00','initial subject has neither paid rights nor invented experience');
    $firstQuote=$service->quote('ML701','month');cfCheck($firstQuote['deposit_amount']==='100.00'&&$firstQuote['service_amount']==='19.00'&&$firstQuote['experience_amount']==='0.00'&&$firstQuote['payable_amount']==='119.00','opening quote separates deposit and service without preselected paid experience');
    $first=$newOrder('ML701',false,'independent-cost-first');$firstRaw=$raw((int)$first['id']);$firstRule=Data::decode($firstRaw['rule_json']);
    cfCheck($firstRule['schema_version']===EntityMembershipService::SNAPSHOT_SCHEMA&&$firstRule['cost_schema']===MembershipCostService::SCHEMA&&$first['amount']==='119.00','server freezes current cost schema and ignores client-forged fee fields');
    cfCheck(!$service->summary()['active']&&MembershipCostService::balances($site,$subject)['balance']==='0.00','creating an unpaid order grants no deposit balance or membership');
    $firstEvent=$receipt($first,'INDEPENDENT_COST_FIRST');Db::name('pay')->where('out_trade_no','INDEPENDENT_COST_FIRST')->update(['money'=>'19.00']);cfDeny(fn()=>PaymentService::confirm($firstEvent),'a receipt covering only service cannot fake the combined deposit receipt');
    cfCheck($raw((int)$first['id'])['status']==='unpaid','mismatched receipt does not mark the order paid');Db::name('pay')->where('out_trade_no','INDEPENDENT_COST_FIRST')->update(['money'=>'119.00']);PaymentService::confirm($firstEvent);
    cfCheck($service->summary()['active']&&$service->summary()['level_code']==='ML701'&&MembershipCostService::balances($site,$subject)['balance']==='100.00','matching combined receipt activates rights and records held deposit');
    cfCheck(EntityExperienceService::summary($site,$subject)['value']==='0.00','deposit and membership service purchases are not delivery experience');
    $reward=Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$first['id'])->find();cfCheck($reward&&$reward['base_amount']==='19.00'&&$reward['amount']==='4.75','opening promotion excludes the refundable hundred-yuan deposit');
    PaymentService::confirm($firstEvent);cfCheck(Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$first['id'])->count()===1&&MembershipCostService::balances($site,$subject)['balance']==='100.00','callback replay cannot award or deposit twice');
    $renew=$service->quote('ML701','month');cfCheck($renew['deposit_amount']==='0.00'&&$renew['service_amount']==='19.00'&&$renew['payable_amount']==='19.00','renewal does not collect an already sufficient held deposit');
    $blocked=$service->quote('ML702','month',false);cfCheck(!$blocked['can_purchase']&&$blocked['experience_quantity']==='0.00','buying experience is a voluntary explicit decision');
    $upgradeQuote=$service->quote('ML702','month',true);cfCheck($upgradeQuote['can_purchase']&&$upgradeQuote['deposit_amount']==='50.00'&&$upgradeQuote['experience_quantity']==='200.00'&&$upgradeQuote['experience_amount']==='6.00','upgrade adds only deposit difference and explicitly prices the true experience shortfall');
    $expected=Rules::cents($upgradeQuote['deposit_amount'])+Rules::cents($upgradeQuote['service_amount'])+Rules::cents($upgradeQuote['experience_amount']);cfCheck($expected===Rules::cents($upgradeQuote['payable_amount'])&&$upgradeQuote['promotion_base_amount']===$upgradeQuote['service_amount'],'upgrade total and promotion base balance without treating deposit or experience as distributable service');
    cfDeny(fn()=>$payments->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','buy_experience'=>false,'request_id'=>'independent-cost-no-consent','quote_token'=>$upgradeQuote['quote_token']]),'a signed experience-buy quote cannot be used without the same explicit decision');
    $upgrade=$newOrder('ML702',true,'independent-cost-upgrade');$upgradeRaw=$raw((int)$upgrade['id']);$upgradeRule=Data::decode($upgradeRaw['rule_json']);cfCheck(EntityExperienceService::summary($site,$subject)['value']==='0.00'&&$service->summary()['level_code']==='ML701','an unpaid upgrade cannot pregrant points or higher-tier capacity');
    $payments->assertPayable((int)$upgrade['id']);$upgradeEvent=$receipt($upgrade,'INDEPENDENT_COST_UPGRADE');PaymentService::confirm($upgradeEvent);
    $xp=EntityExperienceService::summary($site,$subject);cfCheck($xp['value']==='200.00'&&$xp['purchased_value']==='200.00'&&$xp['earned_value']==='0.00','experience becomes available only after matching real-status receipt and identifies purchased versus earned');
    cfCheck($service->summary()['active']&&$service->summary()['level_code']==='ML702'&&MembershipCostService::balances($site,$subject)['balance']==='150.00','confirmed upgrade grants configured tier and cumulative deposit balance');
    $upgradeReward=Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$upgrade['id'])->find();cfCheck($upgradeReward&&Rules::cents($upgradeReward['base_amount'])===Rules::cents($upgradeRule['service_amount'])&&Rules::cents($upgradeReward['amount'])===PromotionRules::reward(Rules::cents($upgradeRule['service_amount']),'25.00'),'upgrade promotion excludes both fifty-yuan deposit top-up and six-yuan point purchase');
    PaymentService::confirm($upgradeEvent);cfCheck(EntityExperienceService::summary($site,$subject)['purchased_value']==='200.00'&&MembershipCostService::balances($site,$subject)['balance']==='150.00','repeated successful callback never purchases experience or deposit twice');
    $number='INDEPENDENT_COST_FULL_REFUND';Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>$number,'out_trade_no'=>'INDEPENDENT_COST_UPGRADE','money'=>$upgrade['amount'],'status'=>RefundDict::SUCCESS]);$refundEvent=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'refund_no'=>$number];(new MembershipRefundSuccess())->handle($refundEvent);PromotionService::refund($refundEvent);
    cfCheck(MembershipCostService::balances($site,$subject)['balance']==='100.00'&&EntityExperienceService::summary($site,$subject)['purchased_value']==='0.00','full upgrade refund returns its deposit top-up and removes its purchased experience only');
    cfCheck($service->summary()['active']&&$service->summary()['level_code']==='ML701'&&$raw((int)$upgrade['id'])['status']==='paid','refund preserves original paid receipt and restores prior purchased entitlement');
    (new MembershipRefundSuccess())->handle($refundEvent);cfCheck(MembershipCostService::balances($site,$subject)['balance']==='100.00'&&EntityExperienceService::summary($site,$subject)['value']==='0.00','full-refund callback replay never deducts twice');
    $partialOrder=$newOrder('ML702',true,'independent-cost-partial');$partialEvent=$receipt($partialOrder,'INDEPENDENT_COST_PARTIAL');PaymentService::confirm($partialEvent);$partialNo='INDEPENDENT_COST_UNKNOWN_PART';Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>$partialNo,'out_trade_no'=>'INDEPENDENT_COST_PARTIAL','money'=>'1.00','status'=>RefundDict::SUCCESS]);(new MembershipRefundSuccess())->handle(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'refund_no'=>$partialNo]);
    cfCheck(MembershipCostService::balances($site,$subject)['review_required']&&!$service->quote('ML701','month')['can_purchase'],'unallocated partial refund blocks further fees instead of guessing which cash or points were refunded');
    $partialRule=Data::decode($raw((int)$partialOrder['id'])['rule_json']);cfCheck(!empty($partialRule['requires_manual_review'])&&$raw((int)$partialOrder['id'])['status']==='paid','uncertain component refund stays paid with an explicit reconciliation flag');
    $personalAfter=Db::name('member')->where('site_id',$site)->where('member_id',$owner)->field('member_id,member_level,growth,growth_get,commission')->find();cfCheck($personalAfter===$personalBefore,'subject service/deposit/experience never rewrites the personal level, growth or payer commission');
    cfCheck(Db::name('pay_refund')->where('site_id',$site)->count()===2,'tests invoked refund-success handling only; no service auto-initiated extra refund or gateway transaction');
    leadAssertIsolated($schema);echo 'PASS '.$checks." independent cost/payment/promotion/refund checks; real services, disposable localhost schema and synthetic verified-status receipts, no gateway or current business data.\n";
}catch(Throwable $error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
