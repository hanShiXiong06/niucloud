import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),ts=require('typescript'),sass=require('sass'),postcss=require('postcss'),pre=require('@dcloudio/uni-cli-shared'),{renderToString}=require('@vue/server-renderer')
const filename=path.join(plugin,'uni-app/components/cooperation/CoopTaskSheet.vue'),source=fs.readFileSync(filename,'utf8'),parsed=sfc.parse(source,{filename})
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++}
check(!parsed.errors.length,'shared sheet SFC parses')
function component(inlineTemplate=true){
    const script=sfc.compileScript(parsed.descriptor,{id:'sheet-size',inlineTemplate}),module={exports:{}}
    const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{})(key=>{
        if(key==='vue')return Vue
        if(key==='./CooperationNav.vue')return{default:{render:()=>Vue.h('header',{},'navigation')}}
        throw Error('Unexpected sheet dependency '+key)
    },module,module.exports)
    return module.exports.default
}
async function html(props,footer=true){
    const slots={default:()=>Vue.h('article',{},'scrollable-content'),filters:()=>Vue.h('form',{},'search-filters'),...(footer?{footer:()=>Vue.h('button',{},'primary-action')}:{})}
    const app=Vue.createSSRApp({render:()=>Vue.h(component(),props,slots)});app.config.warnHandler=()=>{}
    app.component('u-popup',{props:['show','safeAreaInsetBottom'],setup:(props,{slots})=>()=>props.show?Vue.h('aside',{'data-safe-bottom':String(props.safeAreaInsetBottom)},slots.default?.()):null})
    app.component('u-icon',{render:()=>Vue.h('i')})
    return renderToString(app)
}
for(const page of [true,false])for(const fixedBody of [true,false]){
    const out=await html({page,fixedBody,show:true,title:'库存任务',full:true})
    check(out.includes('scrollable-content')&&out.includes('search-filters')&&out.includes('primary-action'),'actual '+(page?'page':'popup')+' renders body, filter and footer')
    check(out.indexOf('coop-sheet__filters')<out.indexOf('coop-sheet__body')&&out.indexOf('primary-action')>out.indexOf('scrollable-content'),'filters precede body and footer follows it in normal flow')
    check(!out.includes('coop-sheet__safe-end'),'a real footer does not reserve a second bottom-safe placeholder')
    check(fixedBody?out.includes('coop-sheet__body--fixed')&&!out.includes('<scroll-view'):out.includes('<scroll-view'),'pager uses one fixed flex body while ordinary forms retain one scroll-view')
    if(!page)check(out.includes('data-safe-bottom="false"'),'u-popup does not add a second independent bottom-safe inset')
    const noFooter=await html({page,fixedBody,show:true,title:'overview',full:true},false)
    check(noFooter.includes('coop-sheet__safe-end')&&!noFooter.includes('primary-action'),'no-footer page still reserves exactly one bottom-safe spacer')
}
check(!(await html({page:true,show:false,title:'closed'})).includes('coop-sheet'),'closed routed sheet cannot become an active flex sibling')
const closed=await html({page:false,show:false,title:'closed'})
check(closed.includes('coop-popup-mount')&&!closed.includes('coop-sheet__body'),'closed popup retains only its zero-height owned mount')
const emitted=[],props=Vue.reactive({show:true,title:'task',busy:true}),state=component(false).setup(props,{expose(){},emit:(...event)=>emitted.push(event)})
state.close();check(!emitted.length,'busy operation still blocks accidental close');props.busy=false;state.close();check(emitted.length===1&&emitted[0][0]==='close','normal close remains one explicit action')
function css(platform){pre.initPreContext(platform);return postcss.parse(sass.compileString(pre.preCss(parsed.descriptor.styles[0].content)).css)}
function resolve(root,classes,dynamic=true){
    const result={},specificity={}
    root.walkRules(rule=>{
        if(!dynamic&&rule.parent.type==='atrule'&&rule.parent.name==='supports')return
        for(const selector of rule.selectors){
            if(!/^(?:\.[\w-]+)+$/.test(selector.trim()))continue
            const names=selector.match(/[\w-]+/g),weight=names.length
            if(!names.every(name=>classes.includes(name)))continue
            for(const declaration of rule.nodes.filter(node=>node.type==='decl'))if(weight>=(specificity[declaration.prop]||0)){result[declaration.prop]=declaration.value;specificity[declaration.prop]=weight}
        }
    })
    return result
}
const web=css('h5'),mini=css('mp-weixin');pre.initPreContext('h5')
for(const [root,label]of [[web,'H5'],[mini,'Mini Program']])for(const dynamic of [true,false]){
    const page=resolve(root,['coop-sheet','is-full','is-page'],dynamic)
    check(page.height==='100%'&&page['max-height']==='100%'&&page.flex==='1 1 0'&&page['min-height']==='0',label+' page uses the allocated parent height, never an extra viewport (dynamic='+dynamic+')')
}
check(resolve(web,['coop-sheet'],false).height==='86vh'&&resolve(web,['coop-sheet','is-full'],false).height==='100vh','older H5 browsers retain explicit vh fallback sizes')
check(resolve(web,['coop-sheet'],true).height==='86dvh'&&resolve(web,['coop-sheet','is-full'],true).height==='100dvh','modern H5 popup follows dynamic visible viewport, including full popup')
check(!mini.toString().includes('dvh'),'native WXSS does not receive unsupported dynamic viewport declarations')
const body=resolve(web,['coop-sheet__body','coop-sheet__body--fixed']),footer=resolve(web,['coop-sheet__footer']),mount=resolve(web,['coop-popup-mount'])
check(body['min-height']==='0'&&body.height==='0'&&body.flex==='1 1 0'&&body.display==='flex'&&body.overflow==='hidden','fixed sheet body alone flexes/shrinks and hosts a child pager, not a second viewport')
check(footer.flex==='none'&&!footer.position&&footer.padding.includes('env(safe-area-inset-bottom)'),'footer occupies normal flex flow and alone includes its safe area')
check(mount.height==='0'&&mount.flex==='none'&&mount.overflow==='visible','closed framework transition root cannot divide page flex space or clip an active fixed popup')
const allPadding=[];web.walkRules(rule=>{if(rule.selector==='.coop-sheet__footer')rule.walkDecls('padding',decl=>allPadding.push(decl.value))})
check(allPadding[0]==='12px 16px'&&allPadding.at(-1).includes('env('),'footer retains usable padding even where env() is unsupported')
check((source.match(/class="coop-sheet__body coop-sheet__body--fixed" @touchmove\.stop/g)||[]).length===2,'fixed/pager body stops bubbling before the popup root preventDefault handler, allowing its own touch scrolling')
const inventory=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopStoreInventory.vue'),'utf8')
check(inventory.includes(':fixed="false"')&&inventory.includes(':use-page-scroll="false"')&&inventory.includes('height="100%"')&&inventory.includes(':safe-area-inset-bottom="false"'),'inventory is an embedded pager: parent-body height, no page scrolling or duplicate safe-area reservation')
check(!/100(?:d)?vh/.test(inventory)&&inventory.includes('flex:1 1 0;height:100%;min-height:0'),'inventory never claims an extra viewport below its filters/footer')
for(const page of ['membership','entity','catalog']){
    const file=path.join(plugin,'uni-app/pages',page,'index.vue'),value=fs.readFileSync(file,'utf8'),descriptor=sfc.parse(value,{filename:file}).descriptor
    pre.initPreContext('h5')
    const pageCss=postcss.parse(sass.compileString(pre.preCss(descriptor.styles.map(style=>style.content).join('\n'))).css)
    const fallback=resolve(pageCss,[page+'-page'],false),dynamic=resolve(pageCss,[page+'-page'],true)
    check(fallback.height==='calc(100vh - var(--window-top, 0px) - var(--window-bottom, 0px))'&&dynamic.height==='calc(100dvh - var(--window-top, 0px) - var(--window-bottom, 0px))',page+' supplies a definite parent height after framework top/bottom reservations, with dynamic fallback')
    check(fallback['min-height']==='0'&&fallback.display==='flex'&&fallback['flex-direction']==='column'&&fallback.overflow==='hidden'&&fallback['box-sizing']==='border-box',page+' parent shrinks rather than forcing content/footer past the visible viewport')
    if(page!=='catalog'){
        const sheetTag=descriptor.template.content.match(/<CoopTaskSheet\b[^>]*>/)?.[0]||''
        check(sheetTag.includes(' page ')&&!sheetTag.includes('fixed-body'),page+' keeps its long ordinary content in TaskSheet scroll-view instead of locking it in a fixed body')
    }
    if(page==='membership')check(descriptor.template.content.includes('#footer')&&fallback.height!==undefined,'membership keeps its existing normal-flow payment footer and independent scrolling content')
    if(page==='entity')check(!resolve(pageCss,['entity-content']).padding.includes('env('),'entity content does not duplicate the sheet-owned bottom-safe inset')
}
pre.initPreContext('h5')
const profileSource=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopProfilePanel.vue'),'utf8'),profileDescriptor=sfc.parse(profileSource).descriptor
const profileBlock=profileDescriptor.styles.find(style=>style.content.includes('.coop-profile-theme.is-page-panel'))
const profileCss=postcss.parse(sass.compileString(profileBlock.content).css),profilePage=resolve(profileCss,['coop-profile-theme','is-page-panel']),profileEmbedded=resolve(profileCss,['coop-profile-theme'])
check(profilePage.height==='100%'&&profilePage['min-height']==='0'&&profilePage.flex==='1 1 0'&&profilePage.display==='flex','extra profile wrapper propagates allocated page height to its sheet')
check(!profileEmbedded.height&&!profileEmbedded.display,'ordinary profile/DIY wrapper keeps intrinsic non-fullscreen layout')
const callers=['CoopPublishForm','CoopStorePicker','CoopTaskDetail','CoopCommissionForm','CoopConnectionPanel','CoopPromotionPanel','ModelCatalogPicker','CoopStoreInventory']
for(const name of callers){const value=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation',name+'.vue'),'utf8');check(/^<template>\s*<CoopTaskSheet\b/.test(value),name+' has no extra unbounded wrapper between task parent and page sheet')}
console.log(`PASS ${checks} task-sheet sizing checks; actual Vue SSR and platform-preprocessed CSS cascade, synthetic props only; real browser geometry requires separate acceptance.`)
