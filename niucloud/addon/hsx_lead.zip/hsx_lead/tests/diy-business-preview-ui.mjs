import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Real admin/renderer SFC setup with paired synthetic Window objects. No actual
// window, browser, credential, request transport, DB, saved DIY or publication.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const clone=value=>JSON.parse(JSON.stringify(value))
function moduleOf(source,deps={},globals={}){const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Date,Number,String,Object,Array,JSON,Set,Map,Promise,URL,console,...globals})(key=>key in deps?deps[key]:('../'+key) in deps?deps['../'+key]:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected import '+key)})(),module,module.exports);return module.exports}
const adminHelper=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/diyBusinessPreview.ts'),'utf8'))
const mobileHelper=moduleOf(fs.readFileSync(path.join(plugin,'uni-app/utils/diy-business-preview.ts'),'utf8'))
const presets=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/diyPresets.ts'),'utf8'))
const roleEntry=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/roleEntry.ts'),'utf8'))
const navigation=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/navigation.ts'),'utf8'))
const mobileRoutes=moduleOf(fs.readFileSync(path.join(plugin,'uni-app/api/cooperation.ts'),'utf8'),{'@/utils/request':{default:{}}}).cooperationPageUrls
check(adminHelper.BUSINESS_PREVIEW_REQUEST===mobileHelper.BUSINESS_PREVIEW_REQUEST&&adminHelper.BUSINESS_PREVIEW_RESULT===mobileHelper.BUSINESS_PREVIEW_RESULT,'both plugin endpoints share the exact bounded preview protocol')
check(mobileHelper.previewParentOrigin('')===''&&mobileHelper.previewParentOrigin('data:text/html,test')==='','missing or opaque parent origins never fall back to wildcard')
const config={enabled:true,fee_percent:'secret-percent',customer_mobile:'private-customer',businesses:[{key:'purchase',name:'二手机',enabled:true,commission_minimum:'secret-fee'},{key:'broadband',name:'宽带',enabled:true,fields:[{key:'private',label:'private-field'}]},{key:'disabled',name:'不应预览',enabled:false}]}
const projected=adminHelper.enabledPreviewBusinesses(config)
check(JSON.stringify(projected)==='[{"key":"purchase","name":"二手机"},{"key":"broadband","name":"宽带"}]','only enabled names and keys are projected from the existing authorized configuration read')
check(mobileHelper.readBusinessPreview({type:mobileHelper.BUSINESS_PREVIEW_RESULT,state:'ready',items:[{key:'purchase',name:'业务',fee:999}],message:''})===null,'a metadata item carrying fee or other extra fields is rejected')

const descriptors={}
for(const [key,file]of Object.entries({admin:'admin/views/diy/components/edit-lead-cooperation-entry.vue',child:'uni-app/components/cooperation/CoopBusinessNavigation.vue'})){const filename=path.join(plugin,file),parsed=compiler.parse(fs.readFileSync(filename,'utf8'),{filename});assert.deepEqual(parsed.errors,[]);const script=compiler.compileScript(parsed.descriptor,{id:key});assert.deepEqual(compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:key,compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors,[]);descriptors[key]=script.content;checks+=2}
function fixture(){
    const queue=[],outgoing=[],requests=[],navigations=[],adminListeners=new Set(),childListeners=new Set(),timers=new Map();let timerId=0,reads=0,memberReads=0
    const user=Vue.reactive({siteInfo:{site_id:100005},rules:['hsx_lead_cooperation_config']})
    const value={id:'entry',componentName:'LeadCooperationEntry',title:'保留标题',subtitle:'说明',storeTitle:'找门店',customerTitle:'找客户',showBusinesses:1,animate:1,panelColor:'#eef5ff',titleColor:'#243b5b',textColor:'#718199',storeImage:'',customerImage:'',ignore:[]}
    const editor=Vue.reactive({editTab:'content',currentIndex:0,value:[clone(value)],get editComponent(){return this.value[this.currentIndex]}})
    const childStore=Vue.reactive({mode:'decorate',value:[clone(value)]})
    const adminWindow={location:{href:'http://admin.example.test/site/decorate/edit'},addEventListener:(_type,listener)=>adminListeners.add(listener),removeEventListener:(_type,listener)=>adminListeners.delete(listener),postMessage(data,origin){requests.push({data:clone(data),origin});queue.push(()=>{for(const listener of adminListeners)listener({source:childWindow,origin:'http://preview.example.test',data})})}}
    const childWindow={parent:adminWindow,addEventListener:(_type,listener)=>childListeners.add(listener),removeEventListener:(_type,listener)=>childListeners.delete(listener),postMessage(data,origin){outgoing.push({data:clone(data),origin});queue.push(()=>{for(const listener of childListeners)listener({source:adminWindow,origin:'http://admin.example.test',data})})}}
    const frame={src:'http://preview.example.test/wap/100005/addon/hsx_lead/pages/index?mode=decorate',contentWindow:childWindow}
    let work=async()=>({data:clone(config)})
    const common={setTimeout:callback=>{timers.set(++timerId,callback);return timerId},clearTimeout:id=>timers.delete(id)}
    function setup(kind,{referrer='http://admin.example.test/site/decorate/edit'}={}){
        const mounted=[],cleanups=[],hooks={...Vue,onMounted:callback=>mounted.push(callback),onBeforeUnmount:callback=>cleanups.push(callback)}
        const deps=kind==='admin'?{vue:hooks,'@/stores/modules/diy':{default:()=>editor},'@/stores/modules/user':{default:()=>user},'../../../api/cooperation':{getCooperationConfig:async()=>{reads++;return work(user.siteInfo.site_id)}},'../../../composables/navigation':navigation,'../../../composables/diyBusinessPreview':adminHelper}:{vue:hooks,'@/app/stores/diy':{default:()=>childStore},'@/utils/common':{img:String,getToken:()=> 'synthetic-member'},'../../../api/cooperation':{cooperationBootstrap:async()=>{memberReads++;return{data:{config:clone(config)}}},cooperationPageUrls:mobileRoutes,coopError:String},'../../../utils/interaction-feedback':{interactionFeedback(){}},'../../../utils/diy-business-preview':mobileHelper,'../../../static/cooperation/visuals/store-discovery.png':{default:'/store.png'},'../../../static/cooperation/visuals/delivery-capability.png':{default:'/capability.png'}}
        deps['element-plus']={ElMessageBox:{confirm:async()=>{}}};deps['../../../composables/diyPresets']=presets;deps['../../utils/cooperation-business-cache']=loadMobileUtility('cooperation-business-cache');deps['../../../utils/cooperation-diy-style']=loadMobileUtility('cooperation-diy-style');deps['../../cooperation/CoopBusinessIcon.vue']={default:{}}
        deps['../../../composables/roleEntry']=roleEntry
        deps['../../utils/cooperation-business-presentation']=loadMobileUtility('cooperation-business-presentation')
        const module=moduleOf(descriptors[kind],deps,{...common,window:kind==='admin'?adminWindow:childWindow,document:kind==='admin'?{getElementById:()=>frame}:{referrer},uni:{navigateTo:route=>navigations.push(route)}})
        const state=module.default.setup(kind==='admin'?{value:editor.value[0]}:{appearance:childStore.value[0]},{emit(){},expose(){}})
        return{state,mount:()=>mounted.forEach(callback=>callback()),unmount:()=>cleanups.forEach(callback=>callback())}
    }
    async function settle(){for(let index=0;index<12;index++){while(queue.length)queue.shift()();await Promise.resolve();await Vue.nextTick()}}
    return{setup,settle,user,editor,childStore,adminWindow,childWindow,frame,outgoing,requests,navigations,adminListeners,childListeners,timers,get reads(){return reads},get memberReads(){return memberReads},setWork:next=>{work=next}}
}
const f=fixture(),child=f.setup('child');child.mount();await f.settle()
check(f.requests.length===1&&f.reads===0&&f.memberReads===0,'decorated child sends one metadata handshake and never invokes member bootstrap')
for(const timer of f.timers.values())timer();await f.settle();check(f.requests.length===1&&child.state.previewMessage.value.includes('选中本组件'),'waiting timeout gives a bounded connection hint without resending requests')
const editor=f.setup('admin');editor.mount();await f.settle()
check(f.reads===1&&child.state.businesses.value.length===2,'an editor opened after the child still pushes actual authorized metadata')
check(f.outgoing.every(row=>row.origin==='http://preview.example.test')&&f.requests.every(row=>row.origin==='http://admin.example.test'),'both directions use exact target origins, never wildcard')
check(!JSON.stringify(f.outgoing).includes('secret')&&!JSON.stringify(f.outgoing).includes('private')&&f.outgoing.every(row=>row.data.items.every(item=>Object.keys(item).sort().join(',')==='key,name')),'frame messages contain no config fees, fields, customer data or credentials')
const savedEditor=JSON.stringify(f.editor.value),savedChild=JSON.stringify(f.childStore.value)
f.childStore.value[0].showBusinesses=0;check(!(child.state.settings.value.showBusinesses&&child.state.businesses.value.length),'the existing switch hides real preview business entries')
f.childStore.value[0].showBusinesses=1;check(!!(child.state.settings.value.showBusinesses&&child.state.businesses.value.length),'the switch shows the enabled names when turned on')
check(JSON.stringify(f.editor.value)===savedEditor&&JSON.stringify(f.childStore.value)===savedChild,'preview metadata never enters persisted DIY value/global')
const outgoingBefore=f.outgoing.length
for(const listener of f.adminListeners){listener({source:{},origin:'http://preview.example.test',data:{type:adminHelper.BUSINESS_PREVIEW_REQUEST}});listener({source:f.childWindow,origin:'http://evil.example.test',data:{type:adminHelper.BUSINESS_PREVIEW_REQUEST}})}
check(f.outgoing.length===outgoingBefore,'admin rejects requests with either the wrong frame source or wrong origin')
for(const listener of f.childListeners){listener({source:{},origin:'http://admin.example.test',data:adminHelper.businessPreview('ready',[{key:'forged',name:'伪造'}])});listener({source:f.adminWindow,origin:'http://evil.example.test',data:adminHelper.businessPreview('ready',[{key:'forged',name:'伪造'}])})}
check(child.state.businesses.value[0].key==='purchase','child rejects data with either wrong source or origin')
child.unmount();check(f.childListeners.size===0&&f.timers.size===0,'child teardown removes its listener and timeout')
const remount=f.setup('child');remount.mount();await f.settle();check(remount.state.businesses.value.length===2&&f.reads===1,'child remount reuses the editor snapshot without another configuration request')
remount.state.publish('purchase');check(f.navigations.length===0,'business metadata in decoration cannot navigate or publish through preview buttons')
f.user.rules=[];await f.settle();check(f.reads===1&&remount.state.businesses.value.length===0&&remount.state.previewMessage.value.includes('没有业务配置查看权限'),'permission revocation clears cached metadata without making an unauthorized read')
f.setWork(async()=>{throw Error('private backend error')});f.user.rules=['hsx_lead_cooperation_config'];await f.settle();check(f.reads===2&&remount.state.previewMessage.value.includes('读取失败')&&!remount.state.previewMessage.value.includes('private'),'read failure is explicit and does not forward backend details')
await f.settle();await f.settle();check(f.reads===2,'failure does not cause polling or repeated automatic requests')
f.setWork(async()=>({data:clone(config)}));await editor.state.loadPreview();await f.settle();check(f.reads===3&&remount.state.businesses.value.length===2,'a deliberate refresh reads once and recovers without changing the decoration')
let resolveOld
f.setWork(site=>site===100005?new Promise(resolve=>{resolveOld=resolve}):Promise.resolve({data:{businesses:[{key:'new_phone',name:'新站业务',enabled:true}]}}))
const oldRead=editor.state.loadPreview();await f.settle();f.user.siteInfo.site_id=100006;f.frame.src=f.frame.src.replace('100005','100006');await f.settle()
check(remount.state.businesses.value[0].name==='新站业务','site change clears old preview and reads the current site context')
const afterSite=f.outgoing.length;resolveOld({data:clone(config)});await oldRead;await f.settle();check(f.outgoing.length===afterSite&&remount.state.businesses.value[0].name==='新站业务','a late old-site response cannot overwrite or resend old-site metadata')
let resolveFinal
f.setWork(()=>new Promise(resolve=>{resolveFinal=resolve}));const finalRead=editor.state.loadPreview();await f.settle();const beforeUnmount=f.outgoing.length;editor.unmount();resolveFinal({data:clone(config)});await finalRead;await f.settle()
check(f.adminListeners.size===0&&f.outgoing.length===beforeUnmount,'editor destruction removes its listener and drops late configuration responses')
remount.unmount()
const missing=fixture(),unconnected=missing.setup('child',{referrer:''});unconnected.mount();await missing.settle();check(missing.requests.length===0&&unconnected.state.previewMessage.value.includes('未连接管理端'),'missing referrer fails closed with a clear connection message');unconnected.unmount()
const normal=fixture();normal.childStore.mode='';const production=normal.setup('child');production.mount();await normal.settle();check(normal.childListeners.size===0&&normal.requests.length===0&&normal.memberReads===1,'normal authenticated business block uses one member read without an editor channel');production.state.publish('purchase');check(normal.navigations[0].url.includes('task=publish&business_type=purchase'),'shared business selection retains its real publishing route');production.unmount()
const denied=fixture();denied.user.rules=[];const deniedEditor=denied.setup('admin');deniedEditor.mount();await denied.settle();check(denied.reads===0&&deniedEditor.state.previewMessage.value.includes('没有业务配置查看权限'),'initial permission denial never invokes the configuration API');deniedEditor.unmount()
const parentFirst=fixture(),firstEditor=parentFirst.setup('admin');firstEditor.mount();await parentFirst.settle();const lateChild=parentFirst.setup('child');lateChild.mount();await parentFirst.settle();check(parentFirst.reads===1&&lateChild.state.businesses.value.length===2,'an iframe child opened after the editor receives the cached metadata without another GET');lateChild.unmount();firstEditor.unmount()
const uniRequire=createRequire(path.resolve(plugin,'../../../uni-app/package.json')),preprocessor=uniRequire('@dcloudio/uni-cli-shared')
preprocessor.initPreContext('mp-weixin');const miniScript=preprocessor.preJs(descriptors.child);preprocessor.initPreContext('h5')
check(!miniScript.includes('window.addEventListener')&&!miniScript.includes('window.removeEventListener')&&!miniScript.includes('window.parent'),'actual uni platform preprocessing removes the entire browser frame channel from Mini Program code')
console.log(`PASS ${checks} DIY business-preview checks; real plugin helpers/SFCs with paired synthetic windows, no browser/API/database or persisted decoration operations.`)
