import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const mobile = path.join(plugin, 'uni-app'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const { compile } = require('@vue/compiler-dom'), { renderToString } = require('@vue/server-renderer')
let checks = 0
const check = (condition, label) => { assert.ok(condition, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
const { erpProviderDisplayName } = loadMobileUtility('erp-provider-display')
const providers = Vue.reactive([{ key: 'soujike', name: '过时的品牌名', display_name: '星河平台', fields: [{ key: 'username', label: '登录手机号', required: true }], auth_modes: [{ key: 'password', fields: [{ key: 'username', label: '登录手机号', required: true }], renewal: { automatic: true } }] }])
equal(erpProviderDisplayName('soujike', providers, '旧连接名'), '星河平台', 'site display_name takes priority over stale name/connection text')
equal(erpProviderDisplayName('unknown-key', [], ''), 'ERP平台', 'missing definitions do not expose a technical provider key')
equal(erpProviderDisplayName('closed', [], '冬日平台'), '冬日平台', 'closed source uses its server-provided display label')
const inputBefore = JSON.stringify(providers)
erpProviderDisplayName('soujike', providers)
equal(JSON.stringify(providers), inputBefore, 'display lookup never mutates schema, source key or credentials')

function component(name, props) {
    const file = path.join(mobile, 'components/cooperation', name + '.vue'), source = fs.readFileSync(file, 'utf8'), parsed = compiler.parse(source, { filename: file })
    check(!parsed.errors.length, name + ' actual SFC parses')
    const script = compiler.compileScript(parsed.descriptor, { id: 'provider-display' })
    const template = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'provider-display', compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
    check(!template.errors.length, name + ' actual template compiles')
    const module = { exports: {} }, calls = []
    const api = { coopDate: String, coopError: error => error.message }
    for (const key of ['cooperationConnection','cooperationChallenge','cooperationProbe','cooperationActivate','cooperationSync','cooperationSyncInfo','cooperationSyncAdvance','cooperationConnectionSettings']) api[key] = async value => { calls.push({ method: key, value }); throw new Error('Synthetic transport is intentionally disabled') }
    const javascript = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + javascript + '})', { Number, String, Date, JSON, Set, Map, Math, console, uni: { getStorageSync: () => '', setStorageSync() {}, removeStorageSync() {}, showToast() {} } })(key => {
        if (key === 'vue') return { ...Vue, onBeforeUnmount() {} }
        if (key === '@/utils/common') return { img: value => value }
        if (key === '../../api/cooperation') return api
        if (key.endsWith('.vue')) return { default: {} }
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        throw new Error('Unexpected dependency ' + key)
    }, module, module.exports)
    const state = module.exports.default.setup(props, { emit() {}, expose() {} })
    return { state, calls, props, template: parsed.descriptor.template.content }
}
async function render(view) {
    const fn = new Function('Vue', compile(view.template, { mode: 'function', prefixIdentifiers: true }).code)(Vue)
    const box = Vue.defineComponent({ setup(_props, { slots }) { return () => Vue.h('section', [slots.default?.(), slots.footer?.()]) } })
    const app = Vue.createSSRApp({ setup: () => ({ ...view.props, ...view.state }), render: fn })
    for (const name of ['CoopTaskSheet','u-collapse','u-collapse-item','u-button']) app.component(name, box)
    app.config.warnHandler = () => {}
    return renderToString(app)
}

const connection = component('CoopConnectionPanel', Vue.reactive({ show: false, page: true, profile: {}, providers }))
connection.state.changeProvider('soujike')
equal(connection.state.selectedProviderName.value, '星河平台', 'authorization identifies the currently selected site display name')
equal(connection.state.providerOptions.value[0].name, '星河平台', 'native picker receives display labels, not technical labels')
connection.state.credentials.username = 'synthetic-authorized-account'
equal(connection.state.payload().provider, 'soujike', 'alias does not replace the canonical provider in authorization payloads')
equal(connection.state.payload().credentials.username, 'synthetic-authorized-account', 'alias does not change the user-entered authorized account')
let html = await render(connection)
check(html.includes('填写星河平台账号') && !html.includes('过时的品牌名'), 'actual authorization view keeps chosen platform explicit without publishing stale brand text')
connection.state.preview.value = { identity: { name: '万机数码店（真实来源门店）' }, first_page_count: 1 }
html = await render(connection)
check(html.includes('我已核对星河平台的来源门店') && html.includes('万机数码店（真实来源门店）'), 'existing consent targets the chosen alias while verified source shop facts remain unchanged')
connection.state.connection.value = { connected: true, provider: 'closed-canonical-key', provider_name: '冬日平台', channel_enabled: false }
connection.state.provider.value = 'closed-canonical-key'
equal(connection.state.connectionProviderName.value, '冬日平台', 'disabled current connection remains labelled using its current server alias')
connection.state.connection.value = { connected: true, provider: 'unknown-technical-key', channel_enabled: false }
connection.state.provider.value = 'unknown-technical-key'
equal(connection.state.connectionProviderName.value, 'ERP平台', 'malformed current-connection response does not reveal provider key')
check(connection.calls.length === 0, 'label presentation never calls an external ERP or a credential API')

const profileProps = Vue.reactive({ profile: { id: 7, provider_requested: 'soujike', provider_requested_name: '星河平台', connection: { connected: true, provider: 'soujike', provider_name: '陈旧连接名' } }, providers, config: {}, editing: true, onboarding: false, busy: false, error: '' })
const profile = component('CoopProfilePanel', profileProps)
equal(profile.state.connectionProviderName.value, '星河平台', 'profile uses fresh source configuration instead of a stale connection label')
equal(profile.state.providerOptions.value.find(value => value.key === 'soujike').name, '星河平台', 'profile and authorization pickers use the same display source')
profileProps.providers = []
profileProps.profile = { id: 7, provider_requested: 'closed-key', provider_requested_name: '冬日平台' }
equal(profile.state.providerOptions.value[1].name, '冬日平台（已关闭，保留原选择）', 'closed requested source uses requested_name even without an active connection')
profileProps.profile = { id: 7, provider_requested: 'closed-key' }
equal(profile.state.providerOptions.value[1].name, 'ERP平台（已关闭，保留原选择）', 'closed source without a display name falls back generically instead of technical key')
check(!profile.template.includes('|| form.provider') && !profile.template.includes('schema?.name'), 'profile visible text has no raw-key fallback')
console.log(`PASS ${checks} ERP display-name mobile checks; actual helpers/SFCs with synthetic schemas only, no network/database/ERP calls.`)
