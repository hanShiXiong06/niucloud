<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external sender functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{TeamService,Store,ConfigService};
use addon\hsx_lead\app\support\Data;
use think\facade\Db;

$pdo=null;$schema='';$checks=0;$failed=false;
function entityPageCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $ids=[];
    for($i=1;$i<=75;$i++){
        $member=2000+$i;
        Db::name('member')->insert(['site_id'=>$site,'member_id'=>$member,'nickname'=>'Page owner '.$i,'member_no'=>'PAGE'.$i,'status'=>1]);
        $id=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'member_id'=>$member,'name'=>'Page shop '.$i,'contact_name'=>'Page contact','mobile'=>'18800001111','status'=>1]);
        Store::partner($site,$id);$ids[]=$id;
    }
    $foreign=(int)Data::query('merchant',$site+1)->insertGetId(['site_id'=>$site+1,'member_id'=>103,'name'=>'Foreign page shop','status'=>1]);
    $service=new TeamService(new Context($site,1));
    $first=$service->adminList(['limit'=>5,'page'=>1]);
    entityPageCheck($first['total']===75&&count($first['data'])===5,'SQL page preserves full total');
    entityPageCheck(array_column($first['data'],'id')===array_reverse(array_slice($ids,-5)),'stable id-desc first page');
    entityPageCheck(Data::query('merchant',$site)->where('subject_code','<>','')->count()===5,'only visible page projected/initialized, not all 75 shops');
    entityPageCheck(!in_array($foreign,array_column($first['data'],'id'),true),'foreign tenant excluded');
    $second=$service->adminList(['limit'=>5,'page'=>2]);
    entityPageCheck(array_intersect(array_column($first['data'],'id'),array_column($second['data'],'id'))===[],'second SQL page does not repeat first page');
    entityPageCheck(Data::query('merchant',$site)->where('subject_code','<>','')->count()===10,'second page presents only five additional shops');
    $repeat=$service->adminList(['limit'=>5,'page'=>1]);
    entityPageCheck($repeat['data']===$first['data'],'repeat page retains presented identities and membership');
    entityPageCheck(Data::query('merchant',$site)->where('subject_code','<>','')->count()===10,'repeat reads do not initialize other pages');
    $search=$service->adminList(['keyword'=>'PAGE1','limit'=>2,'page'=>2]);
    entityPageCheck($search['total']===11&&count($search['data'])===2,'member search total and SQL pagination agree');
    entityPageCheck(isset($search['tiers'])&&is_array($search['tiers']),'framework membership options retained');
    $ownerSummary=(new TeamService(new Context($site,0,2001)))->summary();
    entityPageCheck((int)$ownerSummary['merchant_id']===$ids[0]&&preg_match('/^[A-HJ-NP-Z2-9]{10}$/D',(string)$ownerSummary['subject_code'])===1,'owner of an unvisited page can still obtain a subject code on demand');
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2)+['site_id'=>$site]);
    $settings=ConfigService::defaults();$settings['enabled']=true;(new ConfigService(new Context($site,1)))->save($settings);
    foreach([2002,2003,2004]as$owner)leadMembershipGrant($site,$owner,'ML701');
    // An intentionally stale projection must never grant a filtered membership.
    Store::query('partner',$site)->where('merchant_id',$ids[4])->update(['membership_level'=>'ML701','membership_until'=>time()+86400]);
    Data::query('merchant',$site)->where('id','in',[$ids[1],$ids[2],$ids[3]])->update(['subject_code'=>null]);
    $filtered=$service->adminList(['level_code'=>'ML701','limit'=>1,'page'=>2]);
    entityPageCheck($filtered['total']===3&&count($filtered['data'])===1&&(int)$filtered['data'][0]['id']===$ids[2],'level filter preserves complete totals and stable pagination from verified ledger');
    entityPageCheck(!in_array($ids[4],array_column($filtered['data'],'id'),true),'stale cached partner level is not a membership fact');
    entityPageCheck(Data::query('merchant',$site)->whereIn('id',[$ids[1],$ids[2],$ids[3]])->where('subject_code','<>','')->count()===1,'level filtering generates a subject code only for the visible page, not all matches');
    $filteredSearch=$service->adminList(['level_code'=>'ML701','keyword'=>'PAGE3','limit'=>5]);
    entityPageCheck($filteredSearch['total']===1&&(int)$filteredSearch['data'][0]['id']===$ids[2],'member keyword and verified membership filter compose');
    $emptyPage=$service->adminList(['level_code'=>'ML701','limit'=>2,'page'=>3]);
    entityPageCheck($emptyPage['total']===3&&$emptyPage['data']===[],'out-of-range level page remains empty with accurate full total');
    $filler=[];for($i=0;$i<210;$i++)$filler[]=['site_id'=>$site,'member_id'=>101,'name'=>'Batch filler '.$i,'status'=>1];Data::query('merchant',$site)->insertAll($filler);
    $acrossBatches=$service->adminList(['level_code'=>'ML701','limit'=>1,'page'=>2]);
    entityPageCheck($acrossBatches['total']===3&&(int)$acrossBatches['data'][0]['id']===$ids[2],'keyset batches do not truncate matches past the first 200 candidates');
    entityPageCheck(Data::query('merchant',$site)->whereLike('name','Batch filler%')->where('subject_code','<>','')->count()===0,'nonmatching batch candidates are never presented or assigned subject codes');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'Actual default SQL paging over 75 shops and verified level filtering over 285 candidates; owned random schema only; no business rows or external requests'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
