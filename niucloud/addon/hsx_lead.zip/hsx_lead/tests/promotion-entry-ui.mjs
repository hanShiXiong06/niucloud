import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadFrameworkInvite } from './framework-invite.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const workspace = path.resolve(plugin, '../../..')
const require = createRequire(path.join(workspace, 'uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc')
const relative = 'uni-app/pages/invite/index.vue'
const source = fs.readFileSync(path.join(plugin, relative), 'utf8')
const descriptor = compiler.parse(source, { filename: relative }).descriptor
const script = compiler.compileScript(descriptor, { id: 'promotion-entry-test' })
assert.deepEqual(compiler.compileTemplate({ source: descriptor.template.content, filename: relative, id: 'promotion-entry-test', compilerOptions: { bindingMetadata: script.bindings } }).errors, [])
let checks = 1
const check = (ok, name) => { assert.ok(ok, name); checks++ }
const equal = (actual, expected, name) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, name); checks++ }
function fixture(initialToken = '') {
    let token = initialToken
    const loads = [], shows = [], logins = [], navigations = [], storage = new Map()
    const runtime = { setStorageSync: (key, value) => storage.set(key, value) }
    const deps = {
        vue: Vue,
        '@dcloudio/uni-app': { onLoad: fn => loads.push(fn), onShow: fn => shows.push(fn) },
        '@/utils/common': { getToken: () => token, redirect: value => navigations.push(value) },
        '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: value => logins.push(value) }) },
        '../../utils/cooperation-invite': loadFrameworkInvite(runtime),
        '../../utils/mobile-ui': { cooperationButtonStyle: {} }
    }
    const module = { exports: {} }
    const js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { String, Number, Object, uni: runtime })(key => {
        if (key in deps) return deps[key]
        throw new Error('Unexpected invitation dependency: ' + key)
    }, module, module.exports)
    const state = module.exports.default.setup({}, { expose() {} })
    return { state, loads, shows, logins, navigations, storage, set token(value) { token = value } }
}
const profile = '/addon/hsx_lead/pages/profile/index'
for (const options of [{ mid: '101', promotion_invite: '1' }, { scene: encodeURIComponent('mid-101&pi-1') }]) {
    const f = fixture()
    f.loads[0](options)
    equal(f.logins, [{ url: profile, param: { mid: 101, promotion_invite: 1 }, mode: 'redirectTo' }], 'direct link and native QR both use framework login with invitation return')
    check(f.storage.get('pid') === '101', 'registration receives the inviter even during warm navigation')
    check(!f.navigations.length, 'guest is not sent to store binding or member tasks before login')
    f.shows[0](); f.shows[0]()
    check(f.logins.length === 1, 'cancel/back and repeated onShow do not reopen login')
    f.state.enter()
    check(f.logins.length === 2, 'cancelled guest may explicitly retry login')
    f.state.browse()
    equal(f.navigations.at(-1), { url: '/addon/hsx_lead/pages/index', mode: 'reLaunch' }, 'visitor can browse without compulsory registration')
    f.token = 'synthetic-login'; f.shows[0](); f.state.enter()
    equal(f.navigations.at(-1), { url: profile, param: { mid: 101, promotion_invite: 1 }, mode: 'redirectTo' }, 'successful session enters the personal page, never an entity join')
}
const member = fixture('synthetic-login')
member.loads[0]({ mid: '42', subject_code: 'AAAAAAAAAA', url: '/evil', redirect: '/evil' })
check(member.logins.length === 0, 'existing session does not unnecessarily log in again')
equal(member.navigations[0], { url: profile, param: { mid: 42, promotion_invite: 1 }, mode: 'redirectTo' }, 'client redirect and subject code are not forwarded to the personal page')
for (const options of [{}, { mid: '0' }, { mid: '-1' }, { mid: 'nope' }, { mid: '4294967296' }, { mid: '1.5' }, { scene: '%E0%A4%A' }, { subject_code: 'ABCD234567' }]) {
    const f = fixture(); f.loads[0](options)
    equal(f.logins[0], { url: profile, param: {}, mode: 'redirectTo' }, 'invalid/missing invitation safely opens ordinary login: ' + JSON.stringify(options))
}
check(!/entityJoin|entityLookup|subject_code|bindPromotion|cooperationBootstrap/.test(source), 'promotion entry performs no store join, payment, or relation mutation')
check(fs.readFileSync(path.join(plugin, 'package/uni-app-pages.php'), 'utf8').includes('"path": "pages/invite/index", "style": { "navigationBarTitleText": "登录注册" }, "needLogin": false'), 'installer registers the public route without a login interceptor loop')
check(source === fs.readFileSync(path.join(workspace, 'uni-app/src/addon/hsx_lead/pages/invite/index.vue'), 'utf8'), 'installed and canonical invitation pages match')
const backend = fs.readFileSync(path.join(plugin, 'app/service/cooperation/PromotionService.php'), 'utf8')
check(backend.includes("'/addon/hsx_lead/pages/invite/index?mid='"), 'normal sharing uses the same login entry as the poster')
console.log(`PASS ${checks} invitation entry checks; actual SFC and framework scene decoder, synthetic login/navigation only.`)
