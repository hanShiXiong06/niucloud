import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { profileConfigApi } from './profile-config-fixture.mjs'

// Actual plugin utility and Vue setup code, synthetic inputs only. No network or writes to business data.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), mobile = path.join(plugin, 'uni-app')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
let checks = 0
const check = (value, message) => { assert.ok(value, message); checks++ }
const equal = (value, expected, message) => { assert.deepEqual(JSON.parse(JSON.stringify(value)), expected, message); checks++ }
const businesses = [
    { key: 'purchase', name: '二手机', enabled: true, dimension: 'model', selection_mode: 'multiple', selection_limit: 0, commission_minimum: '125.00', fields: [{ key: 'budget', label: '预算', type: 'number', required: true }], options: [] },
    { key: 'new_phone', name: '新机', enabled: true, dimension: 'brand', selection_mode: 'multiple', selection_limit: 2, commission_minimum: '220.00', fields: [{ key: 'storage', label: '容量', type: 'select', required: true, options: [{ value: '256', label: '256 GB' }] }], options: [] },
    { key: 'broadband', name: '宽带', enabled: true, dimension: 'operator', selection_mode: 'single', selection_limit: 0, commission_minimum: '80.00', fields: [{ key: 'address', label: '装机地址', type: 'text', required: true }], options: [] },
    { key: 'disabled', name: '未开放', enabled: false, fields: [] }
]
const business = loadMobileUtility('cooperation-business'), selection = loadMobileUtility('catalog-selection')
check(business.enabledBusinesses({ businesses }).length === 3, 'only server-enabled businesses are selectable')
check(business.businessSelectionLimit(businesses[0]) === 0 && business.businessSelectionLimit(businesses[2]) === 1, 'zero is unlimited except for an explicitly single-select business')
check(business.businessFormError(businesses[0], [{ id: 'm', title: '型号' }], {}) === '请填写预算', 'business-specific required fields are validated by their actual labels')
check(business.businessFormError(businesses[1], [{ id: 'brand', title: '品牌' }], { storage: 'invalid' }).includes('容量'), 'select fields reject values outside the current business options')
check(business.leadFeeSnapshot({ commission_minimum: '125', fee_percent: '12', fee_minimum: '8', fee_confirmed: true }).known, 'complete confirmed fee snapshots are recognized')
check(!business.leadFeeSnapshot({ commission_minimum: '125' }).known, 'an incomplete fee snapshot cannot silently fall back to current platform rules')
check(!business.leadFeeSnapshot({ commission_minimum: '125', fee_percent: '12', fee_minimum: '8', fee_confirmed: false }).known, 'complete but unconfirmed fee values cannot authorize a payment')
const pathRows = selection.normalizeCatalog([{ id: 'carrier_1', title: '千兆宽带', path: ['宽带', '电信', '千兆'] }])
check(pathRows[0].category === '宽带' && pathRows[0].brand === '电信', 'catalog hierarchy derives from authoritative path values')

const calls = [], storage = new Map([['wap_site_id', 3], ['wap_member_id', 42]])
const runtime = { getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, JSON.parse(JSON.stringify(value))), removeStorageSync: key => storage.delete(key), navigateTo: args => { calls.push({ type: 'navigateTo', ...args }) }, navigateBack: () => calls.push({ type: 'navigateBack' }), redirectTo: args => calls.push({ type: 'redirectTo', ...args }), showToast() {}, showModal() {} }
function execute(source, dependencies = {}, globals = {}) {
    const module = { exports: {} }, js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Date, Math, Number, String, JSON, Set, Map, Promise, console, setTimeout, clearTimeout, uni: runtime, ...globals })(key => { if (key in dependencies) return dependencies[key]; if (key.endsWith('.vue')) return { default: {} }; if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key)); throw Error('Unexpected import ' + key) }, module, module.exports)
    return module.exports
}
let historyLength = 2
const navigation = execute(fs.readFileSync(path.join(mobile, 'utils/cooperation-navigation.ts'), 'utf8'), {}, { getCurrentPages: () => Array.from({ length: historyLength }, (_, index) => ({ route: index ? 'addon/hsx_lead/pages/task/index' : 'addon/hsx_lead/pages/index' })) })
navigation.backCooperationTask(); check(calls.at(-1).type === 'navigateBack', 'task back preserves the real page stack when history exists')
historyLength = 1; navigation.backCooperationTask(); check(calls.at(-1).type === 'redirectTo' && calls.at(-1).url === '/addon/hsx_lead/pages/index', 'a direct task entry returns to plugin home when there is no history')
navigation.openCooperationTask('select', { collaboration_id: 99 }); check(calls.at(-1).type === 'navigateTo' && calls.at(-1).url.includes('collaboration_id=99'), 'ordinary task navigation never relaunches the application')

const api = { ...profileConfigApi, coopRequestId: () => 'synthetic-request', coopMoney: value => value == null || !Number.isFinite(Number(value)) ? '—' : '¥' + Number(value).toFixed(2), coopError: error => error?.message || '读取失败', cooperationCatalog: async () => ({ data: [{ id: 'a', title: '甲', path: ['业务', '品牌'] }, { id: 'b', title: '乙', path: ['业务', '品牌'] }] }) }
let catalogOptions, receiveSelection
const navigationFixture = { ...navigation, openCooperationCatalog: (options, receive) => { catalogOptions = options; receiveSelection = receive } }
const cleanups = []
function setup(name, values) {
    const filename = path.join(mobile, 'components/cooperation', name + '.vue'), source = fs.readFileSync(filename, 'utf8'), parsed = compiler.parse(source, { filename })
    check(!parsed.errors.length, name + ' parses')
    const script = compiler.compileScript(parsed.descriptor, { id: name })
    const template = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename, id: name, compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
    check(!template.errors.length, name + ' template compiles')
    const module = execute(script.content, { vue: { ...Vue, onBeforeUnmount: callback => cleanups.push(callback) }, '../../api/cooperation': api, '../../utils/cooperation-navigation': navigationFixture, '../../utils/interaction-feedback': { interactionFeedback() {} }, '@/utils/common': { img: value => value } })
    const props = Vue.reactive(values), emitted = [], exposed = {}
    const state = module.default.setup(props, { expose: methods => Object.assign(exposed, methods), emit: (...args) => emitted.push(args) })
    return { props, state, emitted, exposed, source }
}
async function settle() { for (let n = 0; n < 8; n++) { await Promise.resolve(); await Vue.nextTick() } }

const publisher = setup('CoopPublishForm', { show: true, page: true, merchantId: 7, config: { businesses, fee_confirmed: true }, busy: false, error: '' })
Object.assign(publisher.state.form, { customer_name: '合成客户', mobile: '18800000000', district_id: 12, consent: true })
publisher.state.selections.purchase = [{ id: 'phone', title: '二手机型' }]; publisher.state.values.value.budget = '3000'
publisher.state.form.business_type = 'new_phone'; publisher.state.values.value.storage = '256'; publisher.state.selections.new_phone = [{ id: 'brand', title: '品牌' }]
publisher.state.form.business_type = 'purchase'; check(publisher.state.values.value.budget === '3000' && publisher.state.models.value[0].id === 'phone', 'switching businesses retains separate field and selection drafts')
publisher.state.chooseDemand(); check(catalogOptions.business_type === 'purchase' && catalogOptions.max === 0, 'customer demand uses the same real business-scoped catalog page')
receiveSelection([{ id: 'phone2', title: '另一个型号' }]); publisher.state.submit()
const demand = publisher.emitted.find(event => event[0] === 'submit')?.[1]
equal(demand.demand_ids, ['phone2'], 'publish sends the selected business demand IDs')
equal(demand.form_values, { budget: '3000' }, 'publish sends only current business fields, never hidden branch values')
await settle(); check(storage.has('hsx_lead_publish_draft:3:42'), 'draft persistence is site and logged-in member scoped')
const restored = setup('CoopPublishForm', { show: true, page: true, merchantId: 7, config: { businesses, fee_confirmed: true }, busy: false, error: '', initialBusinessType: 'broadband' })
check(restored.state.form.business_type === 'broadband' && restored.state.form.customer_name === '合成客户' && restored.state.selections.purchase[0].id === 'phone2', 'a business deep link selects that business without throwing away another business draft')
publisher.props.config.fee_confirmed = false; publisher.state.submit(); check(publisher.state.localError.value.includes('尚未确认收费规则') && publisher.emitted.filter(event => event[0] === 'submit').length === 1 && publisher.state.form.customer_name === '合成客户', 'unconfirmed platform fees block new publishing without clearing input'); publisher.props.config.fee_confirmed = true
publisher.state.form.mobile = 'bad'; publisher.state.submit(); check(!!publisher.state.localError.value && publisher.state.form.customer_name === '合成客户', 'validation failures retain customer input')
publisher.exposed.clear(); await settle(); check(!storage.has('hsx_lead_publish_draft:3:42'), 'successful publish explicitly clears the draft')

const profile = setup('CoopProfilePanel', { profile: { id: 7, member_id: 42, business_capabilities: [] }, config: { businesses }, providers: [], editing: true, page: true, busy: false, error: '' })
await settle()
Object.assign(profile.state.form, { name: '合成门店', contact_name: '合成联系人', mobile: '18800000000', district_id: 12, address: '合成地址' })
profile.state.selectedBusinesses.value = ['purchase', 'broadband']; profile.state.capabilityChoices.purchase = [{ id: 'phone', title: '二手机' }]
profile.state.submit(); check(profile.state.localError.value.includes('宽带') && !profile.emitted.some(event => event[0] === 'submit'), 'a checked business with empty capability cannot accidentally authorize all options')
profile.state.capabilityChoices.broadband = [{ id: 'telecom', title: '电信' }]; profile.state.submit()
equal(profile.emitted.find(event => event[0] === 'submit')[1].business_capabilities, [{ business_type: 'purchase', option_ids: ['phone'] }, { business_type: 'broadband', option_ids: ['telecom'] }], 'onboarding supports independent multi-business capabilities')
profile.state.openModelCatalog('broadband'); check(catalogOptions.max === 0 && catalogOptions.selection_mode === 'multiple', 'a single-operator customer demand does not restrict merchant capability registration')
receiveSelection([{ id: 'telecom', title: '电信' }, { id: 'unicom', title: '联通' }, { id: 'mobile', title: '移动' }]); profile.state.submit()
equal(profile.emitted.filter(event => event[0] === 'submit').at(-1)[1].business_capabilities[1].option_ids, ['telecom', 'unicom', 'mobile'], 'merchant may register three operators despite the demand being single-select')
check(business.businessFormError(businesses[2], profile.state.capabilityChoices.broadband, { address: '合成装机地址' }).includes('最多选择 1'), 'a single customer demand still allows only one operator')

storage.set('wap_member_id', 43)
storage.set('hsx_lead_profile_draft:3:43', { selectedBusinesses: ['broadband'], capabilityChoices: { broadband: [{ id: 'expanded', title: '停用前未保存的草稿扩展' }] } })
const disabledProfile = setup('CoopProfilePanel', { profile: { id: 8, member_id: 43, name: '停用宽带合成门店', contact_name: '合成联系人', mobile: '18800000001', district_id: 12, address: '合成地址', business_capabilities: [{ business_type: 'broadband', business_name: '宽带', option_ids: ['telecom', 'unicom'], items: [{ id: 'telecom', title: '电信' }, { id: 'unicom', title: '联通' }] }] }, config: { businesses: businesses.map(item => item.key === 'broadband' ? { ...item, enabled: false } : item) }, providers: [], editing: true, page: true, busy: false, error: '' })
await settle()
check(disabledProfile.state.disabledCapabilities.value[0].option_ids.length === 2 && !disabledProfile.state.selectedBusinesses.value.includes('broadband') && disabledProfile.source.includes('已停用业务（只读保留）'), 'existing disabled capabilities are visibly read-only rather than an invisible blocking selection')
const lastCatalog = catalogOptions; disabledProfile.state.openModelCatalog('broadband'); disabledProfile.state.toggleBusiness('broadband')
check(catalogOptions === lastCatalog && !disabledProfile.state.selectedBusinesses.value.includes('broadband'), 'closed business cannot open a new capability picker or be selected anew')
disabledProfile.state.form.mobile = '18800000002'; disabledProfile.state.selectedBusinesses.value.push('broadband'); disabledProfile.state.capabilityChoices.broadband = [{ id: 'expanded', title: '不允许扩展' }]; disabledProfile.state.submit()
const disabledSaved = disabledProfile.emitted.find(event => event[0] === 'submit')?.[1]
check(disabledSaved?.mobile === '18800000002' && !disabledProfile.state.localError.value, 'editing the phone remains saveable when an existing broadband business is disabled')
equal(disabledSaved.business_capabilities, [{ business_type: 'broadband', option_ids: ['telecom', 'unicom'] }], 'disabled capability IDs come only from the persisted snapshot, never a stale or expanded draft')
storage.set('wap_member_id', 42)

const operatorCard = setup('CoopStoreCard', { store: { id: 11, business_type: 'broadband', business_name: '宽带', capability_dimension: 'operator', all_models: true, inventory_count: 999, capability_source: 'mixed', business_capabilities: [{ business_type: 'broadband', option_ids: ['telecom', 'unicom', 'mobile'] }] } })
check(!operatorCard.state.modelDimension.value && operatorCard.state.capabilityText.value === '宽带 · 可承接 3 个运营商', 'operator cards show compact operator capability counts, not all-model or stock facts')
check(!operatorCard.state.capabilitySourceText.value.includes('ERP') && operatorCard.source.includes('v-if="modelDimension && store.erp_visible !== false" class="coop-store__stock-link"'), 'only model businesses with visible ERP can expose stock; operators never present inventory as their capability')
const brandCard = setup('CoopStoreCard', { store: { id: 12, business_type: 'new_phone', business_name: '新机', capability_dimension: 'brand', match_demands: Array.from({ length: 80 }, (_, id) => ({ id: String(id), title: '不应堆叠显示的品牌' + id })) } })
check(brandCard.state.capabilityText.value === '新机 · 可承接 80 个品牌' && !brandCard.state.capabilityText.value.includes('不应堆叠'), 'brand matches remain a compact count even with a long capability list')

const commission = setup('CoopCommissionForm', { show: false, page: true, lead: { id: 1, commission_minimum: '125', fee_percent: '12', fee_minimum: '8', fee_confirmed: true }, config: { commission_minimum: '999', fee_percent: '99', fee_minimum: '999', fee_confirmed: true }, busy: false, error: '' })
commission.props.show = true; await settle(); check(commission.state.amount.value === '125', 'commission starts at the lead snapshot minimum, not the newest platform price')
commission.state.amount.value = '200'; check(commission.state.fee.value === '¥24.00' && commission.state.net.value === '¥176.00', 'split preview uses persisted percent and fee minimum')
commission.state.amount.value = '100'; commission.state.submit(); check(commission.state.localError.value.includes('125.00'), 'commission minimum validation uses the actual order rule')
commission.props.lead = { id: 1, commission_minimum: '125' }; commission.state.submit(); check(commission.state.localError.value.includes('快照'), 'missing fees cannot be silently substituted from config')

const catalog = setup('ModelCatalogPicker', { show: true, page: true, modelValue: [], title: '单选运营商', max: 0, businessType: 'broadband', selectionMode: 'single', initialView: 'browse' })
await settle(); catalog.state.toggle(catalog.state.rows.value[0]); catalog.state.toggle(catalog.state.rows.value[1]); equal(catalog.state.chosen.value.map(row => row.id), ['b'], 'single select replaces the previous choice instead of reporting an arbitrary cap')
catalog.state.toggle(catalog.state.rows.value[1]); check(!catalog.state.chosen.value.length, 'tapping a selected option can clear it')
check(!catalog.source.includes('<DemandModels') && catalog.source.includes('已选 ${chosen.length} 项'), 'the shared catalog shows a compact selected count rather than a label wall')
const catalogTemplate = compiler.parse(catalog.source).descriptor.template.content
check(catalogTemplate.includes('{{ visibleRows.length }} 项') && !/设备品类|查看.*型号|已选型号|暂无型号|匹配的型号/.test(catalogTemplate), 'shared directory counters, empty states and accessibility labels use business-neutral wording')
catalog.props.selectionMode = 'multiple'; catalog.props.max = 1; catalog.state.updateSelection(catalog.state.rows.value, 'select_all')
check(catalog.state.selectionError.value.includes('1 项') && !catalog.state.selectionError.value.includes('型号') && !catalog.state.chosen.value.length, 'over-limit feedback uses generic item wording without changing atomic selection validation')

const workbench = fs.readFileSync(path.join(mobile, 'components/cooperation/CooperationWorkbench.vue'), 'utf8')
check(!workbench.includes("mode: 'reLaunch'") && workbench.includes("uni.redirectTo({ url: cooperationTaskLink('select'"), 'publish advances to the real selection page without leaving a duplicate editable submission page')
check(workbench.includes('resumed && !dirty') && workbench.includes('Keep the mounted list'), 'returning from an unchanged task retains the mounted list and its filters/scroll')
check(!/最低\s*50|commission_minimum\s*\|\|\s*50/.test(workbench + commission.source), 'fee confirmation contains no hard-coded fifty-yuan fallback')
for (const cleanup of cleanups) cleanup()
console.log(`PASS ${checks} phase-one mobile route/business/draft/fee checks; real Vue setup and utilities, synthetic API only, no live payment or production calls.`)
