import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Real presentation helper and page render only. No HTTP, payment or stored member changes.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), dom = require('@vue/compiler-dom'), ts = require('typescript')
const { renderToString } = require('@vue/server-renderer')
const { membershipSkin, membershipSkinVars, membershipSkinPresets } = loadMobileUtility('membership-skin')
let checks = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
const keys = ['neutral', 'bronze', 'silver', 'gold', 'sapphire', 'amethyst', 'obsidian']
for (const [rank, name] of keys.entries()) {
    const skin = membershipSkin({}, rank)
    check(skin.preset === name && skin.start === membershipSkinPresets[name].start, 'automatic display rank selects ' + name)
    check(skin.gradient === `linear-gradient(135deg,${skin.start},${skin.end})`, name + ' uses real gradient endpoints')
}
check(membershipSkin({}, 22).preset === 'obsidian', 'arbitrary higher business tiers do not require more hard-coded membership levels')
const custom = membershipSkin({ preset: 'custom', start_color: '#123', end_color: '#456789', text_color: '#fff', accent_color: '#789', angle: 90, card_image: 'upload/member/card.png', avatar_effect: false }, 2)
check(custom.start === '#123' && custom.angle === 90 && custom.gradient.includes('#456789'), 'custom colors and angle remain configurable')
check(custom.cardImage === 'upload/member/card.png' && custom.avatarEffect === false, 'card art and avatar effect have separate presentation controls')
check(membershipSkin({ start_color: 'red;display:none', angle: Infinity }, 1).start === membershipSkinPresets.bronze.start, 'invalid CSS falls back safely')
for (const image of ['javascript:alert(1)', 'data:image/svg+xml,abc', '//external.test/a.png', '../private/a.png', "x');display:none", 'bad\nimage.png']) check(!membershipSkin({ card_image: image }).cardImage, 'unsafe card image is not used: ' + image.slice(0, 12))
check(membershipSkin({ card_image: 'https://example.test/card.png?a=1' }).cardImage.includes('https://'), 'normal absolute image references are supported')
check(membershipSkinVars({ preset: 'gold' })['--lead-member-gradient'].includes('#FFF1C8'), 'shared CSS variables carry the same resolved card/edge gradient')

const filename = path.join(plugin, 'uni-app/pages/membership/index.vue'), source = fs.readFileSync(filename, 'utf8')
const parsed = compiler.parse(source, { filename }), script = compiler.compileScript(parsed.descriptor, { id: 'membership-skin' })
check(!parsed.errors.length, 'membership page remains a valid Vue SFC')
const summary = Vue.ref({ active: false, can_manage: true, level_name: '普通会员', used_accounts: 1, account_limit: 1,
    experience: { value: '0.00', completed_orders: 0 }, next_level: null,
    tiers: keys.slice(1).map((name, index) => ({ code: 'ML' + (index + 1), display_rank: index + 1, name, experience_eligible: false,
        experience_required: '100.00', experience_remaining: '100.00', account_limit: 2, level_visual: { preset: name },
        cycles: [{ key: 'month', name: '月付', months: 1, price: '99.00', enabled: true }] })) })
const controller = { data: summary, loading: Vue.ref(false), ready: Vue.ref(true), busy: Vue.ref(false), error: Vue.ref(''), writeError: Vue.ref(''), identity: () => 'test', current: () => true, pause() {} }
const module = { exports: {} }, js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
vm.runInNewContext(`(function(require,module,exports){${js}\n})`, { String, Number, Object, Array, Math, Date })(key => {
    if (key === 'vue') return Vue
    if (key === '@dcloudio/uni-app') return { onLoad() {}, onShow() {}, onHide() {} }
    if (key === '@/utils/common') return { img: value => 'asset:' + value }
    if (key.endsWith('/useEntityPage')) return { useEntityPage: () => controller }
    if (key.endsWith('/api/cooperation')) return { coopMoney: value => '¥' + value }
    if (key.includes('/utils/')) return loadMobileUtility(path.basename(key))
    return { default: {} }
}, module, module.exports)
const state = module.exports.default.setup({}, { expose() {} })
check(state.currentSkin.value.preset === 'neutral', 'unpaid current membership stays neutral, not the highlighted purchase candidate')
state.selected.value = 'ML1'
check(state.mainLabel.value === '经验未达标', 'rich card design does not bypass experience eligibility')
const render = new Function('Vue', dom.compile(parsed.descriptor.template.content, { mode: 'function', prefixIdentifiers: true }).code)(Vue)
async function html() {
    const app = Vue.createSSRApp({ setup: () => ({ ...state, themeColor: () => '' }), render })
    app.config.warnHandler = () => {}
    app.component('CoopTaskSheet', { setup: (_, { slots }) => () => Vue.h('main', slots.default?.()) })
    for (const name of ['CoopState', 'CoopLevelBadge', 'CoopExperienceProgress', 'CoopBusinessIcon', 'u-icon', 'Pay']) app.component(name, { render: () => Vue.h('span') })
    return renderToString(app)
}
const rendered = await html()
for (const name of keys.slice(1)) check(rendered.includes('--lead-member-start:' + membershipSkinPresets[name].start), 'actual page output renders ' + name + ' skin')
check(rendered.includes('membership-current__growth') && rendered.includes('membership-current__hero'), 'growth remains a legible white region outside the decorative card hero')
summary.value = { ...summary.value, active: true, level_code: 'ML3', display_rank: 3, level_name: '黄金', level_visual: { preset: 'gold', card_image: 'upload/member/card.png' } }
check(state.currentSkin.value.preset === 'gold', 'only active current membership receives its configured premium skin')
check((await html()).includes('asset:upload/member/card.png'), 'actual page resolves uploaded current-member card artwork')
summary.value.active = false
check(state.currentSkin.value.preset === 'neutral' && !state.currentSkin.value.cardImage, 'expired rights do not retain active premium artwork')
console.log(`PASS ${checks} membership skin checks; real helper and page SSR, no HTTP/payment/database writes.`)
