import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Execute the actual request-state hook. No browser, HTTP, database, or business writes.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript')
const source = fs.readFileSync(path.join(plugin, 'uni-app/composables/useCooperation.ts'), 'utf8')
const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
function deferred() { let resolve; const promise = new Promise(done => { resolve = done }); return { promise, resolve } }
function fixture() {
    let token = 'member-a', bootstrapCount = 0, writes = 0
    const listCalls = [], detailCalls = [], controls = {
        leads: async query => ({ data: { data: [{ id: query.page }], total: 5 } }),
        detail: async id => ({ data: { id, status: 'following' } })
    }
    const api = {
        cooperationBootstrap: async () => { bootstrapCount++; return { data: { profile: { id: 7 }, config: {}, providers: [], stats: {}, wallet: {} } } },
        cooperationLeads: async query => { listCalls.push({ ...query }); return controls.leads(query) },
        cooperationLead: async id => { detailCalls.push(id); return controls.detail(id) },
        coopError: cause => cause.message,
        actCooperationLead: async () => { writes++; return { data: {} } }, createCooperationOrder: async () => { writes++; return { data: {} } }, createCooperationLead: async () => { writes++; return { data: {} } }
    }
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Date, Math, Number, String, Map, Promise, JSON, console })(key => key === 'vue' ? Vue : key === '@/utils/common' ? { getToken: () => token } : key === '../api/cooperation' ? api : (() => { throw Error('Unexpected dependency ' + key) })(), module, module.exports)
    const state = module.exports.useCooperation()
    return { state, controls, listCalls, detailCalls, bootstrapCount: () => bootstrapCount, writes: () => writes, changeMember: value => { token = value } }
}
const h = fixture(), s = h.state
s.resume(); await s.bootstrap(); s.direction.value = 'incoming'; s.query.keyword = '苹果'; s.query.status = 'following'
await s.loadLeads(); await s.loadLeads(true)
equal(s.rows.value.map(row => row.id), [1, 2], 'two previously loaded pages establish the real list state')
const append = deferred(); h.controls.leads = () => append.promise
const previousAppend = s.loadLeads(true); s.pause(); s.pause(); append.resolve({ data: { data: [{ id: 999 }], total: 5 } }); await previousAppend
equal(s.rows.value.map(row => row.id), [1, 2], 'a hidden page rejects the interrupted response without discarding earlier pages')
check(!s.listLoading.value && s.ready.value && s.query.page === 2, 'pause releases loading while retaining loaded-page and ready state')
h.controls.leads = async query => ({ data: { data: [{ id: query.page }], total: 5 } })
const bootstraps = h.bootstrapCount(); s.resume(); await s.resumeInterruptedReads()
equal(h.listCalls.at(-1), { keyword: '苹果', status: 'following', page: 3, limit: 20, direction: 'incoming' }, 'resume retries the interrupted append page with its exact direction and filters')
equal(s.rows.value.map(row => row.id), [1, 2, 3], 'resuming an append preserves earlier rows instead of resetting to page one')
check(s.query.page === 3 && h.bootstrapCount() === bootstraps, 'interrupted list recovery does not trigger another bootstrap')
const completedReads = h.listCalls.length; await s.resumeInterruptedReads()
check(h.listCalls.length === completedReads, 'a successful read is not fetched again on an unchanged return')

const detail = deferred(); h.controls.detail = () => detail.promise
const previousDetail = s.loadDetail(77); s.pause(); detail.resolve({ data: { id: 77, status: 'stale' } }); await previousDetail
check(!s.detail.value.id && !s.detailLoading.value && !s.detailError.value, 'the reproduced background race has no false old detail or synthetic error')
h.controls.detail = async id => ({ data: { id, status: 'following' } }); s.resume(); await s.resumeInterruptedReads()
check(s.detail.value.id === 77 && s.detail.value.status === 'following' && h.detailCalls.length === 2, 'returning repairs the blank detail by GETting the interrupted ID once')
check(h.bootstrapCount() === bootstraps && !h.writes(), 'detail recovery performs no bootstrap, action, order or publication')

const replacement = deferred(); s.query.keyword = '新筛选'; h.controls.leads = () => replacement.promise
const previousReplacement = s.loadLeads(); s.pause(); replacement.resolve({ data: { data: [{ id: 888 }], total: 1 } }); await previousReplacement
h.controls.leads = async query => ({ data: { data: [{ id: 10 }], total: 1 } }); s.resume(); await s.resumeInterruptedReads()
check(h.listCalls.at(-1).page === 1 && h.listCalls.at(-1).keyword === '新筛选', 'an interrupted replacement remains a replacement, not an inferred page-four append')
equal(s.rows.value.map(row => row.id), [10], 'resumed filter results replace only as the user originally requested')

const changedFilter = deferred(); h.controls.leads = () => changedFilter.promise
const staleFilterRead = s.loadLeads(); s.pause(); changedFilter.resolve({ data: { data: [], total: 0 } }); await staleFilterRead
s.query.keyword = '另一个条件'; const beforeChangedResume = h.listCalls.length; s.resume(); await s.resumeInterruptedReads()
check(h.listCalls.length === beforeChangedResume, 'recovery never replays an interrupted query after its filter context changed')

const oldIdentity = deferred(); h.controls.detail = () => oldIdentity.promise
const privateRead = s.loadDetail(88); s.pause(); oldIdentity.resolve({ data: { id: 88, mobile: 'synthetic-private' } }); await privateRead
h.changeMember('member-b'); const beforeIdentityResume = h.detailCalls.length; s.resume(); await s.resumeInterruptedReads()
check(h.detailCalls.length === beforeIdentityResume && !s.detail.value.id && !s.ready.value, 'member changes discard interrupted IDs and previous private state instead of refetching another member data')
console.log(`PASS ${checks} interrupted-read recovery checks; actual hook and synthetic delayed transports only, no browser/API/database mutations.`)
