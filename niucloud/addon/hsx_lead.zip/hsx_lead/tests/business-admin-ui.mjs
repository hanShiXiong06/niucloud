import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadAdminUtility } from './admin-utils.mjs'

// Real plugin SFCs and pure helpers; isolated synthetic API responses only.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const runModule=(source,deps={})=>{const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;const module={exports:{}};vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Date,Number,String,Math,Set,Map,JSON,console,Uint8Array,btoa,Blob,URL,setTimeout})(key=>{if(key in deps)return deps[key];if(key==='../../composables/useRemoteOptions')return loadAdminUtility('useRemoteOptions');if(key.endsWith('.vue'))return{default:{}};throw Error('Unexpected dependency '+key)},module,module.exports);return module.exports}
const business=runModule(fs.readFileSync(path.join(plugin,'admin/composables/business.ts'),'utf8'))
const definition=()=>({key:'broadband',name:'宽带',enabled:true,dimension:'operator',selection_mode:'multiple',selection_limit:0,commission_minimum:'200.00',fields:[],options:[{id:'operator_mobile',title:'移动',path:['宽带','运营商','移动']}]})
check(business.normalizeBusinesses([definition()])[0].selection_limit===0,'zero means no business quantity limit')
check(business.normalizeBusinesses([{...definition(),enabled:'0'}])[0].enabled===false,'disabled server flag is not made truthy')
check(business.businessValidation([definition()])==='','valid multi-business definition accepted')
check(business.businessValidation([{...definition(),selection_limit:5001}]).includes('0—5000'),'quantity upper safety bound validated')
check(business.businessValidation([{...definition(),fields:[{key:'speed',label:'带宽',type:'select',required:true,options:[]}]}]).includes('下拉选项'),'empty dynamic dropdown blocked')
check(business.businessValidation([{...definition(),fields:[{key:'speed',label:'带宽',type:'select',required:true,options:[{value:'a',label:'100M'},{value:'a',label:'200M'}]}]}]).includes('重复'),'duplicate dynamic option values blocked')
check(business.businessValidation([{...definition(),fields:[{key:'__proto__',label:'名称',type:'text'}]}]).includes('字段标识'),'unsafe field keys rejected')
check(business.businessValidation([{...definition(),options:[{id:'x',title:'A'},{id:'x',title:'B'}]}]).includes('唯一'),'capability IDs must be stable and unique')
check(business.businessPayload([definition()])[0].commission_minimum==='200.00','money serialized with two decimals')
assert.deepEqual(Array.from(business.demandNames({demands:[{title:'移动'}],models:[{title:'旧型号'}]})),['移动']);checks++
const form=business.businessFormEntries({business_snapshot:{fields:[{key:'speed',label:'安装带宽',options:[{value:'one',label:'100M'}]}]},form_values:{speed:'one',address:'长地址'}})
check(form[0].label==='安装带宽'&&form[0].value==='100M'&&form[1].label==='address','detail uses frozen field labels/options and preserves unknown historical values')

const files=['cooperation/BusinessSettings.vue','cooperation/Settings.vue','cooperation/Leads.vue','cooperation/LeadDetail.vue','cooperation/Partners.vue','cooperation/home-page.vue','diy/components/edit-lead-cooperation-entry.vue','components/BusinessCapabilities.vue','components/MerchantPanel.vue','components/CatalogDrawer.vue']
const descriptors=new Map()
for(const name of files){const filename=path.join(plugin,'admin/views',name),source=fs.readFileSync(filename,'utf8'),parsed=compiler.parse(source,{filename});assert.deepEqual(parsed.errors,[]);const result=compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:name,compilerOptions:{expressionPlugins:['typescript']}});assert.deepEqual(result.errors,[]);compiler.compileScript(parsed.descriptor,{id:name});descriptors.set(name,parsed.descriptor);checks++}
const messages=[],writes=[],events=[]
let failPreview=false,failSave=false,supportsPreview=true
const catalogRows=[{id:'operator_old',title:'现有运营商',path:['宽带','运营商','现有运营商'],aliases:[]}],catalogReads=[],itemWrites=[],logReads=[]
const catalogUser=Vue.reactive({rules:['hsx_lead_catalog_items','hsx_lead_catalog_add','hsx_lead_catalog_edit','hsx_lead_catalog_delete','hsx_lead_catalog_logs','hsx_lead_manage_catalog_save']})
let dialogWork=async()=>{},itemSaveWork=null,failCatalogRead=false
const catalogApi={getCatalogItems:async params=>{catalogReads.push({...params});if(failCatalogRead)throw Error('合成目录读取失败');return{data:{data:catalogRows.map(row=>({...row})),total:catalogRows.length,revision:'a'.repeat(64),supports_item_management:true,supports_preview:supportsPreview,...params}}},getCatalogLogs:async params=>{logReads.push({...params});return{data:{data:[{id:1,operator_name:'合成管理员',action:'updated',create_time:1794096000,detail:{business_type:params.business_type,before:{title:'旧名'},after:{title:'新名'}}}],total:1}}},addCatalogItem:async data=>{itemWrites.push({method:'post',data});if(itemSaveWork)return itemSaveWork(data);const item={...data.item,id:data.item.id||'generated-id'};catalogRows.push(item);return{data:{item,revision:'b'.repeat(64)}}},updateCatalogItem:async(id,data)=>{itemWrites.push({method:'put',id,data});if(itemSaveWork)return itemSaveWork(data);const item={...data.item,id};catalogRows.splice(catalogRows.findIndex(row=>row.id===id),1,item);return{data:{item,revision:'c'.repeat(64)}}},deleteCatalogItem:async(id,data)=>{itemWrites.push({method:'delete',id,data});catalogRows.splice(catalogRows.findIndex(row=>row.id===id),1);return{data:{deleted:true,revision:'d'.repeat(64)}}},saveCatalog:async data=>{writes.push({...data});if(data.preview){if(failPreview)throw Error('第3项：名称不能为空');return{data:{preview:true,items:[{id:'operator_mobile',title:'移动',path:['宽带','运营商','移动']}]}}}if(failSave)throw Error('保存超时，请核对');return{data:{count:1}}}}
function setup(name,props,extra={}){const compiled=compiler.compileScript(descriptors.get(name),{id:name}),module=runModule(compiled.content,{vue:{...Vue,onMounted(){},onBeforeUnmount(){}},'element-plus':{ElMessage:{success:value=>messages.push(value),warning:value=>messages.push(value),error:value=>messages.push(value)},ElMessageBox:{confirm:(...args)=>dialogWork(...args)}},'@/stores/modules/user':{default:()=>catalogUser},'../../composables/navigation':{hasLeadPagePermission:(user,key)=>user.rules.includes(key)},'../../api':catalogApi,'../../composables/useLeadUi':{errorText:cause=>String(cause?.message||cause)},'../../composables/business':business,...extra});return module.default.setup(props,{expose(){},emit:(...args)=>events.push(args)})}
const catalog=setup('components/CatalogDrawer.vue',{modelValue:true,businessType:'broadband',businessName:'宽带'})
await catalog.load()
await catalog.chooseFile({name:'需求.xlsx',raw:{size:4,arrayBuffer:async()=>new Uint8Array([80,75,3,4]).buffer}})
check(catalog.format.value==='xlsx'&&catalog.content.value==='UEsDBA==','xlsx original bytes encoded as base64, not decoded as text')
await catalog.save();check(writes.length===0,'save is blocked before a successful preview and explicit scope confirmation')
failPreview=true;await catalog.preview();check(!catalog.previewReady.value&&catalog.error.value.includes('第3项')&&catalog.content.value,'preview error stays visible and source input is retained')
failPreview=false;await catalog.preview();check(catalog.previewReady.value&&writes.at(-1).business_type==='broadband'&&writes.at(-1).preview===true,'preview requests exact current business without saving')
await catalog.save();check(writes.at(-1).preview===true,'preview alone does not authorize replacement')
catalog.confirmed.value=true;failSave=true;await catalog.save();check(catalog.content.value&&catalog.previewReady.value&&catalog.error.value.includes('超时'),'failed save preserves full local file and preview')
failSave=false;await catalog.save();check(writes.at(-1).preview===false&&writes.at(-1).business_type==='broadband','replacement is scoped and explicitly differs from preview')
check(!catalog.content.value&&!catalog.previewReady.value&&events.some(row=>row[0]==='changed'),'successful save clears only saved local draft and refreshes caller')
await catalog.chooseFile({name:'huge.xlsx',raw:{size:2*1024*1024+1}});check(catalog.fileError.value.includes('2 MB')&&!catalog.content.value,'oversized spreadsheet blocked without dropping into upload')
supportsPreview=false;await catalog.load();catalog.content.value='legacy test';const beforeLegacy=writes.length;await catalog.preview();check(!catalog.previewSupported.value&&writes.length===beforeLegacy,'mixed-version server cannot turn a purported preview into an unintended old-style save');supportsPreview=true

check(catalogReads[0].business_type==='broadband'&&catalogReads[0].page===1&&catalogReads[0].limit===20,'initial list queries only the current business and one server page')
catalog.keyword.value='移动';await catalog.search();check(catalogReads.at(-1).keyword==='移动'&&catalogReads.at(-1).page===1,'search is sent to server and resets pagination')
await catalog.changePage({page:3,limit:50});check(catalogReads.at(-1).page===3&&catalogReads.at(-1).limit===50,'table pagination reaches the server instead of truncating the first100 forever')
catalog.editItem();await catalog.saveItem();check(itemWrites.length===0&&catalog.itemError.value.includes('填写名称'),'empty item name is blocked before mutation')
catalog.itemForm.title='新运营商';catalog.itemForm.third='末级';await catalog.saveItem();check(itemWrites.length===0&&catalog.itemError.value.includes('连续填写'),'classification holes are explained instead of silently shifting levels')
Object.assign(catalog.itemForm,{first:'宽带',second:'运营商',third:'新运营商'});await catalog.saveItem();check(itemWrites.at(-1).method==='post'&&itemWrites.at(-1).data.business_type==='broadband'&&itemWrites.at(-1).data.revision==='a'.repeat(64),'item add sends selected business and last persisted revision')
check(!catalog.editing.value&&events.some(event=>event[0]==='changed'),'successful item readback closes its editor and refreshes settings')
const original=catalogRows[0];catalog.editItem(original);catalog.itemForm.title='重命名运营商';await catalog.saveItem();check(itemWrites.at(-1).method==='put'&&itemWrites.at(-1).id==='operator_old'&&itemWrites.at(-1).data.item.id==='operator_old','editing retains the stable item id in URL and body')
catalog.editItem(catalogRows[0]);catalog.itemForm.title='失败草稿';itemSaveWork=async()=>{throw Error('目录已被其他操作修改，请刷新')};await catalog.saveItem();check(catalog.editing.value&&catalog.itemForm.title==='失败草稿'&&catalog.itemError.value.includes('已被其他操作修改'),'conflict preserves item draft and explains refresh instead of pretending save succeeded');itemSaveWork=null;catalog.closeEditor()
let releaseDelete;dialogWork=()=>new Promise(resolve=>{releaseDelete=resolve});const beforeDelete=itemWrites.length,pendingDelete=catalog.removeItem(catalogRows[0]);await catalog.removeItem(catalogRows[0]);check(catalog.saving.value&&itemWrites.length===beforeDelete,'delete submit lock spans the confirmation dialog');releaseDelete();await pendingDelete;check(itemWrites.length===beforeDelete+1&&itemWrites.at(-1).method==='delete','confirmed deletion submits exactly once');dialogWork=async()=>{}
await catalog.loadLogs();check(logReads.at(-1).business_type==='broadband'&&catalog.logs.value[0].operator_name==='合成管理员','logs are scoped to this business and show the responsible administrator')
catalog.logAction.value='deleted';await catalog.searchLogs();check(logReads.at(-1).action==='deleted'&&logReads.at(-1).page===1,'audit operation filter is sent to server')
const beforeFailedRead=catalog.items.value;failCatalogRead=true;await catalog.load();check(catalog.error.value.includes('目录读取失败')&&catalog.items.value===beforeFailedRead,'failed reload preserves prior rows with a visible error, not false empty state');failCatalogRead=false
catalogUser.rules=['hsx_lead_catalog_items'];catalog.editing.value=false;catalog.editItem();check(!catalog.editing.value,'read-only administrator cannot open an add editor');const beforeReadonly=itemWrites.length;await catalog.removeItem(catalogRows[0]);check(itemWrites.length===beforeReadonly,'read-only administrator cannot invoke delete')
check(descriptors.get('components/CatalogDrawer.vue').scriptSetup.content.includes('{immediate:true}'),'drawer mounted initially open loads without a manual refresh')

const caps=setup('components/BusinessCapabilities.vue',{modelValue:[{business_type:'broadband',option_ids:['operator_mobile'],items:[{id:'operator_mobile',title:'移动'}]}],definitions:[definition()]})
check(caps.selectedIds('new_phone').length===0&&caps.selectedIds('broadband').length===1,'empty business selection does not imply all capability')
caps.update('new_phone',['brand_apple']);check(events.at(-1)[1].length===2&&events.at(-1)[1].find(row=>row.business_type==='broadband'),'editing one capability preserves other businesses')
const singleCapability=setup('components/BusinessCapabilities.vue',{modelValue:[],definitions:[{...definition(),selection_mode:'single',selection_limit:1}]})
singleCapability.update('broadband',['operator_mobile','operator_unicom','operator_telecom']);check(events.at(-1)[1][0].option_ids.length===3,'merchant capabilities remain multiple and independent of customer single selection or quantity limit')
const merchantWrites=[]
let merchantStatus=0,failMerchant=false
const merchant=setup('components/MerchantPanel.vue',{initialFilter:{}},{
    '@element-plus/icons-vue':{Plus:{}},'../../api/cooperation':{getMerchantProfileFormRecord:async()=>({data:{fields:[]}})},'../../composables/cooperation':{coopBusiness:String},'../../composables/filtering':{hasListFilters:()=>false},'../../composables/serviceScope':{serviceScopeFor:()=> 'default'},'../../composables/authRenewal':{authRenewalLabel:String},
    '../../composables/useLeadUi':{errorText:cause=>cause.message,readyLabels:{},region:()=>'',syncLabel:String,useLeadList:()=>({rows:Vue.ref([]),total:Vue.ref(0),loading:Vue.ref(false),error:Vue.ref(''),query:Vue.reactive({}),load:async()=>{},search:async()=>{}})},
    '../../api':{getMerchant:async()=>({data:{id:7,name:'合成门店',contact_name:'合成联系人',mobile:'18800000001',province_id:910000,city_id:910100,district_id:910101,status:merchantStatus,business_capabilities:[{business_type:'broadband',option_ids:['operator_mobile']}],business_definitions:[definition()]}}),saveMerchant:async data=>{merchantWrites.push(JSON.parse(JSON.stringify(data)));if(failMerchant)throw Error('合成保存失败');return{data:{id:7}}}}
})
merchant.formRef.value={validate:async()=>true}
await merchant.open(7);merchant.form.name='调整名称';await merchant.save(false)
check(!('business_capabilities' in merchantWrites.at(-1))&&merchantWrites.at(-1).status===0,'paused merchant basic details do not rewrite unchanged capability or fail its stricter write gate')
merchantStatus=1;await merchant.open(7);merchant.form.business_capabilities=[{business_type:'broadband',option_ids:['operator_unicom']}];failMerchant=true;await merchant.save(false)
check(merchantWrites.at(-1).business_capabilities[0].option_ids[0]==='operator_unicom'&&merchant.visible.value&&merchant.form.business_capabilities[0].option_ids[0]==='operator_unicom','explicit changed capabilities are sent and preserved after save failure')
merchant.form.status=0;const beforePause=merchantWrites.length;await merchant.save(false);check(merchantWrites.length===beforePause&&messages.at(-1).includes('先保存业务能力'),'changing capability and pausing in one submission gives an explicit recoverable instruction')
const home=fs.readFileSync(path.join(plugin,'admin/views/cooperation/home-page.vue'),'utf8')
check(home.includes("path:'/decorate/edit'")&&home.includes("name:'DIY_HSX_LEAD_INDEX'")&&home.includes('permission="hsx_lead_cooperation_home"'),'home entry reuses verified framework route with dedicated permission')
console.log(`PASS ${checks} multi-business admin checks; real SFC compilation and setup with synthetic APIs, no HTTP or database mutations.`)
