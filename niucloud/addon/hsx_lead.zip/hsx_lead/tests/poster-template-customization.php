<?php
declare(strict_types=1);

// Exercise the real framework selection, merge and cache path. Only QR generation and
// the final raster renderer are doubled; neither WeChat nor an image service is called.
namespace app\service\core\poster {
    function qrcode($url,$page,$data,$site,$outfile='',$channel=''): string
    {
        \PosterTemplateCapture::$qrcodes[]=['url'=>$url,'page'=>$page,'data'=>$data,'site_id'=>$site,'channel'=>$channel];
        return 'synthetic-qr-'.hash('sha256',json_encode([$url,$page,$data,$site,$channel])).'.png';
    }
}
namespace {
    if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
    foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
    if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
    require __DIR__.'/bootstrap.php';
    require __DIR__.'/membership-fixtures.php';
    require_once dirname(__DIR__,3).'/vendor/autoload.php';
    use addon\hsx_lead\app\service\Context;
    use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,PosterShareService,PromotionService,TeamService};
    use addon\hsx_lead\app\listener\poster\LeadPosterData;
    use addon\hsx_lead\app\support\Data;
    use app\service\core\poster\CorePosterService;
    use app\service\core\sys\CoreConfigService;
    use think\facade\{Db,Event};

    final class PosterTemplateCapture
    {
        public static array $rendered=[],$qrcodes=[];
        public function createPoster($poster,$dir,$file): string
        {
            self::$rendered[]=$poster;$path=$dir.'/'.$file;
            if(file_put_contents($path,'SYNTHETIC_RENDER_ONLY')===false)throw new RuntimeException('Synthetic cache artifact failed');
            return $path;
        }
    }
    final class PosterTemplateCore extends CorePosterService
    {
        public function driver($site_id,$poster_type='poster') {return new PosterTemplateCapture();}
    }
    $checks=0;$pdo=null;$schema='';$ownedDirectory='';$oldDirectory=getcwd();$failed=false;
    function ptCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
    function ptActor(int $site,int $member,string $channel='h5',string $app='api',int $uid=0):void
    {
        $p=new ReflectionProperty(app\Request::class,'auth_info');$p->setAccessible(true);$p->setValue(null,['member_id'=>$member,'app_type'=>$app,'uid'=>$uid]);
        request()->siteId($site);request()->pushHeader([system_name('channel_name')=>$channel]);
    }
    function ptTemplate(string $marker,string $scene='promotion'):array
    {
        $items=[];
        foreach(['title'=>'自定义标题','subtitle'=>'自定义副标题','label'=>'自定义标签','note'=>'自定义提示'] as $key=>$text) $items[]=['id'=>$key,'type'=>'text','relate'=>'hsx_lead_'.$key,'value'=>$marker.$text];
        $items[]=['id'=>'static','type'=>'text','relate'=>'','value'=>$marker.'普通文字'];
        $items[]=['id'=>'identity','type'=>'text','relate'=>'hsx_lead_identity','value'=>'FORGED_TEMPLATE_IDENTITY'];
        $items[]=['id'=>'code','type'=>'text','relate'=>'hsx_lead_code','value'=>$scene==='entity'?'FORGED_SUBJECT_CODE':$marker.'自定义标语'];
        $items[]=['id'=>'qr','type'=>'qrcode','relate'=>'hsx_lead_qrcode','value'=>'https://attacker.invalid'];
        return ['global'=>['bgType'=>'color','bgColor'=>'#EDF5FF','bgUrl'=>'','width'=>750,'height'=>1100],'value'=>$items];
    }
    function ptValues():array{$last=PosterTemplateCapture::$rendered[array_key_last(PosterTemplateCapture::$rendered)];return array_column($last['value'],'value','id');}
    function ptPoster(int $site,string $type,array $value,int $default=1,int $status=1):int
    {
        return (int)Db::name('sys_poster')->insertGetId(['site_id'=>$site,'type'=>$type,'name'=>'Synthetic saved poster','addon'=>'hsx_lead','value'=>Data::json($value),'is_default'=>$default,'status'=>$status,'create_time'=>time(),'update_time'=>time()]);
    }
    try{
        [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$app->env->set('system.wap_domain','https://example.invalid');
        $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
        if(!preg_match('/CREATE TABLE\s+`sys_poster`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match))throw new RuntimeException('Official poster DDL missing');
        $pdo->exec(preg_replace('/CREATE TABLE\s+`sys_poster`/i','CREATE TABLE `lt_sys_poster`',$match[0],1));
        $ownedDirectory=sys_get_temp_dir().'/'.$schema.'_poster_templates';if(!mkdir($ownedDirectory,0700))throw new RuntimeException('Synthetic temporary directory failed');chdir($ownedDirectory);
        (new CoreConfigService())->setConfig($site,PromotionService::CONFIG_KEY,['enabled'=>true]);
        $profiles=[];
        foreach([101,102] as $i=>$member) {
            $profiles[$member]=(new PartnerService(new Context($site,0,$member)))->saveProfile(['name'=>'Synthetic poster store '.($i+1),'contact_name'=>'Synthetic operator','mobile'=>'1990000010'.($i+1),'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);
        }
        Event::listen('GetPosterData',static fn(array $data):array=>(new LeadPosterData())->handle($data));
        $type=PosterShareService::TYPES['promotion'];
        $foreign=ptPoster($site+1,$type,ptTemplate('FOREIGN_'));
        $wrongType=ptPoster($site,'unrelated_type',ptTemplate('WRONG_TYPE_'));
        $disabled=ptPoster($site,$type,ptTemplate('DISABLED_'),1,2);
        $first=ptPoster($site,$type,ptTemplate('CUSTOM_A_'));
        $second=ptPoster($site,$type,ptTemplate('CUSTOM_B_'),0);
        ptActor($site,101);$core=new PosterTemplateCore();$url=$core->get($site,0,$type,[],'h5',true);$values=ptValues();
        foreach(['title'=>'自定义标题','subtitle'=>'自定义副标题','label'=>'自定义标签','note'=>'自定义提示']as$key=>$suffix)ptCheck($values[$key]==='CUSTOM_A_'.$suffix,'saved default keeps editable '.$key.' even on a formerly dynamic component');
        ptCheck($values['static']==='CUSTOM_A_普通文字'&&$values['code']==='CUSTOM_A_自定义标语','plain text and promotion slogan stay template-owned');
        ptCheck($values['identity']==='Fixture 101','inviter identity remains actual authenticated account, never template text');
        $qr=PosterTemplateCapture::$qrcodes[array_key_last(PosterTemplateCapture::$qrcodes)];
        ptCheck($qr['site_id']===$site&&$qr['channel']==='h5'&&$qr['page']==='addon/hsx_lead/pages/invite/index'&&$qr['data']===[['key'=>'mid','value'=>'101'],['key'=>'pi','value'=>'1']],'QR is bound to current actor, tenant, login entry and actual channel');
        ptCheck(!str_contains(json_encode($values),'FOREIGN_')&&!str_contains(json_encode($values),'WRONG_TYPE_')&&!str_contains(json_encode($values),'DISABLED_'),'default selection excludes foreign site, wrong type and disabled rows');
        $renderCount=count(PosterTemplateCapture::$rendered);$qrCount=count(PosterTemplateCapture::$qrcodes);
        ptCheck($core->get($site,0,$type,[],'h5',true)===$url&&count(PosterTemplateCapture::$rendered)===$renderCount&&count(PosterTemplateCapture::$qrcodes)===$qrCount,'identical template and actor reuse the exact framework cache file');
        $edited=ptTemplate('CUSTOM_A_');$edited['value'][0]['value']='EDITED_TITLE_ONLY';Db::name('sys_poster')->where('id',$first)->update(['value'=>Data::json($edited)]);
        $editedUrl=$core->get($site,0,$type,[],'h5',true);
        ptCheck($editedUrl!==$url&&ptValues()['title']==='EDITED_TITLE_ONLY','editing saved text changes the framework template hash and rendered output without clearing caches');
        Db::name('sys_poster')->where('site_id',$site)->where('type',$type)->update(['is_default'=>0]);Db::name('sys_poster')->where('id',$second)->update(['is_default'=>1]);
        $changed=$core->get($site,0,$type,[],'h5',true);ptCheck($changed!==$editedUrl&&ptValues()['static']==='CUSTOM_B_普通文字','id zero honors the newly selected default saved template rather than the bundled dictionary');
        $explicit=$core->get($site,$first,$type,[],'h5',true);ptCheck($explicit===$editedUrl,'explicit poster ID obeys framework selection independently of the current default');
        ptActor($site,102);$actorUrl=$core->get($site,0,$type,['member_id'=>101,'url'=>'https://attacker.invalid'],'h5',true);$qr=PosterTemplateCapture::$qrcodes[array_key_last(PosterTemplateCapture::$qrcodes)];
        ptCheck($actorUrl!==$changed&&ptValues()['identity']==='Fixture 102'&&$qr['data'][0]['value']==='102','actor change alters data hash while forged param identity is ignored');
        ptActor($site,102,'weapp');$channelUrl=$core->get($site,0,$type,[],'weapp',true);$qr=PosterTemplateCapture::$qrcodes[array_key_last(PosterTemplateCapture::$qrcodes)];
        ptCheck($channelUrl!==$actorUrl&&$qr['channel']==='weapp','actual channel partitions the image cache and QR channel');
        leadMembershipSeed($site);leadSetEntryDefinition($site,702);
        $membershipConfig=ConfigService::defaults();$membershipConfig['enabled']=true;(new ConfigService(new Context($site,1)))->save($membershipConfig);
        foreach([101,102]as$owner)leadMembershipGrant($site,$owner,'ML702');
        $fixturePayments=Db::name('hsx_lead_coop_order')->count();
        $fixtureLedger=Db::name('member_account_log')->count();
        $entityType=PosterShareService::TYPES['entity'];ptPoster($site,$entityType,ptTemplate('ENTITY_','entity'));ptActor($site,101);
        $entityA=$core->get($site,0,$entityType,['subject_code'=>'AAAAAAAAAA','merchant_id'=>$profiles[102]['id']],'h5',true);$values=ptValues();$team=(new TeamService(new Context($site,0,101)))->summary();$code=$team['subject_code'];$qr=PosterTemplateCapture::$qrcodes[array_key_last(PosterTemplateCapture::$qrcodes)];
        ptCheck($values['title']==='ENTITY_自定义标题'&&$values['note']==='ENTITY_自定义提示','entity poster copy is also template-owned');
        ptCheck($values['identity']==='Synthetic poster store 1'&&str_contains($values['code'],$code)&&!str_contains($values['code'],'FORGED_'),'entity identity and subject code remain bound to current responsible owner');
        ptCheck($qr['page']==='addon/hsx_lead/pages/entity/index'&&$qr['data']===[['key'=>'subject_code','value'=>$code]],'entity QR ignores a forged code and foreign merchant from request parameters');
        ptActor($site,102);$entityB=$core->get($site,0,$entityType,[],'h5',true);$otherCode=(new TeamService(new Context($site,0,102)))->summary()['subject_code'];
        ptCheck($entityB!==$entityA&&$otherCode!==$code&&str_contains(ptValues()['code'],$otherCode),'different owners never reuse each other subject-code poster');
        ptActor($site,0,'h5','site',1);$preview=$core->get($site,0,$entityType,['mode'=>'preview'],'h5',true);$values=ptValues();$qr=PosterTemplateCapture::$qrcodes[array_key_last(PosterTemplateCapture::$qrcodes)];
        ptCheck($values['title']==='ENTITY_自定义标题'&&$values['note']==='ENTITY_自定义提示','editor preview retains the saved marketing copy');
        ptCheck($qr['data']===[]&&$qr['url']==='https://example.invalid'&&!str_contains(json_encode($values),$code),'editor preview uses synthetic QR, not a real member or store invite');
        ptCheck(Db::name('member_account_log')->count()===$fixtureLedger&&Db::name('hsx_lead_coop_order')->count()===$fixturePayments,'poster customization never creates additional financial orders or ledger entries beyond explicit seat fixture payments');
        echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'real framework default selection/create/cache hash and real plugin identity listener; random isolated schema; synthetic QR/raster doubles; no remote call or existing business data'],JSON_UNESCAPED_UNICODE).PHP_EOL;
    }catch(Throwable $e){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
    finally{
        Event::remove('GetPosterData');if($oldDirectory!==false)chdir($oldDirectory);
        if($ownedDirectory!==''&&is_dir($ownedDirectory)&&preg_match('/^hsx_lead_test_[a-f0-9]{16}_poster_templates$/D',basename($ownedDirectory))) {
            $it=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($ownedDirectory,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
            foreach($it as $file){if($file->isDir())rmdir($file->getPathname());else unlink($file->getPathname());}rmdir($ownedDirectory);
        }
        if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);
    }
    if($failed)exit(1);
}
