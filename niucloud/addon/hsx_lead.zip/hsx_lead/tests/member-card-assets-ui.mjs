import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const { GifReader }=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))('omggif')
let checks=0
const check=(condition,message)=>{assert.ok(condition,message);checks++}
for(const key of ['bronze','silver','gold','sapphire','amethyst','obsidian']){
    const png=fs.readFileSync(path.join(plugin,'resource/member-covers',key+'.png'))
    check(png.subarray(1,4).toString()==='PNG'&&png.readUInt32BE(16)===600&&png.readUInt32BE(20)===320,key+' static card is 600x320')
    check(png.length<150000,key+' static cover stays below 150 KB')
    const gif=fs.readFileSync(path.join(plugin,'resource/member-covers',key+'.gif')),reader=new GifReader(gif)
    check(reader.width===400&&reader.height===214&&reader.numFrames()===24&&reader.loopCount()===0,key+' small animation loops 24 frames')
    check(gif.length<250000,key+' animated cover stays below 250 KB')
    const first=Buffer.alloc(reader.width*reader.height*4),middle=Buffer.alloc(first.length)
    reader.decodeAndBlitFrameRGBA(0,first);first.copy(middle)
    for(let i=1;i<=16;i++)reader.decodeAndBlitFrameRGBA(i,middle)
    check(!first.equals(middle),key+' GIF contains an actual light change rather than a renamed still')
}
console.log(`PASS ${checks} packaged membership cover checks; reads only the twelve plugin-owned art assets.`)
