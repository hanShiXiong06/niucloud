<?php
declare(strict_types=1);
// Fresh localhost-only schema. The gateway callback is a double; external transports are disabled.
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable network functions before isolated testing\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\{Context,FrameworkNoticeGateway};
use addon\hsx_lead\app\service\notice\{AccountNoticePolicyService,FinancialNoticeService,NoticeEventCatalog,NoticePreferenceService};
use addon\hsx_lead\app\listener\member\AccountNoticeListener;
use addon\hsx_lead\app\listener\notice\AccountNoticeData;
use addon\hsx_lead\app\support\Data;
use core\exception\NoticeDeliveryException;
use think\facade\{Db,Event};

$checks=0;$pdo=null;$schema='';$failed=false;
function fundCheck(bool $value,string $label):void{if(!$value)throw new RuntimeException('Assertion failed: '.$label);$GLOBALS['checks']++;}
function fundReject(callable $call,string $label):void{try{$call();}catch(Throwable $e){fundCheck(true,$label);return;}throw new RuntimeException('Expected rejection: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$ctx=new Context($site,1);$calls=[];
    Event::remove('NoticeData');Event::listen('NoticeData',AccountNoticeData::class);
    $gateway=new FrameworkNoticeGateway(static function(string $channel,array $payload)use(&$calls):array{$calls[]=$payload;return['accepted'=>true,'channel'=>$channel,'provider_code'=>'0'];});
    $service=new FinancialNoticeService([$gateway,'dispatch']);$policy=new AccountNoticePolicyService();
    $source=static function(int $site,int $member=101,string $type='balance',string $delta='10.00',?int $when=null):array{
        $data=['site_id'=>$site,'member_id'=>$member,'account_type'=>$type,'account_data'=>$delta,'account_sum'=>'100.00','create_time'=>$when??time(),'from_type'=>'fixture','memo'=>'Private memo must never leave'];
        $data['account_log_id']=(int)Db::name('member_account_log')->insertGetId($data);return$data;
    };
    // insertGetId receives only actual official columns.
    $disabled=$source($site);fundCheck($service->recordAccountEvent($disabled)['recorded']===0,'new financial feature defaults off');
    $config=$policy->get($site);$accounts=array_values(array_filter($config['events'],static fn($e)=>$e['group']==='account'));fundCheck(count($accounts)===3&&array_column($accounts,'account_type')===['balance','money','commission'],'separate real framework account types');
    $settings=[];foreach(array_filter(NoticeEventCatalog::EVENTS,static fn($e)=>$e['account_type']!=='')as$key=>$entry)$settings[]=['event_key'=>$key,'enabled'=>true,'channels'=>['weapp'=>true],
        'weapp'=>['tid'=>'987654','kid_list'=>[1,2,3],'scene_desc'=>'Isolated synthetic fixture only','confirmed'=>true,'fields'=>[
            ['keyword'=>'thing1','variable'=>'account_name','label'=>'账户'],['keyword'=>'thing2','variable'=>'change_amount','label'=>'金额'],['keyword'=>'time3','variable'=>'occurred_at','label'=>'时间']]]];
    $policy->save($ctx,['enabled'=>true,'events'=>$settings]);$baseline=$policy->get($site)['source_after_id'];fundCheck($baseline===$disabled['account_log_id'],'activation records max real source ID');
    foreach(NoticeEventCatalog::EVENTS as$key=>$unused)Db::name('sys_notice')->where('site_id',$site)->where('key',NoticeEventCatalog::key($key))->update(['is_weapp'=>1,'weapp_template_id'=>'isolated-template-'.$key]);
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['weapp_openid'=>'isolated-member-101']);
    Event::remove('MemberAccount');Event::listen('MemberAccount',AccountNoticeListener::class);
    $realLog=(new \app\service\core\member\CoreMemberAccountService())->addLog($site,101,'balance','1.25','adjust','Isolated money adjustment');
    fundCheck(Db::name('hsx_lead_notice_task')->where('source_id',$realLog)->count()===1&&$calls===[],'real framework account hook supplies the exact source ID and only records intent');
    foreach(['money','commission']as$type){$real=(new \app\service\core\member\CoreMemberAccountService())->addLog($site,101,$type,'2.00','award','Isolated money adjustment');
        fundCheck(Db::name('hsx_lead_notice_task')->where('source_id',$real)->value('event_key')===NoticeEventCatalog::fromAccount($type),'real '.$type.' hook uses its own event');}
    $beforeRealRollback=(int)Db::name('hsx_lead_notice_task')->count();
    Event::listen('MemberAccount',static function(){throw new RuntimeException('Synthetic downstream rollback');});
    fundReject(static fn()=>(new \app\service\core\member\CoreMemberAccountService())->addLog($site,101,'balance','1.00','adjust','rollback'),'real account transaction can roll back after recording intent');
    fundCheck((int)Db::name('hsx_lead_notice_task')->count()===$beforeRealRollback&&$calls===[],'framework rollback also removes new intent');
    Event::remove('MemberAccount');Event::listen('MemberAccount',AccountNoticeListener::class);
    (new AccountNoticeListener())->handle(['site_id'=>$site,'member_id'=>101,'account_log_id'=>999999,'account_type'=>'balance','account_data'=>'1.00','account_sum'=>'1.00']);
    fundCheck($calls===[],'malformed notification listener never fails or sends during money change');
    fundCheck($service->recordAccountEvent($disabled)['recorded']===0,'no historical push before activation');
    $a=$source($site);fundCheck($service->recordAccountEvent($a)['recorded']===1,'real postactivation source creates intent');fundCheck($calls===[],'source event cannot send synchronously');
    fundCheck($service->recordAccountEvent($a)['recorded']===0,'repeated same event deduplicates');$b=$source($site);
    fundCheck($service->recordAccountEvent($b)['recorded']===1,'same second same amount distinct ledger IDs remain distinct');
    $task=(int)Db::name('hsx_lead_notice_task')->where('site_id',$site)->where('source_id',$a['account_log_id'])->value('id');
    fundReject(static fn()=>$service->recordAccountEvent(array_replace($a,['member_id'=>102])),'forged member cannot receive money event');
    fundReject(static fn()=>$service->recordAccountEvent(array_replace($a,['account_data'=>'11.00'])),'forged amount rejected');
    fundReject(static fn()=>$service->recordAccountEvent(array_replace($a,['account_sum'=>'1e2'])),'exponent decimal rejected');
    fundCheck($service->recordAccountEvent(array_replace($a,['site_id'=>$site+1]))['recorded']===0,'disabled other site cannot create tasks from foreign ledger');
    $count=(int)Db::name('hsx_lead_notice_task')->count();Db::startTrans();$rollback=$source($site);$service->recordAccountEvent($rollback);
    fundReject(static fn()=>$service->process($site,$task),'processing in transaction forbidden');Db::rollback();
    fundCheck((int)Db::name('hsx_lead_notice_task')->count()===$count&&$calls===[],'rollback removes intent without external delivery');
    $sent=$service->process($site,$task);fundCheck($sent['status']==='accepted'&&count($calls)===1,'official gateway and NoticeData produce accepted receipt');
    fundCheck($calls[0]['to']['member_id']===101&&$calls[0]['vars']['change_amount']==='10.00','correct owner and source amount sent');
    fundCheck(!str_contains(Data::json($calls),'Private memo'),'no source private memo in notification payload');
    $service->process($site,$task);fundCheck(count($calls)===1,'accepted event never auto resends');
    fundReject(static fn()=>$service->retry($ctx,$task,['confirm'=>true,'reason'=>'should not resend']),'accepted event cannot manual resend');
    $unknownSource=$source($site);$service->recordAccountEvent($unknownSource);$unknownId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$unknownSource['account_log_id'])->value('id');
    $unknown=new FinancialNoticeService(static function(){throw new RuntimeException('Synthetic transport timeout');});$unknown->process($site,$unknownId);
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$unknownId)->value('status')==='unknown','transport exception preserved as unknown');
    fundReject(static fn()=>$service->retry($ctx,$unknownId,['confirm'=>true,'reason'=>'cannot duplicate unknown']),'unknown results cannot manual resend');
    $staleSource=$source($site);$service->recordAccountEvent($staleSource);$staleId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$staleSource['account_log_id'])->value('id');
    Db::name('hsx_lead_notice_task')->where('id',$staleId)->update(['status'=>'dispatching','lease_until'=>time()-1,'lease_token'=>str_repeat('a',32)]);
    $authSource=$source($site);$service->recordAccountEvent($authSource);$authId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$authSource['account_log_id'])->value('id');
    $auth=new FinancialNoticeService(static function(){throw new NoticeDeliveryException('weapp','rejected','43101','Synthetic auth exhausted');});$auth->process($site,$authId);
    $authTask=Db::name('hsx_lead_notice_task')->where('id',$authId)->find();fundCheck($authTask['status']==='pending_authorization'&&(int)$authTask['attempt_count']===0,'authorization pauses without burning retry budget');
    (new NoticePreferenceService())->save($site,101,['preferences'=>[['event_key'=>'account_balance_changed','channel'=>'weapp','enabled'=>true]]]);
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$authId)->value('status')==='pending_authorization','preference switch does not invent native consent');
    (new NoticePreferenceService())->authorizationReported($site,101,['account_balance_changed']);$service->process($site,$authId);
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$authId)->value('status')==='accepted','native authorization signal safely wakes explicit rejection');
    $missing=$source($site,102);$service->recordAccountEvent($missing);$missingId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$missing['account_log_id'])->value('id');$service->process($site,$missingId);
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$missingId)->value('status')==='pending_recipient','missing recipient pauses without fake delivery');
    Db::name('member')->where('site_id',$site)->where('member_id',102)->update(['weapp_openid'=>'isolated-member-102']);
    $retryInput=['confirm'=>true,'reason'=>'会员已绑定身份','request_key'=>'isolated-manual-request'];$service->retry($ctx,$missingId,$retryInput);$service->retry($ctx,$missingId,$retryInput);
    fundCheck(Db::name('hsx_lead_notice_attempt')->where('task_id',$missingId)->where('status','queued')->count()===1,'manual request key deduplicates repeated clicks');
    fundReject(static fn()=>$service->retry($ctx,$missingId,array_replace($retryInput,['request_key'=>'different-request-key'])),'second concurrent manual request rejected');
    $service->process($site,$missingId);fundCheck(Db::name('hsx_lead_notice_task')->where('id',$missingId)->value('status')==='accepted','manual intent processed only by worker');
    $configSource=$source($site);$service->recordAccountEvent($configSource);$configId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$configSource['account_log_id'])->value('id');
    Db::name('sys_notice')->where('site_id',$site)->where('key',NoticeEventCatalog::key('account_balance_changed'))->update(['is_weapp'=>0]);$service->process($site,$configId);
    $waiting=Db::name('hsx_lead_notice_task')->where('id',$configId)->find();fundCheck($waiting['status']==='pending_configuration'&&(int)$waiting['attempt_count']===0&&Db::name('hsx_lead_notice_attempt')->where('task_id',$configId)->count()===0,'missing template pauses without an attempt');
    Db::name('sys_notice')->where('site_id',$site)->where('key',NoticeEventCatalog::key('account_balance_changed'))->update(['is_weapp'=>1]);
    Db::name('hsx_lead_notice_task')->where('id',$configId)->update(['next_retry_at'=>time()-1]);$service->process($site,$configId);
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$configId)->value('status')==='accepted','fixed template resumes in bounded automatic polling');
    $retrySource=$source($site);$service->recordAccountEvent($retrySource);$retryId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$retrySource['account_log_id'])->value('id');
    $transientCalls=0;$transient=new FinancialNoticeService(static function()use(&$transientCalls){$transientCalls++;throw new NoticeDeliveryException('weapp','rejected','-1','Synthetic service busy');});
    $transient->process($site,$retryId);$transient->process($site,$retryId);fundCheck($transientCalls===1,'backoff prevents immediate automatic resends');
    for($retry=0;$retry<2;$retry++){Db::name('hsx_lead_notice_task')->where('id',$retryId)->update(['next_retry_at'=>time()-1]);$transient->process($site,$retryId);}
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$retryId)->value('status')==='exhausted'&&$transientCalls===3,'recoverable rejection respects retry budget');
    $raceSource=$source($site);$service->recordAccountEvent($raceSource);$raceId=(int)Db::name('hsx_lead_notice_task')->where('source_id',$raceSource['account_log_id'])->value('id');
    $raceCalls=0;$race=null;$race=new FinancialNoticeService(static function($claim)use(&$race,&$raceCalls,$site,$raceId){$raceCalls++;$race->process($site,$raceId);return['accepted'=>true,'channel'=>'weapp','provider_code'=>'0'];});$race->process($site,$raceId);
    fundCheck($raceCalls===1&&Db::name('hsx_lead_notice_attempt')->where('task_id',$raceId)->count()===1,'overlapping worker observes lease and cannot claim a second send');
    fundCheck($service->page($ctx,['keyword'=>'19900000101'])['total']>=1,'phone filter uses actual member identity');
    fundReject(static fn()=>$service->detail(new Context($site+1,0,103),$task),'member cannot use administrative task endpoint');
    fundReject(static fn()=>(new NoticePreferenceService())->get($site,103),'preferences cannot cross sites');
    $missed=$source($site);$before=count($calls);$result=$service->recover(50,$site);
    fundCheck($result['reconstructed']>=1&&Db::name('hsx_lead_notice_task')->where('source_id',$missed['account_log_id'])->count()===1,'postactivation compensation reconstructs source missed by listener');
    fundCheck(count($calls)>$before,'compensation sends through injected gateway after commit');
    fundCheck(Db::name('hsx_lead_notice_task')->where('id',$staleId)->value('status')==='unknown','stale in-flight lease becomes unknown and never resends');
    fundCheck($policy->get($site)['source_after_id']===$baseline,'worker never advances activation baseline as business config');
    $policy->save($ctx,['ttl_seconds'=>3600]);fundCheck($policy->get($site)['source_after_id']===$baseline,'config edits never reset activation baseline');
    $policy->save($ctx,['enabled'=>false]);$later=$source($site);(new AccountNoticeListener())->handle($later);
    fundCheck(Db::name('hsx_lead_notice_task')->where('source_id',$later['account_log_id'])->count()===0,'disabled feature does not create financial tasks');
    $beforeResume=(int)Db::name('hsx_lead_notice_task')->count();$beforeResumeCalls=count($calls);$service->recover(50,$site);
    fundCheck((int)Db::name('hsx_lead_notice_task')->count()===$beforeResume&&count($calls)===$beforeResumeCalls,'disabled recovery never creates or sends notices');
    $policy->save($ctx,['enabled'=>true]);fundCheck($policy->get($site)['source_after_id']===$baseline&&$policy->get($site)['resume_after_id']===$later['account_log_id'],'resuming records a new cutoff while first activation baseline remains immutable');
    $service->recover(50,$site);fundCheck(Db::name('hsx_lead_notice_task')->where('source_id',$later['account_log_id'])->count()===0,'resuming never reconstructs transactions that occurred while disabled');
    $afterResume=$source($site);$service->recover(50,$site);fundCheck(Db::name('hsx_lead_notice_task')->where('source_id',$afterResume['account_log_id'])->value('status')==='accepted','new transactions following resume continue through normal delivery');
    $smsPreference=(new NoticePreferenceService())->get($site,101);fundCheck($smsPreference['events'][0]['channels'][2]['enabled']===false,'billable SMS preference defaults off');
    $wrongTemplate=$settings[0];$wrongTemplate['weapp']['fields'][1]['keyword']='amount2';
    fundReject(static fn()=>$policy->save($ctx,['events'=>[$wrongTemplate]]),'unverified amount field type cannot silently enter official templates');
    $wrongTemplate=$settings[0];$wrongTemplate['weapp']['confirmed']=false;
    fundReject(static fn()=>$policy->save($ctx,['events'=>[$wrongTemplate]]),'unconfirmed public-template fields cannot be saved');
    fundReject(static fn()=>$policy->save(new Context($site,0,101),['enabled'=>false]),'member cannot alter site financial notification policy');
    // Real controllers must use token identities, never submitted owner/site IDs.
    $before101=(new NoticePreferenceService())->get($site,101)['events'][0]['channels'][0]['enabled'];
    $request=new \app\Request();$request->siteId($site);$request->memberId(102);$request->withGet(['site_id'=>$site+1,'member_id'=>101,'preferences'=>[['event_key'=>'account_balance_changed','channel'=>'weapp','enabled'=>false]]]);$app->instance('request',$request);
    $prefsResponse=(new \addon\hsx_lead\app\api\controller\Notice($app))->savePreferences()->getData()['data'];
    fundCheck($prefsResponse['events'][0]['channels'][0]['enabled']===false&&(new NoticePreferenceService())->get($site,101)['events'][0]['channels'][0]['enabled']===$before101,'preference endpoint ignores forged member and site parameters');
    fundCheck(Db::name('hsx_lead_notice_preference')->where('site_id',$site+1)->count()===0,'preference endpoint cannot write another site');
    $request=new \app\Request();$request->siteId($site);$request->memberId(101);$request->withGet(['member_id'=>102,'event_keys'=>['account_balance_changed']]);$app->instance('request',$request);
    $httpCalls=count($calls);(new \addon\hsx_lead\app\api\controller\Notice($app))->authorization();fundCheck(count($calls)===$httpCalls,'authorization HTTP only wakes tasks, never sends');
    Db::name('sys_user')->insert(['uid'=>2,'username'=>'read-only-notice-fixture','real_name'=>'Read only','status'=>1]);
    Db::name('sys_menu')->insert(['menu_key'=>'hsx_lead_notice_center_read','app_type'=>'site','status'=>1]);
    $role=(int)Db::name('sys_role')->insertGetId(['site_id'=>$site,'role_name'=>'Read only notice fixture','rules'=>Data::json(['hsx_lead_notice_center_read']),'status'=>1]);
    Db::name('sys_user_role')->insert(['site_id'=>$site,'uid'=>2,'status'=>1,'is_admin'=>0,'role_ids'=>Data::json([$role])]);
    $request=new \app\Request();$request->siteId($site);$request->uid(2);$request->withGet(['site_id'=>$site+1,'page'=>1]);$app->instance('request',$request);
    $readOnly=new \addon\hsx_lead\app\adminapi\controller\Notice($app);fundCheck($readOnly->tasks()->getData()['data']['total']>0,'read-only operator can read its own site financial tasks');
    fundReject(static fn()=>$readOnly->saveSettings(),'read permission never grants notification configuration writes');
    fundReject(static fn()=>$readOnly->retry($missingId),'read permission never grants manual resend');
    fundReject(static fn()=>$readOnly->attempts($task),'separate attempt-detail permission is enforced');
    Db::name('sys_user_role')->insert(['site_id'=>$site+1,'uid'=>1,'status'=>1,'is_admin'=>1]);
    $request=new \app\Request();$request->siteId($site+1);$request->uid(1);$request->withGet(['site_id'=>$site,'page'=>1]);$app->instance('request',$request);
    fundCheck((new \addon\hsx_lead\app\adminapi\controller\Notice($app))->tasks()->getData()['data']['total']===0,'even an authorized other-site admin cannot use a supplied site ID to read tasks');
    fundReject(static fn()=>(new \addon\hsx_lead\app\adminapi\controller\Notice($app))->attempts($task),'attempt endpoint rejects a foreign-site task');
    $request=new \app\Request();$request->siteId($site);$request->uid(1);$app->instance('request',$request);
    foreach([0,2,3]as$siteStatus){Db::name('site')->where('site_id',$site)->update(['status'=>$siteStatus]);$stopped=$source($site);$beforeStopped=count($calls);
        fundCheck($service->recordAccountEvent($stopped)['recorded']===0&&$service->recover(50,$site)['processed']===0&&count($calls)===$beforeStopped,'non-normal site '.$siteStatus.' cannot record or send financial reminders');}
    Db::name('site')->where('site_id',$site)->update(['status'=>1,'expire_time'=>time()-1]);$expiredSiteSource=$source($site);
    fundCheck($service->recordAccountEvent($expiredSiteSource)['recorded']===0&&$service->recover(50,$site)['processed']===0,'expired site cannot record or send financial reminders');
    Db::name('site')->where('site_id',$site)->update(['expire_time'=>0]);
    $group=(int)Db::name('site_group')->insertGetId(['group_name'=>'Only package authorization','app'=>'["hsx_lead"]','addon'=>'[]']);$groupSite=$site+2;
    Db::name('site')->insert(['site_id'=>$groupSite,'site_name'=>'Package-only fixture','app_type'=>'site','app'=>'[]','addons'=>'[]','group_id'=>$group,'status'=>1]);
    Db::name('member')->insert(['site_id'=>$groupSite,'member_id'=>108,'nickname'=>'Package member','mobile'=>'19900000108','weapp_openid'=>'isolated-package-member']);
    Db::name('sys_user_role')->insert(['site_id'=>$groupSite,'uid'=>1,'status'=>1,'is_admin'=>1]);
    fundCheck(AccountNoticePolicyService::installed($groupSite),'framework package-only addon authorization is recognized');
    $policy->save(new Context($groupSite,1),['enabled'=>true,'events'=>[$settings[0]]]);Db::name('sys_notice')->where('site_id',$groupSite)->where('key',NoticeEventCatalog::key('account_balance_changed'))->update(['is_weapp'=>1,'weapp_template_id'=>'package-only-template']);
    $packageSource=$source($groupSite,108);$service->recover(50);
    fundCheck(Db::name('hsx_lead_notice_task')->where('site_id',$groupSite)->where('source_id',$packageSource['account_log_id'])->value('status')==='accepted','bounded global recovery includes package-only sites');
    $cold=Db::connect(null,true);fundCheck(!$cold->getPdo() instanceof PDO,'independent handler begins with lazy uninitialized PDO');
    $service->process($site,$task);fundCheck($cold->getPdo() instanceof PDO,'cold handler establishes safe read-only master probe before checking transaction state');
    $sentBeforeWrongHook=count($calls);Event::remove('NoticeData');Event::listen('NoticeData',static fn()=>['to'=>['member_id'=>102],'vars'=>[
        '__hsx_lead_notice_id'=>'1','__hsx_lead_notice_channel'=>'weapp','__hsx_lead_notice_attempt'=>'1','__hsx_lead_notice_lease'=>'lease-fixture']]);
    fundReject(static fn()=>$gateway->dispatch(['site_id'=>$site,'key'=>'hsx_lead_account_balance_changed','channel'=>'weapp','template'=>[],'expected_recipient_member_id'=>101,
        'data'=>['financial_task_id'=>1,'notice_attempt'=>1,'lease_token'=>'lease-fixture']]),'wrong NoticeData recipient cannot hijack typed notice delivery');
    fundCheck(count($calls)===$sentBeforeWrongHook,'recipient mismatch never enters official channel sender');
    Event::remove('NoticeData');Event::listen('NoticeData',AccountNoticeData::class);
    echo 'PASS financial notification assertions: '.$checks.PHP_EOL;
}catch(Throwable $error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().PHP_EOL.$error->getTraceAsString().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
