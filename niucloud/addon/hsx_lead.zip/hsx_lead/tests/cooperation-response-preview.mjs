import assert from 'node:assert/strict'
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
// Actual isolated uni H5 output, not hand-reconstructed HTML. Every API is a
// synthetic browser route; unexpected remote traffic and writes are blocked.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..')
const artifact=process.env.HSX_NOTICE_H5_DIR||'/private/tmp/hsx-lead-notice-h5-20261109',output=path.join(workspace,'output/hsx-lead-response-mobile-20261109'),{chromium}=createRequire('/tmp/package.json')('playwright')
fs.mkdirSync(output,{recursive:true})
const mime={'.html':'text/html;charset=utf-8','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.ttf':'font/ttf'},clone=v=>JSON.parse(JSON.stringify(v))
const server=http.createServer((req,res)=>{const url=new URL(req.url,'http://localhost'),file=path.resolve(artifact,decodeURIComponent(url.pathname).replace(/^\/wap\//,'')),candidate=file.startsWith(artifact+path.sep)&&fs.existsSync(file)&&fs.statSync(file).isFile()?file:path.join(artifact,'index.html');res.setHeader('Content-Type',mime[path.extname(candidate)]||'application/octet-stream');res.end(fs.readFileSync(candidate))})
const member={member_id:101,member_no:'NIU0000101',nickname:'本地测试负责人',mobile:'13900000000',headimg:'',balance:'0.00'},profile={id:7,site_id:100006,member_id:101,name:'合成发布门店',mobile:'13900000000',region_text:'河北省 / 石家庄市 / 长安区',can_publish:true,can_accept:true,permissions:{},membership:{active:true,level_name:'青铜'}}
const init={tabbar_list:{},map_config:{is_open:0,valid_time:0,map_type:'tencent',key:''},theme_list:[],site_info:{site_id:100006,site_name:'本地验收',app:['hsx_lead'],site_addons:[{key:'hsx_lead'}],site_logo:''},copyright:{},member_level:[],login_config:{is_username:1,is_mobile:0,is_auth_register:0,is_force_access_user_info:0,is_bind_mobile:0,agreement_show:0,wechat_error:'',bg_url:'',logo:'',desc:''},member_exist:1}
const stores=[{id:8,name:'合成原交付门店'},{id:9,name:'合成新交付门店'}].map(row=>({...row,region_text:'河北省 / 石家庄市 / 长安区',capability_source:'manual',manual_model_count:2,erp_visible:false,business_type:'purchase',business_capabilities:[{business_type:'purchase',items:[{id:'iphone16'}]}],membership:{active:false,level_name:'普通会员'}}))
let mode='pending',receiver=8,version=3,browser,page;const errors=[],blocked=[],requests=[],writes=[],unknownBusiness=[],checks=[],geometry=[]
function lead(){const now=Math.floor(Date.now()/1000),incoming=mode==='incoming',overdue=mode!=='pending';return{id:51,site_id:100006,status:'assigned',status_label:incoming?'待接单':'待对方接单',lead_no:'LC202611090051',assignment_version:version,publisher_id:7,receiver_id:receiver,publisher:{name:'合成发布门店'},receiver:clone(stores.find(row=>row.id===receiver)),can_reassign:!incoming,can_withdraw:!incoming,can_accept:incoming,can_reject:incoming,can_assign:false,response_deadline:now+(overdue?-60:295),server_time:now,response_remaining_seconds:overdue?0:295,response_overdue:overdue,customer_name:'合成客户',mobile:incoming?'':'13900000001',region_text:'河北省 / 石家庄市 / 长安区',business_type:'purchase',business_name:'二手机',demands:[{id:'iphone16',title:'iPhone 16'}],commission_minimum:'50.00',fee_percent:'10.00',fee_minimum:'9.90',fee_confirmed:true,create_time:now-60,fields:[],attachments:[],history:[]}}
try{
 assert.ok(fs.existsSync(path.join(artifact,'index.html')),'Run root isolated H5 build first')
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port
 browser=await chromium.launch({headless:true,executablePath:process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disable-component-update','--no-first-run']})
 const context=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,reducedMotion:'reduce',isMobile:true,hasTouch:true})
 await context.addInitScript(()=>{localStorage.setItem('wapToken','synthetic-response-local-only');for(const[key,data]of Object.entries({wap_member_id:101,wap_site_id:100006,wap_member_info:{member_id:101,member_no:'NIU0000101',mobile:'13900000000'}}))localStorage.setItem(key,JSON.stringify({type:typeof data,data}))})
 await context.route('**/*',async route=>{
  const request=route.request(),url=new URL(request.url()),p=url.pathname.replace(/^\/api\//,'/'),method=request.method()
  if(url.origin===origin&&!url.pathname.startsWith('/api/'))return route.continue()
  if(url.hostname==='at.alicdn.com'&&url.pathname.endsWith('.ttf')||url.hostname==='cdn.dcloud.net.cn'&&url.pathname==='/img/shadow-grey.png')return route.abort('blockedbyclient')
  if(url.hostname==='sass.hsxbk.top'||url.origin===origin&&url.pathname.startsWith('/api/')){
   requests.push({path:p,method});let data={},code=1,msg='本地合成响应'
   if(method==='OPTIONS')return route.fulfill({status:204,headers:{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'*'}})
   if(p==='/init')data=init
   else if(p==='/member/member')data=member
   else if(p==='/hsx_lead/cooperation/bootstrap')data={current_member_id:101,profile:{...profile,can_publish:mode!=='expired',membership:{...profile.membership,active:mode!=='expired'}},config:{enabled:true,publishing_required:mode==='expired',erp_visible:false,businesses:[]},providers:[],stats:{},wallet:{}}
   else if(p==='/hsx_lead/cooperation/leads/51'&&method==='GET')data=lead()
   else if(p==='/hsx_lead/cooperation/leads/51/stores')data={data:clone(stores),total:2,scope:'city',reason:'本市有2家可选门店'}
   else if(p==='/hsx_lead/cooperation/leads/51/assign'&&method==='POST'){
    const payload=request.postDataJSON();writes.push({path:p,...payload});assert.equal(payload.replace,true);assert.equal(payload.assignment_version,version);assert.equal(payload.merchant_id,9);receiver=9;version++;data=lead()
   }else if(p.includes('/hsx_lead/')&&method!=='GET'){unknownBusiness.push({path:p,method});code=0;msg='离线验收阻止了未声明的写入'}
   else if(p==='/site')data=init.site_info
   else if(p.includes('/template')||p.includes('/share')||p.includes('/subscribe'))data={}
   return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'*'},body:JSON.stringify({code,msg,data})})
  }
  blocked.push(url.origin+url.pathname);return route.abort('blockedbyclient')
 })
 page=await context.newPage();page.setDefaultTimeout(15000);page.on('pageerror',e=>errors.push(e.message));const url=origin+'/wap/addon/hsx_lead/pages/task/index?task=detail&collaboration_id=51',button=text=>page.locator('.coop-sheet.is-page:visible .coop-sheet__footer .u-button').filter({hasText:text})
 await page.goto(url,{waitUntil:'networkidle',timeout:60000});await page.getByText('接单提醒倒计时',{exact:true}).waitFor();await page.locator('.coop-sheet.is-page .coop-sheet__footer .u-button').getByText('重新选择门店',{exact:true}).waitFor()
 const readCount=requests.length;await page.waitForTimeout(2150);assert.equal(requests.length,readCount);assert.equal(writes.length,0);checks.push('真实倒计时本地更新，不每秒请求，不自动撤回或转派')
 for(const width of[350,390]){
  await page.setViewportSize({width,height:844});await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))))
  const size=await page.locator('.coop-sheet.is-page').evaluate(node=>{const footer=node.querySelector('.coop-sheet__footer'),body=node.querySelector('.coop-sheet__body');return{width:innerWidth,documentWidth:document.documentElement.scrollWidth,footerTop:footer.getBoundingClientRect().top,footerBottom:footer.getBoundingClientRect().bottom,bodyWidth:body.clientWidth,bodyScrollWidth:body.scrollWidth,bodyHeight:body.clientHeight,height:innerHeight}});geometry.push(size);assert.ok(size.documentWidth<=width+1&&size.bodyScrollWidth<=size.bodyWidth+1&&size.footerBottom<=845&&size.bodyHeight>150);await page.screenshot({path:path.join(output,'pending-'+width+'.png'),fullPage:false})
 }
 checks.push('350/390真实手机布局无横向溢出，倒计时、滚动正文与主次按钮可见')
 mode='incoming';await page.reload({waitUntil:'networkidle'});await page.getByText('接单提醒时间已到',{exact:true}).waitFor();await page.getByText('仍可接受本次交付；发布方重新选店后将不可再接单。',{exact:true}).waitFor();const accept=page.locator('.coop-sheet.is-page .coop-sheet__footer .u-button').filter({hasText:'接受交付'});assert.equal(await accept.evaluate(node=>node.getAttribute('disabled')==='true'||node.getAttribute('aria-disabled')==='true'||node.classList.contains('u-button--disabled')),false);assert.equal(writes.length,0);await page.screenshot({path:path.join(output,'overdue-receiver-390.png'),fullPage:false});checks.push('超时接收方仍能接单，文案明确未被自动关单或转派')
 mode='expired';await page.reload({waitUntil:'networkidle'});await page.getByText('接单提醒时间已到',{exact:true}).waitFor();await button('重新选择门店').click();await page.waitForURL(/task=select/);await page.locator('.coop-store').filter({hasText:'合成新交付门店'}).waitFor();assert.equal(receiver,8);assert.equal(writes.length,0);await page.getByText('暂不更换，保留原门店',{exact:true}).click();await page.waitForURL(/task=detail/);assert.equal(receiver,8);assert.equal(writes.length,0);await page.locator('.coop-detail-party').filter({hasText:'承接方'}).getByText('合成原交付门店',{exact:true}).waitFor();checks.push('发布方权益到期仍可管理原合法线索；重选进入真实页面栈，取消回原店且零写入')
 await button('重新选择门店').click();await page.waitForURL(/task=select/);await page.locator('.coop-store').filter({hasText:'合成新交付门店'}).click();await button('确认更换门店').click();await page.locator('.uni-modal').getByText('确认更换交付门店',{exact:true}).waitFor();await page.locator('.uni-modal__btn_default').click();assert.equal(writes.length,0);assert.equal(receiver,8);checks.push('最终确认框取消也不改变原交付')
 await button('确认更换门店').click();await page.locator('.uni-modal').getByText('确认更换交付门店',{exact:true}).waitFor();await page.waitForTimeout(350);await page.screenshot({path:path.join(output,'replace-confirm-390.png'),fullPage:false});await page.locator('.uni-modal__btn_primary').click();await page.waitForURL(/task=detail/);await page.locator('.coop-detail-party').filter({hasText:'承接方'}).getByText('合成新交付门店',{exact:true}).waitFor();assert.equal(writes.length,1);assert.equal(writes[0].replace,true);assert.equal(writes[0].assignment_version,3);assert.equal(version,4);await page.screenshot({path:path.join(output,'replacement-complete-390.png'),fullPage:false});checks.push('确认后只发一次replace+version原子请求；详情刷新为新门店，不执行withdraw')
 assert.deepEqual(errors,[]);assert.deepEqual(blocked,[]);assert.deepEqual(unknownBusiness,[])
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify({passed:true,checks,geometry,errors,blocked,writes,requests,scope:'Actual isolated uni-app H5 with synthetic browser API routes. No real messages, financial changes, backend writes or production. H5 rendering is not native WeChat device acceptance; external icon font blocked offline.'},null,2));console.log(JSON.stringify({passed:true,checks,output,errors,blocked,writes}))
}catch(error){console.error(JSON.stringify({error:String(error),body:page?await page.locator('body').innerText():'',errors,blocked,requests,writes,geometry}));throw error}finally{await browser?.close();await new Promise(resolve=>server.close(resolve))}
