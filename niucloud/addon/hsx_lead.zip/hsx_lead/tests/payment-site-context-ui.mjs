import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { viteFixture } from './vite-fixture.mjs'

// Execute real framework site resolution/request headers and the real plugin hook.
// Native request is a synthetic local callback; no HTTP, credentials, database,
// storage writes, order creation, cashier opening or publication is performed.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const workspace = path.resolve(plugin, '../../..'), mobile = path.join(workspace, 'uni-app/src')
const require = createRequire(path.join(workspace, 'uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript'), pre = require('@dcloudio/uni-cli-shared'), compiler = require('@vue/compiler-sfc')
const read = filename => fs.readFileSync(filename, 'utf8')
const hookSource = read(path.join(plugin, 'uni-app/composables/useCooperation.ts'))
const requestSource = read(path.join(mobile, 'utils/request.ts'))
const commonPath = path.join(mobile, 'utils/common.ts'), commonSource = read(commonPath)
const commonAst = ts.createSourceFile(commonPath, commonSource, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
const getSiteIdSource = commonAst.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'getSiteId')?.getText(commonAst)
assert.ok(getSiteIdSource, 'real framework getSiteId is present')
const workbench = compiler.parse(read(path.join(plugin, 'uni-app/components/cooperation/CooperationWorkbench.vue'))).descriptor.scriptSetup.content
const workbenchAst = ts.createSourceFile('CooperationWorkbench.ts', workbench, ts.ScriptTarget.Latest, true, ts.ScriptKind.TS)
const storageDeclaration = workbenchAst.statements.filter(ts.isVariableStatement).flatMap(node => [...node.declarationList.declarations]).find(node => node.name.getText(workbenchAst) === 'storageKey')?.getText(workbenchAst)
assert.ok(storageDeclaration, 'real Workbench payment cache-key expression is present')
let checks = 0, syntheticReads = 0
const check = (value, label) => { assert.ok(value, label); checks++ }

function execute(source, dependencies, globals, options) {
    const code = ts.transpileModule(viteFixture(source, options), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + code + '\n})', { Number, String, Date, Math, Object, Array, Map, Set, Promise, JSON, console, ...globals })(name => {
        if (!(name in dependencies)) throw new Error('Unexpected fixture dependency: ' + name)
        return dependencies[name]
    }, module, module.exports)
    return module.exports
}

async function scenario({ label, platform = 'mp-weixin', mode = 'production', configured = '100006', cached = '', extension = '', href = 'https://synthetic.invalid/wap/home', expected, currentMember = 101 }) {
    pre.initPreContext(platform)
    const headers = [], storage = new Map(cached === '' ? [] : [['wap_site_id', cached]])
    let writes = 0
    const runtime = {
        getStorageSync: key => storage.get(key),
        setStorageSync: () => { writes++; throw new Error('Site context lookup cannot write device storage') },
        getExtConfigSync: () => extension === '' ? {} : { site_id: extension },
        $u: { deepClone: value => JSON.parse(JSON.stringify(value)) },
        request: options => {
            assert.equal(options.method, 'GET', label + ': only a read request is permitted')
            assert.equal(options.url, 'https://synthetic.invalid/api/hsx_lead/cooperation/bootstrap?', label + ': no order or other endpoint is permitted')
            headers.push({ ...options.header }); syntheticReads++
            options.success({ data: { code: 1, data: { current_member_id: currentMember, profile: { id: 7, member_id: 501, member_no: '0001' }, config: {}, providers: [], stats: {}, wallet: {} } } })
        }
    }
    const globals = { uni: runtime, location: { href, origin: 'https://synthetic.invalid' } }
    const options = { mode, siteId: configured, env: { VITE_APP_BASE_URL: 'https://synthetic.invalid/api/', VITE_REQUEST_HEADER_SITEID_KEY: 'site-id', VITE_REQUEST_HEADER_TOKEN_KEY: 'token', VITE_REQUEST_HEADER_CHANNEL_KEY: 'channel' } }
    const actualSite = execute(pre.preJs(getSiteIdSource), {}, globals, options).getSiteId
    const common = { getSiteId: actualSite, getToken: () => 'synthetic-account-token', getAppChannel: () => platform === 'mp-weixin' ? 'weapp' : 'h5', redirect: () => { throw new Error('Unexpected authentication redirect') }, currRoute: () => '', isUrl: value => /^https?:/.test(value) }
    const request = execute(pre.preJs(requestSource), { '@/stores/member': { default: () => { throw new Error('Unexpected account mutation') } }, '@/locale': { t: value => value }, './common': common, qs: { default: require('qs') } }, globals, options).default
    const api = { cooperationBootstrap: () => request.get('hsx_lead/cooperation/bootstrap', {}, { showErrorMessage: false }), coopError: cause => cause.message }
    const state = execute(pre.preJs(hookSource), { vue: Vue, '@/utils/common': common, '../api/cooperation': api }, globals, options).useCooperation()
    const key = execute('export function paymentKey(ui, context) { const ' + storageDeclaration + '; return storageKey(context) }', {}, globals, options).paymentKey
    state.resume(); const loaded = await state.bootstrap()
    check(loaded && state.ready.value, label + ': actual bootstrap completes from the isolated native transport')
    check(headers.length === 1 && String(headers[0]['site-id'] ?? '') === expected, label + ': framework request sends the expected site')
    check(state.siteId() === expected && state.siteId() === String(headers[0]['site-id'] ?? ''), label + ': plugin and actual request agree on the exact site')
    check(state.memberId.value === currentMember && state.profile.value.member_id === 501, label + ': payer is the verified viewer, not the store owner or display number')
    const cache = key(state, { purpose: 'commission', leadId: 77 })
    if (expected && currentMember > 0) check(cache === `hsx_lead_coop_pay:${expected}:${currentMember}:7:commission:77`, label + ': actual payment pointer is scoped to this site, payer, shop and lead')
    else check(cache === '', label + ': absent site or current member cannot acquire an anonymous payment pointer')
    check(writes === 0 && storage.get('wap_site_id') === (cached || undefined), label + ': reading configured site does not rewrite device storage')
    state.dispose()
}

for (const test of [
    { label: 'MP production first use, no cached site', expected: '100006' },
    { label: 'MP production ignores another site left in cache', cached: '100005', expected: '100006' },
    { label: 'MP production supports another configured tenant', configured: '100008', expected: '100008' },
    { label: 'MP extension config overrides build value', extension: '100009', cached: '100005', expected: '100009' },
    { label: 'MP development configured site wins', mode: 'development', cached: '100005', expected: '100006' },
    { label: 'MP development can use cache when build has no site', mode: 'development', configured: '', cached: '100008', expected: '100008' },
    { label: 'MP production missing config never silently uses stale cache', configured: '', cached: '100006', expected: '' },
    { label: 'MP extension config can supply otherwise missing build site', configured: '', extension: '100010', expected: '100010' },
    { label: 'H5 URL tenant overrides compiled default', platform: 'h5', href: 'https://synthetic.invalid/wap/100005/addon/hsx_lead/pages/task/index', expected: '100005' },
    { label: 'H5 without tenant in URL uses build config', platform: 'h5', expected: '100006' },
    { label: 'H5 other tenant URL is never replaced by 100006', platform: 'h5', cached: '100006', href: 'https://synthetic.invalid/wap/100011/addon/hsx_lead/pages/task/index', expected: '100011' },
    { label: 'H5 development falls back to cache', platform: 'h5', mode: 'development', configured: '', cached: '100012', expected: '100012' },
    { label: 'H5 missing every source stays unscoped', platform: 'h5', configured: '', expected: '' },
    { label: 'Verified site cannot replace missing current payer', expected: '100006', currentMember: 0 }
]) await scenario(test)

check(syntheticReads === 14, 'all site comparisons use actual framework read requests, never a payment endpoint')
console.log(`PASS ${checks} payment site-context checks; actual framework getSiteId/request plus plugin hook/cache expression, 14 synthetic reads, no network/database/storage/order writes.`)
