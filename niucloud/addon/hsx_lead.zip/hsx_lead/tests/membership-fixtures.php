<?php
declare(strict_types=1);

/** Synthetic framework definitions for isolated tests only. No business DB reads. */
function leadMembershipDefinition(int $id,int $rank,int $seats,bool $unlimited=false,array $overrides=[]): array
{
    $config=array_replace(['is_use'=>1,'is_entry'=>$id===701,'level_color'=>'','account_limit'=>$seats,'unlimited'=>$unlimited,
        'can_publish'=>true,'can_accept'=>true,'can_view_inventory'=>true,'all_models'=>false,
        'cycles'=>[['key'=>'month','name'=>'月付','months'=>1,'enabled'=>true,'price'=>number_format(19*$rank,2,'.','')],
            ['key'=>'year','name'=>'年付','months'=>12,'enabled'=>true,'price'=>number_format(199*$rank,2,'.','')],
            ['key'=>'paused','name'=>'暂停周期','months'=>3,'enabled'=>false]]],$overrides);
    return ['level_id'=>$id,'level_name'=>'框架等级'.$rank,'growth'=>$rank*100,'status'=>1,
        'level_benefits'=>json_encode(['hsx_lead_subject'=>$config],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)];
}

function leadMembershipSeed(int $site,array $seats=[1,2,5,10]): array
{
    $ids=[];foreach($seats as $index=>$count) {
        $id=700+$index+1;$row=leadMembershipDefinition($id,$index+1,$count);
        \think\facade\Db::name('member_level')->insert($row+['site_id'=>$site]);$ids[]=$id;
    }return $ids;
}

/** Explicit setup for suites testing seats/pricing/other business, NOT experience.
 * The selected definition becomes the only entry plan before a real quote and
 * verified synthetic payment. Never called implicitly by the grant helper.
 */
function leadSetEntryDefinition(int $site,int $id): void
{
    $rows=\think\facade\Db::name('member_level')->where('site_id',$site)->select()->toArray();$found=false;
    foreach($rows as $row) {
        $benefits=json_decode((string)$row['level_benefits'],true,32,JSON_THROW_ON_ERROR);
        if(!isset($benefits['hsx_lead_subject'])||!is_array($benefits['hsx_lead_subject']))continue;
        $isEntry=(int)$row['level_id']===$id;if($isEntry)$found=true;
        $benefits['hsx_lead_subject']['is_entry']=$isEntry;
        \think\facade\Db::name('member_level')->where('site_id',$site)->where('level_id',$row['level_id'])->update(['level_benefits'=>json_encode($benefits,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)]);
    }
    if(!$found)throw new \RuntimeException('Explicit isolated entry definition does not exist');
}

/** Only synthetic matching framework receipts; no gateway, network or wallet debit. */
function leadMembershipGrant(int $site,int $owner,string $code,string $cycle='month',?int $paidAt=null): array
{
    foreach(['pay','pay_refund'] as $table) {
        $pdo=\think\facade\Db::connect()->getPdo();$exists=$pdo->query("SHOW TABLES LIKE 'lt_".$table."'")->fetchColumn();
        if (!$exists) {
            $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
            if (!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match)) throw new \RuntimeException('Missing receipt fixture DDL');
            $pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));
        }
    }
    $ctx=new \addon\hsx_lead\app\service\Context($site,0,$owner);
    $quote=(new \addon\hsx_lead\app\service\cooperation\EntityMembershipService($ctx))->quote($code,$cycle);
    $row=(new \addon\hsx_lead\app\service\cooperation\PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>$code,'cycle'=>$cycle,'request_id'=>'fixture-membership-'.bin2hex(random_bytes(8)),'quote_token'=>$quote['quote_token']]);
    $no='FIXTURE_'.bin2hex(random_bytes(10));
    \think\facade\Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>\addon\hsx_lead\app\service\cooperation\PaymentService::TRADE_TYPE,'trade_id'=>$row['id'],'out_trade_no'=>$no,'main_type'=>\app\dict\pay\PayDict::MEMBER,'main_id'=>$owner,'from_main_id'=>$owner,'money'=>$row['amount'],'status'=>\app\dict\pay\PayDict::STATUS_FINISH,'pay_time'=>$paidAt??time()]);
    \addon\hsx_lead\app\service\cooperation\PaymentService::confirm(['site_id'=>$site,'trade_type'=>\addon\hsx_lead\app\service\cooperation\PaymentService::TRADE_TYPE,'trade_id'=>$row['id'],'out_trade_no'=>$no]);
    return $row;
}
