import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadAdminUtility } from './admin-utils.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),ts=require('typescript'),compiler=require('@vue/compiler-sfc')
const read=name=>fs.readFileSync(path.join(plugin,name),'utf8')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
function execute(source,deps={}){
    const module={exports:{}}
    const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Date,Math,Number,String,Array,Set,Map,JSON,Promise,console,defineExpose(){},defineProps:()=>({}),withDefaults:(_value,defaults)=>Object.fromEntries(Object.entries(defaults).map(([key,value])=>[key,typeof value==='function'?value():value]))})(key=>{
        if(key in deps)return deps[key]
        if(key.endsWith('.vue'))return {default:{}}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    return module.exports
}
function setup(file,names){
    const parsed=compiler.parse(read(file),{filename:file})
    check(parsed.errors.length===0,file+' parses')
    compiler.compileScript(parsed.descriptor,{id:'merchant-relations-test'})
    check(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'merchant-relations-test',compilerOptions:{expressionPlugins:['typescript']}}).errors.length===0,file+' template compiles')
    for(const style of parsed.descriptor.styles)check(compiler.compileStyle({source:style.content,filename:file,id:'merchant-relations-test',scoped:style.scoped}).errors.length===0,file+' styles compile')
    return parsed.descriptor.scriptSetup.content+`\nexport {${names}}`
}
const commonVue={...Vue,onMounted(){},onBeforeUnmount(){}}
const apiCalls=[]
const transport={get:async(url,data)=>{apiCalls.push({url,data});return {data:{}}}}
const merchantApi=execute(read('admin/api/index.ts'),{'@/utils/request':{default:transport}})
await merchantApi.getMerchantBusinessDefinitions()
check(apiCalls[0].url==='hsx_lead/merchants'&&apiCalls[0].data.params.definitions===1,'new-merchant options use the scoped definitions-only read, not a full merchant page')
const promotionApi=execute(read('admin/api/promotion.ts'),{'@/utils/request':{default:transport}})
await promotionApi.getPromotionRelations({page:2,inviter_member_id:101,payment_state:'paid'})
check(apiCalls[1].url==='hsx_lead/promotion/relations'&&apiCalls[1].data.params.inviter_member_id===101,'relation query sends the explicit scoped endpoint and server-side filters')
const definition={key:'purchase',name:'二手机',enabled:true,dimension:'model',options:[{id:'m1',name:'型号一'}]}
let definitionsWork=async()=>({data:{business_definitions:[definition]}}),detailWork=async id=>({data:{id,name:'门店'+id,status:1,member_id:101,business_definitions:[definition],business_capabilities:[{business_type:'purchase',option_ids:['m1'],items:[{id:'m1',name:'型号一'}]}]}})
let definitionReads=0,detailReads=0
const merchant=execute(setup('admin/views/components/MerchantPanel.vue','open,form,businessDefinitions,detailId,detailLoading,detailError'),{
    vue:commonVue,'element-plus':{ElMessage:{},ElMessageBox:{}},'@element-plus/icons-vue':{Plus:{}},'@/stores/modules/user':{default:()=>({rules:[]})},'../../composables/navigation':{hasLeadPagePermission:()=>false},'../../api/cooperation':{getMerchantProfileFormRecord:async()=>({data:{fields:[]}})},
    '../../composables/useRemoteOptions':loadAdminUtility('useRemoteOptions'),'../../composables/filtering':{hasListFilters:()=>false},'../../composables/serviceScope':{serviceScopeFor:()=> 'default'},
    '../../composables/useLeadUi':{errorText:cause=>cause.message,readyLabels:{},region(){},syncLabel(){},useLeadList:()=>({rows:Vue.ref([]),total:Vue.ref(0),loading:Vue.ref(false),error:Vue.ref(''),query:Vue.reactive({}),load:async()=>{},search:async()=>{}})},
    '../../composables/authRenewal':{authRenewalLabel:()=>''},'../../composables/cooperation':{coopBusiness:value=>value},
    '../../api':{getMerchants(){throw Error('Opening a drawer must not fetch a full list')},getMerchantBusinessDefinitions:()=>{definitionReads++;return definitionsWork()},getMerchant:id=>{detailReads++;return detailWork(id)}}
})
await merchant.open()
check(definitionReads===1&&detailReads===0&&merchant.businessDefinitions.value.length===1,'new drawer loads only the business definitions when opened')
await merchant.open(7)
check(detailReads===1&&merchant.form.id===7&&merchant.form.business_capabilities[0].items.length===1,'edit keeps complete capability fields from the detail endpoint')
definitionsWork=async()=>{throw Error('目录暂时不可用')}
await merchant.open()
check(merchant.detailError.value==='目录暂时不可用'&&!merchant.detailLoading.value&&merchant.businessDefinitions.value.length===0,'failed directory loading is explicit and never leaves stale options or a saveable empty form')
definitionsWork=async()=>({data:{business_definitions:[definition]}})
await merchant.open(merchant.detailId.value)
check(!merchant.detailError.value&&merchant.businessDefinitions.value.length===1,'new drawer can retry its original target after a directory error')
let releaseOld
detailWork=id=>id===8?new Promise(resolve=>{releaseOld=resolve}):Promise.resolve({data:{id,status:1,business_definitions:[definition],business_capabilities:[]}})
const old=merchant.open(8);await merchant.open(9);releaseOld({data:{id:8,status:1,business_definitions:[],business_capabilities:[]}});await old
check(merchant.form.id===9&&merchant.businessDefinitions.value.length===1,'late merchant response cannot overwrite a newer drawer')
check(!read('admin/views/components/MerchantPanel.vue').includes('listedBusinessDefinitions'),'merchant list no longer stores full definitions from every page')
check(read('admin/views/components/MerchantPanel.vue').includes('capability.option_count'),'table renders the server capability count rather than requiring full items')
const response=()=>({data:{data:[],total:0,summary:{relation_count:0,paid_count:0,service_net:'0.00',promotion_total:'0.00'},filters:{payment_states:[{value:'paid',label:'已付费'}],membership_states:[{value:'active',label:'生效中'}]}}})
let relationWork=async()=>response(),relationCalls=[]
const relations=execute(setup('admin/views/promotion/PromotionRelations.vue','load,search,reset,showInviter,clearInviter,query,rows,total,loading,error,summary,filters,selectedInviter,metric,amount'),{
    vue:commonVue,'@element-plus/icons-vue':{Search:{},Right:{}},'../../api/promotion':{getPromotionRelations:params=>{relationCalls.push(JSON.parse(JSON.stringify(params)));return relationWork(params)}},
    '../../composables/cooperation':{coopError:cause=>cause.message,coopMoney:value=>value==null?'—':`¥${value}`},'../../composables/useLeadUi':{timestampParts:value=>value?{full:String(value)}:null}
})
check(relations.metric('paid_count')==='—'&&relations.amount('service_net')==='—','not-yet-loaded summaries never present fake zero values')
await relations.load()
check(relations.summary.value.relation_count===0&&relations.filters.payment_states.length===1,'successful empty response preserves real zero and server-provided filter vocabulary')
relationWork=async()=>({data:{...response().data,summary:{...response().data.summary,service_net:null}}});await relations.load()
check(relations.amount('service_net')==='待核对','unknown service-fee summary is shown as pending verification, never fake zero')
relationWork=async()=>response()
relations.query.page=4;relations.query.keyword='被邀请人';relations.query.inviter_keyword='旧邀请人'
await relations.showInviter({member_id:101,name:'邀请人甲'})
check(relationCalls.at(-1).inviter_member_id===101&&relationCalls.at(-1).page===1&&relationCalls.at(-1).keyword===''&&relationCalls.at(-1).inviter_keyword==='','clicking an inviter searches their direct invitees with no conflicting person search')
check(relations.selectedInviter.value==='邀请人甲','selected inviter scope has an understandable label')
await relations.clearInviter()
check(relationCalls.at(-1).inviter_member_id==='','the single-inviter scope can be removed without sending an invalid zero member ID')
let releaseFirst
relationWork=()=>new Promise(resolve=>{releaseFirst=resolve})
const first=relations.load();relationWork=async()=>({data:{...response().data,data:[{member:{member_id:202}}],total:1}});await relations.load();releaseFirst(response());await first
check(relations.rows.value[0].member.member_id===202&&relations.total.value===1,'out-of-order relationship reads do not overwrite the latest result')
relationWork=async()=>{throw Error('请核对关系查询权限')};await relations.load()
check(relations.error.value==='请核对关系查询权限'&&relations.summary.value===null&&relations.rows.value.length===0,'failed reads are distinct from an empty list and clear stale money summary')
relationWork=async()=>({data:{data:[],total:0,summary:{}}});await relations.load()
check(relations.error.value.includes('未完整返回'),'an incomplete backend response cannot silently become a valid empty result')
relations.query.keyword='abc';relations.query.payment_state='review';relations.query.inviter_member_id=101;relationWork=async()=>response();await relations.reset()
check(relationCalls.at(-1).keyword===''&&relationCalls.at(-1).payment_state===''&&relationCalls.at(-1).inviter_member_id==='','reset clears all search and relation scope predicates')
const parent=setup('admin/views/promotion/index.vue','')
check(parent.includes("allows('hsx_lead_promotion_relations')"),'relation access uses the dedicated permission')
check(read('admin/views/promotion/index.vue').includes("tab==='relations' && canRelations"),'unauthorized users never mount or auto-read the relation panel')
const view=read('admin/views/promotion/PromotionRelations.vue')
check(view.includes('共享所属门店权益')&&view.includes('本人实际付费')&&view.includes('不含押金、经验费'),'shared membership and actual fee facts are labelled separately')
check(view.includes('row.payment?.paid_net')&&view.includes('row.payment?.service_net')&&view.includes('row.payment?.refunded_total'),'cash net payment, commissionable service fee and completed refunds remain distinct')
check(view.includes('row.promotion?.cancelled')&&view.includes('已取消金额不计入有效佣金'),'cancelled rewards remain visible but separate from effective commission')
check(!view.includes('reduce(')&&!view.includes('Math.round('),'client does not recalculate service fees or commission totals')
for(const file of ['admin/api/index.ts','admin/api/promotion.ts','admin/views/components/MerchantPanel.vue','admin/views/promotion/index.vue','admin/views/promotion/PromotionRelations.vue'])check(read(file)===fs.readFileSync(path.resolve(plugin,'../../../admin/src/addon/hsx_lead',file.slice(6)),'utf8'),file+' installation mirror matches')
console.log(`PASS ${checks} merchant-list and promotion-relations UI checks`)
