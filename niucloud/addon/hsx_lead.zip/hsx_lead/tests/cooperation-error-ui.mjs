import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.join(plugin,'../../../uni-app/package.json')),ts=require('typescript')
const source=fs.readFileSync(path.join(plugin,'uni-app/api/cooperation.ts'),'utf8'),module={exports:{}}
const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{String,Number,Date,Math})(key=>{assert.equal(key,'@/utils/request');return{}},module,module.exports)
const {coopError}=module.exports
let checks=0
function check(cause,fallback,expected){assert.equal(coopError(cause,fallback),expected);checks++}
for(const message of ['request:fail','request:fail timeout','Failed to fetch','NetworkError when attempting to fetch resource.','Network request failed','Load failed'])check({errMsg:message},'交付读取失败，请检查网络后重试','交付读取失败，请检查网络后重试')
check({errMsg:'uploadFile:fail'},'上传失败，原照片已保留','上传失败，原照片已保留')
check({message:'request:fail'},'支付结果待核对，请勿重复付款','支付结果待核对，请勿重复付款')
check({msg:'原支付结果待核对',message:'Failed to fetch'},'读取失败','原支付结果待核对')
check(new Error('门店已停止合作'),'读取失败','门店已停止合作')
check(null,'读取失败','读取失败')
console.log(`PASS ${checks} cooperation error presentation checks; actual plugin API helper, no transport or site calls.`)
