import assert from 'node:assert/strict'
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Actual isolated uni-app H5 and uview components, with every business request
// intercepted. This fixture cannot contact a real account or payment provider.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), workspace = path.resolve(plugin, '../../..')
const artifact = process.env.HSX_PAYMENT_HELP_H5_DIR || '/private/tmp/hsx-lead-help-h5-20261109', output = path.join(workspace, 'output/hsx-lead-payment-help-20261109')
const { chromium } = createRequire('/tmp/package.json')('playwright')
fs.mkdirSync(output, { recursive: true })
const mime = { '.html': 'text/html;charset=utf-8', '.js': 'application/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.ttf': 'font/ttf', '.woff2': 'font/woff2' }
const server = http.createServer((request, response) => {
    const url = new URL(request.url, 'http://localhost'), filename = path.resolve(artifact, decodeURIComponent(url.pathname).replace(/^\/wap\//, '')), target = filename.startsWith(artifact + path.sep) && fs.existsSync(filename) && fs.statSync(filename).isFile() ? filename : path.join(artifact, 'index.html')
    response.setHeader('Content-Type', mime[path.extname(target)] || 'application/octet-stream'); response.end(fs.readFileSync(target))
})
const clone = data => JSON.parse(JSON.stringify(data)), now = () => Math.floor(Date.now() / 1000)
const member = { member_id: 101, member_no: 'NIU0000101', nickname: '本地合成测试', mobile: '13900000000', headimg: '', balance: '0.00' }
const init = { tabbar_list: {}, map_config: { is_open: 0, valid_time: 0, map_type: 'tencent', key: '' }, theme_list: [], site_info: { site_id: 100005, site_name: '本地验收', app: ['hsx_lead'], site_addons: [{ key: 'hsx_lead' }], site_logo: '' }, copyright: {}, member_level: [], login_config: { is_username: 1, is_mobile: 0, is_auth_register: 0, is_force_access_user_info: 0, is_bind_mobile: 0, agreement_show: 0, bg_url: '', logo: '', desc: '' }, member_exist: 1 }
const costs = { cost_schema: 'entity-membership-costs-v1', deposit_required: '100.00', deposit_balance: '0.00', deposit_amount: '100.00', service_full_amount: '99.00', service_credit_amount: '0.00', service_amount: '99.00', experience_purchase_enabled: false, experience_unit_price: '0.00', experience_quantity: '0.00', experience_amount: '0.00', buy_experience: false, payable_amount: '199.00', promotion_base_amount: '99.00' }
const tier = { code: 'ML701', name: '青铜会员', rank: 1, display_rank: 1, enabled: true, account_limit: 2, is_entry: true, unlimited: false, cycles: [{ key: 'year', name: '年付', months: 12, enabled: true, price: '99.00' }], benefits: [{ key: 'can_publish', title: '发布客户需求', desc: '门店共同使用', icon: 'order', enabled: true }] }
const membership = { merchant_id: 7, level_code: '', level_name: '普通会员', active: false, can_manage: true, is_owner: true, account_limit: 1, used_accounts: 1, deposit_balance: '0.00', tiers: [tier], experience: { value: '0.00', earned_value: '0.00', purchased_value: '0.00', completed_orders: 0 } }
const order = { id: 81, merchant_id: 7, purpose: 'membership', level_code: tier.code, level_name: tier.name, cycle: 'year', entitlement_months: 12, title: '青铜会员 · 年付', order_no: 'TEST2026110900000081', status: 'unpaid', amount: '199.00', can_pay: true, can_close: true, create_time: now() - 30, expires_at: now() + 600, ...costs }
const profile = { id: 7, site_id: 100005, member_id: 101, name: '合成门店', mobile: '13900000000', can_publish: true, can_accept: true, permissions: {}, membership: { active: true, level_name: '青铜会员' } }
const lead = { id: 51, status: 'unpaid', lead_no: 'TEST-LC-51', assignment_version: 1, publisher_id: 8, receiver_id: 7, customer_name: '合成客户', mobile: '13900000001', commission_minimum: '100.00', fee_percent: '10.00', fee_minimum: '9.90', fee_confirmed: true, business_type: 'purchase', business_name: '二手机', demands: [{ id: 'test-phone', title: '合成意向型号' }], attachments: [], history: [] }
const help = { enabled: true, title: '付款遇到问题？联系本站客服', content: '如付款遇到问题，可联系本站客服协助核对。\n这是管理员自行编辑的合成验收内容，不代表已付款。', qr_image: 'attachment/payment-help-test.png', remark: '合成验收备注：门店名 + 本人手机号' }
const qr = '<svg xmlns="http://www.w3.org/2000/svg" width="240" height="240" viewBox="0 0 240 240"><rect width="240" height="240" fill="white"/><path fill="#273449" d="M20 20h60v60H20zm140 0h60v60h-60zM20 160h60v60H20zm80-60h20v20h-20zm40 0h20v40h-20zm40 0h40v20h-40zm-80 40h20v40h-20zm40 20h40v20h-40zm60-20h20v40h-20zm-80 60h60v20h-60z"/><path fill="white" d="M30 30h40v40H30zm140 0h40v40h-40zM30 170h40v40H30z"/><path fill="#273449" d="M40 40h20v20H40zm140 0h20v20h-20zM40 180h20v20H40z"/><rect x="0" y="100" width="240" height="40" fill="white"/><text x="120" y="125" text-anchor="middle" font-size="18" fill="#53657c">离线验收图片</text></svg>'
let mode = 'enabled', browser, page
const errors = [], blocked = [], deniedStaticRequests = [], writes = [], diagnostics = [], telemetry = [], requests = [], checks = [], geometry = []
try {
    assert.ok(fs.existsSync(path.join(artifact, 'index.html')), 'Run isolated H5 compile first')
    await new Promise(resolve => server.listen(0, '127.0.0.1', resolve)); const origin = 'http://127.0.0.1:' + server.address().port
    browser = await chromium.launch({ headless: true, executablePath: process.env.HSX_TEST_CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome', args: ['--disable-background-networking', '--disable-component-update', '--no-first-run'] })
    const context = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1, reducedMotion: 'reduce', isMobile: true, hasTouch: true })
    await context.addInitScript(() => { localStorage.setItem('wapToken', 'synthetic-payment-help-only'); for (const [key, data] of Object.entries({ wap_member_id: 101, wap_site_id: 100005, wap_member_info: { member_id: 101, member_no: 'NIU0000101', mobile: '13900000000' } })) localStorage.setItem(key, JSON.stringify({ type: typeof data, data })) })
    await context.route('**/*', async route => {
        const request = route.request(), url = new URL(request.url()), p = url.pathname.replace(/^\/api\//, '/'), method = request.method()
        if (url.pathname.endsWith('/attachment/payment-help-test.png')) return route.fulfill({ status: mode === 'image-error' ? 404 : 200, contentType: 'image/svg+xml', headers: { 'Cache-Control': 'no-store' }, body: mode === 'image-error' ? '' : qr })
        if (url.origin === origin && !url.pathname.startsWith('/api/')) return route.continue()
        if (url.hostname === 'at.alicdn.com' && url.pathname.endsWith('.ttf') || url.hostname === 'cdn.dcloud.net.cn' && url.pathname === '/img/shadow-grey.png') { deniedStaticRequests.push(url.origin + url.pathname); return route.abort('blockedbyclient') }
        if (url.hostname === 'sass.hsxbk.top' || url.origin === origin && url.pathname.startsWith('/api/')) {
            requests.push({ path: p, method }); let data = {}, code = 1, msg = '本地合成响应'
            if (method === 'OPTIONS') return route.fulfill({ status: 204, headers: { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' } })
            if (p === '/member/log') telemetry.push({ path: p, method })
            else if (p === '/hsx_lead/cooperation/orders/81/resume' && method === 'POST') { diagnostics.push({ path: p, method }); data = clone(order) }
            else if (method !== 'GET') { writes.push({ path: p, method }); code = 0; msg = '离线验收禁止支付和真实写入' }
            else if (p === '/init') data = init
            else if (p === '/member/member') data = member
            else if (p === '/site') data = init.site_info
            else if (p === '/hsx_lead/cooperation/payment-help') { if (mode === 'read-error') { code = 0; msg = '合成支付帮助读取失败' } else data = mode === 'disabled' ? { enabled: false, title: '', content: '', qr_image: '', remark: '' } : help }
            else if (p === '/hsx_lead/cooperation/orders') data = { data: [clone(order)], total: 1, current_page: 1, per_page: 20 }
            else if (p === '/hsx_lead/cooperation/orders/81') data = clone(order)
            else if (p === '/hsx_lead/cooperation/entity/membership') data = membership
            else if (p === '/hsx_lead/cooperation/entity/quote') data = { ...costs, purpose: 'membership', merchant_id: 7, level_code: tier.code, level_name: tier.name, cycle: 'year', can_purchase: true, period_start_at: now(), period_end_at: now() + 31536000, quote_token: 'synthetic-local-only', expires_at: now() + 600 }
            else if (p === '/hsx_lead/cooperation/bootstrap') data = { current_member_id: 101, profile, config: { enabled: true, publishing_required: false, erp_visible: false, fee_confirmed: true, commission_minimum: '100.00', fee_percent: '10.00', fee_minimum: '9.90', businesses: [] }, providers: [], stats: {}, wallet: {} }
            else if (p === '/hsx_lead/cooperation/leads/51') data = lead
            return route.fulfill({ status: 200, contentType: 'application/json', headers: { 'Access-Control-Allow-Origin': origin, 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': '*' }, body: JSON.stringify({ code, msg, data }) })
        }
        blocked.push(url.origin + url.pathname); return route.abort('blockedbyclient')
    })
    page = await context.newPage(); page.setDefaultTimeout(15000); page.on('pageerror', error => errors.push(error.message))
    const membershipUrl = origin + '/wap/addon/hsx_lead/pages/membership/index?payment_order_id=81', ordersUrl = origin + '/wap/addon/hsx_lead/pages/orders/index', popup = () => page.locator('.coop-payment-help__sheet:visible'), entry = () => page.locator('.coop-payment-help__entry'), close = () => popup().locator('.coop-payment-help__head uni-button')
    await page.goto(membershipUrl, { waitUntil: 'networkidle', timeout: 60000 }); await entry().waitFor(); await page.getByText('原付款单', { exact: true }).waitFor()
    assert.equal(await popup().count(), 0); assert.equal(writes.length, 0); checks.push('真实会员页显示单一显著帮助入口；不自动弹起，不生成或确认付款')
    for (const width of [350, 390]) {
        await page.setViewportSize({ width, height: 844 }); await page.evaluate(() => new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve))))
        assert.equal(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth + 1), true)
        await page.screenshot({ path: path.join(output, 'membership-help-entry-' + width + '.png'), fullPage: false })
        await entry().click(); await popup().waitFor(); await page.waitForTimeout(450)
        const size = await popup().evaluate(node => { const body = node.querySelector('.coop-payment-help__body'), head = node.querySelector('.coop-payment-help__head'); return { width: innerWidth, documentWidth: document.documentElement.scrollWidth, left: node.getBoundingClientRect().left, right: node.getBoundingClientRect().right, top: node.getBoundingClientRect().top, bottom: node.getBoundingClientRect().bottom, bodyClientWidth: body.clientWidth, bodyScrollWidth: body.scrollWidth, headHeight: head.getBoundingClientRect().height, height: innerHeight } })
        geometry.push(size); assert.ok(size.documentWidth <= width + 1 && size.right <= width + 1 && size.left >= -1 && size.bottom <= 845 && size.bodyScrollWidth <= size.bodyClientWidth + 1 && size.headHeight >= 44)
        await popup().getByText('TEST2026110900000081', { exact: true }).waitFor(); await page.screenshot({ path: path.join(output, 'payment-help-popup-' + width + '.png'), fullPage: false })
        await close().click(); await popup().waitFor({ state: 'hidden' }); assert.equal(writes.length, 0)
    }
    checks.push('350/390真实u-popup：长内容换行、单一滚动区、二维码和备注、原单号可见，顶部关闭可达，无横向溢出或支付写入')
    await page.goto(ordersUrl, { waitUntil: 'networkidle' }); await entry().waitFor(); await page.getByText(order.order_no, { exact: true }).waitFor()
    assert.equal(await page.locator('.coop-payment-help__entry').count(), 1); assert.equal(requests.filter(row => row.path.endsWith('/payment-help')).length, 2); checks.push('付款单列表一页只读一次帮助，不对每条付款单重复请求')
    const normalHelp = clone(help); Object.assign(help, { title: '合成验收：付款需要协助时请联系本站客服核对订单资料', content: '这是离线长内容验收，后台填写的提醒应正常换行且保留段落，不覆盖关闭按钮。\n'.repeat(20).slice(0, 600), remark: '合成测试备注，请提供门店名称和本人联系信息。'.repeat(8).slice(0, 120) }); await page.reload({ waitUntil: 'networkidle' }); const previewHeight = await entry().locator('.coop-payment-help__preview').evaluate(node => node.clientHeight); assert.ok(previewHeight <= 39); await entry().click(); await popup().waitFor(); await page.waitForTimeout(400)
    const beforeScroll = await popup().locator('.coop-payment-help__head').boundingBox(), scrollSize = await popup().locator('.coop-payment-help__body').evaluate(node => { const nodes = [node, ...node.querySelectorAll('*')], scroller = nodes.find(item => item.scrollHeight > item.clientHeight + 50 && /^(auto|scroll)$/.test(getComputedStyle(item).overflowY)) || node; scroller.scrollTop = scroller.scrollHeight; return { client: scroller.clientHeight, scroll: scroller.scrollHeight, scrollTop: scroller.scrollTop, tag: scroller.tagName, className: scroller.className, candidates: nodes.slice(0, 5).map(item => ({ tag: item.tagName, name: item.className, client: item.clientHeight, scroll: item.scrollHeight, top: item.scrollTop, overflow: getComputedStyle(item).overflowY })) } }); await page.waitForTimeout(500); geometry.push({ longScroll: scrollSize })
    assert.ok(scrollSize.scroll > scrollSize.client + 100 && scrollSize.scrollTop > 100, JSON.stringify(scrollSize)); const afterScroll = await popup().locator('.coop-payment-help__head').boundingBox(), finalDetail = await popup().locator('.coop-payment-help__detail').last().boundingBox(), popupBox = await popup().boundingBox(); geometry.push({ longViewport: { beforeScroll, afterScroll, finalDetail, popupBox, windowScroll: await page.evaluate(() => ({ x: scrollX, y: scrollY, height: innerHeight })) } }); assert.ok(Math.abs(beforeScroll.y - afterScroll.y) < 1); assert.ok(afterScroll.y >= 0 && afterScroll.y + afterScroll.height <= 844, JSON.stringify(geometry.at(-1))); assert.ok(finalDetail.y >= afterScroll.y + afterScroll.height - 1 && finalDetail.y + finalDetail.height <= popupBox.y + popupBox.height + 1); await page.screenshot({ path: path.join(output, 'payment-help-long-scrolled-390.png'), fullPage: false }); await close().click(); Object.assign(help, normalHelp); checks.push('入口长文只显示两行；600字提醒与120字备注实际scrollTop>100并滚到末尾，关闭头部固定且末尾备注在屏内')
    mode = 'disabled'; await page.reload({ waitUntil: 'networkidle' }); await page.getByText(order.order_no, { exact: true }).waitFor(); assert.equal(await page.locator('.coop-payment-help').count(), 0); assert.equal(await page.getByText('继续支付', { exact: true }).isVisible(), true); checks.push('后台关闭后无空白帮助区，原付款入口继续可见且未被改写')
    mode = 'read-error'; await page.reload({ waitUntil: 'networkidle' }); await page.getByText('支付帮助暂不可用', { exact: true }).waitFor(); assert.equal(await page.getByText('继续支付', { exact: true }).isVisible(), true); await page.screenshot({ path: path.join(output, 'payment-help-read-error-390.png'), fullPage: false }); mode = 'enabled'; await page.getByText('重新加载', { exact: true }).click(); await entry().waitFor(); checks.push('帮助读取失败只影响帮助，原付款按钮保留；重新加载仅GET')
    mode = 'image-error'; await entry().click(); await popup().getByText('二维码暂未加载', { exact: true }).waitFor(); mode = 'enabled'; await popup().getByText('重新加载图片', { exact: true }).click(); await popup().getByText('点按查看大图', { exact: true }).waitFor(); await close().click(); checks.push('图片单独失败有明确恢复动作，不让空白二维码冒充已配置客服')
    await page.goto(origin + '/wap/addon/hsx_lead/pages/task/index?task=commission&collaboration_id=51', { waitUntil: 'networkidle' }); await page.getByText('确认协作佣金', { exact: true }).waitFor(); await entry().waitFor(); assert.equal(await page.locator('.coop-payment-help__entry').count(), 1); await page.screenshot({ path: path.join(output, 'commission-help-entry-390.png'), fullPage: false }); checks.push('协作付佣表单复用相同帮助组件，原金额与确认按钮不变')
    assert.deepEqual(writes, []); assert.deepEqual(errors, []); assert.deepEqual(blocked, [])
    fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify({ passed: true, checks, geometry, errors, blocked, deniedStaticRequests, writes, diagnostics, telemetry, requests, scope: 'Actual isolated uni-app H5/uview output with synthetic API and non-scannable QR image. Framework telemetry and original-order resume are intercepted separately. External icon fonts/static requests are denied; no successful external business request, financial mutation or real payments, messages or production writes. Native WeChat device acceptance remains separate.' }, null, 2))
    console.log(JSON.stringify({ passed: true, checks, output, errors, blocked, writes }))
} catch (error) { const failed = { passed: false, error: String(error), body: page ? await page.locator('body').innerText() : '', errors, blocked, writes, requests, geometry }; fs.writeFileSync(path.join(output, 'report.json'), JSON.stringify(failed, null, 2)); console.error(JSON.stringify(failed)); throw error }
finally { await browser?.close(); await new Promise(resolve => server.close(resolve)) }
