<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{PartnerService,ProfileFormService};
use addon\hsx_lead\app\support\Data;
use app\dict\diy_form\{TemplateDict,TypeDict};
use app\service\admin\diy_form\DiyFormService;
use core\exception\CommonException;
use think\facade\Db;

$pdo=null;$schema='';$failed=false;$checks=0;
function formHookCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function formHookDeny(callable$call,string$label):void{try{$call();}catch(CommonException$error){formHookCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    // Match the framework's actual add-on entitlement source. Do not teach its
    // dictionary loader a plugin-specific fallback or bypass site permission.
    Db::name('site')->where('site_id',$site)->update(['addons'=>'["hsx_lead"]']);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['diy_form','diy_form_fields','diy_form_records','diy_form_records_fields','diy_form_submit_config','diy_form_write_config']as$table){
        preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$matches);
        if(!$matches)throw new RuntimeException('Missing official form table: '.$table);
        $pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$matches[0]));
    }
    $beforeTables=Db::query('SHOW TABLES');
    $types=TypeDict::getType();$type=ProfileFormService::FORM_TYPE;
    formHookCheck(isset($types[$type])&&$types[$type]['title']==='门店补充资料','real framework type dictionary exposes the add-on form in the creation dialog');
    formHookCheck($types[$type]['addon']==='hsx_lead'&&isset($types['DIY_FORM'],$types['DIY_FORM_MEMBER_INFO']),'native types remain intact and new type records the plugin owner');
    formHookCheck(is_file(dirname(__DIR__,3).'/public/'.$types[$type]['preview']),'new type uses a shipped framework preview, not an absent plugin asset');
    $native=new DiyFormService();$init=$native->getInit(['type'=>$type,'title'=>'']);
    formHookCheck($init['type']===$type&&$init['type_name']==='门店补充资料'&&isset($init['component']['DIY_FORM_COMPONENT']),'actual editor init recognizes the new type and framework component catalogue');
    $templates=TemplateDict::getTemplate(['type'=>$type]);
    formHookCheck(isset($templates['hsx_lead_merchant_profile']),'actual template dictionary offers an editable starting template for this type');
    $data=$templates['hsx_lead_merchant_profile']['data'];
    formHookCheck($data['global']['title']==='门店补充资料'&&count($data['value'])===1,'default template is a small supplement, not a duplicate onboarding form');
    $component=$data['value'][0];$field=$component['id'];
    formHookCheck($component['componentName']==='FormTextarea'&&$component['componentType']==='diy_form'&&$component['field']['name']==='门店补充说明','default field reuses the actual framework textarea component and schema');
    formHookCheck(!$component['field']['required']&&!$component['field']['unique']&&!$component['field']['autofill'],'example field does not force an irrelevant answer, unique identity or cached prior-user data');
    $formId=(int)$native->add(['page_title'=>'门店补充资料','title'=>'门店补充资料','type'=>$type,'value'=>Data::json($data),'template'=>'hsx_lead_merchant_profile']);
    $created=Db::name('diy_form')->where('form_id',$formId)->find();
    formHookCheck($formId>0&&(int)$created['site_id']===$site&&$created['type']===$type&&$created['addon']==='hsx_lead'&&(int)$created['status']===1,'real framework creation persists this tenant, type, addon and enabled state');
    formHookCheck(Db::name('diy_form_fields')->where('site_id',$site)->where('form_id',$formId)->where('field_key',$field)->where('field_type','FormTextarea')->count()===1,'framework creation records the actual field identity');
    formHookCheck(Db::name('diy_form_submit_config')->where('form_id',$formId)->count()===1&&Db::name('diy_form_write_config')->where('form_id',$formId)->count()===1,'framework creation initializes the normal form config tables');
    formHookCheck($native->getInit(['form_id'=>$formId])['type_name']==='门店补充资料','editor can reopen its saved specialized form, not only initialize a blank type');
    $admin=new ProfileFormService(new Context($site,1));$member=new Context($site,0,101);$forms=$admin->admin();
    formHookCheck(count($forms['forms'])===1&&(int)$forms['forms'][0]['form_id']===$formId,'plugin binding list includes the real specialized form');
    $bind=static function(int$id)use($admin):array{$state=$admin->admin();return$admin->save(['fields'=>$state['fields'],'extra_form'=>['enabled'=>true,'form_id'=>$id],'expected_version'=>$state['version']]);};
    $bound=$bind($formId);
    formHookCheck($bound['extra_form']['enabled']&&$bound['extra_form']['definition']['type']===$type,'binding read-back retains the specialized form type');
    $owner=new ProfileFormService($member);$memberState=$owner->member();
    formHookCheck($memberState['extra_form']['definition']['type']===$type&&$memberState['extra_form']['definition']['value'][0]['componentName']==='FormTextarea','member endpoint projects the supported definition for the existing mobile form renderer');
    $profile=['name'=>'门店表单钩子测试','contact_name'=>'合成负责人','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'隔离本地地址'];
    $payload=static fn(array$state,string$value):array=>['version'=>$state['version'],'form_id'=>$state['extra_form']['form_id'],'values'=>[$field=>$value]];
    $saved=(new PartnerService($member))->saveProfile($profile+['profile_form'=>$payload($memberState,'支持到店咨询')]);
    $merchant=(int)$saved['id'];
    formHookCheck($merchant>0&&Db::name('diy_form_records')->where('site_id',$site)->where('form_id',$formId)->where('member_id',101)->where('relate_id',$merchant)->count()===1,'onboarding writes the real official form record with the merchant relation');
    formHookCheck(Db::name('diy_form_records_fields')->where('site_id',$site)->where('form_id',$formId)->where('field_key',$field)->value('field_value')==='支持到店咨询','official field record contains the submitted supplemental answer');
    formHookCheck($owner->member()['extra_form']['values'][$field]==='支持到店咨询'&&$admin->adminRecord($merchant)['fields'][0]['display_value']==='支持到店咨询','owner prefill and permissioned admin record read the same verified official record');
    $required=$data;$required['value'][0]['field']['required']=true;
    $native->edit($formId,['value'=>Data::json($required)]);
    $changed=$owner->member();
    formHookDeny(fn()=>(new PartnerService($member))->saveProfile($profile+['profile_form'=>$payload($memberState,'旧定义')]),'native editor updates invalidate a previously loaded plugin version');
    formHookDeny(fn()=>(new PartnerService($member))->saveProfile($profile+['profile_form'=>$payload($changed,'')]),'native field required switch is enforced by the backend');
    (new PartnerService($member))->saveProfile($profile+['profile_form'=>$payload($changed,'已核对说明')]);
    formHookCheck($owner->member()['extra_form']['values'][$field]==='已核对说明'&&Db::name('diy_form_records')->where('form_id',$formId)->count()===2,'profile edit appends the new version and uses the current native definition');
    Db::name('diy_form')->where('form_id',$formId)->update(['status'=>0]);
    formHookDeny(fn()=>$owner->member(),'closed native form is not silently replaced with a default');
    formHookDeny(fn()=>$bind($formId),'closed specialized form cannot be selected');
    Db::name('diy_form')->where('form_id',$formId)->update(['status'=>1]);
    $foreign=(int)Db::name('diy_form')->insertGetId(['site_id'=>$site+1,'title'=>'外站专用表单','type'=>$type,'status'=>1,'value'=>Data::json($data)]);
    formHookDeny(fn()=>$bind($foreign),'specialized type does not bypass tenant ownership');
    formHookCheck(!in_array($foreign,array_map('intval',array_column($admin->admin()['forms'],'form_id')),true),'binding list does not expose the other tenant form');
    $identity=(int)Db::name('diy_form')->insertGetId(['site_id'=>$site,'title'=>'个人资料','type'=>'DIY_FORM_MEMBER_INFO','status'=>1,'value'=>Data::json($data)]);
    formHookDeny(fn()=>$bind($identity),'personal member info form cannot be bound as a merchant supplement');
    formHookCheck(!in_array($identity,array_map('intval',array_column($admin->admin()['forms'],'form_id')),true),'binding list excludes unrelated native business types');
    $legacy=(int)$native->add(['page_title'=>'既有自定义资料','title'=>'既有自定义资料','type'=>'DIY_FORM','value'=>Data::json($data),'template'=>'']);
    $legacyRow=Db::name('diy_form')->where('form_id',$legacy)->find();$legacyBound=$bind($legacy);
    formHookCheck($legacyBound['extra_form']['definition']['type']==='DIY_FORM','previously used general forms remain selectable without migration');
    formHookCheck(Db::name('diy_form')->where('form_id',$legacy)->find()===$legacyRow,'binding never rewrites existing general forms into the new type');
    request()->siteId($site+1);
    $foreignTypes=TypeDict::getType();
    formHookCheck(!isset($foreignTypes[$type])&&isset($foreignTypes['DIY_FORM']),'type registration follows the framework site add-on entitlement instead of leaking to every site');
    formHookCheck(TemplateDict::getTemplate(['type'=>$type])===[],'unauthorized site receives no plugin template');
    request()->siteId($site);
    formHookCheck(isset(TypeDict::getType()[$type]),'switching back to the authorized site restores the type through the native loader');
    formHookCheck(Db::query('SHOW TABLES')===$beforeTables,'plugin hook registration adds no table or schema');
    echo 'PASS '.$checks." profile form hook checks; actual framework dictionaries/editor-init/form create, native records and plugin binding; random localhost schema, no network or existing business data\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL profile form hook after '.$checks.' checks: '.get_class($error).' '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
