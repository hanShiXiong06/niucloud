<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$function)if(function_exists($function))exit("Disable external-network sender functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';

use addon\hsx_lead\app\service\{Context,NoticeConfigService,NoticePreflightException};
use addon\hsx_lead\app\service\cooperation\{CooperationNoticeService,CooperationNoticeReadService,CooperationNoticeOutbox,Store};
use addon\hsx_lead\app\support\Data;
use app\service\core\sys\CoreConfigService;
use core\exception\NoticeDeliveryException;
use think\facade\Db;

$pdo=null;$schema='';$failed=false;$checks=0;
function deliveryCheck(bool $condition,string $label):void{if(!$condition)throw new RuntimeException($label);$GLOBALS['checks']++;}
function deliveryReject(callable $call,string $label):void{try{$call();}catch(Throwable$error){deliveryCheck(true,$label);return;}throw new RuntimeException('Expected rejection: '.$label);}
function deliveryAudit(int $site,int $lead,string $channel='weapp'):array{return Data::query('audit',$site)->where('entity_type','collaboration_notice')->where('entity_id',$lead)->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(detail_json,'$.channel')) = :ch",['ch'=>$channel])->find();}
function deliveryState(int $site,int $id):array{return Data::decode(Data::row('audit',$site,$id)['detail_json']);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$context=new Context($site,1);
    Db::name('site')->where('site_id',$site)->update(['site_domain'=>'https://synthetic-notice.example.test']);
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['nickname'=>'Safe Recipient','member_no'=>'SYNTHETIC_101','weapp_openid'=>'SECRET_OPENID','wx_openid'=>'SECRET_WX']);
    $shop=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'member_id'=>101,'name'=>'Synthetic shop','status'=>1]);Store::partner($site,$shop);
    $newLead=static function()use($site,$shop):int{$key=bin2hex(random_bytes(8));return(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'NOTICE_'.$key,'publisher_id'=>$shop,'receiver_id'=>0,'owner_uid'=>1,'request_id'=>$key,'status'=>'following','assignment_version'=>1,'customer_name'=>'SECRET_CUSTOMER','mobile'=>'18800009999','models_json'=>'[]']);};
    $templates=[];foreach(NoticeConfigService::PHASES as$phase=>$key)$templates[$phase]=['phase'=>$phase,'tid'=>'12345','kid_list'=>[1,2],'scene_desc'=>'Synthetic delivery fixture','fields'=>[['label'=>'编号','variable'=>'task_no','keyword'=>'character_string1'],['label'=>'状态','variable'=>'status_text','keyword'=>'thing2']]];
    (new CoreConfigService())->setConfig($site,NoticeConfigService::CONFIG_KEY,['templates'=>$templates]);NoticeConfigService::syncSite($site);
    $configure=static function(int $enabled=1)use($site):void{foreach(NoticeConfigService::PHASES as$key)Db::name('sys_notice')->where('site_id',$site)->where('key',$key)->update(['is_weapp'=>$enabled,'weapp_template_id'=>'synthetic-template','is_wechat'=>0,'is_sms'=>0]);};$configure();
    $fire=static function(callable $sender)use($site,$newLead):array{$id=$newLead();(new CooperationNoticeService($sender))->changed(['site_id'=>$site,'lead_id'=>$id,'action'=>'accepted']);$row=deliveryAudit($site,$id);return[$id,(int)$row['id'],Data::decode($row['detail_json'])];};
    $receipt=static fn(array$p):array=>['accepted'=>true,'channel'=>$p['channel'],'provider_code'=>'0','provider_id'=>'synthetic-only'];
    [$accepted,$acceptedAudit,$state]=$fire($receipt);deliveryCheck($state['status']==='accepted'&&$state['provider_code']==='0','strict matching provider receipt is accepted, not terminal delivery');
    foreach([true,null,['accepted'=>true,'channel'=>'wechat','provider_code'=>'0'],['accepted'=>true,'channel'=>'weapp','provider_code'=>0]]as$legacy){[,,$state]=$fire(static fn(array$p)=>$legacy);deliveryCheck($state['status']==='submitted','legacy or malformed success without receipt is only submitted');}
    [,,$false]=$fire(static fn(array$p):bool=>false);deliveryCheck($false['status']==='uncertain','false result remains uncertain');
    [$rejected,$rejectedAudit,$state]=$fire(static fn(array$p)=>throw new NoticeDeliveryException('weapp','rejected','43101','SECRET_PROVIDER_BODY'));
    deliveryCheck($state['status']==='rejected'&&$state['provider_code']==='43101'&&str_contains($state['message'],'订阅')&&!str_contains(Data::json($state),'SECRET_PROVIDER_BODY'),'43101 becomes explicit safe subscription failure, never raw provider body');
    [$unknown,$unknownAudit,$state]=$fire(static fn(array$p)=>throw new NoticeDeliveryException('weapp','unknown','','SECRET_TIMEOUT'));
    deliveryCheck($state['status']==='uncertain'&&!str_contains(Data::json($state),'SECRET_TIMEOUT'),'timeout result unknown is safe and not automatically retried');
    [$preflight,$preflightAudit,$state]=$fire(static fn(array$p)=>throw new NoticePreflightException('Synthetic local validation'));
    deliveryCheck($state['status']==='not_submitted','local preflight is known not submitted, not uncertain');
    $nestedCalls=0;$nestedService=new CooperationNoticeService(static function(array$p)use(&$nestedCalls,$receipt):array{$nestedCalls++;return$receipt($p);});
    $nestedBefore=deliveryState($site,$preflightAudit);
    Db::transaction(function()use($nestedService,$context,$site,$preflight,$preflightAudit):void{
        deliveryReject(static fn()=>$nestedService->retry($context,$preflight,$preflightAudit,['confirm'=>true,'reason'=>'Synthetic outer transaction']),'admin retry refuses to submit an external channel inside an uncommitted outer transaction');
        deliveryReject(static fn()=>$nestedService->changed(['site_id'=>$site,'lead_id'=>$preflight,'action'=>'accepted']),'direct channel fanout also refuses to run before an outer commit');
    });
    deliveryCheck($nestedCalls===0&&deliveryState($site,$preflightAudit)===$nestedBefore,'blocked nested retry does not send or consume the retry allowance');
    [$mismatch,,$state]=$fire(static fn(array$p)=>throw new NoticeDeliveryException('wechat','rejected','43101','Synthetic wrong-channel receipt'));
    deliveryCheck($state['status']==='uncertain','mismatching channel exception cannot authorize retry');

    $read=new CooperationNoticeReadService($context,$receipt);
    $page=$read->lists($rejected,['limit'=>1,'channel'=>'weapp','status'=>'rejected','recipient'=>'SYNTHETIC_101']);
    deliveryCheck($page['total']===1&&count($page['data'])===1&&$page['current_page']===1&&$page['per_page']===1&&$page['data'][0]['can_retry']===true,'ledger paginates and filters current recipient and explicit failure');
    deliveryCheck($page['data'][0]['recipient_label']==='Synthetic shop · Safe Recipient'&&$page['data'][0]['provider_code']==='43101','ledger shows original recipient and safe service error code');
    foreach(['SECRET_OPENID','SECRET_WX','SECRET_CUSTOMER','18800009999','SECRET_PROVIDER_BODY']as$secret)deliveryCheck(!str_contains(Data::json($page),$secret),'ledger does not expose '.$secret);
    deliveryCheck($read->lists($rejected,['recipient_member_id'=>102])['total']===0&&$read->lists($rejected,['recipient'=>'101','channel'=>'weapp'])['total']===1,'recipient member id and numeric identity search stay exact');
    deliveryReject(static fn()=>$read->lists($rejected,['channel'=>'wecom']),'unsupported channel rejected');
    deliveryReject(static fn()=>$read->retry($rejected,$rejectedAudit,['reason'=>'test']),'missing explicit confirmation rejected');
    deliveryReject(static fn()=>$read->retry($rejected,$rejectedAudit,['confirm'=>true,'reason'=>'']),'empty retry reason rejected');
    deliveryReject(static fn()=>$read->retry($accepted,$acceptedAudit,['confirm'=>true,'reason'=>'test']),'accepted notification cannot retry');
    deliveryReject(static fn()=>$read->retry($unknown,$unknownAudit,['confirm'=>true,'reason'=>'test']),'unknown notification cannot retry');
    deliveryReject(static fn()=>$read->retry($preflight,$rejectedAudit,['confirm'=>true,'reason'=>'test']),'another lead audit cannot be retried');
    $result=$read->retry($preflight,$preflightAudit,['confirm'=>true,'reason'=>'渠道配置已核对']);
    deliveryCheck($result['status']==='accepted'&&$result['retry_count']===1&&$result['attempts']===2&&!$result['can_retry'],'preflight explicit retry submits original row and records attempt');
    deliveryCheck(Data::query('audit',$site)->where('entity_type','collaboration_notice_retry')->where('entity_id',$preflight)->count()===1,'retry operator and reason are auditable');

    $configure(0);$disabledId=$newLead();$sent=0;(new CooperationNoticeService(static function(array$p)use(&$sent):bool{$sent++;return true;}))->changed(['site_id'=>$site,'lead_id'=>$disabledId,'action'=>'accepted']);$disabledAudit=(int)deliveryAudit($site,$disabledId)['id'];
    deliveryCheck($sent===0&&deliveryState($site,$disabledAudit)['status']==='disabled','disabled configuration never dispatches');$configure();
    $result=$read->retry($disabledId,$disabledAudit,['confirm'=>true,'reason'=>'已明确开启当前小程序模板']);deliveryCheck($result['status']==='accepted','previously disabled claim is retryable only by explicit operator action after config correction');
    Db::name('member')->where('member_id',101)->update(['weapp_openid'=>'']);$missingId=$newLead();(new CooperationNoticeService($receipt))->changed(['site_id'=>$site,'lead_id'=>$missingId,'action'=>'accepted']);$missingAudit=(int)deliveryAudit($site,$missingId)['id'];
    deliveryCheck(deliveryState($site,$missingAudit)['status']==='pending_recipient','missing channel identity is visible');Db::name('member')->where('member_id',101)->update(['weapp_openid'=>'SECRET_OPENID']);
    deliveryCheck($read->retry($missingId,$missingAudit,['confirm'=>true,'reason'=>'用户已登录并订阅'])['status']==='accepted','corrected original identity can explicitly retry without retargeting');

    [$maxLead,$maxAudit]=$fire(static fn(array$p)=>throw new NoticeDeliveryException('weapp','rejected','43101','Synthetic rejection'));$rejectRead=new CooperationNoticeReadService($context,static fn(array$p)=>throw new NoticeDeliveryException('weapp','rejected','43101','Synthetic rejection'));
    for($attempt=1;$attempt<=3;$attempt++){$result=$rejectRead->retry($maxLead,$maxAudit,['confirm'=>true,'reason'=>'Synthetic retry '.$attempt]);deliveryCheck($result['retry_count']===$attempt&&$result['attempts']===$attempt+1,'retry counter is bounded and monotonic');}
    deliveryCheck(!$result['can_retry'],'third retry disables further sends');deliveryReject(static fn()=>$rejectRead->retry($maxLead,$maxAudit,['confirm'=>true,'reason'=>'Fourth attempt']),'fourth manual retry blocked');
    [$stale,$staleAudit]=$fire(static fn(array$p)=>throw new NoticePreflightException('Synthetic preflight'));Store::query('collaboration',$site)->where('id',$stale)->update(['assignment_version'=>2]);
    deliveryCheck(!$read->lists($stale,['channel'=>'weapp'])['data'][0]['can_retry'],'stale original revision is not retryable');deliveryReject(static fn()=>$read->retry($stale,$staleAudit,['confirm'=>true,'reason'=>'test']),'revision is revalidated under lock');
    [$blocked,$blockedAudit]=$fire(static fn(array$p)=>throw new NoticePreflightException('Synthetic preflight'));Db::name('member')->where('member_id',101)->update(['status'=>0]);
    deliveryReject(static fn()=>$read->retry($blocked,$blockedAudit,['confirm'=>true,'reason'=>'test']),'recipient status is revalidated under lock');Db::name('member')->where('member_id',101)->update(['status'=>1]);

    [$racing,$racingAudit]=$fire(static fn(array$p)=>throw new NoticePreflightException('Synthetic preflight'));$reentered=false;
    $racingRead=new CooperationNoticeReadService($context,static function(array$p)use(&$reentered,$context,$racing,$racingAudit,$receipt):array{$reentered=true;deliveryReject(static fn()=>(new CooperationNoticeReadService($context,$receipt))->retry($racing,$racingAudit,['confirm'=>true,'reason'=>'Concurrent retry']),'dispatching claim rejects concurrent duplicate retry');return$receipt($p);});
    $result=$racingRead->retry($racing,$racingAudit,['confirm'=>true,'reason'=>'First retry']);deliveryCheck($reentered&&$result['retry_count']===1,'only one retry owns a dispatching attempt');

    // Real NoticeData preflight recognizes and logs the current retry attempt;
    // an earlier payload cannot consume a newer claim.
    [$attemptLead,$attemptAudit]=$fire(static fn(array$p)=>throw new NoticePreflightException('Synthetic preflight'));
    $attemptRead=new CooperationNoticeReadService($context,static function(array$p)use($site,$receipt):array{$data=$p['data'];deliveryReject(static fn()=>CooperationNoticeService::templateData($site,(int)$data['collaboration_id'],(int)$data['notice_audit_id'],$p['channel'],$p['key'],1),'previous attempt payload cannot resolve current retry');$vars=CooperationNoticeService::templateData($site,(int)$data['collaboration_id'],(int)$data['notice_audit_id'],$p['channel'],$p['key'],(int)$data['notice_attempt']);deliveryCheck($vars['vars']['__hsx_lead_notice_attempt']==='2','current attempt correlated to framework log');return$receipt($p);});
    deliveryCheck($attemptRead->retry($attemptLead,$attemptAudit,['confirm'=>true,'reason'=>'Synthetic attempt check'])['status']==='accepted','retry passes actual original-scene preflight');
    $queue=CooperationNoticeOutbox::record($site,$racing,'accepted');$queuePage=$read->lists($racing,['channel'=>'queue']);deliveryCheck($queuePage['total']===1&&!$queuePage['data'][0]['can_retry'],'queue event is distinguishable and not a direct resend button');
    deliveryReject(static fn()=>(new CooperationNoticeReadService(new Context($site,0,101)))->lists($rejected),'member cannot read operational recipient ledger');
    deliveryReject(static fn()=>(new CooperationNoticeReadService(new Context($site,0,101),$receipt))->retry($rejected,$rejectedAudit,['confirm'=>true,'reason'=>'test']),'member cannot retry administrative notification');
    Db::name('sys_user_role')->insert(['uid'=>1,'site_id'=>$site+1,'status'=>1,'is_admin'=>1]);
    deliveryReject(static fn()=>(new CooperationNoticeReadService(new Context($site+1,1)))->lists($rejected),'another tenant admin cannot read this lead ledger');
    deliveryReject(static fn()=>(new CooperationNoticeReadService(new Context($site+1,1),$receipt))->retry($rejected,$rejectedAudit,['confirm'=>true,'reason'=>'test']),'another tenant cannot retry original claim');
    Db::name('sys_user')->insert(['uid'=>2,'username'=>'notice-reader','status'=>1]);
    Db::name('sys_role')->insert(['role_id'=>2,'site_id'=>$site,'status'=>1,'rules'=>Data::json(['hsx_lead_cooperation_notice_list'])]);
    Db::name('sys_user_role')->insert(['uid'=>2,'site_id'=>$site,'status'=>1,'is_admin'=>0,'role_ids'=>'[2]']);
    foreach(['hsx_lead_cooperation_notice_list','hsx_lead_cooperation_notice_retry','hsx_lead_cooperation_detail']as$key)Db::name('sys_menu')->insert(['menu_key'=>$key,'app_type'=>'site','status'=>1]);
    $scopedRead=new CooperationNoticeReadService(new Context($site,2),$receipt);
    deliveryReject(static fn()=>$scopedRead->lists($rejected),'notice permission does not bypass employee lead ownership');
    Store::query('collaboration',$site)->where('id',$rejected)->update(['owner_uid'=>2]);
    deliveryCheck(!$scopedRead->lists($rejected,['channel'=>'weapp'])['data'][0]['can_retry'],'list-only role sees original recipient but no retry capability');
    deliveryReject(static fn()=>$scopedRead->retry($rejected,$rejectedAudit,['confirm'=>true,'reason'=>'test']),'read-only notice role cannot retry');
    Db::name('sys_role')->where('role_id',2)->update(['rules'=>Data::json(['hsx_lead_cooperation_detail'])]);
    deliveryReject(static fn()=>$scopedRead->lists($rejected),'ordinary lead detail permission does not grant recipient ledger access');
    // Explicitly confirmed SMS retry uses only its original channel. Correcting
    // an SMS account does not replay any disabled historic SMS automatically.
    (new CoreConfigService())->setConfig($site,\app\dict\sys\ConfigKeyDict::SMS,['default'=>'synthetic-offline']);
    foreach(NoticeConfigService::PHASES as$key)Db::name('sys_notice')->where('site_id',$site)->where('key',$key)->update(['is_sms'=>1,'sms_id'=>'synthetic-sms-template']);
    $smsAudit=(int)deliveryAudit($site,$disabledId,'sms')['id'];$smsCalls=[];
    $smsRead=new CooperationNoticeReadService($context,static function(array$p)use(&$smsCalls,$site):bool{$smsCalls[]=$p['channel'];$d=$p['data'];CooperationNoticeService::templateData($site,(int)$d['collaboration_id'],(int)$d['notice_audit_id'],$p['channel'],$p['key'],(int)$d['notice_attempt']);return true;});
    deliveryCheck(deliveryState($site,$smsAudit)['status']==='disabled'&&$smsCalls===[],'fixing SMS configuration does not automatically send history');
    $smsResult=$smsRead->retry($disabledId,$smsAudit,['confirm'=>true,'reason'=>'确认仅补发本条短信及可能产生费用']);
    deliveryCheck($smsCalls===['sms']&&$smsResult['channel']==='sms'&&$smsResult['status']==='submitted'&&!$smsResult['can_retry'],'confirmed SMS retry uses only original channel, never cross-channel fallback');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'owned isolated local schema, network functions disabled, no real notification'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.$error->getFile().':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
