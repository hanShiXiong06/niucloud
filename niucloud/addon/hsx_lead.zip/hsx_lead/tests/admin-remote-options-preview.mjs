import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

// Actual selector markup + shared production composable + real ElementPlus. Synthetic in-memory reads only.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..'),admin=path.join(workspace,'admin')
const require=createRequire(path.join(admin,'package.json')),{createServer}=require('vite'),compiler=require('@vue/compiler-sfc')
const {chromium}=createRequire('/tmp/package.json')('playwright'),output=path.join(workspace,'output/hsx-lead-remote-options-20261109')
fs.mkdirSync(output,{recursive:true})
const read=file=>fs.readFileSync(path.join(plugin,'admin',file),'utf8')
const merchant=read('views/components/MerchantPanel.vue').match(/<el-form-item label="商户会员身份（可稍后绑定）">[\s\S]*?<\/el-form-item>/)?.[0]
const review=read('views/cooperation/Reviews.vue').match(/<el-form-item label="关联线索">[\s\S]*?<\/el-form-item>/)?.[0]
const wizard=read('views/components/ConnectionWizard.vue'),company=wizard.match(/<el-select v-model="selectedCompany"[\s\S]*?<\/el-select>/)?.[0],store=wizard.match(/<el-select v-model="selectedStore"[\s\S]*?<\/el-select>/)?.[0]
assert.ok(merchant&&review&&company&&store,'actual selector markup must exist')
const template=`<main class="preview"><h2>后台检索选择器验收</h2><p class="preview-note">本地合成数据 · 不连接业务接口</p><el-form label-position="top"><section class="fixture-member">${merchant}</section><section class="fixture-review">${review}</section><el-form-item label="来源公司">${company}</el-form-item><el-form-item label="确认来源门店">${store}</el-form-item></el-form><button @click="changeScope">模拟关闭后切换站点</button></main>`
const rendered=compiler.compileTemplate({source:template,filename:'RemoteSelectorFixture.vue',id:'remote-fixture',compilerOptions:{expressionPlugins:['typescript']}})
assert.deepEqual(rendered.errors,[])
const component=rendered.code.replace('export function render','function render')+`
import{ref,reactive}from'vue'
import{useRemoteOptions,remoteOptionRows}from${JSON.stringify('/@fs/'+path.join(plugin,'admin/composables/useRemoteOptions.ts'))}
const errorText=(e,f)=>e?.message||f
export default{render,setup(){
 const actor=ref('synthetic:100005:open'),form=reactive({member_id:101,lead_id:undefined})
 const fixture=window.__remoteFixture={memberReads:[],leadReads:[],mode:'ok',delay:40,company:null,store:null}
 const members=useRemoteOptions({request:async q=>{
  fixture.memberReads.push(q);const mode=fixture.mode,delay=fixture.delay
  await new Promise(r=>setTimeout(r,delay));if(mode==='fail')throw Error('合成会员读取失败，请重试')
  const data=q==='空结果'?[]:q==='18800000002'?[{member_id:202,nickname:'同名会员',member_no:'NIU0000202',mobile:q}]:[{member_id:101,nickname:'原绑定王五',member_no:'NIU0000101',mobile:'18800000001'}]
  return remoteOptionRows({data},r=>r.member_id)
 },key:r=>Number(r.member_id),selectedKey:()=>form.member_id,scope:()=>actor.value,errorText,fallback:'读取失败'})
 members.remember({member_id:101,nickname:'原绑定王五',member_no:'NIU0000101',mobile:'18800000001'})
 const leads=useRemoteOptions({request:async q=>{fixture.leadReads.push(q);await new Promise(r=>setTimeout(r,20));return[{id:7,customer_name:'合成李四',mobile:'18800000007',lead_no:'XL-SYNTHETIC-007'}]},key:r=>Number(r.id),selectedKey:()=>form.lead_id,scope:()=>actor.value,errorText,fallback:'读取失败'})
 const selectedCompany=ref(''),selectedStore=ref(''),companies=[{id:'C01',name:'南京中心'},{id:'C02',name:'南京中心'},{id:'C03',name:'苏州公司'}],preview={stores:[{store_id:'S01',name:'南京玄武店'},{store_id:'S02',name:'南京江宁店'},{store_id:'S03',name:'苏州园区店'}]}
 window.__remoteFixtureState={form,members,leads,actor,selectedCompany,selectedStore}
 return{form,members:members.options,membersLoading:members.loading,membersError:members.error,loadMembers:members.load,searchMembers:members.search,memberOptionLabel:r=>[r.nickname,r.member_no,r.mobile].filter(Boolean).join(' · '),leadOptions:leads.options,leadLoading:leads.loading,leadError:leads.error,loadLeads:leads.load,searchLeads:leads.search,leadOptionLabel:r=>[r.customer_name,r.mobile,r.lead_no].filter(Boolean).join(' · '),selectedCompany,companies,selectedStore,preview,changeScope:()=>actor.value='synthetic:100006:closed'}
}}`
const virtual='virtual:hsx-remote-preview',fixtureComponent='virtual:hsx-remote-selector'
const entry=`import{createApp}from'vue';import ElementPlus from'element-plus';import zhCn from'element-plus/es/locale/lang/zh-cn';import'element-plus/dist/index.css';import Panel from'${fixtureComponent}';createApp(Panel).use(ElementPlus,{locale:zhCn}).mount('#app')`
const fixture={name:'hsx-remote-selector-offline',enforce:'pre',resolveId(id){if(id===virtual||id===fixtureComponent)return'\0'+id},load(id){if(id==='\0'+virtual)return entry;if(id==='\0'+fixtureComponent)return component},configureServer(server){server.middlewares.use((req,res,next)=>{
 if(req.url!=='/')return next();res.setHeader('Content-Type','text/html;charset=utf-8');res.end('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>检索选择器验收</title><style>body{margin:0;background:#f5f7fa;color:#303133;font-family:Arial,"PingFang SC",sans-serif}.preview{margin:24px auto;padding:24px;max-width:600px;box-sizing:border-box;background:white;border:1px solid #ebeef5;border-radius:8px}.preview h2{font-size:18px;margin:0 0 8px}.preview-note{font-size:12px;color:#909399;margin-bottom:24px}.el-select{width:100%}.lead-muted{font-size:12px;color:#909399;line-height:1.6;margin:8px 0}.lead-error,.coop-danger-copy{font-size:12px;color:#c45656;line-height:1.6;width:100%}.el-form-item{margin-bottom:24px}</style></head><body><div id="app"></div><script type="module" src="/@id/'+virtual+'"></script></body></html>')
})}}
const server=await createServer({configFile:false,root:admin,plugins:[fixture],css:{postcss:{plugins:[]}},resolve:{dedupe:['vue'],alias:[{find:'vue',replacement:path.join(admin,'node_modules/vue/dist/vue.runtime.esm-bundler.js')}]},optimizeDeps:{entries:[],include:['vue','element-plus']},server:{host:'127.0.0.1',port:0,strictPort:true,hmr:false,fs:{allow:[workspace]}}})
let browser,page;const errors=[],blocked=[],checks=[]
try{
 await server.listen();const origin='http://127.0.0.1:'+server.httpServer.address().port
 browser=await chromium.launch({headless:true,executablePath:process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disable-component-update','--no-first-run']})
 const context=await browser.newContext({viewport:{width:1100,height:900},deviceScaleFactor:1,reducedMotion:'reduce'})
 await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/')&&!/\/(?:adminapi|api)\//.test(url)||url.startsWith('data:'))return route.continue();blocked.push(url);return route.abort('blockedbyclient')})
 page=await context.newPage();page.on('pageerror',error=>errors.push(error.message));await page.goto(origin,{waitUntil:'networkidle',timeout:60000})
 const member=page.locator('.fixture-member'),memberInput=member.locator('.el-select input').first()
 await member.getByText('原绑定王五 · NIU0000101 · 18800000001',{exact:true}).waitFor();checks.push('初始绑定使用完整昵称、会员编号及手机号，不显示裸ID')
 await member.locator('.el-select').click();await page.waitForFunction(()=>window.__remoteFixture.memberReads.length>=1)
 await memberInput.fill('18800000002');const candidate=page.getByRole('option',{name:'同名会员 · NIU0000202 · 18800000002',exact:true});await candidate.waitFor()
 assert.equal(await page.getByRole('option',{name:'原绑定王五 · NIU0000101 · 18800000001',exact:true}).count(),1);await candidate.click();checks.push('按手机号查找并选择，查询其它会员时保留当前身份供核对')
 await member.locator('.el-select').click();await memberInput.fill('空结果');await page.waitForFunction(()=>window.__remoteFixture.memberReads.at(-1)==='空结果'&&!window.__remoteFixtureState.members.loading.value)
 await page.keyboard.press('Escape');await member.getByText('同名会员 · NIU0000202 · 18800000002',{exact:true}).waitFor();checks.push('没有新匹配时，已选身份名称仍然稳定，不退化成数字')
 await page.evaluate(()=>{window.__remoteFixture.mode='fail'});await member.locator('.el-select').click();await memberInput.fill('错误查询');await member.getByRole('alert').waitFor();assert.ok(await member.getByText('合成会员读取失败，请重试',{exact:false}).isVisible())
 await page.screenshot({path:path.join(output,'remote-options-error-1100.png'),fullPage:false});checks.push('错误与空列表分开，下拉菜单打开时也有可见重新读取入口')
 await page.evaluate(()=>{window.__remoteFixture.mode='ok'});await page.getByRole('button',{name:'重新读取候选',exact:true}).click();await page.waitForFunction(()=>!window.__remoteFixtureState.members.loading.value&&!window.__remoteFixtureState.members.error.value);assert.equal(await page.evaluate(()=>window.__remoteFixture.memberReads.at(-1)),'错误查询');await page.getByRole('heading',{name:'后台检索选择器验收'}).click();checks.push('菜单内重试沿用当前关键词，不清除已选会员')
 await page.locator('.fixture-review .el-select').click();await page.getByRole('option',{name:'合成李四 · 18800000007 · XL-SYNTHETIC-007',exact:true}).click();checks.push('回访选择线索展示客户、手机号、线索号，复用同一远程组件状态')
 const companyInput=page.getByRole('combobox',{name:'搜索授权来源公司',exact:true});await page.locator('.el-select').nth(2).click();await companyInput.fill('C02');await page.getByRole('option',{name:'南京中心 · C02',exact:true}).click();assert.equal(await page.evaluate(()=>window.__remoteFixtureState.selectedCompany.value),'C02');checks.push('来源公司按编号可过滤，同名公司不混淆且不自动切换')
 const storeInput=page.getByRole('combobox',{name:'搜索授权来源门店',exact:true});await page.locator('.el-select').nth(3).click();await storeInput.fill('江宁');await page.getByRole('option',{name:'南京江宁店 · S02',exact:true}).click();assert.equal(await page.evaluate(()=>window.__remoteFixtureState.selectedStore.value),'S02');checks.push('来源门店可输入名称过滤，仍由用户明确选择')
 await page.getByRole('heading',{name:'后台检索选择器验收'}).click();await page.locator('.el-select-dropdown:visible').waitFor({state:'hidden'});await page.screenshot({path:path.join(output,'remote-options-selected-1100.png'),fullPage:false})
 await page.evaluate(()=>{window.__remoteFixtureState.form.member_id=undefined});await member.locator('.el-select').click();await memberInput.fill('空结果');await page.getByText('没有匹配的会员，可换昵称、手机号或编号搜索',{exact:true}).waitFor();checks.push('真正无匹配时显示明确空态，不冒充读取错误')
 await page.getByRole('heading',{name:'后台检索选择器验收'}).click();await page.locator('.el-select-dropdown:visible').waitFor({state:'hidden'})
 await page.evaluate(()=>{window.__remoteFixture.delay=700});await member.locator('.el-select').click();await memberInput.fill('旧站点查询');await page.waitForFunction(()=>window.__remoteFixture.memberReads.at(-1)==='旧站点查询');await page.getByRole('button',{name:'模拟关闭后切换站点'}).click();await page.waitForTimeout(750);assert.equal(await page.evaluate(()=>window.__remoteFixtureState.members.options.value.length),0);checks.push('真实组件切换作用域后，不接收上一个站点的迟到会员候选')
 assert.deepEqual(errors,[]);assert.deepEqual(blocked,[])
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify({passed:true,checks,errors,blocked,scope:'Actual selectors extracted from MerchantPanel, Reviews and ConnectionWizard with production useRemoteOptions and real ElementPlus; synthetic in-memory reads, no business APIs, DB or real saves'},null,2));console.log(JSON.stringify({passed:true,checks,output,errors,blocked}))
}catch(error){console.error(JSON.stringify({errors,blocked,body:page?await page.locator('body').innerText():''}));throw error}finally{await browser?.close();await server.close()}
