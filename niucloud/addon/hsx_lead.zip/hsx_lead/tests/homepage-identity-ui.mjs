import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Actual public-home SFC with synthetic member/site identities and deferred API
// doubles. No browser, server transport, persisted data or real credentials.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const filename=path.join(plugin,'uni-app/components/cooperation/CoopBusinessNavigation.vue')
const parsed=compiler.parse(fs.readFileSync(filename,'utf8'),{filename});assert.deepEqual(parsed.errors,[])
const script=compiler.compileScript(parsed.descriptor,{id:'homepage-identity'})
assert.deepEqual(compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'homepage-identity',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors,[])
const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
let checks=2
const check=(value,label)=>{assert.ok(value,label);checks++}
const response=(key='purchase',name='二手机')=>({data:{profile:{mobile:'synthetic-private'},wallet:{balance:'synthetic-private'},config:{fee_percent:'synthetic-private',businesses:[{key,name,enabled:true,commission_minimum:'synthetic-private',fields:[{key:'private'}],options:[{id:'private'}]},{key:'closed',name:'关闭业务',enabled:false}]}}})
function deferred(){let resolve,reject;const promise=new Promise((ok,fail)=>{resolve=ok;reject=fail});return{promise,resolve,reject}}
function fixture(){
    let token='',site=100005,reads=0,work=async()=>response()
    const module={exports:{}},mounted=[],cleanups=[],store=Vue.reactive({mode:'',value:[]})
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,Object,Array,Promise,console,uni:{getStorageSync:()=>site}})(key=>{
        if(key==='vue')return{...Vue,onMounted:callback=>mounted.push(callback),onBeforeUnmount:callback=>cleanups.push(callback)}
        if(key==='@/app/stores/diy')return{default:()=>store}
        if(key==='@/utils/common')return{img:String,getToken:()=>token,getSiteId:()=>site}
        if(key==='../../api/cooperation')return{cooperationBootstrap:async()=>{reads++;return work()},coopError:cause=>cause.message}
        if(key==='../../utils/diy-business-preview')return loadMobileUtility('diy-business-preview')
        if(key==='../../utils/cooperation-diy-style')return loadMobileUtility('cooperation-diy-style')
        if(key==='../../utils/cooperation-business-cache')return loadMobileUtility('cooperation-business-cache')
        if(key==='../../utils/cooperation-business-presentation')return loadMobileUtility('cooperation-business-presentation')
        if(key==='../../utils/interaction-feedback')return{interactionFeedback(){}}
        if(key.endsWith('.vue'))return{default:{}}
        if(key.endsWith('.png'))return{default:'/synthetic.png'}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    const state=module.exports.default.setup({appearance:{}},{emit(){},expose(){}})
    return{state,store,get reads(){return reads},setToken:value=>{token=value},setSite:value=>{site=value},setWork:value=>{loadMobileUtility('cooperation-business-cache').clearCooperationBusinessCache();work=value},mount:()=>mounted.forEach(callback=>callback()),unmount:()=>cleanups.forEach(callback=>callback())}
}
const f=fixture();f.state.businesses.value=[{key:'old',name:'旧身份'}];f.state.error.value='旧错误';await f.state.load()
check(f.reads===0&&f.state.businesses.value.length===0&&f.state.error.value==='','anonymous load clears prior metadata/error without calling member bootstrap')
f.setToken('synthetic-member-a');const data=response();f.setWork(async()=>data);await f.state.load()
check(JSON.stringify(f.state.businesses.value)==='[{"key":"purchase","name":"二手机"}]','ordinary authenticated homepage stores only enabled key/name, never fee/form/options/profile/wallet data')
data.data.config.businesses[0].name='修改原响应';check(f.state.businesses.value[0].name==='二手机','display metadata is a fresh projection rather than an alias to full bootstrap data')
f.setToken('');await f.state.load();check(f.reads===1&&!f.state.businesses.value.length,'logout removes all prior metadata without a new authenticated read')
f.setToken('synthetic-member-a');await f.state.load();const slowA=deferred();f.setWork(()=>slowA.promise);const pendingA=f.state.load();f.setToken('synthetic-member-b')
const slowB=deferred();f.setWork(()=>slowB.promise);const pendingB=f.state.load();check(!f.state.businesses.value.length,'switching accounts clears the previous labels before the new request completes')
slowB.resolve(response('broadband','乙账号宽带'));await pendingB;slowA.resolve(response('purchase','甲账号旧响应'));await pendingA
check(f.state.businesses.value[0].name==='乙账号宽带','a late previous-account success cannot overwrite the new account result')
const slowLogout=deferred();f.setWork(()=>slowLogout.promise);const pendingLogout=f.state.load();f.setToken('');slowLogout.resolve(response('late','退出后的响应'));await pendingLogout
check(!f.state.businesses.value.length&&f.state.error.value==='','logout during a pending request drops its response and clears retained labels even before another load')
f.setToken('synthetic-member-a');f.setWork(async()=>response());await f.state.load();const failAfterSwitch=deferred();f.setWork(()=>failAfterSwitch.promise);const oldFailure=f.state.load();f.setToken('synthetic-member-b');failAfterSwitch.reject(Error('旧账号错误'));await oldFailure
check(!f.state.businesses.value.length&&f.state.error.value==='','an old-account failure does not expose its error under a different identity')
f.setWork(async()=>response());await f.state.load();const oldSite=deferred();f.setWork(()=>oldSite.promise);const pendingSite=f.state.load();f.setSite(100006);oldSite.resolve(response('old_site','旧站业务'));await pendingSite
check(!f.state.businesses.value.length,'the same token cannot accept a pending response after its site context changes')
f.setWork(async()=>response('new_site','新站业务'));await f.state.load();check(f.state.businesses.value[0].name==='新站业务','the new site can load its own display-only metadata')
const first=deferred(),second=deferred();f.setWork(()=>first.promise);const readFirst=f.state.load();f.setWork(()=>second.promise);const readSecond=f.state.load();second.resolve(response('latest','较新请求'));await readSecond;first.resolve(response('older','较旧请求'));await readFirst
check(f.state.businesses.value[0].name==='较新请求','same-identity concurrent reads obey request generation ordering')
const slowNormal=deferred();f.setWork(()=>slowNormal.promise);const normalRead=f.state.load();f.store.mode='decorate';f.state.businesses.value=[{key:'preview',name:'授权装修预览'}];slowNormal.resolve(response('member','会员响应'));await normalRead
check(f.state.businesses.value[0].key==='preview','a pending member read cannot overwrite or clear the separate decoration preview channel')
const beforePreview=f.reads;await f.state.load();check(f.reads===beforePreview&&f.state.businesses.value[0].key==='preview','decorate load leaves metadata and member transport untouched')
f.store.mode='';f.setWork(async()=>{throw Error('合成读取失败')});await f.state.load();check(f.state.error.value==='合成读取失败','a current authenticated failure still shows a recoverable read error')
const disposed=fixture();disposed.setToken('synthetic-member');const late=deferred();disposed.setWork(()=>late.promise);const afterUnmount=disposed.state.load();disposed.unmount();late.resolve(response('gone','已销毁'));await afterUnmount
check(!disposed.state.businesses.value.length,'an unmounted homepage does not accept member results')
console.log(`PASS ${checks} public-home identity checks; actual SFC with synthetic logout/account/site/request transitions, no browser/API/database/deployment operations.`)
