import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const source = fs.readFileSync(path.join(plugin, 'uni-app/components/cooperation/CoopRegionFields.vue'), 'utf8')
const descriptor = compiler.parse(source).descriptor
const script = compiler.compileScript(descriptor, { id: 'region-search' })
const js = ts.transpileModule(script.content, { compilerOptions: { module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020 } }).outputText
let checks = 0
const check = (value,label) => { assert.ok(value,label); checks++ }
const areas = new Map([[0,[{id:1,name:'河北省'}]],[1,[{id:2,name:'石家庄市'}]],[2,[{id:3,name:'长安区'}]]])
const district = { id:3,name:'长安区',level:3,province_id:1,city_id:2,district_id:3,region_text:'河北省 / 石家庄市 / 长安区' }
let respond = async () => ({data:{data:[district],total:1}})
const cleanup = [], module = {exports:{}}
vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{console,setTimeout,clearTimeout})(key => {
    if(key==='vue') return {...Vue,onBeforeUnmount:fn=>cleanup.push(fn)}
    if(key==='@/app/api/system') return {getAreaListByPid:async pid=>({data:areas.get(pid)||[]})}
    if(key==='../../api/regions') return {searchCooperationRegions:keyword=>respond(keyword)}
    if(key==='../../api/cooperation') return {coopError:(cause,fallback)=>cause.message||fallback}
    if(key==='../../utils/mobile-ui') return loadMobileUtility('mobile-ui')
    if(key.endsWith('.vue')) return {default:{}}
    throw Error('Unexpected dependency '+key)
},module,module.exports)
const events=[], props=Vue.reactive({modelValue:{province_id:1,city_id:2,district_id:3,region_text:district.region_text},minLevel:3,disabled:false})
const state=module.exports.default.setup(props,{emit:(...args)=>events.push(args),expose(){}})
const flush=async()=>{for(let n=0;n<5;n++){await Promise.resolve();await Vue.nextTick()}}
state.open();await flush()
check(state.show.value&&events[0][0]==='overlay'&&events[0][1]===true,'opening informs parent to suspend background scroll')
state.keyword.value='长安区';await flush();await state.search()
check(state.results.value.length===1&&state.results.value[0].region_text===district.region_text,'search results preserve full hierarchy and distinguish duplicate names')
state.selectResult(district)
const written=events.filter(row=>row[0]==='update:modelValue').at(-1)[1]
check(written.province_id===1&&written.city_id===2&&written.district_id===3,'one search selection supplies full region IDs')
check(!state.show.value&&events.at(-1)[1]===false,'successful selection closes only the selector and restores parent scrolling')
state.open();await flush();const count=events.filter(row=>row[0]==='update:modelValue').length
state.selectResult({id:1,name:'河北省',level:1,province_id:1,city_id:0,district_id:0,region_text:'河北省'});await flush()
check(state.hierarchy.value&&state.show.value&&events.filter(row=>row[0]==='update:modelValue').length===count,'required district form does not silently submit an incomplete province')
state.close();check(events.filter(row=>row[0]==='update:modelValue').length===count,'cancel retains previously saved selection')
props.minLevel=1;state.open();await flush();state.selectResult({id:1,name:'河北省',level:1,province_id:1,city_id:0,district_id:0,region_text:'河北省'})
check(events.filter(row=>row[0]==='update:modelValue').at(-1)[1].district_id===0,'province-only store filtering is supported explicitly')
state.open();await flush();state.keyword.value='失败';await flush();respond=async()=>{throw Error('合成查询失败')};await state.search()
check(state.error.value==='合成查询失败'&&!state.searching.value&&state.show.value,'read failure remains visible and leaves selector open')
let resolve;respond=()=>new Promise(ok=>{resolve=ok});state.keyword.value='慢查询';await flush();const pending=state.search();state.close();resolve({data:{data:[district],total:1}});await pending
check(!state.show.value&&!state.searching.value,'a stale response cannot reopen a dismissed selector')
props.disabled=true;state.open();check(!state.show.value,'disabled fields cannot open a new interaction')
for(const stop of cleanup)stop()
check(source.includes('CooperationSearch')&&source.includes('scroll-y class="region-results"'),'shared search and a single bounded results scroller are reused')
const tail=descriptor.template.content.match(/<view class="region-result__tail">([\s\S]*?)<\/view>/)?.[1]||''
check(tail.includes('class="region-level"')&&tail.includes('name="arrow-right"'),'level tag and arrow share one trailing flex group')
const css=compiler.compileStyle({source:descriptor.styles[0].content,filename:path.join(plugin,'uni-app/components/cooperation/CoopRegionFields.vue'),id:'region-search',preprocessLang:'scss',scoped:false})
check(css.errors.length===0,'region layout SCSS compiles')
const tailStyle=css.code.match(/\.region-result\s*>\s*\.region-result__tail\s*\{([^}]*)\}/)?.[1]||''
const contentStyle=css.code.match(/\.region-result\s*>\s*\.region-result__content\s*\{([^}]*)\}/)?.[1]||''
check(/display:\s*flex/.test(tailStyle)&&/flex-direction:\s*row/.test(tailStyle),'trailing icons remain horizontal')
check(/flex:\s*0 0 auto/.test(tailStyle)&&/align-items:\s*center/.test(tailStyle),'tag and arrow are compact and vertically centered')
check(/flex:\s*1/.test(contentStyle)&&/min-width:\s*0/.test(contentStyle),'long place names consume only the remaining width')
check(/flex-wrap:\s*nowrap/.test(css.code)&&/justify-content:\s*space-between/.test(css.code),'row distributes content and tail to opposite sides')
console.log(`PASS ${checks} mobile region search checks; actual Vue setup with synthetic dictionary/transport only.`)
