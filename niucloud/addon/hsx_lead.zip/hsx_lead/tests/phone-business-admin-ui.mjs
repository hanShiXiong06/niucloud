import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../admin/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
let checks = 0
const check = (condition, message) => { assert.ok(condition, message); checks++ }
const run = (source, dependencies = {}) => {
    const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const module = { exports: {} }
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`, { Date, Number, String, Math, Set, Map, JSON })(key => { if (key in dependencies) return dependencies[key]; if (key.endsWith('.vue')) return { default: {} }; throw Error(key) }, module, module.exports)
    return module.exports
}
const business = run(fs.readFileSync(path.join(plugin, 'admin/composables/business.ts'), 'utf8'))
const entity = run(fs.readFileSync(path.join(plugin, 'admin/composables/entity.ts'), 'utf8'))
const home = () => ({ key: 'home_recycle', name: '二手机上门回收', enabled: false, dimension: 'model', selection_mode: 'multiple', selection_limit: 5, commission_minimum: '100.00', fee_override: false, fields: [{ key: 'pickup_address', label: '上门地址', type: 'address', required: true, placeholder: '小区、街道或附近地标' }], options: [] })
const rows = []
check(!business.addBusinessDraft(rows, home()) && rows.length === 1 && !rows[0].enabled, 'preset adds a paused business instead of silently changing live charging')
check(business.addBusinessDraft(rows, home()).includes('已在列表') && rows.length === 1, 'duplicate preset never creates a second business')
check(business.businessValidation(rows) === '', 'address is a supported declarative field without a new table')
check(business.businessValidation([{ ...home(), fields: [{ ...home().fields[0], placeholder: '<script>' }] }]).includes('纯文本'), 'placeholder is plain text, not executable HTML')
check(business.businessValidation([{ ...home(), fields: [{ ...home().fields[0], placeholder: 'a'.repeat(121) }] }]).includes('120'), 'placeholder length is bounded')
check(business.businessValidation([{ ...home(), fee_override: true, fee_percent: 100, fee_minimum: 0 }]).includes('独立平台费'), '100 percent cannot absorb all publisher proceeds')
check(business.businessValidation([{ ...home(), fee_override: true, fee_percent: 10, fee_minimum: 100 }]).includes('独立平台费'), 'business platform floor must stay below commission minimum')
const rule = business.businessFeeRules({ ...home(), fee_override: false, fee_percent: 80, fee_minimum: 90 }, { fee_percent: 10, fee_minimum: 9.9 })
check(rule.percent === 10 && rule.minimum === 9.9, 'inherit ignores stale local fee drafts')
const override = business.businessFeeRules({ ...home(), fee_override: true, fee_percent: 20, fee_minimum: 3 }, { fee_percent: 10, fee_minimum: 9.9 })
check(override.percent === 20 && override.minimum === 3, 'independent per-business rate is used for preview')
const payload = business.businessPayload([{ ...home(), fee_override: true, fee_percent: 20, fee_minimum: 3 }])[0]
check(payload.fee_percent === '20.00' && payload.fee_minimum === '3.00' && payload.fields[0].placeholder === home().fields[0].placeholder, 'address metadata and exact-decimal fee overrides serialize together')
const preset = home(), clones = []
business.addBusinessDraft(clones, preset); clones[0].fields[0].label = '改名'
check(preset.fields[0].label === '上门地址', 'editing added preset cannot mutate server presets or another business')

const messages = [], events = [], descriptors = {}
for (const name of ['BusinessSettings.vue', 'Settings.vue']) {
    const filename = path.join(plugin, 'admin/views/cooperation', name), source = fs.readFileSync(filename, 'utf8')
    const parsed = compiler.parse(source, { filename }); assert.deepEqual(parsed.errors, [])
    const result = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename, id: name, compilerOptions: { expressionPlugins: ['typescript'] } }); assert.deepEqual(result.errors, [])
    descriptors[name] = parsed.descriptor; checks++
}
const props = Vue.reactive({ modelValue: [], canEditCatalog: true, presets: [home()], feePercent: 10, feeMinimum: 9.9, disabled: false })
const setup = run(compiler.compileScript(descriptors['BusinessSettings.vue'], { id: 'phone-business' }).content, { vue: Vue, 'element-plus': { ElMessage: { warning: text => messages.push(text), success: text => messages.push(text) } }, '@element-plus/icons-vue': { Plus: {} }, '../../composables/business': business }).default.setup(props, { expose() {}, emit: (...args) => events.push(args) })
check(setup.availablePresets.value.length === 1, 'an existing site can see a missing phone preset without replacing its saved configuration')
setup.choosePreset('home_recycle')
check(props.modelValue.length === 1 && setup.activeKey.value === 'home_recycle' && setup.availablePresets.value.length === 0, 'adding selects the new paused business and removes only its preset action')
check(events.some(item => item[0] === 'fee-change'), 'fee confirmation is invalidated after business changes')
setup.setFeeOverride(props.modelValue[0], true)
check(props.modelValue[0].fee_percent === 10 && props.modelValue[0].fee_minimum === 9.9 && setup.feePreview(props.modelValue[0]).fee === 10, 'switching to independent rule starts from current global contract with accurate preview')
props.modelValue[0].fee_percent = 20
check(setup.feePreview(props.modelValue[0]).fee === 20 && setup.feePreview(props.modelValue[0]).net === 80, 'per-business preview updates publisher and platform proceeds')
setup.choosePreset('custom'); Object.assign(setup.custom, { key: 'home_recycle', name: '重复', dimension: 'model' }); setup.addCustom()
check(props.modelValue.length === 1 && setup.adding.value && setup.addError.value.includes('已在列表'), 'duplicate custom key preserves dialog and draft with a clear error')
Object.assign(setup.custom, { key: 'phone_clean', name: '手机清洁' }); setup.addCustom()
check(props.modelValue.length === 2 && !props.modelValue[1].enabled && !setup.adding.value, 'custom phone business can be added and remains paused until configured')
props.disabled = true; setup.choosePreset('custom'); setup.setFeeOverride(props.modelValue[0], false)
check(!setup.adding.value && props.modelValue[0].fee_override, 'saving state prevents modal actions and fee mutations')
const detail = business.businessFormEntries({ business_snapshot: { fields: home().fields }, form_values: { pickup_address: '测试街道附近' } })
check(detail[0].label === '上门地址' && detail[0].value === '测试街道附近', 'platform detail shows frozen address label and original text')
const settingWrites = []
const fixture = { enabled: true, publishing_required: true, publishing_price: '99.00', publishing_cycle: 'year', publishing_months: 12, certification_price: '199.00', certification_months: 12, fee_percent: '10.00', fee_minimum: '9.90', fee_confirmed: true, commission_minimum: '50.00', response_minutes: 30, contact_hours: 24, review_hours: 48, inventory_fresh_hours: 24, demand_model_limit: 5, grades: [{ id: 'S', name: 'S', rank: 30, min_inventory: 100, all_models: false, status: 1 }], businesses: [{ ...home(), enabled: true, commission_minimum: '1.00', fee_override: true, fee_percent: '1.00', fee_minimum: '0.01' }], business_presets: [home()] }
const settings = run(compiler.compileScript(descriptors['Settings.vue'], { id: 'phone-settings' }).content, {
    vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} }, 'element-plus': { ElMessage: { success: text => messages.push(text) }, ElMessageBox: { confirm: async () => true } },
    '@element-plus/icons-vue': { Plus: {}, Refresh: {} }, '@/stores/modules/user': { default: () => ({}) },
    '../../composables/business': business, '../../composables/entity': entity, '../../composables/navigation': { hasLeadPagePermission: () => true },
    '../../composables/cooperation': { coopError: error => error.message, coopMoney: value => String(value) },
    '../../api/cooperation': { getCooperationConfig: async () => ({ data: fixture }), saveCooperationConfig: async payload => { settingWrites.push(JSON.parse(JSON.stringify(payload))); return { data: { ...payload, business_presets: [home()] } } } },
}).default.setup({}, { expose() {} })
await settings.load()
check(settings.ready.value && settings.form.business_presets.length === 1, 'editor receives available presets independently of saved site business list')
check(settings.validation() === '', 'a one-yuan business with independent one-cent platform floor is not incorrectly compared with global 9.9 floor')
settings.form.businesses[0].fee_override = false
check(settings.validation().includes('最低协作费用'), 'switching back to inherited global floor rejects an unpayable minimum')
settings.form.businesses[0].fee_override = true
await settings.save()
check(settingWrites.length === 1 && !('business_presets' in settingWrites[0]) && settingWrites[0].businesses[0].fee_minimum === '0.01', 'save sends exact per-business fee and excludes editor-only presets')
check(settings.form.business_presets.length === 1 && !('publishing_cycle' in settings.form) && !settings.error.value, 'successful readback preserves business presets without a second subscription configuration')
console.log(`PASS ${checks} phone-business admin checks; actual SFC scripts and pure config helpers; no HTTP, real fees or database writes.`)
