<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions before isolated testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';

use addon\hsx_lead\app\service\{CatalogService, CatalogConfigStorage, Context};
use addon\hsx_lead\app\service\cooperation\{BusinessService, ConfigService, CooperationService};
use addon\hsx_lead\app\support\Data;
use app\service\core\sys\CoreConfigService;
use think\facade\{Cache, Db};

$checks = 0;
$failed = false;
$pdo = null;
$schema = '';
function curatedCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}

try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    $admin = new Context($site, 1);
    $settings = new ConfigService($admin);
    $config = $settings->get();
    $config['enabled'] = true;
    $config['publishing_required'] = false;
    $config['fee_confirmed'] = true;
    $settings->save($config);

    $now = time();
    $insert = static fn(string $table, array $row): int => (int) Db::name('hsx_lead_' . $table)->insertGetId(
        ['site_id' => $site, 'create_time' => $now, 'update_time' => $now] + $row
    );
    $merchant = $insert('merchant', ['name' => 'Synthetic source category merchant', 'member_id' => 101]);
    $connection = $insert('connection', [
        'merchant_id' => $merchant, 'provider' => 'soujike', 'enabled' => 1,
        'last_sync_status' => 'completed', 'last_sync_at' => $now,
    ]);
    $run = $insert('sync_run', ['merchant_id' => $merchant, 'connection_id' => $connection, 'config_version' => 1, 'status' => 'completed']);
    Db::name('hsx_lead_connection')->where('id', $connection)->update(['published_run_id' => $run]);
    for ($i = 0; $i < 25; $i++) {
        $insert('inventory', [
            'merchant_id' => $merchant, 'connection_id' => $connection, 'sync_run_id' => $run,
            'source_key' => 'curated-only-source-' . $i, 'model' => 'ERP_ONLY_商户杂项型号_' . $i,
            'brand' => 'ERP_ONLY_自定义分类', 'memory' => '256GB', 'price' => '1200.00',
            'quantity' => '1.000', 'saleable_quantity' => '1.000', 'availability' => 'available', 'fetched_at' => $now,
            'snapshot_json' => Data::json(['source_category' => 'ERP_ONLY_不应写入业务分类', 'row' => $i]),
            'source_status_json' => Data::json(['_inventory' => ['listing_status' => 'listed', 'stock_status' => 'in_stock']]),
        ]);
    }
    $stockBefore = Db::name('hsx_lead_inventory')->where('site_id', $site)->order('id')->select()->toArray();
    curatedCheck(count($stockBefore) === 25, 'fixture contains a published ERP generation before directory reads');
    $historicDemand = [['id' => 'historic_curated', 'title' => '既有线索保留型号', 'brand' => '历史快照', 'category_name' => '历史分类', 'aliases' => []]];
    $lead = $insert('collaboration', [
        'lead_no' => 'LC-CURATED-ONLY-FIXTURE', 'publisher_id' => $merchant,
        'request_id' => 'curated-only-historic-request', 'customer_name' => 'Synthetic historic customer',
        'mobile' => '13800000000', 'business_type' => 'purchase', 'models_json' => Data::json($historicDemand),
        'rule_json' => Data::json(['fee_confirmed' => true, 'commission_minimum' => '100.00']),
    ]);
    $leadBefore = Db::name('hsx_lead_collaboration')->where('id', $lead)->find();
    $capabilityKey = 'HSX_LEAD_CAPABILITY_' . $merchant;
    $capabilityBefore = ['models' => $historicDemand];
    (new CoreConfigService())->setConfig($site, $capabilityKey, $capabilityBefore);

    // Enable the ORM's actual SQL listener for this owned test schema. The
    // production settings and all existing application databases stay untouched.
    $database = Db::getConfig();
    $database['connections'][$database['default']]['trigger_sql'] = true;
    Db::setConfig($database);
    Db::connect($database['default'], true);
    $sql = [];
    Db::listen(static function (string $statement) use (&$sql): void { $sql[] = $statement; });
    $readWithoutInventory = static function (callable $read, string $label) use (&$sql) {
        $start = count($sql);
        $result = $read();
        $queries = array_slice($sql, $start);
        curatedCheck(!preg_match('/hsx_lead_(?:inventory|connection|sync_run)/i', implode("\n", $queries)), $label);
        return [$result, $queries];
    };

    $catalog = new CatalogService($admin);
    $catalogCacheKey = 'site_config_cache' . CatalogService::KEY . '_' . $site;
    $staleCatalogCache = ['id' => 999999, 'site_id' => $site, 'config_key' => CatalogService::KEY, 'value' => [
        'items' => [['id' => 'stale_erp_model', 'title' => 'ERP_ONLY_旧缓存分类', 'brand' => 'ERP_ONLY_旧缓存品牌']], 'updated_at' => 1,
    ]];
    Cache::set($catalogCacheKey, $staleCatalogCache);
    [$defaults, $queries] = $readWithoutInventory(fn() => $catalog->directory(), 'unconfigured directory never joins or groups ERP inventory');
    curatedCheck(count($queries) > 0, 'SQL listener observes actual uncached directory configuration reads');
    curatedCheck($defaults['source'] === 'default' && count($defaults['items']) > 0, 'unconfigured directory uses only backend-owned built-in options');
    curatedCheck(!str_contains(json_encode($defaults, JSON_UNESCAPED_UNICODE), 'ERP_ONLY_'), 'source-defined model and brand labels cannot become default options');
    curatedCheck(Cache::get($catalogCacheKey) === $staleCatalogCache, 'uncached canonical directory ignores rather than mutates a late stale framework cache entry');
    Cache::delete($catalogCacheKey);
    $iphone = array_values(array_filter($defaults['items'], static fn(array $item): bool => $item['title'] === 'iPhone 16'));
    curatedCheck(count($iphone) === 1 && in_array('iPhone16', $iphone[0]['aliases'], true), 'built-in labels and aliases remain intact');

    $mobile = new CooperationService(new Context($site, 0, 101));
    [$mobileResult] = $readWithoutInventory(fn() => $mobile->catalog(['business_type' => 'purchase', 'browse' => true]), 'mobile demand selector does not query ERP inventory');
    curatedCheck(!str_contains(json_encode($mobileResult, JSON_UNESCAPED_UNICODE), 'ERP_ONLY_'), 'ERP-only options are absent from mobile browsing');
    curatedCheck($mobile->catalog(['business_type' => 'purchase', 'keyword' => 'ERP_ONLY_']) === [], 'keyword search cannot reintroduce ERP-only categories');
    $businesses = new BusinessService($admin);
    foreach ($settings->get()['businesses'] as $business) {
        [$options] = $readWithoutInventory(fn() => $businesses->options($business), $business['key'] . ' business options never query ERP tables');
        curatedCheck(!str_contains(json_encode($options, JSON_UNESCAPED_UNICODE), 'ERP_ONLY_'), $business['key'] . ' options exclude source-defined labels');
    }

    $catalog->save(['business_type' => 'rent', 'format' => 'json', 'content' => Data::json([[
            'id' => 'rent_curated', 'title' => '人工维护租机型号', 'brand' => '后台品牌',
            'category_name' => '租赁', 'path' => ['租机', '人工品牌', '人工维护租机型号'], 'aliases' => ['人工租机'],
    ]])]);
    $rentBefore = $catalog->get(['business_type' => 'rent'])['items'];
    curatedCheck(array_column($rentBefore, 'id') === ['rent_curated'], 'independent manually configured rental options remain selected');

    $catalog->save(['business_type' => 'purchase', 'format' => 'json', 'content' => json_encode([[
        'id' => 'purchase_curated', 'title' => '人工维护购买型号', 'brand' => '后台品牌',
        'category_name' => '购买', 'path' => ['二手机', '后台品牌', '人工维护购买型号'], 'aliases' => ['人工购买'],
    ]], JSON_UNESCAPED_UNICODE)]);
    Cache::set($catalogCacheKey, -1);
    [$configured] = $readWithoutInventory(fn() => $catalog->directory(), 'configured directory reads do not inspect or classify ERP stock');
    curatedCheck($configured['source'] === 'configured' && array_column($configured['items'], 'id') === ['purchase_curated'], 'backend import alone replaces the shared purchase directory');
    curatedCheck((string) Cache::get($catalogCacheKey) === '-1', 'a stale not-found sentinel cannot hide a newly imported backend directory');
    Cache::set($catalogCacheKey, $staleCatalogCache);
    curatedCheck(array_column($catalog->directory()['items'], 'id') === ['purchase_curated'], 'a late ERP-populated cache cannot replace the persisted backend directory');
    Cache::delete($catalogCacheKey);
    curatedCheck($catalog->get(['business_type' => 'rent'])['items'] === $rentBefore, 'purchase import preserves independent rental directory');
    $exchange = $catalog->get(['business_type' => 'exchange'])['items'];
    curatedCheck(array_column($exchange, 'id') === array_column($defaults['items'], 'id'), 'first import freezes only the prior curated sibling fallback');
    curatedCheck(!str_contains(json_encode($settings->get()['businesses'], JSON_UNESCAPED_UNICODE), 'ERP_ONLY_'), 'sibling fallback preservation cannot persist ERP-derived options');

    (new CoreConfigService())->setConfig($site, CatalogService::KEY, ['items' => [], 'updated_at' => $now]);
    Cache::set($catalogCacheKey, $staleCatalogCache);
    [$empty] = $readWithoutInventory(fn() => $catalog->directory(), 'explicitly empty directory does not fall back to ERP tables');
    curatedCheck($empty['source'] === 'configured' && $empty['items'] === [], 'an administrator explicitly clearing shared options remains empty');
    curatedCheck(Cache::get($catalogCacheKey) === $staleCatalogCache, 'post-reset empty directory is read from persisted state even after a stale cache refill');
    Cache::delete($catalogCacheKey);
    curatedCheck($catalog->get(['business_type' => 'purchase'])['items'] === [], 'purchase model selector respects explicit empty backend directory');
    curatedCheck($catalog->get(['business_type' => 'rent'])['items'] === $rentBefore, 'explicit shared empty state cannot erase a sibling manual directory');
    $reset = $settings->get();
    foreach ($reset['businesses'] as &$business) {$business['options'] = []; $business['catalog_configured'] = true;}
    unset($business);
    // Trusted reset fixture, not the general settings endpoint: the real
    // reset command has its own complete isolated regression suite.
    unset($reset['membership_levels'], $reset['membership_configuration_source']);
    Db::transaction(static function()use($site,$reset):void {
        Db::name('site')->where('site_id',$site)->lock(true)->find();
        CatalogConfigStorage::write($site,ConfigService::KEY,$reset);
    });
    foreach ($settings->get()['businesses'] as $business) {
        [$options] = $readWithoutInventory(fn() => $businesses->options($business), $business['key'] . ' empty reset does not query ERP stock');
        curatedCheck($options === [], $business['key'] . ' options stay empty after explicit administrator reset');
    }
    $catalog->save(['business_type' => 'new_phone', 'format' => 'json', 'content' => json_encode([[
        'id' => 'new_phone_curated', 'title' => '后台重新导入品牌', 'brand' => '后台品牌',
        'category_name' => '新机', 'path' => ['新机', '授权品牌', '后台重新导入品牌'], 'aliases' => [],
    ]], JSON_UNESCAPED_UNICODE)]);
    curatedCheck(array_column($catalog->get(['business_type' => 'new_phone'])['items'], 'id') === ['new_phone_curated'], 'backend import can restore a selected directory after all-business reset');
    curatedCheck($catalog->get(['business_type' => 'purchase'])['items'] === [] && $catalog->get(['business_type' => 'rent'])['items'] === [], 'restoring one business never repopulates other reset businesses');
    curatedCheck(Db::name('hsx_lead_inventory')->where('site_id', $site)->order('id')->select()->toArray() === $stockBefore, 'catalog reads and imports neither delete nor mutate synced inventory snapshots');
    curatedCheck((int) Db::name('hsx_lead_connection')->where('id', $connection)->value('published_run_id') === $run, 'inventory publication remains intact and available to stock reads');
    curatedCheck(Db::name('hsx_lead_collaboration')->where('id', $lead)->find() === $leadBefore, 'catalog reset never rewrites an existing lead demand or fee snapshot');
    curatedCheck((new CoreConfigService())->getConfigValue($site, $capabilityKey) === $capabilityBefore, 'directory reset preserves pre-existing merchant capability declarations');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => 'owned random localhost schema; curated-only catalogs; synced inventory preserved', 'remote_calls' => 0], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true;
    fwrite(STDERR, 'FAIL curated catalog: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    if ($pdo instanceof PDO && $schema !== '') {
        try { leadCleanup($pdo, $schema); }
        catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL test cleanup\n"); }
    }
}
exit($failed ? 1 : 0);
