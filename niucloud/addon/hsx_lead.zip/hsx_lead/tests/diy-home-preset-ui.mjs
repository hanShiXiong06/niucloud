import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {execFileSync} from 'node:child_process'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++},clone=value=>JSON.parse(JSON.stringify(value))
function moduleOf(source,deps={}){const module={exports:{}},code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{String,Number,Object,Array,JSON,Promise})(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected import '+key)})(),module,module.exports);return module.exports}
const helper=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/diyHomePreset.ts'),'utf8'))
const templates=JSON.parse(execFileSync(process.env.PHP_BIN||'php',['-d','error_reporting=0','-r',`echo json_encode((require ${JSON.stringify(path.join(plugin,'app/dict/diy/pages.php'))})['DIY_HSX_LEAD_INDEX'],JSON_UNESCAPED_UNICODE);`],{encoding:'utf8'}))
const HOME='DIY_HSX_LEAD_INDEX',originalValue=JSON.stringify({global:{title:'用户原首页',pageStartBgColor:'#123456'},value:[{componentName:'GraphicNav',title:'自定义入口',unknown_user_setting:'keep'}]})
function fixture(options={}){
    const rows=new Map([[31,{id:31,site_id:100005,name:HOME,type:HOME,title:'用户原首页',page_title:'后台自定义名称',template:'custom',mode:'diy',is_default:1,value:originalValue}]]),calls=[],stages=[];let active=31,current=true,backups=0,writes=0
    const api={
        getDecoratePage:async()=>{calls.push('active');return{code:1,data:{use_template:{id:active}}}},
        getDiyPageInfo:async id=>{calls.push('info:'+id);let row=clone(rows.get(id));if(id===81&&options.badBackup)row=options.badBackup(row);return{code:1,data:row}},
        getDiyTemplatePages:async()=>{calls.push('templates');return{code:1,data:options.badTemplate?{}:clone(templates)}},
        copyDiy:async()=>{calls.push('copy');if(options.failCopy)throw Error('合成备份失败');backups++;rows.set(81,{...clone(rows.get(31)),id:81,is_default:0,page_title:'后台自定义名称_副本'});if(options.sourceChanged)rows.get(31).value=JSON.stringify({global:{title:'其他管理员的新内容'},value:[]});if(options.activeChanged)active=32;if(options.contextAfterCopy)current=false;return{code:1,data:{id:81}}},
        editDiyPage:async value=>{calls.push('edit');writes++;if(options.failSave)throw Error('合成保存拒绝');Object.assign(rows.get(31),clone(value));if(options.activeAfterSave)active=32;if(options.unknownSave)throw Error('合成保存响应中断');return{code:1,data:{}}},
    }
    const context={assertCurrent(){if(!current)throw Error('上下文已变化')},stage:text=>stages.push(text),backup:id=>calls.push('verified-backup:'+id),beforeWrite:()=>calls.push('before-write')}
    return{api,context,calls,rows,stages,get backups(){return backups},get writes(){return writes},setActive:value=>{active=value}}
}
const ok=fixture(),result=await helper.applyBlueWhiteHome(ok.api,ok.context)
check(result.id===31&&result.backupId===81&&ok.writes===1&&ok.backups===1,'one deliberate operation creates one backup and writes the original target once')
check(ok.rows.get(81).value===originalValue&&ok.rows.get(81).is_default===0&&ok.rows.get(31).is_default===1,'original full JSON survives in an inactive backup without changing active selection')
check(ok.calls.join('|')==='active|info:31|templates|copy|info:81|verified-backup:81|active|info:31|before-write|edit|info:31|active','actual orchestration verifies backup before edit and verifies both saved row and active page afterward')
check(helper.diyPageSource(ok.rows.get(31).value)===helper.diyPageSource(templates.hsx_lead_index.data)&&ok.rows.get(31).page_title==='后台自定义名称','only confirmed page layout changes; backend page name remains user-owned')
for(const [name,options]of Object.entries({badTemplate:{badTemplate:true},failedBackup:{failCopy:true},activeBackup:{badBackup:row=>({...row,is_default:1})},differentBackup:{badBackup:row=>({...row,value:'{"global":{},"value":[]}'})},changedSource:{sourceChanged:true},changedActive:{activeChanged:true},changedContext:{contextAfterCopy:true}})){
    const f=fixture(options);let error='';try{await helper.applyBlueWhiteHome(f.api,f.context)}catch(cause){error=cause.message}check(error&&f.writes===0,name+' aborts before target write')
}
const failed=fixture({failSave:true});await assert.rejects(helper.applyBlueWhiteHome(failed.api,failed.context));check(failed.rows.get(81).value===originalValue&&failed.rows.get(31).value===originalValue,'target failure leaves verified backup and old target intact')
const unknown=fixture({unknownSave:true});await assert.rejects(helper.applyBlueWhiteHome(unknown.api,unknown.context));check(unknown.writes===1&&unknown.rows.get(81).value===originalValue,'unknown write result is not replayed or rolled back over another source')
const switched=fixture({activeAfterSave:true});await assert.rejects(helper.applyBlueWhiteHome(switched.api,switched.context));check(switched.writes===1,'saved row alone cannot prove the active homepage was changed')
const filename=path.join(plugin,'admin/views/cooperation/home-page.vue'),parsed=sfc.parse(fs.readFileSync(filename,'utf8'),{filename}),script=sfc.compileScript(parsed.descriptor,{id:'home-preset'})
check(parsed.errors.length===0&&sfc.compileTemplate({source:parsed.descriptor.template.content,filename,id:'home-preset',compilerOptions:{bindingMetadata:script.bindings}}).errors.length===0,'actual homepage action UI compiles')
function pageFixture(options={}){
    const f=fixture(options),user=Vue.reactive({siteInfo:{site_id:100005},token:'synthetic',rules:['hsx_lead_cooperation_home','page_decorate']}),cleanup=[],opens=[];let confirm=async()=>{},confirmCount=0
    const navigation=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/navigation.ts'),'utf8'))
    const state=moduleOf(script.content,{vue:{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)},'vue-router':{useRouter:()=>({resolve:value=>({href:JSON.stringify(value)})})},'element-plus':{ElMessageBox:{confirm:async()=>{confirmCount++;return confirm()}}},'@/stores/modules/user':{default:()=>user},'@/app/api/diy':f.api,'../../composables/navigation':navigation,'../../composables/diyHomePreset':helper,'../components/PageShell.vue':{default:{}}}).default.setup({}, {expose(){}})
    return{...f,state,user,cleanup,opens,setConfirm:fn=>{confirm=fn},get confirmCount(){return confirmCount}}
}
const locked=pageFixture();let release;locked.setConfirm(()=>new Promise(resolve=>{release=resolve}));const first=locked.state.applyBlueWhite();await locked.state.applyBlueWhite();check(locked.state.applying.value&&locked.confirmCount===1&&locked.calls.length===0,'submit lock includes the confirmation dialog and no request happens before consent');release();await first;check(!locked.state.readRequired.value&&locked.state.backupId.value===81&&locked.state.progress.value.includes('回读核对'),'success appears only after verified framework readback')
const denied=pageFixture();denied.user.rules=['hsx_lead_cooperation_home','diy_page_update'];await denied.state.applyBlueWhite();check(denied.calls.length===0&&denied.confirmCount===0,'POST-only page creation grant cannot invoke the PUT preset action')
const changed=pageFixture();changed.setConfirm(async()=>{changed.user.siteInfo.site_id=100006});await changed.state.applyBlueWhite();check(changed.calls.length===0&&changed.state.error.value.includes('变化'),'site change during confirmation prevents all framework requests')
const left=pageFixture();left.setConfirm(async()=>left.cleanup.forEach(fn=>fn()));await left.state.applyBlueWhite();check(left.calls.length===0,'leaving the page during confirmation cannot apply in the background')
const uncertain=pageFixture({unknownSave:true});await uncertain.state.applyBlueWhite();const beforeRetry=uncertain.calls.length;await uncertain.state.applyBlueWhite();check(uncertain.state.readRequired.value&&uncertain.calls.length===beforeRetry,'unknown save requires explicit state inspection instead of a second overwrite')
uncertain.setActive(32);await uncertain.state.verifyResult();check(uncertain.state.readRequired.value,'matching target content does not clear uncertainty when another homepage is active');uncertain.setActive(31);await uncertain.state.verifyResult();check(!uncertain.state.readRequired.value&&uncertain.state.progress.value.includes('保存成功'),'explicit complete identity and active-page inspection can confirm a previously unknown result')
console.log(`PASS ${checks} homepage backup/apply UI checks; actual helper and Vue setup with synthetic framework APIs, no database/network writes.`)
