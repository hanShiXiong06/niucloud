<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,MemberEntitlementDisplayService,EntityMembershipService,Store};
use addon\hsx_lead\app\listener\member\MemberAdminEntitlementDisplay;
use addon\hsx_lead\app\support\Data;
use think\facade\{Cache,Db};
use core\exception\CommonException;

$checks=0;$pdo=null;$schema='';$failed=false;
function mpCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function mpActor(int$site,string$type='site',int$uid=1,int$member=0):void{$p=new ReflectionProperty(app\Request::class,'auth_info');$p->setAccessible(true);$p->setValue(null,['app_type'=>$type,'uid'=>$uid,'member_id'=>$member]);request()->siteId($site);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);mpActor($site);
    Db::name('site')->where('site_id',$site)->update(['addons'=>Data::json(['hsx_lead'])]);Cache::clear();
    leadMembershipSeed($site);$config=ConfigService::defaults();$config['enabled']=true;(new ConfigService(new Context($site,1)))->save($config);
    $addMember=static function(int$id,int$fixtureSite=0)use($site):void{Db::name('member')->insert(['site_id'=>$fixtureSite?:$site,'member_id'=>$id,'member_no'=>'PROJ'.$id,'nickname'=>'Projection '.$id,'mobile'=>sprintf('199%08d',$id),'member_level'=>701]);};
    foreach(range(104,116)as$id)$addMember($id);$addMember(201);
    $makeProfile=static fn(int$id,string$name):array=>(new PartnerService(new Context($site,0,$id)))->saveProfile(['name'=>$name,'contact_name'=>'Owner','mobile'=>sprintf('199%08d',$id),'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);
    $shop=$makeProfile(101,'Shared projection store');$other=$makeProfile(201,'Other projection store');leadSetEntryDefinition($site,702);leadMembershipGrant($site,101,'ML702');
    $link=static function(int$member,int$merchant,string$status='active')use($site):void{Db::name('hsx_lead_merchant_member')->insert(['site_id'=>$site,'merchant_id'=>$merchant,'member_id'=>$member,'status'=>$status,'role'=>'member']);};
    $link(102,(int)$shop['id']);$link(104,(int)$shop['id'],'pending');$link(105,(int)$shop['id'],'removed');
    Db::name('member')->where('member_id',106)->update(['status'=>0]);Db::name('member')->where('member_id',107)->update(['is_del'=>1]);Db::name('member')->where('member_id',108)->update(['delete_time'=>time()]);
    $paused=$makeProfile(109,'Paused projection store');Db::name('hsx_lead_merchant')->where('id',$paused['id'])->update(['status'=>0]);$link(110,(int)$paused['id']);
    $link(111,(int)$shop['id']);$link(111,(int)$paused['id']);
    $conflict=$makeProfile(112,'Conflicting owner');$link(112,(int)$shop['id']);
    $duplicate=$makeProfile(113,'Duplicate owner');$extra=$duplicate;unset($extra['id']);$extra=array_intersect_key($extra,array_flip(['name','contact_name','mobile','province_id','city_id','district_id','address','member_id','status','create_time','update_time']));$extra['site_id']=$site;$extra['member_id']=113;$extra['name']='Second duplicate owner';$extra['subject_code']='';Db::name('hsx_lead_merchant')->insert($extra);
    // Missing partner reads must remain read-only; no Store::partner auto-creation.
    $missingPartner=(int)Db::name('hsx_lead_merchant')->insertGetId(['site_id'=>$site,'member_id'=>114,'name'=>'No partner fixture','mobile'=>'19900000114','status'=>1]);
    $service=new MemberEntitlementDisplayService(new Context($site,1));$partnersBefore=Store::query('partner',$site)->count();$auditBefore=Data::query('audit',$site)->count();$levelsBefore=Db::name('member')->order('member_id')->column('member_level','member_id');$ordersBefore=Store::query('coop_order',$site)->select()->toArray();
    $result=$service->display([101,102,103,104,105,106,107,108,109,110,111,112,113,114,115,116,999999]);$cards=$result['members'];$state=EntityMembershipService::state($site,(int)$shop['id'],['membership_levels'=>\addon\hsx_lead\app\service\cooperation\MembershipCatalogService::levels($site)]);
    mpCheck($result['key']==='hsx_lead_subject'&&$result['title']==='门店会员权益','plugin declares the optional shared-membership display group');
    mpCheck($cards[101]['label']===$state['level_name']&&$cards[101]['status']===$state['display_status']&&$cards[101]['status_text']===$state['display_status_text'],'owner uses exact common receipt-derived name and status');
    mpCheck($cards[102]['label']===$cards[101]['label']&&$cards[102]['expires_at']===$cards[101]['expires_at']&&$cards[102]['status']===$cards[101]['status'],'active staff inherit the same live subject projection, not their personal member level');
    mpCheck(str_contains($cards[101]['context'],'负责人')&&str_contains($cards[102]['context'],'店员'),'shared benefit provenance distinguishes owner and staff');
    foreach([104,105,109,110,115,116]as$id)mpCheck($cards[$id]['status']==='not_joined'&&$cards[$id]['context']==='','pending/removed/paused/unrelated identities do not inherit active rights: '.$id);
    foreach([103,999999]as$id)mpCheck(!isset($cards[$id]),'foreign or absent members never return private plugin cards: '.$id);
    foreach([106,107,108]as$id)mpCheck($cards[$id]['status']==='inactive'&&$cards[$id]['context']===''&&$cards[$id]['expires_at']===0&&!str_contains(json_encode($cards[$id]),'Shared projection store'),'disabled/deleted local accounts report account state without inheriting or disclosing store rights: '.$id);
    mpCheck($cards[106]['label']==='账号已停用'&&$cards[107]['label']==='账号已删除'&&$cards[108]['label']==='账号已删除','account disable/delete is not mislabeled as a membership read failure');
    foreach([111,112,113]as$id)mpCheck($cards[$id]['status']==='review'&&$cards[$id]['context']==='','ambiguous active identity never picks a merchant: '.$id);
    mpCheck($cards[114]['status']==='not_opened'&&str_contains($cards[114]['context'],'No partner fixture'),'valid empty subject has known unopened rights, not unknown read failure');
    mpCheck(Store::query('partner',$site)->count()===$partnersBefore&&!Store::query('partner',$site)->where('merchant_id',$missingPartner)->find(),'list projection does not create a missing partner');
    mpCheck(Db::name('member')->order('member_id')->column('member_level','member_id')===$levelsBefore&&Store::query('coop_order',$site)->select()->toArray()===$ordersBefore&&Data::query('audit',$site)->count()===$auditBefore,'projection never mutates personal levels, order snapshots or audit data');
    mpCheck(array_keys($service->display([115,116])['members'])===[115,116],'a whole unassociated page still receives an explicit not-joined projection');
    $empty=$service->display([]);mpCheck($empty===['key'=>'hsx_lead_subject','title'=>'门店会员权益','members'=>[]],'empty authorized page keeps a stable extension definition');
    $listener=new MemberAdminEntitlementDisplay();mpCheck(isset($listener->handle(['site_id'=>$site,'member_ids'=>[101]])['members'][101]),'registered listener accepts the matching authenticated site administrator');
    mpCheck($listener->handle(['site_id'=>$site+1,'member_ids'=>[101]])===[],'event tenant cannot replace current request tenant');mpActor($site,'api',1,101);mpCheck($listener->handle(['site_id'=>$site,'member_ids'=>[101]])===[],'member API cannot read an administrator extension');mpActor($site,'site',0);mpCheck($listener->handle(['site_id'=>$site,'member_ids'=>[101]])===[],'anonymous request cannot read the extension');mpActor($site);
    Db::name('sys_user')->insert(['uid'=>22,'username'=>'member-only','status'=>1]);Db::name('sys_user_role')->insert(['uid'=>22,'site_id'=>$site,'is_admin'=>0,'status'=>1,'role_ids'=>'[]']);
    mpCheck((new MemberEntitlementDisplayService(new Context($site,22)))->display([101])===[],'official-member visibility alone does not leak separately protected store rights');
    Db::name('sys_menu')->insert(['menu_key'=>'hsx_lead_entity_manage','app_type'=>'site','status'=>1]);Db::name('sys_role')->insert(['role_id'=>222,'site_id'=>$site,'status'=>1,'rules'=>Data::json(['hsx_lead_entity_manage'])]);Db::name('sys_user_role')->where('uid',22)->update(['role_ids'=>'[222]']);
    mpCheck(isset((new MemberEntitlementDisplayService(new Context($site,22)))->display([101])['members'][101]),'existing subject-list read permission suffices without granting write or audit powers');
    Db::name('addon')->where('key','hsx_lead')->update(['status'=>0]);mpCheck($service->display([101])===[],'globally disabled plugin contributes no member data');Db::name('addon')->where('key','hsx_lead')->update(['status'=>1]);
    Db::name('site')->where('site_id',$site)->update(['addons'=>'[]']);Cache::clear();mpCheck($service->display([101])===[],'tenant not subscribed to plugin contributes no store data');Db::name('site')->where('site_id',$site)->update(['addons'=>Data::json(['hsx_lead'])]);Cache::clear();
    $definition=Db::name('member_level')->where('level_id',701)->value('level_benefits');Db::name('member_level')->where('level_id',701)->update(['level_benefits'=>'not-json']);$unknown=$service->display([101,102]);mpCheck($unknown['members'][101]['status']==='unavailable'&&$unknown['members'][102]['status']==='unavailable','a catalog read error never becomes a fake unopened or empty-success membership');mpCheck(!str_contains(json_encode($unknown),'not-json'),'failure cards do not expose raw storage errors');Db::name('member_level')->where('level_id',701)->update(['level_benefits'=>$definition]);
    try{$service->display(range(1000,1500));throw new RuntimeException('Large batch accepted');}catch(CommonException$error){mpCheck(true,'oversized batches fail explicitly instead of silently dropping member IDs');}
    $bulk=[];foreach(range(1000,1099)as$id){$addMember($id);$link($id,(int)$shop['id']);$bulk[]=$id;}
    $database=$app->config->get('database');$database['connections']['mysql']['trigger_sql']=true;$manager=new think\DbManager();$manager->setConfig($database);$app->instance('think\DbManager',$manager);$capturing=false;$queries=[];
    Db::listen(static function($sql,$seconds)use(&$capturing,&$queries):void{if($capturing&&!str_starts_with($sql,'CONNECT:'))$queries[]=$sql;});
    $measure=static function(array$ids)use($service,&$capturing,&$queries):array{$service->display($ids);$queries=[];$capturing=true;try{$rows=$service->display($ids);}finally{$capturing=false;}return[count($queries),$rows];};
    [$small,$smallRows]=$measure(array_slice($bulk,0,10));[$large,$largeRows]=$measure($bulk);mpCheck(count($largeRows['members'])===100&&count($smallRows['members'])===10,'batch projection retains every valid member in the requested page');mpCheck($large===$small&&$large<25,'one shared-store page does not add per-member lookups: '.$small.' vs '.$large);
    $event=require dirname(__DIR__).'/app/event.php';mpCheck(in_array(MemberAdminEntitlementDisplay::class,$event['listen']['MemberAdminEntitlementDisplay'],true),'optional generic event is registered in plugin event dictionary');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'queries_10'=>$small,'queries_100'=>$large,'scope'=>'read-only member-to-subject projection, role/tenant/plugin gates, malformed-data isolation, no partner creation or personal-level mutation; owned random local schema'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
