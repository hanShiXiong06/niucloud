<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
define('HSX_LEAD_RUNTIME_INDEX_LIBRARY_ONLY',true);
require dirname(__DIR__).'/scripts/upgrade-runtime-indexes.php';
use addon\hsx_lead\scripts\RuntimeIndexUpgrade;
use think\facade\Db;
$pdo=null;$schema='';$checks=0;$failed=false;
function riCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function riDeny(callable$fn,string$label):void{try{$fn();}catch(RuntimeException$e){riCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $base=realpath(sys_get_temp_dir()).'/'.$schema.'/index-fixture';$command=new RuntimeIndexUpgrade($base);
    $initial=$command->check();riCheck($initial['pending_statements']===0,'fresh install contains the timeout scan index');
    Db::execute('ALTER TABLE `lt_hsx_lead_coop_order` DROP INDEX `idx_status_expiry`');
    $beforeConfig=Db::name('sys_config')->count();$pending=$command->check();
    riCheck($pending['pending_statements']===1&&!$pending['business_row_writes']&&!$pending['creates_tables']&&!$pending['changes_fields'],'old schema plans one additive index only');
    riCheck(!is_dir($base)&&Db::name('sys_config')->count()===$beforeConfig,'check does not create a backup path or write config');
    riCheck(str_contains($pending['sql'],'ALGORITHM=INPLACE, LOCK=NONE'),'online-only DDL has no silent blocking fallback');
    $now=time();
    for($batch=0;$batch<10;$batch++){
        $rows=[];for($i=1;$i<=200;$i++){$n=$batch*200+$i;$rows[]=['site_id'=>$site,'order_no'=>'INDEX_'.$n,'business_key'=>'index-'.$n,'request_id'=>'index-'.$n,'purpose'=>'membership','merchant_id'=>1,'member_id'=>101,'amount'=>'99.00','status'=>$n<=8?'unpaid':'paid','create_time'=>$now-300,'update_time'=>$now-300];}
        Db::name('hsx_lead_coop_order')->insertAll($rows);
    }
    $before=Db::query('SELECT COUNT(*) AS n,SUM(amount) AS total,SUM(status="unpaid") AS unpaid FROM lt_hsx_lead_coop_order')[0];
    Db::startTrans();try{riDeny(fn()=>$command->apply(),'reject DDL inside a business transaction');}finally{Db::rollback();}
    riCheck($command->check()['pending_statements']===1,'transaction rejection leaves schema unchanged');
    $result=$command->apply();riCheck($result['applied']&&$result['pending_statements']===0,'explicit apply creates and reads back the expected index');
    riCheck(is_file($result['backup'])&&(fileperms($result['backup'])&0777)===0600,'schema-only backup is private');
    $backup=json_decode((string)file_get_contents($result['backup']),true);
    riCheck(isset($backup['create_table'],$backup['indexes'])&&!isset($backup['rows']),'backup records schema/indexes, not customer rows or credentials');
    riCheck(Db::query('SELECT COUNT(*) AS n,SUM(amount) AS total,SUM(status="unpaid") AS unpaid FROM lt_hsx_lead_coop_order')[0]===$before&&Db::name('sys_config')->count()===$beforeConfig,'index upgrade changes neither financial rows nor config');
    riCheck($command->apply()['applied']===false,'repeat apply is idempotent');
    $explain=Db::query('EXPLAIN SELECT site_id FROM lt_hsx_lead_coop_order WHERE status=? AND purpose IN (?,?) AND create_time<=? GROUP BY site_id ORDER BY MIN(update_time) ASC LIMIT 5',['unpaid','membership','commission',$now-120]);
    riCheck(($explain[0]['key']??'')==='idx_status_expiry'&&(int)($explain[0]['rows']??2000)<200,'real timeout query uses targeted index instead of scanning all 2000 orders');
    $indexRows=Db::query('SHOW INDEX FROM `lt_hsx_lead_coop_order`');
    if(array_key_exists('Visible',$indexRows[0])){
        Db::execute('ALTER TABLE `lt_hsx_lead_coop_order` ALTER INDEX `idx_status_expiry` INVISIBLE');
        riDeny(fn()=>$command->check(),'invisible same-name index is not misreported as usable or silently changed');
        Db::execute('ALTER TABLE `lt_hsx_lead_coop_order` ALTER INDEX `idx_status_expiry` VISIBLE');
    }
    Db::execute('ALTER TABLE `lt_hsx_lead_coop_order` DROP INDEX `idx_status_expiry`, ADD INDEX `equivalent_expiry` (`status`,`create_time`,`site_id`,`id`)');
    riCheck($command->check()['pending_statements']===0,'equivalent existing index avoids duplicate storage');
    Db::execute('ALTER TABLE `lt_hsx_lead_coop_order` DROP INDEX `equivalent_expiry`, ADD INDEX `idx_status_expiry` (`status`,`site_id`)');
    riDeny(fn()=>$command->check(),'same index name with a different definition is not overwritten');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'index-only check/apply and real EXPLAIN over 2000 synthetic orders in an owned localhost schema; no original rows or external requests'],JSON_UNESCAPED_UNICODE),PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
