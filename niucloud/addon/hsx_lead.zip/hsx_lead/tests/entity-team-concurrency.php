<?php
declare(strict_types=1);

// Real, independent MySQL connections; only a newly owned random fixture schema.
if (PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true)) exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions\n");
}
if (filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';
require_once dirname(__DIR__,3).'/vendor/autoload.php';

use addon\hsx_lead\app\service\{Context,MerchantService};
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,Store,TeamService};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;

$checks=0;
function teamRaceCheck(bool $condition,string $label): void
{
    if (!$condition) throw new RuntimeException('Assertion failed: '.$label);
    $GLOBALS['checks']++;
}
function teamRaceDenied(callable $action,string $label): void
{
    try {$action();} catch (CommonException $error) {teamRaceCheck(true,$label);return;}
    throw new RuntimeException('Expected rejection: '.$label);
}

/** Private pipe payload only: no credentials in argv, files or child output. */
function teamRaceChild(): void
{
    try {
        $line=fgets(STDIN,131072);
        if (!is_string($line)) throw new RuntimeException('Missing child payload');
        $payload=json_decode($line,true,32,JSON_THROW_ON_ERROR);
        $schema=$payload['schema']??'';$database=$payload['database']??[];$connection=$database['connections']['mysql']??[];
        if (!is_string($schema)||preg_match('/^hsx_lead_test_[a-f0-9]{16}$/D',$schema)!==1
            ||($database['default']??'')!=='mysql'||($connection['hostname']??'')!=='127.0.0.1'
            ||($connection['database']??'')!==$schema||($connection['prefix']??'')!=='lt_'
            ||!empty($connection['deploy'])||!preg_match('/^[0-9]{1,5}$/D',(string)($connection['hostport']??''))
            ||!is_string($payload['auth_key']??null)||preg_match('/^[a-f0-9]{64}$/D',$payload['auth_key'])!==1
            ||!in_array($payload['operation']??'', ['approve','bind','join'],true)
            ||(int)($payload['site']??0)!==900000031) throw new RuntimeException('Unsafe worker configuration');
        $root=dirname(__DIR__,3);$app=new think\App($root);
        require_once $app->getThinkPath().'helper.php';require_once $root.'/app/common.php';
        $app->config->set($database,'database');
        $app->config->set(['default'=>'file','stores'=>['file'=>['type'=>'File','path'=>sys_get_temp_dir().'/'.$schema.'/cache/']]],'cache');
        $app->config->set(['default'=>'file','channels'=>['file'=>['type'=>'File','path'=>sys_get_temp_dir().'/'.$schema.'/log/']]],'log');
        $app->env->set('app.auth_key',$payload['auth_key']);$app->env->set('queue.state',false);
        $app->instance('request',new app\Request());request()->siteId((int)$payload['site']);request()->uid(1);request()->appType('site');
        $manager=new think\DbManager();$manager->setConfig($database);$app->instance('think\DbManager',$manager);
        $GLOBALS['hsx_lead_test_owned_schema']=$schema;leadAssertIsolated($schema);
        $connectionId=(int)Db::query('SELECT CONNECTION_ID() AS id')[0]['id'];
        echo json_encode(['phase'=>'ready','connection_id'=>$connectionId],JSON_THROW_ON_ERROR).PHP_EOL;fflush(STDOUT);
        if (trim((string)fgets(STDIN))!=='GO') throw new RuntimeException('Worker start barrier was not released');
        echo json_encode(['phase'=>'attempting','connection_id'=>$connectionId],JSON_THROW_ON_ERROR).PHP_EOL;fflush(STDOUT);
        try {
            if ($payload['operation']==='approve') {
                (new TeamService(new Context((int)$payload['site'],0,(int)$payload['owner'])))->review((int)$payload['member'],true);
            } elseif($payload['operation']==='join') {
                (new TeamService(new Context((int)$payload['site'],0,(int)$payload['member'])))->join(['subject_code'=>$payload['subject_code']]);
            } else {
                (new MerchantService(new Context((int)$payload['site'],1)))->save((int)$payload['merchant'],$payload['input']);
            }
            $result=['phase'=>'result','operation'=>$payload['operation'],'accepted'=>true,'member'=>(int)$payload['member']];
        } catch(CommonException $error) {
            $result=['phase'=>'result','operation'=>$payload['operation'],'accepted'=>false,'member'=>(int)$payload['member'],'reason'=>$error->getMessage()];
        }
        leadAssertIsolated($schema);unset($GLOBALS['hsx_lead_test_owned_schema']);
        echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL;fflush(STDOUT);
        exit(0); // A child never creates, drops or cleans up the parent's database.
    } catch(Throwable $error) {
        // Do not print arguments or the private transport payload.
        fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);
        exit(2);
    }
}
if (in_array('--team-race-child',$argv,true)) teamRaceChild();

function teamRaceLine(array &$worker): array
{
    $deadline=microtime(true)+15;
    while (microtime(true)<$deadline) {
        $newline=strpos($worker['buffer'],"\n");
        if ($newline!==false) {
            $line=substr($worker['buffer'],0,$newline);$worker['buffer']=substr($worker['buffer'],$newline+1);
            $value=json_decode($line,true,32,JSON_THROW_ON_ERROR);
            if (!is_array($value)) throw new RuntimeException('Invalid worker response');return $value;
        }
        $read=[$worker['pipes'][1]];$write=null;$except=null;
        if (stream_select($read,$write,$except,0,200000)===false) throw new RuntimeException('Worker pipe failed');
        if ($read) {$chunk=fread($worker['pipes'][1],65536);if ($chunk!==false) $worker['buffer'].=$chunk;}
        $status=proc_get_status($worker['process']);
        if (!$status['running']) {
            if ((int)$status['exitcode']>=0) $worker['exitcode']=(int)$status['exitcode'];
            if ($worker['buffer']==='') throw new RuntimeException('Worker exited before response: '.trim((string)stream_get_contents($worker['pipes'][2])));
        }
    }
    throw new RuntimeException('Worker did not reach the bounded barrier');
}

/** Hold the target merchant rows; business workers still use their unmodified site→merchant lock order. */
function teamRacePair($app,PDO $pdo,string $schema,int $site,array $operations,array $barrierMerchants): array
{
    leadAssertIsolated($schema);$children=[];
    try {
        foreach($barrierMerchants as $id)if(!is_int($id)||$id<=0)throw new RuntimeException('Invalid fixture merchant barrier');
        $barrierMerchants=array_values(array_unique($barrierMerchants));sort($barrierMerchants);
        $serverVersion=(string)$pdo->query('SELECT VERSION()')->fetchColumn();
        $engineStatement=$pdo->prepare('SELECT TABLE_NAME,ENGINE FROM information_schema.tables WHERE TABLE_SCHEMA=? AND TABLE_NAME IN (\'lt_site\',\'lt_hsx_lead_merchant\')');$engineStatement->execute([$schema]);$engines=$engineStatement->fetchAll(PDO::FETCH_ASSOC);$engineStatement->closeCursor();
        $pdo->beginTransaction();$statement=$pdo->prepare('SELECT id FROM lt_hsx_lead_merchant WHERE site_id=? AND id IN ('.implode(',',array_fill(0,count($barrierMerchants),'?')).') ORDER BY id FOR UPDATE');$statement->execute(array_merge([$site],$barrierMerchants));
        if (array_map('intval',$statement->fetchAll(PDO::FETCH_COLUMN))!==$barrierMerchants) throw new RuntimeException('Fixture barrier merchants missing');
        $statement->closeCursor();
        foreach($operations as $operation) {
            $pipes=[];$process=proc_open([PHP_BINARY,'-d','error_reporting=22527','-d','allow_url_fopen=0','-d',
                'disable_functions=curl_exec,curl_multi_exec,fsockopen,pfsockopen,stream_socket_client,socket_connect',
                __FILE__,'--isolated-local-mysql','--team-race-child'],[['pipe','r'],['pipe','w'],['pipe','w']],$pipes);
            if (!is_resource($process)) throw new RuntimeException('Cannot create isolated worker');
            foreach([1,2] as $index)stream_set_blocking($pipes[$index],false);
            $worker=['process'=>$process,'pipes'=>$pipes,'buffer'=>''];$children[]=$worker;
            $payload=$operation+['schema'=>$schema,'database'=>$app->config->get('database'),'auth_key'=>(string)$app->env->get('app.auth_key'),'site'=>$site];
            fwrite($pipes[0],json_encode($payload,JSON_THROW_ON_ERROR).PHP_EOL);fflush($pipes[0]);
        }
        $connections=[];
        foreach($children as &$worker) {$ready=teamRaceLine($worker);teamRaceCheck(($ready['phase']??'')==='ready'&&(int)($ready['connection_id']??0)>0,'independent worker reached start barrier');$connections[]=(int)$ready['connection_id'];}unset($worker);
        teamRaceCheck(count(array_unique($connections))===count($operations),'workers use distinct live MySQL connections');
        foreach($children as $worker){fwrite($worker['pipes'][0],"GO\n");fflush($worker['pipes'][0]);}
        foreach($children as &$worker){$attempt=teamRaceLine($worker);teamRaceCheck(($attempt['phase']??'')==='attempting','worker actually attempted its business operation');}unset($worker);
        $deadline=microtime(true)+10;$bothWaiting=false;
        // IDs come only from the two owned workers; no other transaction is read.
        $placeholders=implode(',',array_fill(0,count($connections),'?'));
        // The local MySQL 9.3 server exposes these live waits in performance_schema;
        // information_schema.innodb_trx did not expose them during the held barrier.
        $inspect=$pdo->prepare('SELECT COUNT(DISTINCT t.PROCESSLIST_ID) FROM performance_schema.data_lock_waits w JOIN performance_schema.threads t ON t.THREAD_ID=w.REQUESTING_THREAD_ID WHERE t.PROCESSLIST_ID IN ('.$placeholders.')');
        while(microtime(true)<$deadline){$inspect->execute($connections);if((int)$inspect->fetchColumn()===count($connections)){$bothWaiting=true;break;}usleep(20000);}
        if (!$bothWaiting) {
            // Bounded, credential-free diagnostics for only these owned connections/processes.
            $inspectStates=$pdo->prepare('SELECT trx_mysql_thread_id AS connection_id,trx_state AS state,trx_operation_state AS operation_state FROM information_schema.innodb_trx WHERE trx_mysql_thread_id IN ('.$placeholders.')');
            $inspectStates->execute($connections);$transactions=$inspectStates->fetchAll(PDO::FETCH_ASSOC);
            $inspectProcesses=$pdo->prepare('SELECT ID AS connection_id,COMMAND AS command,STATE AS state,INFO AS statement_text FROM information_schema.processlist WHERE ID IN ('.$placeholders.')');
            $inspectProcesses->execute($connections);$processes=$inspectProcesses->fetchAll(PDO::FETCH_ASSOC);
            foreach($processes as &$process) {
                $sql=(string)($process['statement_text']??'');unset($process['statement_text']);
                preg_match('/^\s*([A-Za-z]+)/',$sql,$keyword);preg_match_all('/\b(?:FROM|JOIN|UPDATE|INTO|TABLE)\s+`?(lt_[A-Za-z0-9_]+)`?/i',$sql,$tables);
                $process['statement_keyword']=strtoupper($keyword[1]??'UNKNOWN');$process['fixture_tables']=array_values(array_unique($tables[1]??[]));
                // No SQL literals, bindings, SQL text or non-fixture table names leave this block.
            }unset($process);
            $inspectStates->closeCursor();$inspectProcesses->closeCursor();
            $workers=[];
            foreach($children as &$worker) {
                $status=proc_get_status($worker['process']);if(!$status['running']&&(int)$status['exitcode']>=0)$worker['exitcode']=(int)$status['exitcode'];
                $worker['buffer'].=(string)stream_get_contents($worker['pipes'][1]);$errorText=(string)stream_get_contents($worker['pipes'][2]);
                $responses=[];
                foreach(explode("\n",$worker['buffer']) as $line){$value=json_decode($line,true);if(is_array($value))$responses[]=array_intersect_key($value,array_flip(['phase','operation','accepted','member']));}
                preg_match('/^([A-Za-z_\\\\][A-Za-z0-9_\\\\]*):/',$errorText,$errorClass);
                preg_match('/ @ ([A-Za-z0-9_.-]+):([0-9]+)/',$errorText,$errorLocation);
                $workers[]=['running'=>(bool)$status['running'],'exitcode'=>$worker['exitcode']??null,'responses'=>$responses,'stderr_present'=>$errorText!=='','error_class'=>$errorClass[1]??'','error_file'=>$errorLocation[1]??'','error_line'=>(int)($errorLocation[2]??0)];
            }unset($worker);
            fwrite(STDERR,json_encode(['barrier_diagnostics'=>['server_version'=>$serverVersion,'fixture_engines'=>$engines,'workers'=>$workers,'owned_transactions'=>$transactions,'owned_processes'=>$processes]],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL);
        }
        teamRaceCheck($bothWaiting,'both processes concurrently wait on the same real transaction barrier');
        $pdo->commit();$results=[];
        foreach($children as &$worker){$result=teamRaceLine($worker);teamRaceCheck(($result['phase']??'')==='result'&&is_bool($result['accepted']??null),'worker returned explicit committed or rejected result');$results[]=$result;fclose($worker['pipes'][0]);$worker['pipes'][0]=null;$errors=stream_get_contents($worker['pipes'][2]);fclose($worker['pipes'][1]);fclose($worker['pipes'][2]);$worker['pipes'][1]=$worker['pipes'][2]=null;$exit=proc_close($worker['process']);if($exit===-1&&isset($worker['exitcode']))$exit=$worker['exitcode'];$worker['process']=null;teamRaceCheck($exit===0&&$errors==='','worker exited cleanly without hidden warnings');}unset($worker);
        return $results;
    } finally {
        if ($pdo->inTransaction()) $pdo->rollBack();
        foreach($children as $worker){foreach($worker['pipes'] as $pipe)if(is_resource($pipe))fclose($pipe);if(is_resource($worker['process'])){proc_terminate($worker['process']);proc_close($worker['process']);}}
    }
}

$pdo=null;$schema='';$failed=false;
try {
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    leadMembershipSeed($site);
    $admin=new Context($site,1);$owner=new Context($site,0,101);
    foreach([104,105,106,107] as $id)Db::name('member')->insert(['site_id'=>$site,'member_id'=>$id,'nickname'=>'Race fixture '.$id,'mobile'=>'19900000'.$id]);
    $config=ConfigService::defaults();$config['enabled']=true;(new ConfigService($admin))->save($config);
    $profileInput=['name'=>'Race subject A','contact_name'=>'Race owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic fixture street'];
    $subject=(new PartnerService($owner))->saveProfile($profileInput);$merchant=(int)$subject['id'];$team=new TeamService($owner);$code=$team->summary()['subject_code'];
    leadSetEntryDefinition($site,702);$partner=Store::partner($site,$merchant);leadMembershipGrant($site,101,'ML702');
    foreach([102,104] as $member)(new TeamService(new Context($site,0,$member)))->join(['subject_code'=>$code]);
    teamRaceCheck($team->summary()['membership']['used_accounts']===1&&$team->summary()['pending_count']===2,'V2 has its owner and two pending applicants for one remaining slot');
    $outcomes=teamRacePair($app,$pdo,$schema,$site,[['operation'=>'approve','owner'=>101,'member'=>102],['operation'=>'approve','owner'=>101,'member'=>104]],[$merchant]);
    $accepted=array_values(array_filter($outcomes,static fn(array $result):bool=>$result['accepted']));$rejected=array_values(array_filter($outcomes,static fn(array $result):bool=>!$result['accepted']));
    if(count($accepted)!==1||count($rejected)!==1)fwrite(STDERR,json_encode(['race_outcome_diagnostics'=>$outcomes,'fixture_links'=>Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->field('member_id,status')->select()->toArray()],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL);
    teamRaceCheck(count($accepted)===1&&count($rejected)===1,'concurrent approvals commit exactly one member');
    teamRaceCheck(str_contains($rejected[0]['reason']??'','名额'),'losing approval fails for the real seat limit, not a generic race error');
    $summary=$team->summary();teamRaceCheck($summary['membership']['used_accounts']===2&&$summary['pending_count']===1,'V2 remains exactly two used accounts and one pending request');
    $loser=(int)$rejected[0]['member'];teamRaceCheck(Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('merchant_id',$merchant)->where('member_id',$loser)->value('status')==='pending','losing application stays pending rather than silently removed');

    // Race an owner's approval against the real existing administrative binding path.
    leadSetEntryDefinition($site,703);leadMembershipGrant($site,101,'ML703');
    $other=(new PartnerService(new Context($site,0,105)))->saveProfile(array_replace($profileInput,['name'=>'Race subject B','mobile'=>'19900000105']));$otherId=(int)$other['id'];
    (new TeamService(new Context($site,0,106)))->join(['subject_code'=>$code]);
    $bindInput=array_replace($profileInput,['name'=>'Race subject B','mobile'=>'19900000105','member_id'=>106,'status'=>1]);
    teamRaceDenied(fn()=>(new MerchantService($admin))->save(0,$bindInput),'pending applicant cannot be bound as a new subject owner');
    $bindingRace=teamRacePair($app,$pdo,$schema,$site,[['operation'=>'approve','owner'=>101,'member'=>106],['operation'=>'bind','merchant'=>$otherId,'member'=>106,'input'=>$bindInput]],[$merchant,$otherId]);
    $byOperation=array_column($bindingRace,null,'operation');
    teamRaceCheck($byOperation['approve']['accepted']&&!$byOperation['bind']['accepted'],'approval wins membership while concurrent administrator binding is denied in either ordering');
    teamRaceCheck((int)Data::query('merchant',$site)->where('id',$otherId)->value('member_id')===105,'failed admin binding leaves the original responsible owner unchanged');
    teamRaceCheck(Data::query('merchant',$site)->where('member_id',106)->count()===0&&Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('member_id',106)->where('status','active')->count()===1,'applicant has one active subject and no new owner identity');
    teamRaceCheck((int)(new Context($site,0,106))->merchant()['id']===$merchant,'post-race identity resolves only to subject A');
    teamRaceDenied(fn()=>(new MerchantService($admin))->save(0,$bindInput),'active member cannot be rebound through a fresh admin merchant');
    teamRaceDenied(fn()=>(new MerchantService($admin))->save($merchant,array_replace($profileInput,['member_id'=>107])),'existing paid/multi-member subject cannot replace its owner by ordinary editing');

    $newBindingInput=array_replace($bindInput,['member_id'=>107]);
    $newIdentityRace=teamRacePair($app,$pdo,$schema,$site,[['operation'=>'join','member'=>107,'subject_code'=>$code],['operation'=>'bind','merchant'=>$otherId,'member'=>107,'input'=>$newBindingInput]],[$merchant,$otherId]);
    teamRaceCheck(count(array_filter($newIdentityRace,static fn(array $result):bool=>$result['accepted']))===1,'new join and administrator owner binding commit exactly one competing identity');
    $ownedCount=(int)Data::query('merchant',$site)->where('member_id',107)->count();
    $linkedCount=(int)Db::name('hsx_lead_merchant_member')->where('site_id',$site)->where('member_id',107)->whereIn('status',['pending','active'])->count();
    teamRaceCheck($ownedCount+$linkedCount===1&&$ownedCount<=1&&$linkedCount<=1,'new applicant cannot become both a subject owner and a pending/active member in another subject');
    $identity=TeamService::resolve(new Context($site,0,107),false);
    if($ownedCount)teamRaceCheck($identity&&$identity['is_owner']&&(int)$identity['id']===$otherId,'owner-binding winner resolves only to subject B');
    else teamRaceCheck($identity===null&&(new TeamService(new Context($site,0,107)))->pending()['merchant_id']===$merchant,'join winner remains pending in subject A without acquiring owner rights');

    // Deliberately inconsistent fixture rows must fail closed, not prefer an owner silently.
    $otherOwner=(int)Data::query('merchant',$site)->where('id',$otherId)->value('member_id');
    Data::query('merchant',$site)->where('id',$otherId)->update(['member_id'=>106]);
    teamRaceDenied(fn()=>(new Context($site,0,106))->merchant(),'conflicting owned and active-member subjects fail closed');
    Data::query('merchant',$site)->where('id',$otherId)->update(['member_id'=>$otherOwner]);
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'independent_worker_pairs'=>3,'mysql_lock_waits_verified'=>6,'scope'=>'Actual plugin services and two independent PHP/MySQL workers in newly owned localhost schema; no existing business rows, payment or external network'],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL;
} catch(Throwable $error) {
    $failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);
} finally {
    if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);
}
if($failed)exit(1);
