<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions before isolated testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';
define('HSX_LEAD_CATALOG_RESET_LIBRARY_ONLY', true);
require dirname(__DIR__) . '/scripts/reset-business-catalogs.php';

use addon\hsx_lead\scripts\BusinessCatalogResetCommand as Command;
use addon\hsx_lead\app\service\cooperation\ConfigService;
use app\service\core\sys\CoreConfigService;
use think\facade\{Cache, Db};

$checks = 0; $failed = false; $pdo = null; $schema = ''; $backend = ''; $testTrigger = false;
function resetCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function resetReject(callable $operation, string $label): void
{
    try { $operation(); }
    catch (RuntimeException $error) { resetCheck(true, $label); return; }
    throw new RuntimeException('Expected refusal: ' . $label);
}
function resetTree(string $path): array
{
    if (!is_dir($path)) return [];
    $files = [];
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $entry) {
        if ($entry->isFile()) $files[] = $entry->getPathname();
    }
    sort($files);
    return $files;
}

try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    $seed = tempnam(sys_get_temp_dir(), 'hsx_lead_catalog_reset_test_');
    if ($seed === false || !unlink($seed) || !mkdir($seed, 0700) || !mkdir($seed . '/runtime', 0700)) throw new RuntimeException('Cannot prepare owned private test directory');
    $backend = realpath($seed);
    $now = time();
    $encode = static fn($value): string => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);
    $writeRaw = static function (int $tenant, string $key, string $value) use ($pdo, $now): void {
        $statement = $pdo->prepare('INSERT INTO `lt_sys_config` (`site_id`,`config_key`,`value`,`status`,`create_time`,`update_time`) VALUES (?,?,?,?,?,?)');
        $statement->execute([$tenant, $key, $value, 1, $now - 100, $now - 50]);
    };
    $configs = static function (?int $tenant = null) use ($pdo): array {
        $statement = $pdo->prepare('SELECT * FROM `lt_sys_config`' . ($tenant === null ? '' : ' WHERE site_id=?') . ' ORDER BY site_id,config_key,id');
        $statement->execute($tenant === null ? [] : [$tenant]);
        return $statement->fetchAll(PDO::FETCH_ASSOC);
    };
    $rawCooperation = ConfigService::defaults();
    $rawCooperation['enabled'] = true; $rawCooperation['fee_confirmed'] = true;
    foreach ($rawCooperation['businesses'] as &$business) $business['options'] = [[
        'id' => 'fixture_' . $business['key'], 'title' => '待清空目录_' . $business['key'],
        'brand' => 'Fixture brand', 'category_name' => 'Fixture category', 'path' => ['Fixture category', $business['key']], 'aliases' => [],
    ]];
    unset($business);
    $rawCooperation['private_unknown_extension'] = (object)['preserve_empty_object' => new stdClass(), 'preserve_zero_float' => 1.0, 'nested' => ['unchanged', (object)['a' => false]]];
    $rawCooperation['membership_marker'] = ['price' => '199.00', 'deposit' => '299.00'];
    $originalCooperation = $encode($rawCooperation);
    $originalDemand = ' { "items": [{"id":"source_fixture","title":"ERP_IMPORTED_FIXTURE","brand":"source","category_name":"source category"}], "updated_at": 123, "private_extension": {"empty":{},"fraction":1.0} } ';
    $writeRaw($site, Command::COOPERATION_KEY, $originalCooperation);
    $writeRaw($site, Command::DEMAND_KEY, $originalDemand);
    $writeRaw($site, 'HSX_LEAD_CAPABILITY_77', '{"models":[{"id":"source_fixture","title":"历史商户能力"}],"other":"preserve"}');
    $writeRaw($site, 'HSX_LEAD_PROMOTION', '{"sources":{"membership_service":{"enabled":true}}}');
    $writeRaw($site + 1, Command::COOPERATION_KEY, $originalCooperation);
    $writeRaw($site + 1, Command::DEMAND_KEY, $originalDemand);
    $beforeAll = $configs(); $beforeTarget = $configs($site);
    $beforeForeign = $configs($site + 1);
    $targetBeforeByKey = array_column($beforeTarget, null, 'config_key');
    $insert = static fn(string $table, array $row): int => (int) Db::name('hsx_lead_' . $table)->insertGetId(['site_id' => $site, 'create_time' => $now, 'update_time' => $now] + $row);
    $merchant = $insert('merchant', ['name' => 'Preserved fixture merchant', 'member_id' => 101]);
    $connection = $insert('connection', ['merchant_id' => $merchant, 'provider' => 'soujike', 'enabled' => 1]);
    $run = $insert('sync_run', ['merchant_id' => $merchant, 'connection_id' => $connection, 'config_version' => 1, 'status' => 'completed']);
    Db::name('hsx_lead_connection')->where('id', $connection)->update(['published_run_id' => $run]);
    $insert('inventory', ['merchant_id' => $merchant, 'connection_id' => $connection, 'sync_run_id' => $run, 'source_key' => 'reset-preserve-stock', 'model' => 'ERP fixture phone', 'brand' => 'ERP fixture brand', 'snapshot_json' => '{"source_category":"preserve audit snapshot"}']);
    $insert('collaboration', ['lead_no' => 'LC-RESET-FIXTURE', 'publisher_id' => $merchant, 'request_id' => 'reset-preserve-lead', 'models_json' => '[{"id":"old-model","title":"历史型号"}]', 'rule_json' => '{"fee_percent":"10.00","fee_minimum":"9.90"}']);
    $businessSnapshot = static function (): array {
        $out = [];
        foreach (['merchant', 'connection', 'sync_run', 'inventory', 'collaboration'] as $table) $out[$table] = Db::name('hsx_lead_' . $table)->order('id')->select()->toArray();
        return $out;
    };
    $beforeBusiness = $businessSnapshot();
    $keys = ['site_config_cache' . Command::DEMAND_KEY . '_' . $site, 'site_config_cache' . Command::COOPERATION_KEY . '_' . $site];
    foreach ($keys as $key) Cache::set($key, ['stale' => true]);
    $unrelatedCache = 'site_config_cacheHSX_LEAD_PROMOTION_' . $site;
    $foreignCache = 'site_config_cache' . Command::DEMAND_KEY . '_' . ($site + 1);
    Cache::set($unrelatedCache, 'keep current tenant unrelated cache');
    Cache::set($foreignCache, 'keep foreign tenant cache');
    $evictions = [];
    $evict = static function (string $key) use (&$evictions): void { $evictions[] = $key; Cache::delete($key); };
    $command = new Command($pdo, 'lt_', $backend, $evict);

    resetCheck(Command::arguments(['--site=' . $site]) === ['site' => $site, 'mode' => 'check', 'local_only' => false], 'CLI defaults to read-only check and requires an explicit site');
    resetReject(fn() => Command::arguments([]), 'no implicit all-site reset');
    resetReject(fn() => Command::arguments(['--site=' . $site, '--site=' . ($site + 1)]), 'duplicate site arguments refused');
    $check = $command->check($site);
    resetCheck($check['can_apply'] === true && $check['mode'] === 'check' && $check['database_writes'] === 0, 'check reports a valid plan without database writes');
    resetCheck($check['saved_business_options'] === 7 && $check['saved_shared_options'] === 1 && $check['configuration_changes'] === 2, 'check identifies all seven businesses and shared directory');
    resetCheck($configs() === $beforeAll && !$pdo->inTransaction(), 'check leaves every config row byte-for-byte unchanged and closes its transaction');
    resetCheck(!is_dir($backend . '/runtime/hsx_lead_catalog_reset') && $command->backup === '' && resetTree($backend) === [], 'check does not create a backup directory or file');
    resetCheck($evictions === [] && Cache::get($keys[0]) === ['stale' => true], 'check never clears caches');

    $result = $command->apply($site);
    resetCheck($result['mode'] === 'complete' && $result['data_committed'] === true && $command->committed === true && $result['database_writes'] === 2, 'apply commits exactly the two directory config rows');
    resetCheck(!$result['schema_changes'] && !$result['inventory_writes'] && !$result['business_record_writes'] && !$result['external_calls'], 'receipt explicitly limits reset scope');
    $afterByKey = array_column($configs($site), null, 'config_key');
    $afterCooperation = json_decode($afterByKey[Command::COOPERATION_KEY]['value']);
    $expectedCooperation = json_decode($originalCooperation);
    foreach ($expectedCooperation->businesses as $business) $business->options = [];
    resetCheck($afterCooperation == $expectedCooperation, 'apply preserves every non-options cooperation value including opaque object extensions');
    foreach ($afterCooperation->businesses as $business) resetCheck($business->options === [], $business->key . ' directory is explicitly empty');
    $afterDemand = json_decode($afterByKey[Command::DEMAND_KEY]['value']);
    $expectedDemand = json_decode($originalDemand); $expectedDemand->items = []; $expectedDemand->updated_at = $afterDemand->updated_at;
    resetCheck($afterDemand == $expectedDemand && is_int($afterDemand->updated_at), 'shared items clear without discarding unknown demand config keys');
    foreach ([Command::COOPERATION_KEY, Command::DEMAND_KEY] as $key) {
        foreach ($targetBeforeByKey[$key] as $field => $value) if (!in_array($field, ['value', 'update_time'], true)) resetCheck($afterByKey[$key][$field] === $value, $key . ' preserves row metadata ' . $field);
    }
    resetCheck($afterByKey['HSX_LEAD_CAPABILITY_77'] === $targetBeforeByKey['HSX_LEAD_CAPABILITY_77'], 'merchant capability config remains byte-for-byte unchanged');
    resetCheck($afterByKey['HSX_LEAD_PROMOTION'] === $targetBeforeByKey['HSX_LEAD_PROMOTION'], 'promotion rules are not rewritten');
    resetCheck($configs($site + 1) === $beforeForeign, 'other tenant config values and metadata remain unchanged');
    resetCheck($businessSnapshot() === $beforeBusiness, 'stock, source generations, merchants and historic lead/fee snapshots remain byte-for-byte unchanged');
    resetCheck($evictions === [$keys[0], $keys[1], $keys[0], $keys[1]], 'only the two exact target cache keys are deleted before and after commit');
    resetCheck(Cache::get($unrelatedCache) === 'keep current tenant unrelated cache' && Cache::get($foreignCache) === 'keep foreign tenant cache', 'cache eviction leaves other settings and tenants intact');
    resetCheck((new CoreConfigService())->getConfigValue($site, Command::DEMAND_KEY)['items'] === [], 'framework read after reset does not return the stale shared directory');
    resetCheck(array_column((new CoreConfigService())->getConfigValue($site, Command::COOPERATION_KEY)['businesses'], 'options') === array_fill(0, 7, []), 'framework read after reset does not return stale business options');

    $backup = $command->backup;
    $backupValue = json_decode((string) file_get_contents($backup), true, 512, JSON_THROW_ON_ERROR);
    $backupRows = array_column($backupValue['rows'], null, 'config_key');
    resetCheck($backupValue['schema'] === 'hsx_lead.catalog_reset.v1' && $backupValue['site_id'] === $site, 'backup records its schema and exact target site');
    resetCheck($backupRows[Command::COOPERATION_KEY] === $targetBeforeByKey[Command::COOPERATION_KEY] && $backupRows[Command::DEMAND_KEY] === $targetBeforeByKey[Command::DEMAND_KEY], 'backup preserves exact original rows and raw JSON strings for restoration');
    clearstatcache();
    resetCheck((fileperms($backup) & 0777) === 0600 && (fileperms(dirname($backup)) & 0777) === 0700 && (fileperms(dirname($backup, 2)) & 0777) === 0700, 'backup JSON is private 0600 inside private 0700 directories');
    $afterFirst = $configs();
    $again = new Command($pdo, 'lt_', $backend, $evict);
    $repeat = $again->apply($site);
    resetCheck($repeat['database_writes'] === 0 && $repeat['data_committed'] === true && $configs() === $afterFirst, 'repeated apply does not rewrite empty data or metadata');
    resetCheck($again->backup !== $backup && is_file($again->backup), 'repeat still retains an independent before-state backup');

    $noConfigSite = $site + 2;
    Db::name('site')->insert(['site_id' => $noConfigSite, 'site_name' => 'No config fixture', 'app_type' => 'site', 'app' => '["hsx_lead"]', 'addons' => '[]', 'group_id' => 0]);
    $guard = new Command($pdo, 'lt_', $backend, $evict);
    $noConfigBefore = $configs(); $backupsBefore = resetTree($backend); $evictionsBefore = $evictions;
    resetCheck($guard->check($noConfigSite)['can_apply'] === false, 'check refuses to manufacture a default cooperation config');
    resetReject(fn() => $guard->apply($noConfigSite), 'apply refuses a site with no saved cooperation config');
    resetCheck($configs() === $noConfigBefore && resetTree($backend) === $backupsBefore && $evictions === $evictionsBefore, 'missing config refusal writes no data, cache or backup');

    $updateCooperation = static function (string $value) use ($pdo, $site): void {
        $statement = $pdo->prepare('UPDATE `lt_sys_config` SET `value`=? WHERE `site_id`=? AND `config_key`=?');
        $statement->execute([$value, $site, Command::COOPERATION_KEY]);
    };
    $malformed = ['{invalid', '[]', '{"businesses":{}}', '{"businesses":[{"key":"purchase","options":{}}]}', '{"businesses":[{"key":"purchase","options":[]},{"key":"purchase","options":[]}]}'];
    foreach ($malformed as $index => $value) {
        $updateCooperation($value);
        $beforeBad = $configs(); $badBackups = resetTree($backend); $badEvictions = $evictions;
        $bad = new Command($pdo, 'lt_', $backend, $evict);
        resetReject(fn() => $bad->check($site), 'malformed config check refuses fixture ' . $index);
        resetReject(fn() => $bad->apply($site), 'malformed config apply refuses fixture ' . $index);
        resetCheck($configs() === $beforeBad && resetTree($backend) === $badBackups && $evictions === $badEvictions && !$pdo->inTransaction(), 'malformed fixture ' . $index . ' has no partial writes or backup');
    }
    $updateCooperation($afterByKey[Command::COOPERATION_KEY]['value']);
    $deleteDemand = $pdo->prepare('DELETE FROM `lt_sys_config` WHERE site_id=? AND config_key=?');
    $deleteDemand->execute([$site, Command::DEMAND_KEY]);
    Cache::delete($keys[0]);
    $withoutShared = new Command($pdo, 'lt_', $backend, $evict);
    resetCheck($withoutShared->check($site)['configuration_changes'] === 1, 'missing shared catalog plans one explicit empty insert, not inventory fallback');
    $missingResult = $withoutShared->apply($site);
    resetCheck($missingResult['database_writes'] === 1 && (new CoreConfigService())->getConfigValue($site, Command::DEMAND_KEY)['items'] === [], 'apply creates only an explicit empty shared catalog when absent');
    resetCheck($businessSnapshot() === $beforeBusiness && $configs($site + 1) === $beforeForeign, 'all refusal and absent-shared cases still preserve stock, history and foreign tenant');

    $restoreFixture = static function () use ($pdo, $site, $originalCooperation, $originalDemand): void {
        $statement = $pdo->prepare('UPDATE `lt_sys_config` SET `value`=? WHERE `site_id`=? AND `config_key`=?');
        foreach ([Command::COOPERATION_KEY => $originalCooperation, Command::DEMAND_KEY => $originalDemand] as $key => $value) $statement->execute([$value, $site, $key]);
    };
    $restoreFixture();
    $rollbackBefore = $configs();
    // This trigger lives only in the test-owned random schema and is removed
    // before the next case (or in finally). It fails the second planned write,
    // after the first cooperation config update has genuinely executed.
    $pdo->exec("CREATE TRIGGER `lt_catalog_reset_reject_fixture` BEFORE UPDATE ON `lt_sys_config` FOR EACH ROW BEGIN IF NEW.config_key='HSX_LEAD_DEMAND_CATALOG' AND NEW.site_id=" . $site . " THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Synthetic second-config-write failure'; END IF; END");
    $testTrigger = true;
    $writeFailure = new Command($pdo, 'lt_', $backend, $evict);
    resetReject(fn() => $writeFailure->apply($site), 'actual second config UPDATE failure is reported');
    resetCheck($configs() === $rollbackBefore && !$writeFailure->committed && !$pdo->inTransaction(), 'second config write failure rolls back both target rows and all metadata');
    resetCheck(is_file($writeFailure->backup), 'second-write rollback retains its original private backup');
    $pdo->exec('DROP TRIGGER `lt_catalog_reset_reject_fixture`'); $testTrigger = false;

    $restoreFixture();
    $preCommitBefore = $configs();
    $beforeCommitCacheFailure = new Command($pdo, 'lt_', $backend, static function (string $key): void {
        throw new RuntimeException('Synthetic pre-commit cache eviction failure');
    });
    resetReject(fn() => $beforeCommitCacheFailure->apply($site), 'cache exception before mutation is reported');
    resetCheck($configs() === $preCommitBefore && !$beforeCommitCacheFailure->committed && !$pdo->inTransaction(), 'pre-commit cache failure leaves both rows and transaction state unchanged');
    resetCheck(is_file($beforeCommitCacheFailure->backup), 'pre-commit cache failure occurs only after a recoverable before-state backup');

    $restoreFixture();
    $postCommitBefore = $configs(); $cacheAttempts = 0;
    $afterCommitCacheFailure = new Command($pdo, 'lt_', $backend, static function (string $key) use (&$cacheAttempts): void {
        $cacheAttempts++;
        if ($cacheAttempts === 3) throw new RuntimeException('Synthetic post-commit cache eviction failure');
        Cache::delete($key);
    });
    resetReject(fn() => $afterCommitCacheFailure->apply($site), 'post-commit cache exception is reported rather than hidden');
    resetCheck($afterCommitCacheFailure->committed && !$pdo->inTransaction() && $cacheAttempts === 3, 'post-commit cache failure explicitly retains committed state, never claims rollback');
    $postCommitAfter = array_column($configs($site), null, 'config_key');
    $postCommitRows = [$postCommitAfter[Command::COOPERATION_KEY], $postCommitAfter[Command::DEMAND_KEY]];
    resetCheck(Command::prepare($postCommitRows, time())['changes'] === [] && $configs() !== $postCommitBefore, 'both directories really remain empty after the committed cache failure');
    resetCheck(is_file($afterCommitCacheFailure->backup) && $businessSnapshot() === $beforeBusiness && $configs($site + 1) === $beforeForeign, 'post-commit failure retains backup and cannot affect stock, history or another tenant');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => 'actual reset command; owned random localhost schema and private temporary backups only', 'remote_calls' => 0], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true;
    fwrite(STDERR, 'FAIL catalog reset command: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    if ($pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    if ($pdo instanceof PDO && $testTrigger) $pdo->exec('DROP TRIGGER IF EXISTS `lt_catalog_reset_reject_fixture`');
    if ($pdo instanceof PDO && $schema !== '') {
        try { leadCleanup($pdo, $schema); }
        catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL owned schema cleanup\n"); }
    }
    if ($backend !== '' && str_starts_with(basename($backend), 'hsx_lead_catalog_reset_test_') && is_dir($backend)) {
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($backend, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
            if ($entry->isDir() && !$entry->isLink()) rmdir($entry->getPathname()); else unlink($entry->getPathname());
        }
        rmdir($backend);
    }
}
exit($failed ? 1 : 0);
