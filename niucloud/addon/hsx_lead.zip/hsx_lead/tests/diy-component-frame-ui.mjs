import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Real wrapper setups and rendered styles. No live API, saved DIY or browser writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),dom=require('@vue/compiler-dom'),ts=require('typescript')
const {renderToString}=require('@vue/server-renderer')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
function instance(file){
    const source=fs.readFileSync(path.join(plugin,file),'utf8'),parsed=sfc.parse(source,{filename:file})
    assert.deepEqual(parsed.errors,[]);checks++
    const script=sfc.compileScript(parsed.descriptor,{id:'native-frame'})
    assert.deepEqual(sfc.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'native-frame',compilerOptions:{bindingMetadata:script.bindings}}).errors,[]);checks++
    const store=Vue.reactive({mode:'',value:[]}),component=Vue.reactive({title:'可配置区块',showTitle:1,componentStartBgColor:'#fff',componentEndBgColor:'',topRounded:0,bottomRounded:0})
    const context={displayable:Vue.ref(true),preview:Vue.ref(false),displayProfile:Vue.ref({id:7,name:'Synthetic shop'}),displayMember:Vue.ref({member_no:'SYNTHETIC-UID',nickname:'合成会员'}),displayConfig:Vue.ref({}),action(){}}
    const module={exports:{}},code=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{String,Number,Object,Array,Math})(key=>{
        if(key==='vue')return{...Vue,onMounted(){}}
        if(key==='@/app/stores/diy')return{default:()=>store}
        if(key==='@/utils/common')return{img:value=>'resolved:'+value}
        if(key.includes('/utils/'))return loadMobileUtility(path.basename(key))
        if(key.endsWith('/useProfileDiy'))return{useProfileDiyContext:()=>context}
        if(key.endsWith('.vue'))return{default:{}}
        if(key.endsWith('.png'))return{default:'/bundled.png'}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    const state=module.exports.default.setup(Vue.reactive({component,index:0,global:{},kind:'identity'}),{emit(){},expose(){}})
    const render=new Function('Vue',dom.compile(parsed.descriptor.template.content,{mode:'function',prefixIdentifiers:true}).code)(Vue)
    // A separately compiled function template uses _ctx, while compileScript's
    // non-enumerable __isScriptSetup flag hides its bindings from public _ctx.
    // Spreading preserves the actual computed/ref getters without that flag.
    async function html(){const app=Vue.createSSRApp({setup:()=>({...state}),render});app.config.warnHandler=()=>{};for(const name of ['CoopProfilePanel','CoopBusinessNavigation','CoopBusinessIcon','u-icon'])app.component(name,{render:()=>Vue.h('span')});return renderToString(app)}
    return{state,component,store,html}
}
for(const file of ['uni-app/components/diy/lead-cooperation-entry/index.vue','uni-app/components/diy/lead-business-navigation/index.vue','uni-app/components/cooperation/CoopProfileDiySection.vue']){
    const f=instance(file),style=()=>f.state.frame.value.style,mask=()=>f.state.frame.value.mask
    check(style().background==='#fff'&&!f.state.frame.value.hasImage,file+' applies a configured solid background')
    f.component.componentEndBgColor='#ddeeff';f.component.componentGradientAngle='to right'
    check(style().background==='linear-gradient(to right,#fff,#ddeeff)',file+' uses both native gradient colors and direction')
    f.component.componentEndBgColor=''
    check(style().background==='#fff',file+' clearing only gradient end restores solid start color')
    f.component.componentEndBgColor='#ddeeff'
    f.component.componentBgUrl='header.png';f.component.componentBgAlpha=4;f.component.topRounded=8;f.component.bottomRounded=12
    check(style().backgroundImage==="url('resolved:header.png')"&&style().backgroundSize==='cover',file+' resolves the native component background image')
    check(style().borderTopLeftRadius==='16rpx'&&style().borderBottomRightRadius==='24rpx',file+' independently consumes native top/bottom corners')
    check(mask().backgroundColor==='rgba(0,0,0,0.4)'&&mask().pointerEvents==='none'&&mask().height==='100%',file+' mask fills the actual component without intercepting actions')
    const rendered=await f.html()
    check(rendered.includes('background-image:url(&#39;resolved:header.png&#39;)')||rendered.includes("background-image:url('resolved:header.png')"),file+' actual rendered outer wrapper contains its image')
    check(rendered.includes('pointer-events:none')&&rendered.includes('position:relative'),file+' actual rendered mask and positioning reach the output')
    f.component.componentBgAlpha=99;check(mask().backgroundColor==='rgba(0,0,0,1)',file+' alpha is bounded above')
    f.component.componentBgAlpha=-1;check(mask().backgroundColor==='rgba(0,0,0,0)',file+' alpha is bounded below')
    const clearMask=await f.html()
    check(clearMask.includes('rgba(0,0,0,0)')&&clearMask.includes('pointer-events:none'),file+' zero-alpha mask is still nonintercepting in rendered output')
    f.component.componentBgUrl='';f.component.componentStartBgColor='';f.component.componentEndBgColor='';f.component.topRounded=0;f.component.bottomRounded=0
    check(!f.state.frame.value.hasImage&&!('backgroundImage'in style())&&style().background===undefined&&style().borderTopLeftRadius==='0rpx',file+' clearing native settings exposes the page without stale image/corners')
    const cleared=await f.html()
    check(!cleared.includes('resolved:header.png')&&!cleared.includes('pointer-events:none'),file+' rendered wrapper removes prior image and obsolete mask after live clear')
    f.component.componentStartBgColor='transparent'
    check(style().background==='transparent',file+' intentional transparent background is not replaced by a fallback color')
    check(!Object.keys(style()).some(key=>key.startsWith('margin')),file+' leaves margins to the framework group exactly once')
    f.store.mode='decorate';f.store.value=[{...f.component,componentStartBgColor:'#112233'}]
    check(style().background==='#112233',file+' live editor changes are applied by the real wrapper')
}
const helper=loadMobileUtility('cooperation-diy-frame')
check(helper.cooperationDiyFrame({componentBgUrl:'',componentBgAlpha:10}).hasImage===false,'alpha alone never creates an input-blocking overlay')
const escaped=helper.cooperationDiyFrame({componentBgUrl:"x');color:red;/*\n.png"}).style.backgroundImage
check(escaped==="url('x\\');color:red;/*.png')",'malformed image path remains quoted and escaped inside the single CSS URL, with control newlines stripped')
check(helper.cooperationDiyFrame({componentBgUrl:'saved.png'},()=>null).hasImage===false,'invalid framework image resolution produces no image or mask')
for(const file of ['uni-app/components/diy/lead-cooperation-entry/index.vue','uni-app/components/diy/lead-business-navigation/index.vue']){
    const source=fs.readFileSync(path.join(plugin,file),'utf8')
    check(/function refresh\(\)/.test(source)&&source.includes('defineExpose({refresh})'),'native uni transformer receives named exposed refresh in '+file)
}
console.log(`PASS ${checks} native component frame checks; three real Vue setups and rendered outer styles, no API/database or saved-layout writes.`)
