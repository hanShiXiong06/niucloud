<?php
declare(strict_types=1);
// Independent red/green financial review. Disposable local schema; no live funds.
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityMembershipService,EntityExperienceService,MembershipCostService,MembershipDepositService,PartnerService,PaymentService,Store};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use addon\hsx_lead\app\listener\pay\MembershipRefundSuccess;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function lrCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['pay','pay_refund']as$table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match);if(empty($match[0]))throw new RuntimeException('Missing checked-in payment fixture DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));}
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2,false,['deposit_amount'=>'100.00'])+['site_id'=>$site]);
    $config=ConfigService::defaults();$config['enabled']=true;$config['publishing_required']=true;$config['fee_confirmed']=true;(new ConfigService(new Context($site,1)))->save($config);
    $owner=102;$ctx=new Context($site,0,$owner);$profile=(new PartnerService($ctx))->saveProfile(['name'=>'Late receipt synthetic merchant','contact_name'=>'Fixture owner','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);$merchant=(int)$profile['id'];
    $service=new EntityMembershipService($ctx);$payments=new PaymentService($ctx);$deposits=new MembershipDepositService($ctx);
    $make=static function(string$request)use($service,$payments):array{$quote=$service->quote('ML701','month');if(!$quote['can_purchase'])throw new RuntimeException('Setup quote refused: '.$quote['reason']);return$payments->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'month','request_id'=>$request,'quote_token'=>$quote['quote_token']]);};
    $receipt=static function(array$order,string$number)use($site,$owner):array{Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>$owner,'from_main_id'=>$owner,'out_trade_no'=>$number,'money'=>$order['amount'],'status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);return['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$number];};
    $initial=$make('late-review-original');PaymentService::confirm($receipt($initial,'LATE_REVIEW_ORIGINAL'));$before=$service->summary();
    lrCheck($before['active']&&MembershipCostService::balances($site,$merchant)['balance']==='100.00','fixture opening confirms original held deposit');
    $late=$make('late-review-renewal');$service->closeUnpaid((int)$late['id']);lrCheck(Store::row('coop_order',$site,(int)$late['id'])['status']==='closed','fixture renewal has a confirmed local closure, not unpaid state');
    lrCheck($deposits->summary()['can_apply']&&$service->quote('ML701','month')['can_purchase'],'ordinary confirmed closure without actual money is not a financial-review block');
    // Model a contradictory, genuine-status provider receipt arriving after closure.
    $event=$receipt($late,'LATE_REVIEW_CONTRADICTORY');
    lrCheck(!$deposits->summary()['can_apply']&&!$service->quote('ML701','month')['can_purchase'],'matching finished receipt blocks deposit exit and new charges even before its business callback');
    $message='';try{PaymentService::confirm($event);}catch(CommonException$error){$message=$error->getMessage();}
    $saved=Store::row('coop_order',$site,(int)$late['id']);$rule=Data::decode($saved['rule_json']);$deposit=$deposits->summary();$next=$service->quote('ML701','month');$after=$service->summary();
    echo json_encode(['case'=>'closed_order_real_status_late_receipt','order_status'=>$saved['status'],'manual_review'=>!empty($rule['requires_manual_review']),'confirm_message'=>$message,'deposit_can_apply'=>$deposit['can_apply'],'quote_can_purchase'=>$next['can_purchase'],'entitlement_unchanged'=>$before['expires_at']===$after['expires_at'],'actual_gateway_calls'=>0],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
    lrCheck($before['expires_at']===$after['expires_at'],'late contradictory receipt cannot automatically extend or grant membership');
    lrCheck(MembershipCostService::balances($site,$merchant)['balance']==='100.00'&&EntityExperienceService::summary($site,$merchant)['purchased_value']==='0.00','late contradictory receipt creates neither held deposit nor purchased experience');
    lrCheck(!empty($rule['requires_manual_review']),'a verified collected receipt after closure must persist an explicit reconciliation marker');
    lrCheck(!$deposit['can_apply'],'unreconciled actual money prevents deposit exit until financial review');
    lrCheck(!$next['can_purchase'],'unreconciled actual money prevents fresh membership charges');
    try{PaymentService::confirm($event);}catch(CommonException$ignored){}
    lrCheck($service->summary()['expires_at']===$before['expires_at'],'late callback replay never creates a new grant');
    $replayed=Data::decode(Store::row('coop_order',$site,(int)$late['id'])['rule_json']);lrCheck(count($replayed['closed_payment_receipts']??[])===1&&Db::name('hsx_lead_audit')->where('site_id',$site)->where('entity_id',$late['id'])->where('action','closed_membership_receipt_review')->count()===1,'same late receipt replay retains one reconciliation source and one audit event');
    $wrong=$event;$wrong['site_id']=$site+1;$denied=false;try{PaymentService::confirm($wrong);}catch(CommonException$expected){$denied=true;}lrCheck($denied,'same numeric order id cannot consume another tenant receipt');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'LATE_UNRELATED','out_trade_no'=>'SOME_OTHER_PAYMENT','money'=>$late['amount'],'status'=>RefundDict::SUCCESS]);
    lrCheck(!$deposits->summary()['can_apply'],'a different payment full refund cannot resolve this closed receipt');
    $waitId=(int)Db::name('pay_refund')->insertGetId(['site_id'=>$site,'refund_no'=>'LATE_UNKNOWN','out_trade_no'=>$event['out_trade_no'],'money'=>$late['amount'],'status'=>RefundDict::WAIT]);
    lrCheck(!$service->quote('ML701','month')['can_purchase'],'unknown refund result never releases the financial lock');Db::name('pay_refund')->where('id',$waitId)->update(['status'=>RefundDict::CANCEL]);
    $part=['site_id'=>$site,'refund_no'=>'LATE_PARTIAL','out_trade_no'=>$event['out_trade_no'],'money'=>'9.00','status'=>RefundDict::SUCCESS,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$late['id']];Db::name('pay_refund')->insert($part);
    $listener=new MembershipRefundSuccess();$listener->handle(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'refund_no'=>'LATE_PARTIAL']);
    lrCheck(!$deposits->summary()['can_apply']&&!$service->quote('ML701','month')['can_purchase'],'a verified partial refund stays under financial review');
    Db::name('pay_refund')->insert($part);$actualReceipt=Db::name('pay')->where('site_id',$site)->where('out_trade_no',$event['out_trade_no'])->find();$partResult=MembershipCostService::receiptRefund($site,Store::row('coop_order',$site,(int)$late['id']),$actualReceipt);
    lrCheck(!$partResult['full']&&$partResult['amount']==='9.00','duplicate rows for one successful refund number cannot manufacture a full refund');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'LATE_REMAINDER','out_trade_no'=>$event['out_trade_no'],'money'=>'10.00','status'=>RefundDict::SUCCESS,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$late['id']]);
    lrCheck($deposits->summary()['can_apply']&&$service->quote('ML701','month')['can_purchase'],'a complete verified original refund removes the cash lock even before its business refund callback');
    $refundEvent=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'refund_no'=>'LATE_REMAINDER'];$listener->handle($refundEvent);
    $resolved=Store::row('coop_order',$site,(int)$late['id']);$resolvedRule=Data::decode($resolved['rule_json']);
    lrCheck($resolved['status']==='closed'&&empty($resolvedRule['requires_manual_review'])&&($resolvedRule['closed_payment_refund_status']??'')==='refunded','successful full refund resolves only the new closed-receipt exception without changing the closed trade');
    lrCheck(($resolvedRule['closed_payment_receipts'][$event['out_trade_no']]['resolved_refund']['amount']??'')===$late['amount'],'resolved exception retains the exact original successful refund proof');
    lrCheck($service->summary()['expires_at']===$before['expires_at']&&MembershipCostService::balances($site,$merchant)['balance']==='100.00'&&EntityExperienceService::summary($site,$merchant)['purchased_value']==='0.00','closed purchase refund neither grants membership nor changes the other held deposit or experience');
    $listener->handle($refundEvent);PaymentService::confirm($event);
    $afterReplay=Data::decode(Store::row('coop_order',$site,(int)$late['id'])['rule_json']);
    lrCheck(empty($afterReplay['requires_manual_review'])&&Db::name('hsx_lead_audit')->where('site_id',$site)->where('entity_id',$late['id'])->where('action','closed_membership_receipt_refunded')->count()===1,'refund-success and late-payment callback replays cannot re-freeze or double-resolve the refunded exception');
    echo json_encode(['case'=>'closed_late_receipt_refund_resolved','order_status'=>$resolved['status'],'manual_review'=>!empty($afterReplay['requires_manual_review']),'deposit_can_apply'=>$deposits->summary()['can_apply'],'quote_can_purchase'=>$service->quote('ML701','month')['can_purchase'],'actual_gateway_calls'=>0],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES).PHP_EOL;
    leadAssertIsolated($schema);echo 'PASS '.$checks." late-membership-receipt reconciliation checks; synthetic receipts, disposable local schema, no gateway.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
