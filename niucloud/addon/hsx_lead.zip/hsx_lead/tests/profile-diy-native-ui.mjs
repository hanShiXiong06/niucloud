import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Execute actual component style getters with synthetic data. No browser,
// member API, database, saved layout, or external request is used.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),root=path.resolve(plugin,'../../..')
const require=createRequire(path.join(root,'uni-app/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0
const equal=(actual,expected,label)=>{assert.deepEqual(actual,expected,label);checks++}
const check=(value,label)=>{assert.ok(value,label);checks++}
const file=path.join(plugin,'uni-app/components/cooperation/CoopProfileDiySection.vue'),parsed=compiler.parse(fs.readFileSync(file,'utf8'),{filename:file})
equal(parsed.errors.length,0,'business section parses')
const script=compiler.compileScript(parsed.descriptor,{id:'native-profile'})
equal(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'native-profile',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length,0,'business section template compiles')
const store=Vue.reactive({mode:'',value:[]}),context={displayable:Vue.ref(true),preview:Vue.ref(false)},module={exports:{}}
const deps={vue:Vue,'@/app/stores/diy':{default:()=>store},'@/utils/common':{img:value=>'local-assets/'+value},'../../composables/useProfileDiy':{useProfileDiyContext:()=>context},'../../utils/cooperation-diy-style':loadMobileUtility('cooperation-diy-style'),'../../utils/cooperation-diy-frame':loadMobileUtility('cooperation-diy-frame'),'./CoopProfilePanel.vue':{default:{}}}
const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Object,Number,String,Math})(key=>{if(!(key in deps))throw Error('Unexpected dependency '+key);return deps[key]},module,module.exports)
const component=Vue.reactive({title:'门店',componentStartBgColor:'#fff',componentEndBgColor:'',componentGradientAngle:'to right',topRounded:0,bottomRounded:0,textColor:'#123',showFeedback:1})
const state=module.exports.default.setup(Vue.reactive({component,index:0,kind:'identity',global:{}}),{expose(){},emit(){}})
equal(state.componentStyle.value.background,'#fff','standard single background is applied')
equal(state.componentStyle.value.color,'var(--lead-diy-text)','body inherits the shared actual render contract')
equal(state.componentStyle.value['--lead-diy-text'],'#123','configured body text is applied through the shared variable')
equal(state.componentStyle.value.borderTopLeftRadius,'0rpx','zero radius is respected')
component.topRounded=8;component.bottomRounded=12
equal(state.componentStyle.value.borderTopRightRadius,'16rpx','top radius follows native px-to-rpx convention')
equal(state.componentStyle.value.borderBottomLeftRadius,'24rpx','bottom radius is independent')
component.componentEndBgColor='#eee'
equal(state.componentStyle.value.background,'linear-gradient(to right,#fff,#eee)','native gradient settings are applied')
component.componentBgUrl='store.png';component.componentBgAlpha=4
equal(state.componentStyle.value.backgroundImage,"url('local-assets/store.png')",'standard background image uses framework img helper')
equal(state.maskStyle.value.backgroundColor,'rgba(0,0,0,0.4)','standard image mask transparency is applied')
component.componentBgAlpha=99;equal(state.maskStyle.value.backgroundColor,'rgba(0,0,0,1)','mask upper bound is finite')
component.componentBgAlpha=-3;equal(state.maskStyle.value.backgroundColor,'rgba(0,0,0,0)','mask lower bound is finite')
component.componentBgUrl='';check(!('backgroundImage' in state.componentStyle.value),'clearing image removes its style')
component.componentStartBgColor='';equal(state.componentStyle.value.background,undefined,'clearing background exposes the native page background')
store.mode='decorate';store.value=[{...component,title:'实时预览',componentStartBgColor:'#aabbcc',componentEndBgColor:'',topRounded:3}];context.preview.value=true
equal(state.settings.value.title,'实时预览','decorator uses the live framework store')
equal(state.componentStyle.value.background,'#aabbcc','live decorator background is applied')
equal(state.componentStyle.value.borderTopLeftRadius,'6rpx','live decorator radius is applied')
store.value[0].textColor='#654321';store.value[0].contentPadding=21;store.value[0].rowGap=7;store.value[0].title='自定义现场标题'
equal(state.settings.value.title,'自定义现场标题','title edits render from the same framework reactive component')
equal(state.componentStyle.value['--lead-diy-text'],'#654321','text color edits immediately reach render variables')
equal(state.componentStyle.value['--lead-diy-content-padding'],'21px','spacing edits immediately reach render variables')
equal(state.componentStyle.value['--lead-diy-row-gap'],'7px','entry-gap edits immediately reach render variables')
equal(component.textColor,'#123','preview edits do not overwrite props or saved source configuration')
equal(state.resolvedAppearance.value.showFeedback,0,'preview cannot mount local preference writes')
check(!parsed.descriptor.template.content.includes('__wallet')&&!parsed.descriptor.template.content.includes('__demo-note'),'section has neither a duplicate wallet link nor repeated explanatory paragraph')
const panel=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopProfilePanel.vue'),'utf8')
check(panel.includes('v-if="hasConfiguredTools" class="coop-profile-tools"')&&/hasOwnProperty\.call\(props\.appearance,\s*key\)/.test(panel),'ordinary tools follow the saved presentation switches rather than being removed unconditionally')
check(panel.includes('background:var(--lead-diy-panel,transparent)')&&panel.includes('cooperationDiyVars(props.appearance)'),'inner business cards honor configured presentation rather than painting a fixed brand skin')
const editor=fs.readFileSync(path.join(plugin,'admin/views/diy/components/ProfileSectionEditor.vue'),'utf8')
check(editor.includes('<DiyAppearanceFields :allow-border="false"')&&editor.includes('<slot name="style" />')&&!editor.includes('editComponent.layout'),'shared appearance retains native style slot and does not invent outlines on borderless personal-centre cards')
const emits=[]
const tools=module.exports.default.setup(Vue.reactive({component:{showNotice:0,showFeedback:0,showProfile:0,showCapability:0,showInventory:0,showConnection:0,showMembers:0},index:1,kind:'tools',global:{}}),{expose(){},emit:(...args)=>emits.push(args)})
store.mode='';check(tools.componentVisible.value===false,'tools without any enabled action are hidden rather than rendering an empty card')
check(emits.some(args=>args[0]==='update:componentIsShow'),'visibility reports to the standard framework wrapper')
const legacy=module.exports.default.setup(Vue.reactive({component:{showNotice:0,showFeedback:0},index:2,kind:'tools',global:{}}),{expose(){},emit(){}})
check(legacy.componentVisible.value===true,'legacy missing ordinary-tool flags keep the same reachable entries as the actual child renderer')
context.displayable.value=false;check(legacy.componentVisible.value===false,'legacy presentation cannot bypass business context visibility')
const sourceLocale=JSON.parse(fs.readFileSync(path.join(root,'admin/src/app/lang/zh-cn/diy.member.json'),'utf8'))
for(const locale of ['zh-cn','en']){
    const localized=JSON.parse(fs.readFileSync(path.join(plugin,'admin/lang',locale,'cooperation.profile-home-page.json'),'utf8'))
    for(const key of Object.keys(sourceLocale))check(typeof localized[key]==='string'&&localized[key].length>0,'reused manager has route-scoped translation: '+locale+'/'+key)
}
console.log(`PASS ${checks} native DIY style, navigation and localization checks; actual component getters, synthetic state only.`)
