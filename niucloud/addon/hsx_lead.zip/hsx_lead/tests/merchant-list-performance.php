<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true)) exit("isolated CLI only\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $fn) {
    if(function_exists($fn)) exit("network functions must be disabled\n");
}
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)) exit("allow_url_fopen must be off\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';

use addon\hsx_lead\app\service\{CatalogConfigStorage,CatalogService,Context,MerchantService};
use addon\hsx_lead\app\service\cooperation\{ConfigService,Store};
use addon\hsx_lead\app\support\{Cipher,Data,SyncStatus};
use think\facade\Db;

$pdo=null;$schema='';$checks=0;$capture=false;$queries=[];$exitCode=0;
function merchantListCheck(bool $ok,string $message):void
{
    global $checks;if(!$ok) throw new RuntimeException($message);$checks++;
}
function merchantListConfig(int $site,string $key,array $value):void
{
    Db::transaction(static function()use($site,$key,$value):void {
        Db::name('site')->where('site_id',$site)->lock(true)->field('site_id')->find();
        CatalogConfigStorage::write($site,$key,$value);
    });
}
function merchantListMeasure(callable $work):array
{
    global $capture,$queries;
    $work();$queries=[];$capture=true;$start=hrtime(true);
    try{$result=$work();}finally{$capture=false;}
    $families=[];foreach($queries as $family)$families[$family]=($families[$family]??0)+1;ksort($families);
    return ['queries'=>count($queries),'wall_ms'=>round((hrtime(true)-$start)/1e6,3),'families'=>$families,
        'response_json_bytes'=>strlen(json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))];
}
try {
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $ctx=new Context($site,1);$service=new MerchantService($ctx);$now=time();
    $config=ConfigService::defaults();$config['enabled']=true;$config['publishing_required']=false;
    $items=[];
    for($i=1;$i<=845;$i++) $items[]=['id'=>'fixture_model_'.$i,'title'=>'Synthetic model '.$i,'brand'=>'Synthetic brand',
        'category_name'=>'Phones','path'=>['Phones','Synthetic brand','Synthetic model '.$i],'aliases'=>[]];
    foreach($config['businesses'] as &$business) if($business['dimension']==='model') {$business['options']=$items;$business['catalog_configured']=true;}unset($business);
    merchantListConfig($site,ConfigService::KEY,$config);merchantListConfig($site,CatalogService::KEY,['items'=>$items,'updated_at'=>$now]);
    leadMembershipSeed($site);$ids=[];$connections=[];
    for($i=1;$i<=125;$i++) {
        $owner=1000+$i;
        Db::name('member')->insert(['site_id'=>$site,'member_id'=>$owner,'nickname'=>'Synthetic member '.$i,'status'=>$i===5?0:1]);
        $id=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'member_id'=>$owner,'name'=>'Synthetic merchant '.$i,
            'contact_name'=>'Synthetic operator','mobile'=>'19900001000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,
            'status'=>$i===4?0:1,'create_time'=>$now,'update_time'=>$now]);$ids[$i]=$id;
        if($i!==8) Store::partner($site,$id);
        if(in_array($i,[1,120],true)) {
            $models=array_map(static fn(array $item):array=>$item+['dimension'=>'model'],$items);
            merchantListConfig($site,'HSX_LEAD_CAPABILITY_'.$id,['business_capabilities'=>[
                ['business_type'=>'purchase','option_ids'=>array_column($models,'id'),'items'=>$models],
                ['business_type'=>'broadband','option_ids'=>['wrong_dimension'],'items'=>[['id'=>'wrong_dimension','dimension'=>'model']]],
            ]]);
        }
        if($i>=120) {
            $status=[120=>'completed',121=>'running',122=>'failed',123=>'completed',124=>'running',125=>'idle'][$i];
            $cid=(int)Data::query('connection',$site)->insertGetId(['site_id'=>$site,'merchant_id'=>$id,'provider'=>'wanji','enabled'=>$i===123?0:1,
                'last_sync_status'=>$status,'last_sync_at'=>$now,'create_time'=>$now,'update_time'=>$now]);
            Data::query('connection',$site)->where('id',$cid)->update(['credentials_cipher'=>$i===125?'invalid-cipher':Cipher::encrypt(['access_token'=>'synthetic-not-real-token','expires_at'=>$now+3600],$site,$cid)]);
            $run=(int)Data::query('sync_run',$site)->insertGetId(['site_id'=>$site,'merchant_id'=>$id,'connection_id'=>$cid,'config_version'=>$i===123?2:1,
                'status'=>$status==='running'?'running':($status==='failed'?'failed':'completed'),'page_count'=>1,'record_count'=>9,
                'started_at'=>$now,'finished_at'=>$status==='running'?0:$now,'create_time'=>$now,'update_time'=>$now]);
            Data::query('connection',$site)->where('id',$cid)->update(['published_run_id'=>in_array($i,[120,123],true)?$run:0,
                'active_run_id'=>$i===121?$run:($i===124?99999999:0)]);
            $connections[$i]=['id'=>$cid,'run'=>$run];
        }
    }
    // A different tenant is never pulled into the summary, count or ready filter.
    Data::query('merchant',$site+1)->insert(['site_id'=>$site+1,'member_id'=>103,'name'=>'Foreign synthetic merchant','status'=>1]);
    leadMembershipGrant($site,1120,'ML701');leadMembershipGrant($site,1121,'ML701');
    foreach([
        ['valid',[]],['valid_second',[]],['off_shelf',['source_status_json'=>Data::json(['_inventory'=>['listing_status'=>'unlisted','stock_status'=>'in_stock','sale_state'=>'unsold']])]],
        ['sold',['source_status_json'=>Data::json(['_inventory'=>['listing_status'=>'listed','stock_status'=>'in_stock','sale_state'=>'sold']])]],
        ['zero',['saleable_quantity'=>'0.000']],['unknown',['availability'=>'unknown']],['old',['fetched_at'=>$now-48*3600]],
        ['unpublished',['sync_run_id'=>99999999]],
    ] as [$key,$replace]) {
        Data::query('inventory',$site)->insert(array_replace(['site_id'=>$site,'merchant_id'=>$ids[120],'connection_id'=>$connections[120]['id'],
            'sync_run_id'=>$connections[120]['run'],'source_key'=>$key,'brand'=>'Synthetic brand','model'=>'Synthetic model 1',
            'quantity'=>'1.000','saleable_quantity'=>'1.000','availability'=>'available','fetched_at'=>$now,
            'source_status_json'=>Data::json(['_inventory'=>['listing_status'=>'listed','stock_status'=>'in_stock','sale_state'=>'unsold']]),
            'create_time'=>$now,'update_time'=>$now],$replace));
    }
    // The fallback must choose MAX(id), not an arbitrary grouped history row.
    Data::query('sync_run',$site)->insert(['site_id'=>$site,'merchant_id'=>$ids[122],'connection_id'=>$connections[122]['id'],
        'config_version'=>1,'status'=>'failed','page_count'=>2,'record_count'=>11,'error_code'=>'http_error',
        'started_at'=>$now,'finished_at'=>$now,'create_time'=>$now,'update_time'=>$now]);
    // A run pointer cannot borrow a different merchant's otherwise valid run.
    Data::query('connection',$site)->where('id',$connections[124]['id'])->update(['active_run_id'=>$connections[121]['run']]);
    $rows=Data::query('connection',$site)->select()->toArray();$batch=SyncStatus::connections($site,$rows);
    foreach($rows as $row) merchantListCheck($batch[(int)$row['id']]===SyncStatus::connection($site,$row),'batched sync projection differs from authoritative single connection');
    $page=$service->lists(['page'=>1,'limit'=>20,'ready_state'=>'']);
    merchantListCheck($page['total']===125&&count($page['data'])===20,'ordinary list must paginate in SQL and stay tenant scoped');
    merchantListCheck(!isset($page['business_definitions']),'ordinary list must not return the whole directory');
    $fields=['region_text','member_name','ready_state','ready_reason','inventory_count','manual_model_count','business_capability_count',
        'capability_source','membership','membership_active','membership_rank','display_rank','all_models','can_collaborate','can_publish','can_accept','can_view_inventory',
        'provider','provider_name','connection_id','sync_interval_minutes','sync_enabled','auth_renewal','channel_enabled','channel_message','last_sync_status','last_sync_at','last_sync_message','last_run_id','published_run_id'];
    foreach($page['data'] as $summary) {
        $detail=$service->detail((int)$summary['id']);
        foreach($fields as $field) merchantListCheck($summary[$field]===$detail[$field],'list/detail differs on '.$field);
        merchantListCheck(!array_intersect(['manual_models','business_definitions','service_areas'],array_keys($summary)),'summary must not include detail-only payload');
        foreach($summary['business_capabilities'] as $entry) merchantListCheck(!array_intersect(['items','option_ids'],array_keys($entry))&&isset($entry['option_count']),'capability summary leaks full selections');
    }
    $byId=array_column($page['data'],null,'id');
    merchantListCheck($byId[$ids[120]]['inventory_count']===2,'SQL inventory count must retain all eligibility/freshness/generation conditions');
    merchantListCheck($byId[$ids[120]]['business_capability_count']===845&&count($byId[$ids[120]]['business_capabilities'])===1,'summary must preserve capability dimension checks');
    $ready=$service->lists(['ready_state'=>'ready','limit'=>1,'page'=>2]);
    merchantListCheck($ready['total']===2&&count($ready['data'])===1&&(int)$ready['data'][0]['id']===$ids[1],'ready filter must evaluate the entire scope before pagination across batches');
    merchantListCheck(!Store::query('partner',$site)->where('merchant_id',$ids[8])->find(),'list read must not lazily insert missing partner rows');
    $definitions=$service->lists(['definitions'=>1]);
    merchantListCheck(count($definitions['business_definitions'][0]['options'])===845&&!isset($definitions['data']),'new-merchant editor must load definitions independently on demand');
    $detail=$service->detail($ids[120]);
    merchantListCheck(count($detail['manual_models'])===845&&count($detail['business_definitions'][0]['options'])===845,'detail/edit payload must remain complete');
    merchantListCheck($service->lists(['provider'=>'wanji'])['total']===6,'provider filtering must precede summaries');
    merchantListCheck($service->lists(['keyword'=>'Foreign synthetic'])['total']===0,'keyword filter must not broaden tenant scope');
    $denied=false;try{(new MerchantService(new Context($site,0,101)))->lists(['definitions'=>1]);}catch(\core\exception\CommonException $e){$denied=true;}
    merchantListCheck($denied,'directory branch must preserve administrator authorization');
    $capabilityKey='HSX_LEAD_CAPABILITY_'.$ids[120];
    merchantListCheck(CatalogConfigStorage::readMany($site,[$capabilityKey])[$capabilityKey]===CatalogConfigStorage::read($site,$capabilityKey),'batch storage must return identical verified chunked payload');
    merchantListCheck(CatalogConfigStorage::readMany($site+1,[$capabilityKey])[$capabilityKey]===[],'batch storage must never reuse another tenant configuration');
    $duplicate=(int)Db::name('sys_config')->insertGetId(['site_id'=>$site,'config_key'=>$capabilityKey,'value'=>'{}']);
    try {
        $denied=false;try{CatalogConfigStorage::readMany($site,[$capabilityKey]);}catch(\core\exception\CommonException $e){$denied=true;}
        merchantListCheck($denied,'batch storage must fail closed on duplicate base keys');
    } finally {Db::name('sys_config')->where('site_id',$site)->where('id',$duplicate)->delete();}
    $manifest=json_decode((string)Db::name('sys_config')->where('site_id',$site)->where('config_key',$capabilityKey)->value('value'),true);
    merchantListCheck(isset($manifest['row_ids'][0]),'large capability fixture must exercise fragment reconstruction');
    $partId=(int)$manifest['row_ids'][0];$original=(string)Db::name('sys_config')->where('site_id',$site)->where('id',$partId)->value('value');
    try {
        $part=json_decode($original,true);$part['generation']='wrong-generation';
        Db::name('sys_config')->where('site_id',$site)->where('id',$partId)->update(['value'=>Data::json($part)]);
        $denied=false;try{CatalogConfigStorage::readMany($site,[$capabilityKey]);}catch(\core\exception\CommonException $e){$denied=true;}
        merchantListCheck($denied,'batch storage must fail closed on mismatched fragment generation');
    } finally {Db::name('sys_config')->where('site_id',$site)->where('id',$partId)->update(['value'=>$original]);}
    // Rebuild only the random-schema manager for redacted SQL-family measurements.
    $database=$app->config->get('database');$database['connections']['mysql']['trigger_sql']=true;
    $manager=new think\DbManager();$manager->setConfig($database);$app->instance('think\DbManager',$manager);
    Db::listen(static function($sql,$seconds)use(&$capture,&$queries):void {
        if(!$capture||str_starts_with($sql,'CONNECT:'))return;
        $family='other';
        if(preg_match('/^(START|COMMIT|ROLLBACK|SAVEPOINT|RELEASE)/i',ltrim($sql),$m))$family='transaction_'.strtolower($m[1]);
        elseif(preg_match('/^SHOW/i',ltrim($sql)))$family='metadata';
        elseif(preg_match('/(?:FROM|JOIN)\s+`lt_([a-z0-9_]+)`/i',$sql,$m))$family=$m[1];
        $queries[]=$family;
    });
    $present=new ReflectionMethod($service,'present');$present->setAccessible(true);
    $getDefinitions=new ReflectionMethod($service,'businessDefinitions');$getDefinitions->setAccessible(true);
    $baseline=static function()use($service,$site,$present,$getDefinitions):array {
        $result=Data::page(Data::query('merchant',$site),['limit'=>20]);
        $result['data']=array_map(static fn(array $row):array=>$present->invoke($service,$row),$result['data']);
        $result['business_definitions']=$getDefinitions->invoke($service);return $result;
    };
    $before=merchantListMeasure($baseline);$after=merchantListMeasure(static fn():array=>$service->lists(['limit'=>20,'ready_state'=>'']));
    merchantListCheck($after['queries']<$before['queries']/2,'batched list must materially reduce query count');
    merchantListCheck($after['response_json_bytes']<$before['response_json_bytes']/4,'summary list must materially reduce response payload');
    merchantListCheck(($after['families']['sys_area']??0)===1,'page must load region names in one query');
    merchantListCheck(($after['families']['member']??0)===1,'page must load member names/states in one query');
    merchantListCheck(($after['families']['hsx_lead_inventory']??0)===1,'page must aggregate eligible inventory once');
    leadAssertIsolated($schema);
    echo json_encode(['checks'=>$checks,'synthetic_fixture'=>['merchants'=>125,'directory_items'=>845],'baseline'=>$before,'optimized'=>$after],JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
} catch(Throwable $error) {
    fwrite(STDERR,'MERCHANT_LIST_FAILED '.get_class($error).' code='.$error->getCode().' message='.$error->getMessage()."\n");$exitCode=1;
} finally {
    if($pdo instanceof PDO&&$schema!==''&&($GLOBALS['hsx_lead_test_owned_schema']??'')===$schema) {
        leadCleanup($pdo,$schema);fwrite(STDERR,"CLEANUP_CONFIRMED random owned test schema dropped\n");
    }
}
exit($exitCode);
