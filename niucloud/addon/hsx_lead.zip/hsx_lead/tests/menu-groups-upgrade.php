<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql; only its own random local schema is written.\n");
require __DIR__ . '/bootstrap.php';
define('HSX_LEAD_MENU_GROUPS_LIBRARY_ONLY', true);
require dirname(__DIR__) . '/scripts/upgrade-menu-groups.php';
use addon\hsx_lead\scripts\MenuGroupsUpgrade;
use addon\hsx_lead\scripts\UpgradeCommand;
use app\service\admin\sys\MenuService;
use app\service\admin\sys\RoleService;
use app\service\core\menu\CoreMenuService;
use think\facade\Db;
$checks=0;
function groupAssert(bool $ok,string $label):void {global$checks;if(!$ok)throw new RuntimeException($label);$checks++;echo '[PASS] '.$label.PHP_EOL;}
function groupKeys(array $nodes):array {$keys=[];foreach($nodes as$node){$keys[]=$node['menu_key'];$keys=array_merge($keys,groupKeys($node['children']??[]));}return$keys;}
function groupRules(int$id):array {return json_decode((string)Db::name('sys_role')->where('role_id',$id)->value('rules'),true,512,JSON_THROW_ON_ERROR);}
function groupApi(array$rules):array {$raw=(new MenuService())->getApiListByMenuKeys($rules,'site');$result=[];foreach($raw as$method=>$routes){$routes=array_values(array_unique(array_filter($routes,static fn($route)=>$route!=='')));sort($routes);if($method!==''&&$routes)$result[$method]=$routes;}ksort($result);return[$result];}
function groupSnapshot():array {$data=[];foreach(['sys_menu'=>'id','sys_role'=>'role_id','site'=>'site_id','sys_config'=>'id','member'=>'member_id','sys_notice'=>'id','sys_schedule'=>'id']as$table=>$pk)$data[$table]=Db::name($table)->order($pk)->select()->toArray();return$data;}
$pdo=null;$schema='';$fixture='';
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    Db::name('site')->whereIn('site_id',[$site,$site+1])->update(['addons'=>'["hsx_lead"]']);
    $fixture=rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema.'/menu-groups';mkdir($fixture,0700,true);
    $plugin=dirname(__DIR__);$groups=array_keys(require $plugin.'/app/dict/menu/site-groups.php');
    $flat=(new CoreMenuService())->loadMenu(require $plugin.'/app/dict/menu/site.php','site','hsx_lead');
    foreach($flat as$row){if(in_array($row['menu_key'],$groups,true))continue;if(in_array($row['parent_key'],$groups,true))$row['parent_key']='hsx_lead';Db::name('sys_menu')->insert($row+['source'=>'system']);}
    Db::name('sys_menu')->insert(['menu_key'=>'other_page','menu_name'=>'Other','app_type'=>'site','addon'=>'','source'=>'system','menu_type'=>1,'api_url'=>'other/read','methods'=>'get']);
    $read=['hsx_lead','hsx_lead_cooperation_leads','hsx_lead_cooperation_leads_scope_read','other_page'];
    $finance=['hsx_lead','hsx_lead_cooperation_finance','hsx_lead_deposit_manage','hsx_lead_deposit_detail'];
    $disabled=['hsx_lead','hsx_lead_manage_inventory'];
    foreach([[11,$site,$read,1],[12,$site,$finance,1],[13,$site,['other_page'],1],[14,$site+1,$disabled,0],[15,$site,['hsx_lead','hsx_lead_promotion_manage'],1]]as[$id,$tenant,$rules,$status])Db::name('sys_role')->insert(['role_id'=>$id,'site_id'=>$tenant,'role_name'=>'Fixture '.$id,'rules'=>json_encode($rules),'status'=>$status]);
    $service=new MenuService();
    $beforeTree=groupKeys($service->getMenuListByMenuKeys($site,$read,'site',1));
    groupAssert(in_array('hsx_lead_cooperation_leads',$beforeTree,true),'ordinary pre-upgrade role sees its granted leaf via the real framework tree');
    $beforeApi=groupApi($read);$before=groupSnapshot();
    $command=new MenuGroupsUpgrade($plugin,$fixture);
    $report=$command->check();
    groupAssert($report['pending_directories']===6&&$report['pending_reparents']===14&&$report['affected_roles']===4,'read-only preflight identifies only the four corresponding roles and the new directories');
    groupAssert(groupSnapshot()===$before&&!is_dir($fixture.'/runtime'),'--check creates no DB change, backup, lock or cache write');
    $guarded=false;
    try{(new UpgradeCommand($plugin,$fixture,$fixture))->check();}catch(RuntimeException$error){$guarded=str_contains($error->getMessage(),'原角色尚缺少本次新增的菜单目录');}
    groupAssert($guarded&&groupSnapshot()===$before&&!is_dir($fixture.'/runtime'),'ordinary updater explicitly blocks unsafe refresh and requests the dedicated permission check without silently changing roles');
    $pdo->exec("CREATE TRIGGER lt_fixture_group_abort BEFORE UPDATE ON lt_sys_role FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='fixture abort'");$rolledBack=false;
    try{$command->apply();}catch(Throwable$error){$rolledBack=true;}finally{$pdo->exec('DROP TRIGGER lt_fixture_group_abort');}
    groupAssert($rolledBack&&groupSnapshot()===$before,'a failed role write rolls back all preceding menu insert/reparent writes atomically');
    $result=$command->apply();$after=groupSnapshot();
    groupAssert($result['status']==='complete'&&$result['api_permission_changes']===false,'atomic apply succeeds without expanding API authority');
    groupAssert(groupRules(11)===array_merge($read,['hsx_lead_group_supervision']),'read role receives only its required pure directory, not finance or writes');
    groupAssert(groupRules(12)===array_merge($finance,['hsx_lead_group_finance']),'finance role retains only its own original page/action grants');
    groupAssert(groupRules(14)===array_merge($disabled,['hsx_lead_group_merchants']),'disabled role keeps its disabled status and gains no extra page');
    groupAssert($after['sys_role'][2]===$before['sys_role'][2],'unrelated role is byte-for-byte unchanged');
    groupAssert(groupApi(groupRules(11))===$beforeApi,'real framework API permission set is identical before and after');
    $afterKeys=groupKeys($service->getMenuListByMenuKeys($site,groupRules(11),'site',1));
    groupAssert(in_array('hsx_lead_cooperation_leads',$afterKeys,true)&&in_array('hsx_lead_group_supervision',$afterKeys,true),'existing ordinary user still sees exactly the same granted business leaf after nesting');
    groupAssert(!in_array('hsx_lead_cooperation_finance',$afterKeys,true)&&!in_array('hsx_lead_manage_merchants',$afterKeys,true),'ordinary user is not granted adjacent pages by the new directory');
    $nativeRules=(new RoleService())->getMenuIdsByRoleIds($site,[11]);
    groupAssert(in_array('hsx_lead_group_supervision',$nativeRules,true)&&in_array('hsx_lead_cooperation_leads',$nativeRules,true)&&!in_array('hsx_lead_cooperation_finance',$nativeRules,true),'real RoleService intersects tenant entitlement without losing the authorized leaf or expanding finance');
    foreach(['site','sys_config','member','sys_notice','sys_schedule']as$table)groupAssert($before[$table]===$after[$table],$table.' remains untouched');
    groupAssert((fileperms($result['backup'])&0777)===0700&&(fileperms($result['backup'].'/before.json')&0777)===0600,'snapshot including old raw role rules is private and outside web files');
    $backed=json_decode(file_get_contents($result['backup'].'/before.json'),true,512,JSON_THROW_ON_ERROR);
    groupAssert($backed['snapshot']['roles'][11]['rules']===$before['sys_role'][0]['rules'],'backup preserves the exact old role JSON before writes');
    $repeat=$command->apply();groupAssert($repeat['status']==='unchanged'&&groupSnapshot()===$after,'repeated apply is idempotent and creates no duplicate menus or permission changes');
    Db::name('sys_menu')->where('menu_key','hsx_lead_group_supervision')->update(['api_url'=>'forbidden/write']);$blockedBefore=groupSnapshot();$blocked=false;
    try{$command->apply();}catch(RuntimeException$error){$blocked=true;}
    groupAssert($blocked&&groupSnapshot()===$blockedBefore,'a directory collision carrying API authority fails closed before role changes');
    echo "PASS {$checks} real menu/permission checks; isolated local schema only.\n";
}catch(Throwable$error){fwrite(STDERR,'FAIL '.get_class($error).': '.$error->getMessage().PHP_EOL.$error->getTraceAsString().PHP_EOL);$failed=true;}
finally{
    if($fixture!==''&&$schema!==''&&str_starts_with($fixture,rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema.'/')){
        if(is_dir($fixture)){foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($fixture,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST)as$entry){if($entry->isFile()||$entry->isLink())unlink($entry->getPathname());else rmdir($entry->getPathname());}rmdir($fixture);}
    }
    if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);
}
exit(!empty($failed)?1:0);
