import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// The real presentation helper and editor setup only. No fabricated UI state,
// browser, transport, credentials, database or business writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.join(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const {cooperationDiyVars}=loadMobileUtility('cooperation-diy-style')
let checks=0
function check(ok,label){assert.ok(ok,label);checks++}
function same(actual,expected,label){assert.deepEqual(JSON.parse(JSON.stringify(actual)),expected,label);checks++}
const dimensions={titleSize:['--lead-diy-title-size',18,14,28],textSize:['--lead-diy-text-size',14,12,20],contentPadding:['--lead-diy-content-padding',16,0,32],rowGap:['--lead-diy-row-gap',12,0,32],itemRadius:['--lead-diy-item-radius',8,0,24],buttonRadius:['--lead-diy-button-radius',6,0,28]}
const colors={primaryColor:'--lead-diy-primary',titleColor:'--lead-diy-title',textColor:'--lead-diy-text',subtleColor:'--lead-diy-subtle',panelColor:'--lead-diy-panel',iconColor:'--lead-diy-icon',borderColor:'--lead-diy-border',buttonColor:'--lead-diy-button',buttonTextColor:'--lead-diy-button-text'}
const expectedKeys=[...Object.values(colors),...Object.values(dimensions).map(value=>value[0])].sort()
const defaults=cooperationDiyVars()
same(Object.keys(defaults).sort(),expectedKeys,'the presentation helper returns exactly fifteen scoped tokens, no extra business or outer-layout fields')
check(defaults['--lead-diy-primary']==='var(--primary-color, #ff4444)'&&defaults['--lead-diy-button']===defaults['--lead-diy-primary'],'unset primary and button use the current site theme, not an invented plugin brand')
check(defaults['--lead-diy-panel']==='transparent'&&defaults['--lead-diy-title']==='#202124'&&defaults['--lead-diy-text']==='#606266'&&defaults['--lead-diy-icon']==='#333333','neutral defaults preserve the framework outer background with clear text and icon contrast')
check(defaults['--lead-diy-border']==='#e4e8ef','unset entry border retains the existing fine-line colour rather than adding a new card outline')
const custom={primaryColor:'#287c63',titleColor:'#182132',textColor:'#435169',subtleColor:'#788294',panelColor:'rgba(230, 244, 238, 0.6)',iconColor:'#356352',borderColor:'#305caa',buttonColor:'#206b54',buttonTextColor:'#fff',titleSize:22,textSize:16,contentPadding:24,rowGap:20,itemRadius:10,buttonRadius:12}
const before=JSON.stringify(custom),configured=cooperationDiyVars(custom)
for(const [key,token]of Object.entries(colors))check(configured[token]===custom[key],key+' maps to the exact configured colour rather than a page-specific override')
for(const [key,[token]]of Object.entries(dimensions))check(configured[token]===custom[key]+'px',key+' uses bounded CSS pixels, not viewport-based font scaling')
check(JSON.stringify(custom)===before,'presentation conversion never rewrites persisted decoration JSON')
check(cooperationDiyVars({primaryColor:'#175d45'})['--lead-diy-button']==='#175d45','a deliberately configured primary becomes the default button background')
check(cooperationDiyVars({primaryColor:'#175d45',buttonColor:'#5b456e'})['--lead-diy-button']==='#5b456e','an explicit button colour remains independent of the primary colour')
check(cooperationDiyVars({panelColor:''})['--lead-diy-panel']==='transparent','empty inner background leaves the framework background visible')
for(const borderColor of ['transparent','rgba(0,0,0,0)','#11223300'])check(cooperationDiyVars({borderColor})['--lead-diy-border']===borderColor,'transparent entry border is a real rendered value: '+borderColor)
check(cooperationDiyVars({borderColor:'url(https://invalid.example)'})['--lead-diy-border']==='#e4e8ef','invalid border CSS cannot inject a remote image or replace native background')
for(const valid of ['#abc','#abcd','#ABCDEF','#11223344','rgb(12, 80, 30)','rgba(12, 80, 30, .5)','hsl(120, 50%, 30%)','hsla(120, 50%, 30%, .5)','transparent'])check(cooperationDiyVars({titleColor:'  '+valid+' '})['--lead-diy-title']===valid,'safe colour syntax is preserved: '+valid)
for(const invalid of ['url(https://invalid.example/image.png)','red;background:url(https://invalid.example/a)','expression(alert(1))','var(--outside)','linear-gradient(red,blue)','<style>','',null,{},[],123,'#12345','#zzzzzz','x'.repeat(81)]){
    const result=cooperationDiyVars({primaryColor:invalid,buttonColor:invalid,titleColor:invalid,panelColor:invalid})
    check(result['--lead-diy-primary']===defaults['--lead-diy-primary']&&result['--lead-diy-button']===defaults['--lead-diy-primary']&&result['--lead-diy-title']===defaults['--lead-diy-title']&&result['--lead-diy-panel']==='transparent','invalid colour cannot inject URLs, styles or untrusted tokens: '+String(invalid))
}
for(const [key,[token,fallback,min,max]]of Object.entries(dimensions)){
    check(cooperationDiyVars({[key]:min-100})[token]===min+'px'&&cooperationDiyVars({[key]:max+100})[token]===max+'px',key+' clamps both ends of its public editor range')
    check(cooperationDiyVars({[key]:String(min+1.6)})[token]===Math.min(max,min+2)+'px',key+' rounds finite numeric configuration to stable integer pixels')
    for(const value of [undefined,null,'','not-a-number',NaN,Infinity])check(cooperationDiyVars({[key]:value})[token]===fallback+'px',key+' uses its documented fallback for an unset or nonfinite number')
}
const editorFile=path.join(plugin,'admin/views/diy/components/DiyAppearanceFields.vue'),editor=compiler.parse(fs.readFileSync(editorFile,'utf8'),{filename:editorFile}).descriptor,script=compiler.compileScript(editor,{id:'diy-appearance'})
check(!compiler.compileTemplate({source:editor.template.content,filename:editorFile,id:'diy-appearance',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'the shared actual Element Plus editor template compiles')
const module={exports:{}},js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{})(key=>{if(key==='vue')return Vue;if(key==='@/stores/modules/diy')return{default:()=>({editComponent:{},predefineColors:[]})};throw Error(key)},module,module.exports)
const state=module.exports.default.setup({}, {expose(){}})
same([...state.mainColors,...state.extraColors].map(field=>field.key).sort(),Object.keys(colors).sort(),'all nine actual colour editor controls correspond to the shared runtime helper')
for(const field of state.dimensions)check(dimensions[field.key]&&dimensions[field.key][3]===field.max,'actual '+field.key+' editor maximum matches the renderer clamp')
check(editor.template.content.includes('editComponent.titleSize')&&editor.template.content.includes(':min="14" :max="28"')&&editor.template.content.includes('editComponent.textSize')&&editor.template.content.includes(':min="12" :max="20"'),'font editor ranges match the real helper rather than merely declaring unused settings')
check(editor.template.content.includes('el-collapse-item')&&editor.template.content.includes('牛云通用样式'),'secondary appearance settings stay folded while framework outer styling remains explicit')
const runtimeFiles=['components/diy/lead-cooperation-entry/index.vue','components/cooperation/CoopProfileDiySection.vue','components/cooperation/CoopProfilePanel.vue','components/cooperation/CoopMembershipEntry.vue','components/cooperation/CoopRoleEntryCard.vue','components/cooperation/CoopBusinessNavigation.vue']
const runtime=runtimeFiles.map(file=>fs.readFileSync(path.join(plugin,'uni-app',file),'utf8'))
const profileFile=path.join(plugin,'uni-app',runtimeFiles[1]),profileDescriptor=compiler.parse(runtime[1],{filename:profileFile}).descriptor
const profileScript=compiler.compileScript(profileDescriptor,{id:'appearance-runtime'}),profileModule={exports:{}}
const profileJs=ts.transpileModule(profileScript.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
const profileStore=Vue.reactive({mode:'',value:[]}),profileContext={displayable:Vue.ref(true),preview:Vue.ref(false),displayProfile:Vue.ref({id:1}),displayMember:Vue.ref({member_no:'SYNTHETIC-UID',nickname:'合成会员'}),displayConfig:Vue.ref({}),action(){}}
vm.runInNewContext('(function(require,module,exports){'+profileJs+'\n})',{String,Number,Object,Array,Math})(key=>{
    if(key==='vue')return Vue
    if(key==='@/app/stores/diy')return{default:()=>profileStore}
    if(key==='@/utils/common')return{img:value=>'local-assets/'+value}
    if(key.endsWith('/useProfileDiy'))return{useProfileDiyContext:()=>profileContext}
    if(key.includes('/utils/'))return loadMobileUtility(path.basename(key))
    if(key.endsWith('.vue'))return{default:{}}
    throw Error('Unexpected runtime dependency '+key)
},profileModule,profileModule.exports)
const appearanceProps=Vue.reactive({component:{...custom,title:'真实外观渲染',showTitle:1,componentStartBgColor:'#ffffff',componentEndBgColor:'#ddeeff',componentGradientAngle:'to right',componentBgUrl:'native-header.png',componentBgAlpha:3},kind:'identity',index:0,global:{}})
const profileState=profileModule.exports.default.setup(appearanceProps,{expose(){},emit(){}})
for(const token of expectedKeys)check(profileState.componentStyle.value[token]===configured[token],'real personal-centre computed style consumes the shared output '+token)
check(profileState.frame.value.style.background==='linear-gradient(to right,#ffffff,#ddeeff)'&&profileState.frame.value.style.backgroundImage==="url('local-assets/native-header.png')"&&profileState.maskStyle.value.backgroundColor==='rgba(0,0,0,0.3)','actual wrapper frame helper keeps native gradient/image/mask independent from content appearance')
const dom=require('@vue/compiler-dom'),render=new Function('Vue',dom.compile(profileDescriptor.template.content,{mode:'function',prefixIdentifiers:true}).code)(Vue)
const app=Vue.createSSRApp({setup:()=>({...profileState,kind:'identity'}),render});app.config.warnHandler=()=>{};app.component('CoopProfilePanel',{render:()=>Vue.h('span')})
const rendered=await require('@vue/server-renderer').renderToString(app)
check(rendered.includes('--lead-diy-border:#305caa')&&rendered.includes('--lead-diy-title:#182132')&&rendered.includes('--lead-diy-content-padding:24px'),'real wrapper render emits configured border/text/spacing variables rather than only declaring editor fields')
check(rendered.includes('local-assets/native-header.png')&&rendered.includes('rgba(0,0,0,0.3)')&&rendered.includes('pointer-events:none'),'real wrapper render emits native image and nonintercepting mask from the extracted frame helper')
check(!runtime[0].includes("background:'var(--lead-diy-panel")&&!runtime[0].includes('background: settings.panelColor'),'homepage does not cover native framework background with an internal panel')
check(editor.template.content.includes('allowPanel || item.key')&&fs.readFileSync(path.join(plugin,'admin/views/diy/components/edit-lead-cooperation-entry.vue'),'utf8').includes(':allow-panel="false"'),'shared style editor can hide the duplicate content background for native home blocks')
check(editor.template.content.includes("['panelColor','borderColor'].includes(field.key)")&&editor.template.content.includes('支持透明'),'entry border editor allows alpha instead of exposing an ineffective solid-only control')
for(const token of expectedKeys)check(runtime.some(source=>source.includes('var('+token)),'the live renderer tree consumes '+token+' rather than exposing a dead decoration setting')
appearanceProps.component.componentBgUrl='';appearanceProps.component.componentStartBgColor='';appearanceProps.component.componentEndBgColor=''
check(profileState.componentStyle.value.background===undefined&&!('backgroundImage'in profileState.componentStyle.value)&&!profileState.frame.value.hasImage,'clearing actual frame fields exposes the page without discarding content variables')
console.log(`PASS ${checks} DIY appearance helper/editor/runtime contracts; actual pure helper and Vue setup, no browser, API or database actions.`)
