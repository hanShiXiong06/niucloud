<?php
declare(strict_types=1);

if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\MerchantService;
use addon\hsx_lead\app\service\cooperation\{ConfigService,CooperationService,EntityMembershipService,PartnerService,PaymentService,Rules,Store,TeamService};
use addon\hsx_lead\app\listener\pay\MembershipRefundSuccess;
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use core\exception\CommonException;
use think\facade\Db;

$checks=0;$pdo=null;$schema='';$failed=false;
function mgCheck(bool $ok,string $message):void{if(!$ok)throw new RuntimeException($message);$GLOBALS['checks']++;}
function mgDeny(callable $work,string $message):void{try{$work();}catch(CommonException $error){mgCheck(true,$message);return;}throw new RuntimeException('Not denied: '.$message);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $definitions=[
        leadMembershipDefinition(701,1,2,false,['can_publish'=>true,'can_accept'=>false,'can_view_inventory'=>false,'all_models'=>false]),
        leadMembershipDefinition(702,2,1,false,['can_publish'=>false,'can_accept'=>true,'can_view_inventory'=>false,'all_models'=>false]),
        leadMembershipDefinition(703,3,1,false,['can_publish'=>false,'can_accept'=>false,'can_view_inventory'=>true,'all_models'=>false]),
        leadMembershipDefinition(704,4,2,false,['all_models'=>true]),
    ];
    foreach($definitions as$definition)Db::name('member_level')->insert($definition+['site_id'=>$site]);
    foreach([104,105,106]as$member)Db::name('member')->insert(['site_id'=>$site,'member_id'=>$member,'nickname'=>'Capability fixture '.$member,'mobile'=>'19900000'.$member]);
    $admin=new Context($site,1);$settings=new ConfigService($admin);$config=$settings->get();$config['enabled']=true;$config['publishing_required']=true;$config['fee_confirmed']=true;$settings->save($config);
    $publisherContext=new Context($site,0,101);$receiverContext=new Context($site,0,102);
    $publisher=new CooperationService($publisherContext);$receiver=new CooperationService($receiverContext);
    $models=$publisher->catalog(['business_type'=>'purchase','browse'=>1]);mgCheck(count($models)>=2,'real builtin demand directory available');$model=$models[0];
    $profile=static function(int$member,bool$declare=true)use($site,$model):array{return(new PartnerService(new Context($site,0,$member)))->saveProfile(['name'=>'Capability fixture '.$member,'contact_name'=>'Synthetic owner','mobile'=>'18800000'.$member,'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic fixture road','business_capabilities'=>$declare?[['business_type'=>'purchase','option_ids'=>[$model['id']]]]:[]]);};
    $a=$profile(101);$b=$profile(102);$viewer=$profile(104);$full=$profile(105,false);$unpaid=$profile(106);
    $aId=(int)$a['id'];$bId=(int)$b['id'];$viewerId=(int)$viewer['id'];$fullId=(int)$full['id'];$unpaidId=(int)$unpaid['id'];
    mgCheck((new MerchantService($admin))->detail($unpaidId)['ready_state']==='membership_required','merchant management marks unpaid receiver as requiring membership');
    $base=['customer_name'=>'Synthetic lead','mobile'=>'13800000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'attachments'=>[],'consent'=>true];
    $newLead=static function(string$request,array$change=[])use($publisher,$base):array{return$publisher->create(array_replace($base,['request_id'=>$request],$change));};
    $noPlan=new CooperationService(new Context($site,0,106));
    mgDeny(fn()=>$newLead('cap-no-plan-0001'),'unpaid subject cannot create a new demand');
    mgDeny(fn()=>$noPlan->stores(['province_id'=>910000]),'unpaid subject cannot search delivery stores');
    mgDeny(fn()=>$noPlan->storeInventory($bId),'unpaid subject cannot view another store inventory');
    mgCheck($noPlan->storeInventory($unpaidId)['data']===[],'own stock stays visible during onboarding, even without a membership');
    $marker=Store::partner($site,$unpaidId);Store::query('partner',$site)->where('id',$marker['id'])->update(['membership_level'=>'ML704','membership_until'=>time()+86400]);
    mgCheck(!Rules::membershipActive(Store::partner($site,$unpaidId),$config),'manual subject marker cannot grant unbacked paid rights');
    Store::query('partner',$site)->where('id',$marker['id'])->update(['membership_level'=>'','membership_until'=>0]);

    // Permission isolation, not experience qualification: each target is
    // explicitly the sole entry at its purchase time; all grants still pay.
    $aPaid=leadMembershipGrant($site,101,'ML701');leadSetEntryDefinition($site,702);$bPaid=leadMembershipGrant($site,102,'ML702');
    leadSetEntryDefinition($site,703);leadMembershipGrant($site,104,'ML703');leadSetEntryDefinition($site,704);leadMembershipGrant($site,105,'ML704');
    $aSummary=(new PartnerService($publisherContext))->bootstrap()['profile'];
    mgCheck($aSummary['can_publish']&&!$aSummary['can_accept']&&!$aSummary['can_view_inventory'],'publisher tier does not inherit absent capabilities');
    mgCheck($aSummary['membership']['level_code']==='ML701'&&$aSummary['membership']['level_name']===$definitions[0]['level_name'],'public tier name is the actual paid framework directory name');
    mgCheck(array_intersect_key($aSummary,array_flip(['grade_id','grade_name','grade_rank','grade_mode','certification_status','publisher_until','premium_refund_pending']))===[],'removed qualifications are not returned as parallel membership state');
    $managed=(new MerchantService($admin))->detail($aId);
    mgCheck($managed['membership']['level_code']==='ML701'&&$managed['display_rank']===1&&$managed['can_publish']&&!$managed['can_accept'],'merchant management projects the same dynamic rights as the mobile profile');
    mgCheck($managed['ready_state']==='membership_required'&&str_contains($managed['ready_reason'],'未包含'),'a paid publish-only member is not mislabeled as ready for new receiving work');
    mgCheck(array_intersect_key($managed,array_flip(['is_reliable','membership_permanent']))===[],'merchant management no longer reads removed parallel entitlement fields');
    mgCheck((new MerchantService($admin))->detail($bId)['ready_state']==='ready','acceptance capability plus declared model qualifies a receiver without ERP');
    mgDeny(fn()=>$receiver->create(array_replace($base,['request_id'=>'cap-accept-only-0001'])),'accept-only tier cannot publish');
    mgDeny(fn()=>$publisher->storeInventory($bId),'publish capability does not grant other-store inventory access');
    $reader=new CooperationService(new Context($site,0,104));mgCheck($reader->storeInventory($bId)['total']===0,'inventory capability grants safe reference access without fabricating stock');
    mgDeny(fn()=>$reader->create(array_replace($base,['request_id'=>'cap-inventory-only-1'])),'inventory capability does not grant publication');
    $lead=$newLead('cap-permission-flow-1');$leadId=(int)$lead['id'];
    $found=$publisher->stores([],$leadId);$ids=array_map('intval',array_column($found['data'],'id'));
    mgCheck(in_array($bId,$ids,true)&&in_array($fullId,$ids,true)&&!in_array($viewerId,$ids,true)&&!in_array($unpaidId,$ids,true),'matching requires real acceptance capability rather than any paid membership');
    mgCheck(!in_array($aId,$ids,true),'single-account subject does not offer a self-assignment even when paid seats remain');
    Db::name('member')->insert(['site_id'=>$site,'member_id'=>107,'nickname'=>'Confirmed colleague','mobile'=>'19900000107']);
    $ownerTeam=new TeamService($publisherContext);$subjectCode=$ownerTeam->summary()['subject_code'];(new TeamService(new Context($site,0,107)))->join(['subject_code'=>$subjectCode]);$ownerTeam->review(107,true);
    $found=$publisher->stores([],$leadId);
    mgCheck(!empty($found['data'][0]['is_internal'])&&(int)$found['data'][0]['id']===$aId&&array_column($found['data'][0]['internal_assignees'],'member_id')===[107],'own store becomes first only after another real colleague is approved');
    $external=array_values(array_filter($found['data'],static fn(array $row):bool=>empty($row['is_internal'])));
    mgCheck((int)$external[0]['id']===$fullId&&$external[0]['membership_rank']===400,'paid rank orders external candidates before lower-ranked stock/declared providers');
    $fullRow=array_values(array_filter($found['data'],static fn(array$row):bool=>(int)$row['id']===$fullId))[0];
    mgCheck($fullRow['all_models']&&$fullRow['inventory_count']===0&&$fullRow['capability_source']==='all_models','full-model entitlement represents delivery capacity, not fictitious stock');
    $lead=$publisher->assign($leadId,['merchant_id'=>$bId,'assignment_version'=>0]);
    mgCheck($lead['status']==='assigned'&&$receiver->detail($leadId)['can_accept'],'assigned eligible receiver is offered acceptance');
    $accepted=$receiver->action($leadId,['action'=>'accept','assignment_version'=>1]);mgCheck($accepted['status']==='following','receiver action enforces and then applies acceptance');
    $beforePersonal=Db::name('member')->where('site_id',$site)->whereIn('member_id',[101,102,104,105,106])->column('member_level','member_id');
    mgCheck(count(array_unique(array_values($beforePersonal)))===1&&(int)reset($beforePersonal)===0,'subject memberships never alter personal framework levels');

    // A completed refund revokes only new rights. Work already accepted remains
    // reportable/payable, without a fresh plan or another entitlement charge.
    $bOrder=(new PaymentService($receiverContext))->order((int)$bPaid['id']);
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'CAPABILITY_REFUND_RECEIVER','out_trade_no'=>$bOrder['out_trade_no'],'money'=>$bOrder['amount'],'status'=>RefundDict::SUCCESS]);
    (new MembershipRefundSuccess())->handle(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'refund_no'=>'CAPABILITY_REFUND_RECEIVER']);
    mgCheck(!(new EntityMembershipService($receiverContext))->summary()['active'],'successful full refund revokes receiver future rights');
    mgCheck($receiver->detail($leadId)['can_report'],'accepted historical work can still report its outcome');
    $outcome=$receiver->action($leadId,['action'=>'deal','assignment_version'=>1]);mgCheck($outcome['status']==='unpaid'&&$outcome['can_pay'],'expired or refunded receiver can finish and settle accepted work');
    $commission=(new PaymentService($receiverContext))->createOrder(['purpose'=>'commission','lead_id'=>$leadId,'amount'=>'100.00','request_id'=>'cap-commission-history-1']);
    mgCheck($commission['purpose']==='commission'&&$commission['amount']==='100.00','historical commission order is not gated behind a new membership');
    $number='CAPABILITY_COMMISSION_RECEIPT';Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$commission['id'],'out_trade_no'=>$number,'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'money'=>$commission['amount'],'status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);
    PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$commission['id'],'out_trade_no'=>$number]);
    mgCheck($publisher->detail($leadId)['status']==='paid','historical work settles from a matching payment receipt');
    mgCheck(Db::name('member_account_log')->where('site_id',$site)->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$commission['id'])->count()===1,'publisher income is credited exactly once');
    PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$commission['id'],'out_trade_no'=>$number]);
    mgCheck(Db::name('member_account_log')->where('site_id',$site)->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$commission['id'])->count()===1,'replayed receipt never credits publisher twice');
    $fresh=$newLead('cap-refund-filter-1');$freshFound=$publisher->stores([],(int)$fresh['id']);
    mgCheck(!in_array($bId,array_map('intval',array_column($freshFound['data'],'id')),true),'refunded receiver is excluded from new assignment');
    mgDeny(fn()=>$publisher->assign((int)$fresh['id'],['merchant_id'=>$bId,'assignment_version'=>0]),'direct assignment cannot bypass current acceptance rights');
    foreach(['publishing','certification']as$removed)mgDeny(fn()=>(new PaymentService($publisherContext))->createOrder(['purpose'=>$removed,'request_id'=>'removed-'.$removed.'-1']),'removed fee purpose is rejected: '.$removed);
    $aOrder=(new PaymentService($publisherContext))->order((int)$aPaid['id']);
    mgCheck($aOrder['level_id']===701&&$aOrder['display_rank']===1&&$aOrder['cycle_name']==='月付'&&$aOrder['entitlement_months']===1,'membership order displays its original dynamic tier and cycle snapshot');
    mgCheck($aOrder['capabilities']['can_publish']&&!$aOrder['capabilities']['can_accept']&&count($aOrder['benefits'])===4,'original order exposes exact frozen rights, not current directory defaults');
    $definition=json_decode($definitions[0]['level_benefits'],true);$definition['hsx_lead_subject']['is_entry']=false;$definition['hsx_lead_subject']['cycles'][0]['enabled']=false;
    Db::name('member_level')->where('site_id',$site)->where('level_id',701)->update(['level_name'=>'Renamed current directory','level_benefits'=>json_encode($definition)]);
    $reloaded=(new PaymentService($publisherContext))->order((int)$aPaid['id']);
    mgCheck($reloaded['level_name']===$aOrder['level_name']&&$reloaded['cycle_name']===$aOrder['cycle_name']&&$reloaded['capabilities']===$aOrder['capabilities'],'renaming or retiring a cycle does not rewrite a paid original order');
    mgCheck(!(new EntityMembershipService($publisherContext))->quote('ML701','month')['can_purchase'],'retired cycle cannot be used for a new purchase');
    mgCheck((new PartnerService($publisherContext))->bootstrap()['profile']['can_publish'],'paid permission snapshot remains valid until expiry despite catalog editing');
    mgDeny(fn()=>(new PartnerService($admin))->update($aId,['membership_level'=>'ML704','membership_until'=>time()+86400]),'admin notes endpoint cannot grant a membership marker');
    (new PartnerService($admin))->update($aId,['remark'=>'Synthetic regulated note']);mgCheck(Store::partner($site,$aId)['remark']==='Synthetic regulated note','regulatory remark remains editable without a parallel qualification form');

    $config=$settings->get();$config['publishing_required']=false;$settings->save($config);
    $freeProfile=(new PartnerService(new Context($site,0,106)))->bootstrap()['profile'];
    mgCheck($freeProfile['can_publish']&&$freeProfile['can_accept']&&$freeProfile['can_view_inventory']&&!$freeProfile['all_models'],'global free operation restores basic flows, not unearned all-model entitlement');
    mgCheck((new MerchantService($admin))->detail($unpaidId)['ready_state']==='ready','explicit global free operation also has consistent admin readiness');
    $freeLead=$noPlan->create(array_replace($base,['request_id'=>'cap-free-operation-1']));mgCheck($freeLead['status']==='selecting','unpaid subject can publish when administrator explicitly disables membership requirement');
    mgCheck($noPlan->storeInventory($bId)['data']===[],'free operation preserves safe cross-store inventory projection');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'dynamic framework catalog and actual cooperation/payment services in owned random localhost schema; synthetic receipts only; no external API or existing data'],JSON_UNESCAPED_UNICODE),PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.$error->getFile().':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
