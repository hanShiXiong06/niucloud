<?php
declare(strict_types=1);

// Real business services/listeners with owned synthetic receipts only. This is
// not an online payment/refund test and never opens an existing business schema.
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';
require __DIR__ . '/membership-fixtures.php';

use addon\hsx_lead\app\listener\member\MemberAdminEntitlementDisplay;
use addon\hsx_lead\app\listener\pay\MembershipRefundSuccess;
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityMembershipService,PartnerService,PaymentService,Rules,Store,TeamService};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use think\facade\{Cache,Db};

$checks = 0;
$pdo = null;
$schema = '';
$failed = false;
function lifecycleCheck(bool $value, string $label): void
{
    if (!$value) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function lifecycleActor(int $site): void
{
    $property = new ReflectionProperty(app\Request::class, 'auth_info');
    $property->setAccessible(true);
    $property->setValue(null, ['uid' => 1, 'app_type' => 'site', 'member_id' => 0]);
    request()->siteId($site);
}
function lifecycleFacts(int $site): string
{
    $facts = [];
    foreach (['member','hsx_lead_merchant','hsx_lead_partner','hsx_lead_merchant_member','hsx_lead_coop_order','pay','pay_refund','member_account_log','hsx_lead_audit_log'] as $table) {
        // Audit table name is taken from the plugin's authoritative table map.
        if ($table === 'hsx_lead_audit_log') $facts[$table] = Data::query('audit', $site)->order('id')->select()->toArray();
        // SQL row order is undefined without ORDER BY. A different read plan
        // (for example after an additive index) is not a financial mutation.
        else $facts[$table] = Db::name($table)->where('site_id', $site)->order($table === 'member' ? 'member_id' : 'id')->select()->toArray();
    }
    return hash('sha256', Data::json($facts));
}
function lifecycleProjection(int $site, array $memberIds, string $stage): array
{
    lifecycleActor($site);
    $before = lifecycleFacts($site);
    $result = (new MemberAdminEntitlementDisplay())->handle(['site_id' => $site, 'member_ids' => $memberIds]);
    lifecycleCheck(($result['key'] ?? '') === 'hsx_lead_subject' && is_array($result['members'] ?? null), $stage . ': display listener provides the real plugin source');
    lifecycleCheck(lifecycleFacts($site) === $before, $stage . ': reading the member display changes no account, entitlement, payment, refund, staff or audit facts');
    return $result['members'];
}
function lifecycleMatch(int $site, int $merchant, array $memberIds, string $stage): array
{
    $config = (new ConfigService(new Context($site, 1)))->get();
    $single = EntityMembershipService::state($site, $merchant, $config);
    $batch = EntityMembershipService::states($site, [$merchant], $config)[$merchant];
    lifecycleCheck($single === $batch, $stage . ': single and page-batch state agree');
    $cards = lifecycleProjection($site, $memberIds, $stage);
    foreach ($memberIds as $memberId) {
        $card = $cards[$memberId] ?? null;
        lifecycleCheck(is_array($card), $stage . ': member ' . $memberId . ' has an explicit display result');
        lifecycleCheck(($card['label'] ?? '') === $single['level_name'] && (int)($card['expires_at'] ?? -1) === (int)$single['expires_at'], $stage . ': member ' . $memberId . ' uses the subject label and expiry, not the personal grade');
        lifecycleCheck(isset($single['display_status'], $single['display_status_text'])
            && ($card['status'] ?? '') === $single['display_status']
            && ($card['status_text'] ?? '') === $single['display_status_text'],
            $stage . ': official member display uses the same explicit read-only status as the subject page');
    }
    return $cards;
}

try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    // The local fixture site uses this plugin as its app; include it in addons
    // as well so the official installation lookup sees the enabled extension.
    Db::name('site')->where('site_id', $site)->update(['addons' => Data::json(['hsx_lead'])]);
    Cache::clear();
    leadMembershipSeed($site, [2, 5]);
    Db::name('member_level')->where('site_id', $site)->where('level_id', 701)->update(['level_name' => '青铜']);
    Db::name('member_level')->where('site_id', $site)->where('level_id', 702)->update(['level_name' => '白银']);
    foreach ([201,202,203,204,205] as $id) Db::name('member')->insert(['site_id' => $site, 'member_id' => $id, 'nickname' => 'Synthetic owner ' . $id, 'mobile' => '19900000' . $id, 'member_level' => $id === 205 ? 0 : 702]);
    Db::name('member')->where('site_id', $site)->where('member_id', 101)->update(['member_level' => 701]);
    $originalGrades = Db::name('member')->where('site_id', $site)->order('member_id')->column('member_level', 'member_id');
    $config = ConfigService::defaults();
    $config['enabled'] = true;
    $config['fee_confirmed'] = true;
    (new ConfigService(new Context($site, 1)))->save($config);
    $profiles = [];
    foreach ([101,201,202,203,204,205] as $id) $profiles[$id] = (new PartnerService(new Context($site, 0, $id)))->saveProfile(['name' => 'Lifecycle subject ' . $id, 'contact_name' => 'Synthetic owner', 'mobile' => '19900000' . $id, 'province_id' => 910000, 'city_id' => 910100, 'district_id' => 910101, 'address' => 'Synthetic road']);

    // Payment tables are copied from checked-in official DDL, never real data.
    $ddl = file_get_contents(dirname(__DIR__, 3) . '/app/install/source/database.sql');
    foreach (['pay','pay_refund'] as $table) {
        if (!preg_match('/CREATE TABLE\s+`' . $table . '`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si', $ddl, $match)) throw new RuntimeException('Missing official receipt fixture DDL');
        $pdo->exec(str_replace('CREATE TABLE `' . $table . '`', 'CREATE TABLE `lt_' . $table . '`', $match[0]));
    }
    $makeOrder = static function(int $owner, string $cycle, string $request) use ($site): array {
        $context = new Context($site, 0, $owner);
        $quote = (new EntityMembershipService($context))->quote('ML701', $cycle);
        return (new PaymentService($context))->createOrder(['purpose' => 'membership', 'level_code' => 'ML701', 'cycle' => $cycle, 'quote_token' => $quote['quote_token'], 'request_id' => $request]);
    };
    $receive = static function(array $order, string $number) use ($site): array {
        Db::name('pay')->insert(['site_id' => $site, 'trade_type' => PaymentService::TRADE_TYPE, 'trade_id' => $order['id'], 'out_trade_no' => $number, 'main_type' => PayDict::MEMBER, 'main_id' => $order['member_id'], 'from_main_id' => $order['member_id'], 'money' => $order['amount'], 'status' => PayDict::STATUS_FINISH, 'pay_time' => time()]);
        $event = ['site_id' => $site, 'trade_type' => PaymentService::TRADE_TYPE, 'trade_id' => $order['id'], 'out_trade_no' => $number];
        PaymentService::confirm($event);
        return $event;
    };
    $refund = static function(array $order, string $number, string $money, string $status = RefundDict::SUCCESS) use ($site): array {
        $id = (int)Db::name('pay_refund')->insertGetId(['site_id' => $site, 'refund_no' => $number, 'out_trade_no' => $order['out_trade_no'], 'money' => $money, 'status' => $status]);
        $event = ['site_id' => $site, 'trade_type' => PaymentService::TRADE_TYPE, 'refund_no' => $number];
        if ($status === RefundDict::SUCCESS) (new MembershipRefundSuccess())->handle($event);
        return [$id, $event];
    };

    $merchant = (int)$profiles[101]['id'];
    lifecycleMatch($site, $merchant, [101], 'Before payment');
    $first = $makeOrder(101, 'month', 'display-first-month');
    lifecycleMatch($site, $merchant, [101], 'Created but unpaid');
    $firstEvent = $receive($first, 'DISPLAY_FIRST_MONTH');
    $cards = lifecycleMatch($site, $merchant, [101], 'Verified opening payment');
    lifecycleCheck($cards[101]['label'] === '青铜' && $cards[101]['status'] === 'active', 'matching official receipt activates the purchased subject plan');
    $firstExpiry = (int)$cards[101]['expires_at'];
    PaymentService::confirm($firstEvent);
    lifecycleCheck((int)lifecycleMatch($site, $merchant, [101], 'Opening callback replay')[101]['expires_at'] === $firstExpiry, 'callback replay never extends the displayed expiry twice');

    $renewal = $makeOrder(101, 'year', 'display-renewal-year');
    $receive($renewal, 'DISPLAY_RENEWAL_YEAR');
    $cards = lifecycleMatch($site, $merchant, [101], 'Verified annual renewal');
    lifecycleCheck((int)$cards[101]['expires_at'] === Rules::addMonths($firstExpiry, 12), 'annual renewal display keeps the unused period plus twelve months');
    $ownerTeam = new TeamService(new Context($site, 0, 101));
    $code = $ownerTeam->summary()['subject_code'];
    $staff = new TeamService(new Context($site, 0, 102));
    $staff->join(['subject_code' => $code]);
    lifecycleCheck((lifecycleProjection($site, [102], 'Pending employee join')[102]['status'] ?? '') === 'not_joined', 'pending employee is not shown as already sharing paid subject rights');
    $ownerTeam->review(102, true);
    $cards = lifecycleMatch($site, $merchant, [101,102], 'Approved employee shares rights');
    lifecycleCheck(str_contains((string)$cards[101]['context'], '负责人') && str_contains((string)$cards[102]['context'], '店员'), 'same shared plan clearly distinguishes responsible owner and employee');
    $staff->leave();
    lifecycleCheck((lifecycleProjection($site, [101,102], 'Employee voluntary exit')[102]['status'] ?? '') === 'not_joined', 'employee exit immediately removes inherited display without clearing personal grade');
    $staff->join(['subject_code' => $code]);
    $ownerTeam->review(102, true);
    $ownerTeam->remove(102);
    lifecycleCheck((lifecycleProjection($site, [102], 'Owner removes employee')[102]['status'] ?? '') === 'not_joined', 'responsible owner removal immediately removes inherited display');

    $paid = [];
    foreach ([201,202,203,204] as $id) {
        $order = $makeOrder($id, 'month', 'display-scenario-' . $id);
        $receive($order, 'DISPLAY_SCENARIO_' . $id);
        $paid[$id] = Store::row('coop_order', $site, (int)$order['id']);
    }
    [$refundId, $refundEvent] = $refund($paid[201], 'DISPLAY_FULL_REFUND', $paid[201]['amount']);
    $cards = lifecycleMatch($site, (int)$profiles[201]['id'], [201], 'Verified full refund');
    lifecycleCheck($cards[201]['status'] === 'not_opened' && Store::row('coop_order', $site, (int)$paid[201]['id'])['status'] === 'paid', 'full refund removes subject rights but retains the paid order receipt history');
    $beforeReplay = lifecycleFacts($site);
    (new MembershipRefundSuccess())->handle($refundEvent);
    lifecycleCheck(lifecycleFacts($site) === $beforeReplay, 'refund callback replay has no duplicate entitlement or audit mutation');
    $refund($paid[202], 'DISPLAY_PARTIAL_REFUND', '1.00');
    $cards = lifecycleMatch($site, (int)$profiles[202]['id'], [202], 'Verified partial refund');
    lifecycleCheck($cards[202]['status'] === 'review', 'partial refund display requires reconciliation instead of inventing remaining days');
    [$pendingRefund] = $refund($paid[203], 'DISPLAY_PENDING_REFUND', $paid[203]['amount'], RefundDict::WAIT);
    $cards = lifecycleMatch($site, (int)$profiles[203]['id'], [203], 'Refund still pending');
    lifecycleCheck($cards[203]['status'] === 'review', 'unconfirmed refund cannot appear as an ordinary opened/closed plan');
    lifecycleCheck(EntityMembershipService::state($site, (int)$profiles[203]['id'])['active'] === true,
        'pending refund presentation does not itself revoke the original paid authorization');
    Db::name('pay_refund')->where('site_id', $site)->where('id', $pendingRefund)->update(['status' => RefundDict::CANCEL]);
    $cards = lifecycleMatch($site, (int)$profiles[203]['id'], [203], 'Pending refund cancelled');
    lifecycleCheck($cards[203]['status'] === 'active', 'cancelling an unexecuted refund restores the normal paid display');

    // Simulate passage of time by dating this isolated fixture's already
    // verified receipt/grant in the past; do not alter the machine clock.
    $expired = $paid[204];
    $rule = Data::decode($expired['rule_json']);
    $start = time() - 70 * 86400;
    $rule['quoted_at'] = $start;
    $rule['period_start_at'] = $start;
    $rule['period_end_at'] = Rules::addMonths($start, (int)$rule['months']);
    foreach (['quoted_period_start_at','quoted_period_end_at'] as $key) if (isset($rule[$key])) $rule[$key] = $key === 'quoted_period_start_at' ? $rule['period_start_at'] : $rule['period_end_at'];
    Store::query('coop_order', $site)->where('id', $expired['id'])->update(['rule_json' => Data::json($rule), 'pay_time' => $start]);
    Db::name('pay')->where('site_id', $site)->where('out_trade_no', $expired['out_trade_no'])->update(['pay_time' => $start]);
    $cards = lifecycleMatch($site, (int)$profiles[204]['id'], [204], 'Paid period has expired');
    lifecycleCheck($cards[204]['status'] === 'expired' && (int)$cards[204]['expires_at'] < time(), 'read-time expiry is shared by the official member and subject display without a cron rewrite');
    leadSetEntryDefinition($site, 702);
    $silverContext = new Context($site, 0, 205);
    $silverQuote = (new EntityMembershipService($silverContext))->quote('ML702', 'year');
    $silver = (new PaymentService($silverContext))->createOrder(['purpose' => 'membership', 'level_code' => 'ML702', 'cycle' => 'year', 'quote_token' => $silverQuote['quote_token'], 'request_id' => 'display-silver-ungraded']);
    $receive($silver, 'DISPLAY_SILVER_UNGRADED');
    $cards = lifecycleMatch($site, (int)$profiles[205]['id'], [205], 'White-silver subject on an ungraded account');
    lifecycleCheck($cards[205]['label'] === '白银' && $cards[205]['status'] === 'active'
        && (int)Db::name('member')->where('site_id', $site)->where('member_id', 205)->value('member_level') === 0,
        'the reported regression shows paid silver subject rights even when the original personal grade is empty');
    lifecycleCheck(Db::name('member')->where('site_id', $site)->order('member_id')->column('member_level', 'member_id') === $originalGrades, 'payment, renewal, refunds, expiry, employee leave and removal never alter any personal member level');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => 'real plugin opening/renewal/refund callbacks and staff services with synthetic official receipts; display-vs-single/batch subject state; random owned localhost schema; no real gateway, existing business data or machine clock change'], JSON_UNESCAPED_UNICODE) . PHP_EOL;
} catch (Throwable $error) {
    $failed = true;
    fwrite(STDERR, get_class($error) . ': ' . $error->getMessage() . ' @ ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    if ($pdo instanceof PDO && $schema !== '') leadCleanup($pdo, $schema);
}
if ($failed) exit(1);
