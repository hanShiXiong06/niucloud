import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),root=path.resolve(plugin,'../../..')
const require=createRequire(path.join(root,'uni-app/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),dom=require('@vue/compiler-dom'),ts=require('typescript'),sass=require('sass'),{renderToString}=require('@vue/server-renderer')
const helpers=loadMobileUtility('profile-identity'),cache=new Map(),styles=[];let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
function component(name){
    if(cache.has(name))return cache.get(name)
    const file=path.join(plugin,'uni-app/components/cooperation',name+'.vue'),parsed=compiler.parse(fs.readFileSync(file,'utf8'),{filename:file})
    check(parsed.errors.length===0,name+' parses')
    const script=compiler.compileScript(parsed.descriptor,{id:'identity-ui',inlineTemplate:true}),module={exports:{}}
    const result=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}})
    check(!(result.diagnostics||[]).length,name+' transpiles')
    for(const style of parsed.descriptor.styles)styles.push(sass.compileString(style.content,{logger:{warn(){},debug(){}}}).css)
    vm.runInNewContext(`(function(require,module,exports){${result.outputText}\n})`,{console,uni:{setClipboardData(){}},String,Number,Object,Array,Set,Map,Date,Math})(key=>{
        if(key==='vue')return Vue
        if(key==='@/utils/common')return{img:value=>value}
        if(key.endsWith('.png'))return{default:'/synthetic-wing.png'}
        if(key.startsWith('../../utils/'))return loadMobileUtility(path.basename(key))
        if(key.endsWith('.vue'))return{default:component(path.basename(key,'.vue'))}
        throw Error('Unexpected import '+key)
    },module,module.exports)
    cache.set(name,module.exports.default);return module.exports.default
}
const member={member_id:11,member_no:'NIU0000011',nickname:'李四',balance:'12.30',money:'1.25'}
const profile={id:7,name:'李四的店',region_text:'河北省 / 石家庄市 / 长安区',membership:{active:true,display_rank:1,level_code:'ML701',level_name:'青铜会员',used_accounts:2,level_visual:{avatar_effect:true}},cooperation_stats:{outgoing:12,incoming:8}}
async function render(props={}){
    const app=Vue.createSSRApp({render:()=>Vue.h(component('CoopMemberIdentity'),{profile,member,...props})})
    app.component('u-icon',{props:['name','size','color'],render(){return Vue.h('span',{'data-icon':this.name,style:{fontSize:this.size+'px',color:this.color}},this.name==='setting'?'⚙':this.name==='arrow-right'?'›':'')}})
    app.config.warnHandler=()=>{}
    return renderToString(app)
}
check(helpers.profileMemberBalance(member)==='13.55','balance uses same balance+money semantics as framework')
for(const item of [{balance:'bad',money:'1.00'},{balance:'-1',money:'0'},{balance:null,money:null}])check(helpers.profileMemberBalance(item)==='—','unknown money is not presented as zero')
check(helpers.profileMemberNo({member_id:777})==='','never fabricate UID from database ID')
check(helpers.profileIdentityStyle('member')==='member'&&helpers.profileIdentityStyle(undefined)==='store','saved classic style retained, new member version explicit')
const html=await render()
check(html.includes('李四的店')&&html.includes('青铜会员')&&html.includes('NIU0000011'),'store, membership badge and framework UID coexist')
check(html.includes('13.55')&&html.includes('设置与退出登录')&&!html.includes('积分'),'balance and settings, no points')
const ordinary=await render({profile:{}})
check(ordinary.includes('李四')&&ordinary.includes('NIU0000011')&&ordinary.includes('创建门店'),'unpaid member without merchant gets identity and setup entry')
check(!ordinary.includes('门店成员')&&!ordinary.includes('is-member'),'ordinary account does not invent store seats or purchased effects')
const hidden=await render({appearance:{showBalance:0,showSettings:0,showMemberNo:0,showStats:0,showGrade:0,showRegion:0}})
check(!hidden.includes('13.55')&&!hidden.includes('NIU0000011')&&!hidden.includes('设置与退出登录')&&!hidden.includes('青铜会员')&&!hidden.includes('长安区'),'DIY switches remove only requested display information')
const employee=await render({profile:{...profile,permissions:{can_manage_billing:false}}})
check(!employee.includes('门店资料')&&employee.includes('设置与退出登录'),'staff has own settings without owner edit permission')
const long=await render({profile:{...profile,name:'一家名字很长的城市交付合作门店'.repeat(4)},member:{...member,member_no:'NIU0000011111111111'}})
check(long.includes('NIU0000011111111111'),'long identity preserves full source data')
const tree=dom.baseParse(html),find=(node,name)=>{if(String(node.props?.find(p=>p.name==='class')?.value?.content||'').split(/\s+/).includes(name))return node;for(const child of node.children||[]){const result=find(child,name);if(result)return result}return null}
check(!!find(tree,'coop-member-identity__metrics')&&!!find(tree,'coop-member-identity__name-row'),'metrics and name/badge have independent layout groups')
const section=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopProfileDiySection.vue'),'utf8')
check(section.includes("identityStyle==='member'")&&section.includes('<CoopProfilePanel v-else'),'only one member information version renders per DIY component')
if(process.argv.includes('--preview')){
    const output=path.join(root,'output/hsx-lead-profile-member-preview-20261108.html')
    const classic=await render({appearance:{showBalance:1}})
    const document=`<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>会员信息组件 · 本地样式验收</title><style>html{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;background:#f4f6f8}body{margin:0}view{display:block}text{display:inline}button{font:inherit;border:0;cursor:pointer}header{font-size:12px;padding:12px 16px;color:#87929f}main{max-width:430px;margin:0 auto;background:#fff;--primary-color:#1677ff;--lead-diy-title:#253b55;--lead-diy-text:#596b82;--lead-diy-subtle:#8392a7;--lead-diy-border:#e5ebf3}h2{font-size:14px;margin:0;padding:20px 16px 8px;background:#f4f6f8}${styles.join('\n').replace(/([\d.]+)rpx/g,(_,n)=>Number(n)/2+'px')}</style></head><body><header>本地合成数据 · 实际 Vue 组件与样式（图标占位）</header><main><h2>门店会员</h2>${classic}<h2>免费普通用户（尚未建店）</h2>${ordinary}<h2>长门店名称</h2>${long}</main></body></html>`
    fs.writeFileSync(output,document);console.log(output)
}
console.log(`PASS ${checks} member-center checks; actual SSR and styles, synthetic identity only; no member/payment/DB requests.`)
