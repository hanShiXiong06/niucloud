import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Real independent/combined card renders. No live API or saved decoration.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),ts=require('typescript'),{renderToString}=require('@vue/server-renderer')
const store=Vue.reactive({mode:'page',value:[]}),navigations=[],feedback=[],cache=new Map();let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const roleFile='components/cooperation/CoopRoleEntryCard.vue',heroFile='components/diy/lead-cooperation-hero/index.vue'
function component(file,inlineTemplate=false){
    const key=file+inlineTemplate;if(cache.has(key))return cache.get(key)
    const filename=path.join(plugin,'uni-app',file),source=fs.readFileSync(filename,'utf8'),parsed=sfc.parse(source,{filename}),module={exports:{}}
    check(!parsed.errors.length,file+' parses')
    const script=sfc.compileScript(parsed.descriptor,{id:'role-card',inlineTemplate})
    check(!sfc.compileTemplate({source:parsed.descriptor.template.content,filename,id:'role-card',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,file+' template compiles')
    for(const style of parsed.descriptor.styles)check(!sfc.compileStyle({source:style.content,filename,id:'role-card',scoped:true}).errors.length,file+' has valid owned CSS')
    const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,Object,Array,Math,console,uni:{navigateTo:value=>navigations.push(value)}})(key=>{
        if(key==='vue')return{...Vue,onMounted:callback=>callback()}
        if(key==='@/app/stores/diy')return{default:()=>store}
        if(key==='@/utils/common')return{img:value=>'normalized:'+value}
        if(key.endsWith('/utils/interaction-feedback'))return{interactionFeedback:value=>feedback.push(value)}
        if(key.includes('/utils/'))return loadMobileUtility(path.basename(key))
        if(key.endsWith('.png'))return{default:'bundled:'+path.basename(key)}
        if(key.endsWith('CoopRoleEntryCard.vue'))return{default:component(roleFile,true)}
        if(key.endsWith('.vue'))return{default:{render:()=>Vue.h('span')}}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    cache.set(key,module.exports.default);return module.exports.default
}
function setup(file,props){return component(file).setup(props,{expose(){},emit(){}})}
async function html(file,props){const app=Vue.createSSRApp({render:()=>Vue.h(component(file,true),props)});app.config.warnHandler=()=>{};app.component('u-icon',{render:()=>Vue.h('i')});return renderToString(app)}
const a=Vue.reactive({title:'独立找门店',subtitle:'合成说明A',buttonText:'去选门店',buttonStyle:'solid',buttonColor:'#216af0',buttonTextColor:'#fff',borderColor:'#aabbcc',componentStartBgColor:'#edf5ff',componentBgUrl:'store-bg.png',componentBgAlpha:2,topRounded:10,bottomRounded:12,image:'a.png'})
const b=Vue.reactive({title:'独立找客户',subtitle:'合成说明B',buttonText:'查看我的客户',buttonStyle:'link',buttonColor:'#536e9d',buttonTextColor:'#fff',componentStartBgColor:'#fff',image:'b.png'})
const left=setup(roleFile,Vue.reactive({role:'stores',appearance:a})),right=setup(roleFile,Vue.reactive({role:'customers',appearance:b}))
check(left.cardStyle.value.background==='#edf5ff'&&right.cardStyle.value.background==='#fff','each role owns an independent native background')
check(left.frame.value.hasImage&&!right.frame.value.hasImage&&left.cardStyle.value.backgroundImage==="url('normalized:store-bg.png')",'one card background image never appears in the other card')
check(left.cardStyle.value['--lead-diy-button']==='#216af0'&&right.cardStyle.value['--lead-diy-button']==='#536e9d','solid/link button colours are independent')
check(left.cardStyle.value['--lead-diy-border']==='#aabbcc'&&left.cardStyle.value.borderBottomLeftRadius==='24rpx','per-card border and native corner controls reach render')
const roundedCard=setup(roleFile,{role:'stores',appearance:{itemRadius:19}}),nativeRoundedCard=setup(roleFile,{role:'stores',appearance:{itemRadius:19,topRounded:0,bottomRounded:10}})
check(roundedCard.cardStyle.value.borderTopLeftRadius==='38rpx'&&roundedCard.cardStyle.value.borderBottomLeftRadius==='38rpx','nested simple corner setting changes the actual card frame')
check(nativeRoundedCard.cardStyle.value.borderTopLeftRadius==='0rpx'&&nativeRoundedCard.cardStyle.value.borderBottomLeftRadius==='20rpx','standalone official native corner controls retain priority, including zero')
let rendered=await html(roleFile,{role:'stores',appearance:a})
check(rendered.includes('独立找门店')&&rendered.includes('去选门店')&&rendered.includes('is-solid')&&rendered.includes('normalized:a.png'),'store illustration, heading and real solid CTA render together')
check(rendered.includes('normalized:store-bg.png')&&rendered.includes('pointer-events:none'),'native image/mask reaches actual card DOM without intercepting actions')
rendered=await html(roleFile,{role:'customers',appearance:b})
check(rendered.includes('独立找客户')&&rendered.includes('is-link')&&!rendered.includes('store-bg.png'),'customer card independently renders its text CTA and white surface')
a.componentStartBgColor='#123456';a.buttonColor='#234567';a.componentBgUrl='';await Vue.nextTick()
check(left.cardStyle.value.background==='#123456'&&!left.frame.value.hasImage&&right.cardStyle.value.background==='#fff'&&right.cardStyle.value['--lead-diy-button']==='#536e9d','live editing one card leaves the other card untouched and clearing image removes it')
for(const layout of ['classic','compact','clean','soft']){a.layoutPreset=layout;check(left.layout.value===layout,'shared renderer retains '+layout+' preset')}
a.image='';a.layoutPreset='soft';check(left.picture.value==='bundled:store-discovery.png','soft layout preserves original optional artwork')
a.showImage=0;check(left.picture.value==='','show-image off hides artwork without changing action');a.showImage=1;a.usePresetImages=0;check(left.picture.value==='','default imagery may be turned off')
const helper=loadMobileUtility('cooperation-role-entry')
const legacy={storeTitle:'原门店入口',customerTitle:'原客户入口',buttonTextColor:'#fff',buttonColor:'#398aff',componentBgUrl:'combined-only.png',componentStartBgColor:'#fefefe',layoutPreset:'compact',storesAppearance:{componentStartBgColor:'#cceeff',buttonStyle:'link',buttonColor:'#105090'},customersAppearance:{componentStartBgColor:'#fff',buttonStyle:'solid',buttonColor:'#14355e'}}
const one=helper.cooperationRoleAppearance(legacy,'stores'),two=helper.cooperationRoleAppearance(legacy,'customers')
check(one.title==='原门店入口'&&two.title==='原客户入口'&&one.layoutPreset==='compact','old saved combined labels and layout are retained')
check(!one.componentBgUrl&&!two.componentBgUrl&&one.componentStartBgColor==='#cceeff'&&two.componentStartBgColor==='#fff','combined outer frame is not cloned into each independent child override')
const legacyCard=setup(roleFile,{role:'stores',appearance:one})
check(legacyCard.settings.value.buttonStyle==='link'&&legacyCard.cardStyle.value['--lead-diy-button']==='#105090','nested link-colour override reaches the same renderer used by independent cards')
rendered=await html(roleFile,{role:'stores',appearance:one})
check(rendered.includes('is-link')&&rendered.includes('--lead-diy-button:#105090'),'legacy white solid text does not erase the actual rendered blue link colour')
const roleSource=fs.readFileSync(path.join(plugin,'uni-app',roleFile),'utf8')
check(/is-link\s*\{[^}]*color:var\(--lead-diy-button,/.test(roleSource),'link-colour editor and runtime use buttonColor, never legacy solid white text')
const combined=setup('components/diy/lead-cooperation-entry/index.vue',{component:legacy,index:0,global:{}})
check(combined.roleEntries.value[0].appearance.componentStartBgColor==='#cceeff'&&combined.roleEntries.value[1].appearance.buttonColor==='#14355e','combined entry projects both independent overrides into the shared card renderer')
const defaultLegacy=helper.cooperationRoleAppearance({buttonTextColor:'#fff'},'customers'),defaultCard=setup(roleFile,{role:'customers',appearance:defaultLegacy})
check(defaultCard.settings.value.buttonStyle==='link'&&defaultCard.cardStyle.value['--lead-diy-button']!==defaultCard.cardStyle.value['--lead-diy-button-text'],'default old white text remains distinct from the visible link colour')
left.go();right.go();check(navigations.map(value=>value.url).join('|')==='/addon/hsx_lead/pages/stores/index|/addon/hsx_lead/pages/workbench/index','roles retain exactly their real framework page routes')
store.mode='decorate';left.go();right.go();check(navigations.length===2,'decoration cannot navigate or create a business action');store.mode='page'
setup(roleFile,{role:'stores',appearance:{},preview:true}).go();check(navigations.length===2,'explicit preview is read-only outside the editor too')
const heroValue=Vue.reactive({caption:'合成标题前缀',title:'合成主标题',showAccent:1,accentColor:'#2156aa',componentStartBgColor:'#eaf2ff',componentBgUrl:'hero.png',topRounded:6})
const hero=setup(heroFile,{component:heroValue,index:0,global:{}})
check(hero.heroStyle.value.background==='#eaf2ff'&&hero.frame.value.hasImage&&hero.accentStyle.value.backgroundColor==='#2156aa','hero separately owns native background/image and accent colour')
rendered=await html(heroFile,{component:heroValue,index:0,global:{}})
check(rendered.includes('合成标题前缀')&&rendered.includes('合成主标题')&&rendered.includes('lead-cooperation-hero__accent')&&rendered.includes('normalized:hero.png'),'hero text, short emphasis line and background reach the actual DOM')
heroValue.showAccent=0;heroValue.componentBgUrl='';rendered=await html(heroFile,{component:heroValue,index:0,global:{}})
check(!rendered.includes('lead-cooperation-hero__accent')&&!rendered.includes('normalized:hero.png'),'accent and background image are independently removable')
for(const file of ['components/diy/lead-role-entry/index.vue',heroFile]){const value=setup(file,{component:{role:'customers',title:'用户设置'},index:0,global:{}});check(value.settings.value.title==='用户设置','real wrapper consumes independently saved JSON: '+file)}
const build=fs.readFileSync(path.join(plugin,'scripts/build-mobile.mjs'),'utf8')
check(build.includes("['LeadRoleEntry', 'diy-lead-role-entry', 'lead-role-entry']")&&build.includes("['LeadCooperationHero', 'diy-lead-cooperation-hero', 'lead-cooperation-hero']"),'isolated builds register both independently discoverable framework components')
check(!roleSource.includes('cooperationBootstrap')&&!fs.readFileSync(path.join(plugin,'uni-app',heroFile),'utf8').includes('cooperationBootstrap'),'static role/hero blocks add no API requests')
console.log(`PASS ${checks} independent role/hero/combined contracts; actual Vue SSR/setup and native frame projection, no API, DB, browser or decoration writes.`)
