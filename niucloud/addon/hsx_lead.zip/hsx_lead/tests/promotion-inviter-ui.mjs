import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),root=path.resolve(plugin,'../../..'),require=createRequire(path.join(root,'admin/package.json'))
const Vue=require('vue'),ts=require('typescript'),compiler=require('@vue/compiler-sfc')
const read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
let checks=0
function check(ok,label){assert.ok(ok,label);checks++}
function equal(actual,expected,label){assert.deepEqual(JSON.parse(JSON.stringify(actual)),expected,label);checks++}
function moduleOf(source,deps={}){
    const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{Date,Math,Number,String,Object,Array,Set,Map,JSON,Promise,console})(key=>{
        if(key in deps)return deps[key]
        if(key.endsWith('.vue'))return{default:{}}
        throw Error('Unexpected promotion inviter import: '+key)
    },module,module.exports)
    return module.exports
}
function sfc(file){
    const parsed=compiler.parse(read(file),{filename:file});equal(parsed.errors,[],file+' parses')
    const script=compiler.compileScript(parsed.descriptor,{id:'promotion-inviter-test'})
    equal(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'promotion-inviter-test',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors,[],file+' template compiles')
    for(const style of parsed.descriptor.styles)equal(compiler.compileStyle({source:style.content,filename:file,id:'promotion-inviter-test',scoped:style.scoped}).errors,[],file+' local style compiles')
    return{script:script.content,raw:parsed.descriptor.scriptSetup.content,template:parsed.descriptor.template.content}
}
const inviterSfc=sfc('admin/views/promotion/PromotionInviters.vue'),relationsSfc=sfc('admin/views/promotion/PromotionRelations.vue'),indexSfc=sfc('admin/views/promotion/index.vue')
for(const file of ['PromotionInviters.vue','PromotionRelations.vue','index.vue'])check(read('admin/views/promotion/'+file)===fs.readFileSync(path.join(root,'admin/src/addon/hsx_lead/views/promotion',file),'utf8'),'canonical and installed source match: '+file)
const apiCalls=[]
const api=moduleOf(read('admin/api/promotion.ts'),{'@/utils/request':{default:{get:(...args)=>{apiCalls.push(args);return Promise.resolve({data:{}})}}}})
await api.getPromotionInviters({keyword:'0001',role:'provider',page:2,limit:20})
check(apiCalls[0][0]==='hsx_lead/promotion/relations'&&apiCalls[0][1].params.view==='inviters'&&apiCalls[0][1].params.page===2,'summary reuses the authorized read-only relations endpoint with explicit view')
const row=(id=7)=>({member_id:id,member_no:'000'+id,name:'合成推广人'+id,mobile_masked:'188****0001',role:'normal',direct_invite_count:0,paid_invitee_count:0,review_invitee_count:0,promotion:{pending:'0.00',settled:'0.00',held:'0.00',cancelled:'0.00',total:'0.00',review_required:false}})
const page=rows=>({data:{data:rows,total:rows.length,current_page:1,per_page:20,scope:{relations:'current_direct',rewards:'lifetime_original_provider'}}})
function fixture(kind='inviters',props={}){
    const calls=[],emitted=[],mounted=[],unmounted=[]
    let work=async()=>page([row()])
    const hooks={...Vue,onMounted:fn=>mounted.push(fn),onBeforeUnmount:fn=>unmounted.push(fn)}
    const source=kind==='inviters'?inviterSfc:relationsSfc
    const readApi=kind==='inviters'?'getPromotionInviters':'getPromotionRelations'
    const deps={vue:hooks,'@element-plus/icons-vue':{Search:{},Right:{}},'../../api/promotion':{[readApi]:async query=>{calls.push(JSON.parse(JSON.stringify(query)));return work(query)}},'../../composables/cooperation':{coopError:(cause,fallback)=>cause?.message||fallback,coopMoney:value=>'¥'+Number(value).toFixed(2)},'../../composables/useLeadUi':{timestampParts:value=>({full:String(value)})}}
    const input=Vue.reactive(props),state=moduleOf(source.script,deps).default.setup(input,{emit:(...args)=>emitted.push(args),expose(){}})
    return{state,input,calls,emitted,mounted,unmounted,set work(value){work=value}}
}
let f=fixture('inviters',{canViewRewards:false}),s=f.state
check(!f.calls.length&&!s.rows.value.length,'construction does not fabricate data or request before mount')
await s.load();check(f.calls.length===1&&s.rows.value.length===1&&s.total.value===1&&!s.error.value&&!s.loading.value,'server-confirmed zero statistics are valid rows, not treated as empty data')
check(s.count(0)==='0'&&s.count(undefined)==='待核对'&&s.money('0.00')==='¥0.00'&&s.money(null)==='待核对','zero and unavailable values remain distinguishable')
Object.assign(s.query,{page:8,keyword:'0001',role:'provider'});await s.search();check(f.calls.at(-1).page===1&&f.calls.at(-1).role==='provider'&&s.hasFilters.value,'search resets page but preserves the selected identity')
await s.changePage({page:2,limit:50});equal(f.calls.at(-1),{keyword:'0001',role:'provider',provider_member_id:'',page:2,limit:50},'pagination carries all current filters')
await s.reset();equal(f.calls.at(-1),{keyword:'',role:'',provider_member_id:'',page:1,limit:50},'reset clears every narrowing condition and retains page size')
s.showRelations(row(7));equal(f.emitted.at(-1),['relations',{member_id:7,name:'合成推广人7',member_no:'0007'}],'invitation drill-down carries the precise member ID rather than a fuzzy nickname')
s.showRelations(row(7),true);check(f.emitted.at(-1)[1].payment_state==='paid','paid invitee count opens the same precise relationship list with paid-only state')
const beforeRewards=f.emitted.length;s.showRewards(row(7));check(f.emitted.length===beforeRewards,'relation-only permission does not expose the reward-ledger action')
f.input.canViewRewards=true;s.showRewards(row(7));equal(f.emitted.at(-1),['rewards',{member_id:7,name:'合成推广人7',member_no:'0007'}],'reward drill-down uses provider ID, not current payer relationship')
f.work=async()=>{throw Error('合成读取失败')};await s.load();check(s.error.value==='合成读取失败'&&!s.rows.value.length&&s.total.value===0&&!s.loading.value,'network failure is explicit and clears misleading stale statistics')
f.work=async()=>page([{...row(),paid_invitee_count:undefined}]);await s.load();check(s.error.value.includes('未完整返回')&&!s.rows.value.length,'missing counts are not converted into fake zero')
f.work=async()=>page([row()]);await s.load();check(!s.error.value&&s.rows.value.length===1,'retry recovers through a new real read')
let resolveOld,resolveNew;f.work=query=>new Promise(resolve=>query.keyword==='old'?resolveOld=resolve:resolveNew=resolve)
s.query.keyword='old';const old=s.load();s.query.keyword='new';const fresh=s.load();resolveNew(page([row(8)]));await fresh;resolveOld(page([row(9)]));await old;check(s.rows.value[0].member_id===8,'late old search cannot overwrite the current query result')
let resolveHidden;f.work=()=>new Promise(resolve=>{resolveHidden=resolve});const hidden=s.load();f.unmounted.forEach(fn=>fn());resolveHidden(page([row(10)]));await hidden;check(s.rows.value[0].member_id===8,'unmounted summary does not accept a late response')

f=fixture('relations',{initialInviter:{member_id:7,name:'精确推广人',member_no:'0007',payment_state:'paid'}})
f.work=async()=>({data:{data:[],total:0,summary:{relation_count:0,paid_count:0,service_net:'0.00',promotion_total:'0.00'},filters:{payment_states:[],membership_states:[]}}})
f.mounted.forEach(fn=>fn());await Promise.resolve();await Promise.resolve()
check(f.calls[0].inviter_member_id===7&&f.calls[0].payment_state==='paid'&&f.calls[0].keyword==='','relations mount respects the supplied exact inviter and paid filter')
await f.state.clearInviter();check(f.calls.at(-1).inviter_member_id==='','selected relationship person can be removed with one clear action')

const actor=Vue.reactive({permissions:['hsx_lead_promotion_relations','hsx_lead_promotion_rewards']}),ledgerCalls=[]
const methods=['getPromotionConfig','savePromotionConfig','getPromotionProviders','savePromotionProvider','reviewPromotionProvider','getPromotionRewards','settlePromotionRewards','holdPromotionReward','resumePromotionReward','retryPromotionPayment']
const apiMock=Object.fromEntries(methods.map(name=>[name,async args=>{ledgerCalls.push({name,args});return{data:{data:[],total:0,payment_reviews:{data:[],total:0}}}}]))
const parent=moduleOf(indexSfc.raw+'\nexport {tab,rewardQuery,rewardDates,rewardInviterName,selectedInviter,showInviterRelations,showInviterRewards,clearRewardInviter,loadTab}',{
    vue:{...Vue,onMounted(){},onBeforeUnmount(){}},'@element-plus/icons-vue':{Refresh:{}},'element-plus':{ElMessage:{success(){},warning(){}},ElMessageBox:{}},'@/stores/modules/user':{default:()=>actor},'../../composables/navigation':{hasLeadPagePermission:(user,key)=>user.permissions.includes(key)},'../../composables/cooperation':{coopError:(cause,fallback)=>cause?.message||fallback,coopMoney:value=>String(value),coopTime:value=>String(value)},'../../api/promotion':apiMock
})
parent.showInviterRelations({member_id:7,name:'同名会员',payment_state:'paid'});check(parent.tab.value==='relations'&&parent.selectedInviter.value.member_id===7,'parent mounts the relationship component with selected member context')
Object.assign(parent.rewardQuery,{keyword:'old',status:'held',source:'maintenance',page:4});parent.rewardDates.value=['1','2'];parent.showInviterRewards({member_id:7,name:'同名会员'});check(parent.tab.value==='rewards'&&parent.rewardQuery.provider_member_id===7&&parent.rewardQuery.page===1&&parent.rewardQuery.keyword===''&&parent.rewardDates.value.length===0,'ledger drill-down clears unrelated filters and narrows by immutable provider ID')
await parent.loadTab();check(ledgerCalls.at(-1).args.provider_member_id===7,'the actual ledger read receives the selected provider ID')
await parent.clearRewardInviter();check(ledgerCalls.at(-1).args.provider_member_id===''&&parent.rewardInviterName.value==='','clearing the person capsule immediately reloads the full ledger')
actor.permissions=['hsx_lead_promotion_relations'];const previousTab=parent.tab.value;parent.showInviterRewards({member_id:8});check(parent.tab.value===previousTab&&parent.rewardQuery.provider_member_id==='','parent rechecks ledger permission before switching context')
check(indexSfc.template.includes('label="推广人汇总"')&&read('admin/views/promotion/index.vue').includes("canRelations.value?'inviters'"),'summary is the first visible default tab for authorized administrators')
check(inviterSfc.template.includes('已入账不代表已提现')&&!inviterSfc.template.includes('已提现金额')&&read('admin/views/promotion/PromotionInviters.vue').includes("label:'已结算'"),'summary explains the boundary without claiming bank settlement or inventing a withdrawal ledger')
console.log(`PASS ${checks} per-inviter admin UI checks; actual Vue state/API contract/SFC compile with synthetic reads only.`)
