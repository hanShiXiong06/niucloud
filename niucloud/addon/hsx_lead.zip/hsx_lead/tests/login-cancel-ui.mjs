import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..'),mobile=path.join(workspace,'uni-app/src')
const require=createRequire(path.join(workspace,'uni-app/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),pre=require('@dcloudio/uni-cli-shared')
pre.initPreContext('mp-weixin')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++},read=file=>fs.readFileSync(file,'utf8')
function execute(source,deps,globals={}){const module={exports:{}},js=ts.transpileModule(viteFixture(pre.preJs(source)),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${js}\n})`,globals)(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports);return module.exports}
const home='/app/pages/index/index',stores='/addon/hsx_lead/pages/stores/index',workbench='/addon/hsx_lead/pages/workbench/index',task='/addon/hsx_lead/pages/task/index',auth='/app/pages/auth/index',form='/app/pages/auth/login'
function world(){
    const storage=new Map([['some_business_draft',{keep:true}]]),calls=[],timers=new Map(),native=[];let timer=0,token='',pages=[{route:home.slice(1)}],authWork=()=>Promise.resolve({data:{token:'synthetic-token'}})
    const runtime={getStorageSync:key=>storage.get(key),setStorageSync:(key,value)=>storage.set(key,value),removeStorageSync:key=>storage.delete(key),getStorage:({key,success,fail})=>storage.has(key)?success({data:storage.get(key)}):fail({}),showToast:args=>calls.push({type:'toast',...args}),setNavigationBarTitle(){},showLoading(){},hideLoading(){},navigateBack:args=>{calls.push({type:'back',delta:args.delta});if(runtime.backFails)args.fail?.();else pages=pages.slice(0,-args.delta)},backFails:false}
    const redirect=options=>{calls.push({type:'redirect',...options});const page={route:options.url.replace(/^\//,'').split('?')[0]};if(options.mode==='reLaunch')pages=[page];else if(options.mode==='redirectTo')pages=[...pages.slice(0,-1),page];else pages.push(page)}
    const common={redirect,getSiteId:()=>100005,getToken:()=>token,currRoute:()=>pages.at(-1)?.route||'',isWeixinBrowser:()=>false,urlDeconstruction:()=>({query:{}}),img:value=>value,pxToRpx:value=>value}
    const pageTools={getFirstPage:()=>home,getAppPages:()=>[home,auth,form,'/app/pages/auth/agreement'],getSubPackagesPages:()=>[stores,workbench,task,'/addon/hsx_lead/pages/membership/index'],getNeedLoginPages:()=>[task,'/addon/hsx_lead/pages/membership/index'],getTabbarPages:()=>[home,stores,workbench]}
    const config={login:{is_username:true,is_mobile:false,is_auth_register:false,is_bind_mobile:false,agreement_show:false},getLoginConfig:async()=>{}}
    const system={initStatus:'finish',menuButtonInfo:{},systemInfo:{platform:'ios'},getSiteInfoFn:async()=>{},getMemberMobileExistFn:async()=>{}}
    const member={info:{mobile:'19900000000'},setToken:(value,callback)=>{calls.push({type:'setToken'});token=value;callback?.()}}
    const globals={console,Set,String,Number,Object,getCurrentPages:()=>pages,uni:runtime,wx:{login:options=>native.push(options),getPrivacySetting(){}},setTimeout:fn=>{timers.set(++timer,fn);return timer},clearTimeout:id=>timers.delete(id)}
    const api={weappLogin:()=>authWork(),updateWeappOpenid(){},updateWechatOpenid(){},wechatUser(){},wechatUserLogin(){},updateWechatOpenidByH5(){},wxappLogin(){}}
    const login=execute(read(path.join(mobile,'hooks/useLogin.ts')),{'@/utils/common':common,'@/utils/pages':pageTools,'@/app/api/auth':api,'@/app/api/system':{},'@/stores/member':{default:()=>member},'@/stores/config':{default:()=>config},'@/stores/system':{default:()=>system},vue:Vue},globals)
    function flush(){let count=0;while(timers.size&&count++<20){const batch=[...timers];timers.clear();for(const[,run]of batch)run()}}
    return{storage,calls,runtime,globals,common,pageTools,config,system,member,login,native,flush,setPages:values=>pages=values.map(route=>({route:route.replace(/^\//,'')})),getPages:()=>pages,authWork:work=>authWork=work,setToken:value=>token=value}
}
{
    const w=world();w.setPages([home,task,auth,form]);w.storage.set('loginBack',{url:task,param:{task:'profile-edit'}});w.login.useLogin().cancelLogin()
    check(w.calls[0].type==='back'&&w.calls[0].delta===3,'cancel skips protected task and every auth page to the nearest public page')
    check(!w.storage.has('loginBack')&&w.storage.get('some_business_draft').keep,'cancel clears only login return state, not business drafts')
    check(w.login.useLogin().isLoginCancelled(),'cancellation survives another hook instance for guest entry pages')
}
{
    const w=world();w.setPages([auth]);w.login.useLogin().cancelLogin();check(w.calls[0].url===home&&w.calls[0].mode==='reLaunch','root auth cancellation uses the registered framework first page, not a hard-coded plugin')
    w.setPages([stores,auth]);w.runtime.backFails=true;w.calls.length=0;w.login.useLogin().cancelLogin();check(w.calls.some(call=>call.type==='redirect'&&call.url===home),'failed navigateBack has a real public fallback')
}
{
    const w=world(),flow=w.login.useLogin();w.setPages([stores]);flow.setLoginBack({url:stores,param:{from:'lead'}});flow.cancelLogin();w.flush();check(!w.calls.some(call=>call.url===auth||call.url===form),'cancel invalidates an already scheduled login redirect')
    w.calls.length=0;flow.setLoginBack({url:stores,param:{from:'lead'}});w.flush();check(w.calls.some(call=>call.url===form),'a new explicit login is not permanently suppressed by an earlier cancellation')
    const active=w.login.useLogin();active.beginLogin();w.setToken('synthetic-token');active.handleLoginBack();check(w.calls.at(-1).url===stores&&w.calls.at(-1).param.from==='lead','successful login preserves the original return page and query')
}
{
    const w=world(),flow=w.login.useLogin();let finish;w.authWork(()=>new Promise(resolve=>finish=resolve));flow.beginLogin();flow.authLogin({code:'synthetic-code',backFlag:true});flow.cancelLogin();finish({data:{token:'late-token'}});await Promise.resolve();await Promise.resolve();check(!w.calls.some(call=>call.type==='setToken'),'cancelled authentication cannot install a late response token')
    const newer=w.login.useLogin();newer.beginLogin();const count=w.calls.length;flow.handleLoginBack();check(w.calls.length===count,'an obsolete hook cannot navigate a newer login flow')
}
{
    const w=world(),flow=w.login.useLogin();flow.beginLogin();flow.getAuthCode({backFlag:true});flow.cancelLogin();let requests=0;w.authWork(()=>{requests++;return Promise.resolve({data:{token:'should-not-request'}})});w.native[0].success({code:'late-native-code'});await Promise.resolve();check(requests===0,'late wx.login result does not start authentication after cancellation')
}
{
    const w=world();w.setPages([task]);let starts=0;const authModule=execute(read(path.join(mobile,'utils/auth.ts')),{'@/hooks/useLogin':{useLogin:()=>({setLoginBack:()=>starts++})},'@/utils/common':w.common,'@/utils/pages':w.pageTools},w.globals)
    authModule.checkNeedLogin({path:task,query:{task:'publish'}});w.setPages([stores]);w.flush();check(starts===0,'stale required-page timer cannot reopen login after returning to a public page')
    w.setPages([task]);authModule.checkNeedLogin({path:task,query:{}});w.setToken('synthetic-token');w.flush();check(starts===0,'login acquired during the delay cancels the automatic redirect')
    w.setToken('');authModule.checkNeedLogin({path:task,query:{}});w.flush();check(starts===1,'a current protected route still requires login')
}
function page(file,w){
    const filename=path.join(mobile,file),parsed=compiler.parse(read(filename),{filename}),script=compiler.compileScript(parsed.descriptor,{id:'login-cancel'})
    check(!parsed.errors.length&&!compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'login-cancel',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,file+' actual login template compiles')
    check(parsed.descriptor.template.content.includes(':customBack="cancelLogin"')&&parsed.descriptor.template.content.includes('暂不登录'),file+' has an explicit native-header and visible cancel action')
    const loads=[],shows=[],deps={'vue':{...Vue,onMounted(){}},'@dcloudio/uni-app':{onLoad:fn=>loads.push(fn),onShow:fn=>shows.push(fn)},'@/app/api/auth':{},'@/stores/member':{default:()=>w.member},'@/stores/config':{default:()=>w.config},'@/hooks/useLogin':w.login,'@/locale':{t:key=>key},'@/utils/common':w.common,'@/utils/topTabbar':{topTabar:()=>({setTopTabbarParam:()=>({}),getScrollBool:()=>-1})},'@/stores/system':{default:()=>w.system}}
    const component=execute(script.content,deps,w.globals),state=component.default.setup({},{expose(){}})
    return{state,load:options=>Promise.all(loads.map(fn=>fn(options||{}))),show:()=>shows.forEach(fn=>fn()),template:parsed.descriptor.template.content}
}
for(const file of ['app/pages/auth/index.vue','app/pages/auth/login.vue']){
    const w=world();w.setPages([stores,file.includes('/login.vue')?form:auth]);let finish;w.config.getLoginConfig=()=>new Promise(resolve=>finish=resolve);const p=page(file,w),loading=p.load({type:'username'});await Promise.resolve();await Promise.resolve();await Promise.resolve();p.state.cancelLogin();if(finish)finish();await loading;w.flush();check(!w.calls.some(call=>call.url===auth||call.url===form),'configuration completing after cancel does not redirect '+file)
}
{
    const w=world();w.setPages([form]);w.config.getLoginConfig=async()=>{throw Error('synthetic configuration failure')};const p=page('app/pages/auth/login.vue',w);await p.load();check(!p.state.type.value&&!!p.state.loginConfigError.value,'failed ordinary-login configuration leaves an explicit retry state')
    check(!p.template.match(/<view[^>]+v-if="type"[^>]*>\s*<!-- #ifdef/),'ordinary login header/cancel are not conditional on the unavailable login type');p.state.cancelLogin();check(w.calls.at(-1).url===home,'configuration failure still allows actual cancellation')
}
{
    const w=world();w.setPages([auth]);let finish,memberReads=0;w.system.getSiteInfoFn=()=>new Promise(resolve=>finish=resolve);w.system.getMemberMobileExistFn=async()=>{memberReads++}
    const index=page('app/pages/auth/index.vue',w),oldLoad=index.load();w.setPages([auth,form]);const ordinary=page('app/pages/auth/login.vue',w);await ordinary.load({type:'username'});check(!index.state.login.isCurrentLogin(),'switching login methods invalidates the previous page session')
    w.setPages([auth]);index.show();check(index.state.login.isCurrentLogin(),'returning to the already mounted quick-login page establishes a usable current session')
    finish();await oldLoad;check(memberReads===0,'returning onShow cannot revive the old async onLoad continuation')
    index.state.cancelLogin();index.show();check(w.login.useLogin().isLoginCancelled(),'a stale onShow after cancellation cannot restart login on a public route')
    w.setPages([form]);ordinary.show();check(ordinary.state.loginFlow.isCurrentLogin(),'an explicitly revisited ordinary-login page can start another valid login')
}
// Execute the real collaboration component with anonymous identity. Only its
// public policy endpoint is permitted; all private reads are counted as errors.
function guest(required=false,role='stores',taskName=''){
    const w=world(),calls=[];w.setPages([role==='stores'?stores:workbench]);const routes={deliveries:workbench,stores,wallet:'/addon/hsx_lead/pages/wallet/index',profile:'/addon/hsx_lead/pages/profile/index'}
    const api={cooperationPageUrls:routes,cooperationAccess:async()=>{calls.push('access');return{data:{login_required:required,erp_visible:true,services:[]}}},cooperationBootstrap:async()=>{calls.push('PRIVATE bootstrap');throw Error('Guest private read')},cooperationLeads:async()=>{calls.push('PRIVATE list');throw Error('Guest private read')},coopError:error=>error.message}
    const hook=execute(read(path.join(plugin,'uni-app/composables/useCooperation.ts')),{vue:Vue,'@/utils/common':w.common,'../api/cooperation':api},w.globals)
    const file=path.join(plugin,'uni-app/components/cooperation/CooperationWorkbench.vue'),parsed=compiler.parse(read(file),{filename:file}),script=compiler.compileScript(parsed.descriptor,{id:'guest-list'})
    // Only expose the framework's original login navigation API to the plugin.
    // The real, extended hook remains available to the independent cancel/back
    // tests above; this catches deployment with an unextended framework hook.
    const pluginLogin={useLogin:()=>({setLoginBack:data=>w.login.useLogin().setLoginBack(data)})}
    const deps={vue:{...Vue,onMounted(){},onBeforeUnmount(){}},'@/utils/common':w.common,'@/hooks/useLogin':pluginLogin,'../../composables/useCooperationSubscribe':{useCooperationSubscribe:()=>({loading:Vue.ref(false),})},'../../composables/useCooperation':hook,'../../api/cooperation':api,'../../utils/mobile-ui':{},'../../utils/cooperation-navigation':{cooperationTaskUrl:task},'../../utils/cooperation-business':{},'../../utils/cooperation-payment':{},'../../utils/entity-membership':{}}
    deps['../../utils/cooperation-payment-orders']=loadMobileUtility('cooperation-payment-orders')
    const component=execute(script.content,deps,w.globals),state=component.default.setup({initialTab:role==='stores'?'stores':'deliveries',initialDirection:role==='stores'?'outgoing':'incoming',initialId:0,initialPaymentId:0,initialInviter:0,task:taskName},{expose(){}})
    return{w,calls,state,pluginLogin}
}
for(const role of ['stores','workbench']){
    const f=guest(false,role);await f.state.initialize();f.w.flush();check(f.calls.join(',')==='access'&&!f.w.calls.some(call=>call.type==='redirect'),'guest '+role+' reads only public presentation metadata and remains browseable')
    check(Object.keys(f.pluginLogin.useLogin()).join(',')==='setLoginBack'&&!f.state.ui.error.value,'guest '+role+' works with the unextended framework hook instead of depending on isLoginCancelled')
    check(f.state.showFrameworkTabbar.value,'guest '+role+' retains the existing framework bottom navigation to public pages')
    f.state.guestAction({kind:role==='stores'?'publish':'accept',business_type:'purchase'});f.w.flush();check(f.w.calls.some(call=>call.url===form),'guest '+role+' can explicitly open real login from its business action')
    f.w.login.useLogin().cancelLogin();await f.state.initialize();f.w.flush();check(f.w.calls.filter(call=>call.url===form).length===1&&!f.calls.some(call=>call.startsWith('PRIVATE')),'cancel returns to '+role+' without private data reads or repeat login')
}
for(const role of ['stores','workbench']){
    const f=guest(true,role);await f.state.initialize();f.w.flush();check(!f.w.calls.some(call=>call.url===auth||call.url===form)&&!f.state.ui.error.value,'enabled legacy entry policy never forces guest '+role+' into login')
    await f.state.refresh();f.w.flush();check(f.calls.every(value=>value==='access')&&!f.w.calls.some(call=>call.type==='redirect'),'refresh remains public even with login policy enabled for '+role)
    f.state.guestAction({kind:role==='stores'?'publish':'accept',business_type:'purchase'});f.w.flush();check(f.w.calls.filter(call=>call.url===form).length===1,'only an explicit business action opens real login for '+role)
    f.w.login.useLogin().cancelLogin();f.state.pausePage();await f.state.initialize();f.w.flush();check(f.w.calls.filter(call=>call.url===form).length===1,'cancel/back returns to public '+role+' without another login')
    f.state.ui.direction.value=role==='stores'?'incoming':'outgoing';await f.state.initialize();f.w.flush();check(f.w.calls.filter(call=>call.url===form).length===1&&!f.calls.some(call=>call.startsWith('PRIVATE')),'role switching after cancel stays public and private reads remain protected for '+role)
    f.state.guestAction({kind:role==='stores'?'stores':'customers'});f.w.flush();check(f.w.calls.filter(call=>call.url===form).length===2,'explicit business retry remains available after cancellation for '+role)
}
{
    const f=guest(false,'stores','publish');await f.state.initialize();f.w.flush();check(!f.calls.length&&f.w.calls.some(call=>call.url===form),'actual private tasks keep authentication and never rely on the public entry switch')
}
for(const platform of ['h5','mp-weixin']){
    pre.initPreContext(platform)
    for(const role of ['stores','workbench']){
        const f=guest(true,role);await f.state.initialize();await f.state.refresh();f.w.flush()
        check(!f.state.ui.error.value&&!f.w.calls.some(call=>call.type==='redirect')&&f.calls.every(value=>value==='access'),platform+': '+role+' accepts a legacy flags-only public response and never depends on cancellation extensions')
        f.state.guestAction({kind:'publish',business_type:'purchase'});f.w.flush()
        check(f.w.calls.filter(call=>call.url===form).length===1,platform+': actual guest action uses the framework login route')
        f.w.login.useLogin().cancelLogin();f.state.pausePage();await f.state.initialize();f.w.flush()
        check(f.w.calls.filter(call=>call.url===form).length===1&&!f.calls.some(call=>call.startsWith('PRIVATE')),platform+': cancel/back leaves '+role+' publicly browseable without automatic retry or private reads')
    }
}
console.log(`PASS ${checks} login-cancel and guest-entry checks; actual framework hooks/SFC with H5/MP guest entry, synthetic navigation only, no HTTP/login/credentials.`)
