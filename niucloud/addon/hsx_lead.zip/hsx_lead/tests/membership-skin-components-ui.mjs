import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Actual paid-state presentation, synthetic props only. No payment or API calls.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),ts=require('typescript'),{renderToString}=require('@vue/server-renderer')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++},cache=new Map()
function component(name,inlineTemplate=true){
    if(inlineTemplate&&cache.has(name))return cache.get(name)
    const filename=path.join(plugin,'uni-app/components/cooperation',name+'.vue'),source=fs.readFileSync(filename,'utf8'),parsed=sfc.parse(source,{filename})
    check(!parsed.errors.length,name+' parses')
    for(const style of parsed.descriptor.styles)check(!sfc.compileStyle({source:style.content,filename,id:'skin',scoped:true}).errors.length,name+' owns valid scoped CSS')
    const script=sfc.compileScript(parsed.descriptor,{id:'skin',inlineTemplate})
    const code=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,module={exports:{}}
    vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{Number,Object,String,Array,Math,Date,console})(key=>{
        if(key==='vue')return Vue
        if(key==='@/utils/common')return{img:value=>'local:'+value}
        if(key.startsWith('../../utils/'))return loadMobileUtility(path.basename(key))
        if(key.endsWith('.png'))return{default:'/local-wing.png'}
        if(key.endsWith('.vue'))return{default:key.includes('CoopLevelBadge')?component('CoopLevelBadge'):{render:()=>Vue.h('span')}}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    if(inlineTemplate)cache.set(name,module.exports.default)
    return module.exports.default
}
async function html(name,props){const app=Vue.createSSRApp({render:()=>Vue.h(component(name),props)});app.config.warnHandler=()=>{};app.component('u-icon',{render:()=>Vue.h('i')});return renderToString(app)}
const custom={preset:'custom',start_color:'#123456',end_color:'#456789',text_color:'#ffffff',accent_color:'#217590',angle:82,avatar_effect:true}
for(const active of [false,undefined,0,1,'true','false']){
    const out=await html('CoopMerchantAvatar',{name:'未生效门店',rank:8,active,appearance:custom,highlighted:true})
    check(!out.includes('is-member')&&!out.includes('is-highlighted')&&!out.includes('--lead-member-'),'appearance and selected rank do not grant a paid avatar: '+String(active))
    check(!out.includes('coop-merchant-avatar__halo')&&!out.includes('coop-merchant-avatar__glint'),'inactive avatar has no premium motion or light')
}
for(const rank of [0,-1,'8',NaN,Infinity]){
    const out=await html('CoopMerchantAvatar',{rank,active:true,appearance:custom,highlighted:true})
    check(!out.includes('is-member')&&!out.includes('coop-merchant-avatar__wing'),'invalid visual rank remains neutral: '+String(rank))
}
let out=await html('CoopMerchantAvatar',{rank:8,active:true,appearance:custom,highlighted:true,image:'owned-store.jpg'})
check(out.includes('is-member')&&out.includes('is-highlighted')&&out.includes('local:owned-store.jpg'),'active tier retains real storefront photo and optional wings')
check(out.includes('--lead-member-gradient:linear-gradient(82deg,#123456,#456789)')&&out.includes('--lead-member-accent:#217590'),'avatar consumes the exact configured skin instead of a hardcoded gold palette')
check(out.includes('coop-merchant-avatar__halo')&&out.includes('coop-merchant-avatar__glint'),'explicit active effect allows gentle halo and glint')
out=await html('CoopMerchantAvatar',{rank:8,active:true,appearance:{...custom,avatar_effect:false},highlighted:true})
check(out.includes('is-member')&&!out.includes('is-highlighted')&&!out.includes('coop-merchant-avatar__halo')&&!out.includes('coop-merchant-avatar__glint'),'effect opt-out preserves only the static paid border and suppresses all VIP motion')
out=await html('CoopMerchantAvatar',{rank:2,active:true,appearance:custom,highlighted:false})
check(out.includes('has-effect')&&out.includes('coop-merchant-avatar__halo')&&!out.includes('coop-merchant-avatar__wing'),'halo does not force high-tier wings')
for(const state of ['locked','expired']){
    out=await html('CoopLevelBadge',{level:8,label:'城市合伙门店',state,animated:true,appearance:custom,variant:'inline'})
    check(out.includes('城市合伙门店')&&out.includes(state==='locked'?'未开通':'已到期')&&!out.includes('is-animated'),'target/expired name always includes actual ownership state')
    check(state==='locked'?out.includes('--lead-member-start:#123456'):!out.includes('--lead-member-start'),'only the unowned plan may preview color; expired identity is neutral')
}
out=await html('CoopLevelBadge',{level:0,state:'active',appearance:custom,animated:true})
check(out.includes('普通会员')&&!out.includes('--lead-member-start')&&!out.includes('is-glowing'),'ordinary badge cannot acquire a configured paid skin')
out=await html('CoopLevelBadge',{level:18,label:'旗舰交付中心',state:'active',appearance:custom,variant:'inline',animated:true})
check(out.includes('level-18')&&out.includes('>旗舰交付中心</text>')&&!out.includes('>V18</text>'),'arbitrary tier count and exact configured name are retained')
check(out.includes('--lead-member-start:#123456')&&out.includes('is-animated'),'active badge uses the same paid palette and opt-in effect')
out=await html('CoopLevelBadge',{level:18,state:'active',appearance:{...custom,avatar_effect:false},animated:true})
check(!out.includes('is-animated')&&!out.includes('coop-level-badge__edge'),'badge effect respects the same explicit effect opt-out')
out=await html('CoopMembershipEntry',{profile:{entity_membership:{active:true,level_code:'ML18',display_rank:18,level_name:'旗舰交付中心',level_visual:custom,expires_at:1900000000}},appearance:{}})
check(out.includes('--lead-member-start:#123456')&&out.includes('旗舰交付中心'),'personal membership entry passes the actual subject palette to its badge')
const entity=fs.readFileSync(path.join(plugin,'uni-app/pages/entity/index.vue'),'utf8')
check(entity.includes(':appearance="membership.level_visual"'),'entity overview forwards its server-owned display palette without inventing another level')
const reactive=Vue.reactive({rank:8,active:true,highlighted:true,appearance:custom}),scope=Vue.effectScope()
const avatar=scope.run(()=>component('CoopMerchantAvatar',false).setup(reactive,{expose(){}}))
check(avatar.showEffect.value&&avatar.showHighlight.value,'actual reactive setup begins in active visual state')
reactive.active=false;await Vue.nextTick()
check(!avatar.showMember.value&&!avatar.showHighlight.value&&Object.keys(avatar.skinStyle.value).length===0,'expiry/payment-state refresh immediately removes paid visual variables and effects')
reactive.active=true;reactive.appearance={...custom,start_color:'#abcdef',avatar_effect:false};await Vue.nextTick()
check(avatar.skinStyle.value['--lead-member-start']==='#abcdef'&&!avatar.showEffect.value,'live catalog color/effect changes do not need a remount')
scope.stop()
for(const name of ['CoopMerchantAvatar','CoopLevelBadge']){
    const source=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation',name+'.vue'),'utf8')
    check(source.includes('prefers-reduced-motion')&&source.includes('animation: none'),name+' honors system reduced motion')
    check(!/navigateTo|request\(|fetch\(|setInterval|setTimeout|v-html/.test(source),name+' never grants rights or triggers a business action')
}
console.log(`PASS ${checks} membership skin component checks; actual Vue setup/SSR with synthetic state, no API, payment, DB or browser writes.`)
