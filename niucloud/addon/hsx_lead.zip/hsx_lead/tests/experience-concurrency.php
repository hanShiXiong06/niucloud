<?php
declare(strict_types=1);
// Independent real MySQL workers, disposable localhost schema, synthetic receipts.
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,CooperationService,EntityExperienceService,EntityMembershipService,PartnerService,PaymentService,Store,TeamService};
use app\dict\pay\{PayDict,RefundDict};
use core\exception\CommonException;
use think\facade\Db;

$checks=0;
function ecCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function ecChild():void{
    try{
        $p=json_decode((string)fgets(STDIN),true,32,JSON_THROW_ON_ERROR);$schema=$p['schema']??'';$db=$p['database']??[];$connection=$db['connections']['mysql']??[];
        if(!preg_match('/^hsx_lead_test_[a-f0-9]{16}$/D',(string)$schema)||($connection['hostname']??'')!=='127.0.0.1'||($connection['database']??'')!==$schema||($connection['prefix']??'')!=='lt_'||($db['default']??'')!=='mysql'||!empty($connection['deploy'])||($p['site']??0)!==900000031||!preg_match('/^[a-f0-9]{64}$/D',(string)($p['auth_key']??'')))throw new RuntimeException('Unsafe worker payload');
        $root=dirname(__DIR__,3);$app=new think\App($root);require_once $app->getThinkPath().'helper.php';require_once $root.'/app/common.php';
        $app->config->set($db,'database');$app->config->set(['default'=>'file','stores'=>['file'=>['type'=>'File','path'=>sys_get_temp_dir().'/'.$schema.'/cache/']]],'cache');$app->config->set(['default'=>'file','channels'=>['file'=>['type'=>'File','path'=>sys_get_temp_dir().'/'.$schema.'/log/']]],'log');
        $app->env->set('app.auth_key',$p['auth_key']);$app->env->set('queue.state',false);$app->instance('request',new app\Request());request()->siteId($p['site']);request()->uid(1);request()->appType('site');
        $manager=new think\DbManager();$manager->setConfig($db);$app->instance('think\DbManager',$manager);$GLOBALS['hsx_lead_test_owned_schema']=$schema;leadAssertIsolated($schema);
        echo json_encode(['ready'=>(int)Db::query('SELECT CONNECTION_ID() id')[0]['id']],JSON_THROW_ON_ERROR).PHP_EOL;fflush(STDOUT);
        if(trim((string)fgets(STDIN))!=='GO')throw new RuntimeException('Missing explicit start');
        try{$order=(new EntityMembershipService(new Context($p['site'],0,102)))->createOrder($p['input']);$result=['accepted'=>true,'id'=>(int)$order['id']];}
        catch(CommonException$error){$result=['accepted'=>false,'reason'=>$error->getMessage()];}
        echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR).PHP_EOL;fflush(STDOUT);exit(0);
    }catch(Throwable$error){fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);exit(2);}
}
if(in_array('--experience-child',$argv,true))ecChild();

function ecLine(array&$w):array{
    $end=microtime(true)+15;
    while(microtime(true)<$end){
        if(($pos=strpos($w['buffer'],"\n"))!==false){$line=substr($w['buffer'],0,$pos);$w['buffer']=substr($w['buffer'],$pos+1);return json_decode($line,true,32,JSON_THROW_ON_ERROR);}
        $read=[$w['pipes'][1]];$write=$except=null;if(stream_select($read,$write,$except,0,100000)===false)throw new RuntimeException('Worker pipe failed');if($read)$w['buffer'].=(string)fread($w['pipes'][1],65536);
    }throw new RuntimeException('Worker timed out at bounded barrier');
}
function ecRace($app,PDO$pdo,string$schema,int$site,array$quote,?callable$beforeRelease=null):array{
    leadAssertIsolated($schema);$workers=[];
    try{
        $pdo->beginTransaction();$s=$pdo->prepare('SELECT site_id FROM lt_site WHERE site_id=? FOR UPDATE');$s->execute([$site]);ecCheck((int)$s->fetchColumn()===$site,'parent owns exact fixture site barrier');$s->closeCursor();
        for($i=0;$i<2;$i++){
            $pipes=[];$process=proc_open([PHP_BINARY,'-d','error_reporting=22527','-d','display_errors=0','-d','allow_url_fopen=0','-d','disable_functions=curl_exec,curl_multi_exec,fsockopen,pfsockopen,stream_socket_client,socket_connect',__FILE__,'--isolated-local-mysql','--experience-child'],[['pipe','r'],['pipe','w'],['pipe','w']],$pipes);
            if(!is_resource($process))throw new RuntimeException('Cannot start isolated worker');stream_set_blocking($pipes[1],false);$workers[]=['process'=>$process,'pipes'=>$pipes,'buffer'=>''];
            fwrite($pipes[0],json_encode(['schema'=>$schema,'database'=>$app->config->get('database'),'auth_key'=>(string)$app->env->get('app.auth_key'),'site'=>$site,'input'=>['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','request_id'=>'experience-race-'.bin2hex(random_bytes(8)),'quote_token'=>$quote['quote_token']]],JSON_THROW_ON_ERROR).PHP_EOL);fflush($pipes[0]);
        }
        $ids=[];foreach($workers as&$w){$ready=ecLine($w);$ids[]=(int)($ready['ready']??0);ecCheck(end($ids)>0,'real worker booted a fresh connection');}unset($w);ecCheck(count(array_unique($ids))===2,'two workers use independent MySQL connections');
        foreach($workers as$w){fwrite($w['pipes'][0],"GO\n");fflush($w['pipes'][0]);}
        $wait=$pdo->prepare('SELECT COUNT(DISTINCT t.PROCESSLIST_ID) FROM performance_schema.data_lock_waits w JOIN performance_schema.threads t ON t.THREAD_ID=w.REQUESTING_THREAD_ID WHERE t.PROCESSLIST_ID IN (?,?)');$end=microtime(true)+10;$blocked=false;
        do{$wait->execute($ids);$blocked=(int)$wait->fetchColumn()===2;$wait->closeCursor();if(!$blocked)usleep(20000);}while(!$blocked&&microtime(true)<$end);
        ecCheck($blocked,'both real workers concurrently wait on the same business site lock');
        if($beforeRelease)$beforeRelease($pdo);$pdo->commit();$out=[];
        foreach($workers as&$w){$out[]=ecLine($w);fclose($w['pipes'][0]);$w['pipes'][0]=null;$error=(string)stream_get_contents($w['pipes'][2]);fclose($w['pipes'][1]);fclose($w['pipes'][2]);$w['pipes'][1]=$w['pipes'][2]=null;$exit=proc_close($w['process']);$w['process']=null;ecCheck($exit===0&&$error==='','worker finished without hidden errors');}unset($w);return$out;
    }finally{if($pdo->inTransaction())$pdo->rollBack();foreach($workers as$w){foreach($w['pipes']as$pipe)if(is_resource($pipe))fclose($pipe);if(is_resource($w['process'])){proc_terminate($w['process']);proc_close($w['process']);}}}
}
$pdo=null;$schema='';$failed=false;
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site,[2,5,10,20]);Db::name('member')->insert(['site_id'=>$site,'member_id'=>104,'nickname'=>'Synthetic staff']);
    $admin=new Context($site,1);$config=(new ConfigService($admin))->get();$config['enabled']=true;$config['publishing_required']=false;$config['fee_confirmed']=true;$config['fee_percent']='0.00';$config['fee_minimum']='0.00';(new ConfigService($admin))->save($config);
    $pub=new CooperationService(new Context($site,0,101));$owner=new Context($site,0,102);$staff=new Context($site,0,104);$model=$pub->catalog(['business_type'=>'purchase','browse'=>1])[0];
    $profiles=[];foreach([101,102]as$id)$profiles[$id]=(new PartnerService(new Context($site,0,$id)))->saveProfile(['name'=>'Experience shop '.$id,'contact_name'=>'Synthetic owner','mobile'=>'18800000'.$id,'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road','business_capabilities'=>[['business_type'=>'purchase','option_ids'=>[$model['id']]]]]);
    leadMembershipGrant($site,102,'ML701');$merchant=(int)$profiles[102]['id'];$team=new TeamService($owner);(new TeamService($staff))->join(['subject_code'=>$team->summary()['subject_code']]);$team->review(104,true);
    $personal=Db::name('member')->where('site_id',$site)->whereIn('member_id',[101,102,104])->field('member_id,growth,growth_get,member_level')->order('member_id')->select()->toArray();
    $lead=$pub->create(['request_id'=>'employee-commission-lead','customer_name'=>'Synthetic customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'attachments'=>[],'consent'=>true]);$pub->assign((int)$lead['id'],['merchant_id'=>$merchant,'assignment_version'=>0]);$receive=new CooperationService($staff);$receive->action((int)$lead['id'],['action'=>'accept','assignment_version'=>1]);$receive->action((int)$lead['id'],['action'=>'deal','assignment_version'=>1]);
    $order=(new PaymentService($staff))->createOrder(['purpose'=>'commission','lead_id'=>$lead['id'],'amount'=>'200.00','request_id'=>'employee-commission-pay']);
    ecCheck(EntityExperienceService::summary($site,$merchant)['value']==='0.00','unpaid external commission contributes zero experience');
    $event=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>'EMPLOYEE_EXPERIENCE_RECEIPT'];Db::name('pay')->insert($event+['main_type'=>PayDict::MEMBER,'main_id'=>104,'from_main_id'=>104,'money'=>'200.00','status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);PaymentService::confirm($event);PaymentService::confirm($event);
    $membership=new EntityMembershipService($owner);$shared=(new EntityMembershipService($staff))->summary();ecCheck($membership->summary()['experience']['value']==='200.00'&&$shared['experience']['value']==='200.00','an employee real receipt accrues once to the shared receiving subject');ecCheck(!$shared['can_manage'],'sharing experience never grants employee billing ownership');
    ecCheck(EntityExperienceService::summary($site,(int)$profiles[101]['id'])['value']==='0.00','sender subject does not inherit the receiving shop experience');
    $quote=$membership->quote('ML702','month');ecCheck($quote['can_purchase'],'actual two-condition qualification precedes the concurrent upgrade requests');$race=ecRace($app,$pdo,$schema,$site,$quote);
    ecCheck($race[0]['accepted']&&$race[1]['accepted']&&$race[0]['id']===$race[1]['id'],'concurrent authorized upgrades reuse exactly one pending membership order');ecCheck(Store::query('coop_order',$site)->where('purpose','membership')->where('status','unpaid')->count()===1,'one persisted pending purchase exists after the real race');$membership->closeUnpaid($race[0]['id']);
    $quote=$membership->quote('ML702','month');$before=Store::query('coop_order',$site)->count();$race=ecRace($app,$pdo,$schema,$site,$quote,static function(PDO$db)use($site):void{$s=$db->prepare('INSERT INTO lt_pay_refund (site_id,refund_no,out_trade_no,money,status,create_time) VALUES (?,?,?,?,?,?)');$s->execute([$site,'EXPERIENCE_RACE_REFUND','EMPLOYEE_EXPERIENCE_RECEIPT','0.01',RefundDict::SUCCESS,time()]);});
    ecCheck(!$race[0]['accepted']&&!$race[1]['accepted'],'refund committed before the site lock is acquired prevents both stale qualifying purchases');ecCheck(Store::query('coop_order',$site)->count()===$before,'failed concurrent qualification creates no cash or membership order');ecCheck(EntityExperienceService::summary($site,$merchant)['value']==='199.99','refund arithmetic remains exact across real connections');
    ecCheck($personal===Db::name('member')->where('site_id',$site)->whereIn('member_id',[101,102,104])->field('member_id,growth,growth_get,member_level')->order('member_id')->select()->toArray(),'neither worker, employee payment nor growth recalculation changes personal level or growth');
    leadAssertIsolated($schema);echo 'PASS '.$checks." subject experience and real concurrent qualification checks; disposable local schema, synthetic receipts, no gateway.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
