import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Actual Vue setup + compiled templates; synthetic read API and save doubles
// only. No network, WeChat client, token, database or real configuration write.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), workspace = path.resolve(plugin, '../../..')
const require = createRequire(path.join(workspace, 'admin/package.json')), Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
let checks = 0
const check = (condition, label) => { assert.ok(condition, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
const clone = value => JSON.parse(JSON.stringify(value))
const flush = async () => { await Promise.resolve(); await Promise.resolve(); await Vue.nextTick() }
const variables = ['task_no', 'status_text', 'occurred_at', 'notice_remark', 'demand_summary', 'task_id'].map(key => ({ key, label: key }))
const rulesSource = fs.readFileSync(path.join(plugin, 'admin/composables/noticeFields.ts'), 'utf8'), rulesModule = { exports: {} }
vm.runInNewContext('(function(require,module,exports){' + ts.transpileModule(rulesSource, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText + '})', { String, Array, Object })(key => { throw Error('Unexpected shared-rule dependency ' + key) }, rulesModule, rulesModule.exports)
const noticeFields = rulesModule.exports
equal(rulesSource, fs.readFileSync(path.join(workspace, 'admin/src/addon/hsx_lead/composables/noticeFields.ts'), 'utf8'), 'shared field rules and admin mirror agree')
equal(noticeFields.noticeVariableOptions('character_string1', variables).map(item => item.key), ['task_no', 'task_id'], 'character_string cannot offer Chinese status, prompt or demand values')
equal(noticeFields.noticeVariableOptions('phrase2', variables).map(item => item.key), ['status_text'], 'phrase can only use the bounded Chinese status value')
equal(noticeFields.noticeVariableOptions('thing3', variables).map(item => item.key), variables.map(item => item.key), 'thing retains exactly the six safe notification variables')
equal(noticeFields.noticeVariableOptions('keyword1', variables), [], 'unknown or legacy public-account fields do not enter the WeChat miniapp helper')
equal(noticeFields.noticeVariableOptions('character_string1', variables.map(item => ({ ...item, field_types: ['character_string', 'phrase', 'thing', 'time', 'date', 'number'] }))).map(item => item.key), ['task_no', 'task_id'], 'permissive server metadata can never widen the fixed semantic boundary')
equal(noticeFields.noticeVariableOptions('character_string1', variables.map(item => ({ ...item, field_types: ['thing'] }))), [], 'server metadata may further narrow the allowed field types')
equal(noticeFields.noticeVariableOptions('thing1', variables.map(item => ({ ...item, field_types: 'thing' }))), [], 'malformed present field metadata fails closed rather than granting all types')
check(noticeFields.suggestNoticeVariable({ keyword: 'character_string1', name: '处理状态' }, variables) === '' && noticeFields.suggestNoticeVariable({ keyword: 'phrase2', name: '备注提示' }, variables) === '', 'semantic suggestions never invent Chinese content for character_string or arbitrary prompts for phrase')
function compile(name) {
    const file = path.join(plugin, 'admin/views/components', name), source = fs.readFileSync(file, 'utf8'), parsed = compiler.parse(source, { filename: file })
    check(!parsed.errors.length, name + ' parses')
    const script = compiler.compileScript(parsed.descriptor, { id: 'notice-picker-test' })
    check(!compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'notice-picker-test', compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } }).errors.length, name + ' actual template compiles')
    equal(source, fs.readFileSync(path.join(workspace, 'admin/src/addon/hsx_lead/views/components', name), 'utf8'), name + ' packaged source and admin mirror agree')
    return { source, script }
}
function setup(compiled, props, dependencies = {}) {
    const module = { exports: {} }, events = [], js = ts.transpileModule(compiled.script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Number, String, Boolean, Array, Object, Set, Map, Date, Math, JSON, Promise, Error })(key => {
        if (key === 'vue') return { ...Vue, onBeforeUnmount() {} }
        if (key in dependencies) return dependencies[key]
        if (key.endsWith('/noticeFields')) return noticeFields
        if (key.endsWith('.vue')) return { default: {} }
        if (key.endsWith('useLeadUi')) return { errorText: (cause, fallback) => cause?.message || fallback }
        throw Error('Unexpected dependency ' + key)
    }, module, module.exports)
    const reactiveProps = Vue.reactive(props), ui = module.exports.default.setup(reactiveProps, { emit: (...args) => events.push(clone(args)), expose() {} })
    return { ui, props: reactiveProps, events }
}
const picker = compile('WeappNoticeTemplatePicker.vue'), settings = compile('NoticeSettings.vue')
check(!/saveNoticeConfig|request\.(?:post|put)|fetch\(|getTemplateId|addtemplate|sendNotice/.test(picker.source), 'picker has only a read-only library dependency and no acquisition, enable or send path')
check(settings.source.includes('高级映射（保留已有配置，用于异常核对）') && settings.source.includes('notice-mapping-preview'), 'existing manual mapping is retained in a named advanced fold and selected mapping stays visible')
check(settings.source.includes("channel === 'weapp' && !item.configured ? '待核对模板' : item.enabled ? '框架已开启'") && settings.source.includes("channel = ref<Channel>('weapp')"), 'unusable miniapp mappings show review state before the framework-enabled flag, and miniapp remains the default tab')
const reads = []; let response = async params => params.operation === 'categories' ? { operation: 'categories', items: [{ id: 1, name: '已开通类目' }, { id: 2, name: '另一类目' }] } : params.operation === 'titles' ? { operation: 'titles', items: [{ tid: '501', title: '工单进度通知', type: 2 }, { tid: '502', title: '处理结果提醒', type: 2 }, { tid: 'invalid', title: '无效模板' }], start: params.start, limit: 30, total: 62 } : { operation: 'keywords', tid: params.tid, items: [
    { kid: 1, name: '工单编号', rule: 'character_string', keyword: 'character_string1', supported: true, example: 'A123' },
    { kid: 2, name: '处理状态', rule: 'phrase', keyword: 'phrase2', supported: true },
    { kid: 3, name: '发生时间', rule: 'time', keyword: 'time3', supported: true },
    { kid: 4, name: '工单数字', rule: 'number', keyword: 'number4', supported: true },
    { kid: 5, name: '需求内容', rule: 'thing', keyword: 'thing5', supported: true },
    { kid: 6, name: '备注提示', rule: 'thing', keyword: 'thing6', supported: true },
    { kid: 7, name: '金额未知', rule: 'amount', keyword: 'amount7', supported: true },
    { kid: 8, name: '错误编号', rule: 'thing', keyword: 'thing9', supported: true },
    { kid: 9, name: '不可映射', rule: 'thing', keyword: 'thing9', supported: false },
    { kid: 1, name: '重复关键词', rule: 'thing', keyword: 'thing1', supported: true }
] }
const api = { getNoticeTemplateLibrary: async params => { reads.push(clone(params)); return { data: await response(params) } } }
const instance = setup(picker, { canEdit: true, variables, sceneName: '商户新工单提醒' }, { '../../api': api }), ui = instance.ui
check(reads.length === 0, 'mounting a phase does not request WeChat or load fabricated defaults')
await ui.open(); equal(reads.at(-1), { operation: 'categories' }, 'explicit open reads only categories')
await ui.changeCategory(1); equal(reads.at(-1), { operation: 'titles', category_id: 1, start: 0, limit: 30 }, 'category selection uses the existing bounded title-read operation')
check(ui.titles.value.length === 2 && ui.total.value === 62, 'only official numeric template identifiers enter the title list')
ui.titleFilter.value = '结果'; check(ui.filteredTitles.value.length === 1 && ui.filteredTitles.value[0].tid === '502', 'title search honestly filters the loaded page')
await ui.loadTitles(30); check(ui.start.value === 30 && reads.at(-1).start === 30, 'next-page operation advances the official start cursor')
await ui.loadKeywords(ui.titles.value[0]); equal(reads.at(-1), { operation: 'keywords', tid: '501' }, 'keyword query uses the selected official tid without manual identifier input')
check(ui.keywords.value.length === 9 && ui.keywords.value[0].example === 'A123', 'real keyword labels, examples and IDs survive and duplicate kids are ignored')
equal(ui.keywords.value.slice(0, 6).map(item => item.variable), ['task_no', 'status_text', 'occurred_at', 'task_id', 'demand_summary', 'notice_remark'], 'visible semantic suggestions match each safe notification variable')
check(ui.keywords.value.slice(6).every(item => !item.supported), 'unknown types, mismatched field IDs and unsupported server fields cannot be selected')
ui.keywords.value[6].selected = true; ui.keywordSelected(ui.keywords.value[6]); check(!ui.keywords.value[6].selected, 'unsupported selection fails closed even when invoked directly')
equal(ui.variableOptions(ui.keywords.value[2]).map(item => item.key), ['occurred_at'], 'time fields only offer notification time')
equal(ui.variableOptions(ui.keywords.value[3]).map(item => item.key), ['task_id'], 'number fields only offer the numeric work-order ID')
ui.keywords.value[0].selected = true; ui.keywords.value[1].selected = true
ui.keywords.value[1].selected = false; ui.keywords.value[0].variable = 'status_text'; ui.applySelection()
check(ui.selectionError.value.includes('符合类型') && instance.events.length === 0, 'picker cannot apply a Chinese status mapped to character_string even with no duplicate variables')
ui.keywords.value[0].variable = 'task_no'; ui.keywords.value[1].selected = true; ui.keywords.value[1].variable = 'notice_remark'; ui.applySelection()
check(ui.selectionError.value.includes('符合类型') && instance.events.length === 0, 'picker cannot apply an arbitrary Chinese prompt mapped to phrase')
ui.keywords.value[1].variable = 'status_text'
ui.keywords.value[1].variable = 'task_no'; check(ui.selectionError.value.includes('不能重复'), 'duplicate notification variables block application')
ui.keywordSelected(ui.keywords.value[1]); check(ui.keywords.value[1].variable === '', 'selecting a duplicate semantic suggestion requires an explicit new variable')
ui.keywords.value[1].variable = 'status_text'; check(!ui.selectionError.value, 'two real unique keywords produce a valid draft')
ui.sceneDesc.value = ''; check(ui.selectionError.value.includes('使用场景'), 'missing scene description blocks application')
ui.sceneDesc.value = '商户新工单提醒'; ui.applySelection()
equal(instance.events, [['select', { tid: '501', kid_list_text: '1,2', scene_desc: '商户新工单提醒', fields: [{ label: '工单编号', keyword: 'character_string1', variable: 'task_no' }, { label: '处理状态', keyword: 'phrase2', variable: 'status_text' }] }]], 'application emits only the current phase mapping draft, without save, enable or acquisition')
check(!ui.visible.value, 'successful draft selection closes the picker')

const normalResponse = response
response = async () => ({ operation: 'categories', items: [] }); await ui.open(); check(ui.error.value.includes('接口权限') && !ui.categories.value.length, 'empty permission or category result is explicit, not a fake successful library')
response = async () => { throw Error('合成接口权限不足') }; await ui.loadCategories(); check(ui.error.value === '合成接口权限不足' && !ui.categoryLoading.value, 'read failure is visible and releases loading state')
response = normalResponse; await ui.loadCategories(); await ui.changeCategory(1)
let resolveOld; response = params => params.operation === 'keywords' ? new Promise(resolve => { resolveOld = resolve }) : normalResponse(params)
const pending = ui.loadKeywords(ui.titles.value[0]); await ui.loadTitles(30); resolveOld({ operation: 'keywords', tid: '501', items: [{ kid: 1, name: '旧请求', rule: 'thing', keyword: 'thing1', supported: true }] }); await pending
check(ui.keywords.value.length === 0 && ui.selectedTitle.value === null, 'changing title page discards an in-flight keyword response from the old page')
let resolveClosed; response = () => new Promise(resolve => { resolveClosed = resolve }); const closing = ui.loadCategories(); ui.visible.value = false; ui.close(); resolveClosed({ operation: 'categories', items: [{ id: 9, name: '已关闭请求' }] }); await closing
check(!ui.categories.value.length && !ui.categoryLoading.value, 'closed picker cannot be repopulated by a late library response')
response = normalResponse
const readonly = setup(picker, { canEdit: false, variables, sceneName: '只读查看' }, { '../../api': api }); await readonly.ui.open(); await readonly.ui.changeCategory(1); await readonly.ui.loadKeywords(readonly.ui.titles.value[0]); readonly.ui.keywords.value[0].selected = true; readonly.ui.keywordSelected(readonly.ui.keywords.value[0]); readonly.ui.applySelection()
check(readonly.ui.categories.value.length > 0 && readonly.ui.keywords.value.length > 0 && !readonly.ui.keywords.value[0].selected && readonly.events.length === 0, 'read-only permission permits viewing official metadata but cannot select or apply a draft')

const notices = [], writes = []
let server = { templates: [{ phase: 'assigned', tid: '', kid_list: [], scene_desc: '', fields: [] }, { phase: 'changed', tid: '600', kid_list: [1], scene_desc: '已有结果提醒', fields: [{ label: '状态', keyword: 'phrase1', variable: 'status_text' }] }], wechat_templates: [{ phase: 'assigned', temp_key: 'ORIGINAL', fields: [] }], variables, channel_settings: [] }
const admin = setup(settings, { canEdit: true, modelValue: true }, {
    'vue-router': { useRouter: () => ({ push: async () => {} }) }, 'element-plus': { ElMessage: { warning: value => notices.push(value), success: value => notices.push(value), error: value => notices.push(value) } },
    '../../api': { getNoticeConfig: async () => ({ data: clone(server) }), saveNoticeConfig: async value => { writes.push(clone(value)); server = { ...server, templates: server.templates.map(item => value.templates?.find(update => update.phase === item.phase) || item) }; return { data: clone(server) } } }
})
await flush(); admin.ui.channel.value = 'weapp'; const assigned = admin.ui.templates.value[0], originalOther = clone(admin.ui.templates.value[1]), originalWechat = clone(admin.ui.wechatTemplates.value)
assigned.confirmed = true; admin.ui.applyWeappSelection(assigned, instance.events[0][1]); check(!assigned.confirmed && writes.length === 0, 'selecting a template resets prior confirmation and only updates a local draft')
equal(admin.ui.templates.value[1], originalOther, 'selection does not overwrite the other phase mapping')
equal(admin.ui.wechatTemplates.value, originalWechat, 'selection does not overwrite the public-account channel')
await admin.ui.save(); check(writes.length === 0 && notices.at(-1).includes('请确认'), 'save is blocked until the user explicitly checks the visible phase confirmation')
assigned.confirmed = true; assigned.fields[0].variable = 'notice_remark'; await admin.ui.save(); check(writes.length === 0 && notices.at(-1).includes('字段类型'), 'advanced mapping cannot save a Chinese prompt into character_string')
assigned.fields[0].variable = 'task_no'; assigned.fields[1].variable = 'demand_summary'; await admin.ui.save(); check(writes.length === 0 && notices.at(-1).includes('字段类型'), 'advanced mapping cannot save demand text into phrase')
assigned.fields[1].variable = 'status_text'
assigned.confirmed = true; assigned.fields[1].variable = 'task_no'; await admin.ui.save(); check(writes.length === 0 && notices.at(-1).includes('只能映射一次'), 'advanced/manual duplicate variables are also rejected before save')
assigned.fields[1].variable = 'status_text'; const normalFields = clone(assigned.fields); assigned.fields = Array.from({ length: 11 }, (_, index) => ({ label: '字段' + index, keyword: 'thing' + (index + 1), variable: 'task_no' })); assigned.kid_list_text = Array.from({ length: 11 }, (_, index) => index + 1).join(','); await admin.ui.save(); check(writes.length === 0 && notices.at(-1).includes('1—10'), 'advanced/manual maps cannot exceed ten official keywords')
assigned.fields = normalFields; assigned.kid_list_text = '1,2'; assigned.confirmed = true; await admin.ui.save()
check(writes.length === 1 && writes[0].templates.length === 1 && writes[0].templates[0].confirmed === true && !('wechat_templates' in writes[0]), 'explicit confirmed save writes only the changed current-channel phase')
check(!admin.ui.changedTemplates.value.length && !admin.ui.templates.value[0].confirmed, 'server readback becomes the clean baseline and clears confirmation for the next edit')
const legacy = { phase: 'changed', tid: '700', configured: false, enabled: true, kid_list: [1], scene_desc: '待核对旧映射', fields: [{ label: '状态', keyword: 'character_string1', variable: 'status_text' }] }
admin.ui.applyData({ ...server, templates: [server.templates[0], legacy] }, 'weapp')
equal(admin.ui.templates.value[1].fields, legacy.fields, 'reading an invalid saved map preserves its fields for review instead of deleting or migrating it')
check(!admin.ui.changedTemplates.value.length && !admin.ui.templates.value[1].configured && admin.ui.templates.value[1].enabled, 'invalid saved map remains an unchanged review baseline without rewriting its real framework switch')
const readonlySettings = setup(settings, { canEdit: false, modelValue: false }, { 'vue-router': { useRouter: () => ({}) }, 'element-plus': { ElMessage: {} }, '../../api': { getNoticeConfig: async () => ({ data: clone(server) }), saveNoticeConfig: async () => { throw Error('Read-only write attempted') } } })
const untouched = { tid: 'old', fields: [] }; readonlySettings.ui.applyWeappSelection(untouched, instance.events[0][1]); await readonlySettings.ui.save(); check(untouched.tid === 'old' && writes.length === 1, 'read-only settings reject draft application and save independently of disabled controls')
console.log(`PASS ${checks} official notice template picker checks; actual Vue state/template compile, fake API only, no network, acquisition, enable or real save.`)
