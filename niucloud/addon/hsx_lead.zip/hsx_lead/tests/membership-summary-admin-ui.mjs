import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),{renderToString}=require('@vue/server-renderer')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++},read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
function run(source,deps={}){
    const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext('(function(require,module,exports){'+js+'})',{Date,Number,String,Math,Set,Map,JSON,Promise,Error,console})(key=>{if(key in deps)return deps[key];throw Error('Unexpected dependency '+key)},module,module.exports)
    return module.exports
}
function component(file,inlineTemplate=false){
    const source=read(file),parsed=compiler.parse(source,{filename:file});check(!parsed.errors.length,file+' parses')
    const built=compiler.compileScript(parsed.descriptor,{id:'membership-summary',inlineTemplate})
    check(!compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'membership-summary',compilerOptions:{bindingMetadata:built.bindings,expressionPlugins:['typescript']}}).errors.length,file+' template compiles')
    for(const style of parsed.descriptor.styles)check(!compiler.compileStyle({source:style.content,filename:file,id:'membership-summary',scoped:style.scoped}).errors.length,file+' styles compile')
    check(source===fs.readFileSync(path.resolve(plugin,'../../../admin/src/addon/hsx_lead',file.slice(6)),'utf8'),file+' matches mounted source')
    return{source,built:built.content,style:parsed.descriptor.styles.map(style=>style.content).join('\n')}
}
const helper=run(read('admin/composables/entity.ts'))
const summary=component('admin/views/cooperation/MembershipSummary.vue',true)
const Summary=run(summary.built,{vue:Vue,'../../composables/entity':helper,'../../composables/cooperation':{coopTime:value=>'日期'+value}}).default
const Tag={props:['type','size','effect'],setup(props,{slots}){return()=>Vue.h('span',{'data-tone':props.type,'data-size':props.size,class:'el-tag'},slots.default?.())}}
async function render(membership){const app=Vue.createSSRApp({render:()=>Vue.h(Summary,{membership})});app.component('ElTag',Tag);return renderToString(app)}
for(const value of [undefined,null,{}]){
    const html=await render(value)
    check(html.includes('普通会员')&&html.includes('未开通'),'missing membership has a safe compact default')
    check(!html.includes('尚未开通')&&!html.includes('<small'),'unopened state is not duplicated in an extra line')
    check(html.includes('data-size="small"')&&html.includes('data-tone="info"'),'inactive status uses the native small info tag')
}
const paid=await render({level_name:'白银',active:true,expires_at:1796000000})
check(paid.includes('白银')&&paid.includes('生效中')&&paid.includes('data-tone="success"'),'active membership preserves framework status semantics')
check(paid.includes('<small>日期1796000000 到期</small>'),'a real expiry stays in its own secondary line')
const forever=await render({level_name:'黄金',active:true,expires_at:0})
check(forever.includes('<small>长期有效</small>'),'active permanent membership retains its existing expiry meaning')
const expired=await render({level_name:'青铜',active:false,state:'expired',expires_at:1786000000})
check(expired.includes('已到期')&&expired.includes('data-tone="warning"')&&expired.includes('日期1786000000 到期'),'expired membership is not mislabeled unopened')
const longName=await render({level_name:'这是一个后台设置的较长会员名称',active:false})
check(longName.includes('这是一个后台设置的较长会员名称'),'configured names are preserved, not replaced or truncated in data')
check(/__heading\{[^}]*display:flex[^}]*align-items:center[^}]*flex-wrap:wrap/.test(summary.style),'heading keeps name and status together while allowing narrow columns to wrap')
check(/__status\{[^}]*flex:0 0 auto[^}]*width:auto[^}]*white-space:nowrap/.test(summary.style),'tag cannot stretch to fill the table column')
for(const file of ['admin/views/cooperation/Partners.vue','admin/views/cooperation/Entities.vue']){
    const page=component(file)
    check(page.source.includes('<template #membership="{row}"><MembershipSummary :membership="row.membership" /></template>'),'both membership lists reuse the same compact cell')
}
console.log(`PASS ${checks} membership summary admin checks; actual Vue SFC, scoped CSS compile and synthetic SSR rendering only; no business/API writes.`)
