import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath,pathToFileURL} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'
import {profileConfigApi} from './profile-config-fixture.mjs'

// Actual profile/avatar/badge SSR. Only unrelated controls and storage are
// synthetic; no browser, saved DIY, member API, payment or database is touched.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),dom=require('@vue/compiler-dom'),ts=require('typescript'),sass=require('sass'),postcss=require('postcss'),{renderToString}=require('@vue/server-renderer')
const directory=path.join(plugin,'uni-app/components/cooperation'),cache=new Map();let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const blank={render:()=>Vue.h('span')}
function component(name){
    if(cache.has(name))return cache.get(name)
    const filename=path.join(directory,name+'.vue'),parsed=sfc.parse(fs.readFileSync(filename,'utf8'),{filename}),module={exports:{}}
    check(!parsed.errors.length,name+' parses')
    const script=sfc.compileScript(parsed.descriptor,{id:'profile-name',inlineTemplate:true})
    check(!sfc.compileTemplate({source:parsed.descriptor.template.content,filename,id:'profile-name',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,name+' template compiles')
    const code=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{Number,Object,String,Array,Math,Date,console,uni:{getStorageSync(){},setStorageSync(){},removeStorageSync(){}}})(key=>{
        if(key==='vue')return Vue
        if(key==='@/utils/common')return{img:value=>'synthetic-local:'+value}
        if(key==='../../api/cooperation')return profileConfigApi
        if(key.startsWith('../../utils/'))return loadMobileUtility(path.basename(key))
        if(key.endsWith('.png'))return{default:'/synthetic-wing.png'}
        if(key.endsWith('.vue'))return{default:/CoopMerchantAvatar|CoopLevelBadge/.test(key)?component(path.basename(key,'.vue')):blank}
        throw Error('Unexpected profile dependency '+key)
    },module,module.exports)
    cache.set(name,module.exports.default);return module.exports.default
}
const profile={id:7,name:'一家名称很长但会员标识仍然需要保持在同一行的合成门店',region_text:'合成地区',storefront_image:'owned/profile.jpg',blocked_at:1790000000,membership:{active:true,level_code:'ML701',display_rank:1,level_name:'认证商户',level_visual:{avatar_effect:false}}}
async function render(props={}){
    const app=Vue.createSSRApp({render:()=>Vue.h(component('CoopProfilePanel'),{profile,config:{},providers:[],section:'identity',...props})});app.config.warnHandler=()=>{};app.component('u-icon',blank)
    return dom.baseParse(await renderToString(app))
}
const classes=node=>String(node.props?.find(prop=>prop.name==='class')?.value?.content||'').split(/\s+/)
function find(node,name){if(classes(node).includes(name))return node;for(const child of node.children||[]){const found=find(child,name);if(found)return found}return null}
const text=node=>(node?.type===2?node.content:'')+(node?.children||[]).map(text).join('')
for(const [label,props]of [['DIY',{displayOnly:true}],['routed page',{page:true}],['embedded profile',{}],['DIY ignores page-size flag',{displayOnly:true,page:true}]]){
    const tree=await render(props),line=find(tree,'coop-profile-name-line'),name=find(line||{},'coop-profile-name'),badge=find(line||{},'coop-profile-name-badge'),avatar=find(tree,'coop-merchant-avatar'),identity=find(tree,'coop-profile-identity')
    check(!!line&&!!name&&!!badge,label+' has the real badge beside the real shop name in one named row')
    check(text(name)===profile.name&&text(badge)==='认证商户',label+' renders actual shop and membership names, not a placeholder or duplicate credential')
    check(!!find(badge,'coop-level-badge'),label+' mounts the actual shared membership badge inside the row')
    check(!!avatar&&!find(avatar,'coop-profile-name-line')&&!find(avatar,'coop-level-badge'),label+' avatar does not swallow the name or membership through an unsupported default slot')
    check(identity.children.filter(node=>node.type===1)[0]===line,label+' identity begins with the name/badge row')
    const blocked=find(tree,'is-blocked'),blockedGroup=find(identity,'coop-profile-badges')
    check(text(blocked)==='已停止合作'&&!!blockedGroup&&!find(line,'is-blocked'),label+' retains blocked status separately below the inline identity')
    check((!!find(tree,'is-page-panel'))===(props.page===true&&!props.displayOnly),label+' only actual routed form context can receive page-height sizing')
}
for(const showGrade of [0,'0',false]){
    const tree=await render({appearance:{showGrade}})
    check(!find(tree,'coop-profile-name-badge')&&!find(tree,'coop-level-badge'),'saved showGrade='+String(showGrade)+' hides the membership badge')
    check(!!find(tree,'coop-profile-name')&&text(find(tree,'is-blocked'))==='已停止合作','hiding a grade never hides the shop identity or blocked-state warning')
}
const expired=await render({profile:{...profile,membership:{...profile.membership,active:false}}})
check(text(find(expired,'coop-profile-name-badge')).includes('已到期'),'inline expired identity keeps the actual expiry state')
const longLevelName='这是一个名称较长的城市旗舰合作交付中心会员'
const longLevel=await render({profile:{...profile,membership:{...profile.membership,level_name:longLevelName}}})
const longBadge=find(longLevel,'coop-level-badge')
check(longBadge.props.find(prop=>prop.name==='aria-label')?.value?.content===longLevelName,'visually clipped long membership label retains its complete accessible name')
const filename=path.join(directory,'CoopProfilePanel.vue'),descriptor=sfc.parse(fs.readFileSync(filename,'utf8'),{filename}).descriptor
const ast=dom.baseParse(descriptor.template.content)
function tag(node,name){if(node.tag===name)return node;for(const child of node.children||[]){const found=tag(child,name);if(found)return found}return null}
const avatarTag=tag(ast,'CoopMerchantAvatar')
check(avatarTag.isSelfClosing&&!(avatarTag.children||[]).some(node=>node.type===1),'source avatar remains self-closing so future edits cannot hide identity as unrendered slot content')
const css=postcss.parse(descriptor.styles.map(style=>sass.compileString(style.content,{url:pathToFileURL(filename),logger:{warn(){},debug(){}}}).css).join('\n'))
function styleFor(names,width){
    const result={},weight={}
    css.walkRules(rule=>{
        for(let parent=rule.parent;parent;parent=parent.parent)if(parent.type==='atrule'&&parent.name==='media'){
            const max=parent.params.match(/max-width:\s*([\d.]+)px/),min=parent.params.match(/min-width:\s*([\d.]+)px/)
            if(max&&width>Number(max[1])||min&&width<Number(min[1]))return
        }
        for(const selector of rule.selectors){
            if(!/^(?:\.[\w-]+\s*)+$/.test(selector))continue
            const parts=selector.match(/[\w-]+/g);if(!parts.every(name=>names.includes(name)))continue
            for(const declaration of rule.nodes.filter(node=>node.type==='decl'))if(parts.length>=(weight[declaration.prop]||0)){result[declaration.prop]=declaration.value;weight[declaration.prop]=parts.length}
        }
    });return result
}
for(const width of [320,375,430]){
    const line=styleFor(['coop-profile-theme','coop-profile-name-line'],width),name=styleFor(['coop-profile-theme','coop-profile-name-line','coop-profile-name'],width),badge=styleFor(['coop-profile-theme','coop-profile-name-badge'],width),identity=styleFor(['coop-profile-theme','coop-profile-identity'],width)
    check(line.display==='flex'&&line['align-items']==='center'&&(!line['flex-wrap']||line['flex-wrap']==='nowrap'),width+'px row keeps the badge horizontally aligned rather than dropping it below the name')
    check(identity['min-width']==='0'&&name['min-width']==='0'&&name.flex==='0 1 auto',width+'px long shop name is allowed to shrink and leave space for the badge')
    check(name.overflow==='hidden'&&name['text-overflow']==='ellipsis'&&name['white-space']==='nowrap',width+'px name truncates rather than expanding the card width')
    check(badge.flex==='none'&&badge.display==='flex'&&badge['min-width']==='0'&&badge['max-width']==='50%'&&badge.overflow==='hidden',width+'px badge cannot consume more than half the row, while retaining its readable accessible label')
}
console.log(`PASS ${checks} profile name/badge checks; actual profile/avatar/badge SSR and narrow-width CSS contracts, no browser/API/DB/DIY writes; physical device layout requires separate acceptance.`)
