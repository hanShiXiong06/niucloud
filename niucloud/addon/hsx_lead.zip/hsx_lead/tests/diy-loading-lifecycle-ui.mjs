import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Actual framework loader and plugin state, deferred synthetic responses only.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),root=path.resolve(plugin,'../../..')
const require=createRequire(path.join(root,'uni-app/package.json')),Vue=require('vue'),ts=require('typescript'),compiler=require('@vue/compiler-sfc'),sass=require('sass')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
function run(source,deps,globals={}){
    const module={exports:{}},code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{Number,String,Object,JSON,Array,Set,Math,Promise,...globals})(key=>{if(key in deps)return deps[key];throw Error('Unexpected dependency '+key)},module,module.exports)
    return module.exports
}
function fixture(){
    const timers=new Map(),events={load:[],show:[],hide:[],unload:[],scroll:[]},storage=new Map();let serial=0,reads=0,resolve,reject
    const runtime={getStorageSync:key=>storage.get(key),setStorageSync:(key,value)=>storage.set(key,value),setNavigationBarTitle(){}}
    const hooks={onLoad:fn=>events.load.push(fn),onShow:fn=>events.show.push(fn),onHide:fn=>events.hide.push(fn),onUnload:fn=>events.unload.push(fn),onPageScroll:fn=>events.scroll.push(fn)}
    const globals={uni:runtime,getCurrentPages:()=>[{route:'addon/hsx_lead/pages/index'}],setTimeout:fn=>{timers.set(++serial,fn);return serial},clearTimeout:id=>timers.delete(id)}
    const state=run(fs.readFileSync(path.join(plugin,'uni-app/composables/useCooperationDiyLoad.ts'),'utf8'),{vue:Vue},globals).useCooperationDiyLoad('首页')
    const store=Vue.reactive({mode:'',global:{},value:[],init(){}})
    const frame=run(fs.readFileSync(path.join(root,'uni-app/src/hooks/useDiy.ts'),'utf8'),{vue:Vue,'@dcloudio/uni-app':hooks,'@/utils/common':{img:x=>x,handleOnloadParams:x=>x},'@/app/api/diy':{getDiyInfo:()=>{reads++;return new Promise((a,b)=>{resolve=a;reject=b})}},'@/app/stores/diy':{default:()=>store},'@/utils/json':{parseJsonValue:(value,fallback)=>{try{return JSON.parse(value)}catch{return fallback}}}},globals)
    const diy=frame.useDiy({name:'DIY_HSX_LEAD_INDEX',...state.requestOptions})
    diy.onLoad();diy.onShow(()=>state.complete());diy.onHide(()=>state.pause())
    return {state,diy,store,timers,events,get reads(){return reads},resolve:value=>resolve(value),reject:error=>reject(error)}
}
const flush=async()=>{for(let i=0;i<12;i++){await Promise.resolve();await Vue.nextTick()}}
const result=()=>({data:{value:JSON.stringify({global:{topStatusBar:{isShow:true}},value:[]}),title:'首页',site_id:100005}})
const success=fixture();success.events.load.forEach(fn=>fn({}));success.events.show.forEach(fn=>fn())
check(success.reads===1&&success.state.loading.value&&!success.state.ready.value,'framework request begins one loading state, not an empty success')
check(success.timers.size===1,'a request has one bounded timeout')
success.resolve(result());await flush()
check(success.state.ready.value&&!success.state.loading.value&&!success.state.error.value&&success.timers.size===0,'successful metadata releases loading and timeout')
success.events.show.forEach(fn=>fn());check(success.state.loading.value&&!success.state.ready.value,'returning to a cached page starts loading again instead of showing stale metadata as final')
success.reject(new Error('PRIVATE_PROVIDER_CREDENTIAL_MUST_NOT_RENDER'));await flush()
check(!success.state.loading.value&&!success.state.ready.value&&success.state.error.value==='首页加载失败，请重新加载','actual framework promise rejection reaches a sanitized page error, not a fake empty state')
check(!success.state.error.value.includes('PRIVATE_')&&success.timers.size===0,'raw request error and credentials never become customer text')
success.events.show.forEach(fn=>fn());success.resolve(result());await flush()
check(success.state.ready.value&&!success.state.error.value,'an explicit later reload clears the error after a successful response')
const slow=fixture();slow.events.show.forEach(fn=>fn());const timeout=[...slow.timers.values()][0];timeout()
check(!slow.state.ready.value&&!slow.state.loading.value&&slow.state.error.value.includes('暂时没有加载出来'),'slow initial request becomes a recoverable error, never a forever spinner')
slow.resolve(result());await flush();check(slow.state.ready.value&&!slow.state.error.value,'a late successful read may recover a timed-out visible page')
const hidden=fixture();hidden.events.show.forEach(fn=>fn());hidden.events.hide.forEach(fn=>fn())
check(hidden.timers.size===0&&!hidden.state.loading.value,'hidden page cancels its timeout')
hidden.reject(new Error('hidden rejection'));await flush();check(!hidden.state.error.value,'hidden rejection does not overwrite visible page feedback')
hidden.events.show.forEach(fn=>fn());check(hidden.state.loading.value,'a new show reactivates the page loading owner')
hidden.state.dispose();hidden.resolve(result());await flush();check(!hidden.state.loading.value&&!hidden.state.complete(),'disposed page ignores completion and releases all timer state')
const preview=fixture();preview.events.load.forEach(fn=>fn({mode:'decorate'}));preview.state.complete();preview.events.show.forEach(fn=>fn())
check(preview.reads===0&&preview.state.ready.value,'decorator preview keeps its framework-owned mode without a private data request')
for(const file of ['pages/index.vue','pages/profile/index.vue']){
    const source=fs.readFileSync(path.join(plugin,'uni-app',file),'utf8'),parsed=compiler.parse(source,{filename:file})
    check(!parsed.errors.length,'DIY page parses: '+file)
    const script=compiler.compileScript(parsed.descriptor,{id:'diy-audit'})
    check(!compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'diy-audit',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length,'DIY page template compiles: '+file)
    check(source.includes('pageLoad.requestOptions')&&source.includes('<CoopDiyPageStatus')&&!source.includes('timedOut'),'both pages reuse the same loading/error owner: '+file)
    check(source.includes('diy-template-wrap bg-index')&&source.includes("@import '@/styles/diy.scss'")&&source.includes('cooperation-diy-page'),'both pages follow the existing phone_shop framework page style contract: '+file)
}
const partial=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/_cooperation-diy-page.scss'),'utf8')
const css=sass.compileString(partial).css,scoped=compiler.compileStyle({id:'data-v-audit',source:css,scoped:true})
check(!scoped.errors.length&&scoped.code.includes('.lead-diy-page[data-v-audit] .diy-group > .ns-navbar-wrap > .u-navbar')&&scoped.code.includes('position: fixed'),'fixed-header correction is scoped to these plugin pages, not every framework navbar')
check(!partial.includes('z-index')&&!partial.includes('height:')&&!partial.includes('overflow:hidden'),'header keeps the framework placeholder, layer ordering, and page scrolling rather than inventing a second viewport')
console.log(`PASS ${checks} DIY loading/header contract checks; actual framework Promise handling and plugin lifecycle with synthetic data only; no API, database or browser mutation.`)
