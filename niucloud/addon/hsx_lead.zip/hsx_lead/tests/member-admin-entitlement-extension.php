<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';
use app\service\admin\member\MemberService;
use app\service\core\member\CoreMemberEntitlementDisplayService;
use think\facade\{Db,Event};
$checks=0;$pdo=null;$schema='';$failed=false;
function extensionCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function extensionCard(string $label='白银'):array{return['label'=>$label,'status'=>'active','status_text'=>'生效中','context'=>'合成门店 · 负责人','expires_at'=>time()+3600];}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    request()->withGet(['page'=>1,'limit'=>10]);
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['member_level'=>0]);
    $before=Db::name('member')->order('member_id')->select()->toArray();
    Event::remove(CoreMemberEntitlementDisplayService::EVENT);
    $core=new CoreMemberEntitlementDisplayService();
    $none=$core->forMembers($site,[101,102]);
    extensionCheck($none===['sources'=>[],'members'=>[101=>[],102=>[]]],'no extension preserves empty presentation without granting a level');
    $page=(new MemberService())->getPage([]);
    extensionCheck($page['total']===2&&$page['member_entitlement_sources']===[],'official member pagination remains tenant-scoped and unchanged with no listener');
    $original=(new MemberService())->getInfo(101);
    extensionCheck($original['member_level']===''&&$original['member_entitlements']===[],'official detail retains its original empty-personal-level behavior');
    $calls=[];
    Event::listen(CoreMemberEntitlementDisplayService::EVENT,static function(array $params)use(&$calls):array{
        $calls[]=$params;$members=[];foreach($params['member_ids']as$id)$members[$id]=extensionCard();
        // Neither a foreign member nor a primary field may be merged into a row.
        $members[103]=extensionCard('FOREIGN');
        return['key'=>'sample_subject','title'=>'<b>门店权益</b>','member_level'=>999,'members'=>$members];
    });
    $page=(new MemberService())->getPage([]);$rows=array_column($page['data'],null,'member_id');$detail=(new MemberService())->getInfo(101);
    extensionCheck(count($calls)===2&&$calls[0]['site_id']===$site&&count($calls[0]['member_ids'])===2&&$calls[1]['member_ids']===[101],'list dispatches once for its own page and detail once for the selected member');
    extensionCheck(!isset($rows[103])&&$page['total']===2,'extension cannot inject another tenant member into list data');
    extensionCheck($page['member_entitlement_sources']===[['key'=>'sample_subject','title'=>'门店权益']],'source title is plain text and not a template or raw HTML');
    extensionCheck($rows[101]['member_entitlements'][0]['label']==='白银'&&$rows[101]['member_level']==0,'official row can show paid store rights while preserving the original personal grade');
    extensionCheck($detail['member_entitlements']===$rows[101]['member_entitlements']&&$detail['member_entitlement_sources']===$page['member_entitlement_sources'],'official list and detail use the same read-only projection contract');
    extensionCheck(!array_key_exists('member_level',$rows[101]['member_entitlements'][0]),'arbitrary extension fields cannot overwrite account identity or personal membership');
    extensionCheck($core->forMembers(0,[101])['sources']===[]&&$core->forMembers($site,[0,-1,[],null,'bad'])['sources']===[],'invalid site and invalid member values do not trigger display reads');

    Event::remove(CoreMemberEntitlementDisplayService::EVENT);$batches=[];
    Event::listen(CoreMemberEntitlementDisplayService::EVENT,static function(array $params)use(&$batches):array{$batches[]=$params['member_ids'];$map=[];foreach($params['member_ids']as$id)$map[$id]=extensionCard();return['key'=>'batch','title'=>'批量权益','members'=>$map];});
    $large=$core->forMembers($site,array_merge(range(1,1001),[1,2,'3']));
    extensionCheck(count($batches)===3&&array_map('count',$batches)===[500,500,1]&&count($large['members'])===1001,'large pages are deduplicated and split into bounded batches, not N+1 or silently truncated');
    extensionCheck(count($large['sources'])===1&&$large['members'][1001][0]['status']==='active','a later batch shares the same source without being treated as a duplicate source');

    foreach(['missing','invalid-status','invalid-time','empty-label','duplicate']as$mode){
        Event::remove(CoreMemberEntitlementDisplayService::EVENT);
        $factory=static function(array $params)use($mode):array{$card=extensionCard();if($mode==='invalid-status')$card['status']='paid';if($mode==='invalid-time')$card['expires_at']=-1;if($mode==='empty-label')$card['label']='';return['key'=>'test','title'=>'只读权益','members'=>$mode==='missing'?[]:[101=>$card]];};
        Event::listen(CoreMemberEntitlementDisplayService::EVENT,$factory);if($mode==='duplicate')Event::listen(CoreMemberEntitlementDisplayService::EVENT,static fn(array $params):array=>$factory($params));
        $bad=$core->forMembers($site,[101]);
        extensionCheck($bad['members'][101][0]['status']==='unavailable','malformed or missing data is explicitly unavailable, never not-opened: '.$mode);
    }
    Event::remove(CoreMemberEntitlementDisplayService::EVENT);
    Event::listen(CoreMemberEntitlementDisplayService::EVENT,static function():array{throw new RuntimeException('SYNTHETIC_INTERNAL_SECRET_NOT_FOR_CUSTOMERS');});
    $bad=(new MemberService())->getPage([]);
    extensionCheck($bad['total']===2&&$bad['data'][0]['member_entitlements'][0]['status']==='unavailable','an extension failure does not break the official member list');
    extensionCheck(strpos(json_encode($bad),'SYNTHETIC_INTERNAL_SECRET')===false,'raw extension exceptions do not leak into the API payload');
    Event::remove(CoreMemberEntitlementDisplayService::EVENT);
    $after=(new MemberService())->getInfo(101);
    extensionCheck($after['member_entitlements']===[]&&$after['member_entitlement_sources']===[],'removing an extension immediately removes its read projection without stale account state');
    extensionCheck(Db::name('member')->order('member_id')->select()->toArray()===$before,'list/detail display never modifies a member, personal level or other account field');
    // The real official endpoints -> registered plugin listener -> verified
    // subject ledger chain, including a staff seat entering and leaving.
    $auth=new ReflectionProperty(app\Request::class,'auth_info');$auth->setAccessible(true);$auth->setValue(null,['uid'=>1,'app_type'=>'site','member_id'=>0]);
    // The framework's subscription resolver uses group apps + site addons,
    // not the fixture's standalone `app` display field.
    Db::name('site')->where('site_id',$site)->update(['addons'=>json_encode(['hsx_lead'])]);
    think\facade\Cache::clear();
    $context=new addon\hsx_lead\app\service\Context($site,1);
    $config=addon\hsx_lead\app\service\cooperation\ConfigService::defaults();$config['enabled']=true;
    (new addon\hsx_lead\app\service\cooperation\ConfigService($context))->save($config);
    leadMembershipSeed($site);leadSetEntryDefinition($site,702);
    Db::name('member_level')->where('site_id',$site)->where('level_id',702)->update(['level_name'=>'白银']);
    $owner=new addon\hsx_lead\app\service\Context($site,0,101);$staff=new addon\hsx_lead\app\service\Context($site,0,102);
    $profile=(new addon\hsx_lead\app\service\cooperation\PartnerService($owner))->saveProfile(['name'=>'合成门店','contact_name'=>'负责人','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'合成测试地址']);
    leadMembershipGrant($site,101,'ML702','year');
    Event::listen(CoreMemberEntitlementDisplayService::EVENT,addon\hsx_lead\app\listener\member\MemberAdminEntitlementDisplay::class);
    $official=(new MemberService())->getInfo(101);$card=$official['member_entitlements'][0];
    $state=addon\hsx_lead\app\service\cooperation\EntityMembershipService::state($site,(int)$profile['id']);
    extensionCheck($card['label']==='白银'&&$card['status']==='active'&&$card['expires_at']===$state['expires_at']&&$official['member_level']==='','real official detail shows white-silver paid subject while the empty personal grade stays untouched');
    $ownerTeam=new addon\hsx_lead\app\service\cooperation\TeamService($owner);$staffTeam=new addon\hsx_lead\app\service\cooperation\TeamService($staff);
    $staffTeam->join(['subject_code'=>$ownerTeam->summary()['subject_code']]);$ownerTeam->review(102,true);
    $officialPage=(new MemberService())->getPage([]);$officialRows=array_column($officialPage['data'],null,'member_id');
    extensionCheck($officialRows[101]['member_entitlements'][0]['label']==='白银'&&$officialRows[102]['member_entitlements'][0]['label']==='白银'&&$officialRows[102]['member_entitlements'][0]['expires_at']===$state['expires_at'],'real official page shares identical subject tier and expiry with the approved staff account');
    extensionCheck(str_ends_with($officialRows[101]['member_entitlements'][0]['context'],'负责人')&&str_ends_with($officialRows[102]['member_entitlements'][0]['context'],'店员'),'list identifies owner vs staff without assigning a personal tier');
    $staffTeam->leave();$departed=(new MemberService())->getInfo(102);$ownerAfter=(new MemberService())->getInfo(101);
    extensionCheck($departed['member_entitlements'][0]['status']==='not_joined'&&$ownerAfter['member_entitlements'][0]['status']==='active','official detail immediately stops shared display after staff leaves, retaining owner rights');
    extensionCheck((int)Db::name('member')->where('member_id',101)->value('member_level')===0&&(int)Db::name('member')->where('member_id',102)->value('member_level')===0,'neither payment, shared membership nor staff exit writes personal levels');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'real official MemberService list/detail and generic event extension; isolated localhost schema and synthetic listener payloads; no existing data or payment'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{Event::remove(CoreMemberEntitlementDisplayService::EVENT);if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
