import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {execFileSync} from 'node:child_process'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

// Pure dictionaries + the real admin editor setup. No framework service/DB,
// installed-site state, browser, publication or saved decoration mutations.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const workspace=path.resolve(plugin,'../../..'),require=createRequire(path.join(workspace,'admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const php=`function get_lang($key){return $key;} echo json_encode(['template'=>require ${JSON.stringify(path.join(plugin,'app/dict/diy/template.php'))},'pages'=>require ${JSON.stringify(path.join(plugin,'app/dict/diy/pages.php'))},'components'=>require ${JSON.stringify(path.join(plugin,'app/dict/diy/components.php'))},'reference'=>require ${JSON.stringify(path.join(workspace,'niucloud/addon/phone_shop/app/dict/diy/template.php'))}],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);`
const dict=JSON.parse(execFileSync(process.env.PHP_BIN||'php',['-d','display_errors=stderr','-d','error_reporting=0','-r',php],{encoding:'utf8'}))
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const type='DIY_HSX_LEAD_INDEX',template=dict.template[type],reference=dict.reference.DIY_PHONE_SHOP_INDEX
const registration=fs.readFileSync(path.join(plugin,'package/uni-app-pages.php'),'utf8').match(/<<<EOT\s*([\s\S]*?)\s*EOT/)
check(!!registration,'mobile page registration is available')
const pageRegistry=createRequire(path.join(workspace,'uni-app/package.json'))('json5').parse('[\n'+registration[1]+'\n]')[0].pages
check(pageRegistry.find(item=>item.path==='pages/index')?.needLogin===false,'presentation-only DIY landing page permits anonymous framework decorator iframe')
const visitorEntries=['pages/index','pages/profile/index','pages/stores/index','pages/workbench/index','pages/invite/index']
check(visitorEntries.every(name=>pageRegistry.find(item=>item.path===name)?.needLogin===false)&&pageRegistry.filter(item=>!visitorEntries.includes(item.path)).every(item=>item.needLogin===true),'four visitor shells and the promotion login entry are public; actual task, catalog, membership and wallet routes remain authenticated')
const protectedEntries=['pages/task/index','pages/catalog/index','pages/entity/index','pages/membership/index','pages/orders/index','pages/wallet/index','pages/notifications/index']
check(pageRegistry.filter(item=>item.needLogin===true).map(item=>item.path).sort().join(',')===protectedEntries.sort().join(','),'the complete protected task/catalog/entity/membership/orders/wallet and notification-preference route set retains login protection')
for(const key of ['page','action','type'])check(typeof template[key]===typeof reference[key],`template ${key} follows the existing shop contract`)
check(template.action==='decorate'&&template.type==='index'&&template.page==='/addon/hsx_lead/pages/index','template declares a real plugin home route, not a separate decoration stack')
const page=dict.pages[type].hsx_lead_index,entry=dict.components.HSX_LEAD_COMPONENT.list.LeadCooperationEntry,component=dict.pages[type].hsx_lead_combined.data.value.find(row=>row.componentName==='LeadCooperationEntry')
check(page.mode==='diy'&&page.data.value.map(row=>row.componentName).join(',')==='LeadCooperationHero,LeadRoleEntry,LeadRoleEntry,LeadBusinessNavigation','framework default page separates hero, both role cards and business navigation')
check(page.data.value[1].role==='stores'&&page.data.value[2].role==='customers'&&dict.components.HSX_LEAD_COMPONENT.list.LeadRoleEntry.uses===0,'repeatable single card carries explicit fixed role and no arbitrary URL')
check(component.path===entry.path&&component.path==='edit-lead-cooperation-entry'&&entry.support_page.includes(type),'PHP editor path, renderer name and supported-page filter agree')
for(const key of ['topStatusBar','bottomTabBar','copyright','popWindow','template'])check(page.data.global[key]&&typeof page.data.global[key]==='object',`default page includes framework global.${key}`)
check(['once','always'].includes(page.data.global.popWindow.count)&&page.data.global.popWindow.show===0,'popup default uses the existing once/always editor values without enabling a popup')
check(page.data.global.bottomTabBar.isShow===true&&page.data.global.bottomTabBar.designNav.key==='hsx_lead','default navigation uses the framework selector key')
check(Array.isArray(component.ignore)&&component.margin&&['top','bottom','both'].every(key=>Number.isFinite(component.margin[key])),'default component is safe for the framework common-style slot and group layout')
check(fs.existsSync(path.join(plugin,'admin/views/diy/components',component.path+'.vue'))&&fs.existsSync(path.join(plugin,'uni-app/components/diy/lead-cooperation-entry/index.vue')),'both sides of the framework DIY registration exist')
const filename=path.join(plugin,'admin/views/diy/components/edit-lead-cooperation-entry.vue'),parsed=compiler.parse(fs.readFileSync(filename,'utf8'),{filename})
assert.deepEqual(parsed.errors,[]);checks++
const script=compiler.compileScript(parsed.descriptor,{id:'lead-editor-contract'})
assert.deepEqual(compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'lead-editor-contract',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors,[]);checks++
const store=Vue.reactive({currentIndex:0,editTab:'content',value:[JSON.parse(JSON.stringify(component))],predefineColors:[],get editComponent(){return this.value[this.currentIndex]}})
const mounted=[],module={exports:{}},js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
const presetModule={exports:{}},presetJs=ts.transpileModule(fs.readFileSync(path.join(plugin,'admin/composables/diyPresets.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${presetJs}\n})`,{String,Object,Array})(()=>{throw Error('Unexpected preset dependency')},presetModule,presetModule.exports)
const helperModule={exports:{}},helperJs=ts.transpileModule(fs.readFileSync(path.join(plugin,'admin/composables/diyBusinessPreview.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${helperJs}\n})`,{URL,String,Object,Array})(()=>{throw Error('Unexpected pure dependency')},helperModule,helperModule.exports)
const roleModule={exports:{}},roleJs=ts.transpileModule(fs.readFileSync(path.join(plugin,'admin/composables/roleEntry.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${roleJs}\n})`,{String,Object,Array})(()=>{throw Error('Unexpected role dependency')},roleModule,roleModule.exports)
vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{String,Object,Array})(key=>key==='vue'?{...Vue,onMounted:callback=>mounted.push(callback),onBeforeUnmount(){}}:key==='@/stores/modules/diy'?{default:()=>store}:key==='@/stores/modules/user'?{default:()=>({siteInfo:{site_id:100005}})}:key==='../../../api/cooperation'?{getCooperationConfig:async()=>({data:{businesses:[]}})}:key==='../../../composables/navigation'?{hasLeadPagePermission:()=>true}:key==='../../../composables/diyBusinessPreview'?helperModule.exports:key==='../../../composables/diyPresets'?presetModule.exports:key==='../../../composables/roleEntry'?roleModule.exports:key==='element-plus'?{ElMessageBox:{confirm:async()=>{}}}:key.endsWith('.vue')?{default:{}}:(()=>{throw Error(key)})(),module,module.exports)
module.exports.default.setup({value:store.value[0]},{expose(){}});mounted.forEach(callback=>callback())
check(store.editComponent.verify(0).code===true,'real admin component verifies the framework-selected page component')
store.editComponent.storeTitle='';check(store.editComponent.verify(0).message.includes('门店入口标题'),'missing required entry text reports a localized field')
store.editComponent.storeTitle='附近交付门店';store.editComponent.title='合成装修标题';store.editComponent.showBusinesses=0
check(store.value[0].storeTitle==='附近交付门店'&&store.value[0].title==='合成装修标题'&&store.value[0].showBusinesses===0,'editor binds to the same reactive framework component rather than a separate draft/schema')
const homeSource=fs.readFileSync(path.join(plugin,'admin/views/cooperation/home-page.vue'),'utf8')
check(homeSource.includes("path:'/decorate/edit'")&&homeSource.includes(`name:'${type}'`),'admin entry uses the same framework route/name initialization as the platform')
console.log(`PASS ${checks} DIY home contract checks; real PHP dictionaries and admin editor setup, no site APIs/browser/database/deployment operations.`)
