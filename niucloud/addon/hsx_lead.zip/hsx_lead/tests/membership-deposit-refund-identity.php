<?php
declare(strict_types=1);
namespace app\service\core\pay {
    /** Test-local namespace seam: force the framework to reuse exactly one
     * identity on every create. No timing dependence, sleep or vendor edits.
     */
    function create_no(string $prefix='',string $tag=''):string{return 'FORCED_FRAMEWORK_REFUND_COLLISION';}
}
namespace {
    // The included real-service suite requires --isolated-local-mysql and
    // disabled network, owns/cleans its random schema, and tests both genuine
    // multi-source balance returns and previously submitted original refunds.
    require __DIR__.'/membership-deposit.php';
}
