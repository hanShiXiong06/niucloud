import assert from 'node:assert/strict'
import {lstat} from 'node:fs/promises'
import path from 'node:path'
import {fileURLToPath,pathToFileURL} from 'node:url'

// Execute the real source validator under --check. Never creates a zip, installs a plugin or runs PHP/DDL.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..'),script=path.join(plugin,'scripts/package.mjs'),prefix='niucloud/addon/hsx_lead'
const releasePath=path.join(workspace,'output/hsx-lead-0.0.1-release-20990101')
const exists=async file=>{try{const stat=await lstat(file);return{directory:stat.isDirectory(),modified:stat.mtimeMs}}catch(error){if(error.code==='ENOENT')return null;throw error}}
const before=await exists(releasePath),argv=process.argv,releaseDate=process.env.HSX_LEAD_RELEASE_DATE,log=console.log,output=[]
let manifest
try{
 process.argv=[process.argv[0],script,'--check'];process.env.HSX_LEAD_RELEASE_DATE='20990101';console.log=value=>output.push(String(value))
 ;({manifest}=await import(pathToFileURL(script).href))
}finally{process.argv=argv;if(releaseDate===undefined)delete process.env.HSX_LEAD_RELEASE_DATE;else process.env.HSX_LEAD_RELEASE_DATE=releaseDate;console.log=log}
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
const summary=JSON.parse(output.at(-1)),files=manifest.files.map(row=>row.path)
check(summary.writes===false&&summary.framework_files===0&&summary.package_type==='fresh-install-source','real --check validates a source-only plan without claiming deployment')
assert.deepEqual(await exists(releasePath),before,'check must not create or rewrite a release directory');checks++
check(summary.source_files===files.length&&new Set(files).size===files.length,'runtime manifest matches the exact validated unique source list')
check(files.every(file=>file.startsWith(prefix+'/'))&&manifest.framework_files.length===0,'all packaged files are scoped to the plugin, not mounted frontend or framework paths')
check(files.every(file=>!/(?:^|\/)(?:tests|node_modules|runtime|output|dist|build|\.git)(?:\/|$)/.test(file)&&!/(?:\.env|curl\.txt|\.(?:pem|key|zip|log|bak|tmp|sqlite|db)$)/i.test(file)),'test data, compiled artifacts, runtime data and credential files remain excluded')
for(const file of ['uni-app/pages/notifications/index.vue','sql/notice-runtime.sql','scripts/upgrade-notice-runtime.php','scripts/upgrade-menu-groups.php','docs/MENU_GROUPS_20261109.md','docs/NOTICE_RUNTIME_UPGRADE_20261109.md','docs/NOTICE_POLISH_20261109.md','docs/PAYMENT_HELP_PHONE_SEARCH.md','app/service/cooperation/PaymentHelpService.php','app/support/AdminKeywordSearch.php','admin/views/cooperation/PaymentHelpSettings.vue','admin/api/paymentHelp.ts','uni-app/components/cooperation/CoopPaymentHelp.vue','uni-app/composables/usePaymentHelp.ts','uni-app/api/paymentHelp.ts'])check(files.includes(prefix+'/'+file),'explicit release source exists: '+file)
check(!files.includes(prefix+'/scripts/package.mjs')&&!files.some(file=>file.includes('/tests/')),'development packager and regression fixtures are not shipped')
check(summary.mobile_pages===12&&manifest.mobile_pages.includes('addon/hsx_lead/pages/notifications/index'),'page validation includes the registered notification-preference route')
check(summary.notice_runtime_tables===3&&manifest.notice_runtime_schema_entry.adds_tables===3&&manifest.notice_runtime_schema_entry.adds_columns===0,'schema contract explicitly declares only three new notification tables')
assert.deepEqual([...manifest.notice_runtime_schema_entry.tables].sort(),['hsx_lead_notice_attempt','hsx_lead_notice_preference','hsx_lead_notice_task']);checks++
check(manifest.notice_runtime_schema_entry.executes_ddl===true&&manifest.notice_runtime_schema_entry.requires_explicit_apply===true&&manifest.notice_runtime_schema_entry.mysql_ddl_atomic_batch===false,'DDL is explicit and never represented as an atomic rollback-capable batch')
check(manifest.notice_runtime_schema_entry.clears_business_data===false&&manifest.notice_runtime_schema_entry.replays_historical_events===false&&manifest.notice_runtime_schema_entry.fresh_install_already_contains_tables===true,'new-install schema and existing-install additive upgrade remain distinct without history replay')
check(manifest.menu_groups_entry.executes_ddl===false&&manifest.menu_groups_entry.preserves_existing_business_permissions===true&&manifest.menu_groups_entry.grants_new_api_permissions===false,'menu grouping does not silently widen business/API access')
const ordered=manifest.notification_upgrade_order.filter(step=>step.check)
assert.deepEqual(ordered.map(step=>step.step),['notice_runtime_schema','menu_groups','mount_plugin']);checks++
check(ordered.every(step=>step.check.endsWith(' --check')&&step.apply.endsWith(' --apply')),'maintenance check and apply remain separate human-triggered commands')
const dependency=manifest.notification_event_dependency
check(dependency.event==='MemberAccount'&&dependency.required_additional_field==='account_log_id'&&dependency.source_identity==='member_account_log.id'&&dependency.timing==='after_ledger_insert_before_transaction_commit','notification depends on the generic transactional ledger identity instead of guessing source data')
check(manifest.required_framework_updates.some(file=>file.path===dependency.framework_path)&&dependency.packaged_framework_source===false&&!files.includes(dependency.framework_path),'necessary framework dependency is documented separately and never bundled into the plugin')
check(manifest.notification_upgrade_order.at(-1).step==='channel_configuration_and_acceptance','installation/compilation does not replace real channel authorization and delivery acceptance')
const manual=manifest.manual_receipts_schema_entry
check(manual?.adds_tables===1&&manual.adds_columns===0&&manual.executes_ddl&&manual.requires_explicit_apply,'manual receipts require a separate explicit one-table upgrade')
assert.deepEqual(manual.tables,['hsx_lead_manual_receipt']);checks++
check(!manual.replays_historical_payments&&!manual.changes_member_balances&&!manual.alters_existing_tables&&!manual.clears_business_data,'receipt schema upgrade cannot manufacture funds or modify financial history')
for(const file of ['sql/manual-receipts.sql','scripts/upgrade-manual-receipts.php','docs/MANUAL_RECEIPTS_AND_MEMBERSHIP_REFUND.md'])check(files.includes(prefix+'/'+file),'explicit manual-receipt source exists: '+file)
check(manifest.generated_configuration_files.some(file=>file.path==='uni-app/src/pages.json')&&!files.includes('uni-app/src/pages.json'),'shared generated manifests are regenerated, not overlaid by the archive')
console.log(`PASS ${checks} package contracts; actual --check and runtime manifest only, no archive, install, database or deployment writes.`)
