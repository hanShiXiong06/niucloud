<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ProfileFormService,PartnerService,ConfigService,Store};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$pdo=null;$schema='';$failed=false;$checks=0;
function pfCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function pfDeny(callable$call,string$label):void{try{$call();}catch(CommonException$e){pfCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$admin=new ProfileFormService(new Context($site,1));$ctx=new Context($site,0,101);$owner=new ProfileFormService($ctx);
    $profile=['name'=>'合成资料门店','contact_name'=>'合成负责人','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'隔离测试地址'];
    $merchant=(new PartnerService($ctx))->saveProfile($profile);
    pfCheck((int)$merchant['id']>0,'default profile without a new client version still saves before any form table is needed');
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['diy_form','diy_form_fields','diy_form_records','diy_form_records_fields']as$table){if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m))throw new RuntimeException('Missing official form DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    $component=static function(string$id,string$type,bool$required=false):array{return['id'=>$id,'componentType'=>'diy_form','componentName'=>$type,'componentTitle'=>'合成字段','isHidden'=>false,'field'=>['name'=>'资料'.$id,'required'=>$required,'unique'=>false,'privacyProtection'=>false,'cache'=>false,'value'=>'']];};
    $text=$component('text','FormInput',true);$number=$component('number','FormNumber',true);$radio=$component('radio','FormRadio');$radio['options']=[['id'=>'yes','text'=>'真实选项'],['id'=>'no','text'=>'不选']];
    $fields=[$text,$number,$radio];$value=['global'=>['completeLayout'=>'style-1','topStatusBar'=>['isShow'=>false],'bottomTabBar'=>['isShow'=>false]],'value'=>$fields];
    $form=(int)Db::name('diy_form')->insertGetId(['site_id'=>$site,'title'=>'门店补充测试','type'=>'DIY_FORM','status'=>1,'value'=>Data::json($value)]);
    foreach($fields as$f)Db::name('diy_form_fields')->insert(['site_id'=>$site,'form_id'=>$form,'field_key'=>$f['id'],'field_type'=>$f['componentName'],'field_name'=>$f['field']['name'],'field_required'=>$f['field']['required']?1:0]);
    $settings=$admin->admin();pfCheck($settings['extra_form']['enabled']===false&&count($settings['forms'])===1,'admin exposes real same-site forms and current default controls');
    pfCheck($admin->adminRecord((int)$merchant['id'])===['form_id'=>0,'title'=>'','version'=>'','fields'=>[]],'new merchant returns an explicit empty history contract, not malformed data');
    $save=static function(array$fields,array$extra,?string$version=null)use($admin):array{return$admin->save(['fields'=>$fields,'extra_form'=>$extra,'expected_version'=>$version??$admin->admin()['version']]);};
    $enabled=$save($settings['fields'],['enabled'=>true,'form_id'=>$form]);pfCheck($enabled['extra_form']['enabled']&&$enabled['version']!==$settings['version'],'configuration read-back contains a new authoritative version');
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>false,'form_id'=>0],$settings['version']),'stale administrator cannot overwrite new configuration');
    $read=$owner->member();pfCheck($read['extra_form']['definition']['status']===1&&count($read['extra_form']['definition']['value'])===3,'member gets controlled definition and no fake fallback');
    $payload=static fn(array$values):array=>['version'=>$read['version'],'form_id'=>$form,'values'=>$values];
    $before=Data::query('audit',$site)->count();
    foreach([
        $profile,
        $profile+['profile_form'=>$payload(['number'=>0])],
        $profile+['profile_form'=>$payload(['text'=>'x','number'=>0,'admin_uid'=>1])],
        $profile+['profile_form'=>array_replace($payload(['text'=>'x','number'=>0]),['form_id'=>$form+1])],
        $profile+['profile_form'=>array_replace($payload(['text'=>'x','number'=>0]),['version'=>str_repeat('0',64)])],
        $profile+['profile_form'=>$payload(['text'=>['field'=>['value'=>'x'],'isHidden'=>true],'number'=>0])],
        $profile+['profile_form'=>$payload(['text'=>'x','number'=>0,'radio'=>[['id'=>'forged','text'=>'恶意值']]])],
    ]as$i=>$bad)pfDeny(fn()=>(new PartnerService($ctx))->saveProfile($bad),'required/unknown/foreign/stale/hidden/type/option guard #'.$i);
    pfCheck(Data::query('audit',$site)->count()===$before&&Db::name('diy_form_records')->count()===0,'all invalid payloads roll back before writing records or audit');
    (new PartnerService($ctx))->saveProfile($profile+['profile_form'=>$payload(['text'=>'真实扩展值','number'=>0,'radio'=>[['id'=>'yes','text'=>'客户端假文字']]])]);
    $record=$admin->adminRecord((int)$merchant['id']);$byId=array_column($record['fields'],null,'id');
    pfCheck($byId['number']['value']==='0'&&$byId['number']['display_value']==='0','numeric zero survives real framework add and profile read-back');
    pfCheck($byId['radio']['value'][0]['text']==='真实选项','choice labels are canonical server labels, never client text');
    pfCheck(Db::name('diy_form_records_fields')->where('field_key','number')->value('field_value')==='0','actual zero exists in official field table');
    $audit=Data::query('audit',$site)->where('entity_type','merchant_profile_form')->order('id desc')->find();$auditData=Data::decode($audit['detail_json']);
    pfCheck(!isset($auditData['fields'])&&!str_contains($audit['detail_json'],'真实扩展值')&&isset($auditData['record_id']),'audit stores pointer/version only, not duplicate private form answers');
    $own=$owner->member();pfCheck($own['extra_form']['values']['text']==='真实扩展值','owner gets edit prefill from the verified own record');
    (new PartnerService($ctx))->saveProfile($profile+['profile_form'=>$payload(['text'=>'第二版','number'=>5])]);
    pfCheck(Db::name('diy_form_records')->count()===2&&$owner->member()['extra_form']['values']['text']==='第二版','edit appends a new immutable version and points to it');
    $current=$admin->admin();$optional=$current['fields'];$optional['storefront_image']['required']=true;
    $save($optional,['enabled'=>true,'form_id'=>$form]);$new=$owner->member();
    pfDeny(fn()=>(new PartnerService($ctx))->saveProfile($profile+['profile_form'=>['version'=>$new['version'],'form_id'=>$form,'values'=>['text'=>'x','number'=>1]]]),'configured storefront required is enforced server-side');
    $optional['storefront_image']=['visible'=>false,'required'=>false,'sort'=>20];$optional['business_license']=['visible'=>false,'required'=>false,'sort'=>10];
    $off=$save($optional,['enabled'=>false,'form_id'=>0]);
    (new PartnerService($ctx))->saveProfile($profile+['storefront_image'=>'untrusted/path','business_license_token'=>'forged-secret','profile_form'=>['version'=>$off['version'],'form_id'=>0,'values'=>[]]]);
    pfCheck((int)(new PartnerService($ctx))->bootstrap()['profile']['id']===(int)$merchant['id'],'hidden optional fields are omitted, not forwarded or used to replace evidence');
    $illegal=$optional;$illegal['business_license']['required']=true;pfDeny(fn()=>$save($illegal,['enabled'=>false,'form_id'=>0]),'hidden and required conflict is rejected');
    $foreign=(int)Db::name('diy_form')->insertGetId(['site_id'=>$site+1,'title'=>'其他站','type'=>'DIY_FORM','status'=>1,'value'=>Data::json($value)]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$foreign]),'foreign form cannot become this site configuration');
    Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json(['global'=>[],'value'=>[$component('file','FormFile')]])]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$form]),'unsupported upload field cannot silently enter private material form');
    Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json($value),'status'=>0]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$form]),'disabled form cannot be enabled as profile supplement');
    pfDeny(fn()=>(new ProfileFormService(new Context($site,0,102)))->admin(),'member cannot read admin configuration');
    pfDeny(fn()=>(new ProfileFormService(new Context($site+1,1)))->adminRecord((int)$merchant['id']),'cross-site record is not visible');
    Db::name('diy_form')->where('form_id',$form)->update(['status'=>1,'value'=>Data::json($value)]);
    $enabled=$save($settings['fields'],['enabled'=>true,'form_id'=>$form]);
    Db::name('diy_form')->where('form_id',$form)->update(['title'=>'管理员更新标题']);
    pfDeny(fn()=>(new PartnerService($ctx))->saveProfile($profile+['profile_form'=>['version'=>$enabled['version'],'form_id'=>$form,'values'=>['text'=>'x','number'=>1]]]),'native form edits invalidate a previously loaded profile version');
    Db::name('diy_form')->where('form_id',$form)->update(['title'=>'门店补充测试']);
    $unique=$text;$unique['field']['unique']=true;Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json(['global'=>[],'value'=>[$unique]])]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$form]),'unsupported unique setting is explicitly rejected rather than disabled silently');
    Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json(['global'=>[],'value'=>[$component('__proto__','FormInput')]])]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$form]),'reserved prototype field key is rejected before frontend projection');
    $unsafeOption=$radio;$unsafeOption['options']=[['id'=>'constructor','text'=>'invalid']];Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json(['global'=>[],'value'=>[$unsafeOption]])]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$form]),'reserved prototype choice key is rejected');
    $timeOnly=$component('time_only','FormDate');$timeOnly['dateFormat']='HH:mm';Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json(['global'=>[],'value'=>[$timeOnly]])]);
    pfDeny(fn()=>$save($settings['fields'],['enabled'=>true,'form_id'=>$form]),'pure time mode unsupported by the current native date leaf is rejected at configuration');
    Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json($value)]);
    $lastRecord=Db::name('diy_form_records')->order('record_id desc')->find();
    Data::query('merchant',$site)->where('id',$merchant['id'])->update(['member_id'=>102]);
    $newOwner=new ProfileFormService(new Context($site,0,102));$newOwnerForm=$newOwner->member();
    pfCheck($newOwnerForm['extra_form']['values']===[]&&$newOwnerForm['extra_form']['values_notice']==='负责人已变更，请重新核对补充资料','a new owner is not blocked or given prior private answer prefill');
    pfCheck($owner->member()['extra_form']['values']===[],'former owner cannot recover old store answers through member endpoint');
    pfCheck($admin->adminRecord((int)$merchant['id'])['fields'][0]['value']==='第二版','dedicated admin permission can still inspect the historical original-author record');
    (new PartnerService(new Context($site,0,102)))->saveProfile(array_replace($profile,['mobile'=>'19900000102','profile_form'=>['version'=>$newOwnerForm['version'],'form_id'=>$form,'values'=>['text'=>'新负责人核对','number'=>7]]]));
    pfCheck($newOwner->member()['extra_form']['values']['text']==='新负责人核对'&&Db::name('diy_form_records')->where('record_id',$lastRecord['record_id'])->find()===$lastRecord,'new owner can save own new version without rewriting historical record');
    $date=$component('date','FormDate',true);$date['dateFormat']='YYYY-MM-DD';$dateForm=['global'=>$value['global'],'value'=>[$date]];
    Db::name('diy_form')->where('form_id',$form)->update(['value'=>Data::json($dateForm)]);Db::name('diy_form_fields')->where('form_id',$form)->delete();Db::name('diy_form_fields')->insert(['site_id'=>$site,'form_id'=>$form,'field_key'=>'date','field_type'=>'FormDate','field_name'=>'日期','field_required'=>1]);
    $dateState=$newOwner->member();$dateProfile=array_replace($profile,['mobile'=>'19900000102']);$datePayload=static fn($date):array=>['version'=>$dateState['version'],'form_id'=>$form,'values'=>['date'=>$date]];
    pfDeny(fn()=>(new PartnerService(new Context($site,0,102)))->saveProfile($dateProfile+['profile_form'=>$datePayload(['date'=>'2026-02-31','timestamp'=>1])]),'invalid calendar date cannot be stored as a valid date');
    pfDeny(fn()=>(new PartnerService(new Context($site,0,102)))->saveProfile($dateProfile+['profile_form'=>$datePayload(['date'=>'','timestamp'=>''])]),'empty required structured date cannot bypass blank validation');
    (new PartnerService(new Context($site,0,102)))->saveProfile($dateProfile+['profile_form'=>$datePayload(['date'=>'2026-11-09','timestamp'=>1])]);
    pfCheck($newOwner->member()['extra_form']['values']['date']['timestamp']!==1,'date timestamp is derived from validated date, not trusted from client');
    $hookWrites=0;$hookCommitted=false;
    \think\facade\Event::listen('HsxLeadMerchantProfileValidate',static function(array$event)use(&$hookWrites):array{$hookWrites++;return['member_id'=>999,'merchant_id'=>999];});
    \think\facade\Event::listen('HsxLeadMerchantProfileSaved',static function(array$event)use(&$hookCommitted):void{$hookCommitted=!Db::connect()->getPdo()->inTransaction()&&$event['member_id']===102;throw new RuntimeException('synthetic extension failed after commit');});
    (new PartnerService(new Context($site,0,102)))->saveProfile($dateProfile+['profile_form'=>$datePayload(['date'=>'2026-11-10','timestamp'=>1])]);
    pfCheck($hookWrites===1&&$hookCommitted&&(int)Data::row('merchant',$site,(int)$merchant['id'])['member_id']===102,'validation return cannot overwrite identity; saved hook is post-commit and failure does not undo save');
    $hookCommitted=false;Db::startTrans();try{(new PartnerService(new Context($site,0,102)))->saveProfile($dateProfile+['profile_form'=>$datePayload(['date'=>'2026-11-11','timestamp'=>1])]);pfCheck(!$hookCommitted,'nested caller does not publish saved event before its outer commit');}finally{Db::rollback();}
    pfCheck($newOwner->member()['extra_form']['values']['date']['date']==='2026-11-10','outer rollback preserves the prior committed form pointer');
    \think\facade\Event::remove('HsxLeadMerchantProfileValidate');\think\facade\Event::remove('HsxLeadMerchantProfileSaved');
    \think\facade\Event::listen('HsxLeadMerchantProfileValidate',static function():void{throw new CommonException('合成扩展拒绝');});$beforeReject=Db::name('diy_form_records')->count();
    pfDeny(fn()=>(new PartnerService(new Context($site,0,102)))->saveProfile($dateProfile+['profile_form'=>$datePayload(['date'=>'2026-11-12','timestamp'=>1])]),'validation extension may reject before persistence');
    pfCheck(Db::name('diy_form_records')->count()===$beforeReject,'rejected extension creates no supplemental record');\think\facade\Event::remove('HsxLeadMerchantProfileValidate');
    $class=new ReflectionClass(\app\service\core\diy_form\CoreDiyFormRecordsService::class);$blank=$class->getMethod('isBlank');$blank->setAccessible(true);
    pfCheck(!$blank->invoke(null,0)&&!$blank->invoke(null,'0')&&$blank->invoke(null,' ')&&$blank->invoke(null,[]),'generic add blank helper preserves zero without changing edit flow');
    $nameBefore=Data::row('merchant',$site,(int)$merchant['id'])['name'];$countBefore=Db::name('diy_form_records')->count();
    $pdo->exec("CREATE TRIGGER pf_forced_failure BEFORE INSERT ON lt_diy_form_records FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='SECRET_SYNTHETIC_FORM_FAILURE'");
    try{(new PartnerService(new Context($site,0,102)))->saveProfile(array_replace($dateProfile,['name'=>'不得落库的新名字','profile_form'=>$datePayload(['date'=>'2026-11-13','timestamp'=>1])]));throw new RuntimeException('Expected persistence rejection');}
    catch(CommonException$e){pfCheck(str_contains($e->getMessage(),'门店资料未更新')&&!str_contains($e->getMessage(),'SECRET_'),'persistence failure is actionable and never exposes raw database detail');}
    finally{$pdo->exec('DROP TRIGGER pf_forced_failure');}
    pfCheck(Data::row('merchant',$site,(int)$merchant['id'])['name']===$nameBefore&&Db::name('diy_form_records')->count()===$countBefore,'supplement write failure rolls back the whole merchant update');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'Official form tables, profile transaction, schema/version/tenant guards; random owned localhost schema; no external requests or business data'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$e){$failed=true;fwrite(STDERR,'FAIL profile form after '.$checks.': '.get_class($e).' '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
finally{if(class_exists(\think\facade\Event::class)){\think\facade\Event::remove('HsxLeadMerchantProfileValidate');\think\facade\Event::remove('HsxLeadMerchantProfileSaved');}if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
