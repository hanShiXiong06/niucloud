import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual pure presentation contract and Vue SFC, with local image imports only.
// No API, paid-level inference, browser mutations, subscription or database use.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), { renderToString } = require('@vue/server-renderer')
const filename = path.join(plugin, 'uni-app/components/cooperation/CoopLevelBadge.vue')
const source = fs.readFileSync(filename, 'utf8'), parsed = compiler.parse(source, { filename })
const visual = loadMobileUtility('membership-visual')
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const same = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
check(parsed.errors.length === 0, 'badge SFC parses')
check(compiler.compileTemplate({ source: parsed.descriptor.template.content, filename, id: 'badge-visual' }).errors.length === 0, 'badge template compiles without dynamic HTML or business hooks')
for (const style of parsed.descriptor.styles) check(style.scoped && !compiler.compileStyle({ source: style.content, filename, id: 'data-v-badge-visual', scoped: true }).errors.length, 'badge has valid component-local CSS')
function component(inlineTemplate = true) {
    const js = ts.transpileModule(compiler.compileScript(parsed.descriptor, { id: 'badge-visual', inlineTemplate }).content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { console })(key => {
        if (key === 'vue') return Vue
        if (key === '../../utils/membership-visual') return visual
        if (key === '../../utils/membership-skin') return loadMobileUtility('membership-skin')
        throw Error('Unexpected dependency: ' + key)
    }, module, module.exports)
    return module.exports.default
}
async function render(props = {}) {
    const app = Vue.createSSRApp({ render: () => Vue.h(component(), props) })
    app.config.warnHandler = () => {}
    return renderToString(app)
}

for (const [input, expected] of [[0, 0], [1, 1], [4, 4], [5, 5], [8, 8], [10, 10], ['0', 0], ['2', 0], ['V1', 0], ['V4', 0]]) same(visual.membershipBadgeLevel(input), expected, 'only a numeric catalog display rank is accepted: ' + String(input))
for (const input of ['S', 'A', 'B', 'premium', 'standard', 'reliable', 'V5', '5', 'V4-member', 'v3', ' V3', 'V2 ', 4.5, -1, Infinity, null, true, {}, []]) same(visual.membershipBadgeLevel(input), 0, 'non-V or malformed value cannot produce a premium badge: ' + String(input))
let appearance = visual.membershipBadgeAppearance(4)
check(appearance.state === 'locked' && !appearance.glowing && !appearance.animated && appearance.stateLabel === '未开通', 'a high target level defaults to unowned, never a paid badge')
for (const value of [undefined, null, 'paid', 'ACTIVE', 1, true]) check(!visual.membershipBadgeAppearance(4, value).glowing, 'only explicit active state can glow: ' + String(value))
for (const rank of [1, 2]) check(!visual.membershipBadgeAppearance(rank, 'active', 'default', 'emblem', true).animated, 'lower levels do not animate on a requested animated flag')
for (const rank of [3, 4]) {
    check(visual.membershipBadgeAppearance(rank, 'active', 'default', 'emblem', true).animated, 'high active level may opt into gentle motion')
    check(!visual.membershipBadgeAppearance(rank, 'active', 'default', 'emblem').animated, 'motion remains opt-in even for active high levels')
    check(!visual.membershipBadgeAppearance(rank, 'expired', 'default', 'emblem', true).animated, 'expired high level cannot animate')
    check(!visual.membershipBadgeAppearance(rank, 'locked', 'default', 'emblem', true).glowing, 'unowned high level cannot emit active glow')
}
appearance = visual.membershipBadgeAppearance(0, 'active', 'large', 'emblem', true)
check(appearance.name === '普通会员' && !appearance.glowing && !appearance.animated && !appearance.stateLabel, 'ordinary level is one neutral identity, not a free premium credential')
appearance = visual.membershipBadgeAppearance(3, 'active', 'giant', 'html', 'true')
check(appearance.size === 'default' && appearance.variant === 'emblem' && !appearance.animated, 'invalid presentation values fall back to bounded defaults')
let html = await render({ level: 4 })
check(html.includes('state-locked') && html.includes('未开通') && !html.includes('is-glowing'), 'default rendered high-level preview cannot be mistaken for activated rights')
check(!html.includes('<image') && html.includes('coop-level-badge__surface'), 'unowned preview uses a native flat surface, never baked metallic artwork')
check(html.includes('aria-label="等级4，未开通"') && html.includes('role="img"'), 'screen-reader meaning includes unowned state')
html = await render({ level: 4, state: 'expired', animated: true })
check(html.includes('已到期') && html.includes('state-expired') && !html.includes('is-animated') && !html.includes('coop-level-badge__halo'), 'expired render removes active-only glow and movement')
check(!html.includes('<image') && html.includes('state-expired') && !html.includes('coop-level-badge__edge'), 'expired render uses unlit neutral geometry, not a merely faded glowing medal')
check(html.includes('coop-level-badge__caption') && !html.includes('coop-level-badge__name'), 'expired state remains visible when the optional level-name label is hidden')
html = await render({ level: 4, state: 'active' })
check(!html.includes('coop-level-badge__caption') && !html.includes('coop-level-badge__name') && html.includes('aria-label="等级4"'), 'active emblem defaults to one flat level mark without an empty or duplicate caption and keeps its accessible name')
html = await render({ level: 4, state: 'active', showLabel: true })
check(html.includes('coop-level-badge__name') && html.includes('>等级4</text>'), 'a dedicated level comparison can explicitly request the full name label')
html = await render({ level: 2, state: 'locked', showLabel: false })
check(html.includes('未开通') && html.includes('coop-level-badge__state') && !html.includes('coop-level-badge__name'), 'hiding the optional name cannot suppress an unowned state label')
html = await render({ level: 2, state: 'expired', showLabel: true })
check(html.includes('>等级2</text>') && html.includes('已到期'), 'opt-in full label and mandatory expiry state can coexist')
html = await render({ level: 0, state: 'active', animated: true })
check(html.includes('普通会员') && !html.includes('<image') && !html.includes('is-glowing'), 'ordinary render has no generated medal or bright light')
for (const size of ['small', 'default', 'large']) {
    html = await render({ level: 3, state: 'active', variant: 'emblem', size, animated: true })
    check(html.includes('size-' + size) && html.includes('is-animated') && html.includes('coop-level-badge__edge') && !html.includes('<image') && html.includes('>V3</text>'), 'emblem ' + size + ' renders native readable V text and an opt-in edge, without pre-glowing artwork')
    html = await render({ level: 2, state: 'active', variant: 'inline', size })
    check(html.includes('variant-inline') && html.includes('>V2</text>') && !html.includes('<image') && !html.includes('V2会员</text>'), 'inline ' + size + ' retains one compact native V identifier without shrinking winged art')
}
html = await render({ level: 0, variant: 'inline' })
check(html.includes('>普通会员</text>') && !html.includes('未开通'), 'ordinary inline label has no confusing unowned membership status')
html = await render({ level: 2, state: 'active', variant: 'inline', showLabel: true })
check(html.includes('>V2</text>') && !html.includes('coop-level-badge__caption') && !html.includes('>V2会员</text>'), 'showLabel does not change the compact inline presentation')
html = await render({ level: 8, label: '旗舰合作商户', state: 'active', showLabel: true })
check(html.includes('>旗舰合作商户</text>') && !html.includes('>V8</text>') && html.includes('level-8') && !html.includes('<image'), 'arbitrary configured tier uses its actual name and rank rather than being collapsed into four hardcoded skins')
const props = Vue.reactive({ level: 1, state: 'active', size: 'default', variant: 'emblem', animated: false })
const scope = Vue.effectScope(), setup = scope.run(() => component(false).setup(props, { expose() {} }))
check(!setup.showEdgeLight.value && setup.badge.value.code === 'V1' && setup.badge.value.state === 'active', 'lower active tier is a readable native label with no artwork dependency or halo')
props.level = 2; await Vue.nextTick()
check(!setup.showEdgeLight.value && setup.badge.value.code === 'V2', 'switching lower tier updates the label without importing a glowing asset')
props.state = 'expired'; await Vue.nextTick()
check(!setup.showEdgeLight.value && !setup.badge.value.glowing, 'expiry immediately removes active edge emphasis')
scope.stop()
for (const rank of [1, 2]) {
    html = await render({ level: rank, state: 'active', animated: true, appearance:{avatar_effect:false} })
    check(!html.includes('is-glowing') && !html.includes('is-animated') && !html.includes('coop-level-badge__edge') && !html.includes('<image'), 'effect opt-out suppresses edge emphasis regardless of rank '+rank)
}
html = await render({ level: 8, state: 'active', variant: 'inline' })
check(!html.includes('is-glowing') && !html.includes('coop-level-badge__edge'), 'even a high active inline tier has no edge light unless explicitly opted in')
const css = parsed.descriptor.styles.map(style => style.content).join('\n')
check(!/box-shadow|text-shadow|radial-gradient|filter\s*:|infinite/.test(css)&&css.includes('var(--lead-member-gradient)'), 'configured gradient is shared with membership cards, without permanent halos or endless badge effects')
check(css.includes('1400ms ease-out 1') && css.includes('opacity:.38'), 'the opted-in high-tier edge is a single subtle pass, not a permanent blinking status')
check(!css.includes('96px') && css.includes('height:48px'), 'large emblem remains bounded rather than expanding into a large decorative medal')
check(!source.includes('.png') && [1,2,3,4].every(rank => !fs.existsSync(path.join(plugin, `uni-app/static/cooperation/levels/level-v${rank}.png`))), 'retired baked-metal badge images are absent from the runtime package')
check(source.includes('@media (prefers-reduced-motion: reduce)') && source.includes('animation: none'), 'reduced-motion styling disables movement')
check(!/background-position|setInterval|setTimeout|navigateTo|uni\.|v-html|:deep\s*\(/.test(source), 'presentation does not use busy repaint animations, navigation, business APIs or unsafe style shortcuts')
check(!source.includes('S级') && !source.includes('靠谱认证') && !source.includes('service_provider'), 'V display cannot silently merge older qualifications or provider approval')
console.log(`PASS ${checks} V-level badge presentation checks; real Vue SFC and pure helper, no HTTP, payment, qualification change or database mutation.`)
