import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { performance } from 'node:perf_hooks'
import { loadMobileUtility } from './mobile-utils.mjs'

// Synthetic 5,000-leaf catalog; actual SFC setup and Vue computed graph only.
// No database, requests, local storage, framework payment or ERP calls.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const file = path.join(plugin, 'uni-app/components/cooperation/ModelCatalogPicker.vue')
const source = fs.readFileSync(file, 'utf8'), parsed = compiler.parse(source, { filename: file })
const script = compiler.compileScript(parsed.descriptor, { id: 'catalog-performance' })
const utility = loadMobileUtility('catalog-selection'), cleanups = []
let checks = 0
const check = (condition, label) => { assert.ok(condition, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
const raw = Array.from({ length: 5000 }, (_, id) => ({ id: `item_${id}`, title: `型号${id}`, path: ['手机', `品牌${id % 20}`, `型号${id}`], aliases: [`lookup_${id}`] }))
const counters = { normalize: 0, index: 0, states: 0 }
const counted = { ...utility,
    normalizeCatalog: (...args) => { counters.normalize++; return utility.normalizeCatalog(...args) },
    indexCatalog: (...args) => { counters.index++; return utility.indexCatalog(...args) },
    indexedSelectionStates: (...args) => { counters.states++; return utility.indexedSelectionStates(...args) },
}
function fixture(options = {}) {
    const props = Vue.reactive({ show: true, page: true, modelValue: [], title: '业务能力', max: 0, businessType: 'purchase', selectionMode: 'multiple', initialView: 'browse', bulkActions: true, ...options })
    const events = [], module = { exports: {} }
    const js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const deps = { vue: { ...Vue, onBeforeUnmount: fn => cleanups.push(fn) }, '../../utils/mobile-ui': loadMobileUtility('mobile-ui'), '../../utils/catalog-selection': counted,
        '../../utils/interaction-feedback': { interactionFeedback() {} }, '../../api/cooperation': { cooperationCatalog: async () => ({ data: raw }), coopError: (cause, fallback) => cause?.message || fallback } }
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`, { Number, String, JSON, Set, Map, Object })(key => key.endsWith('.vue') ? { default: {} } : key in deps ? deps[key] : (() => { throw Error('Unexpected import ' + key) })(), module, module.exports)
    return { props, events, state: module.exports.default.setup(props, { emit: (...args) => events.push(args), expose() {} }) }
}
const settle = async () => { for (let i = 0; i < 6; i++) { await Promise.resolve(); await Vue.nextTick() } }
check(!parsed.errors.length, 'catalog performance SFC parses')
check(!compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'catalog-performance', compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } }).errors.length, 'incremental native scroll template compiles')

const f = fixture(); await settle(); const s = f.state
check(s.rows.value.length === 5000 && s.visibleRows.value.length === 5000, 'full 5,000 options remain addressable')
check(s.renderedRows.value.length === 60, 'only first 60 leaf views enter initial rendering')
check(!Vue.isReactive(s.rows.value) && !Vue.isReactive(s.chosen.value), 'immutable catalog and chosen arrays avoid deep reactive proxies')
const stableIndex = s.catalogIndex.value, stableRange = s.visibleRows.value
Object.keys(counters).forEach(key => { counters[key] = 0 })
const start = performance.now()
s.batch('select_all')
check(s.chosen.value.length === 5000 && s.renderedRows.value.length === 60, 'all-select selects unrendered options without expanding native nodes')
check(s.categorySelectionState('手机').checked && s.categoryCount('手机') === 5000, 'parent counts include every selected descendant')
for (const brand of s.activeGroup.value.brands) check(s.brandSelectionState(brand.key).checked && s.brandCount(brand.key) === 250, 'each brand uses its complete indexed descendant count')
check(s.catalogIndex.value === stableIndex && s.visibleRows.value === stableRange, 'selection change does not rebuild catalog indexing or browse results')
check(counters.normalize === 0 && counters.index === 0 && counters.states === 1, 'all-select and all parent indicators use one count pass, no renormalization')
check(s.rangeState.value.count === 5000 && s.rangeState.value.checked, 'range indicator is based on all 5,000 rows')
s.loadMore(); check(s.renderedRows.value.length === 120 && s.chosen.value.length === 5000, 'scroll loading appends only 60 views and never changes selection')
s.keyword.value = 'lookup_4999'; s.search(); await settle()
check(s.visibleRows.value.length === 1 && s.renderedRows.value[0].id === 'item_4999', 'search reaches a previously unrendered leaf')
check(s.renderLimit.value === 60, 'changing search resets only the rendering window')
s.batch('clear'); check(s.chosen.value.length === 4999 && !s.selectedIds.value.has('item_4999'), 'clearing a search affects just its complete result')
s.clearSearch(); await settle(); s.batch('toggle_all')
check(s.chosen.value.length === 5000, 'partial whole-range selection restores its missing leaf')
s.activeBrand.value = '品牌19'; await settle(); check(s.visibleRows.value.length === 250 && s.renderedRows.value.length === 60, 'brand navigation resets render window but keeps complete range')
s.batch('invert'); check(s.chosen.value.length === 4750 && s.brandCount('品牌19') === 0, 'inverse applies to all 250 brand descendants, not 60 rendered leaves')
check(s.categorySelectionState('手机').indeterminate, 'partial category status remains correct after full brand inverse')
s.toggleBrand('品牌19'); check(s.chosen.value.length === 5000, 'brand parent check restores all unrendered descendants')
s.toggleSelectedView(); await settle(); check(s.visibleRows.value.length === 5000 && s.renderedRows.value.length === 60, 'review selected items also renders incrementally')
s.loadMore(); s.loadMore(); check(s.renderedRows.value.length === 180, 'multiple native bottom events append successive pages')
check(!f.events.length, 'selection and rendering do not implicitly commit form data')
s.confirm(); check(f.events[0][0] === 'update:modelValue' && f.events[0][1].length === 5000 && f.events[1][0] === 'close', 'confirmation returns all 5,000 choices through existing page contract')
check(f.props.modelValue.length === 0, 'parent input remains unmodified before its explicit update handler')

const limited = fixture({ max: 5, modelValue: [raw[0]] }); await settle()
limited.state.toggleCategory('手机'); check(limited.state.chosen.value.length === 1 && limited.state.selectionError.value.includes('5 项'), 'bounded demand selection rejects oversized all-select atomically')
limited.state.cancel(); equal(limited.events, [['close']], 'cancellation does not return edited selections')
const single = fixture({ selectionMode: 'single' }); await settle(); single.state.toggle(single.state.rows.value[4999]); single.state.toggle(single.state.rows.value[0])
equal(single.state.chosen.value.map(row => row.id), ['item_0'], 'single-selection replacement remains independent of rendering window')

const mixed = utility.normalizeCatalog([{ id: 'one', title: '一', path: ['手机', '苹果', '一'] }, { id: 'two', title: '二', path: ['平板', '苹果', '二'] }])
const grouping = utility.indexedSelectionStates(utility.indexCatalog(mixed), new Set(['one', 'saved_unknown']))
check(grouping.brands.get('手机').get('苹果').checked && !grouping.brands.get('平板').get('苹果').checked, 'same-named second-level brands remain scoped to first-level category')
const initial = utility.normalizeCatalog(raw.slice(0, 2)), same = utility.applyIndexedSelection(initial, initial, 'select_all', 0)
check(same.items === initial, 'a no-op batch preserves the immutable choice reference')
check(source.includes('@scrolltolower="loadMore"') && source.includes('v-for="item in renderedRows"') && !source.includes('v-for="item in chosen"'), 'template sends bounded leaf rows and selected counts, never an all-chosen tag wall')
for (const stop of cleanups) stop()
console.log(JSON.stringify({ passed: true, checks, synthetic_options: 5000, initially_rendered: 60, observed_sequence_ms: Math.round((performance.now() - start) * 100) / 100, scope: 'actual Vue setup with synthetic transport; no business writes or real devices' }))
