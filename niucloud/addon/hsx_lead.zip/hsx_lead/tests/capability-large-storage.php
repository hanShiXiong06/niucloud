<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions before isolated testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';

use addon\hsx_lead\app\service\{CatalogConfigStorage as Storage, CatalogService, Context};
use addon\hsx_lead\app\service\cooperation\{CapabilityService, ConfigService, PartnerService};
use core\exception\CommonException;
use think\facade\Db;

$checks = 0; $failed = false; $pdo = null; $schema = ''; $trigger = false;
function capabilityLargeCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function capabilityLargeReject(callable $operation, string $label): void
{
    try { $operation(); }
    catch (Throwable $error) {
        if (!$error instanceof CommonException && !$error instanceof PDOException && !$error instanceof \think\db\exception\PDOException && !$error instanceof RuntimeException) throw $error;
        capabilityLargeCheck(true, $label); return;
    }
    throw new RuntimeException('Expected safe capability refusal: ' . $label);
}

try {
    [$app, $pdo, $schema, $site] = leadBoot(); leadAssertIsolated($schema);
    $columnBefore = Db::query('SHOW COLUMNS FROM `lt_sys_config`');
    $valueColumn = array_values(array_filter($columnBefore, static fn(array $row): bool => $row['Field'] === 'value'))[0];
    capabilityLargeCheck(strtolower($valueColumn['Type']) === 'text', 'member capability tests retain the official TEXT field');
    $settings = new ConfigService(new Context($site, 1));
    $config = $settings->get(); $config['enabled'] = true; $config['fee_confirmed'] = true; $config['publishing_required'] = false;
    foreach ($config['businesses'] as &$business) {
        $business['options'] = $business['key'] === 'purchase' ? [] : [[
            'id' => $business['key'] . '_one', 'title' => $business['key'] . '能力一', 'brand' => '后台品牌',
            'category_name' => '后台分类', 'path' => ['后台分类', $business['key'] . '能力一'], 'aliases' => [],
        ]];
        if ($business['key'] === 'rent') $business['options'][] = [
            'id' => 'rent_two', 'title' => '租机能力二', 'brand' => '后台品牌', 'category_name' => '后台分类', 'path' => ['后台分类', '租机能力二'], 'aliases' => [],
        ];
    }
    unset($business); $settings->save($config);
    // General settings no longer own directory writes. Seed each independent
    // business through the same curated import service used by administrators.
    $catalog = new CatalogService(new Context($site, 1));
    foreach ($config['businesses'] as $business) if ($business['key'] !== 'purchase') {
        $catalog->save(['business_type' => $business['key'], 'format' => 'json',
            'content' => json_encode($business['options'], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
    }
    $rows = [];
    for ($index = 1; $index <= 5000; $index++) $rows[] = [
        'id' => (string) $index, 'title' => '可交付 iPhone ' . $index, 'brand' => '苹果', 'category_name' => '手机',
        'path' => ['手机', '苹果系列', '可交付 iPhone ' . $index], 'aliases' => ['交付型号' . $index],
    ];
    $encode = static fn($value): string => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);
    (new CatalogService(new Context($site, 1)))->save(['business_type' => 'purchase', 'format' => 'json', 'content' => $encode($rows)]);
    $base = ['name' => 'Capability fixture shop', 'contact_name' => 'Fixture owner', 'mobile' => '18800000101',
        'province_id' => 910000, 'city_id' => 910100, 'district_id' => 910101, 'address' => 'Synthetic fixture street'];
    $ctx = new Context($site, 0, 101); $profile = new PartnerService($ctx);
    $merchant = (int) $profile->saveProfile($base)['id'];
    $otherMerchant = (int) (new PartnerService(new Context($site, 0, 102)))->saveProfile(array_replace($base, ['name' => 'Other merchant', 'mobile' => '18800000102']))['id'];
    $foreignMerchant = (int) (new PartnerService(new Context($site + 1, 0, 103)))->saveProfile(array_replace($base, ['name' => 'Other site merchant', 'mobile' => '18800000103']))['id'];
    $key = 'HSX_LEAD_CAPABILITY_' . $merchant; $otherKey = 'HSX_LEAD_CAPABILITY_' . $otherMerchant; $foreignKey = 'HSX_LEAD_CAPABILITY_' . $foreignMerchant;
    $write = static function (int $tenant, string $configKey, array $value): void {
        Db::transaction(static function () use ($tenant, $configKey, $value): void {
            Db::name('site')->where('site_id', $tenant)->lock(true)->find(); Storage::write($tenant, $configKey, $value);
        });
    };
    $opaque = ['opaque_marker' => ['preserve' => 'original metadata', 'quantity' => 7], 'legacy_extra' => ['still' => 'present']];
    $write($site, $key, $opaque);
    $write($site, $otherKey, ['business_capabilities' => [], 'other_owner_canary' => str_repeat('X', 60000)]);
    $write($site + 1, $foreignKey, ['business_capabilities' => [], 'foreign_canary' => str_repeat('Y', 60000)]);
    $allConfig = static function () use ($pdo): array { return $pdo->query('SELECT * FROM `lt_sys_config` ORDER BY site_id,config_key,id')->fetchAll(PDO::FETCH_ASSOC); };
    $baseRecord = static function (int $tenant, string $configKey) use ($allConfig): array {
        $selected = array_values(array_filter($allConfig(), static fn(array $row): bool => (int) $row['site_id'] === $tenant && $row['config_key'] === $configKey));
        capabilityLargeCheck(count($selected) === 1, 'capability has exactly one canonical base row'); return $selected[0];
    };
    $partPrefix = 'HSX_LEAD_CFG_' . substr(hash('sha256', $key), 0, 32) . '_';
    $parts = static fn(): array => array_values(array_filter($allConfig(), static fn(array $row): bool => (int) $row['site_id'] === $site && str_starts_with($row['config_key'], $partPrefix)));
    $assertParts = static function () use ($baseRecord, $site, $key, $parts, $partPrefix): void {
        $raw = json_decode($baseRecord($site, $key)['value'], true, 512, JSON_THROW_ON_ERROR); $storedParts = $parts();
        if (($raw[Storage::MARKER] ?? '') !== Storage::MANIFEST_VERSION) { capabilityLargeCheck($storedParts === [], 'inline capability leaves no old fragment'); return; }
        $actual = array_column($storedParts, 'config_key'); $expected = [];
        for ($i = 0; $i < $raw['parts']; $i++) $expected[] = $partPrefix . $raw['generation'] . '_' . str_pad((string) $i, 4, '0', STR_PAD_LEFT);
        sort($actual); sort($expected); capabilityLargeCheck($actual === $expected, 'capability fragments contain exactly the currently published generation');
        foreach ($storedParts as $part) capabilityLargeCheck(strlen($part['value']) < 65535, 'capability fragment stays below the official TEXT byte limit');
    };
    $foreignBefore = array_values(array_filter($allConfig(), static fn(array $row): bool => (int) $row['site_id'] === $site + 1));
    $otherBefore = Storage::read($site, $otherKey);
    $finance = static function () use ($site): array {
        $out = [];
        foreach (['member', 'member_account_log', 'member_level'] as $table) $out[$table] = Db::name($table)->where('site_id', $site)->select()->toArray();
        $out['orders'] = Db::name('hsx_lead_coop_order')->where('site_id', $site)->select()->toArray();
        $out['rules'] = (new ConfigService(new Context($site, 1)))->get(); return $out;
    };
    $feeBefore = $finance(); $capabilities = new CapabilityService($ctx);
    $selected = static fn(int $count): array => ['business_capabilities' => [
        ['business_type' => 'purchase', 'option_ids' => array_map('strval', range(1, $count))],
        ['business_type' => 'rent', 'option_ids' => ['rent_one']],
    ]];
    $ormPdo = Db::connect()->getPdo();
    foreach (['STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION', 'NO_ENGINE_SUBSTITUTION'] as $mode) {
        $ormPdo->exec('SET SESSION sql_mode=' . $ormPdo->quote($mode)); $pdo->exec('SET SESSION sql_mode=' . $pdo->quote($mode));
        foreach ([845, 5000] as $count) {
            $capabilities->save($merchant, $selected($count));
            $saved = array_column($capabilities->businesses($merchant), null, 'business_type');
            capabilityLargeCheck($saved['purchase']['option_ids'] === array_map('strval', range(1, $count)) && count($saved['purchase']['items']) === $count, $mode . ' member saves and reads all ' . $count . ' selected models');
            capabilityLargeCheck(array_column($capabilities->models($merchant), 'id') === array_map('strval', range(1, $count)), 'manual model projection preserves the complete selected range');
            $stored = Storage::read($site, $key);
            capabilityLargeCheck(strlen($encode($stored)) > 65535 && $stored['opaque_marker'] === $opaque['opaque_marker'] && $stored['legacy_extra'] === $opaque['legacy_extra'], 'large capability snapshot exceeds TEXT and preserves opaque metadata');
            capabilityLargeCheck(!$ormPdo->inTransaction(), 'standalone capability save commits its own encompassing transaction');
            $assertParts();
        }
    }
    capabilityLargeCheck($finance() === $feeBefore, 'capability changes never alter member rank, balances, fees or payment orders');
    capabilityLargeCheck(Storage::read($site, $otherKey) === $otherBefore, 'capability changes do not touch another merchant');
    capabilityLargeCheck(array_values(array_filter($allConfig(), static fn(array $row): bool => (int) $row['site_id'] === $site + 1)) === $foreignBefore, 'capability changes never touch another site');
    capabilityLargeReject(fn() => $capabilities->save($otherMerchant, $selected(845)), 'member cannot overwrite another merchant capability');

    $beforeRepeat = count($parts()); $capabilities->save($merchant, $selected(5000));
    capabilityLargeCheck(count($parts()) === $beforeRepeat, 'repeating full selection does not accumulate old fragments'); $assertParts();
    $profileResult = $profile->saveProfile($base + $selected(5000));
    $profileBusiness = array_column($profileResult['business_capabilities'], null, 'business_type');
    capabilityLargeCheck(count($profileBusiness['purchase']['option_ids']) === 5000 && count($profileResult['manual_models']) === 5000, 'actual member profile save returns all selected capabilities and model projection');
    $snapshot = static function () use ($allConfig, $site): array {
        return ['configs' => $allConfig(), 'merchants' => Db::name('hsx_lead_merchant')->where('site_id', $site)->order('id')->select()->toArray(),
            'partners' => Db::name('hsx_lead_partner')->where('site_id', $site)->order('id')->select()->toArray(), 'audit' => Db::name('hsx_lead_audit')->where('site_id', $site)->order('id')->select()->toArray()];
    };
    $beforeProfileFailure = $snapshot();
    capabilityLargeReject(fn() => $profile->saveProfile(array_replace($base, ['name' => 'Must roll back', 'business_license_token' => 'invalid-token']) + $selected(4)), 'failure after capability save in profile transaction is reported');
    capabilityLargeCheck($snapshot() === $beforeProfileFailure && count($capabilities->models($merchant)) === 5000, 'later profile validation failure restores capability main row, old fragments and merchant fields');

    $beforeFailure = $snapshot();
    $pattern = '^' . $partPrefix . '[a-f0-9]{16}_0001$';
    $pdo->exec('CREATE TRIGGER `lt_capability_part_failure` BEFORE INSERT ON `lt_sys_config` FOR EACH ROW BEGIN IF NEW.site_id=' . $site . ' AND NEW.config_key REGEXP ' . $pdo->quote($pattern) . " THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Synthetic capability second-part failure'; END IF; END"); $trigger = true;
    capabilityLargeReject(fn() => $capabilities->save($merchant, $selected(845)), 'standalone member save reports a real second-fragment SQL failure');
    capabilityLargeCheck($snapshot() === $beforeFailure && count($capabilities->models($merchant)) === 5000 && !$ormPdo->inTransaction(), 'standalone save rollback preserves every prior fragment and closes its transaction');
    $pdo->exec('DROP TRIGGER `lt_capability_part_failure`'); $trigger = false;

    $firstPart = $parts()[0];
    Db::startTrans();
    try {
        Db::name('sys_config')->where('id', $firstPart['id'])->delete();
        capabilityLargeReject(fn() => $capabilities->businesses($merchant), 'missing member capability fragment is rejected rather than returning empty skills');
    } finally { Db::rollback(); }
    capabilityLargeCheck(count($capabilities->models($merchant)) === 5000, 'rolling back corruption fixture restores the complete capability');
    $config = $settings->get();
    foreach ($config['businesses'] as &$business) if ($business['key'] === 'rent') $business['enabled'] = false;
    unset($business); $settings->save($config);
    $disabledFees = $finance();
    $capabilities->save($merchant, $selected(5000));
    capabilityLargeCheck(array_column($capabilities->businesses($merchant), null, 'business_type')['rent']['option_ids'] === ['rent_one'], 'unchanged capability for a disabled business remains readable and saveable');
    $changed = $selected(5000); $changed['business_capabilities'][1]['option_ids'] = ['rent_two']; $beforeDisabled = $snapshot();
    capabilityLargeReject(fn() => $capabilities->save($merchant, $changed), 'disabled business cannot add or replace selected capability');
    capabilityLargeCheck($snapshot() === $beforeDisabled, 'disabled-business rejection leaves previous capabilities untouched');
    $clearedRent = $selected(5000); $clearedRent['business_capabilities'][1]['option_ids'] = [];
    $capabilities->save($merchant, $clearedRent);
    capabilityLargeCheck(array_column($capabilities->businesses($merchant), 'business_type') === ['purchase'] && count($capabilities->models($merchant)) === 5000, 'explicitly clearing disabled business preserves the other selected business');
    $capabilities->save($merchant, ['business_capabilities' => []]);
    $empty = Storage::read($site, $key);
    capabilityLargeCheck($capabilities->businesses($merchant) === [] && $empty['opaque_marker'] === $opaque['opaque_marker'] && $empty['legacy_extra'] === $opaque['legacy_extra'], 'clearing all selected businesses keeps unrelated opaque merchant settings');
    $assertParts();
    capabilityLargeCheck($finance() === $disabledFees && Storage::read($site, $otherKey) === $otherBefore, 'clear operation does not change membership, platform fee rules or another merchant');
    capabilityLargeCheck(array_values(array_filter($allConfig(), static fn(array $row): bool => (int) $row['site_id'] === $site + 1)) === $foreignBefore, 'all capability operations leave other-site config raw rows unchanged');
    capabilityLargeCheck(Db::query('SHOW COLUMNS FROM `lt_sys_config`') === $columnBefore, 'large capabilities require no schema change');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => 'real member 845/5000 capability saves; official TEXT; private random localhost schema; no remote requests', 'remote_calls' => 0], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true; fwrite(STDERR, 'FAIL large capability storage: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    if ($pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    if ($pdo instanceof PDO && $trigger) $pdo->exec('DROP TRIGGER IF EXISTS `lt_capability_part_failure`');
    if ($pdo instanceof PDO && $schema !== '') {
        try { leadCleanup($pdo, $schema); }
        catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL owned schema cleanup\n"); }
    }
}
exit($failed ? 1 : 0);
