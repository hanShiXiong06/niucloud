import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Execute the actual two Vue setup functions with delayed synthetic responses.
// There is no browser, live API, payment, or database access in this suite.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const clone=value=>JSON.parse(JSON.stringify(value))
function run(source,deps={}){
    const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext('(function(require,module,exports){'+js+'})',{Date,Number,String,Math,Set,Map,JSON,Promise,console})(key=>{
        if(key in deps)return deps[key]
        if(key.endsWith('.vue'))return{default:{}}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    return module.exports
}
function component(file,exports,deps){
    const source=fs.readFileSync(path.join(plugin,file),'utf8'),parsed=sfc.parse(source,{filename:file})
    check(!parsed.errors.length,file+' SFC parses')
    sfc.compileScript(parsed.descriptor,{id:'admin-consistency'})
    check(!sfc.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'admin-consistency'}).errors.length,file+' template compiles')
    for(const style of parsed.descriptor.styles)check(!sfc.compileStyle({source:style.content,filename:file,id:'admin-consistency',scoped:style.scoped}).errors.length,file+' style compiles')
    check(source===fs.readFileSync(path.resolve(plugin,'../../../admin/src/addon/hsx_lead',file.slice(6)),'utf8'),file+' canonical and mounted copies match')
    return run(parsed.descriptor.scriptSetup.content+'\nexport {'+exports+'}',deps)
}
const business=run(fs.readFileSync(path.join(plugin,'admin/composables/business.ts'),'utf8'))
const notices=[],writes=[],base={enabled:true,publishing_required:true,listing_login_required:false,fee_confirmed:true,commission_minimum:'50.00',fee_percent:'10.00',fee_minimum:'9.90',response_minutes:30,contact_hours:24,review_hours:48,inventory_fresh_hours:24,demand_model_limit:5,membership_levels:[],businesses:[{key:'rent',name:'租机',enabled:true,dimension:'model',selection_mode:'multiple',selection_limit:5,commission_minimum:'50.00',fields:[],options:[{id:'A',title:'原始型号'}],catalog_configured:true}]}
let saveWork=async payload=>({data:{...clone(base),response_minutes:payload.response_minutes,businesses:[{...clone(base.businesses[0]),options:[{id:'A',title:'原始型号'},{id:'B',title:'其他管理员刚新增型号'}]}]}})
const messages={success:v=>notices.push(['success',v]),warning:v=>notices.push(['warning',v]),error:v=>notices.push(['error',v])}
const common={'element-plus':{ElMessage:messages,ElMessageBox:{confirm:async()=>{},prompt:async()=>({value:'合成原因'})}},'../../composables/business':business}
const settings=component('admin/views/cooperation/Settings.vue','load,save,form,saving,error',{
    ...common,vue:{...Vue,onMounted(){},onBeforeUnmount(){}},'@element-plus/icons-vue':{Refresh:{}},'@/stores/modules/user':{default:()=>({rules:[]})},
    '../../composables/entity':{normalizeEntityLevels:value=>Array.isArray(value)?value:[]},'../../composables/navigation':{hasLeadPagePermission:()=>false},
    '../../composables/cooperation':{coopError:(error,fallback)=>error?.message||fallback,coopMoney:String},
    '../../api/cooperation':{getCooperationConfig:async()=>({data:clone(base)}),saveCooperationConfig:async payload=>{writes.push(clone(payload));return saveWork(payload)}}
})
await settings.load();settings.form.response_minutes=45;await settings.save()
check(writes.length===1&&writes[0].response_minutes===45,'ordinary business settings still submit')
check(!('options'in writes[0].businesses[0])&&!('catalog_configured'in writes[0].businesses[0]),'generic form never resubmits copied catalog options or ownership markers')
check(settings.form.businesses[0].options.length===2&&settings.form.businesses[0].options[1].id==='B','save displays the authoritative fresh catalog from readback')
check(writes[0].businesses[0].dimension==='model'&&writes[0].businesses[0].name==='租机','directory stripping retains editable business metadata')
let releaseSave;saveWork=()=>new Promise(resolve=>{releaseSave=resolve});const saving=settings.save();await settings.save()
check(settings.saving.value&&writes.length===2,'one pending settings submission blocks duplicate writes')
releaseSave({data:clone(base)});await saving

const unmount=[],reads=[],pending=new Map()
const orders=component('admin/views/cooperation/Orders.vue','openRelated,showDetail,invalidateDetail,selected,detailVisible',{
    ...common,vue:{...Vue,onMounted(){},onBeforeUnmount:callback=>unmount.push(callback)},
    '../../composables/cooperation':{coopLabel:String,coopMoney:String,coopTime:String,coopTone:String,coopError:(error,fallback)=>error?.message||fallback,useCooperationAccess:()=>({allows:()=>false}),useCooperationList:()=>({rows:Vue.ref([]),total:Vue.ref(0),loading:Vue.ref(false),error:Vue.ref(''),query:Vue.reactive({page:1,limit:20}),load:async()=>{},search:async()=>{},changePage(){}})},
    '../../api/cooperation':{getCooperationOrders:params=>{reads.push(clone(params));return new Promise((resolve,reject)=>pending.set(Number(params.id),{resolve,reject}))},closeCooperationOrder:async()=>{},repriceCooperationOrder:async()=>{},getOrderPricingLogs:async()=>{}}
})
const resolve=(id,row={id})=>pending.get(id).resolve({data:{data:[row]}})
orders.showDetail({id:1});const first=orders.openRelated(11),last=orders.openRelated(22);resolve(22);await last;resolve(11);await first
check(orders.selected.value.id===22,'earlier related-order response cannot replace latest selected order')
check(reads[0].id===11&&reads[1].id===22&&reads.every(row=>row.limit===1),'related order requests are exact scoped single-id reads')
const dismissed=orders.openRelated(33);orders.detailVisible.value=false;orders.invalidateDetail();resolve(33);await dismissed
check(!orders.detailVisible.value&&orders.selected.value.id===22,'closing detail cancels pending reads without reopening the dialog')
const old=orders.openRelated(44);orders.showDetail({id:55});resolve(44);await old
check(orders.selected.value.id===55,'directly opening another row invalidates an outstanding related-order request')
const staleFailure=orders.openRelated(66),newer=orders.openRelated(77);resolve(77);await newer;const beforeError=notices.length;pending.get(66).reject(Error('合成旧请求错误'));await staleFailure
check(notices.length===beforeError&&orders.selected.value.id===77,'a stale request error does not show an unrelated error over current order')
const mismatch=orders.openRelated(88);resolve(88,{id:888});await mismatch
check(orders.selected.value.id===77&&notices.at(-1)[1].includes('关联订单未读取'),'wrong-id response is rejected instead of opening another payment order')
const disposed=orders.openRelated(99);for(const callback of unmount)callback();resolve(99);await disposed
check(orders.selected.value.id===77,'unmounted order page ignores late async detail response')
console.log(`PASS ${checks} admin consistency checks; actual SFC setup and synthetic delayed APIs only, no HTTP, payment, or database writes.`)
