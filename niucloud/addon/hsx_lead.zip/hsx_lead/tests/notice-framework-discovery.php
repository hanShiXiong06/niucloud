<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\NoticeConfigService;
use app\dict\notice\NoticeDict;
use app\service\admin\weapp\WeappTemplateService;
use app\service\core\sys\CoreConfigService;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function discoveryCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function discoveryDeny(callable $call,string $label):void{try{$call();}catch(\core\exception\CommonException $e){discoveryCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    // The real site's add-on middleware primes this cache before channel APIs.
    \think\facade\Cache::set('local_install_addons_'.$site,['hsx_lead']);
    $before=(int)Db::name('sys_notice')->count();
    $dict=NoticeDict::getNotice();
    foreach(NoticeConfigService::PHASES as$key){
        discoveryCheck(in_array('weapp',$dict[$key]['support_type'],true),'pending scene is discoverable by real framework dictionary');
        discoveryCheck($dict[$key]['weapp']['configuration_required']===true&&$dict[$key]['weapp']['tid']==='','pending entry carries no invented public template');
    }
    $service=new WeappTemplateService();
    $groups=$service->getList();$found=[];
    foreach($groups as$group)foreach($group['notice']??[]as$row)if(in_array($row['key'],NoticeConfigService::PHASES,true))$found[$row['key']]=$row;
    discoveryCheck(count($found)===2,'actual framework list returns both scenes without an existing mapping or sys_notice row');
    discoveryCheck((int)Db::name('sys_notice')->count()===$before,'dictionary and list reads do not initialize notification records');
    discoveryCheck(NoticeConfigService::weappForSite($site)===[],'pending discovery cannot masquerade as a sendable mapping');
    foreach($found as$row)discoveryCheck(!(int)$row['is_weapp']&&$row['weapp_template_id']==='','new scene stays disabled with no private account template');
    $config=new CoreConfigService();$config->setConfig($site,NoticeConfigService::CONFIG_KEY,['templates'=>['assigned'=>['phase'=>'assigned','tid'=>'12345','kid_list'=>[1],'scene_desc'=>'Synthetic isolated scene','fields'=>[['label'=>'编号','variable'=>'task_no','keyword'=>'character_string1']]]]]);
    $definitions=NoticeConfigService::weappDefinitionsForSite($site);
    discoveryCheck($definitions['hsx_lead_task_assigned']['tid']==='12345'&&empty($definitions['hsx_lead_task_assigned']['configuration_required']),'configured site keeps its verified mapping and normal retrieval state');
    discoveryCheck($definitions['hsx_lead_task_changed']['configuration_required']===true,'one configured phase does not make the other phase ready');
    discoveryCheck(NoticeConfigService::weappForSite($site+1)===[],'another site never consumes a configured public mapping implicitly');
    discoveryCheck($definitions['hsx_lead_task_assigned']['content'][0]===['编号','{task_no}','character_string1'],'dictionary and sender consume one shared variable contract');
    $saved=Db::name('sys_config')->where('site_id',$site)->where('config_key',NoticeConfigService::CONFIG_KEY)->value('value');
    foreach([['character_string1','status_text'],['character_string1','notice_remark'],['phrase1','task_no'],['phrase1','notice_remark'],['number1','status_text'],['time1','task_no']]as[$keyword,$variable]){
        $row=['phase'=>'assigned','tid'=>'12345','kid_list'=>[1],'scene_desc'=>'Synthetic type validation','fields'=>[['label'=>'字段','keyword'=>$keyword,'variable'=>$variable]],'confirmed'=>true];
        discoveryDeny(fn()=>(new NoticeConfigService())->save($site,['templates'=>[$row]],1),'field type and variable semantics are checked during save: '.$keyword.'/'.$variable);
    }
    discoveryCheck(Db::name('sys_config')->where('site_id',$site)->where('config_key',NoticeConfigService::CONFIG_KEY)->value('value')===$saved,'invalid new mappings do not overwrite the previous valid configuration');
    $invalid=['phase'=>'assigned','tid'=>'12345','kid_list'=>[1],'scene_desc'=>'Synthetic invalid old map','fields'=>[['label'=>'状态','keyword'=>'character_string1','variable'=>'status_text']]];
    $config->setConfig($site,NoticeConfigService::CONFIG_KEY,['templates'=>['assigned'=>$invalid]]);
    discoveryCheck(NoticeConfigService::weappForSite($site)===[]&&NoticeConfigService::weappDefinitionsForSite($site)['hsx_lead_task_assigned']['configuration_required'],'an invalid old field mapping is neither sendable nor retrievable');
    $state=(new NoticeConfigService())->get($site);
    discoveryCheck(!$state['templates'][0]['configured']&&$state['templates'][0]['status']==='unconfigured','configuration readiness agrees with the actual sendable mapping');
    $numberVariable=array_values(array_filter($state['variables'],static fn($row)=>$row['key']==='task_no'))[0];
    discoveryCheck(in_array('character_string',$numberVariable['field_types'],true)&&!in_array('phrase',$numberVariable['field_types'],true),'UI metadata exposes the same field rules rather than an independent permissive contract');
    discoveryCheck($config->getConfigValue($site,NoticeConfigService::CONFIG_KEY)['templates']['assigned']===$invalid,'validating readiness does not delete or rewrite an existing mapping');
    $valid=['phase'=>'assigned','tid'=>'12345','kid_list'=>[1,2],'scene_desc'=>'Synthetic valid fields','fields'=>[['label'=>'编号','keyword'=>'character_string1','variable'=>'task_no'],['label'=>'状态','keyword'=>'phrase2','variable'=>'status_text']],'confirmed'=>true];
    $configured=(new NoticeConfigService())->save($site,['templates'=>[$valid]],1);
    discoveryCheck($configured['templates'][0]['configured']&&count(NoticeConfigService::weappForSite($site))===1,'real save accepts valid character/status mappings and returns consistent readiness');
    $zero=$valid;$zero['tid']='0';discoveryDeny(fn()=>(new NoticeConfigService())->save($site,['templates'=>[$zero]],1),'zero is not a real public template ID');
    \think\facade\Cache::set('local_install_addons_'.($site+1),[]);request()->siteId($site+1);
    $unassigned=(new WeappTemplateService())->getList();$leaked=false;
    foreach($unassigned as$group)foreach($group['notice']??[]as$row)if(in_array($row['key'],NoticeConfigService::PHASES,true))$leaked=true;
    discoveryCheck(!$leaked,'a site without the plugin still does not see its notification scenes');
    leadAssertIsolated($schema);echo 'PASS '.$checks." real framework discovery checks; owned random MySQL schema, no external calls or template changes.\n";
}catch(Throwable$e){$failed=true;fwrite(STDERR,get_class($e).': '.$e->getMessage().' @ '.$e->getFile().':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
