<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,PosterShareService,PromotionService,Store,TeamService};
use addon\hsx_lead\app\listener\poster\{LeadPosterData,LeadPosterType};
use app\service\core\poster\CorePosterService;
use app\service\core\sys\CoreConfigService;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function psCheck(bool $ok,string $name):void{if(!$ok)throw new RuntimeException($name);$GLOBALS['checks']++;}
function psDeny(callable $run,string $name):void{try{$run();}catch(CommonException $error){psCheck(true,$name);return;}throw new RuntimeException('Not denied: '.$name);}
function psIdentity(int $site,int $member=0,string $app='api',int $uid=0):void{
    $property=new ReflectionProperty(app\Request::class,'auth_info');$property->setAccessible(true);$property->setValue(null,['member_id'=>$member,'app_type'=>$app,'uid'=>$uid]);
    request()->siteId($site);request()->pushHeader([system_name('channel_name')=>'h5']);
}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$app->env->set('system.wap_domain','https://example.invalid');
    leadMembershipSeed($site);
    $admin=new Context($site,1);$owner=new Context($site,0,101);$employee=new Context($site,0,102);
    $config=ConfigService::defaults();$config['enabled']=true;(new ConfigService($admin))->save($config);
    (new CoreConfigService())->setConfig($site,PromotionService::CONFIG_KEY,['enabled'=>true]);
    $types=(new LeadPosterType())->handle(null);psCheck(array_column($types,'type')===array_values(PosterShareService::TYPES),'type hook accepts framework null dispatch');
    $templates=require dirname(__DIR__).'/app/dict/poster/template.php';$components=require dirname(__DIR__).'/app/dict/poster/components.php';$definitions=$components['hsx_lead_share']['list'];
    psCheck(count($templates)===2&&count($definitions)===7,'independent templates and framework editor data components');
    foreach($templates as$template){
        foreach($template['data']['value']as$item)if($item['relate']!=='')psCheck(isset($definitions[$item['componentName']])&&$definitions[$item['componentName']]['relate']===$item['relate'],'dynamic component name matches editor registry: '.$item['id']);
        psCheck($template['data']['global']['width']===750&&$template['data']['global']['height']===1100,'compact share aspect ratio');
        psCheck(is_file(dirname(__DIR__).'/resource/poster/share-background.png'),'plugin-owned background exists');
    }
    psCheck(count((new CorePosterService())->getTemplateList('hsx_lead','hsx_lead_entity'))===1,'real framework dictionary loader resolves default without a database seed');
    $event=require dirname(__DIR__).'/app/event.php';psCheck(in_array(LeadPosterData::class,$event['listen']['GetPosterData'],true)&&in_array(LeadPosterType::class,$event['listen']['GetPosterType'],true),'both real framework hooks registered');
    $listener=new LeadPosterData();psCheck($listener->handle(['type'=>'other'])===[]&&$listener->handle(null)===[],'unrelated poster types left untouched');
    psIdentity($site);psDeny(fn()=>PosterShareService::fromRequest($site),'anonymous generation rejected');
    psDeny(fn()=>$listener->handle(['type'=>'hsx_lead_promotion','site_id'=>$site,'channel'=>'h5','param'=>['member_id'=>101,'mode'=>'preview']]),'anonymous public poster endpoint cannot impersonate member or preview');
    psIdentity($site,101);$service=PosterShareService::fromRequest($site);$promotion=$service->data('promotion','h5');
    psCheck($promotion['hsx_lead_qrcode']['page']==='addon/hsx_lead/pages/profile/index','promotion resolves actual registered profile route');
    psCheck($promotion['hsx_lead_qrcode']['data']===[['key'=>'mid','value'=>'101'],['key'=>'pi','value'=>'1']],'promotion contains only current account and compact confirmation marker');
    $forged=$listener->handle(['type'=>'hsx_lead_promotion','site_id'=>$site,'channel'=>'h5','param'=>['member_id'=>102,'mid'=>102,'url'=>'https://attacker.invalid','mode'=>'preview']]);
    psCheck($forged['hsx_lead_qrcode']===$promotion['hsx_lead_qrcode']&&$forged['hsx_lead_identity']==='Fixture 101','forged identity, redirect and preview ignored under authenticated API');
    psDeny(fn()=>PosterShareService::fromRequest($site+1),'request tenant cannot be replaced by payload');
    psDeny(fn()=>(new PosterShareService(new Context($site,0,102)))->data('promotion','h5'),'context must match actual request identity');
    psDeny(fn()=>$listener->handle(['type'=>'hsx_lead_promotion','site_id'=>$site+1,'channel'=>'h5']),'generic poster event cannot cross site');
    psDeny(fn()=>$service->data('promotion','weapp'),'spoofed channel rejected before any external API');
    psDeny(fn()=>$service->data('promotion','pc'),'unsupported QR channel rejected');
    psDeny(fn()=>$service->data('anything','h5'),'unknown scene never falls back to another business');
    $profile=(new PartnerService($owner))->saveProfile(['name'=>'Synthetic storefront','contact_name'=>'Owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture road']);
    $entity=$service->data('entity','h5');$code=(new TeamService($owner))->summary()['subject_code'];
    psCheck($entity['hsx_lead_qrcode']['page']==='addon/hsx_lead/pages/entity/index','entity joins through its real entity page');
    psCheck($entity['hsx_lead_qrcode']['data']===[['key'=>'subject_code','value'=>$code]],'entity has only server-owned subject code, no promotion mid');
    psCheck(strlen('subject_code-'.$code)<=32,'entity QR obeys native scene limit');
    psCheck(!str_contains(json_encode($entity),'19900000101')&&!isset($entity['members']),'poster data excludes phone, member list and internal business');
    $forged=$listener->handle(['type'=>'hsx_lead_entity','site_id'=>$site,'channel'=>'h5','param'=>['merchant_id'=>999,'subject_code'=>'AAAAAAAAAA','member_id'=>102]]);
    psCheck($forged['hsx_lead_qrcode']===$entity['hsx_lead_qrcode'],'entity ignores forged merchant, owner and code');
    psCheck(Db::name('hsx_lead_merchant_member')->where('site_id',$site)->count()===0,'generating invite never creates a join or auto-approves');
    psIdentity($site,102);psDeny(fn()=>PosterShareService::fromRequest($site)->data('entity','h5'),'ordinary member cannot generate another store invitation');
    leadSetEntryDefinition($site,702);$partner=Store::partner($site,(int)$profile['id']);leadMembershipGrant($site,101,'ML702');
    (new TeamService($employee))->join(['subject_code'=>$code]);psIdentity($site,101);(new TeamService($owner))->review(102,true);
    psIdentity($site,102);psDeny(fn()=>PosterShareService::fromRequest($site)->data('entity','h5'),'approved employee still cannot generate responsible owner invite');
    psIdentity($site,101);Db::name('hsx_lead_partner')->where('id',$partner['id'])->update(['blocked_at'=>time()]);
    psDeny(fn()=>PosterShareService::fromRequest($site)->data('entity','h5'),'paused store cannot generate new member invitations');
    Db::name('hsx_lead_partner')->where('id',$partner['id'])->update(['blocked_at'=>0]);
    (new CoreConfigService())->setConfig($site,PromotionService::CONFIG_KEY,['enabled'=>false]);
    psDeny(fn()=>PosterShareService::fromRequest($site)->data('promotion','h5'),'disabled promotion blocks generation before cached image return');
    (new CoreConfigService())->setConfig($site,PromotionService::CONFIG_KEY,['enabled'=>true]);
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['status'=>0]);
    psDeny(fn()=>PosterShareService::fromRequest($site)->data('promotion','h5'),'disabled actual member cannot use token-stale poster');
    Db::name('member')->where('site_id',$site)->where('member_id',101)->update(['status'=>1]);
    psIdentity($site,0,'site',1);$preview=$listener->handle(['type'=>'hsx_lead_entity','site_id'=>$site,'channel'=>'h5','param'=>['mode'=>'preview','member_id'=>101,'subject_code'=>$code]]);
    psCheck($preview['hsx_lead_qrcode']===['url'=>'https://example.invalid','page'=>'','data'=>[]],'authorized editor preview uses only synthetic non-binding QR');
    psCheck(!str_contains(json_encode($preview),$code),'editor preview does not expose private live subject code');
    psDeny(fn()=>$listener->handle(['type'=>'hsx_lead_entity','site_id'=>$site,'channel'=>'weapp','param'=>['mode'=>'preview']]),'editor cannot turn sample preview into a real WeChat API request');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'actual plugin services/hooks in random owned localhost schema; no existing data, external API, real QR or financial actions'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.$error->getFile().':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
