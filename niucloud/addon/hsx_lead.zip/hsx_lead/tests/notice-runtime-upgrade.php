<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql; writes only its own random localhost schema.\n");
require __DIR__ . '/bootstrap.php';
define('HSX_LEAD_NOTICE_RUNTIME_LIBRARY_ONLY', true);
require dirname(__DIR__) . '/scripts/upgrade-notice-runtime.php';
use addon\hsx_lead\scripts\NoticeRuntimeUpgrade;
use think\facade\Db;
$checks = 0; $pdo = null; $schema = ''; $fixture = '';
function noticeSchemaAssert(bool $ok, string $label): void { global $checks; if (!$ok) throw new RuntimeException($label); $checks++; echo '[PASS] ' . $label . PHP_EOL; }
function noticeSchemaDeny(callable $action, string $label): void { try { $action(); } catch (Throwable $error) { noticeSchemaAssert(true, $label); return; } throw new RuntimeException('Not rejected: ' . $label); }
function noticeSchemaTables(): array { return array_column(Db::query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME'), 'TABLE_NAME'); }
function noticeProtectedRows(): array { $rows = []; foreach (['member'=>'member_id','member_account_log'=>'id','hsx_lead_coop_order'=>'id','sys_config'=>'id','sys_notice'=>'id','sys_role'=>'role_id','sys_schedule'=>'id'] as $table=>$pk) $rows[$table]=Db::name($table)->order($pk)->select()->toArray(); return $rows; }
function noticeUniqueDeny(callable $action, string $label): void { try { $action(); } catch (Throwable $error) { noticeSchemaAssert(str_contains($error->getMessage(), '1062'), $label); return; } throw new RuntimeException('Duplicate accepted: ' . $label); }
try {
    [$app,$pdo,$schema,$site] = leadBoot(); leadAssertIsolated($schema);
    $fixture = rtrim((string)realpath(sys_get_temp_dir()), '/') . '/' . $schema . '/notice-upgrade'; mkdir($fixture,0700,true);
    $command = new NoticeRuntimeUpgrade($fixture);
    noticeSchemaAssert($command->check()['pending_statements'] === 0, 'fresh install three-table schema matches the strict canonical definitions');
    Db::name('member_account_log')->insert(['site_id'=>$site,'member_id'=>101,'account_type'=>'money','account_data'=>'99.00','account_sum'=>'199.00','from_type'=>'fixture-protected','memo'=>'MONEY_MUST_STAY']);
    Db::name('hsx_lead_coop_order')->insert(['site_id'=>$site,'order_no'=>'NOTICE_TEST_PAID','purpose'=>'membership','merchant_id'=>1,'member_id'=>101,'business_key'=>'protected-notice-order','request_id'=>'protected-request','amount'=>'99.00','status'=>'paid','rule_json'=>'{"private_fixture":"DO_NOT_EXPORT_FINANCIAL_ROWS"}']);
    Db::name('sys_config')->insert(['site_id'=>$site,'config_key'=>'PRIVATE_FIXTURE_CREDENTIAL','value'=>'DO_NOT_EXPORT_CREDENTIAL']);
    $protected = noticeProtectedRows();
    foreach (['task','attempt','preference'] as $table) Db::execute('DROP TABLE `lt_hsx_lead_notice_' . $table . '`');
    $beforeTables = noticeSchemaTables(); $beforeCache = glob(dirname($fixture) . '/cache/*');
    $report = $command->check();
    noticeSchemaAssert($report['pending_statements'] === 3 && $report['business_row_writes'] === false && $report['backfill_messages'] === false, 'read-only check plans exactly three missing tables without replaying historical notices');
    noticeSchemaAssert(!is_dir($fixture.'/runtime') && noticeSchemaTables() === $beforeTables && noticeProtectedRows() === $protected && glob(dirname($fixture).'/cache/*') === $beforeCache, '--check writes no file/cache/schema/business rows');
    Db::startTrans(); try { noticeSchemaDeny(fn()=>$command->apply(),'DDL is refused inside an existing business transaction'); } finally { Db::rollback(); }
    noticeSchemaAssert($command->check()['pending_statements'] === 3 && !is_dir($fixture.'/runtime'), 'transaction refusal happens before backup or table creation');
    $key='hsx_lead_notice:'.substr(hash('sha256',$schema.':lt_'),0,40);
    $pdo->query("SELECT GET_LOCK(".$pdo->quote($key).",0)");
    try { noticeSchemaDeny(fn()=>$command->apply(),'advisory lock prevents another upgrader for this database and prefix'); }
    finally { $pdo->query("SELECT RELEASE_LOCK(".$pdo->quote($key).")"); }
    noticeSchemaAssert($command->check()['pending_statements'] === 3, 'a refused concurrent run leaves all three tables absent');
    $result = $command->apply();
    noticeSchemaAssert($result['applied'] && count($result['created_tables']) === 3 && $result['pending_statements'] === 0, 'explicit apply creates only the three canonical notification tables and reads them back');
    $added=array_values(array_diff(noticeSchemaTables(),$beforeTables));sort($added);
    noticeSchemaAssert($added===['lt_hsx_lead_notice_attempt','lt_hsx_lead_notice_preference','lt_hsx_lead_notice_task'],'only the three approved table names were added');
    noticeSchemaAssert(count(array_diff(noticeSchemaTables(),$beforeTables))===3 && noticeProtectedRows()===$protected,'DDL changes no payment order, account log, member, role, notice template, schedule or config');
    foreach (['task','attempt','preference'] as $table) noticeSchemaAssert(Db::name('hsx_lead_notice_'.$table)->count()===0,'new '.$table.' table is empty; no historical message backfill');
    noticeSchemaAssert((fileperms(dirname($result['backup']))&0777)===0700 && (fileperms($result['backup'])&0777)===0600,'DDL metadata backup is private 0700/0600');
    $backup=file_get_contents($result['backup']);$decoded=json_decode($backup,true,512,JSON_THROW_ON_ERROR);
    noticeSchemaAssert(isset($decoded['existing_schema'],$decoded['sql_sha256'])&&!str_contains($backup,'DO_NOT_EXPORT_')&&!str_contains($backup,'MONEY_MUST_STAY')&&!str_contains($backup,'password')&&!str_contains($backup,'username'),'backup contains only structural metadata, not credentials or business data');
    $snapshots=glob($fixture.'/runtime/hsx_lead_upgrade/notice-runtime-*');
    $repeat=$command->apply();
    noticeSchemaAssert($repeat['applied']===false && $repeat['created_tables']===[] && glob($fixture.'/runtime/hsx_lead_upgrade/notice-runtime-*')===$snapshots,'second apply is idempotent with no duplicate DDL or backup');
    $task=['site_id'=>$site,'event_key'=>'fixture.event','source_type'=>'order','source_id'=>1,'recipient_member_id'=>101,'channel'=>'weapp','dedupe_key'=>str_repeat('a',64)];
    $taskId=(int)Db::name('hsx_lead_notice_task')->insertGetId($task);
    noticeUniqueDeny(fn()=>Db::name('hsx_lead_notice_task')->insert($task),'task dedupe is enforced by uk_site_dedupe');
    Db::name('hsx_lead_notice_task')->insert(array_replace($task,['site_id'=>$site+1]));
    noticeSchemaAssert(Db::name('hsx_lead_notice_task')->count()===2,'task dedupe is tenant scoped, not cross-site');
    $attempt=['site_id'=>$site,'task_id'=>$taskId,'attempt_no'=>1,'trigger_type'=>'automatic','status'=>'sending','request_key'=>'fixture-request'];
    Db::name('hsx_lead_notice_attempt')->insert($attempt);
    noticeUniqueDeny(fn()=>Db::name('hsx_lead_notice_attempt')->insert(array_replace($attempt,['request_key'=>'another'])),'attempt number cannot be emitted twice for the same task');
    noticeUniqueDeny(fn()=>Db::name('hsx_lead_notice_attempt')->insert(array_replace($attempt,['attempt_no'=>2])),'a manual request key cannot schedule duplicate retries');
    Db::name('hsx_lead_notice_attempt')->insert(array_replace($attempt,['attempt_no'=>2,'request_key'=>null]));
    Db::name('hsx_lead_notice_attempt')->insert(array_replace($attempt,['attempt_no'=>3,'request_key'=>null]));
    noticeSchemaAssert(Db::name('hsx_lead_notice_attempt')->count()===3,'separate attempts without a manual request key remain valid');
    $preference=['site_id'=>$site,'member_id'=>101,'event_key'=>'fixture.event','channel'=>'weapp'];
    Db::name('hsx_lead_notice_preference')->insert($preference);
    noticeUniqueDeny(fn()=>Db::name('hsx_lead_notice_preference')->insert($preference),'member event/channel preference has a unique persisted identity');
    noticeSchemaAssert($command->apply()['applied']===false && Db::name('hsx_lead_notice_task')->count()===2 && Db::name('hsx_lead_notice_attempt')->count()===3,'idempotent updater preserves existing notification rows');
    Db::execute('ALTER TABLE `lt_hsx_lead_notice_task` DROP INDEX `uk_site_dedupe`');
    $beforeBadTables=noticeSchemaTables();$badBackupCount=count(glob($fixture.'/runtime/hsx_lead_upgrade/notice-runtime-*'));
    noticeSchemaDeny(fn()=>$command->check(),'missing expected unique index is rejected instead of silently reported as valid');
    noticeSchemaDeny(fn()=>$command->apply(),'apply refuses an anomalous same-name table rather than altering its indexes');
    noticeSchemaAssert(count(glob($fixture.'/runtime/hsx_lead_upgrade/notice-runtime-*'))===$badBackupCount && noticeSchemaTables()===$beforeBadTables && noticeProtectedRows()===$protected,'bad existing table stops before backup/DDL or financial data changes');
    Db::execute('ALTER TABLE `lt_hsx_lead_notice_task` ADD UNIQUE KEY `uk_site_dedupe` (`site_id`,`dedupe_key`)');
    Db::execute('ALTER TABLE `lt_hsx_lead_notice_task` DROP INDEX `uk_site_dedupe`, ADD UNIQUE KEY `uk_site_dedupe` (`site_id`,`dedupe_key`,`recipient_member_id`)');
    noticeSchemaDeny(fn()=>$command->apply(),'same unique-index name with a weakened dedupe definition is rejected without rebuilding');
    Db::execute('ALTER TABLE `lt_hsx_lead_notice_task` DROP INDEX `uk_site_dedupe`, ADD UNIQUE KEY `uk_site_dedupe` (`site_id`,`dedupe_key`)');
    Db::execute('ALTER TABLE `lt_hsx_lead_notice_preference` MODIFY COLUMN `enabled` int unsigned NOT NULL DEFAULT 1');
    noticeSchemaDeny(fn()=>$command->check(),'incorrect field type in an existing table is rejected without field migration');
    Db::execute('ALTER TABLE `lt_hsx_lead_notice_preference` MODIFY COLUMN `enabled` tinyint unsigned NOT NULL DEFAULT 1');
    Db::execute('DROP TABLE `lt_hsx_lead_notice_attempt`');
    Db::execute('CREATE TABLE `lt_hsx_lead_notice_attempt` (`id` bigint unsigned NOT NULL PRIMARY KEY) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4');
    Db::execute('DROP TABLE `lt_hsx_lead_notice_task`');
    noticeSchemaDeny(fn()=>$command->apply(),'incomplete same-name table is refused, not replaced or filled');
    noticeSchemaAssert(!in_array('lt_hsx_lead_notice_task',noticeSchemaTables(),true),'an anomalous existing table blocks all pending CREATE statements, not just itself');
    noticeSchemaAssert(noticeProtectedRows()===$protected,'all protected financial and business records remain byte-for-byte unchanged after every failure path');
    echo 'PASS '.$checks." notice schema upgrade checks; only an owned random localhost schema was written.\n";
} catch (Throwable $error) { fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL); $failed=true; }
finally {
    if ($fixture!=='' && $schema!=='' && str_starts_with($fixture,rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema.'/') && is_dir($fixture)) {
        foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($fixture,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST) as $entry) { if($entry->isFile()||$entry->isLink())unlink($entry->getPathname());else rmdir($entry->getPathname()); }rmdir($fixture);
    }
    if ($pdo instanceof PDO && $schema!=='') leadCleanup($pdo,$schema);
}
exit(!empty($failed)?1:0);
