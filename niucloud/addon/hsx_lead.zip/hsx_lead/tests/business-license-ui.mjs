import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.join(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),sass=require('sass')
const file=path.join(plugin,'uni-app/components/cooperation/CoopBusinessLicenseUpload.vue'),source=fs.readFileSync(file,'utf8'),parsed=compiler.parse(source,{filename:file}),descriptor=parsed.descriptor
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
check(!parsed.errors.length,'private license component parses')
check(!compiler.compileTemplate({source:descriptor.template.content,filename:file,id:'license-ui'}).errors.length,'private license template compiles')
const css=sass.compileString(descriptor.styles[0].content).css
check(/\.coop-license-upload__more\s*\{[^}]*width:\s*44px[^}]*height:\s*44px/.test(css),'low-frequency controls preserve a 44px touch target')
check(descriptor.template.content.includes('仅本人和平台可查看')&&descriptor.template.content.includes('v-if="uploading"'),'private document and upload status are explicit, not a public storefront')
check(!/setStorageSync|saveImageToPhotosAlbum|downloadFile/.test(source),'private image bytes do not enter form drafts, album or public downloads')
const png='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAAB',a='a'.repeat(64),b='b'.repeat(64)
function platformSource(source,mp){let keep=true;const stack=[];return source.split('\n').filter(line=>{if(line.includes('// #ifdef MP-WEIXIN')){stack.push(keep);keep=keep&&mp;return false}if(line.includes('// #ifndef MP-WEIXIN')){stack.push(keep);keep=keep&&!mp;return false}if(line.includes('// #endif')){keep=stack.pop();return false}return keep}).join('\n')}
function setup(mp,initial=a){
    const events=[],cleanups=[],writes=[],unlinks=[],previews=[],runtime={env:{USER_DATA_PATH:'/private-test-cache'}},files={writeFileSync:(...args)=>writes.push(args),unlinkSync:file=>unlinks.push(file)}
    let previewWork=async()=>({data:{has_image:true,data_url:png}}),uploadWork=async()=>({data:{token:b}}),uploads=0,reads=0,actionSheet,modal,chosen=0
    const module={exports:{}},script=compiler.compileScript(descriptor,{id:'license-ui'}),js=ts.transpileModule(platformSource(script.content,mp),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{Date,Math,String,Number,Promise,wx:mp?runtime:undefined,uni:{getFileSystemManager:()=>files,previewImage:value=>previews.push(value),showActionSheet:value=>{actionSheet=value},showModal:value=>{modal=value}}})(key=>{
        if(key==='vue')return{...Vue,onBeforeUnmount:fn=>cleanups.push(fn)}
        if(key==='../../api/cooperation')return{coopError:(cause,fallback)=>cause?.message||fallback,previewCooperationBusinessLicense:async token=>{reads++;return previewWork(token)},uploadCooperationBusinessLicense:async file=>{uploads++;return uploadWork(file)}}
        throw Error(key)
    },module,module.exports)
    const props=Vue.reactive({modelValue:initial,disabled:false}),state=module.exports.default.setup(props,{emit:(...value)=>events.push(value),expose(){}})
    state.uploader.value={chooseFile:()=>chosen++}
    return{props,state,events,writes,unlinks,previews,cleanups,get reads(){return reads},get uploads(){return uploads},get actionSheet(){return actionSheet},get modal(){return modal},get chosen(){return chosen},setPreview:work=>{previewWork=work},setUpload:work=>{uploadWork=work}}
}
async function flush(){for(let i=0;i<12;i++){await Promise.resolve();await Vue.nextTick()}}
const h5=setup(false);await flush()
check(h5.state.previewSource.value===png&&h5.writes.length===0,'H5 keeps the protected data URL only in component memory')
h5.state.preview();check(h5.previews.at(-1).current===png&&!h5.events.length,'image click only previews; it does not modify the owner profile')
h5.state.openActions();check(h5.actionSheet.itemList.join('|')==='更换营业执照|移除营业执照','replace/remove live in a native secondary-action sheet')
h5.actionSheet.success({tapIndex:0});check(h5.chosen===1&&!h5.events.length,'replace uses the installed uploader without clearing original evidence')
h5.state.openActions();h5.actionSheet.success({tapIndex:1});check(!!h5.modal&&!h5.events.length,'remove requires a second explicit confirmation')
h5.modal.success({confirm:false});check(!h5.events.length,'cancelled removal leaves the reference unchanged')
h5.modal.success({confirm:true});check(h5.events.at(-1)?.[0]==='update:modelValue'&&h5.events.at(-1)?.[1]==='','only confirmed removal emits an empty reference')
h5.events.length=0;let resolveUpload;h5.setUpload(()=>new Promise(resolve=>{resolveUpload=resolve}));const work=h5.state.afterRead({file:{url:'private-local.png',size:20}})
check(h5.state.uploading.value&&h5.events.at(-1)?.[0]==='pending'&&h5.events.at(-1)?.[1]===true,'parent save is locked during private upload')
await h5.state.afterRead({file:{url:'duplicate.png',size:20}});check(h5.uploads===1,'rapid repeated taps never duplicate an upload')
const beforePreview=h5.previews.length;h5.state.preview();check(h5.previews.length===beforePreview,'upload busy state blocks preview/menu interaction')
resolveUpload({data:{token:b}});await work;check(h5.events.at(-2)?.[1]===b&&h5.events.at(-1)?.[1]===false&&!h5.state.uploading.value,'successful upload emits only server opaque reference and releases pending')
h5.events.length=0;h5.setUpload(async()=>{throw Error('合成上传失败')});await h5.state.afterRead({file:{url:'fail.png',size:20}})
check(h5.state.error.value==='合成上传失败'&&!h5.events.some(event=>event[0]==='update:modelValue')&&h5.state.previewSource.value===png,'failed replacement keeps original picture and reference')
h5.events.length=0;h5.setUpload(async()=>({data:{path:'public/image.png'}}));await h5.state.afterRead({file:{url:'wrong.png',size:20}})
check(h5.state.error.value.includes('有效证照凭据')&&!h5.events.some(event=>event[0]==='update:modelValue'),'public URL/path is not accepted in place of a private token')
const calls=h5.uploads;await h5.state.afterRead({file:{url:'large.png',size:5242881}});check(h5.uploads===calls&&h5.state.error.value.includes('5MB'),'oversize is rejected before a network request')
const mp=setup(true);await flush()
check(mp.writes.length===1&&mp.writes[0][2]==='base64'&&mp.state.previewSource.value.startsWith('/private-test-cache/hsx-lead-license-'),'mini program writes authenticated bytes to its own private app cache')
mp.state.preview();check(mp.previews.at(-1).current===mp.writes[0][0]&&!mp.previews.at(-1).current.startsWith('data:'),'mini program native preview receives a local file, never a base64 URL')
const oldFile=mp.writes[0][0];mp.props.modelValue=b;await flush();check(mp.unlinks.includes(oldFile)&&mp.writes.length===2,'switching token removes only the previous temporary file')
const latest=mp.writes[1][0];mp.cleanups.forEach(fn=>fn());check(mp.unlinks.includes(latest)&&mp.state.previewSource.value==='','unmount removes the current private image cache')
const late=setup(true,'');let resolveRead;late.setPreview(()=>new Promise(resolve=>{resolveRead=resolve}));late.props.modelValue=a;await flush();late.cleanups.forEach(fn=>fn());resolveRead({data:{has_image:true,data_url:png}});await flush()
check(!late.writes.length&&!late.state.previewSource.value,'late preview response after leaving the page cannot recreate a private file')
const wrong=setup(false,'');wrong.setPreview(async()=>({data:{has_image:true,data_url:'https://public.invalid/license.png'}}));wrong.props.modelValue=a;await flush()
check(!wrong.state.previewSource.value&&wrong.state.error.value.includes('预览格式'),'preview rejects an unexpected external image source')
const profile=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopProfilePanel.vue'),'utf8')
check(profile.includes('v-if="editing || visible || onboarding" v-model="form.business_license_token"'),'license preview component is mounted only inside an open profile task')
check(profile.includes('props.busy || uploading.value || licenseUploading.value'),'both picture uploads share the parent save lock')
check(profile.includes("'business_license_token'].map")&&!profile.includes('business_license_data_url'),'profile submits opaque reference only')
h5.cleanups.forEach(fn=>fn());wrong.cleanups.forEach(fn=>fn())
console.log(`PASS ${checks} private business-license mobile checks; actual Vue/SFC, H5 and MP conditional branches with synthetic filesystem/API only; no upload or real device.`)
