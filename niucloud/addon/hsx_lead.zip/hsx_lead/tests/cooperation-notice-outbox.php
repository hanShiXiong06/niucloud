<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\cooperation\{CooperationNoticeOutbox,Store};
use addon\hsx_lead\app\service\{FrameworkNoticeGateway,NoticeConfigService};
use addon\hsx_lead\app\listener\notice\CooperationNoticeData;
use addon\hsx_lead\app\support\Data;
use app\service\core\sys\CoreConfigService;
use think\facade\{Cache,Db,Event};
$pdo=null;$schema='';$failed=false;$checks=0;
function outboxCheck(bool $value,string $name):void{if(!$value)throw new RuntimeException($name);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $publisher=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'name'=>'Outbox publisher','member_id'=>101,'status'=>1]);
    $receiver=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'name'=>'Outbox receiver','member_id'=>102,'status'=>1]);
    $lead=(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'OUTBOX_LOCAL','publisher_id'=>$publisher,'receiver_id'=>$receiver,'request_id'=>'outbox_local_fixture','models_json'=>'[]','status'=>'assigned','assignment_version'=>1]);
    try{Db::transaction(function()use($site,$lead):void{CooperationNoticeOutbox::record($site,$lead,'assigned');throw new RuntimeException('rollback fixture');});}catch(RuntimeException$ignored){}
    outboxCheck(Data::query('audit',$site)->where('entity_type',CooperationNoticeOutbox::TYPE)->count()===0,'rolled back business cannot leak a committed notice event');
    $id=CooperationNoticeOutbox::record($site,$lead,'assigned');outboxCheck($id>0,'business intent persists without a running queue');
    outboxCheck(CooperationNoticeOutbox::record($site,$lead,'assigned')===$id,'replayed business event reuses one intent');
    outboxCheck(Data::query('audit',$site)->where('entity_type','collaboration_notice')->count()===0,'recording the intent does not send or claim a channel');
    $called=0;$sender=static function(array$event)use(&$called):bool{$called++;return true;};
    outboxCheck(CooperationNoticeOutbox::process($site,$id,$sender),'worker consumes the persisted event');
    outboxCheck($called===0,'disabled framework channels never invoke the sender');
    outboxCheck(Data::query('audit',$site)->where('entity_type','collaboration_notice')->count()===6,'both stores retain their three precise disabled-channel results');
    outboxCheck(!CooperationNoticeOutbox::process($site,$id,$sender),'duplicate job is idempotent');
    outboxCheck(Data::query('audit',$site)->where('entity_type','collaboration_notice')->count()===6,'job replay cannot create duplicate channel claims');
    Store::query('collaboration',$site)->where('id',$lead)->update(['status'=>'following']);
    $obsolete=CooperationNoticeOutbox::record($site,$lead,'accepted');
    Store::query('collaboration',$site)->where('id',$lead)->update(['status'=>'no_deal']);
    outboxCheck(!CooperationNoticeOutbox::process($site,$obsolete,$sender),'stale event does not send a later state with the old action');
    outboxCheck(Data::row('audit',$site,$obsolete)['action']==='notice_obsolete','obsolete event is visible and terminal, not an infinite retry');
    $recovery=CooperationNoticeOutbox::record($site,$lead,'no_deal');
    Data::query('audit',$site)->where('id',$recovery)->update(['update_time'=>time()-181]);
    $result=CooperationNoticeOutbox::recover(20,10,$sender);
    outboxCheck($result['processed']===1&&Data::row('audit',$site,$recovery)['action']==='notice_processed','scheduled recovery consumes a persisted event when queue delivery was absent');
    outboxCheck(CooperationNoticeOutbox::recover(20,10,$sender)['processed']===0,'scheduled recovery does not resend a processed notification');
    $state=Data::decode(Data::row('audit',$site,$recovery)['detail_json']);
    outboxCheck($state['attempts']===1&&$state['status']==='processed','attempt count and terminal processing status are persisted');
    outboxCheck(!str_contains(Data::json($state),'member_id')&&!str_contains(Data::json($state),'mobile'),'outbox carries routing facts, not personal contact details');

    $newLead=static function(string$status='assigned')use($site,$publisher,$receiver):int{$suffix=bin2hex(random_bytes(6));return(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'OUTBOX_'.$suffix,'publisher_id'=>$publisher,'receiver_id'=>$receiver,'request_id'=>'OUTBOX_'.$suffix,'models_json'=>'[]','status'=>$status,'assignment_version'=>1]);};
    $nestedLead=$newLead();$intent=0;
    Db::transaction(function()use($site,$nestedLead,&$intent):void{
        CooperationNoticeOutbox::enqueue(['site_id'=>$site,'lead_id'=>$nestedLead,'action'=>'assigned']);
        $intent=(int)Data::query('audit',$site)->where('entity_type',CooperationNoticeOutbox::TYPE)->where('entity_id',$nestedLead)->value('id');
        outboxCheck($intent>0&&Data::query('audit',$site)->where('entity_type','collaboration_notice')->where('entity_id',$nestedLead)->count()===0,'enqueue inside framework outer transaction records intent but never invokes synchronous channel sender');
        outboxCheck(!CooperationNoticeOutbox::process($site,$intent),'direct worker invocation inside an outer business transaction is also blocked');
    });
    outboxCheck(Data::row('audit',$site,$intent)['action']==='notice_pending','outer commit leaves one durable intent for post-commit delivery');
    Data::query('audit',$site)->where('id',$intent)->update(['update_time'=>time()-181]);
    outboxCheck(CooperationNoticeOutbox::recover(20,10,$sender)['processed']===1,'scheduled recovery dispatches committed intent after queue enqueue was deliberately deferred');
    $queueOffLead=$newLead();CooperationNoticeOutbox::enqueue(['site_id'=>$site,'lead_id'=>$queueOffLead,'action'=>'assigned']);
    $queueOffIntent=(int)Data::query('audit',$site)->where('entity_type',CooperationNoticeOutbox::TYPE)->where('entity_id',$queueOffLead)->value('id');
    outboxCheck($queueOffIntent>0&&Data::query('audit',$site)->where('entity_type','collaboration_notice')->where('entity_id',$queueOffLead)->count()===0,'queue disabled outside transaction also returns without channel claims or external work in user request');
    outboxCheck(CooperationNoticeOutbox::recover(20,10,$sender)['processed']===1,'fresh pending intent is processed on the next scheduled round without a 180-second pending delay');
    $leasedLead=$newLead();$leasedId=CooperationNoticeOutbox::record($site,$leasedLead,'assigned');$leasedRow=Data::row('audit',$site,$leasedId);$leasedState=Data::decode($leasedRow['detail_json']);$leasedState['status']='processing';$leasedState['attempts']=1;
    Data::query('audit',$site)->where('id',$leasedId)->update(['detail_json'=>Data::json($leasedState),'update_time'=>time()]);
    outboxCheck(CooperationNoticeOutbox::recover(20,10,$sender)['examined']===0,'fresh processing worker retains its full 180-second lease');
    Data::query('audit',$site)->where('id',$leasedId)->update(['update_time'=>time()-181]);
    outboxCheck(CooperationNoticeOutbox::recover(20,10,$sender)['processed']===1,'only expired processing lease may be recovered');
    $rollbackLead=$newLead();
    try{Db::transaction(function()use($site,$rollbackLead):void{CooperationNoticeOutbox::enqueue(['site_id'=>$site,'lead_id'=>$rollbackLead,'action'=>'assigned']);outboxCheck(Data::query('audit',$site)->where('entity_type','collaboration_notice')->where('entity_id',$rollbackLead)->count()===0,'rollback path never reaches channel claims before outer commit');throw new RuntimeException('Expected outer rollback');});}catch(RuntimeException$ignored){}
    outboxCheck(Data::query('audit',$site)->where('entity_id',$rollbackLead)->where('entity_type',CooperationNoticeOutbox::TYPE)->count()===0,'outer rollback removes enqueue intent without a notification leak');
    $other=(int)Data::query('audit',$site)->insertGetId(['site_id'=>$site,'entity_type'=>'unrelated_test_event','entity_id'=>0,'action'=>'notice_pending','create_time'=>time()-500,'update_time'=>time()-500]);
    $fairLead=$newLead();$fair=CooperationNoticeOutbox::record($site,$fairLead,'assigned');Data::query('audit',$site)->where('id',$fair)->update(['update_time'=>time()-181]);
    outboxCheck(CooperationNoticeOutbox::recover(20,1,$sender)['processed']===1&&Data::row('audit',$site,$other)['action']==='notice_pending','another entity using same action cannot consume bounded recovery slots or starve real notices');

    // Real NoticeData + sender double, no network, to exercise a reclaimed
    // worker lease while the previous worker is still completing its channel.
    foreach([101,102]as$member)Db::name('member')->where('site_id',$site)->where('member_id',$member)->update(['weapp_openid'=>'outbox-synthetic-'.$member]);
    $templates=[];foreach(NoticeConfigService::PHASES as$phase=>$key)$templates[$phase]=['phase'=>$phase,'tid'=>'12345','kid_list'=>[1,2],'scene_desc'=>'Synthetic isolated lease fixture','fields'=>[['label'=>'编号','variable'=>'task_no','keyword'=>'character_string1'],['label'=>'状态','variable'=>'status_text','keyword'=>'thing2']]];
    (new CoreConfigService())->setConfig($site,NoticeConfigService::CONFIG_KEY,['templates'=>$templates]);NoticeConfigService::syncSite($site);
    foreach(NoticeConfigService::PHASES as$key)Db::name('sys_notice')->where('site_id',$site)->where('key',$key)->update(['is_weapp'=>1,'weapp_template_id'=>'synthetic-outbox-template']);
    Event::remove('NoticeData');Event::listen('NoticeData',CooperationNoticeData::class);$sent=[];
    $gateway=new FrameworkNoticeGateway(static function(string$channel,array$event)use(&$sent):bool{$sent[]=['channel'=>$channel,'event'=>$event];return true;});
    $leaseLead=$newLead();$leaseId=CooperationNoticeOutbox::record($site,$leaseLead,'assigned');$reclaimed=false;
    $racing=static function(array$payload)use(&$reclaimed,$site,$leaseId,$gateway):bool{
        if(!$reclaimed){$reclaimed=true;Data::query('audit',$site)->where('id',$leaseId)->update(['update_time'=>time()-181]);outboxCheck(CooperationNoticeOutbox::process($site,$leaseId,static fn(array$p)=>$gateway->dispatch($p)),'stale processing lease can be recovered independently of a slow previous worker');}
        return$gateway->dispatch($payload);
    };
    outboxCheck(!CooperationNoticeOutbox::process($site,$leaseId,$racing),'old worker cannot overwrite the terminal state of a reclaimed newer attempt');
    $leaseState=Data::decode(Data::row('audit',$site,$leaseId)['detail_json']);
    outboxCheck($leaseState['attempts']===2&&$leaseState['status']==='processed'&&count($sent)===2,'recipient/channel dedupe survives a reclaimed worker lease, one submission per member');
    outboxCheck(count(array_unique(array_column(array_column($sent,'event'),'to'),SORT_REGULAR))===2,'owner and receiver identities do not collapse into one or duplicate');
    $noRepeat=count($sent);outboxCheck(!CooperationNoticeOutbox::process($site,$leaseId,$racing)&&count($sent)===$noRepeat,'terminal recovered intent cannot replay a submitted notification');
    $obsoleteLead=$newLead();$obsoleteId=CooperationNoticeOutbox::record($site,$obsoleteLead,'assigned');$mutated=false;$before=count($sent);
    $stale=static function(array$payload)use(&$mutated,$site,$obsoleteLead,$gateway):bool{if(!$mutated){$mutated=true;Store::query('collaboration',$site)->where('id',$obsoleteLead)->update(['status'=>'following']);}return$gateway->dispatch($payload);};
    outboxCheck(!CooperationNoticeOutbox::process($site,$obsoleteId,$stale),'business revision change during processing makes the outbox obsolete');
    outboxCheck(Data::row('audit',$site,$obsoleteId)['action']==='notice_obsolete'&&count($sent)===$before,'changed original revision never reaches sender using stale action or a new state');
    $auditCount=Data::query('audit',$site)->where('entity_type','collaboration_notice')->count();
    (new \addon\hsx_lead\app\service\cooperation\CooperationNoticeService(static fn(array$p)=>$gateway->dispatch($p)))->changed(['site_id'=>$site,'lead_id'=>$obsoleteLead,'action'=>'assigned','assignment_version'=>1,'lead_status'=>'assigned']);
    outboxCheck(Data::query('audit',$site)->where('entity_type','collaboration_notice')->count()===$auditCount,'an already stale outbox snapshot cannot be reloaded and sent under the current status');

    // A deleted source row must not poison every later scheduled notification.
    // These are owned synthetic rows only; this does not repair historical data.
    $orphanLead=$newLead();$orphanIntent=CooperationNoticeOutbox::record($site,$orphanLead,'assigned');
    Store::query('collaboration',$site)->where('id',$orphanLead)->delete();
    $afterOrphan=$newLead();$afterOrphanIntent=CooperationNoticeOutbox::record($site,$afterOrphan,'assigned');
    $before=count($sent);$recovered=CooperationNoticeOutbox::recover(20,20,static fn(array$p)=>$gateway->dispatch($p));
    outboxCheck($recovered['processed']===1&&Data::row('audit',$site,$orphanIntent)['action']==='notice_failed','orphan intent is explicitly failed instead of aborting the whole recovery batch');
    outboxCheck(Data::row('audit',$site,$afterOrphanIntent)['action']==='notice_processed'&&count($sent)-$before===2,'valid notifications following an orphan are still processed once');
    $orphanState=Data::decode(Data::row('audit',$site,$orphanIntent)['detail_json']);
    outboxCheck(($orphanState['status']??'')==='failed'&&!str_contains(Data::json($orphanState),'SQLSTATE'),'orphan failure remains safe and auditable without raw database details');

    // The rotating cursor is disposable operational cache, never business config.
    outboxCheck(Db::name('sys_config')->where('config_key','HSX_LEAD_NOTICE_RECOVERY_CURSOR')->count()===0,'notification recovery never writes operational cursors into the config table');
    $scope=(string)Db::connect()->getConfig('database').':'.(string)Db::connect()->getConfig('prefix');
    $cursorKey='hsx_lead_notice_recovery_cursor:'.hash('sha256',$scope);
    $foreignCursorKey='hsx_lead_notice_recovery_cursor:'.hash('sha256',$scope.':another-database');
    outboxCheck((int)Cache::get($cursorKey)===($site+1)&&Cache::get($foreignCursorKey)===null,'cursor cache is bounded to the exact database and table prefix');
    Cache::set($cursorKey,'corrupted-cursor',86400);$afterCacheLoss=$newLead();$cacheLossIntent=CooperationNoticeOutbox::record($site,$afterCacheLoss,'assigned');
    outboxCheck(CooperationNoticeOutbox::recover(20,20,static fn(array$p)=>$gateway->dispatch($p))['processed']===1&&Data::row('audit',$site,$cacheLossIntent)['action']==='notice_processed','invalid cache can be discarded without losing persisted notification facts');
    Cache::delete($cursorKey);$afterClear=$newLead();$afterClearIntent=CooperationNoticeOutbox::record($site,$afterClear,'assigned');
    outboxCheck(CooperationNoticeOutbox::recover(20,20,static fn(array$p)=>$gateway->dispatch($p))['processed']===1&&Data::row('audit',$site,$afterClearIntent)['action']==='notice_processed','clearing framework cache does not lose or resend durable notification events');

    $badSnapshotLead=$newLead();$badSnapshotIntent=CooperationNoticeOutbox::record($site,$badSnapshotLead,'assigned');
    $badSnapshot=Data::decode(Data::row('audit',$site,$badSnapshotIntent)['detail_json']);unset($badSnapshot['action']);
    Data::query('audit',$site)->where('id',$badSnapshotIntent)->update(['detail_json'=>Data::json($badSnapshot)]);$before=count($sent);
    outboxCheck(!CooperationNoticeOutbox::process($site,$badSnapshotIntent,static fn(array$p)=>$gateway->dispatch($p))&&Data::row('audit',$site,$badSnapshotIntent)['action']==='notice_failed'&&count($sent)===$before,'incomplete original event snapshot fails closed before any channel claim');

    // A partial fanout may be recovered, but an already submitted channel must
    // not be resent while a different missing party keeps failing preparation.
    $partialLead=$newLead();Store::query('collaboration',$site)->where('id',$partialLead)->update(['receiver_id'=>999999901]);
    $partialIntent=CooperationNoticeOutbox::record($site,$partialLead,'assigned');$before=count($sent);
    for($attempt=1;$attempt<=10;$attempt++){
        outboxCheck(!CooperationNoticeOutbox::process($site,$partialIntent,static fn(array$p)=>$gateway->dispatch($p)),'partial preparation failure remains recoverable within its bounded attempt budget');
        $partialState=Data::decode(Data::row('audit',$site,$partialIntent)['detail_json']);
        outboxCheck(($partialState['status']??'')==='pending'&&($partialState['attempts']??0)===$attempt,'partial attempt counter is monotonic and persisted');
    }
    outboxCheck(count($sent)-$before===1,'partial recovery never resubmits the already submitted publisher channel');
    outboxCheck(!CooperationNoticeOutbox::process($site,$partialIntent,static fn(array$p)=>$gateway->dispatch($p))&&Data::row('audit',$site,$partialIntent)['action']==='notice_failed','exhausted preparation budget becomes an auditable terminal failure');
    $afterExhausted=count($sent);outboxCheck(!CooperationNoticeOutbox::process($site,$partialIntent,static fn(array$p)=>$gateway->dispatch($p))&&count($sent)===$afterExhausted,'exhausted task cannot restart by replaying the old queue job');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'random owned local schema; disabled framework senders, no external notification'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.$error->getFile().':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
