import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual PHP rules ↔ actual admin SFC setup/save ↔ actual mobile labels.
// Synthetic configuration inputs only. No database, live HTTP, money or binding.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../admin/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
let checks = 0
const check = (condition, label) => { assert.ok(condition, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
const clone = value => JSON.parse(JSON.stringify(value))
const phpSource = `namespace core\\exception { class CommonException extends \\RuntimeException {} }
namespace {
    require $argv[1]; require $argv[2];
    $input=json_decode(stream_get_contents(STDIN),true,32,JSON_THROW_ON_ERROR);
    $class='addon\\\\hsx_lead\\\\app\\\\service\\\\cooperation\\\\PromotionRules';
    if($argv[3]==='defaults')$result=$class::defaults();
    elseif($argv[3]==='config')$result=$class::config($input);
    elseif($argv[3]==='read')$result=$class::readConfiguration($input);
    elseif($argv[3]==='read_snapshot'){$before=$input;$projection=$class::readConfiguration($input);$result=['before'=>$before,'after'=>$input,'projection'=>$projection];}
    elseif($argv[3]==='reward')$result=$class::reward($input['base'],$input['rate']);
    else throw new \\RuntimeException('Unsupported isolated test operation');
    echo json_encode($result,JSON_THROW_ON_ERROR|JSON_UNESCAPED_UNICODE);
}`
function php(operation, value = {}) {
    return JSON.parse(execFileSync(process.env.PHP_BIN || process.env.PHP_BINARY || 'php', ['-n', '-d', 'display_errors=stderr', '-r', phpSource,
        path.join(plugin, 'app/service/cooperation/Rules.php'), path.join(plugin, 'app/service/cooperation/PromotionRules.php'), operation], { input: JSON.stringify(value), encoding: 'utf8', timeout: 10000 }))
}
function parse(relative) {
    const file = path.join(plugin, relative), source = fs.readFileSync(file, 'utf8'), parsed = compiler.parse(source, { filename: file })
    check(!parsed.errors.length, relative + ' actual SFC parses')
    const compiled = compiler.compileScript(parsed.descriptor, { id: 'promotion-config-contract' })
    check(!compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'promotion-config-contract', compilerOptions: { bindingMetadata: compiled.bindings, expressionPlugins: ['typescript'] } }).errors.length, relative + ' actual template compiles')
    return { source, descriptor: parsed.descriptor, compiled }
}
function execute(source, dependencies, mobile = false) {
    const module = { exports: {} }, javascript = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + javascript + '})', { Date, Number, String, Math, Set, Map, JSON, Promise, console, uni: { getStorageSync() {}, removeStorageSync() {}, setStorageSync() {}, showToast() {} } })(key => {
        if (key in dependencies) return dependencies[key]
        if (key.endsWith('.vue')) return { default: {} }
        if (mobile && key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        throw new Error('Unexpected dependency ' + key)
    }, module, module.exports)
    return module.exports
}

const defaults = php('defaults'), backendKeys = Object.keys(defaults.sources).sort()
equal(backendKeys, ['maintenance', 'membership'], 'the executed real PHP defaults define exactly the current two-source contract')
const maintenanceOnly = { enabled: true, settlement_days: 8, eligibility_months: 6, sources: { maintenance: { enabled: true, normal_rate: '2.50', provider_rate: '18.75', renewal: true } } }
const normalizedMaintenance = { ...maintenanceOnly.sources.maintenance, level_rates: [] }
let server = php('config', maintenanceOnly)
equal(Object.keys(server.sources).sort(), backendKeys, 'real PHP normalizes a legitimate maintenance-only stored configuration with the disabled membership default')
equal(server.sources.membership, defaults.sources.membership, 'missing membership rule is the actual backend disabled default, not an invented front-end entitlement')
equal(server.sources.maintenance, normalizedMaintenance, 'real PHP retains the existing two maintenance rates and participation state')
check(!('membership' in maintenanceOnly.sources), 'normalization never mutates the original synthetic stored input')

const admin = parse('admin/views/promotion/index.vue'), writes = [], notices = [], confirmations = []
let declineConfirmation = false
const administrative = execute(admin.descriptor.scriptSetup.content + '\nexport {sources,sourceRows,sourceLabel,purposeLabel,trialSource,trialAmounts,trialRows,normalizeConfig,loadConfig,saveRules,config,configReady,configError,configSaving,configRequiresReview,configReviewMessage}', {
    vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} },
    'element-plus': { ElMessage: { success: message => notices.push(message) }, ElMessageBox: { confirm: async (...args) => { confirmations.push(args); if (declineConfirmation) throw Error('cancel') } } },
    '@element-plus/icons-vue': { Refresh: {} }, '@/stores/modules/user': { default: () => ({ rules: ['hsx_lead_promotion_config', 'hsx_lead_promotion_config_save'] }) },
    '../../composables/navigation': { hasLeadPagePermission: (user, permission) => user.rules.includes(permission) },
    '../../composables/cooperation': { coopError: error => error.message, coopMoney: String, coopTime: String },
    '../../api/promotion': { getPromotionConfig: async () => ({ data: clone(server) }), savePromotionConfig: async payload => { writes.push(clone(payload)); server = php('read', php('config', payload)); return { data: clone(server) } } }
})
equal(administrative.sources.map(item => item.key).sort(), backendKeys, 'real admin setup sources exactly match the independently executed PHP default keys')
equal(administrative.trialSource.value, 'membership', 'the initial actual admin trial uses a supported member-service source')
await administrative.loadConfig()
check(administrative.configReady.value && !administrative.configError.value, 'actual admin loads PHP-normalized maintenance-only configuration without unsupported-source errors')
check(!administrative.configRequiresReview.value && !administrative.configReviewMessage.value, 'a compatible backend without new review metadata remains usable and does not invent a warning')
equal(administrative.config.sources.maintenance.normal_rate, 2.5, 'admin read projection preserves the current ordinary maintenance rate')
equal(administrative.config.sources.maintenance.provider_rate, 18.75, 'admin read projection preserves the current service-provider maintenance rate')
check(!administrative.config.sources.membership.enabled, 'reading does not enable missing membership commissions automatically')
const projected = administrative.normalizeConfig({ ...clone(server), readonly_metadata: 'synthetic', sources: { ...clone(server.sources), publishing: { enabled: true }, certification: { enabled: true } } })
equal(Object.keys(projected.sources).sort(), backendKeys, 'actual read normalization exposes only the current two-source form contract')
check(!('readonly_metadata' in projected), 'actual read normalization does not mix unrelated response metadata into editable config')
administrative.config.sources.membership = { enabled: true, normal_rate: 7.5, provider_rate: 15, renewal: true, injected_readonly: 'synthetic' }
administrative.config.sources.publishing = { enabled: true, normal_rate: '99.00', provider_rate: '99.00' }
administrative.config.sources.certification = { enabled: true, normal_rate: '99.00', provider_rate: '99.00' }
administrative.config.injected_readonly = 'synthetic'
await administrative.saveRules()
check(writes.length === 1 && notices.length === 1 && !administrative.configError.value, 'actual SFC save is accepted by actual PHP config validation and readback completes')
const written = writes[0]
equal(Object.keys(written).sort(), ['eligibility_months', 'enabled', 'settlement_days', 'sources'], 'save submits an explicit top-level write whitelist')
equal(Object.keys(written.sources).sort(), backendKeys, 'save cannot send obsolete publishing/certification keys even if stale in-memory state includes them')
for (const rule of Object.values(written.sources)) equal(Object.keys(rule).sort(), ['enabled', 'level_rates', 'normal_rate', 'provider_rate', 'renewal'], 'each source has only the five current writable rule fields')
equal(written.sources.membership, { enabled: true, normal_rate: '7.50', provider_rate: '15.00', renewal: true, level_rates: {} }, 'save preserves independent member/provider tiers and renewal instead of merging them')
equal(server.sources.maintenance, normalizedMaintenance, 'saving another source does not lose the existing maintenance rates')
equal(administrative.config.sources.membership.normal_rate, 7.5, 'actual readback publishes the backend-accepted member tier')
equal(administrative.sourceLabel('membership', '主体会员费'), '会员服务费', 'current reward labels no longer reuse stale membership-fee wording')
equal(administrative.sourceLabel('publishing', '历史入驻权益费'), '历史入驻权益费', 'unknown historical record labels remain facts and are not relabelled as new fees')
check(administrative.purposeLabel('membership') === '门店会员付款', 'whole paid-order review does not falsely label deposit/experience amounts as commissionable service fees')
administrative.trialAmounts.membership = 99
for (const row of administrative.trialRows.value) equal(Math.round(row.reward * 100), php('reward', { base: 9900, rate: row.rate }), 'real admin ' + row.role + ' preview matches actual PHP integer-cents reward calculation')

// Reproduce the production GET failure with real legacy input. The read adapter
// must expose a reviewable current form, never guess which retired tier wins.
const legacyStored = { ...clone(maintenanceOnly), sources: { ...clone(maintenanceOnly.sources), publishing: { enabled: true, normal_rate: '9.50', provider_rate: '27.50', renewal: true }, certification: { enabled: true, normal_rate: '17.50', provider_rate: '36.50', renewal: false } } }
const legacyRead = php('read_snapshot', legacyStored)
equal(legacyRead.after, legacyRead.before, 'actual PHP read projection leaves the original legacy configuration unchanged')
server = legacyRead.projection
check(server.requires_review && server.review_message.includes('原配置已保留'), 'actual PHP legacy read returns explicit review guidance rather than failing the GET')
equal(server.ignored_source_keys, ['publishing', 'certification'], 'actual PHP reports exactly the recognized retired source keys')
equal(server.sources.membership, defaults.sources.membership, 'actual PHP does not translate or merge retired rates into a paid-membership commission')
equal(server.sources.maintenance, normalizedMaintenance, 'legacy read preserves existing maintenance ratios without silently resetting them')
await administrative.loadConfig()
check(administrative.configReady.value && !administrative.configError.value && administrative.configRequiresReview.value, 'actual admin loads a legacy projection as an editable form with a non-blocking review warning')
equal(administrative.configReviewMessage.value, server.review_message, 'actual admin renders the server review guidance independently from ordinary load errors')
check(!('requires_review' in administrative.config) && !('review_message' in administrative.config) && !('ignored_source_keys' in administrative.config), 'review metadata never becomes editable financial configuration')
const beforeCancellation = writes.length
declineConfirmation = true
await administrative.saveRules()
check(writes.length === beforeCancellation && administrative.configRequiresReview.value && !administrative.configSaving.value, 'declining legacy-rule review confirmation performs no write and releases the submit lock')
declineConfirmation = false
administrative.config.sources.membership = { enabled: true, normal_rate: 3.25, provider_rate: 12.5, renewal: true }
await administrative.saveRules()
check(writes.length === beforeCancellation + 1 && confirmations.length === 2, 'reviewed save requires an explicit confirmation and then writes exactly once')
equal(Object.keys(writes.at(-1)).sort(), ['eligibility_months', 'enabled', 'settlement_days', 'sources'], 'reviewed save excludes all server projection metadata from its PUT')
equal(Object.keys(writes.at(-1).sources).sort(), backendKeys, 'reviewed save sends no retired publishing/certification rule back to strict PHP validation')
check(!administrative.configRequiresReview.value && !administrative.configReviewMessage.value && !server.requires_review, 'successful saved configuration readback explicitly clears the prior review warning')
await administrative.loadConfig()
check(!administrative.configRequiresReview.value && administrative.config.sources.membership.normal_rate === 3.25 && administrative.config.sources.maintenance.provider_rate === 18.75, 'subsequent real-backend read retains both accepted rates and does not revive the warning')
const explicitMemberRule = { enabled: true, normal_rate: '8.25', provider_rate: '19.25', renewal: false }
const withExplicitMember = php('read', { ...clone(legacyStored), sources: { ...clone(legacyStored.sources), membership: explicitMemberRule } })
equal(withExplicitMember.sources.membership, { ...explicitMemberRule, level_rates: [] }, 'legacy projection preserves an explicitly configured current membership rule rather than replacing it from retired sources')
check(admin.source.includes('v-if="configReady && configRequiresReview"') && admin.source.includes('已核对，保存当前规则'), 'actual admin template displays the warning and confirmation names the explicit reviewed-save action')

const panel = parse('uni-app/components/cooperation/CoopPromotionPanel.vue')
const ui = { overview: Vue.ref({}), application: Vue.ref({}), stop() {} }
const mobile = execute(panel.compiled.content, {
    vue: { ...Vue, onBeforeUnmount() {} }, '@dcloudio/uni-app': { onHide() {} }, '@/utils/common': { redirect() {} },
    '@/hooks/useShare': { useShare: () => ({}) }, '@/stores/system': { default: () => ({ site: {}, shareOptions: {} }) },
    '../../composables/usePromotion': { usePromotion: () => ui }, '../../api/cooperation': { coopDate: String, coopMoney: String },
    '../../utils/cooperation-navigation': { openCooperationTask() {} }
}, true).default.setup({ show: false, page: true, initialTab: 'overview' }, { emit() {}, expose() {} })
equal(mobile.sourceOptions.map(item => item.key).sort(), backendKeys, 'actual mobile rule sources use the exact same PHP key set as admin')
equal(mobile.sourceOptions.find(item=>item.key==='membership').label, '会员服务费', 'actual mobile current-source label is consistent with admin')
check(admin.source.includes('仅按实付服务费计算，不含押金、经验费') && panel.source.includes('只按实付服务费计算，不含押金和经验费'), 'both actual templates explicitly exclude deposits and purchased experience from commission basis')
console.log(`PASS ${checks} promotion configuration cross-layer checks; executed PHP defaults/config/reward and actual admin/mobile SFC state, no database or network.`)
