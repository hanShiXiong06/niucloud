<?php
declare(strict_types=1);
require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\cooperation\{Rules,ConfigService};
use core\exception\CommonException;
$checks=0;
function termCheck(bool $value,string $label):void{if(!$value)throw new RuntimeException($label);$GLOBALS['checks']++;}
function termReject(callable $run,string $label):void{try{$run();}catch(CommonException $error){termCheck(true,$label);return;}throw new RuntimeException($label);}
date_default_timezone_set('Asia/Shanghai');
$defaults=ConfigService::defaults();
termCheck(array_intersect_key($defaults,array_flip(['publishing_price','publishing_cycle','publishing_months','certification_price','certification_months','grades']))===[]&&$defaults['membership_levels']===[],'site defaults contain no independent price or hardcoded membership directory');
foreach([1,2,12,24,120]as$months)termCheck(Rules::entitlementMonths('membership',['months'=>$months])===$months,'dynamic paid snapshot permits bounded custom durations');
foreach([0,121,-1,'12',null,1.0,[]]as$value)termReject(fn()=>Rules::entitlementMonths('membership',['months'=>$value]),'invalid or untyped membership term rejected');
foreach(['publishing','certification','commission','unknown']as$purpose)termReject(fn()=>Rules::entitlementMonths($purpose,['months'=>1]),'only membership is an entitlement');
termCheck(date('Y-m-d H:i:s',Rules::addMonths(strtotime('2024-02-29 10:30:00'),12))==='2025-02-28 10:30:00','annual leap date clamps correctly');
termCheck(date('Y-m-d H:i:s',Rules::addMonths(strtotime('2026-01-31 10:30:00'),1))==='2026-02-28 10:30:00','monthly plan clamps at month end');
$split=Rules::split(100,['commission_minimum'=>'1.00','fee_percent'=>'10.00','fee_minimum'=>'0.00','fee_confirmed'=>true]);
termCheck($split===['amount'=>'1.00','fee_amount'=>'0.10','net_amount'=>'0.90'],'configured fee below 50 works without over-allocation');
termReject(fn()=>Rules::split(0,['commission_minimum'=>'0.00','fee_percent'=>'0.00','fee_minimum'=>'0.00','fee_confirmed'=>true]),'free zero-value commission cannot enter cashier');
$at=1800000000;$required=['publishing_required'=>true];
termCheck(!Rules::membershipActive([],$required,$at),'missing subject context does not grant a free membership');
termCheck(!Rules::membershipActive(['provider_enabled'=>true,'provider_status'=>'approved'],$required,$at),'service-provider approval is not a paid subject membership');
termCheck(Rules::membershipActive([],['publishing_required'=>false],$at),'explicit administrator fee waiver remains distinct from a consumer free tier');
$free=Rules::capabilities([],['publishing_required'=>false]);
termCheck($free===['can_publish'=>true,'can_accept'=>true,'can_view_inventory'=>true,'all_models'=>false],'free operation never invents all-model delivery capacity');
echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'pure membership terms and cent-based configurable fees; no database/network'],JSON_UNESCAPED_UNICODE).PHP_EOL;
