import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..')
const require=createRequire(path.join(workspace,'admin/package.json')),Vue=require('vue'),ts=require('typescript'),compiler=require('@vue/compiler-sfc')
const read=name=>fs.readFileSync(path.join(plugin,'admin',name),'utf8')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
function component(file,names,deps,props={}){
    const source=read(file),parsed=compiler.parse(source,{filename:file})
    check(parsed.errors.length===0,file+' parses');compiler.compileScript(parsed.descriptor,{id:'supervision-test'})
    check(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'supervision-test',compilerOptions:{expressionPlugins:['typescript']}}).errors.length===0,file+' template compiles')
    for(const style of parsed.descriptor.styles)check(compiler.compileStyle({source:style.content,filename:file,id:'supervision-test',scoped:style.scoped}).errors.length===0,file+' style compiles')
    const module={exports:{}},code=ts.transpileModule(parsed.descriptor.scriptSetup.content+`\nexport { ${names} }`,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{
        Number,String,Boolean,Array,Object,Promise,Error,console,setTimeout,clearTimeout,
        defineProps:()=>props,withDefaults:(value,defaults)=>({...Object.fromEntries(Object.entries(defaults).map(([key,item])=>[key,typeof item==='function'?item():item])),...value}),
        defineEmits:()=>deps.emit||(()=>{}),
    })(key=>{if(key in deps)return deps[key];if(key.endsWith('.vue'))return{default:{}};throw Error('Unexpected dependency '+key)},module,module.exports)
    return module.exports
}
const messages=[],calls=[],changed=[],receiver={id:202,name:'原承接门店'},detailResult={id:7,customer_name:'合成客户',receiver,owner_uid:11,owner_name:'原监管人'}
const state=component('views/cooperation/LeadDetail.vue','detail,load,beginTransfer,transfer,targetUid,confirmed,targetName,transferVisible,saving',{
    vue:{...Vue,watch(){},onBeforeUnmount(){}},'element-plus':{ElMessage:{success:value=>messages.push(value)}},'@/utils/common':{img:value=>value},
    '../../api/cooperation':{getCooperationLead:async id=>{calls.push(['get',id]);return{data:{...detailResult}}},transferCooperationOwner:async(id,data)=>calls.push(['transfer',id,data])},
    '../../composables/cooperation':{coopBusiness:value=>value,coopError:error=>error.message,coopLabel:value=>value,coopModels:()=>[],coopMoney:value=>value,coopTime:value=>value,coopTone:()=> 'info',useCooperationAccess:()=>({allows:()=>false})},
    '../../composables/business':{businessDimensionLabels:{},businessFormEntries:()=>[]},emit:(...args)=>changed.push(args)
},{modelValue:true,leadId:7,viewerScope:{can_transfer:true}})
await state.load();state.beginTransfer()
check(state.transferVisible.value&&!state.targetUid.value&&!state.confirmed.value,'opening the regulator dialog never chooses an employee automatically')
state.targetUid.value=12;await state.transfer()
check(!calls.some(row=>row[0]==='transfer'),'a target alone cannot mutate responsibility without explicit confirmation')
state.confirmed.value=true;await state.transfer()
check(JSON.stringify(calls.find(row=>row[0]==='transfer'))===JSON.stringify(['transfer',7,{owner_uid:12,expected_owner_uid:11}]),'confirmed correction sends only the existing owner concurrency contract, not merchant dispatch')
check(JSON.stringify(state.detail.value.receiver)===JSON.stringify(receiver)&&!state.saving.value&&!state.transferVisible.value,'receiver remains unchanged after a successful regulator correction and detail reload')
check(messages[0]==='监管负责人已调整'&&changed.some(row=>row[0]==='changed'),'success names the actual regulator change and refreshes the parent')
const detailSource=read('views/cooperation/LeadDetail.vue')
check(detailSource.includes('由商户选择承接门店，平台仅负责监管')&&!detailSource.includes('转交内部归属'),'detail distinguishes merchant delivery from platform supervision')
check(detailSource.includes('仅变更平台内的监管责任，不转交客户、不更换承接门店'),'confirmation exposes the exact operation impact')
const owners=[],events=[]
const picker=component('views/components/OwnerSelect.vue','load,select,rows,visibleOptions',{
    vue:{...Vue,onBeforeUnmount(){}},'../../api/cooperation':{getCooperationOwners:async query=>{owners.push(query);return{data:{data:[{uid:11,name:'原监管人'},{uid:12,name:'新监管人'}],total:2}}}},
    '../../composables/useLeadUi':{errorText:error=>error.message},emit:(...args)=>events.push(args)
},{modelValue:'',excludeUid:11,includeUnassigned:true})
await picker.load();picker.select(11)
check(!events.length,'current regulator cannot be submitted again through the selector')
picker.select(12)
check(events[0][0]==='update:modelValue'&&events[0][1]===12,'searchable native selector emits the explicit chosen regulator identity')
picker.select(0)
check(events.at(-1)[1].name==='未指定监管负责人','unassigned filter describes platform responsibility, not a lead awaiting merchant dispatch')
check(owners[0].limit===20&&picker.rows.value.length===2,'selector retains server pagination and searchable native behavior')
for(const file of ['views/components/OwnerSelect.vue','views/cooperation/LeadDetail.vue','views/cooperation/Leads.vue'])check(read(file)===fs.readFileSync(path.join(workspace,'admin/src/addon/hsx_lead',file),'utf8'),file+' canonical/mirror remain identical')
const leads=read('views/cooperation/Leads.vue')
component('views/cooperation/Leads.vue','columns',{
    vue:{...Vue,onMounted(){},watch(){}},'../../api/cooperation':{},'../../composables/cooperation':{cooperationStatuses:[],coopBusiness(){},coopLabel(){},coopModels(){},coopMoney(){},coopTime(){},coopTone(){},useCooperationList:()=>({query:Vue.reactive({}),rows:Vue.ref([]),total:Vue.ref(0),load(){},search(){},changePage(){}})},'../../composables/business':{businessFormEntries:()=>[]}
})
check(leads.includes('按监管负责人筛选')&&leads.includes('监管负责人 / 发布于'),'list filter and column use one consistent supervision concept')
check(!read('views/components/PageShell.vue').includes('leadPagePaths'),'native menu grouping does not add a second private page navigation')
// Use the real NiuCloud route formatter plus Vue Router; directories must not prefix
// or rename any existing absolute app-relative page URL.
const routerModule={exports:{}},routerSource=fs.readFileSync(path.join(workspace,'admin/src/router/routers.ts'),'utf8').replace(/import\.meta\.glob\([^\n]+\)/g,'fixtureModules()')
const routerCode=ts.transpileModule(routerSource,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${routerCode}\n})`,{fixtureModules:()=>({}),Symbol,Array,Object})(key=>key==='vue-router'?require('vue-router'):{default:{}},routerModule,routerModule.exports)
const localPhp='/Users/a123/Library/PhpWebStudy/app/static-php-8.0.30/bin/php',php=process.env.LEAD_TEST_PHP||(fs.existsSync(localPhp)?localPhp:'php')
const menu=JSON.parse(execFileSync(php,['-r',`echo json_encode(require $argv[1]);`,path.join(plugin,'app/dict/menu/site.php')],{encoding:'utf8'}))
const pages=[]
function routeInput(nodes){return nodes.filter(row=>Number(row.menu_type)!==2).map(row=>{if(Number(row.menu_type)===1)pages.push(row);return{...row,app_type:'site',addon:'hsx_lead',children:routeInput(row.children||[])}})}
const formatted=routerModule.exports.formatRouters(routeInput(menu)),nativeRouter=require('vue-router'),router=nativeRouter.createRouter({history:nativeRouter.createMemoryHistory(),routes:formatted})
check(formatted[0].children.length===6,'native formatter keeps exactly six navigation directory groups')
for(const page of pages)check(router.resolve({name:page.menu_key}).path==='/site/'+page.router_path,'native named route keeps the exact existing page URL: '+page.menu_key)
console.log(`PASS ${checks} supervision SFC/state/confirmation checks; real Vue state with synthetic transports, no business writes.`)
