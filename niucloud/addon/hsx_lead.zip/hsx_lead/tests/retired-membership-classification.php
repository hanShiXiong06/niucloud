<?php
declare(strict_types=1);
require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\cooperation\EntityMembershipService;
$source=file_get_contents(dirname(__DIR__).'/scripts/clean-retired-membership.php');$checks=0;
function retirementCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
// Execute ONLY the actual pure classification closure, never the CLI program,
// its environment bootstrap, PDO connection, check mode, backup or apply mode.
if(!preg_match('/\$isRetired\s*=\s*(static function\(array \$order\): bool \{.*?\n    \});/s',$source,$match))throw new RuntimeException('Cannot isolate the exact pure retirement predicate');
retirementCheck(str_contains($match[1],'EntityMembershipService::SNAPSHOT_SCHEMA'),'retirement follows the single public current-contract constant');
retirementCheck(!preg_match('/\b(?:PDO|Db|exec|include|require|unlink|file_put_contents)\b/',$match[1]),'isolated predicate has no database, filesystem or process capability');
$classify=eval('use '.EntityMembershipService::class.'; return '.$match[1].';');
$row=static fn(string$purpose,?string$schema):array=>['purpose'=>$purpose,'rule_json'=>json_encode($schema===null?[]:['schema_version'=>$schema],JSON_THROW_ON_ERROR)];
retirementCheck(!$classify($row('membership',EntityMembershipService::SNAPSHOT_SCHEMA)),'a current v3 receipt is never classified as retired');
retirementCheck($classify($row('membership','hsx_lead.entity_membership.v2')),'pre-experience v2 is distinctly retired, not silently upgraded');
retirementCheck($classify($row('membership','hsx_lead.entity_membership.v1')),'old fixed-tier contract remains distinct');
retirementCheck($classify($row('membership',null)),'incomplete membership schema requires explicit cleanup review');
retirementCheck($classify($row('publishing',null))&&$classify($row('certification',null)),'only the explicitly retired standalone purposes are selected');
retirementCheck(!$classify($row('commission',null)),'cooperation commission facts are never blanket-deleted as old membership');
retirementCheck(!$classify($row('other',null)),'unrelated trade purposes remain outside the cleanup predicate');
echo 'PASS '.$checks." pure retirement classification checks; exact source closure only, no CLI script run, database or data cleanup.\n";
