import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const ts=require('typescript'),pre=require('@dcloudio/uni-cli-shared'),shared=require('@dcloudio/uni-shared')
const source=fs.readFileSync(path.join(plugin,'uni-app/utils/bundled-image.ts'),'utf8')
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++}
function utility(platform,globals={}){
    pre.initPreContext(platform)
    const filtered=pre.preJs(source),module={exports:{}}
    const js=ts.transpileModule(filtered,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(module,exports){${js}\n})`,globals)(module,module.exports)
    return{...module.exports,filtered}
}
const browser={location:{origin:'http://localhost:5173',href:'http://localhost:5173/wap/100005/addon/hsx_lead/pages/index'}}
const h5=utility('h5',{window:browser})
const installed=fs.readFileSync(require.resolve('@dcloudio/uni-h5/dist/uni-h5.es.js'),'utf8')
const begin=installed.indexOf('function addBase(filePath)'),end=installed.indexOf('const ua = navigator.userAgent;',begin)
check(begin>=0&&end>begin,'installed uni-image path normalizer is present for the real regression')
function normalize(value,base){return vm.runInNewContext(installed.slice(begin,end)+'\ngetRealPath(input)',{...shared,__uniConfig:{router:{base,assets:'assets'}},getCurrentPages:()=>[],getRealRoute(){throw Error('Unexpected page-relative image')},input:value})}
check(normalize('/wap/assets/store-demo.png','/wap/100005/')==='/wap/100005/wap/assets/store-demo.png','actual installed uni-image reproduces the doubled tenant-prefix bug')
for(const base of ['/wap/100005/','/wap/100006/','/brand/demo/','/','./']){
    browser.location.href='http://localhost:5173'+base+'addon/hsx_lead/pages/stores/index'
    const image=h5.bundledImage('/wap/assets/store-demo.png')
    check(image==='http://localhost:5173/wap/assets/store-demo.png','trusted bundled public path is rooted at the same origin, independent of '+base)
    check(normalize(image,base)===image,'actual installed uni-image does not prepend tenant '+base+' a second time')
}
browser.location.origin='https://gl.hsxbk.top'
check(h5.bundledImage('/wap/assets/avatar-wing.png')==='https://gl.hsxbk.top/wap/assets/avatar-wing.png','HTTPS production remains same-origin, not the configured upload CDN')
for(const value of ['https://cdn.example.test/a.png','//cdn.example.test/a.png','data:image/png;base64,AA','blob:synthetic','bundled:test.png',''])check(h5.bundledImage(value)===value,'already special/absolute import is not rewritten: '+value)
for(const value of [undefined,null,17,{}])check(h5.bundledImage(value)==='','invalid imported value is harmless: '+String(value))
check(utility('h5').bundledImage('/wap/assets/ssr.png')==='/wap/assets/ssr.png','SSR/Node without window never reads a nonexistent location')
check(utility('h5',{window:{}}).bundledImage('/wap/assets/ssr.png')==='/wap/assets/ssr.png','an absent browser location is also safe')
const mini=utility('mp-weixin',{window:browser})
check(!mini.filtered.includes('window')&&!mini.filtered.includes('location'),'real uni preprocessing removes every browser-global access from Mini Program helper')
for(const value of ['/static/local.png','/wap/assets/local.png','../../static/local.png'])check(mini.bundledImage(value)===value,'Mini Program preserves its original bundled path: '+value)
pre.initPreContext('h5')
for(const [file,fragment]of [
    ['components/cooperation/CoopRoleEntryCard.vue','return bundledImage(role.value'],
    ['components/cooperation/CoopMerchantAvatar.vue','const wingImage = bundledImage(highlightWing)'],
    ['components/cooperation/StoreDiscoveryPanel.vue','const storeArt = bundledImage(storeAsset)'],
])check(fs.readFileSync(path.join(plugin,'uni-app',file),'utf8').includes(fragment),'trusted imports use the same small adapter: '+file)
const card=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopRoleEntryCard.vue'),'utf8')
check(card.includes('return img(settings.value.image.trim())'),'customer-uploaded illustrations still use the framework upload path resolver')
check(!source.includes('VITE_IMG_DOMAIN')&&!/fetch\(|request\(|localStorage|uni\./.test(source),'adapter does not change CDN configuration, touch stored data, or issue a request')
console.log(`PASS ${checks} bundled image regressions; actual installed uni-image normalization and platform preprocessing, synthetic location only, no browser/API/file writes.`)
