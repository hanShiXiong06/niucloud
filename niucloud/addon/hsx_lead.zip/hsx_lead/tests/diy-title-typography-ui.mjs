import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Execute the actual generic TopTabbar and plugin policy. No site API, saved
// decoration, browser, database, external service or build output is touched.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const workspace=path.resolve(plugin,'../../..'),require=createRequire(path.join(workspace,'uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const { compile }=require('@vue/compiler-dom'),{renderToString}=require('@vue/server-renderer')
const filename=path.join(workspace,'uni-app/src/components/top-tabbar/top-tabbar.vue'),source=fs.readFileSync(filename,'utf8')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
function platformSource(input,target){
    const stack=[]
    return input.split('\n').filter(line=>{
        const start=line.match(/(?:\/\/|<!--|\/\*)\s*#ifdef\s+([A-Z0-9-]+)/)
        if(start){stack.push(start[1]===target||(start[1]==='MP'&&target.startsWith('MP-')));return false}
        if(/#endif/.test(line)){stack.pop();return false}
        return stack.every(Boolean)
    }).join('\n')
}
function header(config={},target='MP-WEIXIN',platform='ios'){
    const parsed=compiler.parse(platformSource(source,target),{filename})
    assert.deepEqual(parsed.errors,[]);checks++
    const compiled=compiler.compileScript(parsed.descriptor,{id:'topbar-title'})
    const template=compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'topbar-title',compilerOptions:{bindingMetadata:compiled.bindings,expressionPlugins:['typescript']}})
    assert.deepEqual(template.errors,[]);checks++
    const store=Vue.reactive({mode:'',imageAdsSameScreen:false,$patch:callback=>callback(store)}),mounted=[],actions=[]
    const props=Vue.reactive({data:{title:'门店协作标题',topStatusBar:{style:'style-1',isShow:true,textColor:'#123456',rollTextColor:'#654321',textAlign:'left',bgColor:'#eef5ff',rollBgColor:'#ffffff',...config}},scrollBool:0,isBack:true,isFill:true})
    const system=Vue.reactive({systemInfo:{platform,statusBarHeight:24},menuButtonInfo:{height:32,top:24,right:360,width:88},setTopTabbar(){}})
    const module={exports:{}},js=ts.transpileModule(compiled.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,Object,String,getCurrentPages:()=>[{},{}],uni:{getStorageSync(){return{}},setStorageSync(){},navigateBack(){actions.push('back')}}})(key=>{
        if(key==='vue')return{...Vue,onMounted:fn=>mounted.push(fn),getCurrentInstance:()=>null}
        if(key==='@/utils/common')return{redirect:value=>actions.push(value),img:value=>value,currRoute:()=>''}
        if(key==='@/stores/system')return{default:()=>system}
        if(key==='@/app/stores/diy')return{default:()=>store}
        if(key==='@/hooks/useLocation')return{useLocation:()=>({onLoad(){},init(){},refresh(){},reposition(){}})}
        throw Error('Unexpected dependency '+key)
    },module,module.exports)
    const state=module.exports.default.setup(props,{expose(){}})
    return{state,props,store,actions,render:new Function('Vue',compile(parsed.descriptor.template.content,{mode:'function',prefixIdentifiers:true}).code)(Vue),css:parsed.descriptor.styles.map(item=>item.content).join('\n')}
}
const {applyCooperationDiyTitle}=loadMobileUtility('diy-title')
const data={global:{title:'后台自定义标题',topStatusBar:{isShow:false,style:'style-2',textAlign:'center',textColor:'#998877',link:{name:'custom'}}},value:[{componentName:'GraphicNav'}]}
const global=data.global,items=data.value,link=data.global.topStatusBar.link
applyCooperationDiyTitle(data)
check(data.global===global&&data.value===items,'runtime merge preserves the framework initial data/global/component identities')
check(data.global.title==='后台自定义标题'&&data.global.topStatusBar.isShow===false,'configured title and an explicit hidden header are never overridden')
check(data.global.topStatusBar.style==='style-2'&&data.global.topStatusBar.textAlign==='center'&&data.global.topStatusBar.textColor==='#998877'&&data.global.topStatusBar.link===link,'configured style, colors, alignment and link remain intact')
check(data.global.topStatusBar.titleFontSize===20&&data.global.topStatusBar.titleFontWeight===700&&data.global.topStatusBar.titleLineHeight===28&&data.global.topStatusBar.h5Height===44,'home and profile receive the same 20/700/28 typography and 44px H5 bar')
const customized={global:{topStatusBar:{isShow:true,titleFontSize:24,titleFontWeight:600,titleLineHeight:32,h5Height:52,h5Visible:false}}}
applyCooperationDiyTitle(customized)
check(customized.global.topStatusBar.titleFontSize===24&&customized.global.topStatusBar.titleFontWeight===600&&customized.global.topStatusBar.titleLineHeight===32&&customized.global.topStatusBar.h5Height===52&&customized.global.topStatusBar.h5Visible===false,'valid administrator typography/height/visibility is preserved, not overwritten by plugin defaults')
const malformed={global:{topStatusBar:{titleFontSize:'url(secret)',titleFontWeight:950,titleLineHeight:0,h5Height:NaN}}}
applyCooperationDiyTitle(malformed)
check(malformed.global.topStatusBar.titleFontSize===20&&malformed.global.topStatusBar.titleFontWeight===700&&malformed.global.topStatusBar.titleLineHeight===28&&malformed.global.topStatusBar.h5Height===44,'invalid configured typography safely uses shared defaults without injecting CSS')
for(const empty of [null,{}, {global:{}}, {global:{topStatusBar:null}}, {global:{topStatusBar:[]}}])applyCooperationDiyTitle(empty)
check(true,'missing/decorating/loading header data is a safe no-op')
for(const platform of ['ios','android']){
    const old=header({},'MP-WEIXIN',platform),expected=platform==='ios'?'32rpx':'36rpx'
    check(old.state.styleOneFontSize.value.includes(`font-size: ${expected};`)&&old.state.styleOneFontSize.value.includes('font-weight: 500;')&&!old.state.styleOneFontSize.value.includes('20px'),'unconfigured '+platform+' pages retain the prior platform typography')
    const configured=header({...data.global.topStatusBar,style:'style-1'},'MP-WEIXIN',platform),style=configured.state.styleOneFontSize.value
    check(style.endsWith('font-size:20px;font-weight:700;line-height:28px;'),'configured '+platform+' style overrides the default last, at the title element')
    check(style.includes('text-align: center;')&&style.includes('color: #998877;'),'DIY alignment and colors survive typography overrides')
    configured.props.scrollBool=1
    check(configured.state.titleTextColor.value==='#654321'&&configured.state.bgColor.value==='#ffffff','scroll-state colors retain framework behavior')
    configured.state.goBack();check(configured.actions[0]==='back','framework back navigation remains functional')
}
const unchanged=header({},'H5'),web=header({titleFontSize:20,titleFontWeight:700,titleLineHeight:28,h5Visible:true,h5Height:44},'H5')
check(unchanged.state.styleOneFontSize.value.includes('font-size: 28rpx;')&&!unchanged.state.navbarInnerStyle.value.includes('height:'),'unconfigured H5 pages retain their existing font and visibility/height policy')
check(web.state.navbarInnerStyle.value.includes('height:44px;'),'opted-in H5 navigation reserves the same 44px height as business pages')
check(web.css.includes('.is-h5-visible.style-1')&&web.css.includes('display: none;')&&web.css.includes('display: block;'),'H5 title remains opt-in without changing other DIY pages')
const invalid=header({titleFontSize:'20px;display:none',titleFontWeight:'bold',titleLineHeight:1000,h5Visible:true,h5Height:1},'H5')
check(Object.keys(invalid.state.titleTypography.value).length===0&&invalid.state.navbarInnerStyle.value.includes('height:44px;'),'invalid CSS/typography input is ignored and opted-in height safely defaults to44px')
async function html(fixture){const app=Vue.createSSRApp({setup:()=>({...fixture.state}),render:fixture.render});app.config.warnHandler=()=>{};return renderToString(app)}
const visible=await html(web)
check(visible.includes('门店协作标题')&&visible.includes('font-size:20px')&&visible.includes('font-weight:700')&&visible.includes('is-h5-visible'),'actual H5 title render carries the generic typography and visibility contract')
web.store.mode='decorate';check(!(await html(web)).includes('门店协作标题'),'framework editor still owns the preview header; no duplicate live header is mounted')
for(const page of ['pages/index.vue','pages/profile/index.vue']){
    const pageSource=fs.readFileSync(path.join(plugin,'uni-app',page),'utf8')
    check(pageSource.includes('applyCooperationDiyTitle(unref(diy.data))')&&pageSource.includes('<diy-group'),'both existing DIY pages apply the shared policy without replacing the renderer')
}
const profile=fs.readFileSync(path.join(plugin,'uni-app/pages/profile/index.vue'),'utf8')
check(profile.indexOf('<diy-group')<profile.indexOf('<template v-if="pageLoad.ready.value && !context.preview.value">'),'profile header placeholder precedes login/loading states; business states wait for page metadata')
const section=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopProfileDiySection.vue'),'utf8')
check(/__heading\s*\{[^}]*font-size:\s*var\(--lead-diy-title-size,18px\)/.test(section),'profile section heading size follows its shared appearance contract rather than a competing hardcoded page header')
console.log(`PASS ${checks} DIY title typography checks; actual SFC setup/render on H5+iOS+Android with synthetic runtime only; no API/database/browser/deployment.`)
