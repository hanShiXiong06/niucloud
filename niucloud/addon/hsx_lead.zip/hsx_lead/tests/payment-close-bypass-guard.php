<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,PaymentService,PaymentOrderLifecycle,PaymentCloseScope,Store};
use addon\hsx_lead\app\listener\pay\{CooperationPayCloseGuard,CooperationPayCreate};
use addon\hsx_lead\app\middleware\CooperationPaymentGuard;
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{OnlinePayDict,PayDict};
use app\service\core\pay\CorePayService;
use core\exception\CommonException;
use think\facade\{Db,Event};
$checks=0;$pdo=null;$schema='';$failed=false;
function bpCheck(bool$ok,string$name):void{if(!$ok)throw new RuntimeException($name);$GLOBALS['checks']++;}
function bpDeny(callable$fn,string$name):void{try{$fn();}catch(CommonException|\core\exception\PayException$error){bpCheck(true,$name);return;}throw new RuntimeException('Not denied: '.$name);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();
    foreach(['pay','pay_refund','pay_channel']as$table){$official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m))throw new RuntimeException('Missing fixture table');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    $ctx=new Context($site,0,102);$config=ConfigService::defaults();$config['enabled']=true;$config['fee_confirmed']=true;(new ConfigService(new Context($site,1)))->save($config);
    $profile=['name'=>'Synthetic receiver','contact_name'=>'Fixture','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture address','provider'=>''];
    $receiver=(new PartnerService($ctx))->saveProfile($profile);$publisher=(new PartnerService(new Context($site,0,101)))->saveProfile(array_replace($profile,['name'=>'Synthetic publisher','mobile'=>'19900000101']));
    $new=static function(int$status)use($site,$ctx,$publisher,$receiver):array{$suffix=bin2hex(random_bytes(7));$rule=['purpose'=>'commission','fee_percent'=>'10.00','fee_minimum'=>'9.90','commission_minimum'=>'50.00','fee_confirmed'=>true];$lead=(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'BYPASS_'.$suffix,'request_id'=>'BYPASS_'.$suffix,'publisher_id'=>$publisher['id'],'receiver_id'=>$receiver['id'],'status'=>'unpaid','rule_json'=>Data::json($rule)]);$order=(new PaymentService($ctx))->createOrder(['purpose'=>'commission','lead_id'=>$lead,'amount'=>'50.00','request_id'=>'bypass-'.$suffix]);$no='BYPASS_'.bin2hex(random_bytes(12));Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>$status,'type'=>$status===(int)PayDict::STATUS_ING?PayDict::WECHATPAY:'','channel'=>$status===(int)PayDict::STATUS_ING?'weapp':'']);return[$order,$no];};
    $events=require dirname(__DIR__).'/app/event.php';bpCheck(($events['listen']['PayClose']??[])===[CooperationPayCloseGuard::class],'plugin registers a real existing framework PayClose hook, no framework override');
    Event::remove('PayClose');Event::listen('PayClose',CooperationPayCloseGuard::class);Event::remove('PayCreate');Event::listen('PayCreate',CooperationPayCreate::class);
    [$order,$no]=$new((int)PayDict::STATUS_ING);$payCount=Db::name('pay')->count();$core=new CorePayService();
    $unsafeProvider=new class{public array$calls=[];public function init($s,$c,$t){return$this;}public function close($no){$this->calls[]='close';return false;}public function getOrder($no){$this->calls[]='query';return[];}public function pay(...$args){throw new RuntimeException('Unsafe gateway pay reached');}};
    $property=new ReflectionProperty(CorePayService::class,'pay_event');$property->setAccessible(true);$property->setValue($core,$unsafeProvider);
    bpDeny(fn()=>$core->payClose($site,['out_trade_no'=>$no,'reason'=>'trusted channel already closed','trusted'=>true]),'caller-controlled reason or trusted flag does not authorize local cancellation');
    bpCheck((int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_ING,'untrusted direct payClose rolls back local CANCEL marker');
    bpDeny(fn()=>$core->close($site,$no),'real unsafe close false+unknown fallback is vetoed by plugin hook');bpCheck($unsafeProvider->calls===['close','query']&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_ING,'unsafe fallback cannot commit local cancellation for this plugin');
    $core->returnTo($site,$no);bpCheck((int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_ING,'actual PayReturnTo returnTo path cannot blindly cancel a processing plugin payment');
    bpDeny(fn()=>$core->checkOrCreate($site,PaymentService::TRADE_TYPE,(int)$order['id']),'PayCreate vetoes a new payment even if checkOrCreate ignored close false');
    bpCheck(Db::name('pay')->count()===$payCount&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_ING,'framework retry creates no second out_trade_no and preserves original evidence');
    bpDeny(fn()=>$core->createByTrade($site,PaymentService::TRADE_TYPE,(int)$order['id']),'direct framework createByTrade is independently rejected by PayCreate ING guard');
    bpCheck(Db::name('pay')->count()===$payCount,'direct PayCreate bypass cannot create another original-price cashier');
    bpDeny(fn()=>(new PaymentService($ctx))->assertPayable((int)$order['id']),'plugin cashier permission also rejects every unfinished processing payment');
    $app->http->name('api');$guard=new CooperationPaymentGuard();$nextCalls=0;
    $request=static function(string$action)use($site,$order):\app\Request{$r=new \app\Request();$r->setController('pay.Pay')->setAction($action)->withGet(['trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'type'=>PayDict::WECHATPAY]);$r->siteId($site);$r->memberId(102);return$r;};
    bpDeny(fn()=>$guard->handle($request('pay'),function()use(&$nextCalls,$core,$site,$order){$nextCalls++;return$core->pay($site,PaymentService::TRADE_TYPE,(int)$order['id'],PayDict::WECHATPAY,'weapp','synthetic-openid');}),'actual HTTP pay middleware prevents framework checkOrCreate/gateway retry');
    bpCheck($nextCalls===0,'rejected retry never enters the unsafe framework path or gateway');
    $info=$guard->handle($request('info'),static fn()=>$core->getInfoByTrade($site,PaymentService::TRADE_TYPE,(string)$order['id'],'weapp'));
    bpCheck(is_array($info)&&(int)$info['status']===(int)PayDict::STATUS_ING&&$info['out_trade_no']===$no,'HTTP readonly info still returns existing processing payment without invoking PayCreate');
    bpCheck(Db::name('pay')->count()===$payCount,'readonly existing payment query creates no extra trade');
    bpCheck(!PaymentCloseScope::allowed($site,$no),'no ambient close permission exists');
    try{PaymentCloseScope::run($site,$no,static function()use($site,$no):void{bpCheck(PaymentCloseScope::allowed($site,$no)&&!PaymentCloseScope::allowed($site+1,$no)&&!PaymentCloseScope::allowed($site,$no.'x'),'close permission is scoped to exact site and original trade number');throw new RuntimeException('Expected scoped exception');});}catch(RuntimeException$ignored){}
    bpCheck(!PaymentCloseScope::allowed($site,$no),'finally releases close permission even on exception');
    [$waiting,$waitNo]=$new((int)PayDict::STATUS_WAIT);$closed=(new PaymentOrderLifecycle($ctx))->close((int)$waiting['id'],['confirm'=>true]);
    bpCheck($closed['status']==='closed'&&(int)Db::name('pay')->where('out_trade_no',$waitNo)->value('status')===(int)PayDict::STATUS_CANCEL,'verified WAIT lifecycle path has trusted permission and remains functional');
    $provider=new class{public int$count=0;public function getOrder($no){$this->count++;return['status'=>OnlinePayDict::CLOSED];}public function close($no){throw new RuntimeException('Already closed should not re-close');}};
    $closed=(new PaymentOrderLifecycle($ctx,static fn()=>$provider))->close((int)$order['id'],['confirm'=>true]);
    bpCheck($closed['status']==='closed'&&$provider->count===1&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_CANCEL,'authoritatively CLOSED gateway path receives a scoped local cancellation permission');
    bpCheck(!PaymentCloseScope::allowed($site,$no),'verified gateway permission does not survive the operation');
    Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>'synthetic_other_business','trade_id'=>999,'main_type'=>PayDict::MEMBER,'main_id'=>102,'out_trade_no'=>'BYPASS_OTHER_BUSINESS','money'=>'1.00','status'=>PayDict::STATUS_WAIT]);
    bpCheck($core->payClose($site,['out_trade_no'=>'BYPASS_OTHER_BUSINESS'])===true,'guard does not change other business payment closure');
    bpDeny(fn()=>(new CooperationPayCloseGuard())->handle(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'out_trade_no'=>$no,'trusted'=>true]),'forged event parameters cannot manufacture a PHP stack capability');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'random localhost schema, actual core close/returnTo/checkOrCreate and HTTP guard, provider double and no real payment gateway'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
