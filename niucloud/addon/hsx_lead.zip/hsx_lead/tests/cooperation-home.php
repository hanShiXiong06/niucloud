<?php
declare(strict_types=1);
$plugin=dirname(__DIR__);$checks=0;
function homeCheck(bool $ok,string $label):void {if (!$ok) throw new RuntimeException($label);$GLOBALS['checks']++;}
$templates=require $plugin.'/app/dict/diy/template.php';$pages=require $plugin.'/app/dict/diy/pages.php';$components=require $plugin.'/app/dict/diy/components.php';
$template=$templates['DIY_HSX_LEAD_INDEX'];$page=$pages['DIY_HSX_LEAD_INDEX']['hsx_lead_index'];$component=$components['HSX_LEAD_COMPONENT']['list']['LeadCooperationEntry'];
homeCheck($template['action']==='decorate'&&$page['mode']==='diy','homepage registered with native DIY dictionary');
homeCheck($template['page']==='/addon/hsx_lead/pages/index','homepage has real route');
homeCheck(array_column($page['data']['value'],'componentName')===['LeadCooperationHero','LeadRoleEntry','LeadRoleEntry','LeadBusinessNavigation'],'default blueprint has independent hero, both role cards and business navigation');
homeCheck($page['data']['value'][1]['role']==='stores'&&$page['data']['value'][2]['role']==='customers','two independent cards carry distinct fixed role destinations');
homeCheck($page['data']['value'][1]['buttonStyle']==='solid'&&$page['data']['value'][2]['buttonStyle']==='link','blue-white blueprint has independent solid and link CTAs');
homeCheck($components['HSX_LEAD_COMPONENT']['list']['LeadRoleEntry']['uses']===0,'single-card component allows multiple independently configured instances');
homeCheck($pages['DIY_HSX_LEAD_INDEX']['hsx_lead_combined']['data']['value'][0]['componentName']==='LeadCooperationEntry','saved combination remains an optional editable template');
foreach($page['data']['value'] as $block){homeCheck(is_file($plugin.'/admin/views/diy/components/'.$block['path'].'.vue'),'each independent block has a native framework editor');}
homeCheck($page['data']['global']['bottomTabBar']['designNav']['key']==='hsx_lead','native framework tabbar owns homepage navigation');
homeCheck($page['data']['global']['topStatusBar']['control']===true,'framework custom header stays configurable');
homeCheck($component['value']['storeTitle']==='找门店'&&$component['value']['customerTitle']==='找客户','tasks use user-facing names');
homeCheck(is_file($plugin.'/admin/views/diy/components/'.$component['path'].'.vue'),'native decorator edit component exists');
$source=file_get_contents($plugin.'/uni-app/pages/index.vue');homeCheck(str_contains($source,'useDiy')&&str_contains($source,'@/addon/components/diy/group/index.vue'),'real framework hook and group renderer reused');
homeCheck(!str_contains($source,'localStorage')&&!str_contains($source,'mock'),'homepage not a prototype data store');
$entry=file_get_contents($plugin.'/uni-app/components/diy/lead-cooperation-entry/index.vue');
homeCheck((bool)preg_match('/store\.mode\s*===\s*[\'"]decorate[\'"]\s*\)\s*return/',$entry),'decorator preview cannot trigger business writes');
$card=file_get_contents($plugin.'/uni-app/components/cooperation/CoopRoleEntryCard.vue');
homeCheck(str_contains($card,'prefers-reduced-motion'),'shared role-card decorative motion respects reduced motion');
homeCheck(str_contains($entry,'CoopRoleEntryCard')&&str_contains($entry,'cooperationRoleAppearance'),'combination reuses the same single-card renderer and projection');
homeCheck(!str_contains($entry,'reLaunch'),'ordinary homepage entry links do not destroy route history');
echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'real plugin DIY dictionaries and sources; no site writes'],JSON_UNESCAPED_UNICODE).PHP_EOL;
