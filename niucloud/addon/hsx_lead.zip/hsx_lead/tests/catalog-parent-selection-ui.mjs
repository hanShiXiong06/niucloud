import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Actual picker setup with synthetic leaf rows. No browser, network, storage,
// ERP account, catalog import, database or business form is accessed.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const file=path.join(plugin,'uni-app/components/cooperation/ModelCatalogPicker.vue'),source=fs.readFileSync(file,'utf8'),parsed=compiler.parse(source,{filename:file}),script=compiler.compileScript(parsed.descriptor,{id:'catalog-parent-selection'})
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const equal=(actual,expected,label)=>{assert.deepEqual(JSON.parse(JSON.stringify(actual)),JSON.parse(JSON.stringify(expected)),label);checks++}
const data=[
    {id:'a1',title:'iPhone 15',category_name:'手机',brand:'苹果'},
    {id:'a2',title:'iPhone 16',category_name:'手机',brand:'苹果'},
    {id:'s1',title:'Galaxy S24',category_name:'手机',brand:'三星'},
    {id:'s2',title:'Galaxy S25',category_name:'手机',brand:'三星'},
    {id:'i1',title:'iPad Air',category_name:'平板电脑',brand:'苹果'},
    {id:'i2',title:'iPad Pro',category_name:'平板电脑',brand:'苹果'},
    {id:'w1',title:'Apple Watch',category_name:'手表',brand:'苹果'},
]
const utility=loadMobileUtility('catalog-selection'),cleanup=[]
function fixture(options={}){
    const props=Vue.reactive({show:true,page:true,modelValue:[],title:'任意显示名称',max:0,businessType:'purchase',selectionMode:'multiple',initialView:'browse',bulkActions:false,...options}),events=[],module={exports:{}}
    const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    const deps={vue:{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)},'../../utils/mobile-ui':loadMobileUtility('mobile-ui'),'../../utils/catalog-selection':utility,'../../utils/interaction-feedback':{interactionFeedback(){}},'../../api/cooperation':{cooperationCatalog:async()=>({data}),coopError:(cause,fallback)=>cause?.message||fallback}}
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,JSON,Set,Map,Object})(key=>key.endsWith('.vue')?{default:{}}:key in deps?deps[key]:(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports)
    return{props,events,state:module.exports.default.setup(props,{emit:(...args)=>events.push(args),expose(){}})}
}
const flush=async()=>{for(let n=0;n<6;n++){await Promise.resolve();await Vue.nextTick()}}
const ids=state=>state.chosen.value.map(item=>item.id).sort()
check(parsed.errors.length===0&&compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'catalog-parent-selection',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length===0,'category checkbox template compiles')
const f=fixture({modelValue:[{id:'saved',title:'已有额外选项',category_name:'未归类',brand:'其他'}]}),s=f.state;await flush()
check(!s.allowBulk.value,'customer purpose still does not expose the page-wide batch bar')
equal(s.categorySelectionState('手机'),{checked:false,indeterminate:false,count:0,total:4},'unselected first-level category has a real descendant count')
s.toggle(s.rows.value.find(item=>item.id==='a1'))
check(s.categorySelectionState('手机').indeterminate&&s.brandSelectionState('苹果').indeterminate,'one selected leaf makes both containing levels partial')
s.activeBrand.value='三星';const focusedCategory=s.activeCategory.value
s.toggleBrand('苹果');equal(ids(s),['a1','a2','saved'],'second-level check selects only this category plus brand')
check(s.activeCategory.value===focusedCategory&&s.activeBrand.value==='三星'&&!f.events.length,'checking another branch does not navigate or confirm')
check(s.brandSelectionState('苹果').checked&&s.categorySelectionState('手机').indeterminate,'full brand does not imply its whole first-level category is full')
s.toggleBrand('苹果');equal(ids(s),['saved'],'checking a fully selected brand removes only its descendants')
s.toggleCategory('平板电脑');equal(ids(s),['i1','i2','saved'],'checking a first-level category does not select the same brand in other categories')
check(s.activeCategory.value===focusedCategory&&s.activeBrand.value==='三星','first-level checkbox preserves the current browsing focus')
s.toggleBrand('苹果');equal(ids(s),['a1','a2','i1','i2','saved'],'duplicate brand names are scoped to their parent category')
s.toggleCategory('手机');equal(ids(s),['a1','a2','i1','i2','s1','s2','saved'],'partial category check adds missing descendants without replacing other selections')
check(s.categorySelectionState('手机').checked&&!s.categorySelectionState('手表').checked,'full and unselected category indicators remain independent')
s.toggleCategory('手机');equal(ids(s),['i1','i2','saved'],'full category check clears only that category')
check(s.categorySelectionState('平板电脑').checked,'clearing one category retains another full category')
s.toggle(s.rows.value.find(item=>item.id==='i1'));check(s.categorySelectionState('平板电脑').indeterminate,'leaf removal recomputes the category half-selection state')
s.toggleCategory('平板电脑');check(s.categorySelectionState('平板电脑').checked,'checking a half-selected category fills its missing descendants')
const before=ids(s);s.toggleCategory('');s.toggleCategory('不存在');s.toggleBrand('不存在');equal(ids(s),before,'invalid or empty category cannot silently become a global all-select')
check(!f.events.length,'category interactions never emit form data before confirmation')
s.cancel();equal(f.events,[['close']],'cancelling does not return a changed selection')
equal(f.props.modelValue.map(item=>item.id),['saved'],'the parent form input remains untouched before confirmation')
const limited=fixture({max:3,modelValue:[data[0],data[6]]});await flush();const l=limited.state,previous=ids(l)
l.toggleCategory('手机');equal(ids(l),previous,'a first-level batch exceeding max is atomically rejected')
check(l.selectionError.value.includes('3 项')&&l.selectionError.value.includes('未更改'),'over-limit rejection explicitly reports the cap and preserved selection')
l.toggleBrand('苹果');equal(ids(l),['a1','a2','w1'],'a fitting second-level batch is accepted up to max')
l.toggleCategory('平板电脑');equal(ids(l),['a1','a2','w1'],'a second category cannot truncate or overwrite selections to fit')
l.toggleBrand('苹果');equal(ids(l),['w1'],'batch removal remains available after reaching max')
l.confirm();check(limited.events[0][0]==='update:modelValue'&&limited.events[0][1][0].id==='w1'&&limited.events[1][0]==='close','only explicit confirmation returns the updated leaf selection')
const single=fixture({selectionMode:'single',bulkActions:true});await flush();single.state.toggleCategory('手机');single.state.toggleBrand('苹果');check(!single.state.chosen.value.length&&!single.events.length,'single mode ignores category batch handlers')
single.state.toggle(single.state.rows.value[0]);single.state.toggle(single.state.rows.value[1]);equal(ids(single.state),['a2'],'single-leaf replacement is unchanged')
check((source.match(/v-if="selectionMode === 'multiple'" class="catalog-parent-check"/g)||[]).length===3,'classification checkboxes are rendered only in multiple-selection mode')
check(source.includes('@tap.stop="toggleCategory(item.key)"')&&source.includes('@tap.stop="toggleBrand(item.key)"'),'checkbox gestures stop before the surrounding navigation handler')
check(source.includes('const categorySelections = computed')&&source.includes('const brandSelections = computed'),'group states are cached instead of re-normalizing all leaves on every template field')
check(source.includes('min-width:32px; min-height:44px')&&source.includes('width:122px; flex-basis:122px')&&source.includes('width:112px; flex-basis:112px'),'independent checkbox hit areas do not squeeze the narrow secondary labels to one-character lines')
for(const style of parsed.descriptor.styles)check(compiler.compileStyle({source:style.content,filename:file,id:'catalog-parent-selection',preprocessLang:style.lang,scoped:true}).errors.length===0,'new classification controls retain valid scoped styles')
for(const stop of cleanup)stop()
console.log(`PASS ${checks} parent-category selection checks; actual Vue setup, pure range selection and synthetic catalog only.`)
