<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true)) exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $function) if(function_exists($function)) exit("Disable external network functions before testing\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';

use addon\hsx_lead\app\service\CatalogConfigStorage as Storage;
use core\exception\CommonException;
use think\facade\Db;

$pdo=null;$schema='';$failed=false;$checks=0;
function lockScopeCheck(bool $condition,string $label):void {if(!$condition)throw new RuntimeException($label);$GLOBALS['checks']++;}
try {
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $other=$site+1;$key='HSX_LEAD_DEMAND_CATALOG';
    $orm=Db::connect()->getPdo();
    if(!$orm instanceof PDO)throw new RuntimeException('Missing owned ORM PDO');
    $orm->exec('SET SESSION innodb_lock_wait_timeout=1');$pdo->exec('SET SESSION innodb_lock_wait_timeout=1');
    $indexes=$pdo->query('SHOW INDEX FROM `lt_sys_config`')->fetchAll(PDO::FETCH_ASSOC);
    lockScopeCheck(count($indexes)===1&&$indexes[0]['Key_name']==='PRIMARY','fixture has no secondary site/config index');
    $data=static fn(string $label,int $count=600):array=>['items'=>array_map(static fn(int $i):array=>['id'=>(string)$i,'title'=>$label.'设备型号'.$i,'path'=>['测试品牌','交付系列',$label.'设备型号'.$i]],range(1,$count))];
    $write=static function(int $tenant,array $value)use($key):void{Db::transaction(static function()use($tenant,$value,$key):void{Db::name('site')->where('site_id',$tenant)->lock(true)->find();Storage::write($tenant,$key,$value);});};
    $write($site,['items'=>[['id'=>'one','title'=>'A inline']]]);$write($other,['items'=>[['id'=>'two','title'=>'B inline']]]);
    $id=static function(int $tenant)use($pdo,$key):int{$s=$pdo->prepare('SELECT id FROM `lt_sys_config` WHERE site_id=? AND config_key=?');$s->execute([$tenant,$key]);return(int)$s->fetchColumn();};
    $aId=$id($site);$bId=$id($other);
    foreach([false,true]as$exclusive){
        Db::startTrans();
        lockScopeCheck(Storage::read($site,$key,$exclusive)['items'][0]['title']==='A inline','A inline read holds intended outer transaction lock');
        $pdo->beginTransaction();$s=$pdo->prepare('UPDATE `lt_sys_config` SET update_time=update_time+1 WHERE id=?');$s->execute([$bId]);$pdo->commit();
        lockScopeCheck($s->rowCount()===1,'B inline update is not blocked by A '.($exclusive?'exclusive':'shared').' catalog read');
        Db::commit();
    }

    $write($site,$data('A'));$write($other,$data('B'));
    $manifest=static function(int $tenant)use($pdo,$key):array{$s=$pdo->prepare('SELECT value FROM `lt_sys_config` WHERE site_id=? AND config_key=?');$s->execute([$tenant,$key]);return json_decode((string)$s->fetchColumn(),true,512,JSON_THROW_ON_ERROR);};
    $aManifest=$manifest($site);$bManifest=$manifest($other);
    lockScopeCheck(count($aManifest['row_ids'])===$aManifest['parts']&&$aManifest['parts']>1,'manifest persists exact primary IDs for every fragment');
    foreach([false,true]as$exclusive){
        Db::startTrans();$read=Storage::read($site,$key,$exclusive);
        lockScopeCheck($read===$data('A'),'A chunked read is complete while its outer transaction stays active');
        $pdo->beginTransaction();$s=$pdo->prepare('UPDATE `lt_sys_config` SET update_time=update_time+1 WHERE id=?');$s->execute([$bManifest['row_ids'][0]]);$pdo->commit();
        lockScopeCheck($s->rowCount()===1,'B fragment update is not blocked by A '.($exclusive?'exclusive':'shared').' fragment read');
        Db::commit();
    }

    // Even old-generation cleanup must not scan-lock another site's rows.
    $pdo->beginTransaction();$s=$pdo->prepare('SELECT id FROM `lt_sys_config` WHERE id=? FOR UPDATE');$s->execute([$bManifest['row_ids'][0]]);$s->fetchColumn();
    $write($site,$data('A replacement'));
    lockScopeCheck(Storage::read($site,$key)===$data('A replacement'),'A replacement and obsolete-fragment deletion do not wait for B lock');
    $pdo->rollBack();
    lockScopeCheck(Storage::read($other,$key)===$data('B'),'cross-site lock tests leave B directory intact');

    // Create a new generation on PDO 2 after the ORM's RR snapshot is old.
    // The immutable base ID remains visible, but all new fragment IDs are not.
    $external=static function(int $tenant,array $value)use($pdo,$key,$aId):void{
        $json=json_encode($value,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRESERVE_ZERO_FRACTION|JSON_THROW_ON_ERROR);
        $gen=bin2hex(random_bytes(8));$count=(int)ceil(strlen($json)/Storage::PART_BYTES);$ids=[];
        $pdo->beginTransaction();$lock=$pdo->prepare('SELECT site_id FROM `lt_site` WHERE site_id=? FOR UPDATE');$lock->execute([$tenant]);$lock->fetchColumn();
        $insert=$pdo->prepare('INSERT INTO `lt_sys_config` (site_id,config_key,value) VALUES (?,?,?)');
        for($i=0;$i<$count;$i++){
            $part=[Storage::MARKER=>Storage::PART_VERSION,'base_key'=>$key,'generation'=>$gen,'index'=>$i,'data'=>base64_encode(substr($json,$i*Storage::PART_BYTES,Storage::PART_BYTES))];
            $partKey='HSX_LEAD_CFG_'.substr(hash('sha256',$key),0,32).'_'.$gen.'_'.str_pad((string)$i,4,'0',STR_PAD_LEFT);
            $insert->execute([$tenant,$partKey,json_encode($part,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR)]);$ids[]=(int)$pdo->lastInsertId();
        }
        $m=[Storage::MARKER=>Storage::MANIFEST_VERSION,'generation'=>$gen,'parts'=>$count,'bytes'=>strlen($json),'sha256'=>hash('sha256',$json),'row_ids'=>$ids];
        $update=$pdo->prepare('UPDATE `lt_sys_config` SET value=? WHERE id=? AND site_id=?');$update->execute([json_encode($m,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR),$aId,$tenant]);$pdo->commit();
    };
    Db::startTrans();
    $oldSnapshot=Db::name('sys_config')->where('site_id',$site)->where('config_key',$key)->value('value');
    lockScopeCheck(is_string($oldSnapshot),'outer transaction establishes an old consistent-read snapshot');
    $external($site,$data('A newly committed'));
    lockScopeCheck(Storage::read($site,$key,true)===$data('A newly committed'),'locking read follows current manifest row IDs despite an old RR snapshot');
    Db::commit();
    try{Storage::read($site,'HSX_LEAD_COOPERATION',true);throw new RuntimeException('Expected missing locking read refusal');}
    catch(CommonException $error){lockScopeCheck(str_contains($error->getMessage(),'默认收费规则'),'missing locking read refuses defaults explicitly');}
    lockScopeCheck(Storage::read($site,'HSX_LEAD_COOPERATION')===[],'ordinary unconfigured directory read can remain empty');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'two PDO connections; official no-secondary-index schema; PK-scoped catalog locks and stale RR snapshot','remote_calls'=>0],JSON_UNESCAPED_UNICODE),PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL catalog lock scope: '.$error->getMessage().' at '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{
    try{if(\think\facade\Db::connect()->getPdo() instanceof PDO&&\think\facade\Db::connect()->getPdo()->inTransaction())\think\facade\Db::rollback();}catch(Throwable$ignored){}
    if($pdo instanceof PDO&&$pdo->inTransaction())$pdo->rollBack();
    if($pdo instanceof PDO&&$schema!=='')try{leadCleanup($pdo,$schema);}catch(Throwable$error){$failed=true;fwrite(STDERR,"FAIL owned schema cleanup\n");}
}
exit($failed?1:0);
