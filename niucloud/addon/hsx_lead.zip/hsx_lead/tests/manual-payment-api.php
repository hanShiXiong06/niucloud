<?php
declare(strict_types=1);
error_reporting(E_ALL&~E_DEPRECATED);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\adminapi\controller\Cooperation;
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityMembershipService,PartnerService,PaymentOrderLifecycle,PaymentRefundService,PaymentService,Store};
use addon\hsx_lead\app\support\Data;
use addon\hsx_lead\app\listener\pay\{CooperationPayCreate,CooperationPaySuccess,MembershipRefundSuccess,CooperationOrderRefundSuccess,PromotionRefundSuccess};
use core\exception\CommonException;
use app\dict\pay\PayDict;
use app\service\core\pay\CorePayService;
use think\facade\{Db,Event};
$checks=0;$pdo=null;$schema='';
function maCheck(bool $ok,string $message):void {if(!$ok)throw new RuntimeException($message);$GLOBALS['checks']++;}
function maDeny(callable $call,string $message):void {try{$call();}catch(CommonException$error){maCheck(true,$message);return;}throw new RuntimeException('Not denied: '.$message);}
try{
 [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
 $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund','pay_channel']as$table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$matches);$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$matches[0]));}
 $app->config->set(['default'=>'balancepay','drivers'=>['balancepay'=>['driver'=>app\service\core\paytype\CoreBalanceService::class]]],'pay');$app->bind('think\\route\\Url',think\app\Url::class);
 Db::name('pay_channel')->insert(['site_id'=>$site,'type'=>PayDict::BALANCEPAY,'channel'=>'h5','status'=>1,'config'=>'[]']);
 $admin=new Context($site,1);$owner=new Context($site,0,101);$settings=new ConfigService($admin);$config=$settings->get();$config['enabled']=true;$config['publishing_required']=false;$config['fee_confirmed']=true;$settings->save($config);
 $profile=(new PartnerService($owner))->saveProfile(['name'=>'Synthetic API receipt shop','contact_name'=>'Synthetic API owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Local synthetic fixture']);
 Event::listen('PayCreate',CooperationPayCreate::class);Event::listen('PaySuccess',CooperationPaySuccess::class);foreach([MembershipRefundSuccess::class,CooperationOrderRefundSuccess::class,PromotionRefundSuccess::class]as$listener)Event::listen('RefundSuccess',$listener);
 $quote=(new EntityMembershipService($owner))->quote('ML701','month');$order=(new PaymentService($owner))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'month','request_id'=>'api-manual-membership','quote_token'=>$quote['quote_token']]);$id=(int)$order['id'];
 $request=static function(string $method,array $input=[],int $uid=1,?int $identitySite=null)use($app,$site,$id):Cooperation{
  $auth=new ReflectionProperty(\app\Request::class,'auth_info');$auth->setAccessible(true);$auth->setValue(null,[]);
  $request=new \app\Request();$request->siteId($identitySite??$site);$request->uid($uid);$request->appType('site');$request->withServer(['REQUEST_METHOD'=>$method]);$request->withRoute(['id'=>$id]);
  if($method==='POST')$request->withHeader(['content-type'=>'application/json'])->withInput(Data::json($input));else$request->withGet($input);
  $app->instance('request',$request);return new Cooperation($app);
 };
 $response=$request('GET')->manualReceiptPreview($id);$preview=$response->getData()['data'];
 maCheck($response->getHeader('Cache-Control')==='private, no-store'&&$preview['default_amount']==='99.00'&&$preview['order_amount']===$order['amount']&&$preview['can_confirm'],'real GET controller distinguishes the 99-yuan input suggestion from the authoritative order amount');
 maCheck(Db::name('hsx_lead_manual_receipt')->count()===0&&Db::name('pay')->count()===0,'preview controller makes no payment or receipt');
 maDeny(fn()=>$request('GET',['site_id'=>$site+1])->manualReceiptPreview($id),'preview refuses injected tenant selector');
 maDeny(fn()=>$request('GET',[],0)->manualReceiptPreview($id),'guest cannot call financial preview');
 $data=['request_id'=>'api-manual-confirm-once','amount'=>$order['amount'],'confirm'=>true,'expected_fingerprint'=>$preview['source_fingerprint']];
 maDeny(fn()=>$request('POST',$data+['member_id'=>102])->confirmManualReceipt($id),'POST rejects injected payer identity before recording money');
 maCheck(Db::name('hsx_lead_manual_receipt')->count()===0,'invalid POST left no receipt');
 maDeny(fn()=>$request('POST',array_replace($data,['amount'=>'99.00']))->confirmManualReceipt($id),'the suggested amount cannot settle an order for another amount');
 maCheck(Db::name('hsx_lead_manual_receipt')->count()===0&&Db::name('member_account_log')->count()===0&&Db::name('pay')->count()===0,'amount mismatch leaves receipt, recharge, debit and cashier absent');
 $response=$request('POST',$data)->confirmManualReceipt($id);$receipt=$response->getData()['data'];
 maCheck($response->getHeader('Cache-Control')==='private, no-store'&&$receipt['status']==='posted'&&$receipt['order']['status']==='paid','one compact controller action completes real recharge, balance payment and benefit grant');
 maCheck(Db::name('pay')->where('out_trade_no',$receipt['out_trade_no'])->value('type')===PayDict::BALANCEPAY&&Db::name('member_account_log')->where('account_type','balance')->count()===2&&Db::name('member')->where('member_id',101)->value('balance')==='0.00','core records balancepay and exactly two offsetting wallet entries');
 maCheck(EntityMembershipService::state($site,(int)$profile['id'])['active'],'controller outcome agrees with persisted subject membership');
 maCheck($request('POST',$data)->confirmManualReceipt($id)->getData()['data']['id']===$receipt['id']&&Db::name('hsx_lead_manual_receipt')->where('kind','payment')->count()===1,'repeated HTTP payload returns the same receipt');
 $read=$request('GET')->manualReceipt((int)$receipt['id']);maCheck($read->getHeader('Cache-Control')==='private, no-store'&&$read->getData()['data']['id']===$receipt['id'],'real receipt detail action is private/no-store');
 $retry=$request('POST')->retryManualReceipt((int)$receipt['id']);maCheck($retry->getHeader('Cache-Control')==='private, no-store'&&$retry->getData()['data']['status']==='posted','real retry action is idempotent and non-cacheable');
 $before=Db::name('hsx_lead_manual_receipt')->count();
 maDeny(fn()=>$request('POST',$data,1,$site+1)->confirmManualReceipt($id),'actual authenticated other site cannot confirm original order');
 maCheck(Db::name('hsx_lead_manual_receipt')->count()===$before,'cross-site controller call did not create evidence');
 $refund=(new PaymentRefundService($owner))->apply($id,['request_id'=>'api-refund-request','reason'=>'本地核对完整退款再购','confirm'=>true]);$approved=(new PaymentRefundService($admin))->review($id,['decision'=>'approve','request_version'=>$refund['request_version'],'reason'=>'本地核对实际退款流程']);
 maCheck(!$approved['manual_refund_required']&&$approved['status']==='refunded','balance payment refund uses the real wallet path, not manual external-transfer confirmation');
 maCheck(Db::name('member')->where('member_id',101)->value('balance')===$order['amount']&&!EntityMembershipService::state($site,(int)$profile['id'])['active'],'completed refund restores the exact amount to balance and revokes old paid rights');
 $next=(new EntityMembershipService($owner))->quote('ML701','month');maCheck($next['can_purchase']&&!empty($next['quote_token']),'completed controller refund permits a genuinely new membership quote');
 $rebuy=(new PaymentService($owner))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'month','request_id'=>'api-rebuy-from-refund','quote_token'=>$next['quote_token']]);
 Db::transaction(fn()=>(new CorePayService())->pay($site,PaymentService::TRADE_TYPE,(int)$rebuy['id'],PayDict::BALANCEPAY,'h5',''));
 maCheck(Db::name('member')->where('member_id',101)->value('balance')==='0.00'&&EntityMembershipService::state($site,(int)$profile['id'])['active']&&Db::name('hsx_lead_manual_receipt')->count()===1,'customer reuses refunded balance without another administrator recharge');
 $closingQuote=(new EntityMembershipService($owner))->quote('ML701','month');$closed=(new PaymentService($owner))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'month','request_id'=>'api-closed-manual-denial','quote_token'=>$closingQuote['quote_token']]);
 $closedPreview=$request('GET')->manualReceiptPreview((int)$closed['id']);$closedInput=['amount'=>$closed['amount'],'request_id'=>'api-closed-receipt','confirm'=>true,'expected_fingerprint'=>$closedPreview->getData()['data']['source_fingerprint']];
 (new PaymentOrderLifecycle($admin))->close((int)$closed['id'],['confirm'=>true,'reason'=>'本地闭单不得收款验证'],true);
 $snapshot=static function():array{$result=[];foreach(['member','member_account_log','pay','hsx_lead_coop_order','hsx_lead_manual_receipt','hsx_lead_audit']as$table)$result[$table]=Db::name($table)->order($table==='member'?'member_id':'id')->select()->toArray();return$result;};$beforeClosed=$snapshot();
 maCheck(!$request('GET')->manualReceiptPreview((int)$closed['id'])->getData()['data']['can_confirm'],'actual controller preview makes a closed order read-only');
 maDeny(fn()=>$request('POST',$closedInput)->confirmManualReceipt((int)$closed['id']),'actual POST cannot settle, fund or recreate a closed order');
 maCheck($snapshot()===$beforeClosed,'closed controller calls produce no receipt, wallet, payment, order or audit writes');
 $routes=file_get_contents(dirname(__DIR__).'/app/adminapi/route/cooperation.php');$menu=require dirname(__DIR__).'/app/dict/menu/site.php';$flat=[];$walk=static function($rows)use(&$walk,&$flat){foreach($rows as$row)if(is_array($row)){$flat[]=$row;if(isset($row['children']))$walk($row['children']);}};$walk($menu);
 foreach([['order_manual_receipt','post','hsx_lead/cooperation/orders/<id>/manual-receipt'],['order_manual_receipt_preview','get','hsx_lead/cooperation/orders/<id>/manual-receipt'],['order_manual_receipt_read','get','hsx_lead/cooperation/manual-receipts/<id>'],['order_manual_receipt_retry','post','hsx_lead/cooperation/manual-receipts/<id>/retry'],['order_manual_refund','post','hsx_lead/cooperation/orders/<id>/manual-refund']]as[$key,$method,$url]){
  $matched=array_values(array_filter($flat,static fn(array$r):bool=>($r['menu_key']??'')==='hsx_lead_cooperation_'.$key));maCheck(count($matched)===1&&$matched[0]['methods']===$method&&$matched[0]['api_url']===$url,'native permission definition exists for '.$key);
 }
 maCheck(str_contains($routes,'AdminCheckToken::class,AdminCheckRole::class,PermissionGate::class')&&str_contains($routes,'->completeMatch()'),'new financial routes stay in the existing token, role and strict native permission group');
 echo 'PASS '.$checks." manual payment/refund API checks; real controllers, random local schema, no real transfers.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit(!empty($failed)?1:0);
