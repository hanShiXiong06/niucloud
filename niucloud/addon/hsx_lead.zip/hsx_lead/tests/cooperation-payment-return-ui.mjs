import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual plugin Vue setup and real framework return contract, synthetic transports only.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const file = path.join(plugin, 'uni-app/components/cooperation/CooperationWorkbench.vue'), source = fs.readFileSync(file, 'utf8')
const script = compiler.compileScript(compiler.parse(source).descriptor, { id: 'payment-return' })
const js = ts.transpileModule(script.content.replaceAll('import.meta.env.VITE_SITE_ID', "'fixture'"), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const baseKey = 'hsx_lead_coop_pay:100005:7'
const cacheKey = (purpose, id = 0) => baseKey + ':' + purpose + ':' + id
const order = (id = 23, leadId = 77, status = 'unpaid', purpose = 'commission') => ({ id, merchant_id: 7, purpose, lead_id: leadId, amount: '125.00', status })
const taskLink = (task, params = {}) => '/addon/hsx_lead/pages/task/index?' + new URLSearchParams(Object.fromEntries(Object.entries({ task, ...params }).filter(([, value]) => value != null && value !== ''))).toString()
function fixture(overrides = {}, options = {}) {
    const store = options.store || new Map([['wap_site_id', 100005]]), records = options.records || new Map([[23, order()]])
    const opened = [], navigated = [], created = [], reads = [], logins = []
    let token = 'fixture-session', sequence = 0, bootstraps = 0
    const controls = {
        readOrder: async id => { if (!records.has(id)) throw Error('合成原单读取失败'); return { data: { ...records.get(id) } } },
        createOrder: async () => ({ ...records.get(23) })
    }
    const ui = {
        direction: Vue.ref('incoming'), busy: Vue.ref(false), loading: Vue.ref(false), ready: Vue.ref(false), profile: Vue.ref({ id: 7 }), config: Vue.ref({enabled:true}), tab: Vue.ref('deliveries'), error: Vue.ref(''), writeError: Vue.ref(''), detailLoading: Vue.ref(false), detail: Vue.ref({ id: 77, status: 'unpaid', payment_order_id: 23 }),
        query: Vue.reactive({ keyword: '', status: '', page: 1, limit: 20 }), rows: Vue.ref([]), total: Vue.ref(0), listError: Vue.ref(''),
        resume: () => token, pause() {}, dispose() {}, resumeInterruptedReads: async () => {},
        bootstrap: async () => { bootstraps++; ui.ready.value = true; return true },
        refresh: async () => true,
        loadDetail: async id => { const paid = [...records.values()].some(row => row.lead_id === id && row.status === 'paid' && !row.requires_manual_review); ui.detail.value = { id, status: paid ? 'paid' : 'unpaid', payment_order_id: id === 77 ? 23 : 0 }; return true },
        order: async data => { if (ui.busy.value) return null; ui.busy.value = true; created.push({ ...data }); try { return await controls.createOrder(data) } finally { ui.busy.value = false } }
    }
    const deps = {
        '../../utils/entity-membership':loadMobileUtility('entity-membership'), '../../utils/mobile-ui': loadMobileUtility('mobile-ui'),
        '../../api/promotion': { promotionOverview: async () => { throw Error('Payment return must not read marketing rules') } },
        vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} },
        '@/utils/common': { getToken: () => token },
        '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: value => logins.push(value) }) },
        '@/hooks/useSubscribeMessage': { useSubscribeMessage: () => ({ request() {} }) },
        '../../composables/useCooperation': { useCooperation: () => ui },
        '../../api/cooperation': { cooperationPageUrls: { deliveries: '/addon/hsx_lead/pages/workbench/index' }, cooperationOrder: async id => { reads.push(id); return controls.readOrder(id) }, coopError: error => error.message, coopMoney: value => String(value), coopRequestId: () => 'synthetic_' + ++sequence },
        '../../utils/cooperation-business': loadMobileUtility('cooperation-business'),
        '../../utils/cooperation-payment': loadMobileUtility('cooperation-payment'),
        '../../utils/cooperation-navigation': { cooperationTaskLink: taskLink, cooperationTaskUrl: '/addon/hsx_lead/pages/task/index', openCooperationTask: (task, params) => navigated.push({ task, params }), backCooperationTask() {} }
    }
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Map, Promise, console, uni: { getStorageSync: key => store.get(key), setStorageSync: (key, value) => store.set(key, value), removeStorageSync: key => store.delete(key), showToast() {}, showModal() {} } })(key => { if (key in deps) return deps[key]; if (key.endsWith('.vue')) return { default: {} }; throw Error('Unexpected dependency ' + key) }, module, module.exports)
    const props = { initialId: 77, initialTab: 'deliveries', initialInviter: 0, initialPromotion: false, task: 'commission', initialStoreId: 0, initialPurpose: '', initialPaymentId: 0, initialPromotionTab: 'overview', initialBusinessType: '', initialDirection: 'incoming', ...overrides }
    const state = module.exports.default.setup(props, { expose() {} }); state.payRef.value = { open: (...args) => opened.push(args) }
    return { state, ui, props, store, records, opened, navigated, created, reads, logins, controls, setToken: value => { token = value }, bootstraps: () => bootstraps }
}
const first = fixture(); await first.state.initialize(); await first.state.startOrder('commission', '125.00')
check(first.opened.at(-1)[2].includes('task=commission') && first.opened.at(-1)[2].includes('collaboration_id=77') && first.opened.at(-1)[2].includes('payment_order_id=23'), 'initial cashier return preserves task, collaboration and original payment ID')
check(first.state.cashierReturnUrl.value === first.opened.at(-1)[2] && source.includes(':reformat="cashierReturnUrl"'), 'framework success reformat and cashier open share the same route')
check(first.store.get(cacheKey('commission', 77)) === 23, 'pending commission cache is scoped by purpose and lead')
await first.state.resumePayment(); check(first.opened.at(-1)[2] === first.state.cashierReturnUrl.value, 'resuming the same verified unpaid order stays on the original lead')
const beforeResume = first.reads.length, initialBootstraps = first.bootstraps(); await first.state.initialize()
check(first.reads.length === beforeResume + 1 && first.bootstraps() === initialBootstraps, 'returning to a mounted task rechecks its pending order without resetting the list or form')
first.records.set(23, order(23, 77, 'paid')); await first.state.verifyPayment()
check(first.state.paymentCompleted.value && first.state.paymentId.value === 0 && first.state.overlay.value === 'detail', 'authoritative paid response ends the commission task on real detail')
check(first.state.cashierReturnUrl.value.includes('payment_order_id=23'), 'return ID survives clearing matching pending caches')
const confirmedCreateCount = first.created.length; await first.state.startOrder('commission', '125.00')
check(first.created.length === confirmedCreateCount, 'a completed payment cannot create another order on the same page')
const returned = fixture({ initialPaymentId: 23 }, { store: first.store, records: first.records }); await returned.state.initialize()
check(returned.state.paymentCompleted.value && returned.state.overlay.value === 'detail' && !returned.opened.length && !returned.created.length, 'a fresh native return checks the original paid order without creating or opening another payment')

const shared = new Map([['wap_site_id', 100005], [baseKey, 23], [cacheKey('commission', 77), 23]])
const otherLead = fixture({ initialId: 88 }, { store: shared }); await otherLead.state.initialize()
check(!otherLead.state.paymentId.value && !otherLead.reads.length && shared.get(cacheKey('commission', 77)) === 23, 'lead B does not install the merchant-wide pending pointer from lead A')
otherLead.controls.createOrder = async () => { const row = order(24, 88); otherLead.records.set(24, row); return row }; await otherLead.state.startOrder('commission', '125.00')
check(otherLead.opened[0][1] === 24 && otherLead.opened[0][2].includes('collaboration_id=88') && shared.get(cacheKey('commission', 77)) === 23, 'lead B creates/opens only its own payment while preserving lead A pending protection')
otherLead.records.set(24, order(24, 88, 'paid')); await otherLead.state.verifyPayment()
check(shared.get(cacheKey('commission', 77)) === 23 && !shared.has(cacheKey('commission', 88)), 'confirming B clears only B pending state, never A')
const wrongLink = fixture({ initialId: 88, initialPaymentId: 23 }, { store: shared }); await wrongLink.state.initialize(); await wrongLink.state.startOrder('commission', '125.00'); await wrongLink.state.resumePayment()
check(!!wrongLink.state.paymentContextError.value && !wrongLink.opened.length && !wrongLink.created.length && shared.get(cacheKey('commission', 77)) === 23, 'an explicit A-payment/B-lead link is blocked after server context validation without losing A protection')
const wrongPurpose=fixture({initialPaymentId:23});wrongPurpose.records.set(23,order(23,77,'unpaid','membership'));await wrongPurpose.state.initialize()
check(!!wrongPurpose.state.paymentContextError.value&&!wrongPurpose.opened.length,'a membership order cannot be restored as collaboration commission')
const wrongMerchant = fixture({ initialPaymentId: 23 }); wrongMerchant.records.set(23, { ...order(), merchant_id: 8 }); await wrongMerchant.state.initialize()
check(!!wrongMerchant.state.paymentContextError.value && !wrongMerchant.opened.length, 'a response belonging to a different merchant is never sent to the cashier')
const malformed = fixture({ initialPaymentId: 23 }); malformed.controls.readOrder = async () => ({ data: { ...order(), id: 999 } }); await malformed.state.initialize()
check(!!malformed.state.paymentContextError.value && malformed.state.paymentId.value === 23, 'mismatched response IDs retain the original candidate and block payment')

const closed = fixture({ initialPaymentId: 23 }); closed.records.set(23, order(23, 77, 'closed')); closed.store.set(cacheKey('commission', 77), 23); closed.store.set(baseKey, 23); await closed.state.initialize()
check(closed.state.paymentId.value === 0 && !closed.state.paymentCompleted.value && !closed.store.has(cacheKey('commission', 77)) && !closed.opened.length && !closed.created.length, 'a confirmed closed order unlocks the task but never automatically creates or opens a replacement')
check(closed.state.commissionLead.value.payment_order_id === 0 && closed.state.paymentMessage.value.includes('再次明确确认'), 'closed commission has editable amount and explicit user confirmation guidance')
closed.controls.createOrder = async () => { const row = order(25); closed.records.set(25, row); return row }; await closed.state.startOrder('commission', '125.00')
check(closed.created.length === 1 && closed.opened[0][1] === 25 && closed.store.get(cacheKey('commission', 77)) === 25, 'only a subsequent explicit click creates and opens the new replacement')
const repeatedClosed = fixture(); repeatedClosed.records.set(23, order(23, 77, 'closed')); await repeatedClosed.state.initialize(); await repeatedClosed.state.startOrder('commission', '125.00')
check(repeatedClosed.created.length === 1 && !repeatedClosed.opened.length && !repeatedClosed.state.paymentCompleted.value, 'if the server still returns a closed order, no cashier or false payment success is emitted')

const unknown = fixture({ initialPaymentId: 23 }); unknown.controls.readOrder = async () => { throw Error('合成超时') }; unknown.store.set(cacheKey('commission', 77), 23); await unknown.state.initialize(); await unknown.state.startOrder('commission', '125.00')
check(unknown.state.paymentId.value === 23 && unknown.store.get(cacheKey('commission', 77)) === 23 && !unknown.created.length && !unknown.opened.length, 'unknown payment outcome preserves the original ID/cache and cannot create or open a replacement')
const review = fixture({ initialPaymentId: 23 }); review.records.set(23, { ...order(23, 77, 'paid'), requires_manual_review: true }); await review.state.initialize(); await review.state.startOrder('commission', '125.00')
check(review.state.paymentId.value === 23 && !review.state.paymentCompleted.value && review.store.get(cacheKey('commission', 77)) === 23 && !review.created.length && !review.opened.length, 'paid-but-needs-review preserves its pending protection and never appears eligible for a replacement payment')
const unfamiliar = fixture({ initialPaymentId: 23 }); unfamiliar.records.set(23, order(23, 77, 'processing')); await unfamiliar.state.initialize(); await unfamiliar.state.startOrder('commission', '125.00')
check(unfamiliar.state.paymentId.value === 23 && !unfamiliar.created.length && !unfamiliar.opened.length, 'an unknown status cannot be treated as unpaid or closed')

const singleFlight = fixture({ initialPaymentId: 23 }); await singleFlight.state.initialize()
let release; singleFlight.controls.readOrder = () => new Promise(resolve => { release = resolve })
const readCount = singleFlight.reads.length, resumeOne = singleFlight.state.resumePayment(), resumeTwo = singleFlight.state.resumePayment()
check(singleFlight.reads.length === readCount + 1, 'repeated resume clicks share one in-flight authoritative check')
release({ data: order() }); await Promise.all([resumeOne, resumeTwo])
check(singleFlight.opened.length === 1, 'a single resume flow opens the cashier at most once')
const main = fixture({ task: '', initialId: 0 }); main.store.set(baseKey, 23); await main.state.initialize(); await main.state.resumePayment()
check(!main.opened.length && main.navigated[0].task === 'commission' && main.navigated[0].params.collaboration_id === 77 && main.navigated[0].params.payment_order_id === 23, 'a main-tab reminder routes to the verified original payment task rather than paying under generic page context')
const loggedOut = fixture({ initialPaymentId: 23 }); loggedOut.setToken(''); await loggedOut.state.initialize()
check(loggedOut.logins[0].param.payment_order_id === 23, 'login return preserves the original payment ID')
const failedAction = fixture(); await failedAction.state.initialize(); failedAction.ui.writeError.value = '合成接单结果待核实'
await failedAction.state.reloadDetail()
check(!failedAction.ui.writeError.value && failedAction.ui.detail.value.id === 77 && !failedAction.created.length, 'detail retry clears the old write error and performs only a fresh read, never replaying an action or payment')
const interruptedPage = fixture({ task: 'detail' }); let finishOldDetail
interruptedPage.ui.loadDetail = () => new Promise(resolve => { finishOldDetail = resolve })
const obsoleteInitialize = interruptedPage.state.initialize()
for (let step = 0; step < 5 && !finishOldDetail; step++) await Promise.resolve()
interruptedPage.state.pausePage()
interruptedPage.ui.resumeInterruptedReads = async () => { interruptedPage.ui.detail.value = { id: 77, status: 'following' } }
await interruptedPage.state.initialize()
check(interruptedPage.state.overlay.value === 'detail' && interruptedPage.ui.detail.value.id === 77, 'recovery mounts the detail task even when backgrounding interrupted its very first initialization')
finishOldDetail(false); await obsoleteInitialize
check(interruptedPage.state.overlay.value === 'detail', 'an obsolete initialization cannot overwrite the resumed task')

const nativePay = fs.readFileSync(path.resolve(plugin, '../../../uni-app/src/components/pay/pay.vue'), 'utf8')
check(nativePay.includes('url: prop.reformat'), 'checks cover the real framework success-path contract, not only the open payReturn argument')
console.log(`PASS ${checks} payment return/isolation/retry checks; actual plugin Vue setup and framework source contract, synthetic transports only, no browser or business mutations.`)
