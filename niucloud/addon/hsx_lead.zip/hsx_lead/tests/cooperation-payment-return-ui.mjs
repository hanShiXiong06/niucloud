import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'

// Actual plugin Vue setup and real framework return contract, synthetic transports only.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const file = path.join(plugin, 'uni-app/components/cooperation/CooperationWorkbench.vue'), source = fs.readFileSync(file, 'utf8')
const script = compiler.compileScript(compiler.parse(source).descriptor, { id: 'payment-return' })
const js = ts.transpileModule(viteFixture(script.content), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const baseKey = 'hsx_lead_coop_pay:100005:101:7'
const cacheKey = (purpose, id = 0) => baseKey + ':' + purpose + ':' + id
const order = (id = 23, leadId = 77, status = 'unpaid', purpose = 'commission') => ({ id, member_id: 101, merchant_id: 7, purpose, lead_id: leadId, amount: '125.00', fee_amount: '12.50', net_amount: '112.50', status, can_pay: status === 'unpaid' })
const taskLink = (task, params = {}) => '/addon/hsx_lead/pages/task/index?' + new URLSearchParams(Object.fromEntries(Object.entries({ task, ...params }).filter(([, value]) => value != null && value !== ''))).toString()
function fixture(overrides = {}, options = {}) {
    const store = options.store || new Map([['wap_site_id', 100005]]), records = options.records || new Map([[23, order()]])
    const opened = [], navigated = [], created = [], reads = [], logins = []
    let token = 'fixture-session', site = options.site ?? '100005', sequence = 0, bootstraps = 0
    const controls = {
        readOrder: async id => { if (!records.has(id)) throw Error('合成原单读取失败'); return { data: { ...records.get(id) } } },
        createOrder: async () => ({ ...records.get(23) })
    }
    const ui = {
        direction: Vue.ref('incoming'), busy: Vue.ref(false), loading: Vue.ref(false), ready: Vue.ref(false), profile: Vue.ref({ id: 7 }), memberId: Vue.ref(options.memberId ?? 101), siteId: () => site, sessionScope: () => token ? site + ':' + token : '', config: Vue.ref({enabled:true}), tab: Vue.ref('deliveries'), error: Vue.ref(''), writeError: Vue.ref(''), detailLoading: Vue.ref(false), detail: Vue.ref({ id: 77, status: 'unpaid', payment_order_id: 23 }),
        query: Vue.reactive({ keyword: '', status: '', page: 1, limit: 20 }), rows: Vue.ref([]), total: Vue.ref(0), listError: Vue.ref(''),
        resume: () => ui.sessionScope(), pause() {}, dispose() {}, resumeInterruptedReads: async () => {},
        bootstrap: async () => { bootstraps++; ui.ready.value = true; return true },
        refresh: async () => true,
        loadDetail: async id => { const candidates = [...records.values()].filter(row => row.lead_id === id), paid = candidates.some(row => row.status === 'paid' && !row.requires_manual_review), latest = candidates.at(-1); ui.detail.value = { id, status: paid ? 'paid' : 'unpaid', payment_order_id: latest?.id || 0 }; return true },
        order: async data => { if (ui.busy.value) return null; ui.busy.value = true; created.push({ ...data }); try { return await controls.createOrder(data) } finally { ui.busy.value = false } }
    }
    const deps = {
        '../../utils/entity-membership':loadMobileUtility('entity-membership'), '../../utils/mobile-ui': loadMobileUtility('mobile-ui'),
        '../../api/promotion': { promotionOverview: async () => { throw Error('Payment return must not read marketing rules') } },
        vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} },
        '@/utils/common': { getToken: () => token },
        '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: value => logins.push(value) }) },
        '../../composables/useCooperationSubscribe': { useCooperationSubscribe:()=>({loading:Vue.ref(false), prepare: async () => false, request() {} }) },
        '../../composables/useCooperation': { useCooperation: () => ui },
        '../../api/cooperation': { cooperationPageUrls: { deliveries: '/addon/hsx_lead/pages/workbench/index' }, cooperationOrder: async id => { reads.push(id); return controls.readOrder(id) }, coopError: error => error.message, coopMoney: value => String(value), coopRequestId: () => 'synthetic_' + ++sequence },
        '../../utils/cooperation-business': loadMobileUtility('cooperation-business'),
        '../../utils/cooperation-payment': loadMobileUtility('cooperation-payment'),
        '../../utils/cooperation-payment-orders': loadMobileUtility('cooperation-payment-orders'),
        '../../utils/cooperation-navigation': { cooperationTaskLink: taskLink, cooperationTaskUrl: '/addon/hsx_lead/pages/task/index', openCooperationTask: (task, params) => navigated.push({ task, params }), backCooperationTask() {} }
    }
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Map, Promise, console, uni: { getStorageSync: key => store.get(key), setStorageSync: (key, value) => store.set(key, value), removeStorageSync: key => store.delete(key), showToast() {}, showModal() {} } })(key => { if (key in deps) return deps[key]; if (key.endsWith('.vue')) return { default: {} }; throw Error('Unexpected dependency ' + key) }, module, module.exports)
    const props = { initialId: 77, initialTab: 'deliveries', initialInviter: 0, initialPromotion: false, task: 'commission', initialStoreId: 0, initialPurpose: '', initialPaymentId: 0, initialPromotionTab: 'overview', initialBusinessType: '', initialDirection: 'incoming', ...overrides }
    const state = module.exports.default.setup(props, { expose() {} }); state.payRef.value = { open: (...args) => opened.push(args) }
    return { state, ui, props, store, records, opened, navigated, created, reads, logins, controls, setToken: value => { token = value }, setSite: value => { site = value }, bootstraps: () => bootstraps }
}
const first = fixture(); await first.state.initialize(); await first.state.startOrder('commission', '125.00')
check(first.opened.at(-1)[2].includes('task=commission') && first.opened.at(-1)[2].includes('collaboration_id=77') && first.opened.at(-1)[2].includes('payment_order_id=23'), 'initial cashier return preserves task, collaboration and original payment ID')
check(first.state.cashierReturnUrl.value === first.opened.at(-1)[2] && source.includes(':reformat="cashierReturnUrl"'), 'framework success reformat and cashier open share the same route')
check(first.store.get(cacheKey('commission', 77)) === 23, 'pending commission cache is scoped by purpose and lead')
await first.state.resumePayment(); check(first.opened.at(-1)[2] === first.state.cashierReturnUrl.value, 'resuming the same verified unpaid order stays on the original lead')
const beforeResume = first.reads.length, initialBootstraps = first.bootstraps(); await first.state.initialize()
check(first.reads.length === beforeResume + 1 && first.bootstraps() === initialBootstraps, 'returning to a mounted task rechecks its pending order without resetting the list or form')
first.records.set(23, order(23, 77, 'paid')); await first.state.verifyPayment()
check(first.state.paymentCompleted.value && first.state.paymentId.value === 0 && first.state.overlay.value === 'detail', 'authoritative paid response ends the commission task on real detail')
check(first.state.cashierReturnUrl.value.includes('payment_order_id=23'), 'return ID survives clearing matching pending caches')
const confirmedCreateCount = first.created.length; await first.state.startOrder('commission', '125.00')
check(first.created.length === confirmedCreateCount, 'a completed payment cannot create another order on the same page')
const returned = fixture({ initialPaymentId: 23 }, { store: first.store, records: first.records }); await returned.state.initialize()
check(returned.state.paymentCompleted.value && returned.state.overlay.value === 'detail' && !returned.opened.length && !returned.created.length, 'a fresh native return checks the original paid order without creating or opening another payment')

const shared = new Map([['wap_site_id', 100005], [baseKey, 23], [cacheKey('commission', 77), 23]])
const otherLead = fixture({ initialId: 88 }, { store: shared }); await otherLead.state.initialize()
check(!otherLead.state.paymentId.value && !otherLead.reads.length && shared.get(cacheKey('commission', 77)) === 23, 'lead B does not install the merchant-wide pending pointer from lead A')
otherLead.controls.createOrder = async () => { const row = order(24, 88); otherLead.records.set(24, row); return row }; await otherLead.state.startOrder('commission', '125.00')
check(otherLead.opened[0][1] === 24 && otherLead.opened[0][2].includes('collaboration_id=88') && shared.get(cacheKey('commission', 77)) === 23, 'lead B creates/opens only its own payment while preserving lead A pending protection')
otherLead.records.set(24, order(24, 88, 'paid')); await otherLead.state.verifyPayment()
check(shared.get(cacheKey('commission', 77)) === 23 && !shared.has(cacheKey('commission', 88)), 'confirming B clears only B pending state, never A')
const wrongLink = fixture({ initialId: 88, initialPaymentId: 23 }, { store: shared }); await wrongLink.state.initialize(); await wrongLink.state.startOrder('commission', '125.00'); await wrongLink.state.resumePayment()
check(!!wrongLink.state.paymentContextError.value && !wrongLink.opened.length && !wrongLink.created.length && shared.get(cacheKey('commission', 77)) === 23, 'an explicit A-payment/B-lead link is blocked after server context validation without losing A protection')
check(!wrongLink.ui.busy.value && !wrongLink.state.paymentChecking.value && !wrongLink.state.paymentResuming.value && source.includes(':blocked="!!paymentContextError"') && !source.includes('paymentResuming || !!paymentContextError'), 'invalid context blocks checkout without masquerading as an active request and locking the back navigation')
const wrongPurpose=fixture({initialPaymentId:23});wrongPurpose.records.set(23,order(23,77,'unpaid','membership'));await wrongPurpose.state.initialize()
check(!!wrongPurpose.state.paymentContextError.value&&!wrongPurpose.opened.length,'a membership order cannot be restored as collaboration commission')
const wrongMerchant = fixture({ initialPaymentId: 23 }); wrongMerchant.records.set(23, { ...order(), merchant_id: 8 }); await wrongMerchant.state.initialize()
check(!!wrongMerchant.state.paymentContextError.value && !wrongMerchant.opened.length, 'a response belonging to a different merchant is never sent to the cashier')
const malformed = fixture({ initialPaymentId: 23 }); malformed.controls.readOrder = async () => ({ data: { ...order(), id: 999 } }); await malformed.state.initialize()
check(!!malformed.state.paymentContextError.value && malformed.state.paymentId.value === 23, 'mismatched response IDs retain the original candidate and block payment')

const closed = fixture({ initialPaymentId: 23 }); closed.records.set(23, order(23, 77, 'closed')); closed.store.set(cacheKey('commission', 77), 23); closed.store.set(baseKey, 23); await closed.state.initialize()
check(closed.state.paymentId.value === 23 && !closed.state.paymentCompleted.value && closed.store.get(cacheKey('commission', 77)) === 23 && !closed.opened.length && !closed.created.length, 'a closed order retains its identity and never automatically creates or opens a replacement')
check(closed.state.commissionLead.value.payment_order_id === 23 && closed.state.commissionPaymentClosed.value && closed.state.paymentMessage.value.includes('不会按原金额'), 'closed commission does not clear the server pointer or present an editable old-price checkout')
closed.controls.createOrder = async () => { const row = order(25); closed.records.set(25, row); return row }; await closed.state.startOrder('commission', '125.00')
check(!closed.created.length && !closed.opened.length && closed.store.get(cacheKey('commission', 77)) === 23, 'clicking the closed context cannot recreate the original price')
const repeatedClosed = fixture(); repeatedClosed.records.set(23, order(23, 77, 'closed')); await repeatedClosed.state.initialize(); await repeatedClosed.state.startOrder('commission', '125.00')
check(!repeatedClosed.created.length && !repeatedClosed.opened.length && !repeatedClosed.state.paymentCompleted.value, 'a current closed lead pointer is read without sending another create request')

const repriced = fixture({ initialPaymentId: 23 }); repriced.records.set(23, { ...order(23,77,'closed'),replacement_order_id:26 }); repriced.records.set(26, { ...order(26),reprices_order_id:23,amount:'150.00',fee_amount:'15.00',net_amount:'135.00' }); await repriced.state.initialize()
check(repriced.state.paymentId.value===26&&repriced.state.paymentOrder.value.amount==='150.00'&&repriced.state.commissionLead.value.commission_amount==='150.00'&&repriced.store.get(cacheKey('commission',77))===26&&!repriced.created.length&&!repriced.opened.length,'old commission link follows proven replacement and shows new amount without auto-paying or creating an old-price trade')
await repriced.state.resumePayment();check(repriced.opened.at(-1)?.[1]===26&&repriced.state.cashierReturnUrl.value.includes('payment_order_id=26'),'resuming the adjusted commission opens only the new verified trade and return context')
repriced.records.set(26,{...repriced.records.get(26),status:'paid',can_pay:false});await repriced.state.verifyPayment();check(repriced.state.paymentCompleted.value&&repriced.state.paymentOrder.value.id===26&&repriced.state.overlay.value==='detail'&&!repriced.store.has(cacheKey('commission',77)),'payment return clears only new trade pending state and routes to the paid detail')
const reverseOnly=fixture({initialPaymentId:23});reverseOnly.records.set(23,order(23,77,'closed'));reverseOnly.records.set(26,{...order(26),reprices_order_id:23});await reverseOnly.state.initialize();check(reverseOnly.state.paymentId.value===26,'fresh lead pointer and replacement reverse link can establish the current trade without an old cached forward link')
const badReplacement=fixture({initialPaymentId:23});badReplacement.records.set(23,{...order(23,77,'closed'),replacement_order_id:26});badReplacement.records.set(26,{...order(26),reprices_order_id:999});await badReplacement.state.initialize();await badReplacement.state.resumePayment();check(badReplacement.state.paymentId.value===23&&!badReplacement.created.length&&!badReplacement.opened.length,'a replacement with a wrong reverse source cannot change payment context or open cashier')
const staleAfterSuccess=fixture({initialPaymentId:23});await staleAfterSuccess.state.initialize();staleAfterSuccess.controls.readOrder=async()=>{throw Error('第二次读取失败')};await staleAfterSuccess.state.resumePayment();check(!staleAfterSuccess.opened.length&&staleAfterSuccess.state.paymentId.value===23,'a failed fresh read cannot reuse a previously valid unpaid snapshot to open cashier')
const wrongPayerReplacement=fixture({initialPaymentId:23});wrongPayerReplacement.records.set(23,{...order(23,77,'closed'),replacement_order_id:26});wrongPayerReplacement.records.set(26,{...order(26),member_id:102,reprices_order_id:23});await wrongPayerReplacement.state.initialize();await wrongPayerReplacement.state.resumePayment();check(wrongPayerReplacement.state.paymentId.value===23&&!wrongPayerReplacement.opened.length&&!wrongPayerReplacement.created.length,'replacement under another payer is rejected even when store and lead IDs match')
const changedLeadPointer=fixture({initialPaymentId:23});changedLeadPointer.records.set(26,{...order(26),reprices_order_id:23});await changedLeadPointer.state.initialize();await changedLeadPointer.state.resumePayment();check(changedLeadPointer.state.paymentId.value===23&&!changedLeadPointer.opened.length&&!changedLeadPointer.created.length,'an unpaid old trade cannot pay after the server lead has switched to another current trade')
const missingReplacement=fixture({initialPaymentId:23});missingReplacement.records.set(23,{...order(23,77,'closed'),replacement_order_id:26});await missingReplacement.state.initialize();await missingReplacement.state.resumePayment();check(missingReplacement.state.paymentId.value===23&&!missingReplacement.opened.length&&!missingReplacement.created.length,'an unreadable replacement keeps the old protection and cannot fall back to an old-price creation')

const unknown = fixture({ initialPaymentId: 23 }); unknown.controls.readOrder = async () => { throw Error('合成超时') }; unknown.store.set(cacheKey('commission', 77), 23); await unknown.state.initialize(); await unknown.state.startOrder('commission', '125.00')
check(unknown.state.paymentId.value === 23 && unknown.store.get(cacheKey('commission', 77)) === 23 && !unknown.created.length && !unknown.opened.length, 'unknown payment outcome preserves the original ID/cache and cannot create or open a replacement')
const review = fixture({ initialPaymentId: 23 }); review.records.set(23, { ...order(23, 77, 'paid'), requires_manual_review: true }); await review.state.initialize(); await review.state.startOrder('commission', '125.00')
check(review.state.paymentId.value === 23 && !review.state.paymentCompleted.value && review.store.get(cacheKey('commission', 77)) === 23 && !review.created.length && !review.opened.length, 'paid-but-needs-review preserves its pending protection and never appears eligible for a replacement payment')
const unfamiliar = fixture({ initialPaymentId: 23 }); unfamiliar.records.set(23, order(23, 77, 'processing')); await unfamiliar.state.initialize(); await unfamiliar.state.startOrder('commission', '125.00')
check(unfamiliar.state.paymentId.value === 23 && !unfamiliar.created.length && !unfamiliar.opened.length, 'an unknown status cannot be treated as unpaid or closed')

const singleFlight = fixture({ initialPaymentId: 23 }); await singleFlight.state.initialize()
let release; singleFlight.controls.readOrder = () => new Promise(resolve => { release = resolve })
const readCount = singleFlight.reads.length, resumeOne = singleFlight.state.resumePayment(), resumeTwo = singleFlight.state.resumePayment()
check(singleFlight.reads.length === readCount + 1, 'repeated resume clicks share one in-flight authoritative check')
release({ data: order() }); await Promise.all([resumeOne, resumeTwo])
check(singleFlight.opened.length === 1, 'a single resume flow opens the cashier at most once')
const main = fixture({ task: '', initialId: 0 }); main.store.set(baseKey, 23); await main.state.initialize(); await main.state.resumePayment()
check(!main.opened.length && main.navigated[0].task === 'commission' && main.navigated[0].params.collaboration_id === 77 && main.navigated[0].params.payment_order_id === 23, 'a main-tab reminder routes to the verified original payment task rather than paying under generic page context')
const loggedOut = fixture({ initialPaymentId: 23 }); loggedOut.setToken(''); await loggedOut.state.initialize()
check(loggedOut.logins[0].param.payment_order_id === 23, 'login return preserves the original payment ID')
const failedAction = fixture(); await failedAction.state.initialize(); failedAction.ui.writeError.value = '合成接单结果待核实'
await failedAction.state.reloadDetail()
check(!failedAction.ui.writeError.value && failedAction.ui.detail.value.id === 77 && !failedAction.created.length, 'detail retry clears the old write error and performs only a fresh read, never replaying an action or payment')
const interruptedPage = fixture({ task: 'detail' }); let finishOldDetail
interruptedPage.ui.loadDetail = () => new Promise(resolve => { finishOldDetail = resolve })
const obsoleteInitialize = interruptedPage.state.initialize()
for (let step = 0; step < 5 && !finishOldDetail; step++) await Promise.resolve()
interruptedPage.state.pausePage()
interruptedPage.ui.resumeInterruptedReads = async () => { interruptedPage.ui.detail.value = { id: 77, status: 'following' } }
await interruptedPage.state.initialize()
check(interruptedPage.state.overlay.value === 'detail' && interruptedPage.ui.detail.value.id === 77, 'recovery mounts the detail task even when backgrounding interrupted its very first initialization')
finishOldDetail(false); await obsoleteInitialize
check(interruptedPage.state.overlay.value === 'detail', 'an obsolete initialization cannot overwrite the resumed task')

const differentMember = fixture({ task: '', initialId: 0 }, { store: shared, memberId: 104 }); await differentMember.state.initialize()
check(!differentMember.reads.length && !differentMember.state.paymentId.value && shared.get(cacheKey('commission', 77)) === 23, 'another staff account in the same store never restores the original member payment cache')
const differentSite = fixture({ task: '', initialId: 0 }, { store: shared, site: '100006' }); await differentSite.state.initialize()
check(!differentSite.reads.length && !differentSite.state.paymentId.value, 'the actual runtime site, not a fallback storage site, isolates pending payment pointers')
const missingMember = fixture({ initialPaymentId: 23 }, { store: shared, memberId: 0 }); await missingMember.state.initialize(); await missingMember.state.startOrder('commission', '125.00'); await missingMember.state.resumePayment()
check(!missingMember.created.length && !missingMember.opened.length && missingMember.state.paymentContextError.value.includes('登录信息') && missingMember.state.paymentContextError.value.includes('本次未发起付款') && !shared.has(''), 'missing validated current member blocks payment with a specific sign-in hint and does not read/write an anonymous cache key')
const missingMemberNew = fixture({}, { memberId: 0 }); missingMemberNew.ui.loadDetail = async id => { missingMemberNew.ui.detail.value = { id, status: 'unpaid', payment_order_id: 0 }; return true }; await missingMemberNew.state.initialize(); await missingMemberNew.state.startOrder('commission', '125.00')
check(!missingMemberNew.created.length && missingMemberNew.ui.writeError.value.includes('登录信息') && missingMemberNew.ui.writeError.value.includes('本次未发起付款') && ![...missingMemberNew.store.keys()].some(key => key.startsWith('hsx_lead_coop_pay:')), 'unpaired backend cannot create or persist a new payment by pretending the owner is the current viewer')
const missingSite = fixture({ initialPaymentId: 23 }, { store: shared, site: '' }); await missingSite.state.initialize(); await missingSite.state.resumePayment()
check(!missingSite.created.length && !missingSite.opened.length && missingSite.state.paymentContextError.value.includes('所属站点') && !missingSite.state.paymentContextError.value.includes('登录信息') && !shared.has(''), 'missing site is identified separately from login identity and cannot open a cached or explicit payment')
const missingSiteNew = fixture({}, { site: '' }); missingSiteNew.ui.loadDetail = async id => { missingSiteNew.ui.detail.value = { id, status: 'unpaid', payment_order_id: 0 }; return true }; await missingSiteNew.state.initialize(); await missingSiteNew.state.startOrder('commission', '125.00')
check(!missingSiteNew.created.length && !missingSiteNew.opened.length && missingSiteNew.ui.writeError.value.includes('所属站点') && ![...missingSiteNew.store.keys()].some(key => key.startsWith('hsx_lead_coop_pay:')), 'a valid member with no site cannot create or persist an unscoped payment, even with an old stored site')
check(![...shared.keys()].some(key => key.includes('fixture-session')), 'payment storage keys never contain authentication tokens')

// Real commission-form guard and real navigation handler: blocked is not busy.
function componentSetup(name, props, events) {
    const filename = path.join(plugin, 'uni-app/components/cooperation', name + '.vue'), parsed = compiler.parse(fs.readFileSync(filename, 'utf8')).descriptor
    const compiled = compiler.compileScript(parsed, { id: name }), output = ts.transpileModule(compiled.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText, module = { exports: {} }
    const deps = { vue: { ...Vue, onMounted() {}, onBeforeUnmount() {}, useSlots: () => ({}) }, '../../api/cooperation': { coopMoney: value => String(value) } }
    vm.runInNewContext('(function(require,module,exports){' + output + '\n})', { Date, Number, String, Math, Set, console })(key => { if (key in deps) return deps[key]; if (key.endsWith('.vue')) return { default: {} }; if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key)); throw Error('Unexpected dependency ' + key) }, module, module.exports)
    return { state: module.exports.default.setup(props, { expose() {}, emit: (...args) => events.push(args) }), template: parsed.template.content }
}
const formEvents = [], formProps = Vue.reactive({ show: true, page: true, lead: { ...order(), payment_order_id: 23, commission_amount: '125.00' }, config: {}, busy: false, blocked: true, error: '付款信息不符' })
const form = componentSetup('CoopCommissionForm', formProps, formEvents); form.state.submit()
check(!formEvents.length && form.template.includes(':busy="busy"') && form.template.includes(':loading="busy"') && form.template.includes(':disabled="busy || blocked'), 'blocked commission form prevents submission while its task sheet and spinner receive only real busy state')
const backEvents = [], navigation = componentSetup('CooperationNav', { title: '确认协作佣金', back: true, disabled: formProps.busy, actions: [], actionsWidth: 44 }, backEvents)
navigation.state.goBack(); check(backEvents[0]?.[0] === 'back', 'real custom navigation can leave a blocked payment context with no active request')

const nativePay = fs.readFileSync(path.resolve(plugin, '../../../uni-app/src/components/pay/pay.vue'), 'utf8')
check(nativePay.includes('url: prop.reformat'), 'checks cover the real framework success-path contract, not only the open payReturn argument')
console.log(`PASS ${checks} payment return/isolation/retry checks; actual plugin Vue setup and framework source contract, synthetic transports only, no browser or business mutations.`)
