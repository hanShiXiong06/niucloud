import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const ts = require('typescript')
const filename = path.resolve(plugin, '../../../uni-app/src/utils/common.ts')
const source = fs.readFileSync(filename, 'utf8'), ast = ts.createSourceFile(filename, source, ts.ScriptTarget.Latest, true)
const node = ast.statements.find(value => ts.isFunctionDeclaration(value) && value.name?.text === 'handleOnloadParams')
if (!node) throw Error('The installed framework no longer exposes handleOnloadParams')
function execute(input, deps, runtime) {
    const module = { exports: {} }
    const js = ts.transpileModule(input, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { String, Object, Array, Number, uni: runtime })(key => {
        if (key in deps) return deps[key]
        throw Error('Unexpected framework-invite dependency: ' + key)
    }, module, module.exports)
    return module.exports
}

/** Executes both actual source functions; only storage side effects are synthetic. */
export function loadFrameworkInvite(runtime = {}) {
    const common = execute(node.getText(ast), {}, { setStorageSync() {}, ...runtime })
    return execute(fs.readFileSync(path.join(plugin, 'uni-app/utils/cooperation-invite.ts'), 'utf8'), { '@/utils/common': common }, runtime)
}
