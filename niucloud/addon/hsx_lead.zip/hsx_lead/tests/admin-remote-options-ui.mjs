import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..')
const require=createRequire(path.join(workspace,'admin/package.json')),Vue=require('vue'),ts=require('typescript'),compiler=require('@vue/compiler-sfc')
let checks=0,clock=0
const check=(ok,label)=>{assert.ok(ok,label);checks++},cleanup=[],timers=new Map()
const source=ts.transpileModule(fs.readFileSync(path.join(plugin,'admin/composables/useRemoteOptions.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,module={exports:{}}
vm.runInNewContext(`(function(require,module,exports){${source}\n})`,{console,Number,String,Array,Math,Promise,Error,setTimeout:fn=>{timers.set(++clock,fn);return clock},clearTimeout:id=>timers.delete(id)})(key=>{assert.equal(key,'vue');return{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)}},module,module.exports)
const {useRemoteOptions,remoteOptionRows}=module.exports
const flush=async()=>{await Promise.resolve();await Promise.resolve();await Vue.nextTick()}
const runTimers=async()=>{const pending=[...timers.values()];timers.clear();pending.forEach(fn=>fn());await flush()}
const scope=Vue.ref('actor-a:site100005:dialog1'),selected=Vue.ref(undefined),calls=[]
let work=async keyword=>[{id:1,name:keyword||'张三',mobile:'18800000001'}]
const state=useRemoteOptions({request:keyword=>{calls.push(keyword);return work(keyword)},key:row=>Number(row.id),selectedKey:()=>selected.value,scope:()=>scope.value,errorText:(error,fallback)=>error?.message||fallback,fallback:'读取失败'})
state.search('张');state.search('张三');state.search('18800000001')
check(calls.length===0&&state.loading.value&&timers.size===1,'typing is debounced and visibly pending before a request')
await runTimers();check(calls.length===1&&calls[0]==='18800000001'&&!state.loading.value,'only the latest keyword is requested')
selected.value=1
work=async()=>[{id:2,name:'同名会员',mobile:'18800000002'}]
await state.load('另一个');check(state.options.value.length===2&&state.options.value[0].name==='18800000001','selected identity remains readable when another search returns different IDs')
selected.value=2;check(state.options.value.length===1&&state.options.value[0].id===2,'choosing a new row replaces the previous pinned identity')
work=async()=>[];await state.load('没有');check(state.options.value.length===1&&state.options.value[0].id===2&&!state.error.value,'a successful empty query preserves only the real selected identity')
selected.value=undefined;check(state.options.value.length===0,'clear removes the pinned identity instead of restoring it')
state.remember({id:8,name:'原绑定会员'});selected.value=8;check(state.options.value[0].id===8,'a detail-provided selected identity is retained before any search')
let oldResolve,newResolve
work=keyword=>new Promise(resolve=>{if(keyword==='旧查询')oldResolve=resolve;else newResolve=resolve})
const old=state.load('旧查询'),current=state.load('新查询');newResolve([{id:10,name:'新结果'}]);await current;oldResolve([{id:9,name:'旧结果'}]);await old
check(state.options.value.some(row=>row.id===10)&&!state.options.value.some(row=>row.id===9),'late response cannot overwrite current search')
let scopeResolve;work=()=>new Promise(resolve=>scopeResolve=resolve);const previous=state.load('私有候选');scope.value='actor-b:site100006:dialog1';scopeResolve([{id:11,name:'上个账号'}]);await previous
check(state.options.value.length===0&&!state.loading.value&&!state.error.value,'closing/changing actor or site clears private candidates and rejects late responses')
state.search('不应发起');scope.value='actor-b:site100006:dialog2';await runTimers();check(calls.at(-1)==='私有候选','scope change cancels pending debounce before a request is issued')
work=async()=>{throw Error('合成权限失败')};await state.load('失败');check(state.error.value==='合成权限失败'&&!state.loading.value&&state.options.value.length===0,'failed read is an explicit error, not a successful empty search')
work=async()=>[{id:12,name:'重试成功'}];await state.load();check(!state.error.value&&state.options.value[0].id===12&&calls.at(-1)==='失败','retry keeps the submitted keyword and restores options')
for(const result of [undefined,{}, {data:null},{data:{}},{data:[null]},{data:[{id:0}]},{data:[{id:'bad'}]},{data:[{id:true}]},{data:[{id:1.5}]},{data:[{id:{}}]}]){
 assert.throws(()=>remoteOptionRows(result,row=>row.id),/候选列表格式不完整/);checks++
}
check(remoteOptionRows({data:{data:[{id:'15'}]}},row=>row.id)[0].id==='15','valid paginated response remains supported')
check(remoteOptionRows({data:[]},row=>row.id).length===0,'genuine empty array remains valid')
let unmountResolve;work=()=>new Promise(resolve=>unmountResolve=resolve);const pending=state.load('卸载');cleanup.forEach(fn=>fn());unmountResolve([{id:13}]);await pending
check(!state.options.value.some(row=>row.id===13)&&!state.loading.value,'unmount prevents late writes and clears pending loading')
for(const name of ['composables/useRemoteOptions.ts','views/components/MerchantPanel.vue','views/cooperation/Reviews.vue','views/components/ConnectionWizard.vue']){
 const code=fs.readFileSync(path.join(plugin,'admin',name),'utf8')
 check(code===fs.readFileSync(path.join(workspace,'admin/src/addon/hsx_lead',name),'utf8'),name+' canonical/mirror match')
 if(name.endsWith('.vue')){
  const parsed=compiler.parse(code,{filename:name});check(parsed.errors.length===0,name+' parses')
  compiler.compileScript(parsed.descriptor,{id:'remote-options'})
  check(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:name,id:'remote-options',compilerOptions:{expressionPlugins:['typescript']}}).errors.length===0,name+' template compiles')
 }
}
console.log(`PASS ${checks} searchable-identity Vue state, race, scope, malformed-response, retry and SFC checks. Synthetic only; no API, database or writes.`)
