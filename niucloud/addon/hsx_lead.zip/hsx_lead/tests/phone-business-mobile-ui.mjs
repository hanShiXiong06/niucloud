import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Real plugin utilities and Vue component setup/render; only uni I/O and leaf UI
// controls are doubles. No business API, map request, payment or existing data.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const mobile = path.join(plugin, 'uni-app'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), { renderToString } = require('@vue/server-renderer')
let checks = 0, sequence = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
const copy = value => JSON.parse(JSON.stringify(value))
const storage = new Map([['wap_site_id', 100005], ['wap_member_id', 101]]), clips = [], toasts = [], scopes = []
const uni = { getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, copy(value)), removeStorageSync: key => storage.delete(key), setClipboardData: value => clips.push(value), showToast: value => toasts.push(value) }
const api = { coopMoney: value => value == null ? '—' : '¥' + Number(value).toFixed(2), coopRequestId: () => 'phone-business-' + (++sequence), coopDate: () => '', coopStatusLabels: {}, businessLabels: {} }
const slotStub = { setup: (_props, { slots }) => () => Vue.h('section', {}, [slots.default?.(), slots.footer?.()]) }
function execute(source, deps = {}) {
    const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText, module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Array, Object, JSON, Set, Map, Promise, console, uni })(key => {
        if (key in deps) return deps[key]
        if (key === 'vue') return Vue
        if (key === '../../api/cooperation') return api
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        if (key === '@/utils/common') return { img: value => value }
        if (key.endsWith('CoopTaskSheet.vue')) return { default: slotStub }
        if (key.endsWith('.vue')) return { default: {} }
        throw Error('Unexpected dependency: ' + key)
    }, module, module.exports)
    return module.exports
}
function component(name, inline = false) {
    const filename = path.join(mobile, 'components/cooperation', name + '.vue'), parsed = compiler.parse(fs.readFileSync(filename, 'utf8'), { filename })
    check(!parsed.errors.length, name + ' parses')
    return execute(compiler.compileScript(parsed.descriptor, { id: 'phone-business-' + name, inlineTemplate: inline }).content).default
}
function setup(name, initial) {
    const actual = component(name), props = Vue.reactive(initial), events = [], exposed = {}, scope = Vue.effectScope()
    const state = scope.run(() => actual.setup(props, { expose: value => Object.assign(exposed, value), emit: (...args) => events.push(args) }))
    scopes.push(scope)
    return { props, state, events, exposed }
}
async function html(name, props) {
    const app = Vue.createSSRApp({ render: () => Vue.h(component(name, true), props) }); app.config.warnHandler = () => {}
    app.component('u-icon', { props: ['name'], setup: props => () => Vue.h('i', { 'data-icon': props.name }) })
    app.component('u-input', { props: ['modelValue', 'placeholder', 'disabled', 'maxlength'], setup: props => () => Vue.h('input', { value: props.modelValue, placeholder: props.placeholder, disabled: props.disabled, maxlength: props.maxlength }) })
    for (const name of ['u-collapse', 'u-collapse-item']) app.component(name, slotStub)
    return renderToString(app)
}
const utilities = loadMobileUtility('cooperation-business')
const address = { key: 'pickup_address', label: '上门地址', type: 'address', required: true, placeholder: '小区、街道或地标即可' }
const home = { key: 'home_recycle', name: '二手机上门回收', enabled: true, dimension: 'model', selection_mode: 'multiple', selection_limit: 5, commission_minimum: '100.00', fields: [address], options: [] }
const repair = { key: 'repair', name: '手机维修', enabled: true, dimension: 'model', selection_mode: 'multiple', selection_limit: 5, commission_minimum: '150.00', fee_override: true, fee_percent: '20.00', fee_minimum: '12.00', fields: [{ key: 'fault', label: '故障描述', type: 'text', required: true }], options: [] }
const models = [{ id: 'phone_1', title: '合成型号' }]
try {
    equal(utilities.businessFormError(home, models, {}), '请填写上门地址', 'required address rejects omitted value')
    equal(utilities.businessFormError(home, models, { pickup_address: '   ' }), '请填写上门地址', 'required address rejects whitespace')
    equal(utilities.businessFormError(home, models, { pickup_address: '合成街道' }), '', 'approximate address is sufficient without door number or coordinates')
    for (const value of ['街'.repeat(301), '<script>', '街道\n门牌']) check(utilities.businessFormError(home, models, { pickup_address: value }).includes('300字以内'), 'invalid address rejected locally: ' + value.slice(0, 12))
    check(utilities.businessFormError(home, models, { pickup_address: { latitude: 1, longitude: 2 } }).includes('格式'), 'objects and fabricated coordinates do not pass as text')
    equal(utilities.businessFormError(home, models, { pickup_address: '街'.repeat(300) }), '', '300 unicode characters are accepted at the documented boundary')
    equal(utilities.businessFieldValue(address, {}), '', 'redacted server field stays empty')
    equal(utilities.businessFieldValue(address, { pickup_address: {} }), '', 'malformed field cannot render object strings')
    equal(utilities.businessAddressText('河北 / 石家庄 / 长安区', ' 合成小区西门 '), '河北 / 石家庄 / 长安区 合成小区西门', 'copy text includes selected region and approximate address')
    equal(utilities.businessAddressText('河北', ''), '', 'region alone does not enable copy of a redacted address')
    equal(utilities.businessAddressText('河北', '河北 合成小区'), '河北 合成小区', 'an address already prefixed with its region is not doubled')
    equal(utilities.businessFeeRules(home, { fee_percent: '10.00', fee_minimum: '9.90' }), { percent: '10.00', minimum: '9.90' }, 'business without override inherits global rates')
    equal(utilities.businessFeeRules(repair, { fee_percent: '10.00', fee_minimum: '9.90' }), { percent: '20.00', minimum: '12.00' }, 'business override displays its actual backend contract')

    const publisher = setup('CoopPublishForm', { show: true, page: true, merchantId: 7, config: { businesses: [home, repair], fee_confirmed: true, fee_percent: '10.00', fee_minimum: '9.90' }, busy: false, error: '' })
    Object.assign(publisher.state.form, { customer_name: '合成客户', mobile: '18800000000', province_id: 1, city_id: 2, district_id: 3, region_text: '合成省 / 合成市 / 合成区', consent: true })
    publisher.state.selections.home_recycle = copy(models)
    publisher.state.submit(); check(publisher.events.length === 0 && publisher.state.localError.value === '请填写上门地址', 'real publishing form blocks missing home-pickup address')
    publisher.state.values.value.pickup_address = '合成小区西门'
    publisher.state.submit(); equal(publisher.events[0][1].form_values, { pickup_address: '合成小区西门' }, 'real submit sends plain configured address without duplicate contact fields')
    publisher.state.changeBusiness({ detail: { value: '1' } }); publisher.state.selections.repair = copy(models)
    equal([publisher.state.form.business_type, publisher.state.businessIndex.value], ['repair', 1], 'native business picker changes only the selected business key')
    publisher.state.submit(); check(publisher.state.localError.value === '请填写故障描述', 'switching business validates its own fields rather than former address')
    publisher.state.values.value.fault = '合成屏幕故障'; publisher.state.submit()
    equal(publisher.events.at(-1)[1].form_values, { fault: '合成屏幕故障' }, 'repair payload contains no address from another business')
    equal(publisher.state.feeRules.value, { percent: '20.00', minimum: '12.00' }, 'real fee panel follows selected business overrides')
    publisher.state.changeBusiness({ detail: { value: '0' } })
    equal(publisher.state.values.value.pickup_address, '合成小区西门', 'business switching retains independent address draft')
    equal(publisher.state.models.value, models, 'business picker retains previously selected model draft')
    check(publisher.state.fields.repair.fault === '合成屏幕故障', 'business picker does not discard another business form fields')
    for (const value of ['-1', '999', '0.5', 'bad']) publisher.state.changeBusiness({ detail: { value } })
    check(publisher.state.form.business_type === 'home_recycle', 'native picker rejects invalid or out-of-range indices')
    publisher.props.busy = true; publisher.state.changeBusiness({ detail: { value: '1' } })
    check(publisher.state.form.business_type === 'home_recycle', 'submission lock disables business switching')
    publisher.props.busy = false
    await Vue.nextTick()
    publisher.props.show = false; await Vue.nextTick()
    const reopened = setup('CoopPublishForm', { ...publisher.props, show: true })
    equal(reopened.state.values.value.pickup_address, '合成小区西门', 'local draft persists the address after leaving and reopening the form')
    reopened.exposed.clear(); check(!storage.has('hsx_lead_publish_draft:100005:101'), 'successful publication can clear only this member/site draft')

    const field = setup('CoopBusinessField', { field: address, modelValue: '', disabled: false })
    field.state.writeAddress({ detail: { value: '合成小区\n西门' } })
    equal(field.events[0], ['update:modelValue', '合成小区 西门'], 'mobile textarea converts an accidental new line into address spacing')
    field.props.disabled = true; field.state.writeAddress({ detail: { value: 'Cannot edit' } }); check(field.events.length === 1, 'address input ignores changes while submission is locked')
    field.props.modelValue = '合成📍小区'; equal(field.state.charCount.value, 5, 'script-owned count handles unicode without template global calls')
    let rendered = await html('CoopBusinessField', { field: address, modelValue: '合成小区', disabled: false })
    check(rendered.includes('textarea') && rendered.includes('maxlength="300"') && rendered.includes('小区、街道或地标即可') && rendered.includes('4/300'), 'actual field render provides compact address input, configured placeholder and count')

    const lead = { id: 9, status: 'assigned', can_accept: true, mobile: '', region_text: '河北 / 石家庄 / 长安区', fields: [address], form_values: {}, models: [] }
    rendered = await html('CoopTaskDetail', { show: true, page: true, lead, config: {} })
    check(rendered.includes('接单后查看上门地址') && !rendered.includes('复制地址'), 'unaccepted redacted detail has no address or copy control')
    const detail = setup('CoopTaskDetail', { show: true, lead, config: {}, busy: false })
    detail.state.copyAddress(address); check(clips.length === 0, 'direct invocation cannot copy a redacted address either')
    detail.props.lead = { ...lead, can_accept: false, status: 'following', form_values: { pickup_address: '合成小区西门' } }
    rendered = await html('CoopTaskDetail', { show: true, page: true, lead: detail.props.lead, config: {} })
    check(rendered.includes('合成小区西门') && rendered.includes('复制地址'), 'authorized detail renders actual address and one copy action')
    detail.state.copyAddress(address)
    check(clips.length === 1 && clips[0].data === '河北 / 石家庄 / 长安区 合成小区西门', 'copy action uses only the disclosed region and address')
    clips[0].success(); check(toasts.at(-1).title === '地址已复制', 'copy success is explicit')
    clips[0].fail(); check(toasts.at(-1).title.includes('复制失败'), 'clipboard denial has an actionable fallback')
    detail.props.busy = true; detail.state.copyAddress(address); check(clips.length === 1, 'locked detail does not start repeated clipboard actions')
    check(!fs.readFileSync(path.join(mobile, 'components/cooperation/CoopTaskDetail.vue'), 'utf8').includes('openLocation'), 'plain address is not represented as a verified geocoded navigation point')
    const publisherSource = fs.readFileSync(path.join(mobile, 'components/cooperation/CoopPublishForm.vue'), 'utf8')
    check(publisherSource.includes(':range="businesses"') && publisherSource.includes('range-key="name"') && publisherSource.includes('@change="changeBusiness"') && !publisherSource.includes('coop-type-switch'), 'form uses one native business picker without a duplicate chip interaction')
    console.log(`PASS ${checks} phone-business mobile checks; actual Vue setup/render and plugin utilities, synthetic storage/clipboard only; no API, map, money or existing-data access.`)
} finally { for (const scope of scopes) scope.stop() }
