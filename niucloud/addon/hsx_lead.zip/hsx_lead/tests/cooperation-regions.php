<?php
declare(strict_types=1);
require dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\cooperation\RegionSearchService;
$checks=0;
function areaCheck(bool $ok,string $label): void { if (!$ok) throw new RuntimeException($label);$GLOBALS['checks']++; }
$rows=[
    ['id'=>1,'pid'=>0,'name'=>'河北省','level'=>1],['id'=>2,'pid'=>1,'name'=>'石家庄市','level'=>2],['id'=>3,'pid'=>2,'name'=>'长安区','level'=>3],
    ['id'=>4,'pid'=>0,'name'=>'陕西省','level'=>1],['id'=>5,'pid'=>4,'name'=>'西安市','level'=>2],['id'=>6,'pid'=>5,'name'=>'长安区','level'=>3],
    ['id'=>7,'pid'=>999,'name'=>'失效地区','level'=>3],
];
$found=RegionSearchService::find($rows,'长安区');
areaCheck($found['total']===2,'same district names keep two complete paths');
areaCheck($found['data'][0]['region_text']==='河北省 / 石家庄市 / 长安区','full path distinguishes same-name districts');
areaCheck($found['data'][0]['province_id']===1&&$found['data'][0]['city_id']===2&&$found['data'][0]['district_id']===3,'district selection returns all framework parent IDs');
areaCheck(RegionSearchService::find($rows,'河北省 石家庄市 长安区')['total']===1,'full path keyword can be searched directly');
areaCheck(RegionSearchService::find($rows,'石家庄市')['data'][0]['level']===2,'exact city name ranks before its child districts');
areaCheck(RegionSearchService::find($rows,'河北')['data'][0]['city_id']===0,'province selection does not invent a city');
areaCheck(RegionSearchService::find($rows,'失效地区')['total']===0,'orphan paths cannot be selected');
areaCheck(RegionSearchService::find($rows,'不存在')['total']===0,'no matches is a real empty result');
areaCheck(RegionSearchService::find($rows,' ')['total']===0,'blank keyword does not enumerate dictionary');
for($i=10;$i<70;$i++) $rows[]=['id'=>$i,'pid'=>2,'name'=>'测试地区'.$i,'level'=>3];
$bounded=RegionSearchService::find($rows,'测试');areaCheck($bounded['total']===60&&count($bounded['data'])===30,'results bounded without lying about total');
echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'synthetic area dictionary only; no database or network'],JSON_UNESCAPED_UNICODE).PHP_EOL;
