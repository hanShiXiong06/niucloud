import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), root = path.resolve(plugin, '../../..')
const require = createRequire(path.join(root, 'uni-app/package.json')), Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc'), sass = require('sass')
const read = name => fs.readFileSync(path.join(plugin, 'uni-app', name), 'utf8')
let checks = 0
function check(value, label) { assert.ok(value, label); checks++ }
function execute(source, deps, globals = {}) { const module = { exports: {} }, js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText; vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Number, String, Date, Math, Object, Map, Set, Promise, console, ...globals })(name => { if (name in deps) return deps[name]; if (name.endsWith('.vue')) return { default: {} }; throw Error('Unexpected dependency ' + name) }, module, module.exports); return module.exports }
const utility = loadMobileUtility('cooperation-payment-orders')
check(utility.cooperationPaymentOrderStatuses.map(item => item.value).join(',') === 'unpaid,paid,closed', 'mobile offers only pending, paid and closed state tabs')
check(utility.cooperationPaymentOrderStatus(undefined) === 'unpaid' && utility.cooperationPaymentOrderStatus('unknown') === 'unpaid', 'initial or unsupported filter selects pending payment, never an empty hidden all-state query')
check(utility.cooperationPaymentOrderStatus('paid') === 'paid' && utility.cooperationPaymentOrderStatus('closed') === 'closed', 'explicit existing paid/closed deep links retain their selected tab')
for (const bad of [{ order_id: 9, status: 'pending', amount: '99.00' }, { order_id: 8, status: 'mystery', amount: '99.00' }, { order_id: 8, status: 'pending', amount: 'NaN' }]) {
    let blocked = false; try { utility.cooperationPaymentRefundDetail(bad, 8) } catch { blocked = true }; check(blocked, 'wrong order, unknown result or invalid money cannot be accepted as confirmed refund data')
}
for (const name of ['pages/orders/index.vue', 'pages/orders/components/PaymentRefundSheet.vue']) {
    const descriptor = compiler.parse(read(name), { filename: name }).descriptor
    compiler.compileScript(descriptor, { id: 'refund-mobile' })
    check(!compiler.compileTemplate({ source: descriptor.template.content, filename: name, id: 'refund-mobile', compilerOptions: { expressionPlugins: ['typescript'] } }).errors.length, name + ' real template compiles')
    for (const style of descriptor.styles) if (style.lang === 'scss') sass.compileString(style.content, { logger: { warn() {} } })
    check(read(name) === fs.readFileSync(path.join(root, 'uni-app/src/addon/hsx_lead', name), 'utf8'), name + ' mirror matches source')
}
const source = read('pages/orders/index.vue'), component = read('pages/orders/components/PaymentRefundSheet.vue')
check(source.includes('z-paging') && source.includes('createCooperationPagingGuard') && source.includes(':concat="false"'), 'existing real pagination and first-page retry guard remain in use')
check(!/filterOpen|filterDraft|readOptions|payment_type:|payment_channel:|refund_status:|start_time:|purposeOptions/.test(source) && source.includes('payment_type_name') && source.includes('payment_channel_name') && !source.includes('requestPayment'), 'mobile removes advanced filtering but retains per-order payment metadata and the original cashier')
check(component.includes('<u-form ') && component.includes('<u-form-item ') && component.includes('<u-textarea ') && component.includes('formRef.value.validate()'), 'refund reason uses installed framework uview form, item, textarea and validation')
check(component.includes('重新读取原申请') && component.includes('平台审核') && !component.includes('input type="digit"'), 'unknown result offers original request recovery and never lets the browser choose refund amount')
const sheetDescriptor = compiler.parse(component).descriptor, sheetModule = execute(compiler.compileScript(sheetDescriptor, { id: 'refund-sheet-form' }).content, { vue: Vue, '../../../api/cooperation': { coopMoney: String, coopDate: String }, '../../../utils/mobile-ui': { cooperationButtonStyle: {} } }, { uni: { showToast() {} } })
const sheetProps = Vue.reactive({ show: true, order: { id: 8 }, detail: { can_request: true }, loading: false, busy: false, error: '', readRequired: false }), formEvents = []
const sheetState = sheetModule.default.setup(sheetProps, { expose() {}, emit: (...args) => formEvents.push(args) })
await sheetState.submit(); check(!formEvents.length, 'unmounted form cannot bypass the framework validator')
sheetState.formRef.value = { validate: async () => { throw Error('invalid') } }; sheetState.form.reason = '填写申请原因'; await sheetState.submit(); check(!formEvents.length, 'failed framework form validation never emits a financial intent')
sheetState.formRef.value = { validate: async () => true }; await sheetState.submit(); check(formEvents.length === 1 && formEvents[0][0] === 'submit' && formEvents[0][1] === '填写申请原因', 'validated form emits only its normalized reason to the guarded page handler')
sheetProps.readRequired = true; await sheetState.submit(); check(formEvents.length === 1, 'uncertain write state disables form submission until original data is read')
sheetProps.readRequired = false; let finishValidation; sheetState.formRef.value = { validate: () => new Promise(resolve => { finishValidation = resolve }) }; const staleValidation = sheetState.submit(); sheetProps.show = false; finishValidation(true); await staleValidation; check(formEvents.length === 1, 'sheet closed during async validation cannot submit later')

let member = 'member-a', site = '100005', requestSequence = 0
const lifecycle = {}, dialogs = [], toasts = [], reads = [], writes = [], listCalls = []
const base = () => ({ order_id: 8, order_no: 'TEST-8', amount: '99.00', status: 'none', status_name: '未申请退款', can_request: true, can_cancel: false, can_refresh: false, request_version: '', logs: [], components: { service: '99.00', deposit: '0.00', experience: '0.00' } })
let detail = base(), readWork = async () => ({ data: structuredClone(detail) }), postWork = async () => ({ data: { ...base(), status: 'pending', status_name: '待审核', can_request: false, can_cancel: true, request_version: 'version-1' } }), refreshWork = async () => ({ data: { ...base(), status: 'refunding', status_name: '退款处理中', can_request: false, can_refresh: true } }), cancelWork = async () => ({ data: { ...base(), status: 'cancelled', status_name: '申请已撤回' } })
const api = {
    cooperationOrders: async query => { listCalls.push(query); return { data: { data: [], total: 0 } } },
    cooperationOrderRefund: async id => { reads.push(id); return readWork(id) },
    requestCooperationOrderRefund: async (id, payload) => { writes.push({ kind: 'request', id, payload }); return postWork(id, payload) },
    refreshCooperationOrderRefund: async id => { writes.push({ kind: 'refresh', id }); return refreshWork(id) },
    cancelCooperationOrderRefund: async (id, request_version) => { writes.push({ kind: 'cancel', id, request_version }); return cancelWork(id, request_version) },
    coopRequestId: () => 'synthetic-refund-' + ++requestSequence,
    coopError: (error, fallback) => error.message || fallback, coopMoney: value => '¥' + value, coopDate: String
}
const pageScript = compiler.parse(source).descriptor.scriptSetup.content + '\nexport { openRefund, readRefund, closeRefund, submitRefund, refreshRefund, withdrawRefund, refundVisible, refundOrder, refundDetail, refundLoading, refundBusy, refundError, refundReadRequired, busyId, rows, status, filter, query, revision, pagingRef };'
const page = execute(pageScript, { vue: Vue, '@dcloudio/uni-app': { onShow: cb => lifecycle.show = cb, onHide: cb => lifecycle.hide = cb, onLoad: cb => lifecycle.load = cb }, '@/utils/common': { getToken: () => member, getSiteId: () => site }, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack() {} }) }, '../../api/cooperation': api, '../../utils/cooperation-payment-orders': utility, '../../utils/cooperation-paging': loadMobileUtility('cooperation-paging'), '../../utils/mobile-ui': { cooperationButtonStyle: {} }, '../../utils/cooperation-navigation': { backCooperationTask() {} } }, { uni: { getStorageSync: () => site, showToast: options => toasts.push(options.title), showModal: options => dialogs.push(options) } })
lifecycle.load({}); lifecycle.show(); await Promise.resolve(); await Promise.resolve()
page.pagingRef.value = { completeByNoMore() {}, complete() {} }; await page.query(1, 20, page.revision.value)
check(page.status.value === 'unpaid' && JSON.stringify(listCalls[0]) === JSON.stringify({ status: 'unpaid', page: 1, limit: 20 }), 'default pending tab sends only status and pagination, without advanced filters or options reads')
page.filter('paid'); await page.query(1, 20, page.revision.value); check(page.status.value === 'paid' && listCalls.at(-1).status === 'paid' && Object.keys(listCalls.at(-1)).length === 3, 'paid tab resets page one with no refund, type, purpose or date filter')
page.filter('closed'); await page.query(1, 20, page.revision.value); check(page.status.value === 'closed' && listCalls.at(-1).status === 'closed', 'closed tab queries its own terminal order list')
const version = page.revision.value; page.filter('closed'); check(page.revision.value === version, 'repeated selected-tab tap does not trigger a second reload')

await page.openRefund({ id: 8, order_no: 'TEST-8', status: 'paid', amount: '99.00' })
check(reads.length === 1 && page.refundDetail.value.order_id === 8 && !page.refundReadRequired.value && !writes.length, 'opening the refund sheet only reads the original paid order and does not send money')
await page.submitRefund('短'); check(!dialogs.length && !writes.length && page.refundError.value.includes('4至500'), 'reason validation prevents incomplete requests')
const cancelled = page.submitRefund('测试申请退款'); await page.submitRefund('重复点击退款'); check(dialogs.length === 1 && page.refundBusy.value && !writes.length, 'confirmation dialog locks repeated taps before the write')
dialogs.pop().success({ confirm: false }); await cancelled; check(!page.refundBusy.value && !page.busyId.value && !writes.length, 'cancel confirmation leaves the original payment untouched')
const submitted = page.submitRefund('测试申请退款'); dialogs.pop().success({ confirm: true }); await submitted
check(writes.length === 1 && writes[0].payload.confirm === true && !('amount' in writes[0].payload) && !('channel' in writes[0].payload), 'member requests contain only confirmation, reason and idempotency key, not money or payment source')
check(page.refundDetail.value.status === 'pending' && toasts.at(-1).includes('等待平台审核') && !page.refundReadRequired.value, 'pending approval is shown as an application, not a successful refund')
await page.submitRefund('再次提交申请'); check(writes.length === 1, 'a returned pending request cannot create a second application')
const withdrawal = page.withdrawRefund(); dialogs.pop().success({ confirm: true }); await withdrawal
check(writes.at(-1).kind === 'cancel' && writes.at(-1).request_version === 'version-1' && toasts.at(-1) === '退款申请已撤回', 'member withdrawal uses the loaded original request version and confirms the terminal result')

detail = base(); await page.readRefund(); const before = writes.length
postWork = async () => { throw Error('结果未知，请核对原申请') }
const unknown = page.submitRefund('测试超时保留'); dialogs.pop().success({ confirm: true }); await unknown
const originalKey = writes.at(-1).payload.request_id
check(page.refundReadRequired.value && page.refundError.value.includes('原申请') && !page.refundBusy.value, 'unknown request result blocks another submission but never traps the user in busy state')
await page.submitRefund('不能直接重试'); check(writes.length === before + 1 && !dialogs.length, 'unknown write cannot be retried until the original request is read')
await page.readRefund(); postWork = async () => ({ data: { ...base(), status: 'pending', can_request: false, can_cancel: true, request_version: 'version-2' } })
const retry = page.submitRefund('核对后继续'); dialogs.pop().success({ confirm: true }); await retry
check(writes.at(-1).payload.request_id === originalKey, 'recovery reuses the same idempotency key after the server confirms no request, never a new refund identity')

detail = { ...base(), status: 'refunding', status_name: '退款处理中', can_request: false, can_refresh: true }; await page.readRefund(); const requestCount = writes.filter(item => item.kind === 'request').length
await page.refreshRefund(); check(writes.at(-1).kind === 'refresh' && page.refundDetail.value.status === 'refunding' && toasts.at(-1) === '退款处理中', 'refresh reads only original refund progress and never claims processing funds have arrived')
refreshWork = async () => ({ data: { ...detail, status: 'refunded', status_name: '已退款', can_refresh: false } }); await page.refreshRefund()
check(toasts.at(-1) === '渠道已确认退款' && !page.refundDetail.value.can_refresh && writes.filter(item => item.kind === 'request').length === requestCount, 'only a verified refunded response ends processing; queries create no refund application')
const finalWrites = writes.length; await page.refreshRefund(); await page.withdrawRefund(); check(writes.length === finalWrites, 'completed refund has no further financial or withdrawal actions')

let releaseOld; readWork = () => new Promise(resolve => { releaseOld = resolve }); const oldRead = page.openRefund({ id: 8, status: 'paid' }); page.closeRefund(); releaseOld({ data: base() }); await oldRead
check(!page.refundVisible.value && !page.refundLoading.value, 'closing the sheet invalidates an in-flight detail response and does not reopen it')
let releaseA, releaseB; readWork = id => new Promise(resolve => { if (id === 8) releaseA = resolve; else releaseB = resolve })
const a = page.openRefund({ id: 8, status: 'paid' }), b = page.openRefund({ id: 9, status: 'paid' }); releaseB({ data: { ...base(), order_id: 9 } }); await b; releaseA({ data: base() }); await a
check(page.refundDetail.value.order_id === 9, 'order A late response cannot overwrite active order B refund details')
readWork = async () => ({ data: { ...base(), order_id: 999 } }); await page.readRefund(); check(page.refundReadRequired.value && page.refundError.value.includes('原申请'), 'mismatched detail blocks all new financial actions')
readWork = async () => ({ data: base() }); await page.openRefund({ id: 8, status: 'paid' })
const beforeHide = writes.length, inactive = page.submitRefund('页面离开测试'); lifecycle.hide(); dialogs.pop().success({ confirm: true }); await inactive
check(writes.length === beforeHide, 'leaving during confirmation prevents an obsolete write')
lifecycle.show(); await Promise.resolve(); await Promise.resolve(); page.closeRefund(); readWork = () => new Promise(resolve => { releaseOld = resolve }); const crossSite = page.openRefund({ id: 8, status: 'paid' }); site = '100006'; lifecycle.show(); releaseOld({ data: base() }); await crossSite
check(!page.refundVisible.value && !page.refundDetail.value.order_id && !page.rows.value.length, 'switching site clears private refund information and rejects the old response')
member = ''; lifecycle.show(); const anonymousReads = reads.length; await page.openRefund({ id: 8, status: 'paid' }); check(reads.length === anonymousReads && !page.refundVisible.value, 'logged-out visitors cannot fetch member refund information')

const apiCalls = [], apiModule = execute(read('api/cooperation.ts'), { '@/utils/request': { default: { get: (...args) => apiCalls.push(['get', ...args]), post: (...args) => apiCalls.push(['post', ...args]) } } })
apiModule.cooperationOrderRefund(8); apiModule.requestCooperationOrderRefund(8, { confirm: true, reason: '测试', request_id: 'same-key' }); apiModule.refreshCooperationOrderRefund(8); apiModule.cancelCooperationOrderRefund(8, 'version-1')
check(apiCalls.map(item => item[1]).join('|') === 'hsx_lead/cooperation/orders/8/refund|hsx_lead/cooperation/orders/8/refund|hsx_lead/cooperation/orders/8/refund/refresh|hsx_lead/cooperation/orders/8/refund/cancel', 'real refund adapters retain the agreed endpoints without a mobile-only filter dictionary request')
console.log(`PASS ${checks} payment/refund mobile checks; actual Vue handlers, SFC/SCSS and API adapters with synthetic requests only. No live payments, refunds or notification sends.`)
