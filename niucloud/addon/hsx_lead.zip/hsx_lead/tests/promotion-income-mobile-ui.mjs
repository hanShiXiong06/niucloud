import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), root = path.resolve(plugin, '../../..')
const require = createRequire(path.join(root, 'uni-app/package.json')), Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc'), sass = require('sass')
const read = name => fs.readFileSync(path.join(plugin, 'uni-app', name), 'utf8')
let checks = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
function execute(source, deps, globals = {}) { const module = { exports: {} }; const output = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText; vm.runInNewContext('(function(require,module,exports){' + output + '\n})', { Number, String, Date, Math, Map, Set, Promise, console, ...globals })(name => { if (!(name in deps)) throw Error('Unexpected dependency ' + name); return deps[name] }, module, module.exports); return module.exports }
function deferred() { let resolve; const promise = new Promise(done => { resolve = done }); return { promise, resolve } }
const income = loadMobileUtility('cooperation-income'), orders = loadMobileUtility('cooperation-payment-orders'), paging = loadMobileUtility('cooperation-paging')
check(income.cooperationIncomeTypes.length === 4 && income.cooperationIncomeType('unknown') === 'all', 'only supported income types are accepted')
check(income.cooperationIncomeKey({ income_type: 'publisher', id: 1 }) !== income.cooperationIncomeKey({ income_type: 'membership', id: 1 }), 'different ledgers cannot collide on numeric IDs')
check(income.cooperationIncomeCredited({ status: 'settled' }) && !income.cooperationIncomeCredited({ status: 'held' }), 'pending and held rewards are not presented as credited money')
check(orders.cooperationPaymentOrderResumeUrl({ id: 2, purpose: 'membership', status: 'unpaid', can_pay: true }).endsWith('?payment_order_id=2'), 'membership resume targets the original order')
check(orders.cooperationPaymentOrderResumeUrl({ id: 3, purpose: 'commission', lead_id: 7, status: 'unpaid', can_pay: true }).includes('collaboration_id=7&payment_order_id=3'), 'commission resume preserves the original lead and payment IDs')
for (const row of [{ id: 2, purpose: 'membership', status: 'paid', can_pay: true }, { id: 2, purpose: 'membership', status: 'unpaid', can_pay: false }, { id: 2, purpose: 'membership', status: 'unpaid', can_pay: true, requires_manual_review: true }, { id: 2, purpose: 'commission', lead_id: 0, status: 'unpaid', can_pay: true }]) check(!orders.cooperationPaymentOrderResumeUrl(row), 'invalid or unresolved payments cannot obtain a resume URL')
let member = 'member-a', site = '100005', calls = [], result = async query => ({ data: { account: { available: '9.90', frozen: '0.00' }, entries: { data: [{ id: 1, income_type: query.income_type === 'all' ? 'membership' : query.income_type, status: 'settled', amount: '9.90' }], total: 2 } } })
const common = { getToken: () => member, getSiteId: () => site }, uni = { getStorageSync: () => site }
const hook = execute(read('composables/useCooperationIncome.ts'), { vue: Vue, '@/utils/common': common, '../api/cooperation': { coopError: (error, fallback) => error.message || fallback }, '../api/promotion': { promotionIncome: query => { calls.push(query); return result(query) } }, '../utils/cooperation-income': income }, { uni }).useCooperationIncome()
check(await hook.read(1, 20) && hook.ready.value && hook.account.value.available === '9.90', 'ordinary member loads the existing commission account without a merchant prerequisite')
check(calls[0].income_type === 'all' && calls[0].page === 1 && calls[0].limit === 20, 'type and pagination travel to the server')
result = async () => ({ data: { account: { available: '9.90' }, entries: { data: [{ id: 1, income_type: 'publisher', amount: '20.00' }], total: 2 } } })
await hook.read(2, 20); check(hook.rows.value.length === 2 && !hook.hasMore.value, 'pagination merges ledger-scoped records, not ambiguous numeric IDs')
const stale = deferred(); result = () => stale.promise; const oldRead = hook.read(1, 20)
hook.filter('maintenance'); result = async () => ({ data: { account: { available: '1.00' }, entries: { data: [{ id: 2, income_type: 'maintenance' }], total: 1 } } }); await hook.read(1, 20)
stale.resolve({ data: { account: { available: '999.00' }, entries: { data: [{ id: 99, income_type: 'membership' }], total: 1 } } }); await oldRead
check(hook.rows.value[0].income_type === 'maintenance' && hook.account.value.available === '1.00', 'stale reads from a previous type cannot overwrite the active filter')
site = '100006'; hook.resume(); check(!hook.ready.value && !hook.rows.value.length && !hook.account.value.available, 'changing sites clears all private account and ledger state')
result = async () => ({ data: {} }); await hook.read(1, 20); check(hook.error.value && !hook.ready.value, 'malformed responses are errors, not successful empty ledgers')
member = ''; const count = calls.length; check(await hook.read(1, 20) === false && calls.length === count, 'logged-out readers never call a member-only endpoint')

const compiled = ['components/cooperation/CoopIncomePanel.vue', 'components/cooperation/CoopPromotionPanel.vue', 'pages/wallet/index.vue', 'pages/orders/index.vue']
for (const relative of compiled) { const descriptor = compiler.parse(read(relative), { filename: relative }).descriptor; compiler.compileScript(descriptor, { id: 'income-test' }); const result = compiler.compileTemplate({ source: descriptor.template.content, filename: relative, id: 'income-test', compilerOptions: { expressionPlugins: ['typescript'] } }); check(result.errors.length === 0, relative + ' template compiles'); for (const style of descriptor.styles) if (style.lang === 'scss') sass.compileString(style.content, { logger: { warn() {} } }); check(fs.readFileSync(path.join(root, 'uni-app/src/addon/hsx_lead', relative), 'utf8') === read(relative), relative + ' mounted source matches plugin source') }
const wallet = read('pages/wallet/index.vue'), panel = read('components/cooperation/CoopIncomePanel.vue'), promotion = read('components/cooperation/CoopPromotionPanel.vue')
check(!wallet.includes('CooperationWorkbench') && wallet.includes('FrameworkTabbar') && wallet.includes('登录后查看收益'), 'income entry uses framework navigation and does not force store onboarding')
check(panel.includes('z-paging') && panel.includes('completeByNoMore') && panel.includes('ui.incomeType.value'), 'income supports native list refresh and paginated type filters')
check(panel.includes('/app/pages/member/apply_cash_out') && panel.includes("'cashOutAccountType', 'commission'") && !panel.includes('requestPayment'), 'withdrawal reuses the framework commission account without creating a new cash channel')
check(promotion.includes('data.current_rates') && promotion.includes('source.level_rates') && promotion.includes('openIncome'), 'promotion displays server-calculated role rates and opens the unified income page')
check(promotion.includes('不含押金和经验费') && promotion.includes('普通用户也能分享得佣'), 'service-fee-only and free promoter rules are visible')

// Execute the real order-page handlers with local transport/dialog doubles.
const lifecycle = {}, navigations = [], toasts = [], closeCalls = [], modal = []
let orderResult = { id: 8, purpose: 'membership', status: 'unpaid', can_pay: true }, closeResult = { id: 8, status: 'closed' }
member = 'member-a'; site = '100005'
const pageScript = compiler.parse(read('pages/orders/index.vue')).descriptor.scriptSetup.content + '\nexport { continuePayment, cancelOrder, busyId, rows };'
const page = execute(pageScript, { vue: Vue, '@dcloudio/uni-app': { onShow: cb => lifecycle.show = cb, onHide: cb => lifecycle.hide = cb, onLoad: cb => lifecycle.load = cb }, '@/utils/common': common, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack() {} }) }, 'z-paging/components/z-paging/z-paging.vue': { default: {} }, '../../components/cooperation/CoopTaskSheet.vue': { default: {} }, '../../components/cooperation/CoopState.vue': { default: {} }, '../../api/cooperation': { cooperationOrders: async () => ({ data: { data: [], total: 0 } }), cooperationOrder: async () => ({ data: orderResult }), closeCooperationOrder: async id => { closeCalls.push(id); return { data: closeResult } }, coopError: (error, fallback) => error.message || fallback, coopMoney: value => '¥' + value, coopDate: value => value }, '../../utils/cooperation-payment-orders': orders, '../../utils/cooperation-paging': paging, '../../utils/mobile-ui': { cooperationButtonStyle: {} }, '../../utils/cooperation-navigation': { backCooperationTask() {} } }, { uni: { ...uni, navigateTo: options => navigations.push(options.url), showToast: options => toasts.push(options.title), showModal: options => modal.push(options) } })
lifecycle.load({}); lifecycle.show()
await page.continuePayment({ id: 8, can_pay: true }); check(navigations[0] === '/addon/hsx_lead/pages/membership/index?payment_order_id=8', 'continue payment re-reads the original order before using the existing membership cashier route')
orderResult = { id: 8, status: 'paid', purpose: 'membership', can_pay: false }; await page.continuePayment({ id: 8, can_pay: true }); check(navigations.length === 1 && toasts.length === 1, 'late payment received by server cannot be paid again from a stale list')
const cancel = page.cancelOrder({ id: 8, order_no: 'TEST-8', amount: '99.00', can_close: true }); await page.cancelOrder({ id: 8, can_close: true }); check(modal.length === 1 && !closeCalls.length && page.busyId.value === 8, 'cancel confirmation locks repeated taps before any write')
modal.pop().success({ confirm: false }); await cancel; check(!closeCalls.length && !page.busyId.value, 'declining cancellation sends no write and releases the lock')
const confirmed = page.cancelOrder({ id: 8, order_no: 'TEST-8', amount: '99.00', can_close: true }); modal.pop().success({ confirm: true }); await confirmed; check(closeCalls.length === 1 && toasts.at(-1) === '付款单已取消', 'closed state is reported only after an explicit matching server response')
closeResult = { id: 8, status: 'paid', close_message: '已核实渠道收款，订单不能取消' }; const uncertain = page.cancelOrder({ id: 8, can_close: true }); modal.pop().success({ confirm: true }); await uncertain; check(toasts.at(-1) === closeResult.close_message, 'conflicting paid response explains the real channel result instead of claiming cancellation')
const afterHide = page.cancelOrder({ id: 8, can_close: true }); lifecycle.hide(); modal.pop().success({ confirm: true }); await afterHide; check(closeCalls.length === 2, 'leaving the page during confirmation prevents a stale cancel write')
check(fs.readFileSync(path.join(plugin, 'package/uni-app-pages.php'), 'utf8').includes('pages/orders/index') && fs.readFileSync(path.join(plugin, 'app/dict/diy/links.php'), 'utf8').includes('HSX_LEAD_PAYMENT_ORDERS'), 'native order page and DIY link are registered inside the plugin')
console.log(`PASS ${checks} promotion income and payment-order mobile checks. Actual hooks, page handlers and SFC/SCSS compiled with isolated transports; no real payment, cancellation or withdrawal.`)
