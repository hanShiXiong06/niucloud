import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.join(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), sass = require('sass'), { renderToString } = require('@vue/server-renderer')
const filename = path.join(plugin, 'uni-app/components/cooperation/CoopBusinessIcon.vue'), source = fs.readFileSync(filename, 'utf8'), descriptor = compiler.parse(source, { filename }).descriptor
let checks = 0
function check(value, message) { assert.ok(value, message); checks++ }
const script = compiler.compileScript(descriptor, { id: 'business-icon-test', inlineTemplate: true })
check(!compiler.compileTemplate({ source: descriptor.template.content, filename, id: 'business-icon-test', compilerOptions: { bindingMetadata: script.bindings } }).errors.length, 'actual symbol template compiles')
const js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText, module = { exports: {} }
vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Object })(key => { if (key === 'vue') return Vue; throw Error(key) }, module, module.exports)
const Icon = module.exports.default, iconDictionary = fs.readFileSync(path.resolve(plugin, '../../../uni-app/node_modules/uview-plus/components/u-icon/icons.js'), 'utf8')
async function html(props = {}) { const app = Vue.createSSRApp({ render: () => Vue.h(Icon, props) }); app.config.warnHandler = () => {}; app.component('u-icon', { props: ['name', 'size', 'color'], setup: p => () => Vue.h('i', { 'data-symbol': p.name, 'data-size': p.size, 'data-color': p.color }) }); return renderToString(app) }
for (const name of ['store', 'customer', 'order', 'stock', 'team', 'wallet', 'member', 'invite', 'connection']) {
    const result = await html({ name })
    const icons = [...result.matchAll(/data-symbol="([^"]+)"/g)].map(match => match[1])
    check(icons.length === 1 && icons.every(icon => iconDictionary.includes("'uicon-" + icon + "'")), name + ' uses one installed standard outline without doubled fill')
    check(result.includes('aria-hidden="true"') && !result.includes('role="button"') && !result.includes('tabindex='), name + ' does not create a competing action or screen-reader label')
}
const themed = await html({ name: 'store', color: '#378268', size: 'small', pressed: true })
check(themed.includes('color:#378268') && themed.includes('is-small') && themed.includes('is-pressed') && themed.includes('data-size="21"'), 'explicit tenant colour and compact size apply without changing the glyph')
const inherited = await html({ name: 'wallet' })
check(inherited.includes('var(--coop-icon-color, var(--primary-color, #526d8e))'), 'default stroke inherits the framework theme rather than fixing a blue/red brand')
check((await html({ name: 'customer', color: null })).includes('var(--coop-icon-color'), 'unfilled decoration colour safely falls back to the tenant theme')
check(!(await html({ name: 'constructor', disabled: true, pressed: true })).includes('is-pressed'), 'unknown prototype-looking name falls back safely and disabled never appears pressed')
check((await html({ name: 'not-a-business' })).includes('data-symbol="file-text"'), 'unknown names have a neutral order fallback')
const css = sass.compileString(descriptor.styles[0].content).css
check(css.includes('120ms') && css.includes('prefers-reduced-motion') && css.includes('transition: none') && !css.includes('animation:'), 'only a short press transition exists, with reduced motion and no continuous effects')
check(css.includes('width: 32px') && css.includes('width: 36px') && css.includes('width: 44px'), 'entry symbols stay compact at all three explicit sizes')
check(!source.includes('@tap') && !source.includes('emit(') && !source.includes('navigateTo') && !source.includes('https://'), 'the reusable symbol owns no business action, remote media or permission state')
check(!css.includes('linear-gradient') && !css.includes('box-shadow') && !css.includes('filter:'), 'linework and a neutral inset replace decorative gradients, glows and blur')
console.log(`PASS business symbol: ${checks} actual SFC/theme/installed-glyph/interaction checks; no API calls`)
