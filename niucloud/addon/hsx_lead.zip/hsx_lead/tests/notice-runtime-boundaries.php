<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\notice\{NoticeTaskRuntime,AccountNoticePolicyService,FinancialNoticeService};
use think\facade\Db;
$pdo=null;$schema='';$checks=0;
function noticeBoundary(bool$ok,string$label):void{global$checks;if(!$ok)throw new RuntimeException($label);$checks++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $configuration=Db::getConfig();$manager=new think\DbManager();$manager->setConfig($configuration);$app->instance('think\DbManager',$manager);
    noticeBoundary(Db::connect()->getPdo()===false,'fresh isolated connection has not created a PDO yet');
    noticeBoundary(NoticeTaskRuntime::inTransaction()===false&&Db::connect()->getPdo() instanceof PDO,'cold runtime explicitly probes the real connection instead of calling a method on false');
    Db::startTrans();try{noticeBoundary(NoticeTaskRuntime::inTransaction()===true,'transaction detection still sees an existing real business transaction');}finally{Db::rollback();}
    $group=(int)Db::name('site_group')->insertGetId(['group_name'=>'Package-only notice fixture','app'=>'["hsx_lead"]','addon'=>'[]']);
    Db::name('site')->where('site_id',$site)->update(['group_id'=>$group,'app'=>'[]','addons'=>'[]']);
    noticeBoundary(AccountNoticePolicyService::installed($site),'site granted solely through the framework package is recognized');
    (new AccountNoticePolicyService())->save(new Context($site,1),['enabled'=>true]);
    $dispatches=0;$runtime=new FinancialNoticeService(static function()use(&$dispatches){$dispatches++;throw new RuntimeException('No source exists; a send would be a regression');});
    $result=$runtime->recover(10);
    noticeBoundary($result['sites']===1&&$result['failed_sites']===0,'bounded global recovery discovers an enabled package-only site without direct app/addons JSON');
    noticeBoundary($result['reconstructed']===0&&$result['processed']===0&&$dispatches===0,'package discovery does not backfill history or invent source messages');
    noticeBoundary(Db::name('hsx_lead_notice_task')->count()===0&&Db::name('member_account_log')->count()===0,'boundary probes never change financial facts or create notification tasks');
    echo 'PASS '.$checks." cold-connection and package-entitlement checks; owned random local schema only, no external sends.\n";
}catch(Throwable$error){fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);$failed=true;}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit(!empty($failed)?1:0);
