<?php
declare(strict_types=1);

/** Explicit legacy offline receipt fixture. New confirmations use balancepay;
 * these existing paid records must retain their human-transfer refund contract.
 * Only called inside a fresh owned test schema; no gateway or transfer occurs. */
function mfLegacyReceipt(\addon\hsx_lead\app\service\Context $admin,array $order,string $reference,string $request): array
{
    $site=$admin->site;$id=(int)$order['id'];
    \leadAssertIsolated((string)\think\facade\Db::query('SELECT DATABASE() AS db')[0]['db']);
    $preview=(new \addon\hsx_lead\app\service\cooperation\ManualPaymentService($admin))->preview($id);
    $core=new \app\service\core\pay\CorePayService();
    $pay=$core->createByTrade($site,\addon\hsx_lead\app\service\cooperation\PaymentService::TRADE_TYPE,$id);
    $no=(string)$pay['out_trade_no'];$amount=(string)$order['amount'];$now=time();
    $hash=\addon\hsx_lead\app\service\cooperation\ManualPaymentService::referenceHash('payment','bank','Legacy fixture bank',$reference);
    $snapshot=['schema'=>\addon\hsx_lead\app\service\cooperation\ManualPaymentService::SCHEMA,'acknowledged'=>true,
        'source_fingerprint'=>$preview['source_fingerprint'],'source'=>['order_id'=>$id,'merchant_id'=>(int)$order['merchant_id'],'member_id'=>(int)$order['member_id'],'purpose'=>$order['purpose'],'amount'=>$amount]];
    $receipt=(int)\think\facade\Db::name('hsx_lead_manual_receipt')->insertGetId(['site_id'=>$site,'kind'=>'payment','order_id'=>$id,'target_order_id'=>$id,'member_id'=>$order['member_id'],
        'out_trade_no'=>$no,'request_id'=>$request,'method'=>'bank','account_label'=>'Legacy fixture bank','external_no'=>$reference,'reference_hash'=>$hash,'amount'=>$amount,
        'received_at'=>$now,'operator_uid'=>$admin->uid,'status'=>'processing','reason'=>'显式合成历史线下到账凭据','snapshot_json'=>\addon\hsx_lead\app\support\Data::json($snapshot),'create_time'=>$now,'update_time'=>$now]);
    $voucher='manual-receipt:'.$receipt;
    $snapshot['core_payment']=['out_trade_no'=>$no,'order_fingerprint'=>$preview['source_fingerprint'],'merchant_id'=>(int)$order['merchant_id'],'member_id'=>(int)$order['member_id'],'amount'=>$amount,'voucher'=>$voucher];
    \think\facade\Db::name('hsx_lead_manual_receipt')->where('site_id',$site)->where('id',$receipt)->update(['snapshot_json'=>\addon\hsx_lead\app\support\Data::json($snapshot)]);
    (new \app\service\core\paytype\CoreOfflineService())->pay(['site_id'=>$site,'out_trade_no'=>$no,'voucher'=>$voucher]);
    $core->paySuccess($site,['out_trade_no'=>$no,'type'=>\app\dict\pay\PayDict::OFFLINEPAY,'trade_no'=>$reference,'voucher'=>$voucher,'mch_id'=>substr(hash('sha256','Legacy fixture bank'),0,40)]);
    \addon\hsx_lead\app\service\cooperation\PaymentService::confirm(['site_id'=>$site,'trade_type'=>\addon\hsx_lead\app\service\cooperation\PaymentService::TRADE_TYPE,'trade_id'=>$id,'out_trade_no'=>$no]);
    \think\facade\Db::name('hsx_lead_manual_receipt')->where('site_id',$site)->where('id',$receipt)->update(['status'=>'posted']);
    $view=(new \addon\hsx_lead\app\service\cooperation\PaymentService(new \addon\hsx_lead\app\service\Context($site,0,(int)$order['member_id'])))->order($id);
    if($view['status']!=='paid'||$view['payment_type']!==\app\dict\pay\PayDict::OFFLINEPAY)throw new \RuntimeException('Explicit legacy fixture did not pass authoritative framework payment');
    return ['status'=>'posted','order'=>$view];
}
