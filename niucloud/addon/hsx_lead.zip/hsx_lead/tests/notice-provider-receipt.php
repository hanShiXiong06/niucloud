<?php
declare(strict_types=1);

// Actual framework drivers/listeners, synthetic transport and log store only.
namespace notice_receipt_test {
    final class Response {
        public array $body;
        public function __construct(array $body) { $this->body=$body; }
        public function toArray(): array { return $this->body; }
    }
    final class Client {
        public $response;
        public ?\Throwable $error=null;
        public int $calls=0;
        public function postJson($url,$params) {
            $this->calls++;
            if ($this->error) throw $this->error;
            return $this->response;
        }
    }
    final class Config {
        public function set($key,$value):void {}
    }
    final class Application {
        public $client;
        public function __construct($client){$this->client=$client;}
        public function getConfig(){return new Config();}
        public function setConfig($config):void {}
        public function createClient(){return $this->client;}
    }
}
namespace think\facade { final class Log { public static function write(...$args): void {} } }
namespace core\template {
    abstract class BaseTemplate {
        public function __construct(array $config=[]) { $this->initialize($config); }
        protected function initialize(array $config=[]) {}
    }
    final class TemplateLoader {
        public static $result;
        public static ?\Throwable $error=null;
        public function __construct(...$args) {}
        public function send(array $data) { if(self::$error)throw self::$error;return self::$result; }
    }
}
namespace app\service\core\weapp {
    final class CoreWeappService {
        public static $client;
        public static ?\Throwable $error=null;
        public static function appApiClient($site) { if(self::$error)throw self::$error;return self::$client; }
        public static function app($site) { if(self::$error)throw self::$error;return new \notice_receipt_test\Application(self::$client); }
    }
    final class CoreWeappConfigService { public function getWeappConfig($site):array{return ['app_id'=>'synthetic_app'];} }
}
namespace app\service\core\wechat {
    final class CoreWechatService {
        public static $client;
        public static ?\Throwable $error=null;
        public static function appApiClient($site) { if(self::$error)throw self::$error;return self::$client; }
        public static function app($site) { if(self::$error)throw self::$error;return new \notice_receipt_test\Application(self::$client); }
    }
}
namespace app\service\core\member {
    final class CoreMemberService {
        public static array $member=['weapp_openid'=>'synthetic_weapp','wx_openid'=>'synthetic_wechat','nickname'=>'synthetic'];
        public function getInfoByMemberId($site,$member):array{return self::$member;}
    }
}
namespace app\service\core\notice {
    final class CoreNoticeBindMerchantService { public function getInfo($id):array{return [];} }
    final class CoreNoticeLogService {
        public static array $logs=[];
        public function add($site,$data):void{self::$logs[]=$data;}
    }
}
namespace app\dict\notice { final class NoticeTypeDict {const WEAPP='weapp';const WECHAT='wechat';} }
namespace {
    use core\exception\NoticeDeliveryException;
    use core\template\NoticeReceipt;
    use core\template\TemplateLoader;
    use app\service\core\notice\CoreNoticeLogService;
    use app\service\core\member\CoreMemberService;
    $root=dirname(__DIR__,3);
    foreach (['core/exception/NoticeException.php','core/exception/NoticeDeliveryException.php','core/template/NoticeReceipt.php','core/template/NoticeTransport.php','core/template/Weapp.php','core/template/Wechat.php','app/listener/notice/Weapp.php','app/listener/notice/Wechat.php'] as $file) require $root.'/'.$file;
    $checks=0;
    function check(bool $ok,string $message):void{global $checks;$checks++;if(!$ok)throw new \RuntimeException($message);}
    function failure(callable $fn,string $state,string $code=''):void {
        try{$fn();throw new \RuntimeException('Expected typed failure');}
        catch(NoticeDeliveryException $e){check($e->deliveryStatus()===$state,'Wrong delivery state');check($e->providerCode()===$code,'Wrong provider code');check(strpos($e->getMessage(),'secret_marker')===false,'Raw provider message leaked');}
    }
    foreach(['weapp','wechat'] as $channel){
        foreach([0,'0'] as $code){$r=NoticeReceipt::accepted(['errcode'=>$code,'msgid'=>'123-abc'],$channel);check($r['accepted']===true&&$r['channel']===$channel&&$r['provider_id']==='123-abc','Explicit success receipt');}
        foreach([43101,47003,40003,40037,-1] as $code)failure(fn()=>NoticeReceipt::accepted(['errcode'=>$code,'errmsg'=>'secret_marker'],$channel),'rejected',(string)$code);
        foreach([[],['errcode'=>false],['errcode'=>0.0],['errcode'=>'ok'],['errcode'=>0,'error'=>'secret_marker']] as $invalid)failure(fn()=>NoticeReceipt::accepted($invalid,$channel),'unknown');
        check(NoticeReceipt::accepted(['errcode'=>0,'msgid'=>'secret_marker@host'],$channel)['provider_id']==='','Unsafe provider ID rejected');
        $client=new \notice_receipt_test\Client();$client->response=new \notice_receipt_test\Response(['errcode'=>0]);
        $service=$channel==='weapp'?\app\service\core\weapp\CoreWeappService::class:\app\service\core\wechat\CoreWechatService::class;
        $driver=$channel==='weapp'?new \core\template\Weapp(['site_id'=>100005]):new \core\template\Wechat(['site_id'=>100005]);
        $service::$client=$client;
        $params=['template_id'=>'template','openid'=>'openid','data'=>[],'page'=>'page','url'=>'','first'=>'','remark'=>''];
        $result=$driver->send($params);
        check($channel==='weapp'?($result['accepted']??false)===true:$result===$client->response,'Driver success contract retained');
        check($client->calls===1,'No duplicate submission');
        $client->response=new \notice_receipt_test\Response(['errcode'=>43101,'errmsg'=>'secret_marker']);
        failure(fn()=>$driver->send($params),'rejected','43101');
        $client->error=new \RuntimeException('secret_marker timeout');
        failure(fn()=>$driver->send($params),'unknown');
        check($client->calls===3,'No implicit retry after timeout');
        $service::$error=new \RuntimeException('secret_marker config');
        failure(fn()=>$driver->send($params),'not_submitted');
        check($client->calls===3,'Configuration error did not submit');
        $service::$error=null;

        $listener=$channel==='weapp'?new \app\listener\notice\Weapp():new \app\listener\notice\Wechat();
        $template=['is_weapp'=>1,'is_wechat'=>1,'receiver_type'=>1,'async'=>false,'weapp_template_id'=>'t','wechat_template_id'=>'t','weapp'=>['content'=>[]],'wechat'=>['content'=>[]]];
        $event=['site_id'=>100005,'key'=>'synthetic','vars'=>[],'to'=>['member_id'=>1],'template'=>$template];
        TemplateLoader::$result=$channel==='weapp'?NoticeReceipt::accepted(['errcode'=>0],$channel):new \notice_receipt_test\Response(['errcode'=>0]);
        check($listener->handle($event)===true,'Existing listener bool contract retained');
        $event['return_receipt']=true;
        check(($listener->handle($event)['accepted']??false)===true,'Opt-in explicit receipt');
        TemplateLoader::$error=new NoticeDeliveryException($channel,'rejected','47003','字段不符合模板要求');
        failure(fn()=>$listener->handle($event),'rejected','47003');
        check(end(CoreNoticeLogService::$logs)['result']==='字段不符合模板要求','Failed result stored in existing log');
        $event['template']['async']=true;
        failure(fn()=>$listener->handle($event),'rejected','47003');
        unset($event['return_receipt']);
        check($listener->handle($event)===true,'Legacy async log-only contract retained');
        TemplateLoader::$error=null;TemplateLoader::$result=null;$event['return_receipt']=true;
        failure(fn()=>$listener->handle($event),'unknown');
        CoreMemberService::$member=[];
        failure(fn()=>$listener->handle($event),'not_submitted');
        CoreMemberService::$member=['weapp_openid'=>'synthetic_weapp','wx_openid'=>'synthetic_wechat'];
    }
    $logSource=file_get_contents($root.'/app/service/core/notice/CoreNoticeLogService.php');
    check(preg_match_all('/content,\s*result/',$logSource)===2,'Existing result field exposed in log list/detail');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'Actual framework drivers and official listeners; synthetic HTTP, identities and log store; no external delivery'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}
