<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\CatalogConfigStorage as Storage;
use addon\hsx_lead\app\service\cooperation\ConfigService;
use think\facade\Db;

$checks=0;$failed=false;$pdo=null;$schema='';
function visitorCheck(bool$condition,string$label):void{if(!$condition)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $save=static function(array$value)use($site):void{Db::transaction(static function()use($site,$value):void{Db::name('site')->where('site_id',$site)->lock(true)->find();Storage::write($site,ConfigService::KEY,$value);});};
    $snapshot=static fn():array=>Db::name('sys_config')->order('id')->select()->toArray();
    visitorCheck(ConfigService::publicAccess($site)===['login_required'=>false,'erp_visible'=>true,'visitor'=>['enabled'=>false,'businesses'=>[]]],'missing configuration does not advertise default businesses as enabled');
    $secret='SECRET_PRIVATE_FIXTURE_NOT_PUBLIC';
    $config=['enabled'=>true,'listing_login_required'=>true,'erp_visible'=>false,'fee_percent'=>'99.00','provider_password'=>$secret,'contact_mobile'=>$secret,'membership_levels'=>[['secret'=>$secret]],'businesses'=>[
        ['key'=>'purchase','name'=>'二手机','dimension'=>'model','enabled'=>true,'options'=>[['title'=>$secret]],'fields'=>[['label'=>$secret]],'commission_minimum'=>$secret],
        ['key'=>'new_phone','name'=>' 新机 ','dimension'=>'brand','enabled'=>1,'options'=>[['id'=>$secret]]],
        ['key'=>'broadband','name'=>'宽带','dimension'=>'operator','enabled'=>'1'],
        ['key'=>'rent','name'=>'租机','dimension'=>'model','enabled'=>false],
        ['key'=>'repair','name'=>'维修','dimension'=>'model','enabled'=>'true'],
        ['key'=>'constructor','name'=>'危险键','dimension'=>'model','enabled'=>true],
        ['key'=>'purchase','name'=>'重复键不得覆盖','dimension'=>'model','enabled'=>true],
        ['key'=>'unsafe','name'=>'<script>','dimension'=>'model','enabled'=>true],
        ['key'=>'unsafe_dim','name'=>'未知维度','dimension'=>'html','enabled'=>true],
        ['key'=>'blank','name'=>' ','dimension'=>'model','enabled'=>true],
        ['key'=>'control','name'=>"bad\nname",'dimension'=>'model','enabled'=>true],
        ['key'=>['not_text'],'name'=>'坏键','dimension'=>'model','enabled'=>true],
        ['key'=>'long','name'=>str_repeat('字',101),'dimension'=>'model','enabled'=>true],
    ]];
    $save($config);$before=$snapshot();$access=ConfigService::publicAccess($site);
    $expected=[['key'=>'purchase','name'=>'二手机','dimension'=>'model'],['key'=>'new_phone','name'=>'新机','dimension'=>'brand'],['key'=>'broadband','name'=>'宽带','dimension'=>'operator']];
    visitorCheck($access===['login_required'=>true,'erp_visible'=>false,'visitor'=>['enabled'=>true,'businesses'=>$expected]],'visitor contract contains only valid enabled business keys, plain labels and known dimensions');
    visitorCheck(!str_contains(json_encode($access,JSON_THROW_ON_ERROR),$secret),'unknown/private/nested fields never leak through the anonymous projection');
    visitorCheck($snapshot()===$before,'anonymous presentation reads do not mutate saved business or directory configuration');
    visitorCheck(ConfigService::publicAccess($site+1)===['login_required'=>false,'erp_visible'=>true,'visitor'=>['enabled'=>false,'businesses'=>[]]],'another site cannot borrow the current tenant business metadata');
    $config['enabled']=false;$save($config);
    visitorCheck(ConfigService::publicAccess($site)['visitor']===['enabled'=>false,'businesses'=>[]],'disabled cooperation does not advertise actionable business entries');
    $config['enabled']='true';$save($config);
    visitorCheck(ConfigService::publicAccess($site)['visitor']===['enabled'=>false,'businesses'=>[]],'ambiguous enabled strings do not activate visitor services');
    $config['enabled']=true;$config['businesses']='malformed';$save($config);
    visitorCheck(ConfigService::publicAccess($site)['visitor']===['enabled'=>true,'businesses'=>[]],'malformed business lists do not borrow presets or expose raw values');
    $config['businesses']=[];
    for($i=0;$i<31;$i++)$config['businesses'][]=['key'=>'type_'.$i,'name'=>'业务'.$i,'dimension'=>'model','enabled'=>true,'options'=>[['secret'=>$secret]]];
    $save($config);$bounded=ConfigService::publicAccess($site)['visitor']['businesses'];
    visitorCheck(count($bounded)===30&&$bounded[29]['key']==='type_29','public projection is bounded to the same thirty-business contract as configuration');
    $source=file_get_contents(dirname(__DIR__).'/app/service/cooperation/ConfigService.php');
    $method=substr($source,strpos($source,'public static function publicAccess'),strpos($source,'public static function erpVisible')-strpos($source,'public static function publicAccess'));
    visitorCheck(substr_count($method,'CatalogConfigStorage::read(')===1&&!preg_match('/(?:new\s+|::)(?:PartnerService|MembershipCatalogService|ProviderChannelService|CatalogService)\b/',$method),'anonymous response shares one storage read without loading private bootstrap, member, ERP or full catalogs');
    $route=file_get_contents(dirname(__DIR__).'/app/api/route/cooperation.php');$cut=strpos($route,"Route::group('hsx_lead/cooperation'");
    visitorCheck(str_contains(substr($route,0,$cut),"Route::get('hsx_lead/cooperation/access'")&&str_contains(substr($route,$cut),'middleware(ApiCheckToken::class,true)'),'public presentation does not weaken authentication on business routes');
    $settings=file_get_contents(dirname(__DIR__).'/admin/views/cooperation/Settings.vue');
    visitorCheck(!str_contains($settings,'form.listing_login_required')&&!str_contains($settings,'进入时提示登录'),'administrator no longer sees a conflicting automatic login prompt control');
    $mounted=file_get_contents(dirname(__DIR__,4).'/admin/src/addon/hsx_lead/views/cooperation/Settings.vue');
    visitorCheck($mounted===$settings,'canonical and mounted administration source match');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'anonymous projection and private-route authentication; owned random localhost schema only; no external requests'],JSON_UNESCAPED_UNICODE),PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL public visitor access: '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
