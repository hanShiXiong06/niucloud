import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),sass=require('sass')
const {compile}=require('@vue/compiler-dom'),{renderToString}=require('@vue/server-renderer')
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++}
const utility=loadMobileUtility('cooperation-business-presentation'),rows=[{key:'purchase',name:'二手机'},{key:'broadband',name:'宽带'}]
const initial=JSON.stringify(rows),defaults=utility.presentBusinessEntries(rows)
check(defaults.length===2&&defaults.every(row=>row.iconMode==='css'&&!row.badge),'default enabled entries have visible CSS icons with no invented badges')
check(defaults[0].iconColor!==defaults[1].iconColor&&defaults[0].shape==='phone'&&defaults[1].shape==='wifi','each supported business has a distinct preset theme and CSS shape')
check(utility.presentBusinessEntries(rows,{items:{forged:{title:'伪造',enabled:true,url:'https://evil.test'}}}).length===2,'visual overrides cannot create or enable a business')
const styled=utility.presentBusinessEntries(rows,{items:{purchase:{title:'购买设备',iconMode:'image',image:'upload/icons/phone.png',badgeMode:'custom',badgeText:'热门业务超长文字123',iconColor:'#abc',titleColor:'#456',badgeColor:'#fff',badgeBgColor:'#f00',url:'https://evil.test',enabled:false}}})[0]
check(styled.name==='购买设备'&&styled.image==='upload/icons/phone.png'&&styled.badge.length===8,'names, uploaded images and bounded custom badges project from existing DIY JSON')
check(styled.iconColor==='#abc'&&styled.titleColor==='#456'&&styled.badgeBgColor==='#f00'&&!('url'in styled)&&!('enabled'in styled),'only safe presentation fields reach rendering')
for(const mode of ['css','original','library','image','none'])check(utility.presentBusinessEntries(rows,{items:{purchase:{iconMode:mode}}})[0].iconMode===mode,`supported icon mode ${mode}`)
for(const [mode,label]of [['hot','HOT'],['new','NEW'],['none','']])check(utility.presentBusinessEntries(rows,{items:{purchase:{badgeMode:mode}}})[0].badge===label,`badge ${mode} resolves predictably`)
check(utility.presentBusinessEntries(rows,{items:{purchase:{iconMode:'raw-css',icon:'<script>',iconColor:'url(https://evil.test)',badgeBgColor:'red;position:fixed'}}})[0].iconMode==='css','arbitrary code and unsupported visual modes fail closed')
check(utility.presentBusinessEntries(rows,{items:{purchase:{iconMode:'library',icon:'wallet'}}})[0].icon==='wallet','library icons use a fixed supported name, not an arbitrary CSS class')
for(const image of ['javascript:alert(1)','//evil.test/a.png','upload/../a.png','upload/%2e%2e/a.png','upload/a.png;position:fixed','data:image/png;base64,test'])check(utility.businessImage(image)==='',`reject unsafe image ${image}`)
check(utility.businessImage('https://images.example.test/phone.png?x=1')!==''&&utility.businessImage('addon/hsx_lead/diy/tabbar/home.png')!=='','valid uploaded or HTTP images remain configurable')
check(JSON.stringify(rows)===initial,'projection never rewrites source business metadata')
check(utility.businessPresentationLayout('slide')==='slide'&&utility.businessPresentationLayout('list')==='list'&&utility.businessPresentationLayout('bad')==='compact','layout is a bounded presentation enumeration')
check(utility.businessPresentationSize(100)===64&&utility.businessPresentationSize(-2)===24&&utility.businessPresentationSize('bad')===40,'icon sizes are bounded at runtime')
function execute(source,deps,globals={}){const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext('(function(require,module,exports){'+js+'})',{console,Math,Date,URL,Number,String,Array,Object,Set,Map,Promise,...globals})(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports);return module.exports}
function script(relative){const filename=path.join(plugin,relative),source=fs.readFileSync(filename,'utf8'),parsed=compiler.parse(source,{filename});check(!parsed.errors.length,relative+' parses');const compiled=compiler.compileScript(parsed.descriptor,{id:'business-ui'});check(!compiler.compileTemplate({filename,source:parsed.descriptor.template.content,id:'business-ui',compilerOptions:{bindingMetadata:compiled.bindings}}).errors.length,relative+' template compiles');if(parsed.descriptor.styles[0])check(!!sass.compileString(parsed.descriptor.styles[0].content).css,relative+' style compiles');return{source,script:compiled.content}}
const mobile=script('uni-app/components/cooperation/CoopBusinessNavigation.vue'),admin=script('admin/views/diy/components/edit-lead-business-navigation.vue')
let now=1000;class Clock extends Date{static now(){return now}}
const store=Vue.reactive({mode:''}),props=Vue.reactive({appearance:{layoutPreset:'slide',items:{}}}),navigations=[],feedback=[],hooks=[]
const mobileDeps={vue:{...Vue,onMounted:callback=>hooks.push(callback),onBeforeUnmount(){}},'@/app/stores/diy':{default:()=>store},'@/utils/common':{img:String,getToken:()=>'',getSiteId:()=>100005},'../../api/cooperation':{cooperationBootstrap(){throw Error('No real request allowed')},coopError:String},'../../utils/interaction-feedback':{interactionFeedback:value=>feedback.push(value)},'../../utils/cooperation-diy-style':loadMobileUtility('cooperation-diy-style'),'../../utils/cooperation-business-cache':loadMobileUtility('cooperation-business-cache'),'../../utils/diy-business-preview':loadMobileUtility('diy-business-preview'),'../../utils/cooperation-business-presentation':utility}
const runtime=execute(mobile.script,mobileDeps,{Date:Clock,uni:{navigateTo:row=>navigations.push(row)}}).default.setup(props,{expose(){}})
runtime.businesses.value=rows;runtime.publish('forged');check(!navigations.length&&!feedback.length,'unknown key cannot navigate or produce feedback')
runtime.publish('purchase');check(navigations.length===1&&navigations[0].url==='/addon/hsx_lead/pages/task/index?task=publish&business_type=purchase','ordinary tap has the fixed business destination')
runtime.touchStart({touches:[{clientX:100,clientY:20}]});runtime.touchMove({touches:[{clientX:75,clientY:20}]});runtime.touchEnd();runtime.publish('broadband');check(navigations.length===1,'horizontal swipe cannot accidentally publish a business')
now+=351;runtime.publish('broadband');check(navigations.length===2,'intentional tap works again after swipe settles')
runtime.scrolling();runtime.publish('purchase');check(navigations.length===2,'native scroll momentum suppresses a tap');now+=251
runtime.touchStart({touches:[{clientX:10,clientY:10}]});runtime.touchMove({touches:[{clientX:12,clientY:12}]});runtime.touchEnd();runtime.publish('purchase');check(navigations.length===3,'small finger jitter does not block an ordinary tap')
store.mode='decorate';runtime.publish('purchase');check(navigations.length===3&&feedback.length===3,'decoration previews never navigate or trigger haptics')
props.appearance.items={purchase:{title:'改后名称',badgeMode:'hot',iconMode:'library',icon:'wallet'}};check(runtime.entries.value[0].name==='改后名称'&&runtime.entries.value[0].badge==='HOT'&&runtime.entries.value[0].icon==='wallet','live changes in actual DIY appearance reproject immediately')
runtime.failedImage('upload/test.png');runtime.failedImage('upload/test.png');check(runtime.failedImages.value.length===1,'image failure fallback is stable and not a reload loop')
check(mobile.source.includes('top:2px;right:2px')&&mobile.source.includes('min-height:44px')&&!mobile.source.includes('top:-6px'),'badges stay within each scroll item and touch targets remain usable')
const preview=execute(fs.readFileSync(path.join(plugin,'admin/composables/diyBusinessPreview.ts'),'utf8'),{}),navigation=execute(fs.readFileSync(path.join(plugin,'admin/composables/navigation.ts'),'utf8'),{})
const user=Vue.reactive({siteInfo:{site_id:100005},rules:['hsx_lead_cooperation_config']}),saved={componentName:'LeadBusinessNavigation',title:'原有标题',items:{purchase:{title:'原有业务',badgeMode:'hot'},hidden:{title:'保留未知配置'}},unknown:'保留扩展'},diy=Vue.reactive({editTab:'content',value:[saved],get editComponent(){return this.value[0]}}),mounted=[],unmounted=[];let reads=0
const editor=execute(admin.script,{vue:{...Vue,onMounted:callback=>mounted.push(callback),onBeforeUnmount:callback=>unmounted.push(callback)},'@/stores/modules/diy':{default:()=>diy},'@/stores/modules/user':{default:()=>user},'../../../api/cooperation':{getCooperationConfig:async()=>{reads++;return{data:{businesses:[...rows.map(row=>({...row,enabled:true})),{key:'disabled',name:'未启用',enabled:false}]}}}},'../../../composables/navigation':navigation,'../../../composables/diyBusinessPreview':preview}).default.setup({},{expose(){}})
mounted.forEach(callback=>callback());await Promise.resolve();await Vue.nextTick();await Promise.resolve()
check(reads===1&&editor.businesses.value.length===2&&!editor.businesses.value.some(row=>row.key==='disabled'),'editor previews only actual enabled business metadata via the existing authorized config read')
check(diy.editComponent.title==='原有标题'&&diy.editComponent.items.purchase.title==='原有业务'&&diy.editComponent.unknown==='保留扩展','opening editor preserves saved text, item visuals and unrelated extension fields')
const adminTemplate=compiler.parse(admin.source).descriptor.template.content,adminRender=new Function('Vue',compile(adminTemplate,{mode:'function',prefixIdentifiers:true}).code)(Vue)
async function adminHtml(){const app=Vue.createSSRApp({setup:()=>({...editor}),render:adminRender});app.config.warnHandler=()=>{};for(const name of new Set([...adminTemplate.matchAll(/<(el-[a-z-]+|UploadImage|DiyAppearanceFields)\b/g)].map(match=>match[1])))app.component(name,{setup(_props,{slots}){return()=>Vue.h('div',slots.default?.())}});return renderToString(app)}
const tabTag=(html,name)=>html.match(new RegExp('<div[^>]*class="business-'+name+'-tab"[^>]*>'))?.[0]||''
let html=await adminHtml();check(!tabTag(html,'content').includes('display:none')&&tabTag(html,'style').includes('display:none'),'actual content-tab render hides shared appearance and framework background fields')
diy.editTab='style';html=await adminHtml();check(tabTag(html,'content').includes('display:none')&&!tabTag(html,'style').includes('display:none'),'actual style-tab render hides content and per-business editing fields')
editor.patchItem('purchase','badgeMode','new');check(diy.editComponent.items.purchase.title==='原有业务'&&diy.editComponent.items.purchase.badgeMode==='new'&&diy.editComponent.items.hidden.title==='保留未知配置','single-item changes are sparse and preserve other saved item settings')
editor.patchItem('disabled','title','不应新增');editor.patchItem('purchase','url','https://evil.test');check(!diy.editComponent.items.disabled&&!diy.editComponent.items.purchase.url,'editor cannot create disabled entries or write arbitrary destinations')
user.rules=[];await Vue.nextTick();await Promise.resolve();editor.patchItem('purchase','title','不允许');check(diy.editComponent.items.purchase.title==='原有业务'&&editor.businesses.value.length===0&&reads===1,'permission loss clears preview and cannot change item settings or perform unauthorized reads')
unmounted.forEach(callback=>callback())
check(admin.source.includes('<UploadImage')&&admin.source.includes('<slot name="style"')&&!admin.source.includes('<DiyAppearanceFields'),'editor reuses framework uploader and native background controls, exposing only business-applicable style fields')
check(!editor.styleColors.some(row=>row.key==='buttonColor'||row.key==='buttonTextColor')&&!editor.styleSizes.some(row=>row.key==='buttonRadius')&&mobile.source.includes('gap:var(--lead-diy-row-gap')&&mobile.source.includes('border-radius:var(--lead-diy-item-radius'),'navigation has no dead CTA controls and consumes its actual spacing/radius fields')
const consumers={titleColor:'--lead-diy-title',textColor:'business.titleColor',iconColor:'business.iconColor',subtleColor:'--lead-diy-subtle',borderColor:'--lead-diy-border',titleSize:'--lead-diy-title-size',textSize:'--lead-diy-text-size',contentPadding:'--lead-diy-content-padding',rowGap:'--lead-diy-row-gap',itemRadius:'--lead-diy-item-radius'}
for(const field of [...editor.styleColors,...editor.styleSizes])check(!!consumers[field.key]&&mobile.source.includes(consumers[field.key]),`visible style field ${field.key} has an actual mobile rendering consumer`)
console.log(`PASS ${checks} business navigation presentation checks; actual helper + SFC setup and style compilation, synthetic config only; no browser, API transport, database or persisted DIY writes.`)
