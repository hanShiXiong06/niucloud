<?php
declare(strict_types=1);

/** Pure contracts by default; optional synthetic lifecycle in a process-owned random local schema. */
if (PHP_SAPI !== 'cli') exit("CLI only\n");
$isolated = in_array('--isolated-local-mysql', $argv, true);
foreach (['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable network functions before testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require_once dirname(__DIR__, 3) . '/vendor/autoload.php';
require __DIR__.'/membership-fixtures.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{BusinessService, ConfigService, CooperationService, PartnerService, PaymentService, Rules, Store};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\PayDict;
use core\exception\CommonException;
use think\facade\Db;

$checks = 0;
function phoneServiceCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function phoneServiceDenied(callable $work, string $label): void
{
    try { $work(); } catch (CommonException $error) { phoneServiceCheck(true, $label); return; }
    throw new RuntimeException('Expected safe rejection: ' . $label);
}

function phoneServicePure(): void
{
    $defaults = BusinessService::defaults();
    $byKey = array_column($defaults, null, 'key');
    phoneServiceCheck(array_column($defaults, 'key') === ['purchase','new_phone','rent','exchange','broadband','repair','home_recycle'], 'existing business order is preserved and phone-service presets are appended');
    phoneServiceCheck($byKey['exchange']['name'] === '二手机置换' && count(array_filter($defaults, static fn(array $row): bool => $row['key'] === 'exchange')) === 1, 'exchange keeps one stable business key');
    foreach (['repair','home_recycle'] as $key) {
        phoneServiceCheck($byKey[$key]['enabled'] === false && $byKey[$key]['dimension'] === 'model' && $byKey[$key]['commission_minimum'] === '100.00', 'new service is model-based, configurable and initially disabled');
    }
    $valid = array_column(BusinessService::validate($defaults), null, 'key');
    phoneServiceCheck($valid['home_recycle']['fields'][0]['key'] === 'pickup_address' && $valid['home_recycle']['fields'][0]['type'] === 'address' && $valid['home_recycle']['fields'][0]['required'], 'home collection includes its required address field');
    phoneServiceCheck($valid['repair']['fields'][0]['type'] === 'text' && $valid['repair']['fields'][0]['required'], 'repair includes required fault description');
    phoneServiceCheck(BusinessService::formValues($valid['home_recycle'], ['pickup_address' => '  科技园东门，电话联系  ']) === ['pickup_address' => '科技园东门，电话联系'], 'address is a trimmed plain scalar, not coordinates');
    phoneServiceCheck(mb_strlen(BusinessService::formValues($valid['home_recycle'], ['pickup_address' => str_repeat('址', 300)])['pickup_address']) === 300, 'address accepts at most 300 characters');
    foreach ([[], ['pickup_address'=>''], ['pickup_address'=>'   '], ['pickup_address'=>str_repeat('址',301)], ['pickup_address'=>'<img src=x>'], ['pickup_address'=>"address\ncontrol"], ['pickup_address'=>"address\n"], ['pickup_address'=>['latitude'=>1]]] as $input) {
        phoneServiceDenied(static fn() => BusinessService::formValues($valid['home_recycle'], $input), 'required address rejects blank, oversized, HTML, control or structured data');
    }
    $business = $byKey['repair'];
    $business['fields'][0]['placeholder'] = '  描述故障现象  ';
    $business['fields'][] = ['key'=>'optional_text','label'=>'其他说明','type'=>'text','required'=>false,'placeholder'=>''];
    $business = BusinessService::validate([$business])[0];
    phoneServiceCheck($business['fields'][0]['placeholder'] === '描述故障现象' && $business['fields'][1]['placeholder'] === '', 'field placeholders are optional, trimmed and may be empty');
    foreach ([str_repeat('字',121), '<b>hint</b>', "hint\n", [], null, 12] as $placeholder) {
        $bad = $business; $bad['fields'][0]['placeholder'] = $placeholder;
        phoneServiceDenied(static fn() => BusinessService::validate([$bad]), 'unsafe or invalid placeholder rejected');
    }
    $global = ['fee_percent'=>'10.00','fee_minimum'=>'9.90','fee_confirmed'=>true];
    phoneServiceCheck(BusinessService::feeRules($business, $global) === ['commission_minimum'=>'100.00','fee_percent'=>'10.00','fee_minimum'=>'9.90','fee_confirmed'=>true], 'a business without override inherits global fees');
    $business['fee_override'] = true; $business['fee_percent'] = '12.50'; $business['fee_minimum'] = '8.00';
    $business = BusinessService::validate([$business])[0];
    $snapshot = BusinessService::snapshot($business, $global, ['fault_detail'=>'不开机']);
    phoneServiceCheck($snapshot['fee_percent'] === '12.50' && $snapshot['fee_minimum'] === '8.00' && $snapshot['form_values']['fault_detail'] === '不开机', 'snapshot freezes business-specific fees and submitted fields');
    phoneServiceCheck(Rules::split(10000, $snapshot) === ['amount'=>'100.00','fee_amount'=>'12.50','net_amount'=>'87.50'], 'integer-cent settlement applies the business-specific split');
    $changed = $global; $changed['fee_percent'] = '50.00';
    phoneServiceCheck(Rules::split(10000, $snapshot)['fee_amount'] === '12.50' && BusinessService::feeRules($business, $changed)['fee_percent'] === '12.50', 'later global changes do not reprice a frozen or overridden rule');
    $snapshotUnconfirmed = BusinessService::snapshot($business, array_replace($global, ['fee_confirmed'=>false]), []);
    phoneServiceDenied(static fn() => Rules::split(10000, $snapshotUnconfirmed), 'an override never bypasses global fee confirmation');
    foreach (['0.00','-1.00','0.001','100000000.00',true] as $amount) {
        $bad = $business; $bad['commission_minimum'] = $amount;
        phoneServiceDenied(static fn() => BusinessService::validate([$bad]), 'every business minimum enforces positive cents and account precision');
    }
    foreach ([['fee_percent','100.00'],['fee_percent','-1'],['fee_percent',true],['fee_minimum','100.00'],['fee_minimum','100000000.00']] as [$key,$value]) {
        $bad = $business; $bad[$key] = $value;
        phoneServiceDenied(static fn() => BusinessService::validate([$bad]), 'business override validates ratio, floor and account precision');
    }
    $bad = $business; $bad['fee_override'] = 'yes';
    phoneServiceDenied(static fn() => BusinessService::validate([$bad]), 'override switch cannot silently coerce arbitrary text');
    $business['fee_override'] = false;
    $business['fee_percent'] = '99.00'; $business['fee_minimum'] = '90.00';
    $inherited = BusinessService::validate([$business])[0];
    phoneServiceCheck(!array_key_exists('fee_percent',$inherited) && !array_key_exists('fee_minimum',$inherited) && BusinessService::feeRules($inherited, $global)['fee_percent'] === '10.00', 'disabled override cannot leak stale local values into global inheritance');
    $tiny = $business; $tiny['commission_minimum'] = '0.01'; $tiny['fee_override'] = true; $tiny['fee_percent'] = '0.00'; $tiny['fee_minimum'] = '0.00';
    phoneServiceCheck(BusinessService::validate([$tiny])[0]['commission_minimum'] === '0.01', 'one cent is the smallest valid business commission with a valid fee rule');
    $tiny['fee_percent'] = '99.99';
    phoneServiceDenied(static fn() => BusinessService::validate([$tiny]), 'percentage rounding cannot consume the entire minimum commission');
}

function phoneServiceLifecycle(): void
{
    require_once __DIR__ . '/bootstrap.php';
    $pdo = null; $schema = '';
    try {
        [$app,$pdo,$schema,$site] = leadBoot(); leadAssertIsolated($schema);
        leadMembershipSeed($site);
        Db::name('member_level')->where('site_id',$site)->where('level_id',704)->update(['level_benefits'=>leadMembershipDefinition(704,4,10,false,['all_models'=>true])['level_benefits']]);
        $official = file_get_contents(dirname(__DIR__,3) . '/app/install/source/database.sql');
        foreach(['pay','pay_refund'] as $table){if (!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si', $official, $matches)) throw new RuntimeException('Missing official pay fixture DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$matches[0]));}
        $tables = Db::query('SHOW TABLES');
        $settings = new ConfigService(new Context($site,1));
        $config = $settings->get();
        phoneServiceCheck(!isset($config['business_presets']), 'ordinary runtime configuration does not contain response-only presets');
        // A site that explicitly chose only its original five must keep that choice.
        $config['businesses'] = array_slice($config['businesses'],0,5);
        $settings->save($config);
        phoneServiceCheck(count($settings->get()['businesses']) === 5, 'reading config never force-merges or enables missing presets');
        $request = new \app\Request(); $request->siteId($site); $request->uid(1); $request->username('Isolated tester'); $request->appType('site');
        $app->instance('request',$request);
        $controller = new \addon\hsx_lead\app\adminapi\controller\Cooperation($app);
        $response = $controller->config()->getData()['data'];
        phoneServiceCheck(count($response['business_presets']) === 7 && count($response['businesses']) === 5, 'admin GET exposes available presets separately from selected businesses');
        $config['enabled'] = true; $config['publishing_required'] = false; $config['fee_confirmed'] = true;
        $config['businesses'] = BusinessService::defaults();
        foreach ($config['businesses'] as &$business) {
            if (in_array($business['key'],['repair','home_recycle'],true)) $business['enabled'] = true;
            if ($business['key'] === 'home_recycle') { $business['fee_override'] = true; $business['fee_percent'] = '15.00'; $business['fee_minimum'] = '5.00'; }
        } unset($business);
        $config['business_presets'] = [['key'=>'must_not_persist']];
        $request = new \app\Request(); $request->siteId($site); $request->uid(1); $request->username('Isolated tester'); $request->appType('site'); $request->withGet($config);
        $app->instance('request',$request);
        $response = (new \addon\hsx_lead\app\adminapi\controller\Cooperation($app))->saveConfig()->getData()['data'];
        phoneServiceCheck(count($response['business_presets']) === 7 && $response['businesses'][6]['fee_percent'] === '15.00', 'admin save returns clean persisted settings plus server-owned presets');
        $persisted = Data::decode((string)Db::name('sys_config')->where('site_id',$site)->where('config_key',ConfigService::KEY)->value('value'));
        phoneServiceCheck(!array_key_exists('business_presets',$persisted), 'client cannot persist or replace the response-only preset list');
        $config = $settings->get();
        phoneServiceCheck($config['businesses'][6]['fields'][0]['type'] === 'address' && $config['businesses'][6]['fee_percent'] === '15.00', 'address metadata and business override survive actual save and read-back');
        $invalid = $config; $invalid['businesses'][6]['fee_minimum'] = '100.00';
        phoneServiceDenied(static fn() => $settings->save($invalid), 'invalid per-business fee cannot pass configuration saving');
        phoneServiceCheck($settings->get() === $config, 'invalid save cannot partially overwrite existing settings');
        $pubCtx = new Context($site,0,101); $recCtx = new Context($site,0,102); $pub = new CooperationService($pubCtx); $rec = new CooperationService($recCtx);
        $model = $pub->catalog(['business_type'=>'repair'])[0];
        $base = ['name'=>'Synthetic publisher','contact_name'=>'Fixture','mobile'=>'18800000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road'];
        $publisher = (new PartnerService($pubCtx))->saveProfile($base);
        $receiver = (new PartnerService($recCtx))->saveProfile(array_replace($base,['name'=>'Synthetic service shop','mobile'=>'18800000102','business_capabilities'=>[
            ['business_type'=>'repair','option_ids'=>[$model['id']]], ['business_type'=>'home_recycle','option_ids'=>[$model['id']]],
        ]]));
        Db::name('member')->insert(['site_id'=>$site,'member_id'=>104,'nickname'=>'Synthetic stock-only']);
        $stockOnly = (new PartnerService(new Context($site,0,104)))->saveProfile(array_replace($base,['name'=>'Stock-only highest-grade shop','mobile'=>'18800000104']));
        leadSetEntryDefinition($site,704);leadMembershipGrant($site,104,'ML704');
        $now = time();
        $connection = (int)Data::query('connection',$site)->insertGetId(['site_id'=>$site,'merchant_id'=>$stockOnly['id'],'provider'=>'soujike','enabled'=>1,'last_sync_status'=>'completed','last_sync_at'=>$now]);
        $run = (int)Data::query('sync_run',$site)->insertGetId(['site_id'=>$site,'merchant_id'=>$stockOnly['id'],'connection_id'=>$connection,'config_version'=>1,'status'=>'completed','finished_at'=>$now]);
        Data::query('connection',$site)->where('id',$connection)->update(['published_run_id'=>$run]);
        Data::query('inventory',$site)->insert(['site_id'=>$site,'merchant_id'=>$stockOnly['id'],'connection_id'=>$connection,'sync_run_id'=>$run,'source_key'=>'phone-services-stock-only','model'=>$model['title'],'brand'=>$model['brand'],'price'=>'1000.00','quantity'=>'1.000','saleable_quantity'=>'1.000','availability'=>'available','fetched_at'=>$now,'source_status_json'=>Data::json(['_inventory'=>['listing_status'=>'listed','stock_status'=>'in_stock','sale_state'=>'unsold']])]);
        $seed = ['customer_name'=>'Synthetic client','mobile'=>'13800000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'consent'=>true,'attachments'=>[],'demand_ids'=>[$model['id']]];
        phoneServiceDenied(static fn() => $pub->create($seed + ['business_type'=>'home_recycle','request_id'=>'phone-services-empty-address','form_values'=>[]]), 'server prevents home collection without address');
        phoneServiceDenied(static fn() => $pub->create($seed + ['business_type'=>'repair','request_id'=>'phone-services-empty-fault','form_values'=>[]]), 'server prevents repair without fault description');
        $repair = $pub->create($seed + ['business_type'=>'repair','request_id'=>'phone-services-repair','form_values'=>['fault_detail'=>'无法充电']]);
        $form = ['pickup_address'=>'科技园东门附近，电话联系'];
        $input = $seed + ['business_type'=>'home_recycle','request_id'=>'phone-services-home-recycle','form_values'=>$form];
        $home = $pub->create($input);
        phoneServiceCheck($home['form_values'] === $form && $home['fields'][0]['type'] === 'address' && $home['fee_percent'] === '15.00', 'published home collection exposes frozen address definition and rule');
        foreach ([$repair,$home] as $lead) {
            $external=array_values(array_filter($pub->stores([],(int)$lead['id'])['data'],static fn(array $row):bool=>empty($row['is_internal'])));
            $ids = array_map('intval',array_column($external,'id'));
            phoneServiceCheck($ids === [(int)$receiver['id']] && !in_array((int)$stockOnly['id'],$ids,true), 'service matching requires its own declared capability, not stock or all-model grade');
        }
        $config = $settings->get(); $config['fee_percent'] = '40.00'; $config['businesses'][6]['fee_percent'] = '30.00'; $config['businesses'][6]['commission_minimum'] = '200.00'; $config['businesses'][6]['fields'][0]['label'] = '新地址名称'; $settings->save($config);
        phoneServiceCheck($pub->create($input)['id'] === $home['id'] && $pub->detail((int)$home['id'])['fee_percent'] === '15.00', 'idempotent retry preserves original address, field names and fees after configuration changes');
        phoneServiceDenied(static fn() => $pub->create(array_replace($input,['form_values'=>['pickup_address'=>'Changed address']])), 'request replay cannot change an original collection address');
        $pub->assign((int)$home['id'],['merchant_id'=>$receiver['id'],'assignment_version'=>0]);
        $private = $rec->detail((int)$home['id']);
        phoneServiceCheck($private['mobile'] === '' && $private['form_values'] === [], 'receiver cannot read customer phone or collection address before acceptance');
        $rec->action((int)$home['id'],['action'=>'accept','assignment_version'=>1]);
        phoneServiceCheck($rec->detail((int)$home['id'])['form_values'] === $form, 'accepted assigned shop sees the required home collection location');
        $rec->action((int)$home['id'],['action'=>'deal','assignment_version'=>1]);
        $payments = new PaymentService($recCtx);
        $order = $payments->createOrder(['purpose'=>'commission','lead_id'=>$home['id'],'amount'=>'100.00','request_id'=>'phone-services-payment']);
        phoneServiceCheck($order['amount'] === '100.00' && $order['fee_amount'] === '15.00' && $order['net_amount'] === '85.00', 'commission payment uses frozen business-specific fees, not current global or business rules');
        $event = ['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>'PHONE_SERVICES_SYNTHETIC_RECEIPT'];
        Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'out_trade_no'=>$event['out_trade_no'],'money'=>'100.00','status'=>PayDict::STATUS_FINISH]);
        PaymentService::confirm($event); PaymentService::confirm($event);
        $paid = $pub->detail((int)$home['id']);
        phoneServiceCheck($paid['status'] === 'paid' && $paid['form_values'] === $form && $paid['fee_percent'] === '15.00', 'successful synthetic receipt completes lead and retains private address snapshot');
        phoneServiceCheck((string)Db::name('member')->where('site_id',$site)->where('member_id',101)->value('commission') === '85.00' && Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->count() === 1, 'duplicate callback credits publisher once with the correct remainder');
        phoneServiceCheck(Db::query('SHOW TABLES') === $tables, 'new phone services require no additional business tables');
        leadAssertIsolated($schema);
    } finally {
        if ($pdo instanceof PDO && $schema !== '') leadCleanup($pdo,$schema);
    }
}

try {
    phoneServicePure();
    if ($isolated) phoneServiceLifecycle();
    echo 'PASS phone-service contracts: ' . $checks . ' checks; ' . ($isolated ? 'owned random local schema and synthetic receipt only' : 'pure only, no database') . "; no network\n";
} catch (Throwable $error) {
    fwrite(STDERR,'FAIL phone-service contracts: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . "\n" . $error->getTraceAsString() . "\n");
    exit(1);
}
