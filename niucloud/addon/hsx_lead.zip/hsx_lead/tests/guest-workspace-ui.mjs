import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), sass = require('sass')
const { renderToString } = require('@vue/server-renderer')
const filename = path.join(plugin, 'uni-app/components/cooperation/CoopGuestWorkspace.vue')
const source = fs.readFileSync(filename, 'utf8'), parsed = compiler.parse(source, { filename })
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
check(parsed.errors.length === 0, 'guest workspace is a real parseable SFC')
const deps = {
    vue: Vue,
    './CoopServiceLineIcon.vue': { default: { props: ['shape', 'size'], setup: p => () => Vue.h('span', { 'data-shape': p.shape, 'data-size': p.size }) } },
    '../../utils/mobile-ui': loadMobileUtility('mobile-ui'),
    '../../utils/bundled-image': loadMobileUtility('bundled-image'),
    '../../utils/cooperation-business-presentation': loadMobileUtility('cooperation-business-presentation'),
    '../../static/cooperation/visuals/store-discovery.png': { default: '/owned-store.png' },
    '../../static/cooperation/visuals/delivery-capability.png': { default: '/owned-capability.png' }
}
function compile(inlineTemplate) {
    const script = compiler.compileScript(parsed.descriptor, { id: 'guest-workspace', inlineTemplate })
    const js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Object, Array, String, Number })(key => {
        if (key in deps) return deps[key]
        throw Error('Unexpected guest dependency: ' + key)
    }, module, module.exports)
    return module.exports.default
}
const Component = compile(true)
async function html(props) {
    const app = Vue.createSSRApp({ render: () => Vue.h(Component, props) })
    app.config.warnHandler = () => {}
    app.component('u-button', { props: ['text', 'disabled'], setup: p => () => Vue.h('button', { disabled: p.disabled }, p.text) })
    app.component('u-icon', { props: ['name'], setup: p => () => Vue.h('i', { 'data-icon': p.name }) })
    app.component('u-loading-icon', { setup: () => () => Vue.h('span', 'loading') })
    return renderToString(app)
}
const businesses = [{ key: 'purchase', name: '二手机', dimension: 'model' }, { key: 'repair', name: '手机维修', dimension: 'model' }]
for (const direction of ['outgoing', 'incoming']) {
    const result = await html({ direction, services: businesses, enabled: true })
    check(result.includes(direction === 'outgoing' ? '发布客户需求' : '登记门店交付能力'), direction + ' has a contextual primary action rather than a login wall')
    check(result.includes(direction === 'outgoing' ? '/owned-store.png' : '/owned-capability.png'), direction + ' uses owned purpose-specific artwork')
    check(result.includes('二手机') && result.includes('手机维修') && result.includes('2 项服务'), direction + ' displays only the supplied public business names')
    check(!result.includes('样例客户') && !result.includes('已有客户') && !result.includes('共 0 条'), direction + ' invents no customer records or private empty statistics')
    check(result.includes(direction === 'outgoing' ? '从需求到交付' : '从接单到成交'), direction + ' has a role-specific readable workflow')
}
const unknown = await html({ direction: 'outgoing', services: [] })
check(!unknown.includes('本站协作业务') && !unknown.includes('二手机'), 'older backend can show a real introduction without inventing enabled services')
const closed = await html({ enabled: false, services: [] })
check(closed.includes('协作服务暂未开放') && closed.includes('disabled'), 'closed service has no fake active CTA')
const failure = await html({ error: 'synthetic error', services: [] })
check(failure.includes('重新加载') && !failure.includes('synthetic error'), 'public lookup failure is retryable and does not expose raw internals')
const pending = await html({ loading: true, services: [] })
check(pending.includes('正在读取本站协作业务') && pending.includes('aria-busy="true"'), 'public business metadata has an explicit loading state')
const events = [], props = Vue.reactive({ direction: 'outgoing', services: businesses, enabled: true, loading: false, error: '' })
const state = compile(false).setup(props, { expose() {}, emit: (...args) => events.push(args) })
check(events.length === 0, 'creating the visitor component never starts login or emits a business action')
state.act('publish')
check(events.length === 1 && events[0][0] === 'action' && events[0][1].kind === 'publish', 'primary click is an explicit parent-owned business intent')
state.act('business', 'purchase')
check(events[1][1].business_type === 'purchase', 'business shortcut preserves its selected business context')
props.enabled = false; state.act('publish')
check(events.length === 2, 'disabled service cannot emit an actionable intent')
check(!/cooperationBootstrap|cooperationLeads|useLogin|request\.|navigateTo|setStorageSync|setInterval/.test(source), 'presentation owns neither credentials, private reads, navigation nor polling')
const css = sass.compileString(parsed.descriptor.styles[0].content).css
check(css.includes('min-height: 44px') && css.includes('min-height: 52px'), 'secondary and retry actions retain mobile-size touch targets')
check(css.includes('max-width: 340px') && css.includes('width: 33.3333%') && css.includes('min-width: 0'), 'narrow mobile screens wrap the business grid without shrinking text')
check(!css.includes('position: fixed') && !source.includes('<scroll-view'), 'guest presentation uses the page scroll owner, not a second fixed dock or nested scroller')
console.log(`PASS ${checks} guest workspace checks; actual SFC, scoped CSS and synthetic SSR; no APIs or authentication operations.`)
