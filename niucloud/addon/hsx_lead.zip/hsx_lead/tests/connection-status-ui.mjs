import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Actual mobile SFC setup with synthetic public responses. No HTTP, database,
// browser, ERP login, synchronization job, notification or storage writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const file=path.join(plugin,'uni-app/components/cooperation/CoopConnectionPanel.vue'),source=fs.readFileSync(file,'utf8'),parsed=compiler.parse(source,{filename:file})
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const equal=(actual,expected,label)=>{assert.deepEqual(JSON.parse(JSON.stringify(actual)),expected,label);checks++}
check(parsed.errors.length===0,'connection SFC parses')
const script=compiler.compileScript(parsed.descriptor,{id:'connection-status'})
check(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'connection-status',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length===0,'actual connection template compiles')
for(const style of parsed.descriptor.styles)check(compiler.compileStyle({source:style.content,filename:file,id:'connection-status',preprocessLang:style.lang,scoped:true}).errors.length===0,'connection scoped styles compile')
const copy=value=>JSON.parse(JSON.stringify(value))
function fixture(){
    let server={connected:true,provider:'synthetic',provider_name:'合成 ERP',enabled:true,interval_minutes:60,channel_enabled:true,last_sync_status:'completed',published_run_id:5,last_sync_at:100,
        auth_renewal:{automatic:true,ready:true,status:'automatic'},sync_progress:{run_id:5,status:'completed',published:true,complete:true,record_count:42,progress_known:true,progress_percent:100},recent_runs:[]},settingsError=null,starts=0,advances=0
    const writes=[],timers=new Map(),cleanup=[],events=[],props=Vue.reactive({show:true,page:true,profile:{},providers:[]});let timer=0
    const api={cooperationConnection:async()=>({data:copy(server)}),cooperationConnectionSettings:async input=>{writes.push(copy(input));if(settingsError)throw settingsError;server={...server,enabled:input.enabled,interval_minutes:input.interval_minutes};return{data:copy(server)}},
        cooperationSync:async()=>{starts++;server={...server,requires_sync_restart:false,last_sync_status:'completed',published_run_id:8,sync_progress:{run_id:8,status:'completed',published:true,record_count:3,complete:true}};return{data:{id:8,...server.sync_progress}}},
        cooperationSyncAdvance:async()=>{advances++;throw Error('A stale run must not be advanced')},cooperationSyncInfo:async()=>{throw Error('Unexpected detail read')},coopDate:value=>value?'合成时间':'尚未记录',coopError:(cause,fallback)=>cause?.message||fallback}
    const module={exports:{}},js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Date,Number,String,Math,Set,Map,JSON,Object,Promise,console,setTimeout:callback=>{timers.set(++timer,callback);return timer},clearTimeout:id=>timers.delete(id),uni:{showToast(){},showModal(){throw Error('No pause confirmation is permitted in this fixture')}}})(key=>key==='vue'?{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)}:key==='../../api/cooperation'?api:key==='../../utils/mobile-ui'?loadMobileUtility('mobile-ui'):key==='../../utils/connection-actions'?loadMobileUtility('connection-actions'):key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports)
    const state=module.exports.default.setup(props,{expose(){},emit:(...args)=>events.push(args)})
    return{state,writes,props,events,get server(){return server},set server(value){server=value},set settingsError(value){settingsError=value},get starts(){return starts},get advances(){return advances},dispose(){cleanup.forEach(fn=>fn())}}
}
const f=fixture(),s=f.state
await s.readState();check(s.currentSyncStatus.value==='completed'&&s.syncStateLabel.value==='货盘已更新','only a published completed run is shown as updated')
check(s.authorizationLabel.value==='已配置自动续登','connection renewal readiness remains distinct from sync completion')
equal(s.knownProgressPercent.value,100,'published complete run may display 100 percent')
f.server={...f.server,last_sync_status:'running',published_run_id:5,sync_progress:{run_id:6,status:'running',record_count:10,total_records:null,progress_known:false,progress_percent:null}}
await s.readState();equal(s.knownProgressPercent.value,null,'unknown source totals never invent a percentage');check(s.progressText.value.includes('已整理 10 条')&&!s.progressText.value.includes('/'),'partial saved records are not misrepresented as a total')
f.server={...f.server,last_sync_status:'interrupted',requires_sync_restart:true,sync_progress:{run_id:6,status:'running',record_count:10}}
await s.readState();check(s.currentSyncStatus.value==='interrupted'&&s.syncStateLabel.value==='需要重新同步','interrupted projection overrides a stale running progress object')
check(s.flow.value.primary==='sync','interruption retains one recoverable sync action')
f.server={...f.server,sync_progress:{run_id:6,status:'completed',published:false,record_count:10,complete:true,progress_known:true,progress_percent:100}};await s.readState();check(s.currentSyncStatus.value==='interrupted'&&s.knownProgressPercent.value===null,'unpublished completion is not shown as an updated 100-percent snapshot')
await s.sync();check(f.starts===1&&f.advances===0,'restart starts a fresh server-managed round instead of advancing the stale pointer')
f.server={...f.server,channel_enabled:false,recent_runs:[{id:8,status:'completed',is_current_snapshot:true,record_count:3}]};await s.readState()
check(s.currentSyncStatus.value==='paused'&&s.syncStateLabel.value.includes('暂停'),'current channel closure is visible')
check(s.logStatus(s.historyRows.value[0])==='同步完成','channel pause does not erase a historical successful result')
f.server={...f.server,channel_enabled:true,enabled:false,interval_minutes:60};await s.readState();s.selectInterval(1)
check(s.interval.value===30&&s.intervalDirty.value,'changing frequency creates an explicit unsaved setting')
f.server={...f.server,interval_minutes:120};await s.readState();check(s.interval.value===30&&s.intervalDirty.value,'background reads cannot overwrite the unsaved choice')
f.settingsError=Error('合成：保存失败');await s.saveSettings();check(s.interval.value===30&&s.intervalDirty.value&&s.error.value.includes('保存失败'),'failed save keeps the choice and a readable error')
f.settingsError=null;await s.saveSettings();equal(f.writes.at(-1),{enabled:false,interval_minutes:30},'saving frequency preserves the current disabled state')
check(!s.intervalDirty.value&&f.server.enabled===false&&f.server.interval_minutes===30,'only confirmed settings response clears the draft')
f.server={...f.server,channel_enabled:false,enabled:true};await s.readState();s.selectInterval(0);const before=f.writes.length;await s.saveSettings();check(f.writes.length===before&&s.intervalDirty.value,'saving interval cannot bypass a paused channel or silently enable it')
f.server={...f.server,channel_enabled:true,recent_runs:Array.from({length:14},(_,index)=>({id:100-index,status:index===0?'failed':'completed',record_count:index,message:'合成同步说明'})),recent_runs_total:20,recent_runs_has_more:true};await s.readState()
check(s.historyRows.value.length===3&&s.recentRunRows.value.length===10,'initial history is compact and its total is capped to returned recent rounds')
check(s.historyCaption.value==='最近 10 次','caption does not confuse visible three rows with total history')
s.historyExpanded.value=true;check(s.historyRows.value.length===10,'explicit expansion shows at most the ten returned rounds')
check(s.logTone(s.historyRows.value[0])==='warning'&&s.inventoryCount({record_count:0})==='0 条资料','failure and genuine zero-record result are distinct')
check(s.inventoryCount({})==='数量待确认','missing count is not fabricated as zero')
f.server={...f.server};delete f.server.recent_runs;await s.readState();check(!s.historyAvailable.value&&s.historyRows.value.length===0,'a missing history contract is not fabricated as a successful run')
check(source.includes('title="同步设置"')&&source.includes('title="授权账号"')&&!/u-collapse[^>]*\b(?:value|model-value|v-model)=/.test(source),'low-frequency settings and authorization start collapsed')
check(source.includes('v-if="intervalDirty"')&&source.includes('保存设置'),'save is exposed only for an explicit settings edit')
f.dispose()
console.log(`PASS ${checks} mobile connection status/log/settings checks; real Vue setup, synthetic public responses only.`)
