import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual plugin homepage lifecycle + framework exposed-ref contract. No browser,
// API, deployment files or business database reads/writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const {compile}=require('@vue/compiler-dom'),{renderToString}=require('@vue/server-renderer')
const filename=path.join(plugin,'uni-app/pages/index.vue'),parsed=compiler.parse(fs.readFileSync(filename,'utf8'),{filename})
assert.deepEqual(parsed.errors,[])
const script=compiler.compileScript(parsed.descriptor,{id:'homepage-refresh'})
assert.deepEqual(compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'homepage-refresh',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors,[])
const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
let checks=2
const check=(value,label)=>{assert.ok(value,label);checks++}
function fixture(){
    const module={exports:{}},redirects=[];let show,cleanup,groupRefreshes=0
    const diyStore=Vue.reactive({mode:'',global:{bottomTabBar:{isShow:true,designNav:{key:'hsx_lead'}}}})
    const diy={onLoad(){},onShow:callback=>{show=callback},onHide(){},onUnload(){},onPageScroll(){},getLoading:()=>false,pageStyle:()=>'',data:{global:diyStore.global,value:[]}}
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Promise,Set,setTimeout,clearTimeout})(key=>{
        if(key==='vue')return{...Vue,onBeforeUnmount:callback=>{cleanup=callback}}
        if(key==='@dcloudio/uni-app')return{onLoad(){}}
        if(key==='@/hooks/useDiy')return{useDiy:()=>diy}
        if(key==='@/app/stores/diy')return{default:()=>diyStore}
        if(key==='@/hooks/useShare')return{useShare:()=>({setShare(){}})}
        if(key==='@/utils/json')return{parseJsonValue:(_value,fallback)=>fallback}
        if(key==='@/utils/common')return{redirect:value=>redirects.push(value)}
        if(key.endsWith('.vue'))return{default:{}}
        if(key==='../utils/mobile-ui')return loadMobileUtility('mobile-ui')
        if(key==='../utils/diy-title')return loadMobileUtility('diy-title');throw Error('Unexpected dependency '+key)
    },module,module.exports)
    const state=module.exports.default.setup({},{expose(){}})
    return{state,diyStore,redirects,show:(data={share:{}})=>show(data),cleanup:()=>cleanup(),mount:component=>{state.groupRef.value={refresh(){groupRefreshes++},getFormRef:()=>({componentRefs:{diyLeadCooperationEntryRef:component}})}},groupReads:()=>groupRefreshes}
}
async function settle(){for(let index=0;index<5;index++){await Vue.nextTick();await Promise.resolve()}}
const selected=fixture();let selectedEntryReads=0
selected.mount([{refresh(){selectedEntryReads++}}]);selected.show({page:'/app/pages/member/index'});await settle()
check(selected.redirects[0]?.url==='/app/pages/member/index'&&selected.redirects[0]?.mode==='reLaunch'&&selected.groupReads()===0&&selectedEntryReads===0,'framework selected page redirects before refreshing the replaced homepage entry')
selected.show({value:'{}',page:'/ignored',share:{}});await settle()
check(selected.redirects.length===1&&selected.groupReads()===1,'a real component decoration is not replaced by its fallback page')
const page=fixture();let reads=1 // The real child already starts one onMounted read.
const entry={refresh(){reads++}}
page.mount([entry]);page.show();await settle()
check(reads===1&&page.groupReads()===1,'first page show leaves the initial business read to child onMounted, without duplicate bootstrap')
page.show();await settle()
check(reads===2&&page.groupReads()===2,'returning to the same homepage refreshes business names/enabled state through the exposed child ref')
page.mount(entry);page.show();await settle()
check(reads===3,'single-component refs work as well as framework v-for arrays')
page.mount([undefined,{},entry,entry]);page.show();await settle()
check(reads===4,'missing refs are skipped and duplicate instances are refreshed once')
page.state.groupRef.value=null;page.show();await settle()
check(reads===4,'unmounted group is safe during return')
page.state.groupRef.value={refresh(){},getFormRef(){throw Error('not mounted')}};page.show();await settle()
check(reads===4,'temporarily unavailable framework refs do not reject the page callback')
let release,pendingReads=0
page.mount([{refresh(){pendingReads++;return new Promise(resolve=>{release=resolve})}}])
page.show();await settle();page.show();await settle()
check(pendingReads===1,'consecutive return callbacks share the same pending child refresh')
release();await settle();page.show();await settle()
check(pendingReads===2,'a later return can read again after the previous refresh completes')
release();await settle()
page.mount([{refresh(){return Promise.reject(Error('synthetic read failed'))}}]);page.show();await settle()
check(true,'a child read failure does not become an unhandled page lifecycle rejection')
const leaving=fixture();let lateReads=0
leaving.show();leaving.mount([{refresh(){lateReads++}}]);leaving.show();leaving.cleanup();await settle()
check(lateReads===0,'a queued return refresh cannot run after page disposal')
const navPage=fixture(),render=new Function('Vue',compile(parsed.descriptor.template.content,{mode:'function',prefixIdentifiers:true}).code)(Vue)
const groupFilename=path.resolve(plugin,'../../../uni-app/src/addon/components/diy/group/index.vue')
const groupDescriptor=compiler.parse(fs.readFileSync(groupFilename,'utf8'),{filename:groupFilename}).descriptor
const groupRender=new Function('Vue',compile(groupDescriptor.template.content,{mode:'function',prefixIdentifiers:true}).code)(Vue)
async function navigationHtml(){
    const app=Vue.createSSRApp({setup:()=>({...navPage.state}),render})
    app.config.globalProperties.themeColor=()=>'';app.config.warnHandler=()=>{}
    app.component('tabbar',Vue.defineComponent({props:['addon'],setup:props=>()=>Vue.h('nav',{'data-addon':props.addon},'框架底部导航')}))
    app.component('loading-page',Vue.defineComponent({setup:()=>()=>Vue.h('span')}))
    app.component('diy-group',Vue.defineComponent({props:['data'],setup:props=>({data:props.data,diyStore:navPage.diyStore,diyGroup:{componentsScrollBool:{},showCopyright:{value:false}}}),render:groupRender}))
    return renderToString(app)
}
const normalHtml=await navigationHtml()
check((normalHtml.match(/data-addon="hsx_lead"/g)||[]).length===1,'actual framework group renders exactly one configured tabbar; plugin page does not duplicate it')
navPage.diyStore.mode='decorate';check(!(await navigationHtml()).includes('框架底部导航'),'editor preview does not mount interactive fixed navigation')
navPage.diyStore.mode='';navPage.diyStore.global.bottomTabBar.isShow=false;check(!(await navigationHtml()).includes('框架底部导航'),'the existing DIY bottom-navigation visibility switch is effective')
navPage.diyStore.global.bottomTabBar={isShow:true,designNav:{key:'custom-addon'}};check((await navigationHtml()).includes('data-addon="custom-addon"'),'the selected framework navigation key is respected rather than hardcoded')
console.log(`PASS ${checks} homepage return-refresh checks; real SFC lifecycle, synthetic exposed refs only; no browser/API/database/deployment operations.`)
