import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'

// Real SFC and request-state hook, synthetic transport/native-mount scheduling.
// No server, database, credentials, real notifications or payment operations.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const mobile = path.join(plugin, 'uni-app')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc')
let checks = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
function execute(source, dependencies = {}, globals = {}) {
    const module = { exports: {} }
    const javascript = ts.transpileModule(viteFixture(source), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + javascript + '})', { Date, Math, Number, String, Map, Set, Promise, JSON, console, ...globals })(key => {
        if (key in dependencies) return dependencies[key]
        if (key.endsWith('.vue')) return { default: {} }
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        if (key === '../../api/promotion') return {}
        throw new Error('Unexpected dependency ' + key)
    }, module, module.exports)
    return module.exports
}
const filename = path.join(mobile, 'components/cooperation/CooperationWorkbench.vue')
const source = fs.readFileSync(filename, 'utf8'), parsed = compiler.parse(source, { filename })
check(!parsed.errors.length, 'actual workbench parses')
const script = compiler.compileScript(parsed.descriptor, { id: 'cooperation-list-resume' }).content
check(parsed.descriptor.template.content.includes(':auto="true"'), 'the actual pager mounted lifecycle owns its initial read')
check(/<CoopGuestWorkspace\b[^>]*@action="guestAction"/s.test(parsed.descriptor.template.content), 'both public roles render the shared visitor workspace and wire its actual action event')
check(!script.includes('.isLoginCancelled('), 'public workbench has no dependency on the custom framework cancellation inspector')
async function settle() { for (let index = 0; index < 8; index++) { await Promise.resolve(); await Vue.nextTick() } }
function deferred() { let resolve; const promise = new Promise(done => { resolve = done }); return { promise, resolve } }
function fixture(direction = 'outgoing', initiallyLoggedIn = true) {
    let token = initiallyLoggedIn ? 'synthetic-member-a' : '', preloads = 0, subscriptions = 0
    const storage = new Map([['wap_site_id', 100005]]), calls = [], nativeMounts = []
    const controls = { read: async () => ({ data: { data: [{ id: 1 }], total: 1 } }), access: async () => ({ data: { login_required: false, erp_visible: true, services: [] } }), prepare: async () => true }
    const api = {
        cooperationPageUrls: { stores: '/addon/hsx_lead/pages/stores/index', deliveries: '/addon/hsx_lead/pages/workbench/index' },
        coopError: error => error.message,
        cooperationBootstrap: async () => { calls.push('bootstrap'); return { data: { profile: { id: token === 'synthetic-member-b' ? 8 : 7 }, config: { enabled: true }, providers: [], stats: {} } } },
        cooperationLeads: async query => { calls.push({ type: 'list', ...query }); return controls.read(query) },
        cooperationAccess: async () => { calls.push('access'); return controls.access() }
    }
    const common = { getSiteId:()=>100005, getToken: () => token }
    const hook = execute(fs.readFileSync(path.join(mobile, 'composables/useCooperation.ts'), 'utf8'), { vue: Vue, '@/utils/common': common, '../api/cooperation': api })
    const component = execute(script, {
        vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} }, '@/utils/common': common,
        // The official pre-extension hook exposes setLoginBack but not the
        // bespoke cancellation inspector. Entry pages must work with that API.
        '@/hooks/useLogin': { useLogin: () => ({ setLoginBack() { calls.push('login') } }) },
        '../../composables/useCooperationSubscribe': { useCooperationSubscribe:()=>({loading:Vue.ref(false), prepare() { preloads++; return controls.prepare() }, request() { subscriptions++ } }) },
        '../../api/cooperation': api, '../../composables/useCooperation': hook,
        '../../utils/cooperation-navigation': {}
    }, { uni: { getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, value), removeStorageSync: key => storage.delete(key), setNavigationBarTitle() {}, showToast() {}, showModal() {} } })
    const state = component.default.setup({ initialTab: direction === 'outgoing' ? 'stores' : 'deliveries', initialDirection: direction, initialId: 0, initialPaymentId: 0, initialInviter: 0, initialPromotion: false, initialPromotionTab: 'overview', initialBusinessType: '', task: '' }, { expose() {} })
    const stop = Vue.watch([state.leadListVisible, state.leadPagingRevision], ([visible, revision]) => {
        state.leadPagingRef.value = null
        if (!visible) return
        const query = state.leadPagingQuery.value
        nativeMounts.push(() => {
            // Vue/native never mounts an obsolete keyed instance.
            if (!state.leadListVisible.value || revision !== state.leadPagingRevision.value) return
            const pager = Vue.markRaw({ completions: [], scrollTop: 145,
                completeByNoMore(rows, noMore) { this.completions.push({ rows, noMore }); return Promise.resolve() },
                complete(value) { this.completions.push(value); return Promise.resolve() },
                reload() { return query(1, 20, 'reload') }
            })
            state.leadPagingRef.value = pager
            // This may happen while the page is hidden; the real handler must
            // ignore it and a later onShow must ensure a replacement first read.
            return query(1, 20, 'mounted')
        })
    }, { flush: 'sync' })
    return { state, calls, controls, setToken(value) { token = value }, get preloads() { return preloads }, get subscriptions() { return subscriptions },
        listCalls: () => calls.filter(value => value?.type === 'list'), bootstrapCalls: () => calls.filter(value => value === 'bootstrap'),
        async mount() { const queued = nativeMounts.splice(0); const pending = queued.map(work => work()); await settle(); return pending },
        stop
    }
}

for (const direction of ['outgoing', 'incoming']) {
    const cold = fixture(direction)
    const discovery = deferred(); cold.controls.prepare = () => discovery.promise
    await Promise.all([cold.state.initialize(), cold.state.initialize()])
    check(cold.state.ui.ready.value && !cold.state.leadPagingRef.value && cold.listCalls().length === 0, direction + ': bootstrap may finish before the native pager ref exists')
    check(cold.preloads === 1 && !cold.subscriptions, direction + ': pending optional discovery does not delay business initialization or automatically authorize')
    discovery.resolve(false)
    const plannedRevision = cold.state.leadPagingRevision.value
    await cold.state.initialize()
    check(cold.state.leadPagingRevision.value === plannedRevision, direction + ': repeated show while mounting does not invalidate the already planned first query')
    await cold.mount(); await settle()
    check(cold.listCalls().length === 1 && cold.bootstrapCalls().length === 1, direction + ': cold start reads the first page exactly once without manual refresh')
    check(cold.listCalls()[0].direction === direction && cold.state.leadFirstPageReady.value, direction + ': role direction is preserved and first-page completion is independent of bootstrap')
    cold.stop()

    const hidden = fixture(direction)
    await hidden.state.initialize()
    hidden.state.pausePage()
    await hidden.mount()
    check(hidden.listCalls().length === 0 && !hidden.state.leadFirstPageReady.value, direction + ': native mounted query arriving while hidden does not read private list data')
    const hiddenRevision = hidden.state.leadPagingRevision.value
    await Promise.all([hidden.state.initialize(), hidden.state.initialize()])
    check(hidden.state.leadPagingRevision.value === hiddenRevision + 1, direction + ': resume replaces one ignored initial query, even with concurrent show triggers')
    await hidden.mount(); await settle()
    check(hidden.listCalls().length === 1 && hidden.bootstrapCalls().length === 1, direction + ': show after hidden mounting recovers without another bootstrap or duplicate list read')
    hidden.stop()
}

const empty = fixture()
empty.controls.read = async () => ({ data: { data: [], total: 0 } })
await empty.state.initialize(); await empty.mount(); await settle()
check(empty.state.leadFirstPageReady.value && empty.state.ui.rows.value.length === 0, 'successful zero-row response is marked loaded, not confused with never queried')
const emptyRevision = empty.state.leadPagingRevision.value
empty.state.pausePage(); await empty.state.initialize(); await empty.mount()
check(empty.listCalls().length === 1 && empty.state.leadPagingRevision.value === emptyRevision, 'returning to a genuinely empty list preserves its loaded state without recurring reads')
empty.stop()

const pending = fixture(), oldRead = deferred(), recoveredRead = deferred()
pending.controls.read = () => oldRead.promise
await pending.state.initialize(); await pending.mount()
check(pending.state.ui.listLoading.value && pending.listCalls().length === 1, 'fixture pauses during a real outstanding first list request')
pending.state.pausePage(); oldRead.resolve({ data: { data: [{ id: 999 }], total: 1 } }); await settle()
equal(pending.state.ui.rows.value, [], 'hidden obsolete response does not populate the active identity')
pending.controls.read = () => recoveredRead.promise
const resuming = pending.state.initialize(); await settle()
check(pending.listCalls().length === 2 && pending.state.ui.listLoading.value, 'show replays the interrupted read exactly once')
const pendingRevision = pending.state.leadPagingRevision.value
const repeatedResume = pending.state.initialize(); await pending.mount()
check(pending.listCalls().length === 2 && pending.state.leadPagingRevision.value === pendingRevision, 'another show does not create a pager or third read while recovery is in flight')
recoveredRead.resolve({ data: { data: [{ id: 2 }], total: 1 } }); await Promise.all([resuming, repeatedResume]); await settle()
equal(pending.state.ui.rows.value.map(row => row.id), [2], 'only recovered first page is rendered')
check(pending.state.leadFirstPageReady.value && pending.listCalls().length === 2, 'recovered first page does not schedule an additional initial query')
pending.stop()

const failedRecovery = fixture(), interruptedFailure = deferred()
failedRecovery.controls.read = () => interruptedFailure.promise
await failedRecovery.state.initialize(); await failedRecovery.mount()
failedRecovery.state.pausePage()
interruptedFailure.resolve({ data: { data: [{ id: 999 }], total: 1 } }); await settle()
failedRecovery.controls.read = async () => { throw new Error('合成首查恢复失败') }
const failedRevision = failedRecovery.state.leadPagingRevision.value
await failedRecovery.state.initialize(); await failedRecovery.mount(); await settle()
check(failedRecovery.listCalls().length === 2 && failedRecovery.state.leadPagingRevision.value === failedRevision, 'an interrupted first read that explicitly fails on recovery is not mistaken for an unstarted read and automatically queried a third time')
check(!failedRecovery.state.leadFirstPageReady.value && failedRecovery.state.ui.listError.value === '合成首查恢复失败' && !failedRecovery.state.ui.listLoading.value, 'failed recovery preserves its retryable error and releases loading without claiming a successful first page')
check(failedRecovery.state.leadPagingRef.value.completions.includes(false) && failedRecovery.state.ui.rows.value.length === 0, 'failed recovery completes the pager as failed instead of hiding the error behind another initial load')
failedRecovery.stop()

const guest = fixture('incoming', false), access = deferred()
guest.controls.access = () => access.promise
const guestOpening = guest.state.initialize(); await settle()
check(guest.calls.length === 1 && guest.calls[0] === 'access', 'guest entry reads only the public access setting, not bootstrap or private lists')
check(guest.preloads === 0 && guest.subscriptions === 0, 'guest initialization does not discover private templates or request notification authorization')
guest.state.pausePage(); guest.setToken('synthetic-member-b')
await guest.state.initialize(); await guest.mount(); await settle()
access.resolve({ data: { login_required: true, erp_visible: true, services: [] } }); await guestOpening; await settle()
check(guest.bootstrapCalls().length === 1 && guest.listCalls().length === 1 && !guest.calls.includes('login'), 'login return supersedes a late public-setting response without re-prompting or dropping first list')
equal(guest.state.ui.profile.value.id, 8, 'login return initializes the current member, not the former guest state')
check(guest.preloads === 1 && guest.subscriptions === 0, 'login return independently preloads the mounted notification entry without opening authorization')
guest.stop()

for (const direction of ['outgoing', 'incoming']) {
    const visitor = fixture(direction, false)
    visitor.controls.access = async () => ({ data: { login_required: true, erp_visible: false, services: [] } })
    await visitor.state.initialize(); await settle()
    check(visitor.calls.length > 0 && visitor.calls.every(value => value === 'access'), direction + ': an enabled legacy login policy still leaves the public page browseable with a setLoginBack-only hook')
    check(!visitor.state.ui.error.value && visitor.bootstrapCalls().length === 0 && visitor.listCalls().length === 0, direction + ': missing isLoginCancelled does not become a runtime error or reveal private reads')
    await visitor.state.refresh(); await settle()
    check(visitor.calls.every(value => value === 'access'), direction + ': public refresh does not start login or request private data')
    visitor.state.guestAction({ kind: direction === 'outgoing' ? 'publish' : 'accept', business_type: 'purchase' })
    check(visitor.calls.filter(value => value === 'login').length === 1, direction + ': a real guest business action opens login using the original framework API')
    // Returning from a cancelled login is an ordinary public-page onShow.
    visitor.state.pausePage(); await visitor.state.initialize(); await settle()
    visitor.state.ui.direction.value = direction === 'outgoing' ? 'incoming' : 'outgoing'
    await visitor.state.initialize(); await settle()
    check(visitor.calls.filter(value => value === 'login').length === 1 && visitor.bootstrapCalls().length === 0 && visitor.listCalls().length === 0, direction + ': cancel/back, role switching and repeated show do not reopen login or request private lists')
    visitor.state.guestAction({ kind: direction === 'outgoing' ? 'stores' : 'customers' })
    check(visitor.calls.filter(value => value === 'login').length === 2, direction + ': another explicit user action can retry login after cancellation')
    visitor.stop()
}

for (const direction of ['outgoing', 'incoming']) {
    const logout = fixture(direction)
    await logout.state.initialize(); await logout.mount(); await settle()
    check(logout.state.ui.profile.value.id === 7 && logout.state.ui.rows.value.length === 1, direction + ': logout regression starts with a genuinely loaded private page')
    logout.state.pausePage(); logout.setToken('')
    logout.controls.access = async () => ({ data: { login_required: true, erp_visible: true } })
    await logout.state.initialize(); await settle()
    check(!logout.state.ui.loggedIn.value && !logout.state.ui.ready.value && !logout.state.ui.profile.value.id && logout.state.ui.rows.value.length === 0, direction + ': logout immediately clears the former identity and private records')
    check(!logout.state.ui.error.value && logout.bootstrapCalls().length === 1 && logout.listCalls().length === 1 && !logout.calls.includes('login'), direction + ': return after logout renders the public page with no hook error, private reload or forced login')
    logout.state.guestAction({ kind: 'publish' })
    check(logout.calls.filter(value => value === 'login').length === 1, direction + ': an explicit operation still offers login after logout')
    logout.stop()
}

{
    const visitor = fixture('outgoing', false), policy = deferred()
    visitor.controls.access = () => policy.promise
    const first = visitor.state.initialize(); await settle()
    visitor.state.pausePage()
    policy.resolve({ data: { login_required: true, erp_visible: true, services: [] } })
    await first; await settle()
    check(visitor.calls.every(value => value === 'access') && !visitor.state.ui.error.value, 'a public configuration arriving after back/hide cannot start a stale login flow')
    visitor.stop()
}

console.log(`PASS ${checks} role-list first-read/resume checks; actual SFC/hook, delayed native refs and synthetic transports only.`)
