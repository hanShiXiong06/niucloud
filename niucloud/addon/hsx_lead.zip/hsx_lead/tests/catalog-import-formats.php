<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions before isolated testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';

use addon\hsx_lead\app\service\{CatalogService, Context};
use addon\hsx_lead\app\service\cooperation\ConfigService;
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;

$checks = 0; $failed = false; $pdo = null; $schema = ''; $temporaryFiles = [];
function importCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function importReject(callable $operation, string $label): string
{
    try { $operation(); }
    catch (CommonException $error) { importCheck(true, $label); return $error->getMessage(); }
    throw new RuntimeException('Expected safe import refusal: ' . $label);
}

try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    $admin = new Context($site, 1); $settings = new ConfigService($admin); $catalog = new CatalogService($admin);
    $config = $settings->get();
    $config['enabled'] = true; $config['fee_confirmed'] = true; $config['publishing_required'] = false;
    $settings->save($config);
    foreach ($config['businesses'] as $business) $catalog->save(['business_type' => $business['key'], 'format' => 'json', 'content' => Data::json([[
        'id' => 'unchanged_' . $business['key'], 'title' => '既有目录_' . $business['key'],
        'brand' => '既有品牌', 'category_name' => '既有分类', 'path' => ['既有分类', $business['key']], 'aliases' => [],
    ]])]);
    $siblings = [];
    foreach ($settings->get()['businesses'] as $business) if ($business['key'] !== 'purchase') $siblings[$business['key']] = $business;
    $now = time();
    $merchant = (int) Db::name('hsx_lead_merchant')->insertGetId(['site_id' => $site, 'name' => 'Synthetic format merchant', 'member_id' => 101]);
    $lead = (int) Db::name('hsx_lead_collaboration')->insertGetId([
        'site_id' => $site, 'lead_no' => 'LC-IMPORT-FORMAT-FIXTURE', 'publisher_id' => $merchant,
        'request_id' => 'catalog-import-format-history', 'business_type' => 'purchase',
        'models_json' => '[{"id":"old","title":"既有客户所选型号"}]',
        'rule_json' => '{"commission_minimum":"100.00","fee_percent":"10.00","fee_confirmed":true}',
        'create_time' => $now, 'update_time' => $now,
    ]);
    $historicBefore = Db::name('hsx_lead_collaboration')->where('id', $lead)->find();
    $persisted = static function () use ($pdo, $site): array {
        $statement = $pdo->prepare('SELECT * FROM `lt_sys_config` WHERE site_id=? ORDER BY id');
        $statement->execute([$site]);
        return ['config' => $statement->fetchAll(PDO::FETCH_ASSOC), 'audit' => Db::name('hsx_lead_audit')->where('site_id', $site)->order('id')->select()->toArray()];
    };
    $assertSiblings = static function (string $label) use ($settings, $siblings): void {
        $current = [];
        foreach ($settings->get()['businesses'] as $business) if ($business['key'] !== 'purchase') $current[$business['key']] = $business;
        importCheck($current === $siblings, $label . ' preserves every other business and its fee/form/options');
    };
    $headers = ['一级分类', '二级分类', '三级分类', '名称', 'id', '品牌', '别名'];
    $titles = ['iPhone Duo', 'iPhone 18 Pro Max', 'iPhone 18 Pro', 'iPhone 17 Pro Max'];
    $rawRows = [];
    foreach ($titles as $index => $title) $rawRows[] = ['苹果', $index === 3 ? '17系列' : '18系列', $title, '', $index + 1, '苹果', ''];
    $jsonRows = array_map(static fn(array $row): array => array_combine($headers, $row), $rawRows);
    $delimited = static function (array $head, array $rows, string $separator = ',', string $eol = "\n"): string {
        $stream = fopen('php://temp', 'r+');
        if (!$stream) throw new RuntimeException('Cannot prepare in-memory delimited fixture');
        try {
            foreach (array_merge([$head], $rows) as $row) fputcsv($stream, $row, $separator, '"', '');
            rewind($stream); $value = stream_get_contents($stream);
            if ($value === false) throw new RuntimeException('Cannot read in-memory delimited fixture');
            return $eol === "\n" ? $value : str_replace("\n", $eol, $value);
        } finally { fclose($stream); }
    };
    $book = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $book->getActiveSheet()->fromArray(array_merge([$headers], $rawRows), null, 'A1');
    $file = tempnam(sys_get_temp_dir(), 'hsx_lead_format_xlsx_');
    if ($file === false) throw new RuntimeException('Cannot prepare owned XLSX fixture');
    $temporaryFiles[] = $file;
    (new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($book))->save($file); $book->disconnectWorksheets();
    $xlsx = file_get_contents($file);
    if ($xlsx === false) throw new RuntimeException('Cannot read owned XLSX fixture');
    $formats = [
        'comma_csv' => ['format' => 'csv', 'content' => $delimited($headers, $rawRows)],
        'tab_tsv' => ['format' => 'csv', 'content' => $delimited($headers, $rawRows, "\t")],
        'semicolon_csv' => ['format' => 'csv', 'content' => $delimited($headers, $rawRows, ';')],
        'bom_crlf_csv' => ['format' => 'csv', 'content' => "\xEF\xBB\xBF" . $delimited($headers, $rawRows, ',', "\r\n")],
        'real_numeric_cell_xlsx' => ['format' => 'xlsx', 'content' => base64_encode($xlsx)],
        'json_numeric_ids' => ['format' => 'json', 'content' => json_encode($jsonRows, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)],
        'json_items_wrapper' => ['format' => 'json', 'content' => json_encode(['items' => $jsonRows], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)],
    ];
    $assertFour = static function (array $response, string $label) use ($titles): void {
        importCheck(count($response['items']) === 4 && (int) $response['count'] === 4, $label . ' imports exactly four rows');
        importCheck(array_column($response['items'], 'id') === ['1', '2', '3', '4'], $label . ' normalizes spreadsheet/JSON numeric IDs to stable strings');
        importCheck(array_column($response['items'], 'title') === $titles, $label . ' falls back from empty name to the third-level model');
        foreach ($response['items'] as $index => $item) {
            importCheck($item['path'] === ['苹果', $index === 3 ? '17系列' : '18系列', $titles[$index]], $label . ' preserves all three hierarchy levels for row ' . ($index + 1));
            importCheck($item['brand'] === '苹果' && $item['category_name'] === '苹果' && $item['aliases'] === [], $label . ' preserves brand/category and empty aliases for row ' . ($index + 1));
        }
    };
    foreach ($formats as $label => $payload) {
        $payload['business_type'] = 'purchase';
        $before = $persisted();
        $preview = $catalog->save($payload + ['preview' => true]);
        $assertFour($preview, $label . ' preview');
        importCheck(($preview['preview'] ?? false) === true && $persisted() === $before, $label . ' preview makes zero persisted config/audit writes');
        $saved = $catalog->save($payload + ['preview' => false]);
        $assertFour($saved, $label . ' save');
        $read = $catalog->get(['business_type' => 'purchase']); $read['count'] = count($read['items']);
        $assertFour($read, $label . ' readback');
        $assertSiblings($label);
        importCheck(Db::name('hsx_lead_collaboration')->where('id', $lead)->find() === $historicBefore, $label . ' does not alter historic selected models or fee rules');
    }

    $special = static function (array $row) use ($catalog): array {
        return $catalog->save(['business_type' => 'purchase', 'format' => 'json', 'preview' => true, 'content' => json_encode([$row], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)])['items'][0];
    };
    $fallback = $special(['title' => '  ', 'model' => '', '名称' => ' ', '型号' => '', '一级分类' => '苹果', '二级分类' => '18系列', '三级分类' => 'iPhone Duo', 'id' => 0, '品牌' => '苹果']);
    importCheck($fallback['title'] === 'iPhone Duo' && $fallback['id'] === '0', 'whitespace aliases fall through to a real model label and numeric zero remains stable ID zero');
    $nameWins = $special(['title' => '  明确的展示名称  ', '三级分类' => 'iPhone Duo', '一级分类' => '苹果', '二级分类' => '18系列', 'id' => 1]);
    importCheck($nameWins['title'] === '明确的展示名称' && $nameWins['path'] === ['苹果', '18系列', 'iPhone Duo'], 'first nonempty display title wins without rewriting the third-level taxonomy label');
    $trailing = $rawRows; $trailing[0] = array_slice($trailing[0], 0, 6); $trailing[3] = array_slice($trailing[3], 0, 6);
    $trailingPreview = $catalog->save(['business_type' => 'purchase', 'format' => 'csv', 'preview' => true, 'content' => $delimited($headers, $trailing, "\t")]);
    importCheck(count($trailingPreview['items']) === 4 && $trailingPreview['items'][0]['aliases'] === [] && $trailingPreview['items'][3]['brand'] === '苹果' && $trailingPreview['items'][3]['aliases'] === [], 'TSV safely pads only a missing final optional alias cell without losing row alignment');
    $merged = $rawRows; $merged[1][0] = ''; $merged[1][1] = ''; $merged[2][0] = ''; $merged[2][1] = '';
    $mergedPreview = $catalog->save(['business_type' => 'purchase', 'format' => 'csv', 'preview' => true, 'content' => $delimited($headers, $merged)]);
    $assertFour($mergedPreview, 'merged-like blank parent cells');
    $quotedRows = [['苹果', '18系列', 'iPhone Duo', '', 'quoted', '苹果', 'Duo,备用;另一别名']];
    foreach ([',' => 'comma', ';' => 'semicolon'] as $separator => $label) {
        $quoted = $catalog->save(['business_type' => 'purchase', 'format' => 'csv', 'preview' => true, 'content' => $delimited($headers, $quotedRows, $separator)]);
        importCheck($quoted['items'][0]['aliases'] === ['Duo,备用', '另一别名'] && $quoted['items'][0]['title'] === 'iPhone Duo', 'quoted delimiters remain inside cells for ' . $label . ' files');
    }

    $rejected = [
        'empty_json' => ['format' => 'json', 'content' => '[]'],
        'empty_items_wrapper' => ['format' => 'json', 'content' => '{"items":[]}'],
        'header_only_csv' => ['format' => 'csv', 'content' => $delimited($headers, [])],
        'header_and_blank_rows' => ['format' => 'csv', 'content' => $delimited($headers, [array_fill(0, 7, '')])],
        'duplicate_header' => ['format' => 'csv', 'content' => "名称,id,名称\niPhone Duo,1,Duplicate\n"],
        'duplicate_numeric_ids' => ['format' => 'json', 'content' => '[{"名称":"Model one","id":1},{"名称":"Model two","id":"1"}]'],
        'missing_all_names' => ['format' => 'json', 'content' => '[{"title":" ","model":"","名称":"","三级分类":"","id":1}]'],
        'boolean_id' => ['format' => 'json', 'content' => '[{"名称":"Model one","id":true}]'],
        'decimal_id' => ['format' => 'json', 'content' => '[{"名称":"Model one","id":1.5}]'],
        'too_many_columns' => ['format' => 'csv', 'content' => "名称,id\niPhone Duo,1,extra\n"],
        'comma_short_misaligned_row' => ['format' => 'csv', 'content' => "名称,id,品牌\niPhone16,Apple\n"],
        'mixed_header_data_delimiters' => ['format' => 'csv', 'content' => "名称,id,品牌\niPhone16;1;苹果\n"],
        'unsafe_label' => ['format' => 'json', 'content' => '[{"三级分类":"<script>bad</script>","id":1}]'],
    ];
    foreach ($rejected as $label => $payload) {
        $before = $persisted();
        $message = importReject(fn() => $catalog->save($payload + ['business_type' => 'purchase', 'preview' => false]), $label . ' safely refuses before overwriting a valid directory');
        importCheck($persisted() === $before, $label . ' changes no existing config or audit data');
        if (in_array($label, ['empty_json', 'empty_items_wrapper', 'header_only_csv', 'header_and_blank_rows'], true)) importCheck((bool) preg_match('/为空|没有可导入|未读取到.*(?:目录|数据)|未找到.*(?:条目|数据)|至少.*(?:型号|数据|条目|一行)/u', $message), $label . ' explains that no importable row was found');
    }
    $assertSiblings('final rejected imports');
    importCheck(Db::name('hsx_lead_collaboration')->where('id', $lead)->find() === $historicBefore, 'all format and rejection fixtures preserve historic lead state');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => 'real four-row CSV/TSV/XLSX/JSON import fixtures; owned random localhost schema only', 'remote_calls' => 0], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true;
    fwrite(STDERR, 'FAIL catalog import formats: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    foreach ($temporaryFiles as $file) if (is_file($file)) unlink($file);
    if ($pdo instanceof PDO && $schema !== '') {
        try { leadCleanup($pdo, $schema); }
        catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL owned schema cleanup\n"); }
    }
}
exit($failed ? 1 : 0);
