import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const read=relative=>fs.readFileSync(path.join(plugin,relative),'utf8')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const filename='uni-app/pages/task/index.vue',parsed=compiler.parse(read(filename),{filename})
const script=compiler.compileScript(parsed.descriptor,{id:'membership-native'})
check(!parsed.errors.length&&!compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'membership-native',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'native task page compiles without a legacy payment alias')
function fixture(){
    const hooks=[],calls=[],module={exports:{}}
    const deps={vue:Vue,'@dcloudio/uni-app':{onLoad:fn=>hooks.push(fn),onShow(){},onHide(){}},'../../utils/cooperation-navigation':{backCooperationTask:()=>calls.push('back')},'../../utils/entity-membership':{entityPageUrl:'/addon/hsx_lead/pages/entity/index'}}
    const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Set,String,Number,uni:{showToast:args=>calls.push(args),redirectTo:args=>calls.push(args)}})(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:(()=>{throw Error(key)})(),module,module.exports)
    const state=module.exports.default.setup({},{expose(){}})
    return{state,calls,load:options=>hooks.forEach(fn=>fn(options))}
}
for(const task of ['plans','payment']){const f=fixture();f.load({task,purpose:'publishing'});check(!f.state.task.value&&f.calls.includes('back'),'removed '+task+' URL does not mount a duplicate purchase page')}
const original=fixture();original.load({task:'commission',collaboration_id:'77',payment_order_id:'701'})
check(original.state.task.value==='commission'&&original.state.id.value===77&&original.state.paymentId.value===701,'commission native route retains exact lead and original payment ID')
const team=fixture();team.load({task:'members'});check(team.calls[0].url==='/addon/hsx_lead/pages/entity/index'&&!team.state.task.value,'team task opens the dedicated enterprise page')
for(const relative of ['uni-app/components/cooperation/CoopPlansEntryCard.vue','uni-app/components/cooperation/CoopPlanComparison.vue','uni-app/utils/cooperation-plans.ts'])check(!fs.existsSync(path.join(plugin,relative)),'retired duplicate source is removed: '+relative)
const workbench=read('uni-app/components/cooperation/CooperationWorkbench.vue')
check(!/cooperationQuote|loadPlanPromotion|paymentQuote|quote_token|publisher_until|certification_status/.test(workbench),'workbench has only collaboration commission payment state, not old membership calculations')
check(workbench.includes('uni.navigateTo({ url: membershipPageUrl })')&&workbench.includes('needsMembershipNow(\'can_accept\')'),'membership entry uses a real page and server-owned acceptance capability')
check(!/cooperationQuote/.test(read('uni-app/api/cooperation.ts')),'legacy membership quote transport is removed')
console.log(`PASS ${checks} native membership routing checks; actual Vue page lifecycle with synthetic navigation only, no HTTP or payment actions.`)
