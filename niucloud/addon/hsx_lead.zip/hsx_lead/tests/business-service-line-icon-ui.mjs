import assert from 'node:assert/strict'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { spawnSync } from 'node:child_process'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual local component compilation and SSR. Native style parsing writes only
// private temporary files; no full application build, browser or network.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), sfc = require('@vue/compiler-sfc'), ts = require('typescript')
const sass = require('sass'), postcss = require('postcss'), native = require('@dcloudio/uni-mp-compiler')
const uni = require('@dcloudio/uni-cli-shared'), { renderToString } = require('@vue/server-renderer')
const filename = path.join(plugin, 'uni-app/components/cooperation/CoopServiceLineIcon.vue')
const source = fs.readFileSync(filename, 'utf8'), parsed = sfc.parse(source, { filename })
let checks = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
check(parsed.errors.length === 0, 'actual service line icon SFC parses')
const descriptor = parsed.descriptor, script = sfc.compileScript(descriptor, { id: 'service-line-test', inlineTemplate: true })
check(sfc.compileTemplate({ source: descriptor.template.content, filename, id: 'service-line-test', compilerOptions: { bindingMetadata: script.bindings } }).errors.length === 0, 'actual template compiles, not a manually reproduced icon')
const module = { exports: {} }, code = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
vm.runInNewContext('(function(require,module,exports){' + code + '})', { Number, Math })(name => { if (name === 'vue') return Vue; throw Error('Unexpected icon dependency ' + name) }, module, module.exports)
const Icon = module.exports.default
async function html(props = {}) {
    const app = Vue.createSSRApp({ render: () => Vue.h(Icon, props) }); app.config.warnHandler = () => {}
    return renderToString(app)
}
const shapes = ['phone', 'new', 'rent', 'exchange', 'wifi', 'repair', 'recycle'], signatures = new Set()
for (const shape of shapes) {
    const result = await html({ shape, color: '#397fc6', size: 32 })
    check(result.includes('is-' + shape) && result.includes('service-stroke'), shape + ' has real stroke primitives rather than an empty component mock')
    const primitives = [...result.matchAll(/class="(service-stroke[^"]*)"/g)].map(match => match[1]).join('|')
    signatures.add(primitives)
    check(primitives.length > 0 && result.includes('color:#397fc6') && result.includes('width:32px') && result.includes('height:32px'), shape + ' uses the explicit DIY colour and bounded real icon dimensions')
    check(result.includes('aria-hidden="true"') && !/role="button"|tabindex=|(?:onclick|ontap)=/.test(result), shape + ' remains decorative under the labelled parent button')
}
check(signatures.size === 7, 'all seven business drawings have distinct rendered primitives')
const fallback = await html({ shape: 'constructor' })
check(fallback.includes('is-phone') && fallback.includes('color:inherit') && fallback.includes('width:30px'), 'unknown prototype-looking shape falls back to the neutral phone and inherited colour')
check((await html({ shape: 'not-a-business' })).includes('is-phone'), 'unknown shapes do not select an uncontrolled CSS class')
for (const [size, expected] of [[0, 16], [-50, 16], [15, 16], [16, 16], [31.6, 32], [48, 48], [99, 48], [Infinity, 30], [NaN, 30], ['invalid', 30]]) {
    const result = await html({ size })
    check(result.includes('width:' + expected + 'px') && result.includes('height:' + expected + 'px') && !result.includes('scale(NaN)'), 'size ' + String(size) + ' is clamped or safely defaulted to ' + expected)
}
check((await html({ color: '' })).includes('color:inherit') && (await html({ color: null })).includes('color:inherit'), 'unset decoration colours inherit their actual parent business colour')
check(!/<(?:svg|image|img|canvas|u-icon|text)\b|v-html|@[\w-]+=/.test(descriptor.template.content), 'drawings use native view geometry only, not fonts, image downloads, vector tags, arbitrary HTML or actions')
check(!/navigateTo|request\(|fetch\(|https?:\/\/|defineEmits|interactionFeedback/.test(source), 'component owns no remote service, haptic or business action')
const css = sass.compileString(descriptor.styles.map(style => style.content).join('\n')).css
check(!/gradient|box-shadow|text-shadow|filter:|url\(|font-family|@font-face|animation:|biz-mark/.test(css), 'linework has no 3D gradient, glow, font dependency or filled overlaid mark')
const declarations = []
postcss.parse(css).walkDecls(declaration => declarations.push(declaration))
check(declarations.some(declaration => declaration.value.includes('currentColor')) && declarations.filter(declaration => /^background(?:-color|-image)?$/.test(declaration.prop)).every(declaration => /^(?:none|transparent)$/.test(declaration.value)), 'strokes inherit currentColor and introduce no solid background badges')
check(css.includes('pointer-events: none') && css.includes('position: absolute') && css.includes('border-box'), 'decoration cannot intercept the parent tap and its stroke geometry has explicit sizing')

// The real navigation projection remains the only source of colour and shape.
const presentation = loadMobileUtility('cooperation-business-presentation')
const keys = ['purchase', 'new_phone', 'rent', 'exchange', 'broadband', 'repair', 'home_recycle']
const entries = presentation.presentBusinessEntries(keys.map(key => ({ key, name: key })))
check(entries.map(entry => entry.shape).join(',') === shapes.join(',') && entries.every(entry => entry.iconMode === 'css'), 'all authoritative business types retain the existing saved CSS-mode/shape contract')
check(new Set(entries.map(entry => entry.iconColor)).size === 7, 'default line icons retain a distinct single business colour')
const override = presentation.presentBusinessEntries([{ key: 'purchase', name: '购买' }], { items: { purchase: { iconColor: '#abcdef', iconMode: 'css' } } })[0]
check((await html({ shape: override.shape, color: override.iconColor })).includes('color:#abcdef'), 'an administrator colour override reaches the actual new icon rendering')
const navigationSource = fs.readFileSync(path.join(plugin, 'uni-app/components/cooperation/CoopBusinessNavigation.vue'), 'utf8')
check(navigationSource.includes("import CoopServiceLineIcon from './CoopServiceLineIcon.vue'") && navigationSource.includes('<CoopServiceLineIcon'), 'business renderer actually imports and renders this tested component')
check(!navigationSource.includes('class="lead-business-css"') && navigationSource.includes("business.iconMode==='library'") && navigationSource.includes("business.iconMode==='original'"), 'only the CSS/fallback drawing changes; original and library modes stay separate')

// Exercise the installed uni compiler's MP template and style pipelines, then
// the actual local WeChat parser. This is not a full application/device test.
const emitted = [], errors = []
native.compile(descriptor.template.content, { filename, root: path.join(plugin, 'uni-app'), scopeId: 'data-v-service-line-test', bindingMetadata: script.bindings, prefixIdentifiers: true, onError: error => errors.push(error), miniProgram: { class: { array: true }, slot: { fallbackContent: false, dynamicSlotNames: true }, directive: 'wx:', event: { key: true }, emitFile: asset => { emitted.push(asset); return asset.fileName || 'service-icon.wxml' } } })
const wxml = emitted.map(asset => String(asset.source || '')).join('\n')
check(errors.length === 0 && /<view\b/.test(wxml) && wxml.includes('wx:if') && wxml.includes('service-stroke'), 'installed uni MP compiler emits native conditional view primitives with no syntax errors')
const oldPlatform = process.env.UNI_PLATFORM
process.env.UNI_PLATFORM = 'mp-weixin'
let wxss
try {
    const scoped = sfc.compileStyle({ source: css, filename, id: 'data-v-service-line-test', scoped: true, postcssPlugins: [uni.uniPostcssPlugin({ unit: 'rpx', unitRatio: 1 }), uni.uniPostcssScopedPlugin()] })
    check(scoped.errors.length === 0, 'actual uni postcss/scoped pipeline accepts the component CSS')
    wxss = scoped.code
} finally { if (oldPlatform === undefined) delete process.env.UNI_PLATFORM; else process.env.UNI_PLATFORM = oldPlatform }
const wcsc = process.env.WXSS_COMPILER || '/Applications/wechatwebdevtools.app/Contents/Resources/app.asar.unpacked/node_modules/wcc-exec/wcsc'
check(fs.existsSync(wcsc), 'actual local WeChat WXSS compiler is available; parser verification is not silently skipped')
const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'hsx-service-line-icon-'))
try {
    fs.writeFileSync(path.join(directory, 'icon.wxss'), wxss)
    const result = spawnSync(wcsc, ['-lc', '-pc', '1', '-o', path.join(directory, 'icon.js'), './icon.wxss'], { cwd: directory, encoding: 'utf8', timeout: 15000 })
    check(!result.error && result.status === 0, 'real WeChat WXSS parser accepts native linework: ' + (result.error?.message || result.stderr || result.stdout || '').slice(0, 300))
} finally { fs.rmSync(directory, { recursive: true, force: true }) }
console.log(`PASS ${checks} service line icon checks; actual seven-shape SFC SSR, projection, uni MP template/style compilation and local WeChat WXSS parser. No browser/API/database/full build.`)
