import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),root=path.resolve(plugin,'../../..'),require=createRequire(path.join(root,'uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),scopedVue={...Vue,onBeforeUnmount:Vue.onScopeDispose}
const file='admin/views/cooperation/ProfileFormSettings.vue',source=fs.readFileSync(path.join(plugin,file),'utf8'),descriptor=compiler.parse(source,{filename:file}).descriptor,script=compiler.compileScript(descriptor,{id:'profile-form-settings-ui'})
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++},clone=value=>JSON.parse(JSON.stringify(value)),flush=async()=>{for(let i=0;i<5;i++){await Promise.resolve();await Vue.nextTick()}}
check(source===fs.readFileSync(path.join(root,'admin/src/addon/hsx_lead/views/cooperation/ProfileFormSettings.vue'),'utf8'),'canonical and mounted settings component match')
check(!compiler.compileTemplate({source:descriptor.template.content,filename:file,id:'profile-form-settings-ui',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'actual admin form template compiles')
check(descriptor.template.content.includes('在牛云万能表单中创建“门店补充资料”')&&descriptor.template.content.includes('已有的自定义表单仍可继续使用'),'entry describes the registered native form type and retains existing custom forms')
check(descriptor.template.content.includes('@click="refreshForms"')&&descriptor.template.content.includes('刷新表单列表'),'new form list refresh is an explicit action, separate from reloading all settings')
check(descriptor.template.content.includes('门店名称、联系人、联系电话、完整地区、详细地址与经营能力由协作业务校验'),'fixed core business data is not falsely advertised as configurable supplemental fields')
check(!/requestPayment|uploadFile|request\.post|request\.put/.test(source),'settings component does not implement a private uploader or financial operation')
const initial=()=>({version:'version-one',fields:{storefront_image:{visible:true,required:false,sort:10},business_license:{visible:true,required:false,sort:20}},extra_form:{enabled:false,form_id:0},forms:[{form_id:7,title:'已有自定义表单',type:'DIY_FORM',status:1}],supported_types:['FormInput','FormTextarea']})
const user=Vue.reactive({token:'admin-a',siteInfo:{site_id:100005}}),props=Vue.reactive({modelValue:true,canEdit:true}),reads=[],writes=[],routes=[],messages=[],events=[]
let stored=initial(),readWork=async()=>({data:clone(stored)}),saveWork=async payload=>({data:{...clone(stored),version:'saved-version',fields:clone(payload.fields),extra_form:clone(payload.extra_form)}})
const module={exports:{}},compiled=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext('(function(require,module,exports){'+compiled+'\n})',{console,Number,String,Object,JSON,Promise,Error})(key=>{
    if(key==='vue')return scopedVue
    if(key==='vue-router')return{useRouter:()=>({push:value=>routes.push(value)})}
    if(key==='element-plus')return{ElMessage:{success:value=>messages.push(value)}}
    if(key==='@/stores/modules/user')return{default:()=>user}
    if(key==='../../api/cooperation')return{getProfileFormSettings:()=>{reads.push({site:user.siteInfo.site_id,token:user.token});return readWork()},saveProfileFormSettings:payload=>{writes.push(clone(payload));return saveWork(payload)}}
    if(key==='../../composables/cooperation')return{coopError:(error,fallback)=>error?.message||fallback}
    if(key.endsWith('.vue'))return{default:{}}
    throw Error('Unexpected dependency '+key)
},module,module.exports)
const scope=Vue.effectScope(),state=scope.run(()=>module.exports.default.setup(props,{expose(){},emit:(...value)=>events.push(value)}))
await flush()
check(reads.length===1&&state.ready.value&&!state.loading.value,'opening the drawer makes one authoritative read and releases loading')
check(state.version.value==='version-one'&&state.forms.value.length===1,'loaded native form options and version are taken from the server')
check(state.fields.business_license.sort===20&&state.selectedExtraForm.value===undefined,'server field order and an unselected form remain explicit')
state.fields.storefront_image.required=true;state.fields.business_license.sort=45;state.extra.enabled=true;state.selectedExtraForm.value=9
stored={...initial(),fields:{storefront_image:{visible:false,required:false,sort:0},business_license:{visible:false,required:false,sort:0}},extra_form:{enabled:false,form_id:0},forms:[...initial().forms,{form_id:9,title:'门店补充资料',type:'HSX_LEAD_MERCHANT_PROFILE',status:1}]}
await state.refreshForms()
check(state.forms.value.some(row=>row.form_id===9)&&state.forms.value.some(row=>row.form_id===7),'list refresh discovers new dedicated forms without discarding existing DIY_FORM options')
check(state.fields.storefront_image.required===true&&state.fields.business_license.sort===45,'refreshing options does not overwrite unsaved material requirements')
check(state.extra.enabled&&state.extra.form_id===9&&state.selectedExtraForm.value===9,'refreshing options preserves the draft supplemental form selection')
check(state.version.value==='version-one'&&!state.error.value&&!state.loading.value&&writes.length===0,'same-version refresh is read-only and leaves the write precondition intact')
const beforeFailure=clone(state.forms.value);readWork=async()=>{throw Error('合成列表读取失败')};await state.refreshForms()
check(state.ready.value&&state.error.value==='合成列表读取失败'&&!state.loading.value,'refresh failure retains an editable draft and exposes a clear read error')
check(JSON.stringify(state.forms.value)===JSON.stringify(beforeFailure)&&state.extra.form_id===9&&state.fields.business_license.sort===45,'refresh failure does not clear previous options or form edits')
readWork=async()=>({data:{version:'bad-response'}});await state.refreshForms()
check(state.error.value.includes('返回不完整')&&state.forms.value.length===2&&state.fields.storefront_image.required,'incomplete options response cannot erase the current draft')
readWork=async()=>({data:{...clone(stored),version:'version-two'}});await state.refreshForms()
check(state.version.value==='version-one'&&state.error.value.includes('配置已被更新'),'refreshing against a changed server version warns without silently rebasing the write precondition')
check(state.extra.form_id===9&&state.fields.business_license.sort===45,'concurrent setting changes preserve the unsaved local draft for deliberate review')
saveWork=async()=>{throw Error('合成服务端版本冲突')};await state.save()
check(writes.length===1&&writes[0].expected_version==='version-one'&&writes[0].extra_form.form_id===9,'save carries the original expected version and current deliberate selection')
check(writes[0].fields.storefront_image.required===true&&state.error.value==='合成服务端版本冲突'&&!state.saving.value,'failed save retains draft requirements and releases the busy state')
check(!messages.length&&state.version.value==='version-one','failed save never shows success or advances version optimistically')
props.canEdit=false;await state.save();check(writes.length===1,'read-only administrator cannot submit a settings mutation');props.canEdit=true
state.loading.value=true;const readCount=reads.length;await state.refreshForms();await state.save();check(reads.length===readCount&&writes.length===1,'busy reads block duplicate refreshes and saves');state.loading.value=false
state.ready.value=false;await state.refreshForms();await state.save();check(reads.length===readCount&&writes.length===1,'unready settings cannot submit or refresh a guessed configuration');state.ready.value=true
state.saving.value=true;state.openForms();await state.refreshForms();check(!routes.length&&reads.length===readCount,'a pending save cannot leave for native form management or start another read');state.saving.value=false
state.openForms();check(routes.at(-1)==='/site/diy_form/list','manage-forms link uses NiuCloud native form management route')
state.selectedExtraForm.value=999;await state.save();check(writes.length===1&&state.error.value.includes('请选择本站已有'),'an unknown selected form is rejected before calling save')
state.selectedExtraForm.value=0;check(state.selectedExtraForm.value===undefined&&state.extra.form_id===0,'cleared select maps to the explicit unselected zero, not an invalid option')
state.extra.enabled=false;saveWork=async payload=>({data:{...clone(stored),version:'saved-version',fields:clone(payload.fields),extra_form:clone(payload.extra_form)}});await state.save()
check(writes.length===2&&writes[1].extra_form.enabled===false&&writes[1].extra_form.form_id===0,'disabling supplemental forms sends zero form identity rather than stale selected ID')
check(state.version.value==='saved-version'&&messages.at(-1)==='门店资料要求已保存'&&!state.saving.value,'successful save installs the server response rather than an optimistic draft')
// Tenant changes invalidate any late list result. The watcher starts a fresh
// native configuration read; it never keeps one site's form IDs in another.
const pending=[];readWork=()=>new Promise(resolve=>pending.push(resolve));const old=state.refreshForms();user.siteInfo.site_id=100006;await flush()
check(pending.length===2&&!state.ready.value,'identity watcher invalidates ready state and starts a fresh site read')
pending[1]({data:{...initial(),version:'new-site-version',forms:[{form_id:51,title:'新站资料',status:1,type:'HSX_LEAD_MERCHANT_PROFILE'}]}});await flush()
pending[0]({data:{...initial(),version:'old-site-late',forms:[{form_id:99,title:'旧站迟到',status:1,type:'DIY_FORM'}]}});await old
check(state.version.value==='new-site-version'&&state.forms.value[0].form_id===51&&!state.loading.value,'late previous-site refresh cannot overwrite current forms or version')
check(state.extra.form_id===0&&!state.extra.enabled&&state.fields.business_license.sort===20,'tenant switch reloads settings instead of carrying another site draft')
// Token rotation is also an identity change; a pending save may finish on the
// server, but its stale presentation cannot become the new actor's state.
let resolveSave;state.extra.enabled=true;state.extra.form_id=51;saveWork=()=>new Promise(resolve=>{resolveSave=resolve});const oldSave=state.save();const beforeMessages=messages.length
readWork=async()=>({data:{...initial(),version:'new-token-version'}});user.token='admin-b';await flush();resolveSave({data:{...initial(),version:'stale-save-result'}});await oldSave
check(state.version.value==='new-token-version'&&messages.length===beforeMessages,'late response from a previous administrator token cannot install state or show success')
props.modelValue=false;await flush();const closedReads=reads.length,closedWrites=writes.length;await state.refreshForms();await state.save()
check(reads.length===closedReads&&writes.length===closedWrites&&!state.ready.value,'closed drawer has no refresh or save side effects')
readWork=async()=>({data:initial()});props.modelValue=true;await flush();check(state.ready.value&&state.version.value==='version-one','reopening reads the actual settings again')
let lateResolve;readWork=()=>new Promise(resolve=>{lateResolve=resolve});const leaving=state.refreshForms();scope.stop();lateResolve({data:{...initial(),version:'unmounted-late'}});await leaving
check(state.version.value==='version-one','unmounted drawer ignores a late refresh response')
const previousReads=reads.length,previousWrites=writes.length;await state.refreshForms();await state.save()
check(reads.length===previousReads&&writes.length===previousWrites,'disposed scope cannot issue new form reads or settings writes')
console.log(`PASS ${checks} native profile-form settings UI checks; actual Vue setup/SFC compilation with synthetic API responses only, no network, database, upload or business mutation.`)
