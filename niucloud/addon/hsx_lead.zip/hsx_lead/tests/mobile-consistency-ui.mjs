import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Real local SFCs, scoped SCSS and Vue SSR. All server/uni transports are blocked;
// this is not native keyboard, visual browser, upload or payment acceptance.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),{compile}=require('@vue/compiler-dom'),ts=require('typescript'),sass=require('sass'),{renderToString}=require('@vue/server-renderer')
const directory=path.join(plugin,'uni-app/components/cooperation'),read=name=>fs.readFileSync(path.join(directory,name+'.vue'),'utf8')
let checks=0,networkCalls=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
function execute(source,deps={}){const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{Date,Math,Number,String,Map,Set,JSON,Promise,console,setTimeout,clearTimeout,uni:{getStorageSync(){},setStorageSync(){},removeStorageSync(){},showToast(){}}})(key=>{if(key in deps)return deps[key];if(key.startsWith('../../utils/'))return loadMobileUtility(path.basename(key));if(key.endsWith('.png'))return{default:'/synthetic-asset.png'};throw Error('Unexpected import '+key)},module,module.exports);return module.exports}
const blocked=()=>{networkCalls++;throw Error('No transport is permitted in mobile presentation tests')}
const api=execute(fs.readFileSync(path.join(plugin,'uni-app/api/cooperation.ts'),'utf8'),{'@/utils/request':{default:new Proxy({},{get:()=>blocked})}})
const names=['CoopPublishForm','CoopCommissionForm','CoopTaskDetail','CoopTaskSheet','CoopStorePicker','CoopStoreInventory','CoopWalletPanel','CoopRegionFields','CooperationSearch','ModelCatalogPicker','CoopConnectionPanel','CoopAttachmentUpload','CoopState']
const css=new Map(),cache=new Map()
for(const name of names){const parsed=compiler.parse(read(name),{filename:name+'.vue'});check(!parsed.errors.length,name+' SFC parses');const script=compiler.compileScript(parsed.descriptor,{id:'mobile-consistency-'+name});check(!compiler.compileTemplate({source:parsed.descriptor.template.content,filename:name+'.vue',id:name,compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length,name+' actual template compiles');let content='';for(const style of parsed.descriptor.styles){const compiled=style.lang==='scss'?sass.compileString(style.content,{loadPaths:[directory],logger:{warn(){}}}).css:style.content;const result=compiler.compileStyle({source:compiled,filename:name+'.vue',id:'data-v-mobile-consistency',scoped:true});check(!result.errors.length,name+' component-owned style compiles');content+='\n'+compiled}css.set(name,content)}
const button=loadMobileUtility('mobile-ui').cooperationButtonStyle
check(button.height==='44px'&&button.minHeight==='44px'&&button.boxSizing==='border-box','one pure shared public uview style sets a fixed 44px touch height')
check(loadMobileUtility('mobile-ui').cooperationInputStyle.minHeight==='48px','uview text inputs share a fixed 48px height through their public customStyle prop')
check(!fs.readFileSync(path.join(plugin,'uni-app/utils/mobile-ui.ts'),'utf8').includes('request.'),'shared presentation helper cannot own transport or payment actions')
for(const name of ['CoopPublishForm','CoopCommissionForm','CoopTaskDetail','CoopStorePicker','CoopStoreInventory','CoopWalletPanel','CoopRegionFields','ModelCatalogPicker','CoopConnectionPanel']){const template=compiler.parse(read(name)).descriptor.template.content;const actions=[...template.matchAll(/<u-button\b[^>]*>/g)].map(match=>match[0]);check(actions.length>0&&actions.every(tag=>tag.includes(':custom-style="cooperationButtonStyle"')),name+' buttons explicitly receive the shared touch size without cross-scope CSS')}
check(/\.coop-form-row\s*\{[^}]*min-height:\s*48px/.test(css.get('CoopPublishForm')),'form input rows retain 48px height even at a 320px viewport')
check(/\.coop-form-column\s*\{[^}]*gap:\s*8px[^}]*padding:\s*12px/.test(css.get('CoopPublishForm')),'form fields share an 8px label gap and 12px group spacing')
check(/\.coop-sheet__footer\s*\{[^}]*padding:\s*12px 16px calc\(12px \+ env\(safe-area-inset-bottom\)\)/.test(css.get('CoopTaskSheet')),'one non-scrolling footer owns its 12/16 spacing and safe-area inset')
check(/\.coop-icon-button\s*\{[^}]*width:\s*44px[^}]*height:\s*44px/.test(css.get('CoopTaskSheet')),'task close has its own 44px hit area')
check(read('CoopStorePicker').includes("selected ? '确认交付'")&&!read('CoopStorePicker').includes('`交付给${selected.name}`'),'long merchant names do not become variable-width primary button text')
check(read('CoopStorePicker').includes("'已选：' + selected.name"),'the selected merchant remains fully identifiable outside the confirmation button')
check(read('CoopStoreInventory').includes("firstPageReady ? total + ' 条可售库存参考'"),'inventory summary does not claim a real zero before its first successful page')
check(read('CoopCommissionForm').includes('title="查看本单收费规则"')&&read('CoopWalletPanel').includes('title="账户与提现说明"'),'low-frequency explanation has a deliberate disclosure entry rather than a permanent paragraph stack')
check(read('CoopCommissionForm').includes('if (props.busy || props.blocked) return')&&read('CoopCommissionForm').includes('!busy && !blocked && (amount = String(value))'),'busy or invalid context locks both amount presets and programmatic form submission')
check(read('CoopTaskDetail').includes('成交后最低付佣')&&read('CoopTaskDetail').includes('未成交不收协作佣金'),'critical per-order charging boundary remains visible and distinguishes collaboration commission from membership fees rather than hiding it in help')
check(/\.coop-upload-image\s*>\s*button\s*\{[^}]*width:\s*44px[^}]*height:\s*44px/.test(css.get('CoopAttachmentUpload')),'screenshot removal retains a 44px target without making the visible glyph larger')
check(/\.region-head button\s*\{[^}]*width:\s*44px[^}]*height:\s*44px/.test(css.get('CoopRegionFields')),'region close shares the task close touch size')
check(read('CooperationSearch').includes(':height="44"')&&read('CooperationSearch').includes("minHeight: '44px'"),'search field and its action keep a stable 44px height')
let prepare=()=>{}
const Nav={props:['title'],setup:props=>()=>Vue.h('header',{},props.title)}
const pass={setup:(_,{slots})=>()=>Vue.h('div',{},slots.default?.())}
function component(name){
    if(name==='CooperationNav')return Nav
    if(cache.has(name))return cache.get(name)
    const filename=path.join(directory,name+'.vue'),descriptor=compiler.parse(fs.readFileSync(filename,'utf8'),{filename}).descriptor
    const script=compiler.compileScript(descriptor,{id:'mobile-render-'+name})
    const presentationVue={...Vue,watch:()=>()=>{},onBeforeUnmount(){}}
    const paymentHelp=execute(fs.readFileSync(path.join(plugin,'uni-app/composables/usePaymentHelp.ts'),'utf8'),{vue:presentationVue,'@dcloudio/uni-app':{onHide(){},onShow(){}},'@/utils/common':{getSiteId:()=>100005,getToken:()=>''},'../api/paymentHelp':{getPaymentHelp:blocked},'../api/cooperation':api})
    const deps={vue:presentationVue,'../../composables/usePaymentHelp':paymentHelp,'../../composables/useResponseDeadline':execute(fs.readFileSync(path.join(plugin,'uni-app/composables/useResponseDeadline.ts'),'utf8'),{vue:presentationVue}),'../../api/cooperation':api,'@/utils/common':{img:value=>value,redirect:blocked},'../../utils/cooperation-navigation':{openCooperationTask:blocked,openCooperationCatalog:blocked},'@/app/api/system':{getAreaListByPid:blocked},'../../api/regions':{searchCooperationRegions:blocked},'z-paging/components/z-paging/z-paging.vue':{default:pass}}
    for(const match of script.content.matchAll(/from\s+['"](\.\/[^'"]+\.vue)['"]/g))deps[match[1]]={default:component(path.basename(match[1],'.vue'))}
    const actual=execute(script.content,deps).default,render=new Function('Vue',compile(descriptor.template.content,{mode:'function',prefixIdentifiers:true,isCustomElement:tag=>['view','text','scroll-view'].includes(tag)}).code)(Vue)
    const wrapped={...actual,setup(props,context){const result=actual.setup(props,context);prepare(name,result);return{...result}},render}
    cache.set(name,wrapped);return wrapped
}
async function html(name,props,override=()=>{}){
    prepare=override
    const Component=component(name),app=Vue.createSSRApp({render:()=>Vue.h(Component,props)})
    app.config.warnHandler=()=>{}
    for(const[key,value]of cache)app.component(key,value)
    app.component('CooperationNav',Nav)
    app.component('u-button',{props:['text','disabled','loading','customStyle','type'],setup:(props,{slots})=>()=>Vue.h('button',{disabled:props.disabled||props.loading,style:props.customStyle,'data-primary':props.type==='primary'},props.text||slots.default?.())})
    app.component('u-icon',{setup:()=>()=>Vue.h('i')});app.component('u-loading-icon',{setup:()=>()=>Vue.h('i',{},'loading')})
    app.component('u-popup',{props:['show'],setup:(props,{slots})=>()=>props.show?Vue.h('aside',{},slots.default?.()):null})
    app.component('u-collapse',pass);app.component('u-upload',pass)
    app.component('u-collapse-item',{props:['title'],setup:(props,{slots})=>()=>Vue.h('details',{},[Vue.h('summary',{},props.title),slots.default?.()])})
    app.component('u-input',{props:['modelValue','disabled'],setup:props=>()=>Vue.h('input',{value:props.modelValue,disabled:props.disabled})})
    app.component('u-textarea',{props:['modelValue'],setup:props=>()=>Vue.h('textarea',{},props.modelValue)})
    const rendered=await renderToString(app);prepare=()=>{};return rendered
}
const base={id:51,status:'assigned',customer_name:'合成客户长称呼用于检查信息换行',region_text:'河北省 / 石家庄市 / 长安区 / 合成长地址仅用于本地测试',commission_minimum:'50.00',fee_percent:'10.00',fee_minimum:'9.90',fee_confirmed:true,models:[{id:'one',title:'合成意向型号一'}],publisher:{name:'合成发布门店'},receiver:{name:'合成承接门店'},history:[{id:1,content:'合成历史处理记录'}]}
for(const [lead,label,secondary]of[[{...base,can_accept:true},'接受交付','暂不承接'],[{...base,can_report:true},'已成交，去付佣','未成交'],[{...base,can_assign:true,can_cancel:true},'选择交付门店','取消线索'],[{...base,status:'unpaid',can_pay:true},'支付协作佣金',null]]){
    const rendered=await html('CoopTaskDetail',{show:true,page:true,lead,config:{}})
    check(rendered.includes(label)&&(!secondary||rendered.includes(secondary)),'server-owned detail action branch remains intact: '+label)
    check((rendered.match(/data-primary="true"/g)||[]).length===1,'each actionable detail branch has exactly one primary button: '+label)
    check(!rendered.includes('合成历史处理记录')&&rendered.includes('编号与处理记录'),'history starts collapsed without removing its entry')
}
let rendered=await html('CoopCommissionForm',{show:true,page:true,lead:base,config:{},busy:false},(name,state)=>{if(name==='CoopCommissionForm')state.amount.value='50'})
check(rendered.includes('¥40.10')&&rendered.includes('¥9.90')&&rendered.includes('确认金额，去支付'),'actual commission summary retains the frozen fifty-yuan split and one payment action')
rendered=await html('CoopCommissionForm',{show:true,page:true,lead:{id:1},config:{},busy:false})
check(rendered.includes('收费规则待核对')&&!rendered.includes('成交最低付佣 ¥0.00'),'missing snapshot is explicit and never advertised as a zero-fee minimum')
rendered=await html('CoopWalletPanel',{wallet:{},loading:true,error:''})
check(rendered.includes('coop-balance')&&!rendered.includes('¥0.00')&&rendered.includes('disabled'),'unloaded wallet preserves unknown money and a disabled withdrawal action')
rendered=await html('CoopWalletPanel',{wallet:{available:'88.00',frozen:'0.00'},loading:false,error:'合成读取错误'})
check(rendered.includes('¥88.00')&&rendered.includes('合成读取错误')&&rendered.includes('disabled'),'wallet read failure retains last known balance without allowing a stale withdrawal entry')
const longName='合成的非常长的同城交付门店名称用于窄屏核对'
rendered=await html('CoopStorePicker',{show:true,page:true,lead:{id:1,status:'selecting',can_assign:true},config:{},busy:false},(name,state)=>{if(name==='CoopStorePicker'){state.selected.value={id:7,name:longName};state.rows.value=[]}})
check(rendered.includes('已选：'+longName)&&rendered.includes('>确认交付</button>')&&!rendered.includes('交付给'+longName),'selected long merchant stays in a wrapping context row, not the main button label')
check(networkCalls===0,'compilation and SSR checks never call a live service or storage transport')
console.log(`PASS ${checks} mobile consistency checks; real Vue SFC/SSR/scoped SCSS and pure UI helper, synthetic data only; no browser, API, upload, database or payment actions.`)
