<?php
declare(strict_types=1);
/** Real official Sms listener, synthetic core sender/logs only. No app boot, DB or network. */
namespace app\dict\notice { final class NoticeTypeDict { public const SMS='sms'; } }
namespace app\service\core\member {
    final class CoreMemberService {
        public static array $member=['mobile'=>'19900000101','nickname'=>'Synthetic'];
        public static array $reads=[];
        public function getInfoByMemberId($site,$id): array { self::$reads[]=[$site,$id]; return self::$member; }
    }
}
namespace app\service\core\notice {
    final class CoreNoticeBindMerchantService {
        public static array $merchant=['mobile'=>'19900000201'];
        public function getInfo($id): array { return self::$merchant; }
    }
    final class CoreNoticeLogService {
        public static array $logs=[];
        public static ?\Throwable $error=null;
        public static int $calls=0;
        public function add($site,$data): void { self::$calls++; if(self::$error)throw self::$error; self::$logs[]=['site'=>$site]+$data; }
    }
    final class CoreSmsService {
        public static array $configuration=['sms_type'=>'aliyun'];
        public static ?\Throwable $configurationError=null;
        public static ?\Throwable $sendError=null;
        public static $result=true;
        public static array $calls=[];
        public static int $configurationReads=0;
        public function getDefaultSmsConfig($site): array { self::$configurationReads++; if(self::$configurationError)throw self::$configurationError;return self::$configuration; }
        public function send(...$args) { self::$calls[]=$args;if(self::$sendError)throw self::$sendError;return self::$result; }
    }
}
namespace {
    use app\service\core\notice\{CoreSmsService,CoreNoticeLogService};
    use app\service\core\member\CoreMemberService;
    use core\exception\{NoticeDeliveryException,NoticeException};
    $root=dirname(__DIR__,3);
    require $root.'/core/exception/NoticeException.php';
    require $root.'/core/exception/NoticeDeliveryException.php';
    require $root.'/app/listener/notice/Sms.php';
    $checks=0;
    function smsCheck(bool $ok,string $label): void { global $checks;if(!$ok)throw new \RuntimeException($label);$checks++; }
    function smsReset(): void {
        CoreSmsService::$configuration=['sms_type'=>'aliyun'];CoreSmsService::$configurationError=null;CoreSmsService::$sendError=null;CoreSmsService::$result=true;CoreSmsService::$calls=[];CoreSmsService::$configurationReads=0;
        CoreNoticeLogService::$logs=[];CoreNoticeLogService::$error=null;CoreNoticeLogService::$calls=0;CoreMemberService::$member=['mobile'=>'19900000101','nickname'=>'Synthetic'];CoreMemberService::$reads=[];
    }
    function smsFailure(callable $action,string $expected): NoticeDeliveryException {
        try{$action();throw new \RuntimeException('Expected typed failure');}
        catch(NoticeDeliveryException $error){smsCheck($error->channel()==='sms'&&$error->deliveryStatus()===$expected&&$error->providerCode()==='','SMS failure has a conservative typed outcome');smsCheck(!str_contains($error->getMessage(),'SECRET_MARKER'),'public error never contains raw provider/config/log details');return$error;}
    }
    $listener=new \app\listener\notice\Sms();
    $base=['site_id'=>100005,'key'=>'synthetic_sms','vars'=>['amount'=>'99.00'],'to'=>['member_id'=>101],
        'template'=>['is_sms'=>1,'sms_id'=>'SYNTHETIC_TEMPLATE','receiver_type'=>1,'async'=>false,'sms'=>['content'=>'变动{amount}','url_params'=>[]]]];
    smsReset();smsCheck($listener->handle($base)===true,'default caller retains its original boolean success contract');
    smsCheck(count(CoreSmsService::$calls)===1&&CoreSmsService::$configurationReads===0,'legacy path does not perform the new optional preflight');
    smsCheck(CoreNoticeLogService::$logs[0]['receiver']==='19900000101'&&CoreNoticeLogService::$logs[0]['member_id']===101,'legacy success retains the existing notice log identity');
    $receipt=$base+['return_receipt'=>true];
    smsReset();$result=$listener->handle($receipt);
    smsCheck($result===['accepted'=>true,'channel'=>'sms','provider_code'=>'0','provider_id'=>''],'explicit request gets provider acceptance, not a delivery/read acknowledgement');
    smsCheck(count(CoreSmsService::$calls)===1&&CoreSmsService::$configurationReads===1,'optional success invokes the core SMS service exactly once');
    smsCheck(CoreMemberService::$reads===[[100005,101]]&&CoreNoticeLogService::$logs[0]['result']==='','receipt keeps source site/member and a successful framework notice log');
    foreach(['aliyun','tencent','niuyun']as$driver){smsReset();CoreSmsService::$configuration=['sms_type'=>$driver];smsCheck($listener->handle($receipt)['accepted']===true,'core accepted result is normalized for '.$driver);}
    foreach([false,null,'true',1]as$invalid){smsReset();CoreSmsService::$result=$invalid;smsFailure(fn()=>$listener->handle($receipt),'unknown');smsCheck(count(CoreSmsService::$calls)===1,'an unverified core result never triggers implicit resubmission');}
    foreach([new NoticeException('SECRET_MARKER provider response'),new \RuntimeException('SECRET_MARKER transport timeout'),new NoticeDeliveryException('sms','rejected','45009','SECRET_MARKER legacy wrapped error')]as$error){
        foreach([false,true]as$async){smsReset();CoreSmsService::$sendError=$error;$event=$receipt;$event['template']['async']=$async;smsFailure(fn()=>$listener->handle($event),'unknown');
            smsCheck(count(CoreSmsService::$calls)===1&&count(CoreNoticeLogService::$logs)===1,'both sync and async receipt requests keep one failed attempt log and never resend');
            smsCheck(!str_contains(CoreNoticeLogService::$logs[0]['result'],'SECRET_MARKER'),'new receipt log result is sanitized, not a raw provider error');}
    }
    smsReset();CoreMemberService::$member=[];smsFailure(fn()=>$listener->handle($receipt),'not_submitted');
    smsCheck(!CoreSmsService::$calls&&count(CoreNoticeLogService::$logs)===1&&CoreNoticeLogService::$logs[0]['receiver']==='','missing mobile never submits and still has a fully initialized audit log');
    smsReset();$closed=$receipt;$closed['template']['is_sms']=0;smsFailure(fn()=>$listener->handle($closed),'not_submitted');
    smsCheck(!CoreSmsService::$calls&&CoreSmsService::$configurationReads===0&&count(CoreNoticeLogService::$logs)===1,'closed channel is explicitly not submitted and logged');
    smsReset();$missingTemplate=$receipt;$missingTemplate['template']['sms_id']='';smsFailure(fn()=>$listener->handle($missingTemplate),'not_submitted');smsCheck(!CoreSmsService::$calls,'missing SMS template does not call the sender');
    smsReset();CoreSmsService::$configuration=[];smsFailure(fn()=>$listener->handle($receipt),'not_submitted');smsCheck(!CoreSmsService::$calls,'unconfigured sender is rejected in the read-only preflight');
    smsReset();CoreSmsService::$configurationError=new NoticeException('SECRET_MARKER credentials/config');smsFailure(fn()=>$listener->handle($receipt),'not_submitted');smsCheck(!CoreSmsService::$calls,'configuration exception before send is provably not submitted');
    smsReset();CoreNoticeLogService::$error=new \RuntimeException('SECRET_MARKER log database error');smsFailure(fn()=>$listener->handle($receipt),'unknown');
    smsCheck(count(CoreSmsService::$calls)===1&&CoreNoticeLogService::$calls===1,'post-send audit failure cannot masquerade as success or retry the SMS');
    smsReset();$direct=$receipt;$direct['to']=['mobile'=>'19900000999'];smsCheck($listener->handle($direct)['accepted']===true&&!CoreMemberService::$reads,'existing direct-mobile addressing remains supported');
    smsReset();$merchant=$receipt;$merchant['template']['receiver_type']=2;$merchant['to']=['merchant_id'=>20];smsCheck($listener->handle($merchant)['accepted']===true&&CoreNoticeLogService::$logs[0]['receiver']==='19900000201','existing merchant-recipient addressing remains supported');
    smsReset();CoreSmsService::$sendError=new NoticeException('legacy error');$legacyAsync=$base;$legacyAsync['template']['async']=true;
    smsCheck($listener->handle($legacyAsync)===true&&CoreNoticeLogService::$logs[0]['result']==='legacy error','default legacy async callers retain their original log-only error behavior');
    smsReset();CoreSmsService::$sendError=new NoticeException('legacy error');$legacyThrown=false;
    try{$listener->handle($base);}catch(NoticeException$error){$legacyThrown=!($error instanceof NoticeDeliveryException)&&$error->getMessage()==='legacy error';}
    smsCheck($legacyThrown,'default legacy synchronous error contract is unchanged');
    smsReset();CoreMemberService::$member=[];$legacyEmpty=$base;$legacyEmpty['template']['async']=true;
    set_error_handler(static function($severity,$message){throw new \ErrorException($message,0,$severity);});
    try{smsCheck($listener->handle($legacyEmpty)===true,'legacy empty-mobile async handling produces no undefined log_data warning');}finally{restore_error_handler();}
    smsCheck(CoreNoticeLogService::$logs[0]['result']==='NOTICE_SMS_EMPTY'&&CoreNoticeLogService::$logs[0]['member_id']===101,'legacy missing recipient is logged with its real context');
    smsReset();$legacyClosed=$base;$legacyClosed['template']['async']=true;$legacyClosed['template']['is_sms']=0;
    smsCheck($listener->handle($legacyClosed)===true&&!CoreNoticeLogService::$logs&&!CoreSmsService::$calls,'non-opted-in closed async channel retains its previous no-send/no-log behavior');
    echo 'PASS '.$checks." SMS receipt checks; actual official listener with synthetic core sender and logs, no database or external delivery.\n";
}
