import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual mobile hook, utility and SFC code. Every transport is synthetic; no account/payment writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),sass=require('sass')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++},read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
const execute=(source,deps={},globals={})=>{const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{Date,Math,Number,String,Promise,Map,Set,console,uni:{showToast(){},getStorageSync(){},removeStorageSync(){}},...globals})(key=>{if(key in deps)return deps[key];if(key==='../../utils/mobile-ui')return loadMobileUtility('mobile-ui');if(key.endsWith('.vue'))return{default:{}};throw Error('Unexpected import '+key)},module,module.exports);return module.exports}
const app=(status='none',values={})=>({status,status_label:status,version:0,can_apply:status==='none'||status==='rejected',reason:'',apply_reason:'',merchant_name:'合成测试门店',city:'合成市',contact_name:'合成联系人',mobile_masked:'188****0000',disabled_mode:'normal',...values})
let application=app(),identity='member-a',reads=0,writes=0,readWork=async()=>({data:{application:{...application}}}),writeWork=async()=>{application=app('pending',{version:1});return{data:{application:{...application},already_submitted:false}}}
const summary=()=>({enabled:true,role:'normal',promotion_allowed:true,member:{member_id:1,name:'合成会员'},provider:null,stats:{team_count:0,pending:'0.00',settled:'0.00',held:'0.00'},account:{available:'0.00'},rules:{enabled:true,sources:{publishing:{enabled:true,normal_rate:5,provider_rate:10}}},share:{path:'/addon/hsx_lead/pages/profile/index?mid=1'},application:{...application}})
const dependencies={vue:Vue,'@/utils/common':{getToken:()=>identity},'../api/cooperation':{coopError:(cause,fallback)=>cause?.message||fallback},'../api/promotion':{promotionOverview:async()=>({data:summary()}),promotionApplication:async()=>{reads++;return readWork()},submitPromotionApplication:async()=>{writes++;return writeWork()}}}
const hook=execute(read('uni-app/composables/usePromotion.ts'),dependencies),state=hook.usePromotion()
check(!state.applicationReady.value&&!state.application.value.status,'no application or eligibility is invented before a server read')
check(await state.applyProvider()===false&&writes===0,'application cannot be submitted before current identity and server eligibility exist')
await state.reload();check(state.applicationReady.value&&state.application.value.status==='none','overview projects the server-owned current application')
let finish;writeWork=()=>new Promise(resolve=>{finish=resolve});const first=state.applyProvider();await state.applyProvider()
check(writes===1&&state.saving.value,'rapid repeated taps share one mutation lock')
application=app('pending',{version:1});finish({data:{application:{...application},already_submitted:false}})
check(await first===true&&state.application.value.status==='pending'&&!state.saving.value,'server pending is kept as waiting for review, not approved provider')
check(await state.applyProvider()===false&&writes===1,'pending application cannot submit again')
application=app('rejected',{version:1,reason:'门店资料需核对'});await state.readApplication()
check(state.application.value.reason==='门店资料需核对'&&state.application.value.can_apply,'rejection and resubmission eligibility come from the server')
writeWork=async()=>{application=app('pending',{version:2});throw Error('synthetic lost response')}
const oldReads=reads;check(await state.applyProvider()===true&&reads===oldReads+1&&state.application.value.status==='pending','lost write response is recovered by a read of the persisted pending application')
application=app('rejected',{version:2});await state.readApplication();writeWork=async()=>{throw Error('synthetic timeout')};readWork=async()=>{throw Error('synthetic read timeout')}
check(await state.applyProvider()===false&&state.applicationUncertain.value&&state.applicationError.value.includes('不要重复提交'),'unverifiable outcome is visibly uncertain rather than success or a free retry')
const unknownWrites=writes,unknownReads=reads;await state.applyProvider()
check(writes===unknownWrites&&reads===unknownReads+1&&state.applicationUncertain.value,'another tap while uncertain only rereads; it never reposts')
readWork=async()=>({data:{application:{...application}}});await state.applyProvider()
check(writes===unknownWrites&&!state.applicationUncertain.value,'a successful status check clears uncertainty without posting in that same action')
application=app('disabled',{disabled_mode:'blocked',can_apply:false,reason:'已停止合作'});await state.readApplication();await state.applyProvider()
check(writes===unknownWrites&&state.application.value.reason==='已停止合作','disabled applicants cannot bypass the platform decision through resubmission')
readWork=async()=>({data:{application:{status:'mystery',can_apply:true,version:1}}})
check(await state.readApplication()===false&&state.application.value.status==='disabled','malformed reads preserve the prior status with an error')
let resolveRead;readWork=()=>new Promise(resolve=>{resolveRead=resolve});const delayed=state.readApplication();identity='member-b';resolveRead({data:{application:app('approved',{version:9})}});await delayed
check(state.application.value.status!=='approved','a late application response from another identity cannot grant the current identity provider status')
state.resume();check(!state.applicationReady.value&&!state.application.value.status&&!state.applicationUncertain.value,'identity change clears application and uncertain-write state')
identity='';const anonymousReads=reads;check(await state.readApplication()===false&&reads===anonymousReads,'anonymous application reads never reach the transport')

const apiCalls=[],api=execute(read('uni-app/api/promotion.ts'),{'@/utils/request':{default:Object.fromEntries(['get','post'].map(method=>[method,async(url,data)=>{apiCalls.push({method,url,data});return{data:{}}}]))}})
await api.promotionApplication();await api.submitPromotionApplication()
check(apiCalls[0].method==='get'&&apiCalls[0].url==='hsx_lead/promotion/application','application status has a read-only endpoint')
check(apiCalls[1].method==='post'&&JSON.stringify(apiCalls[1].data)==='{"confirm":true}','one-click application sends confirmation only, never applicant identity, city or a chosen rate')

const panelFile='uni-app/components/cooperation/CoopPromotionPanel.vue',panel=read(panelFile),parsed=compiler.parse(panel,{filename:panelFile}).descriptor,script=compiler.compileScript(parsed,{id:'provider-application-ui'})
check(!compiler.compileTemplate({source:parsed.template.content,filename:panelFile,id:'provider-application-ui',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'provider application and tier template compiles')
check(!!sass.compileString(parsed.styles[0].content).css,'provider application scoped CSS compiles')
const navigation=[],panelHides=[],panelDependencies={vue:{...Vue,onBeforeUnmount(){}},'@dcloudio/uni-app':{onHide:callback=>panelHides.push(callback)},'@/utils/common':{redirect(){}},'@/hooks/useShare':{useShare:()=>({setShare(){}})},'@/stores/system':{default:()=>({})},'../../composables/usePromotion':{usePromotion:()=>state},'../../api/cooperation':{coopMoney:String,coopDate:String},'../../utils/cooperation-navigation':{openCooperationTask:(task,params)=>navigation.push({task,params})}}
const Panel=execute(script.content,panelDependencies).default,panelState=Panel.setup({show:false,page:true,initialTab:'overview'},{emit(){},expose(){}})
panelState.posterOpen.value=true;panelHides[0]();check(!panelState.posterOpen.value,'hiding the native promotion page closes its private poster session')
state.overview.value=summary();check(panelState.canInvite.value&&!panelState.providerRole.value,'ordinary members can invite when the server permits it; provider status is not required')
state.overview.value={...summary(),role:'provider'};check(panelState.canInvite.value&&panelState.providerRole.value,'approved role has its distinct provider tier')
state.overview.value={...summary(),role:'normal',promotion_allowed:false};check(!panelState.canInvite.value&&!panelState.providerRole.value,'blocked normal role cannot acquire an invitation from a stale share path')
check(panel.includes('normal_rate')&&panel.includes('provider_rate')&&!panel.includes('sources[item.key].rate +'),'rule comparison uses both explicit tiers, not the legacy provider rate alias')
check(panel.includes('计佣基数：平台实际收取的维护费')&&panel.includes('实际支付的'),'each reward source explains the actual fee base instead of total deal value')
check(panel.includes('application.mobile_masked')&&!panel.includes('application.mobile }}')&&!panel.includes('v-model="application.'),'application displays masked saved identity and no arbitrary editable applicant fields')
check(panel.includes("task.value='application'")&&panel.includes("application:'服务商申请'")&&!panel.includes('CoopRegionFields'),'application reuses the current native promotion page and saved merchant details, not another registration overlay')
check(panel.includes('服务商不自动获得门店会员权益')&&panel.includes('两档不叠加'),'provider approval is independent of merchant membership and rates are not additive')
check(panel.includes('服务商申请免费、不要求先购买入驻权益')&&panel.includes('不保证通过')&&panel.includes('确认资料，免费申请')&&panel.includes("openCooperationTask('profile-edit')"),'application clearly stays free, requires human review and can complete identity facts without a payment detour')
check(panel.includes('ui.applicationUncertain.value ? \'核对申请结果\''),'uncertain application exposes a status check rather than a second submission')
const priorNavigationReads=reads;await panelState.openApplication()
check(navigation.length===1&&navigation[0].task==='promotion'&&navigation[0].params.tab==='application'&&reads===priorNavigationReads,'page application entry creates a native task stack with tab=application instead of swapping an overlay')
identity='member-c';application=app('pending',{version:3});readWork=async()=>({data:{application:{...application}}})
const routedProps=Vue.reactive({show:false,page:true,initialTab:'application'}),routedEvents=[],routed=Panel.setup(routedProps,{emit:(...args)=>routedEvents.push(args),expose(){}})
const routedReads=reads;routedProps.show=true
for(let index=0;index<10;index++){await Vue.nextTick();await Promise.resolve()}
check(routed.task.value==='application'&&routed.heading.value==='服务商申请'&&reads===routedReads+1&&state.application.value.status==='pending','real show watcher initializes the routed application state and reloads saved server status')
routed.closePanel();check(routedEvents.at(-1)?.[0]==='close'&&routed.task.value==='application','native application header delegates one page-stack return instead of replacing the page with a local overview')
const embeddedEvents=[],embedded=Panel.setup({show:false,page:false,initialTab:'overview'},{emit:(...args)=>embeddedEvents.push(args),expose(){}});embedded.task.value='application';embedded.closePanel()
check(embedded.task.value===''&&!embeddedEvents.length,'embedded application header returns to promotion overview before closing its container')
state.saving.value=true;await routed.openApplication();routed.closePanel();check(navigation.length===1&&routedEvents.length===1,'native navigation and header respect the in-flight submission lock');state.saving.value=false

const paymentContext=loadMobileUtility('cooperation-payment')
check(paymentContext.cooperationPaymentContext('membership',0)===null,'subject membership cannot enter the independent collaboration commission cashier context')
const profile=read('uni-app/components/cooperation/CoopProfilePanel.vue'),workbench=read('uni-app/components/cooperation/CooperationWorkbench.vue')
check(!/发单权益|购买后有效一个月|publishing_price\) \+ ' \/ 月'/.test(profile+workbench),'customer copy no longer hard-codes a monthly publishing entitlement')
const commissionFile='uni-app/components/cooperation/CoopCommissionForm.vue',commission=compiler.compileScript(compiler.parse(read(commissionFile)).descriptor,{id:'positive-commission'})
const emitted=[],commissionState=execute(commission.content,{vue:Vue,'../../api/cooperation':{coopMoney:String},'../../utils/cooperation-business':loadMobileUtility('cooperation-business')}).default.setup({lead:{commission_minimum:'0',fee_percent:10,fee_minimum:0,fee_confirmed:true},show:true,busy:false,error:''},{emit:(...args)=>emitted.push(args),expose(){}})
commissionState.amount.value='0';commissionState.submit();check(!emitted.length&&commissionState.localError.value.includes('大于零'),'zero configuration does not authorize a zero payment')
commissionState.amount.value='0.01';commissionState.submit();check(emitted.at(-1)?.[1]==='0.01','a positive amount respects a zero-minimum snapshot without a hard-coded fifty threshold')
console.log(`PASS ${checks} promotion application, two-tier invitation and enrollment term UI checks; actual hook/SFC/utility, synthetic transports only.`)
