import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual mobile hook, utility and SFC code. Every transport is synthetic; no account/payment writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),sass=require('sass')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++},read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
const execute=(source,deps={},globals={})=>{const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{Date,Math,Number,String,Promise,Map,Set,console,uni:{showToast(){},getStorageSync(){},removeStorageSync(){}},...globals})(key=>{if(key in deps)return deps[key];if(key==='../../utils/mobile-ui')return loadMobileUtility('mobile-ui');if(key==='../../utils/profile-identity')return loadMobileUtility('profile-identity');if(key.endsWith('.vue'))return{default:{}};throw Error('Unexpected import '+key)},module,module.exports);return module.exports}
const profileIdentity=loadMobileUtility('profile-identity')
check(profileIdentity.profileMemberNo({member_no:'0001',member_id:99})==='0001'&&profileIdentity.profileMemberNo({member_id:99})==='','real profile identity preserves zero-padded promotion numbers and never fabricates them from member IDs')
const app=(status='none',values={})=>({status,status_label:status,version:0,can_apply:status==='none'||status==='rejected',reason:'',apply_reason:'',merchant_name:'合成测试门店',city:'合成市',contact_name:'合成联系人',mobile_masked:'188****0000',disabled_mode:'normal',...values})
let application=app(),identity='member-a',reads=0,writes=0,readWork=async()=>({data:{application:{...application}}}),writeWork=async()=>{application=app('pending',{version:1});return{data:{application:{...application},already_submitted:false}}}
const summary=()=>({enabled:true,role:'normal',promotion_allowed:true,member:{member_id:1,name:'合成会员'},provider:null,stats:{team_count:0,pending:'0.00',settled:'0.00',held:'0.00'},account:{available:'0.00'},rules:{enabled:true,sources:{membership:{enabled:true,normal_rate:5,provider_rate:10},maintenance:{enabled:false,normal_rate:0,provider_rate:0}}},share:{path:'/addon/hsx_lead/pages/profile/index?mid=1'},application:{...application}})
const dependencies={vue:Vue,'@/utils/common':{getToken:()=>identity},'../api/cooperation':{coopError:(cause,fallback)=>cause?.message||fallback},'../api/promotion':{promotionOverview:async()=>({data:summary()}),promotionApplication:async()=>{reads++;return readWork()},submitPromotionApplication:async()=>{writes++;return writeWork()}}}
const hook=execute(read('uni-app/composables/usePromotion.ts'),dependencies),state=hook.usePromotion()
check(!state.applicationReady.value&&!state.application.value.status,'no application or eligibility is invented before a server read')
check(await state.applyProvider()===false&&writes===0,'application cannot be submitted before current identity and server eligibility exist')
await state.reload();check(state.applicationReady.value&&state.application.value.status==='none','overview projects the server-owned current application')
let finish;writeWork=()=>new Promise(resolve=>{finish=resolve});const first=state.applyProvider();await state.applyProvider()
check(writes===1&&state.saving.value,'rapid repeated taps share one mutation lock')
application=app('pending',{version:1});finish({data:{application:{...application},already_submitted:false}})
check(await first===true&&state.application.value.status==='pending'&&!state.saving.value,'server pending is kept as waiting for review, not approved provider')
check(await state.applyProvider()===false&&writes===1,'pending application cannot submit again')
application=app('rejected',{version:1,reason:'门店资料需核对'});await state.readApplication()
check(state.application.value.reason==='门店资料需核对'&&state.application.value.can_apply,'rejection and resubmission eligibility come from the server')
writeWork=async()=>{application=app('pending',{version:2});throw Error('synthetic lost response')}
const oldReads=reads;check(await state.applyProvider()===true&&reads===oldReads+1&&state.application.value.status==='pending','lost write response is recovered by a read of the persisted pending application')
application=app('rejected',{version:2});await state.readApplication();writeWork=async()=>{throw Error('synthetic timeout')};readWork=async()=>{throw Error('synthetic read timeout')}
check(await state.applyProvider()===false&&state.applicationUncertain.value&&state.applicationError.value.includes('不要重复提交'),'unverifiable outcome is visibly uncertain rather than success or a free retry')
const unknownWrites=writes,unknownReads=reads;await state.applyProvider()
check(writes===unknownWrites&&reads===unknownReads+1&&state.applicationUncertain.value,'another tap while uncertain only rereads; it never reposts')
readWork=async()=>({data:{application:{...application}}});await state.applyProvider()
check(writes===unknownWrites&&!state.applicationUncertain.value,'a successful status check clears uncertainty without posting in that same action')
application=app('disabled',{disabled_mode:'blocked',can_apply:false,reason:'已停止合作'});await state.readApplication();await state.applyProvider()
check(writes===unknownWrites&&state.application.value.reason==='已停止合作','disabled applicants cannot bypass the platform decision through resubmission')
readWork=async()=>({data:{application:{status:'mystery',can_apply:true,version:1}}})
check(await state.readApplication()===false&&state.application.value.status==='disabled','malformed reads preserve the prior status with an error')
let resolveRead;readWork=()=>new Promise(resolve=>{resolveRead=resolve});const delayed=state.readApplication();identity='member-b';resolveRead({data:{application:app('approved',{version:9})}});await delayed
check(state.application.value.status!=='approved','a late application response from another identity cannot grant the current identity provider status')
state.resume();check(!state.applicationReady.value&&!state.application.value.status&&!state.applicationUncertain.value,'identity change clears application and uncertain-write state')
identity='';const anonymousReads=reads;check(await state.readApplication()===false&&reads===anonymousReads,'anonymous application reads never reach the transport')

const apiCalls=[],api=execute(read('uni-app/api/promotion.ts'),{'@/utils/request':{default:Object.fromEntries(['get','post'].map(method=>[method,async(url,data)=>{apiCalls.push({method,url,data});return{data:{}}}]))}})
await api.promotionApplication();await api.submitPromotionApplication()
check(apiCalls[0].method==='get'&&apiCalls[0].url==='hsx_lead/promotion/application','application status has a read-only endpoint')
check(apiCalls[1].method==='post'&&JSON.stringify(apiCalls[1].data)==='{"confirm":true}','one-click application sends confirmation only, never applicant identity, city or a chosen rate')

const panelFile='uni-app/components/cooperation/CoopPromotionPanel.vue',panel=read(panelFile),parsed=compiler.parse(panel,{filename:panelFile}).descriptor,script=compiler.compileScript(parsed,{id:'provider-application-ui'})
check(!compiler.compileTemplate({source:parsed.template.content,filename:panelFile,id:'provider-application-ui',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'provider application and tier template compiles')
check(!!sass.compileString(parsed.styles[0].content).css,'provider application scoped CSS compiles')
const navigation=[],panelHides=[],panelDependencies={vue:{...Vue,onBeforeUnmount(){}},'@dcloudio/uni-app':{onHide:callback=>panelHides.push(callback)},'@/utils/common':{redirect(){}},'@/hooks/useShare':{useShare:()=>({setShare(){}})},'@/stores/system':{default:()=>({})},'../../composables/usePromotion':{usePromotion:()=>state},'../../api/cooperation':{coopMoney:String,coopDate:String},'../../utils/cooperation-navigation':{openCooperationTask:(task,params)=>navigation.push({task,params})}}
const Panel=execute(script.content,panelDependencies).default,panelState=Panel.setup({show:false,page:true,initialTab:'overview'},{emit(){},expose(){}})
panelState.posterOpen.value=true;panelHides[0]();check(!panelState.posterOpen.value,'hiding the native promotion page closes its private poster session')
state.overview.value=summary();check(panelState.canInvite.value&&!panelState.providerRole.value,'ordinary members can invite when the server permits it; provider status is not required')
state.overview.value={...summary(),role:'provider'};check(panelState.canInvite.value&&panelState.providerRole.value,'approved role has its distinct provider tier')
state.overview.value={...summary(),role:'normal',promotion_allowed:false};check(!panelState.canInvite.value&&!panelState.providerRole.value,'blocked normal role cannot acquire an invitation from a stale share path')
check(panel.includes('normal_rate')&&panel.includes('provider_rate')&&!panel.includes('sources[item.key].rate +'),'rule comparison uses both explicit tiers, not the legacy provider rate alias')
check(panel.includes('按平台实收维护费计算')&&panel.includes('只按实付服务费计算，不含押金和经验费'),'each reward source explains the actual fee base instead of total deal value')
check(panel.includes('application.mobile_masked')&&!panel.includes('application.mobile }}')&&!panel.includes('v-model="application.'),'application displays masked saved identity and no arbitrary editable applicant fields')
check(panel.includes("task.value='application'")&&panel.includes("application:'服务商申请'")&&!panel.includes('CoopRegionFields'),'application reuses the current native promotion page and saved merchant details, not another registration overlay')
check(panel.includes('服务商不自动获得门店会员权益')&&panel.includes('两档不叠加'),'provider approval is independent of merchant membership and rates are not additive')
check(panel.includes('服务商申请免费、不要求先购买入驻权益')&&panel.includes('不保证通过')&&panel.includes('确认资料，免费申请')&&panel.includes("openCooperationTask('profile-edit')"),'application clearly stays free, requires human review and can complete identity facts without a payment detour')
check(panelState.footerKind.value===''&&panel.includes("footerKind.value==='check'?'核对申请状态'"),'overview has no manufactured footer and uncertain applications use a status-check action')
const priorNavigationReads=reads;await panelState.openApplication()
check(navigation.length===1&&navigation[0].task==='promotion'&&navigation[0].params.tab==='application'&&reads===priorNavigationReads,'page application entry creates a native task stack with tab=application instead of swapping an overlay')
identity='member-c';application=app('pending',{version:3});readWork=async()=>({data:{application:{...application}}})
const routedProps=Vue.reactive({show:false,page:true,initialTab:'application'}),routedEvents=[],routed=Panel.setup(routedProps,{emit:(...args)=>routedEvents.push(args),expose(){}})
const routedReads=reads;routedProps.show=true
for(let index=0;index<10;index++){await Vue.nextTick();await Promise.resolve()}
check(routed.task.value==='application'&&routed.heading.value==='服务商申请'&&reads===routedReads+1&&state.application.value.status==='pending','real show watcher initializes the routed application state and reloads saved server status')
routed.closePanel();check(routedEvents.at(-1)?.[0]==='close'&&routed.task.value==='application','native application header delegates one page-stack return instead of replacing the page with a local overview')
const embeddedEvents=[],embedded=Panel.setup({show:false,page:false,initialTab:'overview'},{emit:(...args)=>embeddedEvents.push(args),expose(){}});embedded.task.value='application';embedded.closePanel()
check(embedded.task.value===''&&!embeddedEvents.length,'embedded application header returns to promotion overview before closing its container')
panelState.task.value='rules';panelState.closePanel();check(panelState.task.value==='','native promotion rule header first returns to the promotion centre')
check(!parsed.template.content.includes('promo-back')&&(parsed.template.content.match(/#footer/g)||[]).length===1,'one native navigation return and one conditional footer slot replace duplicate inline return areas')
state.applicationReady.value=true;state.applicationError.value='';state.applicationUncertain.value=false;panelState.task.value='application'
for(const status of ['pending','approved']){state.application.value=app(status,{can_apply:false});check(panelState.footerKind.value==='','pending or approved status has no redundant bottom submit/return action')}
state.application.value=app('none');check(panelState.footerKind.value==='apply'&&panelState.footerLabel.value==='确认资料，免费申请','an eligible new applicant has exactly one meaningful submit action')
state.applicationUncertain.value=true;check(panelState.footerKind.value==='check'&&panelState.footerLabel.value==='核对申请状态','unknown submission switches to checking the original status, never repeat application')
state.applicationUncertain.value=false;state.application.value=app('none',{merchant_name:'',can_apply:false});state.overview.value={...summary(),enabled:true,promotion_allowed:true};check(panelState.footerKind.value==='profile','missing saved merchant identity leads to one profile completion action')
panelState.task.value='bind';state.invitation.value={can_bind:true};state.confirmedUpstream.value=null;check(panelState.footerKind.value==='bind'&&parsed.template.content.includes('text="取消"'),'unsubmitted relationship confirmation retains an explicit cancel alongside confirm')
check(panelState.stageLabel('待完善门店')==='待完善门店'&&panelState.stageLabel('已登记门店')==='已登记门店','older server Chinese stage labels no longer collapse into a generic joined label')
check(panelState.membershipStatusLabel({})==='状态待更新'&&panelState.membershipStatusLabel({membership:{status:'active'}})==='生效中'&&panelState.membershipStatusLabel({membership:{status:'review'}})==='待核对','invitation membership display is explicit and does not turn missing proof into unpaid or active')
state.saving.value=true;await routed.openApplication();routed.closePanel();check(navigation.length===1&&routedEvents.length===1,'native navigation and header respect the in-flight submission lock');state.saving.value=false

// Render the real compiled template with inert native controls and synthetic
// server state. This verifies slot output, not just a string or event handler.
const{renderToString}=require('@vue/server-renderer')
const nativeSheet={props:['show','title'],setup(props,{slots}){return()=>Vue.h('section',{'data-native-sheet':true},[Vue.h('header',props.title),slots.default?.(),slots.footer?Vue.h('footer',slots.footer()):null])}}
const nativeButton={props:['text'],setup(props){return()=>Vue.h('button',props.text)}}
const box={setup(props,{slots}){return()=>Vue.h('div',slots.default?.())}}
const renderState={...state,reload:async()=>false,readApplication:async()=>false}
const renderDeps={...panelDependencies,'../../composables/usePromotion':{usePromotion:()=>renderState},'./CoopTaskSheet.vue':{default:nativeSheet},'./CoopState.vue':{default:box},'./CooperationSearch.vue':{default:box},'./CoopInvitePoster.vue':{default:box}}
const RealPanel=execute(script.content,renderDeps).default
const renderedTemplate=execute(compiler.compileTemplate({source:parsed.template.content,filename:panelFile,id:'provider-render',compilerOptions:{bindingMetadata:script.bindings}}).code,{vue:Vue}).render
async function renderPanel(taskValue='',tabValue='overview'){
    const component={...RealPanel,render:renderedTemplate,setup(props,ctx){const value=RealPanel.setup(props,ctx);value.task.value=taskValue;value.tab.value=tabValue;return value}}
    const app=Vue.createSSRApp({render:()=>Vue.h(component,{show:true,page:true,initialTab:'overview'})})
    app.component('UButton',nativeButton);app.component('UIcon',box);app.component('UCollapse',box);app.component('UCollapseItem',box);app.config.warnHandler=()=>{}
    return renderToString(app)
}
state.ready.value=true;state.loading.value=false;state.error.value='';state.overview.value=summary();state.applicationError.value='';state.applicationUncertain.value=false;state.applicationReady.value=true
const rulesHtml=await renderPanel('rules')
check(rulesHtml.includes('推广奖励规则')&&!rulesHtml.includes('返回推广中心')&&!rulesHtml.includes('<footer'),'actual rules rendering contains only the native header return, no inline or bottom duplicate return')
for(const status of['pending','approved']){state.application.value=app(status,{can_apply:false});const html=await renderPanel('application');check(!html.includes('<footer'),'actual settled application status does not render a blank/double-action footer')}
state.application.value=app('none');const applyHtml=await renderPanel('application');check((applyHtml.match(/<footer/g)||[]).length===1&&applyHtml.includes('确认资料，免费申请'),'actual eligible application renders one meaningful footer')
state.invitation.value={can_bind:true};state.confirmedUpstream.value=null;const bindHtml=await renderPanel('bind');check(bindHtml.includes('取消')&&bindHtml.includes('确认邀请关系')&&(bindHtml.match(/<footer/g)||[]).length===1,'actual unsubmitted binding preserves cancel and confirmation within one footer')
state.team.value=[{member_id:9,name:'合成会员',mobile_masked:'188****0000',merchant_name:'合成共享门店',stage:'已加入门店',stage_label:'已加入门店',membership:{status:'active',status_label:'生效中',level_name:'合成白银',shared:true}}]
const teamHtml=await renderPanel('','team')
check(teamHtml.includes('门店会员')&&teamHtml.includes('生效中')&&teamHtml.includes('合成白银')&&teamHtml.includes('共享门店权益')&&!teamHtml.includes('本人已支付'),'actual invitation list distinguishes shop membership from personally buying a plan')
check(!parsed.template.content.includes('promo-invite-plus')&&parsed.template.content.includes('name="share" size="44"'),'invitation art uses one existing line icon rather than decorative stacked icon shapes')

const paymentContext=loadMobileUtility('cooperation-payment')
check(paymentContext.cooperationPaymentContext('membership',0)===null,'subject membership cannot enter the independent collaboration commission cashier context')
const profile=read('uni-app/components/cooperation/CoopProfilePanel.vue'),workbench=read('uni-app/components/cooperation/CooperationWorkbench.vue')
check(!/发单权益|购买后有效一个月|publishing_price\) \+ ' \/ 月'/.test(profile+workbench),'customer copy no longer hard-codes a monthly publishing entitlement')
const commissionFile='uni-app/components/cooperation/CoopCommissionForm.vue',commission=compiler.compileScript(compiler.parse(read(commissionFile)).descriptor,{id:'positive-commission'})
const emitted=[],commissionState=execute(commission.content,{vue:Vue,'../../api/cooperation':{coopMoney:String},'../../utils/cooperation-business':loadMobileUtility('cooperation-business')}).default.setup({lead:{commission_minimum:'0',fee_percent:10,fee_minimum:0,fee_confirmed:true},show:true,busy:false,error:''},{emit:(...args)=>emitted.push(args),expose(){}})
commissionState.amount.value='0';commissionState.submit();check(!emitted.length&&commissionState.localError.value.includes('大于零'),'zero configuration does not authorize a zero payment')
commissionState.amount.value='0.01';commissionState.submit();check(emitted.at(-1)?.[1]==='0.01','a positive amount respects a zero-minimum snapshot without a hard-coded fifty threshold')
console.log(`PASS ${checks} promotion application, two-tier invitation and enrollment term UI checks; actual hook/SFC/utility, synthetic transports only.`)
