import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {execFileSync} from 'node:child_process'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

// Real PHP dictionaries and real admin SFC setup; no framework service, site,
// browser, member information, payment, saved decoration or database access.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..')
const require=createRequire(path.join(workspace,'admin/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const paths={components:'app/dict/diy/components.php',template:'app/dict/diy/template.php',pages:'app/dict/diy/pages.php',links:'app/dict/diy/links.php',menus:'app/dict/menu/site.php'}
const php=`function get_lang($key){return $key;} $data=[];${Object.entries(paths).map(([key,file])=>`$data[${JSON.stringify(key)}]=require ${JSON.stringify(path.join(plugin,file))};`).join('')}echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);`
const dictionaries=JSON.parse(execFileSync(process.env.PHP_BIN||'php',['-d','display_errors=stderr','-d','error_reporting=0','-r',php],{encoding:'utf8'}))
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const type='DIY_HSX_LEAD_MEMBER_INDEX',page=dictionaries.pages[type].hsx_lead_member_index
const kinds={identity:'LeadProfileIdentity',tools:'LeadProfileTools',benefits:'LeadProfileBenefits',promotion:'LeadProfilePromotion'}
const definition=dictionaries.components.HSX_LEAD_COMPONENT.list
check(dictionaries.template[type].page==='/addon/hsx_lead/pages/profile/index'&&dictionaries.template[type].type==='member_index'&&dictionaries.template[type].action==='decorate','member decoration uses the existing native route and framework member_index contract')
check(dictionaries.template.DIY_HSX_LEAD_INDEX.page==='/addon/hsx_lead/pages/index'&&dictionaries.pages.DIY_HSX_LEAD_INDEX.hsx_lead_index.data.value.map(item=>item.componentName).join(',')==='LeadCooperationHero,LeadRoleEntry,LeadRoleEntry,LeadBusinessNavigation','existing homepage route uses independent hero, two role cards and business block')
check(page.mode==='diy'&&page.data.value.map(item=>item.componentName).join(',')==='LeadProfileIdentity,GraphicNav,LeadProfileTools,LeadProfileBenefits,LeadProfilePromotion','member default composes native navigation with necessary dynamic blocks')
check(new Set(page.data.value.map(item=>item.id)).size===5,'default block IDs are unique')
check(page.data.global.title==='我的门店'&&dictionaries.pages.DIY_HSX_LEAD_INDEX.hsx_lead_index.data.global.title==='商户协作','member global settings do not overwrite homepage globals')
check(page.data.global.bottomTabBar.designNav.key==='hsx_lead'&&page.data.global.bottomTabBar.isShow===true,'framework tabbar remains the only declared member navigation')
check(page.data.global.popWindow.show===0&&page.data.global.copyright.isShow===false,'member default does not enable marketing overlays or unrelated blocks')
for(const [kind,name] of Object.entries(kinds)){
    const item=definition[name],block=page.data.value.find(value=>value.componentName===name)
    check(item.path===`edit-lead-profile-${kind}`&&JSON.stringify(item.support_page)===JSON.stringify([type]),`${kind} metadata is isolated to the member decoration page`)
    check(item.uses===1&&block.uses===1&&Array.isArray(block.ignore)&&block.componentIsShow===true,`${kind} obeys framework component/card contract`)
    check(item.value.title&&item.value.titleColor&&item.value.panelColor===''&&item.template.componentStartBgColor,`${kind} has transparent inner presentation and a framework-owned outer background`)
    check(!Object.keys(item.value).some(key=>/^(?:member_id|entity_id|balance|price|expiry|level_id|level_code|account_limit|capabilities|commission|membership)$/.test(key)),`${kind} has no editable identity, balance, fee or membership facts`)
    check(block.path===item.path&&['top','bottom','both'].every(key=>Number.isFinite(block.margin[key])),`${kind} default layout is safe for framework margin rendering`)
}
const flatten=items=>items.flatMap(item=>[item,...flatten(item.children||[])])
const menus=flatten(dictionaries.menus),menu=menus.find(item=>item.menu_key==='hsx_lead_cooperation_profile_home')
check(menu?.view_path==='cooperation/profile-home-page'&&menu.router_path==='hsx_lead/cooperation/profile-home'&&menu.is_show==='1','member decoration has its own visible site menu and view')
check(new Set(menus.map(item=>item.menu_key)).size===menus.length,'new menu does not collide with existing permission identifiers')
const source=fs.readFileSync(path.join(plugin,'admin/views/cooperation/profile-home-page.vue'),'utf8')
check(source.includes("permission=\"hsx_lead_cooperation_profile_home\"")&&source.includes("@/app/views/diy/member.vue")&&!source.includes('/decorate/edit'),'admin entry reuses the framework selected-page manager and exact permission key')
check(!/request\.(?:post|put)|\bfetch\(|saveCooperation|createCooperation/.test(source),'opening decoration does not execute business writes')
const componentPath=path.join(plugin,'admin/views/diy/components/ProfileSectionEditor.vue'),component=compiler.parse(fs.readFileSync(componentPath,'utf8'),{filename:componentPath})
check(component.errors.length===0,'shared section editor parses')
const script=compiler.compileScript(component.descriptor,{id:'profile-editor'})
check(compiler.compileTemplate({source:component.descriptor.template.content,filename:componentPath,id:'profile-editor',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length===0,'shared section editor template compiles')
check(!script.content.includes('/api/')&&!script.content.includes('postMessage')&&!script.content.includes('window'),'editor does not load or transmit member business data')
for(const [kind,name] of Object.entries(kinds)){
    const wrapperPath=path.join(plugin,'admin/views/diy/components',`edit-lead-profile-${kind}.vue`),wrapper=compiler.parse(fs.readFileSync(wrapperPath,'utf8'),{filename:wrapperPath})
    check(wrapper.errors.length===0&&wrapper.descriptor.template.content.includes(`kind="${kind}"`)&&wrapper.descriptor.template.content.includes('<slot name="style"'),`${kind} wrapper uses shared logic and forwards framework style slot`)
    const wrapperScript=compiler.compileScript(wrapper.descriptor,{id:'wrapper-'+kind})
    check(compiler.compileTemplate({source:wrapper.descriptor.template.content,filename:wrapperPath,id:'wrapper-'+kind,compilerOptions:{bindingMetadata:wrapperScript.bindings}}).errors.length===0,`${kind} wrapper compiles`)
    const store=Vue.reactive({editTab:'content',value:[{componentName:name}],predefineColors:[],get editComponent(){return this.value[0]}}),mounted=[],module={exports:{}}
    const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{String,Object,Array})(key=>key==='vue'?{...Vue,onMounted:callback=>mounted.push(callback)}:key==='@/stores/modules/diy'?{default:()=>store}:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports)
    module.exports.default.setup({kind,value:store.value[0]},{expose(){}});mounted.forEach(callback=>callback())
    check(store.editComponent.title===definition[name].value.title&&store.editComponent.verify(0).code===true,`${kind} real editor setup fills expected PHP-consistent defaults`)
    store.editComponent.showTitle=1;store.editComponent.title='';check(store.editComponent.verify(0).message==='请填写区块标题或关闭标题显示',`${kind} visible missing title has localized validation`)
    store.editComponent.showTitle=0;check(store.editComponent.verify(0).code===true,`${kind} can intentionally hide its title`)
    store.editComponent.title='测试区块';check(store.value[0].title==='测试区块'&&store.editComponent.verify(0).code===true,`${kind} binds to framework state rather than a separate draft`)
    const firstToggle=Object.keys(definition[name].value).find(key=>key.startsWith('show'))
    store.editComponent[firstToggle]='invalid';check(store.editComponent.verify(0).code===false,`${kind} rejects invalid display toggles`)
    store.editComponent[firstToggle]=0;check(store.editComponent.verify(0).code===true,`${kind} permits an explicitly hidden entry without changing business records`)
    for(const [key,value]of Object.entries(definition[name].value))if(key!=='title'&&key!==firstToggle)check(JSON.stringify(store.editComponent[key])===JSON.stringify(value),`${kind} JSON default agrees with real editor: ${key}`)
    if(kind==='tools'){check(!('layout' in definition[name].value),'notification block does not invent a second navigation layout');check(['showProfile','showCapability','showInventory','showConnection','showMembers'].every(key=>definition[name].value[key]===0),'optional ordinary links are off by default; native GraphicNav remains the only default ordinary navigation')}
}
const navigation=page.data.value.find(item=>item.componentName==='GraphicNav')
check(navigation.path==='edit-graphic-nav'&&navigation.uses===0,'ordinary entries use the existing framework renderer/editor')
check(navigation.list.length===5&&new Set(navigation.list.map(item=>item.id)).size===5,'default navigation entries have stable unique IDs')
for(const item of navigation.list){
    const link=dictionaries.links.HSX_LEAD_MERCHANT_LINK.child_list.find(link=>link.name===item.link.name)
    check(link&&link.url===item.link.url&&item.link.parent==='HSX_LEAD_MERCHANT_LINK','default link is registered in the standard picker: '+item.title)
    check(fs.existsSync(path.join(plugin,'resource',item.imageUrl.replace('addon/hsx_lead/',''))),'default navigation image is packaged: '+item.title)
}
for(const name of ['HSX_LEAD_MERCHANT_HOME','HSX_LEAD_MERCHANT_PROFILE'])check(dictionaries.links.HSX_LEAD_MERCHANT_LINK.child_list.find(link=>link.name===name).action==='decorate','standard page manager can decorate '+name)
console.log(`PASS ${checks} profile DIY admin/dictionary checks; real PHP and Vue setup, no site API, member data or saved decoration mutation.`)
