<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,EntityMembershipService,PaymentService,PaymentOrderLifecycle,Store};
use addon\hsx_lead\app\middleware\CooperationPaymentGuard;
use addon\hsx_lead\app\listener\pay\{CooperationPayCreate,CooperationPayCloseGuard,CooperationPaySuccess};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,OnlinePayDict};
use app\service\core\pay\CorePayService;
use app\service\core\member\CoreMemberAccountService;
use app\dict\member\MemberAccountTypeDict;
use core\exception\{CommonException,PayException};
use think\facade\{Db,Event};

final class CashierContinuationRecoveryProvider
{
    public array$calls=[];
    public function __construct(private array$answers,private $closed=true){}
    public function getOrder(string$number){$this->calls[]='query:'.$number;$answer=array_shift($this->answers);if($answer instanceof Throwable)throw$answer;return$answer;}
    public function close(string$number){$this->calls[]='close:'.$number;if($this->closed instanceof Throwable)throw$this->closed;return$this->closed;}
}
/** Only the existing CorePayService sender is doubled, never checkOrCreate or PayCreate. */
final class CashierContinuationPrepayProvider
{
    public array$calls=[];public array$channels=[];
    public function init(int$site,string$channel,string$type):self{$this->channels[]=['site'=>$site,'channel'=>$channel,'type'=>$type];return$this;}
    public function pay(string$number,$money,...$other):array{$this->calls[]=['out_trade_no'=>$number,'money'=>(string)$money];return['synthetic_prepay'=>true,'out_trade_no'=>$number];}
    public function close(string$number){throw new RuntimeException('Unsafe core fallback must not close a processing trade');}
    public function getOrder(string$number){throw new RuntimeException('Core fallback must not query instead of plugin recovery');}
}

$checks=0;$pdo=null;$schema='';$failed=false;
function continuationCheck(bool$condition,string$label):void{if(!$condition)throw new RuntimeException($label);$GLOBALS['checks']++;}
function continuationDeny(callable$fn,string$label,?string$contains=null):void{try{$fn();}catch(CommonException|PayException$error){if($contains!==null&&!str_contains($error->getMessage(),$contains))throw new RuntimeException('Unexpected rejection: '.$label.'; '.get_class($error).': '.$error->getMessage());continuationCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();
    $ddl=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund','pay_channel']as$table){if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$ddl,$match))throw new RuntimeException('Missing official receipt fixture DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));}
    $config=ConfigService::defaults();$config['enabled']=true;$config['fee_confirmed']=true;(new ConfigService(new Context($site,1)))->save($config);
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2,false,['deposit_amount'=>'200.00','cycles'=>[['key'=>'year','name'=>'年付','months'=>12,'enabled'=>true,'price'=>'99.00']]])+['site_id'=>$site]);
    foreach([PayDict::WECHATPAY,PayDict::BALANCEPAY,PayDict::ALIPAY]as$type)Db::name('pay_channel')->insert(['site_id'=>$site,'type'=>$type,'channel'=>'weapp','status'=>1,'config'=>'[]']);
    Event::remove('PayCreate');Event::listen('PayCreate',CooperationPayCreate::class);Event::remove('PayClose');Event::listen('PayClose',CooperationPayCloseGuard::class);Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    $app->http->name('api');$number=300;
    $new=static function(string$label,int$status=1)use($site,&$number):array{
        $member=++$number;Db::name('member')->insert(['site_id'=>$site,'member_id'=>$member,'nickname'=>'Cashier fixture '.$member,'mobile'=>sprintf('199%08d',$member)]);$ctx=new Context($site,0,$member);
        $merchant=(new PartnerService($ctx))->saveProfile(['name'=>'Cashier '.$label,'contact_name'=>'Fixture','mobile'=>sprintf('199%08d',$member),'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic address']);
        $quote=(new EntityMembershipService($ctx))->quote('ML701','year');$order=(new PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'year','request_id'=>'cashier-continue-'.$label,'quote_token'=>$quote['quote_token']]);$no='CONTINUE_'.$member;
        Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>$member,'from_main_id'=>$member,'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>$status,'type'=>PayDict::WECHATPAY,'channel'=>'weapp','pay_time'=>$status===(int)PayDict::STATUS_FINISH?time():0]);
        return[$ctx,$order,$no,(int)$merchant['id']];
    };
    $http=static function(Context$ctx,array$order,string$type=PayDict::WECHATPAY,string$method='POST',string$action='pay'):app\Request{
        $request=new app\Request();$request->setController('pay.Pay')->setAction($action)->withServer(['REQUEST_METHOD'=>$method])->withHeader([system_name('channel_name')=>'weapp']);$params=['trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'type'=>$type];if($method==='POST')$request->withPost($params);else$request->withGet($params);$request->siteId($ctx->site);$request->memberId($ctx->memberId);return$request;
    };
    $core=static function(CashierContinuationPrepayProvider$provider):CorePayService{$core=new CorePayService();$property=new ReflectionProperty(CorePayService::class,'pay_event');$property->setAccessible(true);$property->setValue($core,$provider);return$core;};
    $status=static fn(string$state):array=>['status'=>$state];
    $run=static function(Context$ctx,array$order,string$type,CashierContinuationRecoveryProvider$provider,&$nextCalls,?CashierContinuationPrepayProvider$sender=null)use($http,$core):mixed{
        $guard=new CooperationPaymentGuard(static fn(int$s,string$c,string$t):object=>$provider);$sender=$sender??new CashierContinuationPrepayProvider();$cashier=$core($sender);$request=$http($ctx,$order,$type);
        return$guard->handle($request,static function(app\Request$request)use(&$nextCalls,$cashier,$ctx,$order,$type){$nextCalls++;return$cashier->pay($ctx->site,PaymentService::TRADE_TYPE,(int)$order['id'],$type,'weapp','synthetic-openid');});
    };

    foreach([PayDict::WECHATPAY,PayDict::BALANCEPAY]as$type){
        [$ctx,$order,$no]=$new($type);$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)]);$sender=new CashierContinuationPrepayProvider();$next=0;$ordersBefore=Store::query('coop_order',$site)->count();$paysBefore=Db::name('pay')->where('trade_id',$order['id'])->count();
        $response=$run($ctx,$order,$type,$provider,$next,$sender);$rows=Db::name('pay')->where('site_id',$site)->where('trade_type',PaymentService::TRADE_TYPE)->where('trade_id',$order['id'])->order('id')->select()->toArray();$latest=end($rows);
        continuationCheck($next===1&&$response['synthetic_prepay']===true,'actual POST pay can continue after safely recovering abandoned WeChat, requested '.$type);
        continuationCheck($provider->calls===['query:'.$no,'close:'.$no,'query:'.$no],'HTTP continuation checks NOTPAY then authoritative CLOSED before entering cashier');
        continuationCheck(count($rows)===$paysBefore+1&&(int)$rows[0]['status']===(int)PayDict::STATUS_CANCEL&&$latest['out_trade_no']!==$no&&(int)$latest['status']===(int)PayDict::STATUS_ING,'real framework checkOrCreate makes one new prepay after proven old cancellation');
        continuationCheck((int)$latest['trade_id']===(int)$order['id']&&Store::query('coop_order',$site)->count()===$ordersBefore&&Store::row('coop_order',$site,(int)$order['id'])['status']==='unpaid','same business membership order is preserved, never another membership purchase');
        continuationCheck($sender->channels===[['site'=>$site,'channel'=>'weapp','type'=>$type]]&&count($sender->calls)===1&&$latest['type']===$type,'selected payment type reaches the actual framework sender without using old WeChat mode');
    }

    foreach([OnlinePayDict::USERPAYING,'UNKNOWN',new RuntimeException('Synthetic timeout')]as$index=>$answer){
        [$ctx,$order,$no]=$new('uncertain-'.$index);$provider=new CashierContinuationRecoveryProvider([$answer instanceof Throwable?$answer:$status($answer)]);$sender=new CashierContinuationPrepayProvider();$next=0;$before=Db::name('pay')->count();
        continuationDeny(function()use($run,$ctx,$order,$provider,&$next,$sender){return$run($ctx,$order,PayDict::WECHATPAY,$provider,$next,$sender);},'POST cannot restart an unresolved payment');
        continuationCheck($next===0&&$sender->calls===[]&&$provider->calls===['query:'.$no],'unknown, USERPAYING and timeout never enter cashier or send a close request');
        continuationCheck(Db::name('pay')->count()===$before&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_ING&&Store::row('coop_order',$site,(int)$order['id'])['status']==='unpaid','uncertain original payment evidence is retained');
    }

    foreach(['success','payment-race','local-finish']as$label){
        [$ctx,$order,$no,$merchant]=$new($label,$label==='local-finish'?(int)PayDict::STATUS_FINISH:(int)PayDict::STATUS_ING);
        $answers=$label==='success'?[$status(OnlinePayDict::SUCCESS)]:($label==='payment-race'?[$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::SUCCESS)]:[]);$provider=new CashierContinuationRecoveryProvider($answers);$sender=new CashierContinuationPrepayProvider();$next=0;$before=Db::name('pay')->count();
        continuationDeny(function()use($run,$ctx,$order,$provider,&$next,$sender){return$run($ctx,$order,PayDict::BALANCEPAY,$provider,$next,$sender);},'successful original payment cannot enter another selected payment method');
        continuationCheck($next===0&&$sender->calls===[]&&Db::name('pay')->count()===$before&&Store::row('coop_order',$site,(int)$order['id'])['status']==='paid','successful receipt is reconciled without duplicate cashier charge');
        continuationCheck(EntityMembershipService::state($site,$merchant)['active'],'real original success restores the already-purchased rights');
        $expiry=EntityMembershipService::state($site,$merchant)['expires_at'];$repeat=new CashierContinuationRecoveryProvider([]);$again=0;continuationDeny(function()use($run,$ctx,$order,$repeat,&$again){return$run($ctx,$order,PayDict::WECHATPAY,$repeat,$again);},'paid retry remains blocked');
        continuationCheck($again===0&&$repeat->calls===[]&&EntityMembershipService::state($site,$merchant)['expires_at']===$expiry,'repeated POST cannot extend membership again or query paid gateway again');
    }

    [$ctx,$order,$no]=$new('expired');Store::query('coop_order',$site)->where('id',$order['id'])->update(['create_time'=>time()-121]);$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)]);$next=0;
    continuationDeny(function()use($run,$ctx,$order,$provider,&$next){return$run($ctx,$order,PayDict::BALANCEPAY,$provider,$next);},'expired order cannot start another cashier');
    continuationCheck($next===0&&Store::row('coop_order',$site,(int)$order['id'])['status']==='closed'&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_CANCEL,'expired POST safely closes original channel and business, rather than charging stale quote');
    continuationCheck((new EntityMembershipService($ctx))->quote('ML701','year')['existing_order_id']===0,'verified expired closure permits a fresh signed purchase flow');

    foreach(['wrong-user','wrong-money','unsupported','unavailable-channel','get-pay']as$label){
        [$ctx,$order,$no]=$new($label);$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::CLOSED)]);$guard=new CooperationPaymentGuard(static fn(int$s,string$c,string$t):object=>$provider);$next=0;$type=$label==='unsupported'?PayDict::OFFLINEPAY:($label==='unavailable-channel'?PayDict::ALIPAY:PayDict::WECHATPAY);
        $request=$http($label==='wrong-user'?new Context($site,0,101):$ctx,$order,$type,$label==='get-pay'?'GET':'POST');
        if($label==='wrong-money')Db::name('pay')->where('out_trade_no',$no)->update(['money'=>'1.00']);
        if($label==='unavailable-channel')Db::name('pay_channel')->where('site_id',$site)->where('type',PayDict::ALIPAY)->update(['status'=>0]);
        continuationDeny(function()use($guard,$request,&$next){return$guard->handle($request,function()use(&$next){$next++;return'unsafe-cashier';});},'preflight rejects '.$label.' before a provider request');
        continuationCheck($provider->calls===[]&&$next===0&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_ING,'preflight failure does not disclose or change original payment');
        if($label==='unavailable-channel')Db::name('pay_channel')->where('site_id',$site)->where('type',PayDict::ALIPAY)->update(['status'=>1]);
    }

    [$ctx,$order,$no]=$new('readonly-info');$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::CLOSED)]);$guard=new CooperationPaymentGuard(static fn(int$s,string$c,string$t):object=>$provider);$request=$http($ctx,$order,PayDict::WECHATPAY,'GET','info');$coreInfo=$core(new CashierContinuationPrepayProvider());$before=Db::name('pay')->count();
    $result=$guard->handle($request,static fn()=>$coreInfo->getInfoByTrade($site,PaymentService::TRADE_TYPE,(string)$order['id'],'weapp'));
    continuationCheck(is_array($result)&&$result['out_trade_no']===$no&&(int)$result['status']===(int)PayDict::STATUS_ING,'GET info remains a read of the existing processing cashier');
    continuationCheck($provider->calls===[]&&Db::name('pay')->count()===$before&&Store::row('coop_order',$site,(int)$order['id'])['status']==='unpaid','GET info does not recover, close or replace an existing cashier');
    continuationCheck(Db::name('pay_refund')->count()===0&&Db::name('member_account_log')->count()===0,'continuation never invents refunds, balance charges or referral credits in these sender-double tests');

    [$ctx,$order,$no]=$new('advisory-lock');$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::CLOSED)]);$guard=new CooperationPaymentGuard(static fn(int$s,string$c,string$t):object=>$provider);
    $connection=Db::connect();$scope=(string)$connection->getConfig('database').':'.(string)$connection->getConfig('prefix');$key='lead_coop_pay:'.substr(hash('sha256',$scope.':'.$site.':'.$order['id']),0,40);$otherLock=static function()use($pdo,$key):int{return(int)$pdo->query('SELECT GET_LOCK('.$pdo->quote($key).',0) AS acquired')->fetchColumn();};
    $guard->handle($http($ctx,$order),static function()use($otherLock,$pdo,$key):string{$acquired=$otherLock();if($acquired===1)$pdo->query('SELECT RELEASE_LOCK('.$pdo->quote($key).')');continuationCheck($acquired===0,'nested recovery releasing its inner lock does not release the outer HTTP payment lock');return'locked-next';});
    $acquired=$otherLock();if($acquired===1)$pdo->query('SELECT RELEASE_LOCK('.$pdo->quote($key).')');continuationCheck($acquired===1,'outer lock is released when the HTTP guard exits');

    // The real framework balance engine and ledger run only in this random schema.
    // No gateway sender double can stand in for the debit / PaySuccess transaction.
    $app->bind(['think\\route\\Url'=>think\app\Url::class]); // Normal multi-app service URL binding omitted by the minimal test bootstrap.
    $app->config->set(require dirname(__DIR__,3).'/config/pay.php','pay');$app->lang->load(dirname(__DIR__,3).'/app/lang/zh-cn.php','zh-cn');$app->lang->load(dirname(__DIR__,3).'/app/lang/zh-cn/dict.php','zh-cn');
    $realBalance=static function(Context$ctx,array$order,CashierContinuationRecoveryProvider$provider,&$nextCalls)use($http):mixed{
        $guard=new CooperationPaymentGuard(static fn(int$s,string$c,string$t):object=>$provider);$request=$http($ctx,$order,PayDict::BALANCEPAY);
        return$guard->handle($request,static function()use($ctx,$order,&$nextCalls){$nextCalls++;return(new CorePayService())->pay($ctx->site,PaymentService::TRADE_TYPE,(int)$order['id'],PayDict::BALANCEPAY,'weapp','');});
    };
    [$ctx,$order,$no,$merchant]=$new('actual-balance');Db::name('member')->where('site_id',$site)->where('member_id',$ctx->memberId)->update(['balance'=>'1000.00']);$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)]);$next=0;
    $paid=$realBalance($ctx,$order,$provider,$next);$balance=(string)Db::name('member')->where('member_id',$ctx->memberId)->value('balance');$debits=Db::name('member_account_log')->where('site_id',$site)->where('member_id',$ctx->memberId)->where('account_type','balance')->where('from_type','order')->where('account_data','<',0)->select()->toArray();
    continuationCheck($paid===true&&$next===1&&$balance==='701.00'&&count($debits)===1&&$debits[0]['account_data']==='-299.00','actual CoreBalanceService debits the synthetic member once for deposit plus service');
    continuationCheck(Store::row('coop_order',$site,(int)$order['id'])['status']==='paid'&&EntityMembershipService::state($site,$merchant)['active'],'real balance receipt and membership grant commit together');
    $retry=new CashierContinuationRecoveryProvider([]);$next=0;continuationDeny(function()use($realBalance,$ctx,$order,$retry,&$next){return$realBalance($ctx,$order,$retry,$next);},'already paid balance order rejects repeated POST');continuationCheck($next===0&&$retry->calls===[]&&(string)Db::name('member')->where('member_id',$ctx->memberId)->value('balance')==='701.00'&&Db::name('member_account_log')->where('member_id',$ctx->memberId)->where('account_type','balance')->count()===1,'repeated paid balance request never debits again');

    [$ctx,$order,$no,$merchant]=$new('balance-hook-failure');Db::name('member')->where('site_id',$site)->where('member_id',$ctx->memberId)->update(['balance'=>'1000.00']);$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)]);$next=0;
    Event::listen('PaySuccess',static function(array$event):void{throw new RuntimeException('Synthetic PaySuccess failure after business grant');});
    continuationDeny(function()use($realBalance,$ctx,$order,$provider,&$next){return$realBalance($ctx,$order,$provider,$next);},'failed balance PaySuccess propagates as failed attempt','Synthetic PaySuccess failure after business grant');Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    $faultBalance=(string)Db::name('member')->where('member_id',$ctx->memberId)->value('balance');$faultDebitCount=Db::name('member_account_log')->where('member_id',$ctx->memberId)->where('account_type','balance')->count();
    continuationCheck($next===1&&$faultBalance==='1000.00'&&$faultDebitCount===0,'failed balance business hook rolls back both actual debit and ledger '.json_encode(['next'=>$next,'balance'=>$faultBalance,'debits'=>$faultDebitCount,'order_status'=>Store::row('coop_order',$site,(int)$order['id'])['status']]));
    continuationCheck(Store::row('coop_order',$site,(int)$order['id'])['status']==='unpaid'&&!EntityMembershipService::state($site,$merchant)['active']&&Db::name('pay')->where('trade_id',$order['id'])->count()===1&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_CANCEL,'balance rollback does not undo the separately verified old WeChat cancellation or grant unpaid rights');
    $retry=new CashierContinuationRecoveryProvider([]);$next=0;$realBalance($ctx,$order,$retry,$next);continuationCheck($next===1&&$retry->calls===[]&&(string)Db::name('member')->where('member_id',$ctx->memberId)->value('balance')==='701.00'&&Store::row('coop_order',$site,(int)$order['id'])['status']==='paid','after atomic balance rollback the same original order can be safely paid once');

    [$ctx,$order,$no]=$new('orphan-balance-debit',(int)PayDict::STATUS_WAIT);Db::name('member')->where('site_id',$site)->where('member_id',$ctx->memberId)->update(['balance'=>'1000.00']);(new CoreMemberAccountService())->addLog($site,$ctx->memberId,MemberAccountTypeDict::BALANCE,-299,'order','Synthetic previous local debit',$no);$provider=new CashierContinuationRecoveryProvider([$status(OnlinePayDict::CLOSED)]);$next=0;
    continuationDeny(function()use($run,$ctx,$order,$provider,&$next){return$run($ctx,$order,PayDict::BALANCEPAY,$provider,$next);},'WAIT receipt with pre-existing real local balance debit cannot be charged again');continuationCheck($provider->calls===[]&&$next===0&&(string)Db::name('member')->where('member_id',$ctx->memberId)->value('balance')==='701.00'&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_WAIT,'unconfirmed local debit is retained for review, not assumed unpaid or queried to external provider');
    Store::query('coop_order',$site)->where('id',$order['id'])->update(['create_time'=>time()-121]);$tick=PaymentOrderLifecycle::tick(20,100,static fn(int$s,string$c,string$t):object=>$provider);continuationCheck($tick['blocked']>=1&&Store::row('coop_order',$site,(int)$order['id'])['status']==='unpaid'&&(int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_WAIT,'timeout also cannot close an unfinished cashier with an existing local debit');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'actual POST middleware, original-channel reconciliation, framework pay/checkOrCreate, real isolated balance debit/rollback, business hooks and two-connection locks; no external gateway or existing data'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
