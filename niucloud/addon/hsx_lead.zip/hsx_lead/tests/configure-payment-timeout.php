<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true)) exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $function) {
    if(function_exists($function)) exit("Disable external network functions\n");
}
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
define('HSX_LEAD_PAYMENT_TIMEOUT_LIBRARY_ONLY',true);
require dirname(__DIR__).'/scripts/configure-payment-timeout.php';

use addon\hsx_lead\scripts\PaymentTimeoutScheduleCommand;
use addon\hsx_lead\app\job\CloseUnpaidOrders;
use addon\hsx_lead\app\service\cooperation\Store;
use addon\hsx_lead\app\support\Data;
use app\service\core\schedule\CoreScheduleService;
use think\facade\Db;

$pdo=null;$schema='';$fixture='';$checks=0;$failed=false;
function timeoutConfigCheck(bool $condition,string $label):void
{
    if(!$condition) throw new RuntimeException($label);$GLOBALS['checks']++;
}
function timeoutConfigDeny(callable $operation,string $label):void
{
    $denied=false;try{$operation();}catch(RuntimeException $error){$denied=true;}
    timeoutConfigCheck($denied,$label);
}
function timeoutConfigSnapshot(): string
{
    $result=[];
    foreach(['addon','sys_schedule','sys_schedule_log','sys_config','sys_notice','hsx_lead_coop_order','hsx_lead_collaboration','hsx_lead_audit','pay','pay_refund','member_account_log','hsx_lead_promotion_reward'] as $table) {
        $result[$table]=Db::name($table)->order($table==='addon'?'key':'id')->select()->toArray();
    }
    return json_encode($result,JSON_THROW_ON_ERROR);
}
function timeoutConfigFiles(string $root): array
{
    $files=[];
    if(is_dir($root)) foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root,FilesystemIterator::SKIP_DOTS)) as $file) {
        if($file->isFile()) $files[$file->getPathname()]=hash_file('sha256',$file->getPathname());
    }
    ksort($files);return $files;
}
try {
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $fixture=rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema;
    $backend=$fixture.'/configure-payment-timeout/backend';mkdir($backend.'/runtime',0700,true);
    file_put_contents($backend.'/runtime/.schedule',(string)(time()-5));
    file_put_contents($backend.'/runtime/workerman_queue.pid','777777');
    $command=new PaymentTimeoutScheduleCommand($backend,dirname(__DIR__));
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['pay','pay_refund'] as $table) {
        if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$matches)) throw new RuntimeException('Missing official payment fixture DDL');
        $pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$matches[0]));
    }
    foreach([
        ['addon'=>'hsx_lead','key'=>'hsx_lead_inventory_sync','status'=>1,'time'=>'{"type":"min","min":23}','count'=>2420,'last_time'=>1711111111,'next_time'=>1711112222],
        ['addon'=>'hsx_lead','key'=>'hsx_lead_promotion_settle','status'=>2,'time'=>'{"type":"min","min":5}','count'=>19],
        ['addon'=>'hsx_lead','key'=>'hsx_lead_notice_recover','status'=>2,'time'=>'{"type":"min","min":1}'],
        ['addon'=>'fixture_other','key'=>'fixture_other_task','status'=>1,'time'=>'{"type":"min","min":3}','count'=>91],
    ] as $schedule) Db::name('sys_schedule')->insert($schedule);
    $now=time();$orderIds=[];
    foreach(['safe','blocked','fresh'] as $label) {
        $orderIds[$label]=(int)Store::query('coop_order',$site)->insertGetId(['site_id'=>$site,'order_no'=>'TIMEOUT_CONFIG_'.$label,
            'request_id'=>'timeout-config-'.$label,'business_key'=>'timeout-config-'.$label,'purpose'=>'commission','member_id'=>102,
            'amount'=>'50.00','status'=>'unpaid','rule_json'=>Data::json($label==='blocked'?['requires_manual_review'=>'synthetic_review']:[]),
            'create_time'=>$label==='fresh'?$now:$now-300,'update_time'=>$now-300]);
    }
    $dbBefore=timeoutConfigSnapshot();$filesBefore=timeoutConfigFiles($fixture);$check=$command->check();
    timeoutConfigCheck(timeoutConfigSnapshot()===$dbBefore&&timeoutConfigFiles($fixture)===$filesBefore,'--check changes neither DB nor files, even with overdue synthetic orders');
    timeoutConfigCheck($check['schedule']===null&&$check['job_executed']===false&&$check['runtime_loaded']===null,'missing registration is reported, not silently installed or claimed running');
    timeoutConfigCheck($check['heartbeat']['recent']===true&&$check['pid_files'][0]['running_process_verified']===false,'fresh heartbeat/PID file never claims this task is loaded');
    timeoutConfigCheck($check['backend_root']===$backend&&$check['project_root']===dirname($backend),'report identifies the exact backend/project paths');
    timeoutConfigCheck($check['lifecycle_timeout_seconds']===120&&$check['payment_dependencies_loadable']&&$check['can_enable'],'check verifies actual two-minute implementation and loadable payment safety dependencies');
    Db::name('addon')->where('key','hsx_lead')->update(['status'=>0]);$snapshot=timeoutConfigSnapshot();$disabled=$command->check();
    timeoutConfigCheck($disabled['addon_status']===0&&!$disabled['can_enable']&&timeoutConfigSnapshot()===$snapshot,'read-only check reports a disabled addon without activating it');
    timeoutConfigDeny(static fn()=>$command->enable(),'disabled addon cannot enable financial tasks');
    timeoutConfigCheck(timeoutConfigSnapshot()===$snapshot,'rejected disabled addon leaves all tasks and business data unchanged');
    Db::name('addon')->where('key','hsx_lead')->update(['status'=>1]);
    $incomplete=$fixture.'/incomplete-plugin';mkdir($incomplete.'/app/dict/schedule',0700,true);
    copy(dirname(__DIR__).'/app/dict/schedule/schedule.php',$incomplete.'/app/dict/schedule/schedule.php');
    foreach(['app/job/CloseUnpaidOrders.php','app/service/cooperation/PaymentOrderLifecycle.php','app/service/cooperation/PaymentOrderRecovery.php','app/service/cooperation/PaymentCloseScope.php'] as $file) {
        if(!is_dir(dirname($incomplete.'/'.$file))) mkdir(dirname($incomplete.'/'.$file),0700,true);
        copy(dirname(__DIR__).'/'.$file,$incomplete.'/'.$file);
    }
    $broken=new PaymentTimeoutScheduleCommand($backend,$incomplete);$snapshot=timeoutConfigSnapshot();
    timeoutConfigDeny(static fn()=>$broken->check(),'missing gateway reconciler dependency is detected before enabling');
    timeoutConfigDeny(static fn()=>$broken->enable(),'incomplete deployed backend cannot register a financial task');
    timeoutConfigCheck(timeoutConfigSnapshot()===$snapshot,'missing dependency causes no DB mutation');
    foreach([[],['--enable','--check'],['--run'],['--enable','--key=fixture_other_task']] as $arguments) timeoutConfigDeny(static fn()=>PaymentTimeoutScheduleCommand::arguments($arguments),'unsupported/ambiguous target arguments are rejected');
    timeoutConfigCheck(PaymentTimeoutScheduleCommand::arguments(['--check'])==='--check'&&PaymentTimeoutScheduleCommand::arguments(['--enable'])==='--enable','only explicit read/enable modes are accepted');
    $otherSchedules=Db::name('sys_schedule')->order('id')->select()->toArray();
    $ordersBefore=Store::query('coop_order',$site)->order('id')->select()->toArray();
    $enabled=$command->enable();$target=$enabled['schedule'];
    timeoutConfigCheck($enabled['registered_now']&&$enabled['changed']&&$target['status']===1&&$target['time']===['type'=>'min','min'=>1],'enable registers exactly the one missing target using the framework installer');
    timeoutConfigCheck(Db::name('sys_schedule')->where('id','<>',$target['id'])->order('id')->select()->toArray()===$otherSchedules,'ERP, promotion, notice and other-plugin tasks are byte-for-byte unchanged');
    timeoutConfigCheck(Store::query('coop_order',$site)->order('id')->select()->toArray()===$ordersBefore&&Db::name('sys_schedule_log')->count()===0,'configuration never executes tick or changes even already-overdue payment orders');
    timeoutConfigCheck($enabled['job_executed']===false&&$enabled['runtime_loaded']===null&&$enabled['reload_required_after_enable']===true,'enable reports DB configuration only and requires actual-worker verification');
    $beforeRepeat=timeoutConfigSnapshot();$repeat=$command->enable();
    timeoutConfigCheck(!$repeat['registered_now']&&!$repeat['changed']&&timeoutConfigSnapshot()===$beforeRepeat,'repeated enable creates no duplicate and causes no writes');
    Db::name('sys_schedule')->where('id',$target['id'])->update(['status'=>2,'time'=>'{"type":"min","min":9}','count'=>23,
        'last_time'=>1711111111,'next_time'=>1711112222,'create_time'=>1711110000]);
    $updated=$command->enable();$row=$updated['schedule'];
    timeoutConfigCheck($updated['changed']&&!$updated['registered_now']&&$row['status']===1&&$row['time']===['type'=>'min','min'=>1],'existing target alone is enabled with one-minute interval');
    timeoutConfigCheck($row['count']===23&&$row['last_time']===1711111111&&$row['next_time']===1711112222&&$row['create_time']===1711110000,'enabling preserves execution counters and historical timestamps');
    $beforeRepeat=timeoutConfigSnapshot();$command->enable();timeoutConfigCheck(timeoutConfigSnapshot()===$beforeRepeat,'repeat enable preserves populated counters as well as other schedules');
    $duplicate=(int)Db::name('sys_schedule')->insertGetId(['addon'=>'hsx_lead','key'=>PaymentTimeoutScheduleCommand::KEY,'status'=>2,'time'=>'{}']);
    $snapshot=timeoutConfigSnapshot();timeoutConfigDeny(static fn()=>$command->enable(),'duplicate target fails closed');
    timeoutConfigCheck(timeoutConfigSnapshot()===$snapshot,'duplicate target is neither merged, deleted nor enabled');Db::name('sys_schedule')->where('id',$duplicate)->delete();
    $foreign=(int)Db::name('sys_schedule')->insertGetId(['addon'=>'fixture_other','key'=>PaymentTimeoutScheduleCommand::KEY,'status'=>2,'time'=>'{}']);
    $snapshot=timeoutConfigSnapshot();timeoutConfigDeny(static fn()=>$command->enable(),'same key belonging to another plugin fails closed');
    timeoutConfigCheck(timeoutConfigSnapshot()===$snapshot,'foreign-plugin collision never changes either task');Db::name('sys_schedule')->where('id',$foreign)->delete();
    Db::name('sys_schedule')->where('id',$target['id'])->update(['delete_time'=>$now]);$snapshot=timeoutConfigSnapshot();
    timeoutConfigDeny(static fn()=>$command->enable(),'soft-deleted target is not silently restored');timeoutConfigCheck(timeoutConfigSnapshot()===$snapshot,'soft-deleted task remains intact');
    Db::name('sys_schedule')->where('id',$target['id'])->update(['delete_time'=>0]);
    $templates=require dirname(__DIR__).'/app/dict/schedule/schedule.php';$template=null;
    foreach($templates as $entry) if($entry['key']===PaymentTimeoutScheduleCommand::KEY) $template=$entry;
    $schedule=array_replace($template,Db::name('sys_schedule')->where('id',$target['id'])->find());
    // Deliberately execute ONLY the random-schema synthetic schedule in this test.
    (new CoreScheduleService())->execute($schedule,'');
    $log=Db::name('sys_schedule_log')->where('schedule_id',$target['id'])->order('id desc')->find();$stats=json_decode((string)$log['execute_result'],true);
    timeoutConfigCheck($log['status']==='success'&&is_array($stats)&&$stats['examined']===2&&$stats['closed']===1&&$stats['blocked']===1,'actual framework log persists real examined/closed/blocked totals instead of generic true');
    timeoutConfigCheck(Store::row('coop_order',$site,$orderIds['safe'])['status']==='closed'
        &&Store::row('coop_order',$site,$orderIds['blocked'])['status']==='unpaid'
        &&Store::row('coop_order',$site,$orderIds['fresh'])['status']==='unpaid','successful sweep accurately distinguishes closed, blocked and not-yet-due orders');
    timeoutConfigCheck((int)Db::name('sys_schedule')->where('id',$target['id'])->value('count')===24,'framework execution increments its existing count once without reset');
    timeoutConfigCheck(Db::name('sys_schedule')->where('id','<>',$target['id'])->order('id')->select()->toArray()===$otherSchedules,'running the test job still does not alter other schedule records');
    Store::query('coop_order',$site)->where('id',$orderIds['blocked'])->update(['status'=>'closed']);
    $empty=json_decode((new CloseUnpaidOrders())->doJob(),true);
    timeoutConfigCheck($empty['examined']===0&&$empty['closed']===0&&$empty['blocked']===0,'zero eligible orders are logged as zero, not generic completion');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'single-task registration, read-only check, immutable unrelated schedules, idempotent counters and actual framework JSON execution log; synthetic local schema only'],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";
} catch(Throwable $error) {
    $failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine()."\n");
} finally {
    if($pdo instanceof PDO&&$schema!==''&&($GLOBALS['hsx_lead_test_owned_schema']??'')===$schema) {
        if($fixture!==''&&$fixture===rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema&&is_dir($fixture)) {
            foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($fixture,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
                if($entry->isFile()||$entry->isLink()) unlink($entry->getPathname());else rmdir($entry->getPathname());
            }
            rmdir($fixture);
        }
        leadCleanup($pdo,$schema);fwrite(STDERR,"CLEANUP_CONFIRMED random owned schema and runtime fixtures removed\n");
    }
}
exit($failed?1:0);
