import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Execute the canonical Workbench/TaskDetail setup and template. All identities,
// confirmations and transports below are synthetic; no account or network is used.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const { compile } = require('@vue/compiler-dom'), { renderToString } = require('@vue/server-renderer')
const directory = path.join(plugin, 'uni-app/components/cooperation')
let checks = 0, unexpectedTransports = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
const clone = value => JSON.parse(JSON.stringify(value))
const noTransport = () => { unexpectedTransports++; throw Error('No live transport is permitted in membership UI tests') }
const taskLink = (task, params = {}) => '/addon/hsx_lead/pages/task/index?' + new URLSearchParams(Object.fromEntries(Object.entries({ task, ...params }).filter(([, value]) => value != null && value !== ''))).toString()
const apiHelpers = {
    cooperationPageUrls: { deliveries: '/addon/hsx_lead/pages/workbench/index', stores: '/addon/hsx_lead/pages/stores/index', profile: '/addon/hsx_lead/pages/profile/index', wallet: '/addon/hsx_lead/pages/wallet/index' },
    coopError: (cause, fallback) => cause?.message || fallback,
    coopMoney: value => value == null ? '—' : `¥${Number(value).toFixed(2)}`,
    coopDate: value => String(value || ''), businessLabels: { purchase: '二手机' },
    coopStatusLabels: { assigned: '待接单', following: '跟进中', unpaid: '待付佣', paid: '已付佣' }
}
function compileSfc(name) {
    const filename = path.join(directory, name + '.vue'), source = fs.readFileSync(filename, 'utf8')
    const parsed = compiler.parse(source, { filename })
    check(parsed.errors.length === 0, name + ' parses')
    const script = compiler.compileScript(parsed.descriptor, { id: 'membership-access-' + name })
    const template = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename, id: name, compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
    check(template.errors.length === 0, name + ' actual template compiles')
    const js = ts.transpileModule(script.content.replaceAll('import.meta.env.VITE_SITE_ID', "'fixture'"), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    return { source, descriptor: parsed.descriptor, js }
}
const workbench = compileSfc('CooperationWorkbench'), taskDetail = compileSfc('CoopTaskDetail')
function execute(js, deps, uni) {
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Map, Set, JSON, Promise, console, setTimeout, clearTimeout, uni })(key => {
        if (key in deps) return deps[key]
        if (key.endsWith('.vue')) return { default: {} }
        throw Error('Unexpected membership fixture import ' + key)
    }, module, module.exports)
    return module.exports.default
}
const fee = { commission_minimum: '50.00', fee_percent: '10.00', fee_minimum: '9.90', fee_confirmed: true }
const assigned = () => ({ id: 77, status: 'assigned', assignment_version: 3, customer_name: '合成客户', region_text: '河北省 / 石家庄市 / 长安区', business_type: 'purchase', ...fee, can_accept: false, can_reject: true, membership_required: true, membership_message: '请先开通入驻权益，历史履约与账款仍可处理' })
function fixture(options = {}) {
    const navigated = [], mutations = [], confirmations = [], cashier = [], notices = [], reads = []
    const storage = new Map([['wap_site_id', 100005]])
    let persistedLead = { ...assigned(), ...(options.lead || {}) }, sequence = 0
    const ui = {
        loggedIn: Vue.ref(true), ready: Vue.ref(false), loading: Vue.ref(false), busy: Vue.ref(false), error: Vue.ref(''), writeError: Vue.ref(''),
        direction: Vue.ref('incoming'), tab: Vue.ref('deliveries'), profile: Vue.ref({ id: 7, can_publish:false,can_accept:false, ...(options.profile || {}) }),
        config: Vue.ref({ enabled: true, publishing_required: true, publishing_price: '99.00', publishing_cycle: 'year', publishing_months: 12, fee_confirmed: true, ...(options.config || {}) }),
        providers: Vue.ref([]), stats: Vue.ref({}), wallet: Vue.ref({}), rows: Vue.ref([]), total: Vue.ref(0), canLoadMore: Vue.ref(false),
        query: Vue.reactive({ keyword: '', status: '', page: 1, limit: 20 }), listError: Vue.ref(''), listLoading: Vue.ref(false),
        detail: Vue.ref(clone(persistedLead)), detailError: Vue.ref(''), detailLoading: Vue.ref(false),
        resume: () => 'synthetic-membership-session', pause() {}, dispose() {}, resumeInterruptedReads: async () => {},
        bootstrap: async () => { reads.push('bootstrap'); ui.ready.value = true; return true },
        refresh: async () => { ui.ready.value = true; reads.push('refresh'); return true },
        loadLeads: async () => { reads.push('leads'); return true }, loadWallet: async () => { reads.push('wallet'); return true },
        loadDetail: async id => { reads.push(['detail', id]); ui.detail.value = clone(persistedLead); return true },
        saveProfile: async data => { mutations.push({ type: 'profile', data: clone(data) }); return { id: 7 } },
        createLead: async data => { mutations.push({ type: 'create', data: clone(data) }); return { id: 78 } },
        assign: async (...args) => { mutations.push({ type: 'assign', args }); return { id: 77 } },
        action: async type => { mutations.push({ type: 'action', action: type }); if (type === 'deal') persistedLead = { ...persistedLead, status: 'unpaid', can_report: false, can_pay: true }; return { id: 77 } },
        order: async data => { mutations.push({ type: 'order', data: clone(data) }); return { id: 701, merchant_id: 7, lead_id: data.lead_id || 0, purpose: data.purpose, amount: data.amount || '99.00', status: 'unpaid' } }
    }
    const uni = {
        getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, value), removeStorageSync: key => storage.delete(key),
        showToast: value => notices.push(value), showModal: value => { confirmations.push(value); value.success({ confirm: true }) },
        navigateTo: value => navigated.push({ native: 'navigateTo', ...value }), redirectTo: value => navigated.push({ native: 'redirectTo', ...value }), setNavigationBarTitle() {}
    }
    const deps = {
        vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} }, '@/utils/common': { getToken: () => 'synthetic-membership-session' },
        '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: noTransport }) }, '@/hooks/useSubscribeMessage': { useSubscribeMessage: () => ({ request: noTransport }) },
        '../../composables/useCooperation': { useCooperation: () => ui },
        '../../api/cooperation': { ...apiHelpers, cooperationOrder: noTransport, coopRequestId: () => 'synthetic_membership_' + ++sequence },
        '../../api/promotion': { promotionOverview: noTransport },
        '../../utils/entity-membership':loadMobileUtility('entity-membership'), '../../utils/mobile-ui': loadMobileUtility('mobile-ui'), '../../utils/cooperation-business': loadMobileUtility('cooperation-business'), '../../utils/cooperation-payment': loadMobileUtility('cooperation-payment'),
        '../../utils/cooperation-navigation': { cooperationTaskLink: taskLink, cooperationTaskUrl: '/addon/hsx_lead/pages/task/index', openCooperationTask: (task, params = {}) => navigated.push({ task, params: clone(params) }), backCooperationTask: () => navigated.push({ task: 'back' }) }
    }
    const Component = execute(workbench.js, deps, uni)
    const props = Vue.reactive({ initialId: 77, initialTab: 'deliveries', initialInviter: 0, initialPromotion: false, task: 'detail', initialStoreId: 0, initialPurpose: '', initialPaymentId: 0, initialPromotionTab: 'overview', initialBusinessType: '', initialDirection: 'incoming', ...(options.props || {}) })
    const state = Component.setup(props, { expose() {} })
    state.payRef.value = { open: (...args) => cashier.push(args) }
    return { state, ui, props, navigated, mutations, confirmations, cashier, notices, reads, storage }
}

for (const [name, operation] of [['new publication', state => state.openPublish()], ['new selection', state => state.openSelection(77)], ['new acceptance', state => state.act('accept')]]) {
    const test = fixture(); await test.state.initialize(); await operation(test.state)
    check(test.navigated.length === 1 && test.navigated[0].url === '/addon/hsx_lead/pages/membership/index', 'inactive membership routes ' + name + ' to the shared plan page')
    check(test.mutations.length === 0 && test.confirmations.length === 0 && test.cashier.length === 0, 'inactive ' + name + ' neither mutates business data nor opens a payment/acceptance confirmation')
}
for (const task of ['publish', 'select']) {
    const test = fixture({ props: { task } }); await test.state.initialize()
    check(test.navigated.at(-1).url === '/addon/hsx_lead/pages/membership/index' && test.mutations.length === 0, 'a direct native ' + task + ' URL cannot bypass the membership page')
}
const provider = fixture({ profile: { promotion_role: 'provider', provider_enabled: true, provider_status: 'approved' } })
await provider.state.initialize(); provider.state.openPromotion('application')
check(provider.navigated.at(-1).task === 'promotion' && provider.navigated.at(-1).params.tab === 'application' && provider.mutations.length === 0, 'an inactive approved provider can still open the free application/status entry')
provider.state.openPublish(); await provider.state.act('accept')
check(provider.navigated.slice(-2).every(row => row.url === '/addon/hsx_lead/pages/membership/index') && provider.mutations.length === 0, 'provider status never substitutes for membership on new publication or acceptance')
const freeApplication = fixture({ profile: { id: 0 }, props: { task: 'promotion', initialId: 0, initialPromotionTab: 'application' } })
await freeApplication.state.initialize()
check(freeApplication.state.overlay.value === 'promotion' && freeApplication.mutations.length === 0, 'unpaid members without a merchant profile can reach application requirements rather than a forced membership checkout')

const active = fixture({ profile: { can_publish:true,can_accept:true,membership_active:true } })
await active.state.initialize(); active.state.openPublish(); await active.state.openSelection(77); await active.state.act('accept')
check(active.navigated[0].task === 'publish' && active.navigated[1].task === 'select' && active.navigated[1].params.collaboration_id === 77, 'an active shared entitlement opens publication and the original selected lead route')
check(active.mutations.length === 1 && active.mutations[0].action === 'accept' && active.confirmations.length === 1, 'active acceptance still requires one explicit confirmation and calls the existing action once')
const publishOnly=fixture({profile:{can_publish:true,can_accept:false,membership_active:true}})
await publishOnly.state.initialize();publishOnly.state.openPublish();await publishOnly.state.act('accept')
check(publishOnly.navigated[0].task==='publish'&&publishOnly.navigated.at(-1).url==='/addon/hsx_lead/pages/membership/index'&&publishOnly.mutations.length===0,'publication rights do not silently grant acceptance rights from the same paid tier')
const exempt = fixture({ config: { publishing_required: false } })
await exempt.state.initialize(); exempt.state.openPublish(); await exempt.state.openSelection(77); await exempt.state.act('accept')
check(exempt.navigated.some(row => row.task === 'publish') && exempt.navigated.some(row => row.task === 'select') && !exempt.navigated.some(row => row.url === '/addon/hsx_lead/pages/membership/index'), 'administrator-disabled admission gate is an explicit site exemption, not a new free package')
check(exempt.mutations.length === 1 && exempt.mutations[0].action === 'accept', 'administrator exemption preserves the existing acceptance action')

const following = fixture({ lead: { status: 'following', can_report: true, can_reject: false } })
await following.state.initialize(); await following.state.act('deal')
check(following.mutations.length === 1 && following.mutations[0].action === 'deal' && following.confirmations.length === 1, 'membership expiry does not prevent an already accepted delivery from reporting a deal')
check(following.navigated.at(-1).task === 'commission' && following.navigated.at(-1).params.collaboration_id === 77 && !following.navigated.some(row => row.url === '/addon/hsx_lead/pages/membership/index'), 'existing deal reporting continues to its original commission page, never an admission payment')
const commission = fixture({ lead: { status: 'unpaid', can_pay: true, can_reject: false }, props: { task: 'commission' } })
await commission.state.initialize(); await commission.state.payCommission('50.00')
check(commission.mutations.length === 1 && commission.mutations[0].type === 'order' && commission.mutations[0].data.purpose === 'commission' && commission.mutations[0].data.lead_id === 77 && commission.mutations[0].data.amount === '50.00', 'expired admission leaves the original fifty-yuan commission purpose and lead binding intact')
check(commission.cashier.length === 1 && commission.cashier[0][0] === 'hsx_lead_cooperation' && commission.cashier[0][1] === 701 && !commission.navigated.some(row => row.url === '/addon/hsx_lead/pages/membership/index'), 'existing commission opens only the synthetic original cashier contract, not a replacement admission order')
for (const action of ['reject', 'withdraw', 'cancel', 'no_deal']) {
    const test = fixture({ lead: { status: action === 'no_deal' ? 'following' : 'assigned' } }); await test.state.initialize(); await test.state.act(action)
    check(test.mutations.length === 1 && test.mutations[0].action === action && !test.navigated.some(row => row.url === '/addon/hsx_lead/pages/membership/index'), 'expiry cannot lock the existing ' + action + ' lifecycle action behind payment')
}

const pass = { setup: (_, { slots }) => () => Vue.h('section', {}, [slots.default?.(), slots.footer?.()]) }
const detailComponent = execute(taskDetail.js, {
    vue: Vue, '@/utils/common': { img: value => value }, '../../api/cooperation': apiHelpers,'../../utils/entity-membership':loadMobileUtility('entity-membership'),
    '../../utils/mobile-ui': loadMobileUtility('mobile-ui'), '../../utils/cooperation-business': loadMobileUtility('cooperation-business'), './CoopTaskSheet.vue': { default: pass },
    './CoopState.vue': { default: pass }, './CoopModels.vue': { default: pass }, './CoopMerchantAvatar.vue': { default: pass }
}, { makePhoneCall: noTransport, previewImage: noTransport, showToast: noTransport })
const render = new Function('Vue', compile(taskDetail.descriptor.template.content, { mode: 'function', prefixIdentifiers: true, isCustomElement: tag => ['view', 'text'].includes(tag) }).code)(Vue)
async function detailHtml(lead) {
    const Component = { ...detailComponent, setup(props, context) { return { ...detailComponent.setup(props, context) } }, render }
    const app = Vue.createSSRApp({ render: () => Vue.h(Component, { show: true, page: true, lead, config: {}, loading: false, busy: false, error: '' }) })
    app.config.warnHandler = () => {}
    // Compiler-dom resolves imported child tags by their registered names here;
    // the sheet stub must expose both slots rather than silently dropping footer.
    for (const name of ['CoopTaskSheet', 'CoopState', 'CoopModels', 'CoopMerchantAvatar']) app.component(name, pass)
    app.component('u-button', { props: ['text', 'disabled', 'loading', 'type'], setup: props => () => Vue.h('button', { disabled: props.disabled || props.loading, 'data-primary': props.type === 'primary' }, props.text) })
    app.component('u-icon', { setup: () => () => Vue.h('i') })
    app.component('u-collapse', pass)
    app.component('u-collapse-item', { props: ['title'], setup: (props, { slots }) => () => Vue.h('details', {}, [Vue.h('summary', {}, props.title), slots.default?.()]) })
    return renderToString(app)
}
const restricted = await detailHtml(assigned())
check(restricted.includes('开通入驻权益') && restricted.includes('暂不承接') && restricted.includes('请先开通入驻权益'), 'server can_reject=true and can_accept=false shows both membership entry and a free rejection exit')
check(!restricted.includes('>接受交付</button>') && !restricted.includes('>已成交，去付佣</button>') && (restricted.match(/data-primary="true"/g) || []).length === 1, 'membership-required assignment has no acceptance bypass or competing primary action')
const reportHtml = await detailHtml({ ...assigned(), status: 'following', can_report: true, can_reject: false })
check(reportHtml.includes('>已成交，去付佣</button>') && reportHtml.includes('>未成交</button>') && !reportHtml.includes('>开通入驻权益</button>'), 'server can_report remains ahead of the membership notice for an already accepted delivery')
const payHtml = await detailHtml({ ...assigned(), status: 'unpaid', can_pay: true, can_reject: false, commission_amount: '50.00' })
check(payHtml.includes('>支付协作佣金</button>') && !payHtml.includes('>开通入驻权益</button>'), 'server can_pay remains payable after admission expiry rather than being covered by membership UI')
check(unexpectedTransports === 0, 'all checks execute only local SFCs/utilities and synthetic handlers; no live account, API, payment or notification transport')
console.log(`PASS ${checks} membership access UI checks; actual Workbench/TaskDetail Vue setup and template, synthetic data only; no network, database, upload or payment actions.`)
