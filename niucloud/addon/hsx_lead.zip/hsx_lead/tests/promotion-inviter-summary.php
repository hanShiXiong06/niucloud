<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{InviterSummaryReadService,ConfigService,PartnerService,PromotionRules,PromotionService,Store};
use addon\hsx_lead\app\support\Data;
use app\service\core\sys\CoreConfigService;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function isCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function isRow(array$page,int$id):array{foreach($page['data']as$row)if($row['member_id']===$id)return$row;throw new RuntimeException('Missing promoter '.$id);}
function isDeny(callable$run,string$label):void{try{$run();}catch(CommonException$error){isCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();$ctx=new Context($site,1);$summary=new InviterSummaryReadService($ctx);
    $config=ConfigService::defaults();$config['enabled']=true;(new ConfigService($ctx))->save($config);
    Db::name('member')->where('member_id',101)->update(['member_no'=>'0001']);Db::name('member')->where('member_id',102)->update(['member_no'=>'0002','pid'=>101]);
    foreach([201=>0,202=>101,203=>101,204=>0,205=>0,206=>101]as$id=>$pid)Db::name('member')->insert(['member_id'=>$id,'site_id'=>$site,'member_no'=>'INV'.$id,'nickname'=>'Person '.$id,'mobile'=>'19900000'.$id,'pid'=>$pid]);
    Db::name('member')->where('member_id',103)->update(['pid'=>101]); // Another tenant, never this inviter's child.
    Db::name('member')->where('member_id',206)->update(['is_del'=>1]);
    (new CoreConfigService())->setConfig($site,PromotionService::PROVIDER_PREFIX.'201',['status'=>'approved','enabled'=>true]);
    $rules=PromotionRules::defaults();$rules['enabled']=true;$rules['settlement_days']=0;$rules['sources']['membership']['enabled']=true;$rules['sources']['membership']['normal_rate']='10.00';$rules['sources']['membership']['renewal']=true;
    (new PromotionService($ctx))->saveConfig($rules);
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,5,false,['deposit_amount'=>'50.00','cycles'=>[['key'=>'month','name'=>'月付','months'=>1,'enabled'=>true,'price'=>'100.00']]])+['site_id'=>$site]);
    $profile=(new PartnerService(new Context($site,0,102)))->saveProfile(['name'=>'Inviter summary shop','contact_name'=>'Owner','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);
    $paid=leadMembershipGrant($site,102,'ML701');$settled=PromotionService::settleSite($site);isCheck($settled['settled']===1,'real existing settlement transaction credits the synthetic framework commission account');
    $second=leadMembershipGrant($site,102,'ML701');
    Db::name('hsx_lead_merchant_member')->insert(['site_id'=>$site,'merchant_id'=>$profile['id'],'member_id'=>204,'status'=>'active','role'=>'member']);
    $forged=Store::row('coop_order',$site,(int)$paid['id']);unset($forged['id']);$forged=array_replace($forged,['member_id'=>203,'merchant_id'=>0,'order_no'=>'INVITER_FAKE_PAID','request_id'=>'inviter-fake-paid','business_key'=>'inviter-fake-paid','out_trade_no'=>'']);Db::name('hsx_lead_coop_order')->insert($forged);
    $before=hash('sha256',Data::json([Db::name('member')->order('member_id')->select()->toArray(),Db::name('member_account_log')->order('id')->select()->toArray(),Store::query('coop_order',$site)->order('id')->select()->toArray(),Db::name('hsx_lead_promotion_reward')->order('id')->select()->toArray(),Data::query('audit',$site)->order('id')->select()->toArray()]));
    $all=$summary->lists(['limit'=>100]);$first=isRow($all,101);$zero=isRow($all,205);
    isCheck($first['member_no']==='0001'&&$first['role']==='normal','opaque original promotion number and ordinary role are preserved');
    isCheck($first['direct_invite_count']===3,'only current, non-deleted same-site member.pid children count; not staff seats or other tenants');
    isCheck($first['paid_invitee_count']===1&&$first['review_invitee_count']===1,'repeated genuine own payments count one person, paid flag without receipt is review');
    isCheck($first['promotion']['settled']==='10.00'&&$first['promotion']['pending']==='10.00'&&$first['promotion']['total']==='20.00','per-person sums use existing reward snapshots without deposit and experience');
    isCheck($zero['direct_invite_count']===0&&$zero['paid_invitee_count']===0&&$zero['promotion']['total']==='0.00','zero-activity ordinary users remain discoverable with actual zeros');
    $logs=Db::name('member_account_log')->where('site_id',$site)->where('member_id',101)->where('from_type',PromotionService::INCOME_TYPE)->select()->toArray();
    isCheck(count($logs)===1&&(string)$logs[0]['account_data']==='10.00','normal settled fixture has real framework commission log, not a fake settled flag');
    isCheck($summary->lists(['role'=>'provider'])['total']===1&&isRow($summary->lists(['role'=>'provider']),201)['role']==='provider','service-provider filter uses approved qualification, not paid member tier');
    isCheck($summary->lists(['role'=>'normal'])['total']===$all['total']-1,'ordinary and provider view partitions share one user list');
    isCheck(isRow($summary->lists(['keyword'=>'0001']),101)['member_no']==='0001'&&$summary->lists(['keyword'=>'19900000101'])['total']===1&&$summary->lists(['keyword'=>'Inviter summary shop'])['total']===1,'search supports promotion number, phone and owner shop');
    isCheck($summary->lists(['keyword'=>'%'])['total']===0,'SQL wildcard search is escaped rather than broadening scope');
    $one=$summary->lists(['limit'=>1]);isCheck(count($one['data'])===1&&$one['total']===$all['total']&&$one['current_page']===1,'normal bounded pagination does not claim visible rows are total users');
    isCheck($summary->lists(['provider_member_id'=>101])['total']===1&&$summary->lists(['provider_member_id'=>103])['total']===0,'exact provider filter cannot cross tenant');
    $after=hash('sha256',Data::json([Db::name('member')->order('member_id')->select()->toArray(),Db::name('member_account_log')->order('id')->select()->toArray(),Store::query('coop_order',$site)->order('id')->select()->toArray(),Db::name('hsx_lead_promotion_reward')->order('id')->select()->toArray(),Data::query('audit',$site)->order('id')->select()->toArray()]));isCheck($after===$before,'read summaries do not change relationships, accounts, receipts, grants or audits');
    Db::name('member')->where('member_id',102)->update(['pid'=>201]);$old=isRow($summary->lists(['provider_member_id'=>101]),101);$new=isRow($summary->lists(['provider_member_id'=>201]),201);
    isCheck($old['direct_invite_count']===2&&$old['paid_invitee_count']===0&&$new['direct_invite_count']===1&&$new['paid_invitee_count']===1,'current relationship counts follow a changed inviter exactly once');
    isCheck($old['promotion']['total']==='20.00'&&$new['promotion']['total']==='0.00','historical awards remain with original provider and are not reallocated via current PID');
    $rid=Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$second['id'])->value('id');Db::name('hsx_lead_promotion_reward')->where('id',$rid)->update(['status'=>'held','review_required'=>1]);
    $held=isRow($summary->lists(['provider_member_id'=>101]),101);isCheck($held['promotion']['held']==='10.00'&&$held['promotion']['review_required']&&$held['promotion']['total']==='20.00','held rewards are separate from settled and retain review signal');
    $order=Store::row('coop_order',$site,(int)$second['id']);$rule=Data::decode($order['rule_json']);$rule['order_refund']=['status'=>'refunded'];Store::query('coop_order',$site)->where('id',$second['id'])->update(['rule_json'=>Data::json($rule)]);Db::name('hsx_lead_promotion_reward')->where('id',$rid)->update(['review_required'=>0]);
    $cancelled=isRow($summary->lists(['provider_member_id'=>101]),101);isCheck($cancelled['promotion']['held']==='0.00'&&$cancelled['promotion']['cancelled']==='10.00'&&$cancelled['promotion']['total']==='10.00','managed returned/cancelled awards are not included in effective earnings');
    $rows=[];for($i=1000;$i<1505;$i++)$rows[]=['member_id'=>$i,'site_id'=>$site,'member_no'=>'BATCH'.$i,'nickname'=>'Batch '.$i,'pid'=>101];Db::name('member')->insertAll($rows);
    $many=isRow($summary->lists(['provider_member_id'=>101]),101);isCheck($many['direct_invite_count']===507&&$many['review_invitee_count']===1,'keyset payment projection includes more than one 500-child chunk without dropping IDs');
    isDeny(fn()=>$summary->lists(['role'=>'fake']),'invalid role is rejected');isDeny(fn()=>$summary->lists(['provider_member_id'=>'bad']),'invalid exact member identity is rejected');
    isDeny(fn()=>(new InviterSummaryReadService(new Context($site,0,102)))->lists(),'member cannot read platform promoter summaries');
    Db::name('sys_user')->insert(['uid'=>22,'username'=>'scoped-summary','status'=>1]);Db::name('sys_role')->insert(['role_id'=>222,'site_id'=>$site,'status'=>1,'rules'=>Data::json(['hsx_lead_promotion_relations'])]);Db::name('sys_user_role')->insert(['uid'=>22,'site_id'=>$site,'status'=>1,'is_admin'=>0,'role_ids'=>'[222]']);Db::name('sys_menu')->insert(['menu_key'=>'hsx_lead_promotion_relations','app_type'=>'site','status'=>1]);
    isDeny(fn()=>(new InviterSummaryReadService(new Context($site,22)))->lists(),'relation permission without all-data scope cannot expose other staff finances');
    Db::name('sys_menu')->insert(['menu_key'=>'hsx_lead_manage_all_data','app_type'=>'site','status'=>1]);Db::name('sys_role')->where('role_id',222)->update(['rules'=>Data::json(['hsx_lead_manage_all_data','hsx_lead_promotion_relations'])]);
    isCheck((new InviterSummaryReadService(new Context($site,22)))->lists(['provider_member_id'=>101])['total']===1,'existing relation and all-data rights suffice without a new permission alias');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'per-person current direct referrals, own verified fee payers, immutable original-provider award buckets, existing settlement ledger, zero rows, search, page chunks and permissions; isolated localhost schema'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
