<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $fn)if(function_exists($fn))exit("Disable external sender functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';

use addon\hsx_lead\app\service\{Context,MerchantService};
use addon\hsx_lead\app\service\cooperation\{CooperationService,TeamService,PaymentService,InviterSummaryReadService,Store};
use addon\hsx_lead\app\support\Data;
use think\facade\Db;

$pdo=null;$schema='';$checks=0;$failed=false;
function identityCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function searchIds(array $page):array{return array_map('intval',array_column($page['data'],'id'));}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$ctx=new Context($site,1);
    Db::name('member')->where('member_id',101)->update(['nickname'=>'Account Alpha','mobile'=>'18811110001','member_no'=>'MEM0001']);
    Db::name('member')->where('member_id',102)->update(['nickname'=>'Account Beta','mobile'=>'18811110002','member_no'=>'MEM0002']);
    Db::name('member')->where('member_id',103)->update(['nickname'=>'Foreign Owner Needle','mobile'=>'18811110999','member_no'=>'FOREIGN999']);
    foreach([
        ['site_id'=>$site,'member_id'=>104,'nickname'=>'Inactive Needle','member_no'=>'INACTIVE004','mobile'=>'18811110004','status'=>0],
        ['site_id'=>$site,'member_id'=>105,'nickname'=>'Deleted Needle','member_no'=>'DELETED005','mobile'=>'18811110005','is_del'=>1],
        ['site_id'=>$site,'member_id'=>106,'nickname'=>'Literal %_ member','member_no'=>'LITERAL006','mobile'=>'18811110006'],
        ['site_id'=>$site,'member_id'=>107,'nickname'=>'Literal XX member','member_no'=>'OTHER007','mobile'=>'18811110007'],
    ]as$member)Db::name('member')->insert($member);
    $makeShop=static function(int $member,string $name,string $phone,string $contact,int $target=0)use($site):int{
        return(int)Data::query('merchant',$target?:$site)->insertGetId(['site_id'=>$target?:$site,'member_id'=>$member,'name'=>$name,'contact_name'=>$contact,'mobile'=>$phone,
            'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'status'=>1,'create_time'=>time(),'update_time'=>time()]);
    };
    $a=$makeShop(101,'Publisher East','17711110001','Contact One');$b=$makeShop(102,'Delivery West','17711110002','Contact Two');
    $bad=$makeShop(103,'Incorrect foreign binding','17711110003','Other Contact');
    $inactive=$makeShop(104,'Inactive binding','17711110004','Other Contact');$deleted=$makeShop(105,'Deleted binding','17711110005','Other Contact');
    $foreign=$makeShop(103,'Foreign Store Needle','17711110999','Foreign Contact',$site+1);
    $literal=$makeShop(106,'Literal %_ shop','17711110006','Literal Contact');$other=$makeShop(107,'Literal XX shop','17711110007','Other Contact');
    foreach([$a,$b,$bad,$inactive,$deleted,$literal,$other]as$id)Store::partner($site,$id);
    $merchants=new MerchantService($ctx);$team=new TeamService($ctx);
    foreach(['Account Alpha','MEM0001','18811110001','101','Publisher East','Contact One','17711110001'] as$key){
        $page=$merchants->lists(['keyword'=>$key]);identityCheck($page['total']===1&&searchIds($page)===[$a],'merchant keyword resolves valid shop/member: '.$key);
    }
    foreach(['FOREIGN999','Foreign Owner Needle','18811110999','INACTIVE004','DELETED005']as$key)
        identityCheck($merchants->lists(['keyword'=>$key])['total']===0,'invalid or foreign member cannot expand merchant search: '.$key);
    identityCheck($merchants->lists(['keyword'=>'%_'])['total']===1&&searchIds($merchants->lists(['keyword'=>'%_']))===[$literal],'LIKE wildcard symbols are literal');
    foreach(['MEM0001','101','18811110001','Account Alpha']as$key){$options=$merchants->members(['keyword'=>$key]);identityCheck(count($options)===1&&(int)$options[0]['member_id']===101&&$options[0]['member_no']==='MEM0001','remote member select supports stable identity: '.$key);}
    foreach(['FOREIGN999','INACTIVE004','DELETED005']as$key)identityCheck($merchants->members(['keyword'=>$key])===[],'remote member select rejects unavailable identities');
    identityCheck(count($merchants->members(['keyword'=>'%_']))===1,'remote select escapes wildcards');
    foreach(['Account Alpha','MEM0001','18811110001','101']as$key){$page=$team->adminList(['keyword'=>$key]);identityCheck($page['total']===1&&searchIds($page)===[$a],'displayed owner is searchable: '.$key);}
    foreach(['FOREIGN999','INACTIVE004','DELETED005']as$key)identityCheck($team->adminList(['keyword'=>$key])['total']===0,'subject lookup keeps valid own-site member binding');
    $makeLead=static function(string $label,int $owner,int $target=0,int $publisher=0,int $receiver=0)use($site,$a,$b):int{
        return(int)Store::query('collaboration',$target?:$site)->insertGetId(['site_id'=>$target?:$site,'lead_no'=>'LEAD_'.$label,'publisher_id'=>$publisher?:$a,'receiver_id'=>$receiver?:$b,
            'owner_uid'=>$owner,'request_id'=>'identity-'.$label,'customer_name'=>'Customer '.$label,'mobile'=>'16611110001','status'=>'following',
            'models_json'=>Data::json([['id'=>'fixture','title'=>'Fixture Device Alpha']]),'create_time'=>time(),'update_time'=>time()]);
    };
    $own=$makeLead('Own',11);$others=$makeLead('Others',12);$foreignLead=$makeLead('Foreign',11,$site+1,$foreign,$foreign);
    $leads=new CooperationService($ctx);
    foreach(['Customer','16611110001','Fixture Device','Publisher East','Delivery West','Contact Two','17711110002']as$key){$page=$leads->lists(['keyword'=>$key]);identityCheck($page['total']===2&&count($page['data'])===2&&!in_array($foreignLead,searchIds($page),true),'lead keyword searches business fields without crossing tenants: '.$key);}
    identityCheck(searchIds($leads->lists(['keyword'=>'LEAD_Own']))===[$own],'lead number remains searchable');
    identityCheck($leads->lists(['keyword'=>'Foreign Store Needle'])['total']===0,'foreign related shop never matches own-site lead');
    identityCheck($leads->lists(['keyword'=>"%' OR 1=1 --"])['total']===0,'SQL metacharacters are data, not predicates');
    identityCheck($leads->lists(['keyword'=>'Delivery West','status'=>'paid'])['total']===0,'keyword OR cannot override status');
    $paged=$leads->lists(['keyword'=>'Delivery West','limit'=>1,'page'=>2]);identityCheck($paged['total']===2&&count($paged['data'])===1,'search total and SQL pagination retain full scoped matches');
    (new app\service\core\menu\CoreMenuService())->refreshAddonMenu('hsx_lead');
    $role=(int)Db::name('sys_role')->insertGetId(['site_id'=>$site,'role_name'=>'Search scoped staff','rules'=>Data::json(['hsx_lead_cooperation_leads','hsx_lead_cooperation_detail']),'status'=>1]);
    Db::name('sys_user')->insert(['uid'=>11,'username'=>'search-staff','real_name'=>'Scoped Staff','status'=>1]);
    Db::name('sys_user_role')->insert(['uid'=>11,'site_id'=>$site,'role_ids'=>Data::json([$role]),'is_admin'=>0,'status'=>1]);
    $scoped=(new CooperationService(new Context($site,11)))->lists(['keyword'=>'Delivery West']);
    identityCheck($scoped['total']===1&&searchIds($scoped)===[$own],'related shop OR cannot override employee ownership');
    $mobile=new CooperationService(new Context($site,0,101));
    identityCheck($mobile->lists(['keyword'=>'16611110001'])['total']===0,'admin phone matching does not broaden mobile pre-contact search');
    // Historical payer differs from the current store owner. Only the original
    // order member_id may make that financial order match a member search.
    $makeOrder=static function(string $suffix,int $payer,int $merchant,int $target=0)use($site):int{
        return(int)Store::query('coop_order',$target?:$site)->insertGetId(['site_id'=>$target?:$site,'order_no'=>'SEARCH_ORDER_'.$suffix,'purpose'=>'commission','merchant_id'=>$merchant,'member_id'=>$payer,
            'request_id'=>'search-order-'.$suffix,'business_key'=>'search-order-'.$suffix,'amount'=>'50.00','status'=>'closed','create_time'=>time(),'update_time'=>time()]);
    };
    $orderA=$makeOrder('A',102,$a);$orderB=$makeOrder('B',102,$a);$makeOrder('BAD_FOREIGN_MEMBER',103,$a);$makeOrder('FOREIGN_SITE',102,$foreign,$site+1);$inactiveOrder=$makeOrder('INACTIVE',104,$a);
    $financialBefore=Store::query('coop_order',$site)->order('id')->select()->toArray();$payments=new PaymentService($ctx);
    foreach(['Account Beta','MEM0002','18811110002','102','Publisher East','Contact One','SEARCH_ORDER_A']as$key){
        $page=$payments->adminOrders(['keyword'=>$key]);$expected=$key==='SEARCH_ORDER_A'?1:(in_array($key,['Publisher East','Contact One'],true)?4:2);
        identityCheck($page['total']===$expected,'payment keyword matches actual original payer or existing store fields: '.$key);
    }
    identityCheck($payments->adminOrders(['keyword'=>'MEM0001'])['total']===0,'current owner is not confused with a different historical payer');
    identityCheck($payments->adminOrders(['keyword'=>'FOREIGN999'])['total']===0,'foreign member data cannot match own-site order with an invalid stored link');
    identityCheck($payments->adminOrders(['keyword'=>'SEARCH_ORDER_FOREIGN_SITE'])['total']===0,'order number search remains tenant scoped');
    identityCheck($payments->adminOrders(['keyword'=>'18811110004'])['total']===1,'suspended original payer financial history remains searchable');
    identityCheck($payments->adminOrders(['keyword'=>'Account Beta','status'=>'paid'])['total']===0,'payer OR cannot override payment status');
    identityCheck($payments->adminOrders(['keyword'=>'Account Beta','purpose'=>'membership'])['total']===0,'payer OR cannot override payment purpose');
    identityCheck($payments->adminOrders(['keyword'=>'Account Beta','merchant_id'=>$b])['total']===0,'payer OR cannot override selected merchant');
    $orderPage=$payments->adminOrders(['keyword'=>'102','page'=>2,'limit'=>1]);identityCheck($orderPage['total']===2&&count($orderPage['data'])===1,'payment search paginates in SQL with total preserved');
    identityCheck($payments->adminOrders(['keyword'=>"%' OR 1=1 --"])['total']===0,'financial keyword cannot become SQL');
    identityCheck(Store::query('coop_order',$site)->order('id')->select()->toArray()===$financialBefore,'financial queries do not change order amount, state or snapshot');
    $inviters=new InviterSummaryReadService($ctx);
    $inviter=$inviters->lists(['keyword'=>'101']);identityCheck($inviter['total']===1&&(int)$inviter['data'][0]['member_id']===101,'promoter ID matches exactly alongside original fields');
    identityCheck($inviters->lists(['keyword'=>'103'])['total']===0,'promoter ID cannot cross tenants');
    identityCheck($inviters->lists(['keyword'=>'101','role'=>'provider'])['total']===0,'exact promoter ID OR retains provider role filter');
    foreach(['Account Alpha','MEM0001','18811110001','Publisher East']as$key)identityCheck($inviters->lists(['keyword'=>$key])['total']===1,'existing promoter keyword matching remains available: '.$key);
    identityCheck($inviters->lists(['keyword'=>'4294967296'])['total']===0,'out-of-range ID is not truncated into another account');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'Actual merchant/member/subject/lead/payer/promoter queries; random owned local schema; no network, ERP, payment or existing business writes'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable $error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
