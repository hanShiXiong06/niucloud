import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.join(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const { renderToString } = require('@vue/server-renderer')
let checks = 0
const check = (condition, label) => { assert.ok(condition, label); checks++ }
const passthrough = { setup: (_, ctx) => () => Vue.h('section', {}, ctx.slots.default?.()) }

for (const name of ['CoopLeadCard', 'CoopTaskDetail']) {
    const file = path.join(plugin, 'uni-app/components/cooperation', name + '.vue')
    const source = fs.readFileSync(file, 'utf8'), parsed = compiler.parse(source, { filename: file })
    check(!parsed.errors.length, name + ' parses')
    const script = compiler.compileScript(parsed.descriptor, { id: name, inlineTemplate: true })
    const js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Number, String, Array })(key => {
        if (key === 'vue') return Vue
        if (key === '../../api/cooperation') return { businessLabels: {}, coopStatusLabels: {}, coopDate: () => '测试时间', coopMoney: x => '¥' + x }
        if (key === '@/utils/common') return { img: x => x }
        if (key.endsWith('.vue')) return { default: passthrough }
        if (key.startsWith('../../utils/')) return loadMobileUtility(key.split('/').at(-1))
        throw Error('Unexpected dependency: ' + key)
    }, module, module.exports)
    async function html(lead) {
        const app = Vue.createSSRApp({ render: () => Vue.h(module.exports.default, { lead, direction: 'outgoing', show: true, config: {} }) })
        app.config.warnHandler = () => {}
        app.component('u-icon', { setup: () => () => Vue.h('i') })
        app.component('u-button', { props: ['text'], setup: p => () => Vue.h('button', p.text) })
        app.component('u-collapse', passthrough); app.component('u-collapse-item', passthrough)
        return renderToString(app)
    }
    const base = { id: 1, status: 'assigned', is_internal: true, receiver: { name: '本店' } }
    const live = await html({ ...base, internal_assignee: { name: '李四' }, internal_assignee_name: '旧姓名' })
    check(live.includes('接收成员') && live.includes('李四') && !live.includes('旧姓名'), name + ' prioritizes the current approved member name')
    const past = await html({ ...base, internal_assignee: null, internal_assignee_name: '历史接收人' })
    check(past.includes('历史接收人'), name + ' retains the assignment name snapshot after a member leaves')
    const legacy = await html(base)
    check(!legacy.includes('接收成员'), name + ' does not invent a person for historical shared-store queues')
    const external = await html({ ...base, is_internal: false, internal_assignee_name: '错误残留' })
    check(!external.includes('接收成员') && !external.includes('错误残留'), name + ' keeps external store delivery unchanged')
}
console.log(`PASS ${checks} internal assignment display checks; actual Vue SFC and SSR; no live data.`)
