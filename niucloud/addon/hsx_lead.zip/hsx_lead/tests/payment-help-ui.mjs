import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), root = path.resolve(plugin, '../../..')
const require = createRequire(path.join(root, 'uni-app/package.json')), Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc'), sass = require('sass')
const scopedVue = { ...Vue, onBeforeUnmount: Vue.onScopeDispose }
const read = file => fs.readFileSync(path.join(plugin, file), 'utf8')
let checks = 0
function check(ok, label) { assert.ok(ok, label); checks++ }
function execute(source, dependencies, globals = {}) {
    const module = { exports: {} }, script = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + script + '\n})', { console, Number, String, Object, Math, Date, JSON, Promise, Error, ...globals })(name => { if (name in dependencies) return dependencies[name]; if (name.endsWith('.vue')) return { default: {} }; throw Error('Unexpected dependency: ' + name) }, module, module.exports)
    return module.exports
}
const flush = async () => { await Promise.resolve(); await Promise.resolve(); await Vue.nextTick() }
const blank = () => ({ enabled: false, title: '支付帮助', content: '', qr_image: '', remark: '' })
const configured = () => ({ enabled: true, title: '付款遇到问题？', content: '请联系本站客服协助核对。\n备注内容由本站管理员维护。', qr_image: 'attachment/test-only.png', remark: '测试备注：本人手机号' })
const files = ['admin/api/paymentHelp.ts', 'admin/views/cooperation/PaymentHelpSettings.vue', 'admin/views/cooperation/Settings.vue', 'uni-app/api/paymentHelp.ts', 'uni-app/composables/usePaymentHelp.ts', 'uni-app/components/cooperation/CoopPaymentHelp.vue', 'uni-app/components/cooperation/CoopCommissionForm.vue', 'uni-app/pages/orders/index.vue', 'uni-app/pages/membership/index.vue']
for (const file of files) {
    const source = read(file), mirror = path.join(root, file.startsWith('admin/') ? 'admin/src/addon/hsx_lead' : 'uni-app/src/addon/hsx_lead', file.replace(/^(admin|uni-app)\//, ''))
    check(source === fs.readFileSync(mirror, 'utf8'), file + ' canonical and mounted source match')
    if (!file.endsWith('.vue')) continue
    const descriptor = compiler.parse(source, { filename: file }).descriptor
    compiler.compileScript(descriptor, { id: 'payment-help-test' })
    const result = compiler.compileTemplate({ source: descriptor.template.content, filename: file, id: 'payment-help-test', compilerOptions: { expressionPlugins: ['typescript'] } })
    check(!result.errors.length, file + ' real SFC template compiles')
    for (const style of descriptor.styles) if (style.lang === 'scss') { const local = path.join(plugin, path.dirname(file)); sass.compileString(style.content, { loadPaths: [local], logger: { warn() {} } }) }
}

const calls = []
const request = { default: { get: (...args) => calls.push(['GET', ...args]), put: (...args) => calls.push(['PUT', ...args]) } }
const adminApi = execute(read('admin/api/paymentHelp.ts'), { '@/utils/request': request })
adminApi.getPaymentHelpSettings(); adminApi.savePaymentHelpSettings(configured())
check(calls[0][1] === 'hsx_lead/cooperation/config' && calls[0][2].params.section === 'payment_help' && calls[1][2].section === 'payment_help', 'admin adapters isolate the payment_help section from the normal catalog/config payload')
const mobileApi = execute(read('uni-app/api/paymentHelp.ts'), { '@/utils/request': request })
mobileApi.getPaymentHelp()
check(calls.at(-1)[0] === 'GET' && calls.at(-1)[1] === 'hsx_lead/cooperation/payment-help' && calls.at(-1)[3].showErrorMessage === false, 'mobile adapter is one quiet read, with no financial mutation')

let site = '100005', member = 'member-a', reads = 0, work = async () => ({ data: blank() })
const lifecycle = {}, enabled = Vue.ref(true)
const hook = execute(read('uni-app/composables/usePaymentHelp.ts'), {
    vue: scopedVue, '@dcloudio/uni-app': { onShow: callback => lifecycle.show = callback, onHide: callback => lifecycle.hide = callback },
    '@/utils/common': { getToken: () => member, getSiteId: () => site },
    '../api/paymentHelp': { getPaymentHelp: () => { reads++; return work() } }, '../api/cooperation': { coopError: (cause, fallback) => cause.message || fallback }
}, { uni: { getStorageSync: () => site } }).usePaymentHelp
const scope = Vue.effectScope(), helper = scope.run(() => hook(() => enabled.value))
await flush()
check(reads === 1 && !helper.data.value && !helper.opened.value && !helper.error.value, 'disabled help finishes silently and cannot alter the original payment action')
helper.open(); check(!helper.opened.value, 'disabled settings never open a popup')
work = async () => ({ data: configured() }); await helper.refresh()
check(helper.data.value.title === configured().title && !helper.opened.value, 'configured help is ready but does not open automatically')
helper.open(); check(helper.opened.value, 'help opens only on explicit user action')
helper.close(); check(!helper.opened.value, 'closing help leaves its read-only source untouched')
work = async () => { throw Error('合成网络读取失败') }; await helper.refresh()
check(!helper.data.value && helper.error.value.includes('读取失败') && !helper.loading.value && !helper.opened.value, 'read errors clear obsolete QR information and release loading without blocking payment')
work = async () => ({ data: { enabled: true, content: '', qr_image: 'x' } }); await helper.refresh()
check(!helper.data.value && !!helper.error.value, 'incomplete enabled DTO is not guessed into a working customer-service entry')
work = async () => ({ data: { enabled: false } }); await helper.refresh()
check(!helper.data.value && !helper.error.value, 'disabled partial response is accepted without inventing information')
const pending = []; work = () => new Promise(resolve => pending.push(resolve))
const late = helper.refresh(); site = '100006'; lifecycle.show()
pending[1]({ data: { ...configured(), title: '有效新站' } }); await flush(); pending[0]({ data: { ...configured(), title: '迟到旧站' } }); await late
check(helper.data.value.title === '有效新站', 'late response from a previous tenant cannot overwrite current help')
helper.open(); lifecycle.hide(); check(!helper.opened.value && !helper.loading.value, 'leaving the page closes its popup and releases an old read')
member = ''; const beforeGuest = reads; lifecycle.show(); await flush(); helper.open()
check(reads === beforeGuest && !helper.data.value && !helper.opened.value, 'logged-out visitor sees no authenticated help data and makes no help request')
member = 'member-b'; work = async () => ({ data: configured() }); lifecycle.show(); await flush(); enabled.value = false; await flush()
check(!helper.data.value && !helper.opened.value && !helper.error.value, 'hidden commission form removes its prior help and popup')
scope.stop()

const clipboard = [], previews = [], toasts = [], helpState = { data: Vue.ref(configured()), loading: Vue.ref(false), error: Vue.ref(''), opened: Vue.ref(true), current: () => true, close() { helpState.opened.value = false }, refresh() {}, open() {} }
const componentProps = Vue.reactive({ active: true, order: { order_no: 'TEST-ORDER-000001' }, inset: 16, spacing: 12 })
const component = execute(compiler.compileScript(compiler.parse(read('uni-app/components/cooperation/CoopPaymentHelp.vue')).descriptor, { id: 'payment-help-component' }).content, {
    vue: Vue, '@/utils/common': { img: value => '/images/' + value }, '../../composables/usePaymentHelp': { usePaymentHelp: () => helpState }
}, { uni: { setClipboardData: options => { clipboard.push(options.data); options.success() }, previewImage: options => previews.push(options), showToast: options => toasts.push(options.title) } }).default.setup(componentProps, { expose() {}, emit() {} })
check(component.layoutStyle.value.paddingLeft === '16px' && component.layoutStyle.value.marginBottom === '12px', 'reusable inset and spacing are rendered inside the native virtualHost root, not inherited from page-only classes')
componentProps.inset = Infinity; componentProps.spacing = -10; check(component.layoutStyle.value.paddingLeft === '0px' && component.layoutStyle.value.marginTop === '0px', 'invalid or negative layout input cannot break the mobile viewport')
component.copyRemark(); component.copyOrder(); component.preview()
check(clipboard.join('|') === configured().remark + '|TEST-ORDER-000001' && previews[0].urls[0] === '/images/' + configured().qr_image, 'actual Vue handlers use framework clipboard and image preview for real configured text and original order number')
helpState.current = () => false; component.copyRemark(); component.preview()
check(clipboard.length === 2 && previews.length === 1 && !helpState.opened.value, 'identity changed while popup open disables preview/copy and closes old information')
const mobileComponent = read('uni-app/components/cooperation/CoopPaymentHelp.vue')
check(mobileComponent.includes('coop-payment-help__preview">{{ help.data.value.content }}') && mobileComponent.includes('-webkit-line-clamp:2') && !mobileComponent.includes('查看客服信息'), 'entry prominently previews the actual admin-authored content as at most two plain-text lines')
check(mobileComponent.includes('width:100%;height:82vh;max-height:82vh') && mobileComponent.includes('coop-payment-help__body{flex:1 1 0;min-height:0;height:0;'), 'popup has a definite-height flex chain so native/uni internal percent-height scrollers can actually scroll long content')
check(!/requestPayment|request\.post|request\.put|v-html|navigateTo|openURL|window\.open/.test(mobileComponent) && mobileComponent.includes('@tap.stop') && mobileComponent.includes('safe-area-inset-bottom') && mobileComponent.includes('@error="imageFailed=true"'), 'help has no payment, external navigation or HTML execution, and includes event isolation, safe area and QR failure recovery')
for (const page of ['pages/membership/index.vue', 'pages/orders/index.vue', 'components/cooperation/CoopCommissionForm.vue']) check((read('uni-app/' + page).match(/<CoopPaymentHelp\b/g) || []).length === 1, page + ' mounts exactly one helper, never a request per order row')

const adminUser = Vue.reactive({ token: 'synthetic-admin-a', siteInfo: { site_id: 100005 } }), adminProps = Vue.reactive({ modelValue: true, canEdit: true })
let saved = blank(), adminReads = 0, adminWrites = 0, adminWork = async payload => { saved = structuredClone(payload); return { data: structuredClone(saved) } }, adminRead = async () => ({ data: structuredClone(saved) }), confirmWork = async () => true
const alerts = [], adminScope = Vue.effectScope(), admin = adminScope.run(() => execute(compiler.compileScript(compiler.parse(read('admin/views/cooperation/PaymentHelpSettings.vue')).descriptor, { id: 'payment-help-admin' }).content, {
    vue: scopedVue, 'element-plus': { ElMessage: { success: text => alerts.push(text) }, ElMessageBox: { confirm: () => confirmWork() } }, '@/stores/modules/user': { default: () => adminUser }, '@/utils/common': { img: String }, '../../api/paymentHelp': { getPaymentHelpSettings: () => { adminReads++; return adminRead() }, savePaymentHelpSettings: payload => { adminWrites++; return adminWork(payload) } }, '../../composables/cooperation': { coopError: (cause, fallback) => cause.message || fallback }
}).default.setup(adminProps, { expose() {}, emit: (event, value) => { if (event === 'update:modelValue') adminProps.modelValue = value } }))
await flush(); check(admin.ready.value && !admin.draft.enabled, 'admin reads stored disabled defaults rather than assuming the help is already enabled')
saved = { ...configured(), qr_image: '' }; await admin.read(); const beforeMissingImage = adminWrites; await admin.save()
check(admin.ready.value && admin.draft.enabled && !admin.draft.qr_image && adminWrites === beforeMissingImage && admin.fieldError.qr_image, 'deleted QR remains repairable in admin but cannot be saved as an enabled empty image')
saved = blank(); await admin.read()
admin.draft.enabled = true; await admin.save(); check(!adminWrites && admin.fieldError.content && admin.fieldError.qr_image, 'enabling help requires both plain content and a selected QR')
Object.assign(admin.draft, configured()); await admin.save()
check(adminWrites === 1 && saved.enabled && alerts.at(-1) === '支付帮助已保存', 'explicit admin save persists only the complete help DTO')
admin.draft.remark = '保留的修改'; adminWork = async () => { throw Error('保存结果尚未确认') }; await admin.save()
check(admin.readRequired.value && admin.draft.remark === '保留的修改' && !admin.saving.value, 'unknown save retains the whole draft, releases busy and requires a read before resubmitting')
await admin.save(); check(adminWrites === 2, 'unknown save cannot be repeated automatically or by another tap')
await admin.reconcile(); check(!admin.readRequired.value && admin.draft.remark === '保留的修改' && !!admin.verifiedMessage.value, 'reread of different stored settings preserves the local draft and unlocks deliberate correction')
adminWork = async payload => { saved = structuredClone(payload); throw Error('已保存但响应中断') }; await admin.save(); await admin.reconcile()
check(!admin.readRequired.value && admin.draft.remark === saved.remark && admin.verifiedMessage.value.includes('已保存'), 'uncertain save that actually persisted is recognized from the read-back without another write')
adminProps.canEdit = false; await admin.save(); check(adminWrites === 3, 'read-only admin never submits a help save')
adminProps.canEdit = true; admin.draft.remark = '关闭后保留草稿'; adminProps.modelValue = false; await flush(); adminProps.modelValue = true; await flush()
check(admin.draft.remark === '关闭后保留草稿', 'closing and reopening the same settings panel preserves unsaved inputs')
let finishConfirm; confirmWork = () => new Promise(resolve => { finishConfirm = resolve })
const staleReload = admin.reload(); adminUser.siteInfo.site_id = 100006; await flush(); admin.draft.remark = '新站正在编辑的草稿'; const readsBeforeOldConfirm = adminReads; finishConfirm(true); await staleReload
check(admin.draft.remark === '新站正在编辑的草稿' && adminReads === readsBeforeOldConfirm, 'old tenant reload confirmation cannot start a read that overwrites the new tenant draft')
const closedReload = admin.reload(); adminProps.modelValue = false; await flush(); adminProps.modelValue = true; await flush(); admin.draft.remark = '重新打开后的草稿'; const readsBeforeReopen = adminReads; finishConfirm(true); await closedReload
check(admin.draft.remark === '重新打开后的草稿' && adminReads === readsBeforeReopen, 'reload confirmation expires after closing and reopening even under the same identity')
let adminRelease; adminRead = () => new Promise(resolve => { adminRelease = resolve }); const staleRead = admin.read(); const finishOld = adminRelease; adminUser.siteInfo.site_id = 100007; await flush(); const finishCurrent = adminRelease
finishCurrent({ data: { ...configured(), title: '新站设置' } }); await flush(); finishOld({ data: { ...configured(), title: '旧站迟到设置' } }); await staleRead
check(admin.draft.title === '新站设置' && admin.draft.remark !== '关闭后保留草稿', 'admin tenant change removes the previous private draft and rejects old read completion')
adminScope.stop()
console.log(`PASS ${checks} payment-help UI checks: real Vue setup/composables, SFC/SCSS, source mirrors and API contracts; synthetic requests only, no payments or production writes.`)
