import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'

// Actual SFC state, synthetic transports and local read-only menu parsing. Never sends notifications.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),root=path.resolve(plugin,'../../..')
const require=createRequire(path.join(root,'admin/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++},clone=value=>JSON.parse(JSON.stringify(value)),read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
function run(source,deps={}){
    const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    vm.runInNewContext('(function(require,module,exports){'+js+'})',{Date,Number,String,Object,Array,Math,Set,Map,JSON,Promise,Error,console})(key=>{if(key in deps)return deps[key];if(key.endsWith('.vue'))return{default:{}};throw Error('Unexpected dependency '+key)},module,module.exports)
    return module.exports
}
function sfc(file){
    const source=read(file),parsed=compiler.parse(source,{filename:file})
    check(!parsed.errors.length,file+' parses')
    const built=compiler.compileScript(parsed.descriptor,{id:'notice-delivery-admin'})
    check(!compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'notice-delivery-admin',compilerOptions:{bindingMetadata:built.bindings,expressionPlugins:['typescript']}}).errors.length,file+' template compiles')
    for(const style of parsed.descriptor.styles)check(!compiler.compileStyle({source:style.content,filename:file,id:'notice-delivery-admin',scoped:style.scoped}).errors.length,file+' styles compile')
    check(source===fs.readFileSync(path.join(root,'admin/src/addon/hsx_lead',file.slice(6)),'utf8'),file+' mirrors match')
    return{source,script:built.content,parsed}
}
const panel=sfc('admin/views/cooperation/NoticeDeliveryPanel.vue'),detail=sfc('admin/views/cooperation/LeadDetail.vue')
check(detail.source.includes("allows('notice_list')")&&detail.source.includes(":active=\"noticePanels.includes('notices')\"")&&!detail.source.includes('detail.notice'),'detail uses permission-aware paginated lazy reader instead of truncated payload')
const apiCalls=[],request=Object.fromEntries(['get','post','put'].map(method=>[method,async(...args)=>{apiCalls.push([method,...args]);return{data:{}}}]))
const api=run(read('admin/api/cooperation.ts'),{'@/utils/request':{default:request}})
await api.getCooperationNotices(21,{page:2,recipient:'0007',channel:'weapp',status:'rejected'})
await api.retryCooperationNotice(21,901,{confirm:true,reason:'合成客服复查'})
check(apiCalls[0][0]==='get'&&apiCalls[0][1]==='hsx_lead/cooperation/leads/21/notices'&&apiCalls[0][2].params.recipient==='0007'&&apiCalls[0][2].params.page===2,'reader passes original lead and filters')
check(apiCalls[1][0]==='post'&&apiCalls[1][1]==='hsx_lead/cooperation/leads/21/notices/901/retry'&&apiCalls[1][2].confirm===true&&apiCalls[1][3].timeout===45000,'retry targets one original record with explicit consent')
check(read('admin/api/cooperation.ts')===fs.readFileSync(path.join(root,'admin/src/addon/hsx_lead/api/cooperation.ts'),'utf8'),'API mirrors match')
const permissions=['hsx_lead_cooperation_notice_list','hsx_lead_cooperation_notice_retry']
const row=(id=901)=>({id,channel:'weapp',status:'rejected',recipient_member_id:7,recipient_label:'发布门店 · 合成李四',event_action:'assigned',phase:'assigned',notice_key:'hsx_lead_assigned',template_id:'SAFE-TEMPLATE',provider_code:'43101',message:'用户未授权订阅',retry_count:0,can_retry:true,create_time:1})
const page=(items=[row()],total=45,current=1)=>({data:{data:items,total,current_page:current,per_page:20}})
const user=Vue.reactive({siteInfo:{site_id:100005},token:'synthetic-one',rules:[...permissions]}),props=Vue.reactive({leadId:21,active:false})
const reads=[],writes=[],messages=[],cleanup=[]
let readWork=async query=>page([row()],45,query.page),writeWork=async()=>({data:{...row(),status:'accepted',can_retry:false,provider_code:'0'}})
const deps={vue:{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)},'element-plus':{ElMessage:{success:value=>messages.push(['success',value]),warning:value=>messages.push(['warning',value])}},'@/stores/modules/user':{default:()=>user},'../../composables/navigation':{hasLeadPagePermission:(actor,key)=>actor.rules.includes(key)},'../../composables/cooperation':{coopError:(cause,fallback)=>cause?.message||fallback,coopTime:value=>'合成时间'+value},'../../api/cooperation':{getCooperationNotices:async(id,query)=>{reads.push([id,clone(query)]);return readWork(query,id)},retryCooperationNotice:async(id,noticeId,data)=>{writes.push([id,noticeId,clone(data)]);return writeWork(id,noticeId,data)}}}
const s=run(panel.script,deps).default.setup(props,{expose(){}})
const flush=async()=>{for(let i=0;i<6;i++){await Promise.resolve();await Vue.nextTick()}}
check(!reads.length,'closed collapse issues no requests')
props.active=true;await flush()
check(reads.length===1&&s.rows.value.length===1&&s.total.value===45&&!s.loading.value,'opening loads server page and full total')
s.query.page=4;Object.assign(s.filters,{recipient:'0007',channel:'weapp',status:'rejected'});await s.search()
check(reads.at(-1)[1].recipient==='0007'&&reads.at(-1)[1].channel==='weapp'&&reads.at(-1)[1].status==='rejected'&&reads.at(-1)[1].page===1,'search combines filters and resets page')
await s.changePage({page:2,limit:50});check(reads.at(-1)[1].page===2&&reads.at(-1)[1].limit===50&&reads.at(-1)[1].recipient==='0007','pagination retains applied filters')
await s.reset();check(reads.at(-1)[1].recipient===''&&reads.at(-1)[1].status===''&&reads.at(-1)[1].page===1,'reset clears filters')
readWork=async()=>{throw Error('合成读取失败')};await s.load()
check(s.error.value==='合成读取失败'&&!s.rows.value.length&&s.total.value===0&&!s.loading.value,'read failure clears stale rows with explicit error')
readWork=async()=>({data:{data:[],total:'not-a-number'}});await s.load();check(s.error.value.includes('返回不完整'),'malformed page is not empty success')
readWork=async()=>page();await s.load();check(!s.error.value&&s.rows.value.length===1,'refresh recovers via new read')
for(const status of ['accepted','submitted','uncertain','dispatching','processed','pending','failed','new_status'])check(!s.retryAllowed({...row(),status}),'status '+status+' cannot resend even with stale flag')
for(const status of ['rejected','not_submitted','disabled','pending_configuration','pending_recipient'])check(s.retryAllowed({...row(),status}),'explicit unsent '+status+' supports backend permission')
check(!s.retryAllowed({...row(),can_retry:'true'})&&!s.retryAllowed({...row(),retry_count:3}),'strict boolean and retry cap required')
check(s.statusLabel('submitted')==='已交框架，渠道未核实'&&s.statusLabel('accepted')==='渠道已受理','framework dispatch differs from channel acceptance')
check(s.hasCode(0)&&!s.hasCode('')&&!s.hasCode(undefined),'safe channel zero code visible')
user.rules=[permissions[0]];await flush();check(!s.retryAllowed(row()),'read permission cannot send')
user.rules=[...permissions];await flush();s.beginRetry(row())
check(s.retryVisible.value&&s.selected.value.id===901&&!s.confirmed.value,'row action opens confirmation without sending')
await s.retry();check(!writes.length,'missing reason and consent block send')
s.reason.value='合成复查原因';await s.retry();check(!writes.length,'reason alone is not consent')
s.confirmed.value=true
let releaseWrite;writeWork=()=>new Promise(resolve=>{releaseWrite=resolve});const pending=s.retry();await s.retry()
check(writes.length===1&&s.busy.value,'in-flight retry is single-flight')
releaseWrite({data:{...row(),status:'accepted',can_retry:false}});await pending
check(writes[0][0]===21&&writes[0][1]===901&&writes[0][2].confirm===true&&writes[0][2].reason==='合成复查原因','confirmed payload contains only original identity, consent and reason')
check(!s.retryVisible.value&&!s.busy.value&&messages.at(-1)[1].includes('不代表用户已读'),'acceptance reloads without claiming delivery')
s.beginRetry(row());s.reason.value='合成未知结果';s.confirmed.value=true;writeWork=async()=>{throw Error('合成结果未知')};await s.retry()
check(s.readRequired.value&&s.retryError.value.includes('结果未知')&&!s.confirmed.value,'unknown response locks sending')
const beforeUnknown=writes.length;s.confirmed.value=true;await s.retry();check(writes.length===beforeUnknown,'unknown result never auto-retries')
// Closing the dialog must not restore the old row's stale can_retry flag.
s.retryVisible.value=false;s.clearRetry();s.beginRetry(row());check(!s.retryVisible.value&&!s.retryAllowed(row()),'closing unknown-result dialog cannot reopen sending before a successful reread')
await s.refreshAfterUnknown();check(!s.retryVisible.value&&!s.readRequired.value,'explicit reread closes stale dialog')
s.beginRetry({...row(),channel:'sms'});check(s.selected.value.channel==='sms'&&panel.source.includes('短信提交后可能计费'),'SMS cost warning exists before confirmation')
user.rules=[];await flush();check(!s.canRead.value&&!s.retryVisible.value&&!s.rows.value.length,'revoking permission clears sensitive rows and actions')
const noRead=reads.length;await s.load();check(reads.length===noRead,'unauthorized component cannot read')
user.rules=[...permissions];await flush()
let releaseOld,releaseNew;readWork=query=>new Promise(resolve=>query.recipient==='old'?releaseOld=resolve:releaseNew=resolve)
s.query.recipient='old';const old=s.load();s.query.recipient='new';const fresh=s.load()
releaseNew(page([row(902)]));await fresh;releaseOld(page([row(903)]));await old
check(s.rows.value[0].id===902,'late old search cannot replace current rows')
let releaseSite;readWork=()=>new Promise(resolve=>{releaseSite=resolve});const oldSite=s.load();user.siteInfo.site_id=100006;props.active=false;await flush();releaseSite(page([row(904)]));await oldSite
check(!s.rows.value.length,'old-site response cannot repopulate hidden panel')
readWork=async()=>page();props.active=true;await flush();s.beginRetry(row());s.reason.value='合成核对';s.confirmed.value=true
writeWork=()=>new Promise(resolve=>{releaseWrite=resolve});const staleWrite=s.retry(),messageCount=messages.length,readCount=reads.length
user.token='synthetic-two';props.active=false;await flush();releaseWrite({data:{...row(),status:'accepted'}});await staleWrite
check(messages.length===messageCount&&reads.length===readCount,'old-account write response cannot notify success or trigger new reads')
props.active=true;await flush();let releaseUnmount;readWork=()=>new Promise(resolve=>{releaseUnmount=resolve});const unmount=s.load();cleanup.forEach(fn=>fn());releaseUnmount(page([row(905)]));await unmount
check(s.rows.value[0]?.id!==905,'unmounted component discards late response')

const {renderToString}=require('@vue/server-renderer'),pass={setup:(_,ctx)=>()=>Vue.h('section',ctx.slots.default?.())}
const table={props:['data','columns'],setup:(props,ctx)=>()=>Vue.h('table',props.data.map(row=>Vue.h('tr',props.columns.map(column=>Vue.h('td',ctx.slots[column.slot]?.({row})||'')))))}
const inline=compiler.compileScript(panel.parsed.descriptor,{id:'notice-delivery-ssr',inlineTemplate:true})
const ssrDeps={...deps,vue:Vue,'@/addon/hsx_components/components/HsxTable/index.vue':{default:table},'@/addon/hsx_components/components/HsxPagination/index.vue':{default:pass},'../../api/cooperation':{getCooperationNotices:async()=>page([{...row(),status:'accepted',provider_code:'0',message:'渠道已受理',can_retry:false}])}}
const component=run(inline.content,ssrDeps).default,setup=component.setup
component.setup=async(props,ctx)=>{const result=setup(props,ctx);await flush();return result}
const app=Vue.createSSRApp({render:()=>Vue.h(component,{leadId:21,active:true})});app.config.warnHandler=()=>{}
for(const name of ['el-form','el-form-item','el-input','el-select','el-option','el-button','el-alert','el-tag','el-dialog','el-checkbox'])app.component(name,pass)
const html=await renderToString(app)
check(html.includes('发布门店 · 合成李四')&&html.includes('渠道返回码：0')&&html.includes('SAFE-TEMPLATE')&&html.includes('渠道已受理'),'rendered table includes object/template/state/safe provider code')
check(!html.includes('已送达'),'acceptance is never presented as user delivery')

// PermissionGate validates exact api+method, not just the menu name.
const menu=JSON.parse(execFileSync('php',['-n','-r','echo json_encode(require $argv[1], JSON_UNESCAPED_UNICODE);',path.join(plugin,'app/dict/menu/site.php')],{encoding:'utf8'})),found=[]
function walk(items,parent=''){for(const item of items){if(permissions.includes(item.menu_key))found.push({...item,parent});walk(item.children||[],item.menu_key)}}walk(menu)
check(found.length===2&&found.every(item=>item.parent==='hsx_lead_cooperation_leads'&&item.menu_type==='2'&&item.is_show==='0'),'distinct action permissions under original collaboration menu')
check(found.find(item=>item.menu_key===permissions[0])?.api_url==='hsx_lead/cooperation/leads/<id>/notices'&&found.find(item=>item.menu_key===permissions[0])?.methods==='get','reader exact GET permission')
check(found.find(item=>item.menu_key===permissions[1])?.api_url==='hsx_lead/cooperation/leads/<id>/notices/<notice_id>/retry'&&found.find(item=>item.menu_key===permissions[1])?.methods==='post','retry exact POST permission')
const routes=read('app/adminapi/route/cooperation.php'),controller=read('app/adminapi/controller/Cooperation.php')
check(routes.includes("Route::get('leads/:id/notices',$c.'notices')")&&routes.includes("Route::post('leads/:id/notices/:notice_id/retry',$c.'retryNotice')")&&routes.includes('PermissionGate::class')&&routes.includes('completeMatch()'),'routes remain authenticated in exact-match PermissionGate group')
check(controller.includes('public function notices(int $id)')&&controller.includes('public function retryNotice(int $id,int $notice_id)')&&controller.includes('->lists($id,$this->request->param())')&&controller.includes('->retry($id,$notice_id,$this->request->param())'),'controller passes trusted context and original IDs to new service')
check(controller.split('\n').filter(line=>line.includes('public function notices(')||line.includes('public function retryNotice(')).every(line=>line.includes("'Cache-Control'=>'private, no-store'")),'sensitive records and mutation responses disable caching')
console.log('PASS '+checks+' notification admin UI/API/permission checks; synthetic transports, no real sends or database writes.')
