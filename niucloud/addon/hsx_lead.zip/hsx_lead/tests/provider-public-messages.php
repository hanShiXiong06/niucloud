<?php
declare(strict_types=1);

namespace think {
    class Response { public function __construct(public array $payload) {} }
}
namespace think\exception { class Handle {} }
namespace core\exception {
    class CommonException extends \RuntimeException {}
    class AuthException extends \RuntimeException {}
}
namespace {
    function fail($message,array $data=[],$code=400): \think\Response { return new \think\Response(['message'=>$message,'data'=>$data,'code'=>$code]); }
    require dirname(__DIR__).'/app/provider/ProviderException.php';
    require dirname(__DIR__).'/app/support/ProviderPublicMessage.php';
    require dirname(__DIR__).'/app/support/SafeExceptionHandle.php';
    use addon\hsx_lead\app\provider\ProviderException;
    use addon\hsx_lead\app\support\{ProviderPublicMessage,SafeExceptionHandle};
    $checks=0;
    function check(bool $condition,string $label): void { global $checks; if (!$condition) throw new \RuntimeException($label);$checks++; }
    $handler=new SafeExceptionHandle();
    foreach([
        'auth_required'=>'重新验证','invalid_credentials'=>'账号','invalid_captcha'=>'验证码',
        'invalid_challenge'=>'验证码','auth_challenge'=>'人工确认','captcha_invalid_request'=>'验证码',
        'channel_disabled'=>'暂停','http_error'=>'稍后重试','upstream_error'=>'稍后重试',
        'rate_limited'=>'频繁','scope_mismatch'=>'门店','invalid_scope'=>'范围',
        'schema_changed'=>'资料','client_version_changed'=>'版本','response_too_large'=>'上限',
        'unsupported_environment'=>'联系平台','unsupported_transport'=>'更新',
        'unsupported_provider'=>'重新选择','forbidden_endpoint'=>'接口配置',
        'generation_expired'=>'重新完整同步','sync_failed'=>'未完成',
    ] as $reason=>$action) {
        // Synthetic adapter diagnostics intentionally include names and a fake
        // account/token marker; they must remain internal, not be replaced in facts.
        $raw='搜机客/万机管家/爱管机/机小二 diagnostic fake-secret-123';
        $error=new ProviderException($reason,$raw);
        $response=$handler->render(null,$error)->payload;
        check(str_contains($response['message'],$action),$reason.' retains actionable classified guidance');
        check(!preg_match('/搜机客|万机|爱管机|机小二|fake-secret/',$response['message']),$reason.' does not publish brands or raw diagnostic content');
        check($error->getMessage()===$raw&&$error->reason()===$reason,$reason.' keeps original adapter diagnostic and classification unchanged');
    }
    $unknown=$handler->render(null,new ProviderException('future_fake_secret','new-brand future diagnostic'))->payload;
    check($unknown['message']===ProviderPublicMessage::forReason('unknown')&&$unknown['code']===400,'unknown reason fails closed with generic guidance, not the reason or raw body');
    foreach(['idle','pending','running','completed','cancelled','interrupted','paused','failed','unrecognized'] as $status) {
        $message=ProviderPublicMessage::syncStatus($status,'auth_required');
        check($message!==''&&!preg_match('/搜机客|万机|爱管机|机小二/',$message),$status.' summary is brand-independent');
    }
    check(str_contains(ProviderPublicMessage::syncStatus('failed','auth_required'),'重新验证'),'failed summary retains the reason-specific next action');
    $common=$handler->render(null,new \core\exception\CommonException('门店名：万机数码，型号：苹果'))->payload;
    check($common['message']==='门店名：万机数码，型号：苹果','business facts in CommonException are not blindly rewritten with a brand regex');
    $auth=$handler->render(null,new \core\exception\AuthException('请登录',403))->payload;
    check($auth['message']==='请登录'&&$auth['code']===403,'ordinary member authentication semantics remain unchanged');
    echo "PASS {$checks} provider public-message checks; isolated stubs only, no database/network/ERP calls.\n";
}
