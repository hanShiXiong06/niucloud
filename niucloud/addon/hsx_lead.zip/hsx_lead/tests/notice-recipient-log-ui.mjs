// Keep the established regression entry point while exercising the complete paginated delivery UI.
import './notice-delivery-admin-ui.mjs'
