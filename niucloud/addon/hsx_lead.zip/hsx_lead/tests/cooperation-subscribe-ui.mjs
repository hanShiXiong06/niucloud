import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript'), source = fs.readFileSync(path.join(plugin, 'uni-app/composables/useCooperationSubscribe.ts'), 'utf8')
let checks = 0
const check = (value, message) => { assert.ok(value, message); checks++ }
const deferred = () => { let resolve, reject; const promise = new Promise((done, fail) => { resolve = done; reject = fail }); return { promise, resolve, reject } }
function preprocess(platform) { return source.replace(/\s*\/\/ #ifdef MP-WEIXIN\s*\n([\s\S]*?)\s*\/\/ #endif/g, platform === 'mp-weixin' ? '\n$1\n' : '\n') }
function harness(platform = 'mp-weixin', options = {}) {
    let token = 'member-a', site = '100005', work = async () => ({ data: ['template-a', 'template-b'] }), reads = 0
    const native = [], toasts = [], lifecycle = {}
    const deps = { vue: { ...Vue, onMounted: callback => lifecycle.mount = callback, onBeforeUnmount: callback => lifecycle.unmount = callback }, '@/app/api/system': { getWeappTemplateId: keys => { check(keys === 'hsx_lead_task_assigned,hsx_lead_task_changed', 'template discovery uses the real framework notice keys'); reads++; return work() } }, '@/utils/common': { getToken: () => token, getSiteId: () => site } }
    const uni = { getStorageSync: () => site, showToast: options => toasts.push(options.title), requestSubscribeMessage: options => native.push(options) }
    const module = { exports: {} }, output = ts.transpileModule(preprocess(platform), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + output + '\n})', { uni, Number, String, Date, Promise, Set, console })(name => { if (!(name in deps)) throw Error('unexpected import ' + name); return deps[name] }, module, module.exports)
    const state = module.exports.useCooperationSubscribe(options)
    return { state, native, toasts, lifecycle, reads: () => reads, token: value => { token = value }, site: value => { site = value }, work: value => { work = value } }
}
let h = harness(); await h.state.prepare()
check(h.reads() === 1 && h.state.prepared.value && h.native.length === 0, 'preloading template IDs never opens authorization without a user tap')
const accepted = h.state.request(); check(h.native.length === 1 && h.state.requesting.value, 'prepared click invokes the native dialog synchronously')
check((await h.state.request()).status === 'ignored' && h.native.length === 1, 'repeated taps cannot create a second native dialog')
h.native[0].success({ 'template-a': 'accept', 'template-b': 'accept' }); check((await accepted).status === 'accepted' && !h.state.loading.value && h.toasts.at(-1) === '已同意本次通知', 'acceptance reports only this authorization rather than a permanent delivery guarantee')
const partial = h.state.request(); h.native.at(-1).success({ 'template-a': 'accept', 'template-b': 'reject' }); check((await partial).status === 'partial' && h.toasts.at(-1).includes('其余未开启'), 'partial authorization is not presented as all templates accepted')
const rejected = h.state.request(); h.native.at(-1).success({ 'template-a': 'reject', 'template-b': 'ban' }); check((await rejected).status === 'rejected' && h.toasts.at(-1).includes('未同意'), 'native refusal is explicit, not a success toast')
const cancelled = h.state.request(); h.native.at(-1).fail({ errMsg: 'requestSubscribeMessage:fail cancel' }); check((await cancelled).status === 'cancelled' && !h.state.requesting.value, 'cancelling releases the lock and explains no authorization was granted')
const filtered = h.state.request(); h.native.at(-1).success({ 'template-a': 'filter', 'template-b': 'reject' }); check((await filtered).status === 'unconfigured', 'filtered templates are a configuration problem, not a user refusal')
const missing = h.state.request(); h.native.at(-1).success({ errMsg: 'requestSubscribeMessage:ok' }); check((await missing).status === 'failed', 'a success callback with no per-template result cannot claim authorization')
const stale = h.state.request(), toastCount = h.toasts.length; h.token('member-b'); h.native.at(-1).success({ 'template-a': 'accept', 'template-b': 'accept' }); check((await stale).status === 'ignored' && h.toasts.length === toastCount, 'old authorization callbacks cannot affect another signed-in account')
h = harness(); h.work(async () => ({ data: [] })); await h.state.prepare(); check((await h.state.request()).status === 'unconfigured' && h.native.length === 0, 'missing platform templates block the native prompt with a useful explanation')
h = harness(); const templates = deferred(); h.work(() => templates.promise); h.lifecycle.mount(); const first = await h.state.request(); check(first.status === 'preparing' && h.native.length === 0 && h.reads() === 1, 'an unready tap shares preloading and does not authorize after losing the gesture')
templates.resolve({ data: ['template-a', 'template-a', '', 'template-b'] }); await h.state.prepare(); check(h.state.prepared.value && h.native.length === 0, 'completing discovery never automatically triggers authorization')
const next = h.state.request(); check(h.native[0].tmplIds.length === 2, 'duplicate or empty template IDs are not submitted to WeChat'); h.native[0].fail({ errMsg: 'network failure' }); check((await next).status === 'failed', 'native transport failure is shown as failure, not a refusal or success')
h = harness(); const discoveryFailure = deferred(); h.work(() => discoveryFailure.promise); h.lifecycle.mount()
await h.state.request(); await h.state.request(); const failedDiscovery = h.state.prepare(); discoveryFailure.reject(new Error('synthetic template discovery failure')); await failedDiscovery
check(!h.state.loading.value && !h.state.prepared.value && h.native.length === 0 && h.toasts.filter(title => title === '通知模板读取失败，请点击订阅重试').length === 1, 'a clicked pending discovery reports one clear retryable failure, releases loading and never opens authorization')
h.work(async () => ({ data: ['template-a'] })); check((await h.state.request()).status === 'preparing', 'a failed discovery can be retried with the same explicit entry')
await h.state.prepare(); check(h.state.prepared.value && h.reads() === 2 && h.native.length === 0, 'recovery prepares fresh templates without automatically authorizing after the network response')
const retriedAuthorization = h.state.request(); h.native[0].success({ 'template-a': 'accept' }); check((await retriedAuthorization).status === 'accepted', 'only the next deliberate tap after discovery recovery opens authorization')
h = harness(); h.work(async () => ({ data: { unexpected: 'not a template list' } })); await h.state.request(); await h.state.prepare()
check(h.toasts.at(-1) === '通知模板读取失败，请点击订阅重试' && !h.state.prepared.value && !h.native.length, 'a malformed discovery result is a retryable read error rather than a permanent missing-template claim')
h = harness(); h.work(async () => { throw new Error('synthetic background failure') }); check(!await h.state.prepare() && !h.toasts.length && !h.state.loading.value, 'optional background discovery failure is quiet and settles without rejecting the business workflow')
h = harness(); h.work(() => { throw new Error('synthetic synchronous read failure') }); await h.state.request(); await h.state.prepare()
check(!h.state.loading.value && h.toasts.at(-1) === '通知模板读取失败，请点击订阅重试', 'a synchronous framework read failure also settles after the preparation hint and reports retryability')
h.work(async () => ({ data: ['template-a'] })); await h.state.prepare(); check(h.state.prepared.value && h.reads() === 2 && !h.native.length, 'a synchronously failed read cannot leave a cached failed promise that prevents later discovery')
h = harness(); const obsoleteDiscovery = deferred(); h.work(() => obsoleteDiscovery.promise); await h.state.request(); const obsoletePending = h.state.prepare(), beforeFailure = h.toasts.length
h.token('member-b'); h.work(async () => ({ data: ['member-b-template'] })); await h.state.prepare(); obsoleteDiscovery.reject(new Error('synthetic old-account failure')); await obsoletePending
check(h.toasts.length === beforeFailure && h.state.prepared.value && !h.native.length, 'a late discovery failure cannot notify or clear the new account discovery')
const currentAuthorization = h.state.request(); check(h.native[0].tmplIds[0] === 'member-b-template', 'a switched account authorizes only its freshly discovered template'); h.native[0].success({ 'member-b-template': 'accept' }); await currentAuthorization
h = harness('h5'); h.lifecycle.mount(); check((await h.state.request()).status === 'unsupported' && h.reads() === 0 && !h.native.length, 'H5 gives a platform hint and never calls a Mini Program API')
h = harness(); h.token(''); h.lifecycle.mount(); check((await h.state.request()).status === 'login_required' && h.reads() === 0, 'guests do not read private template IDs or start member authorization')
h.token('signed-in-after-return'); await h.state.prepare(); check(h.reads() === 1 && h.state.prepared.value && h.native.length === 0, 'authenticated initialization can preload a formerly anonymous mounted entry without opening authorization')
const afterLogin = h.state.request(); check(h.native.length === 1, 'the first deliberate tap after login preloading can authorize synchronously'); h.native[0].success({ 'template-a': 'accept', 'template-b': 'accept' }); await afterLogin
h = harness(); const abandonedDiscovery = h.state.prepare(); h.token(''); await abandonedDiscovery
check(h.reads() === 0 && !h.state.loading.value && !h.native.length && !h.toasts.length, 'logout before scheduled discovery starts prevents even a private template read')
h = harness(); await h.state.prepare(); h.lifecycle.unmount(); check((await h.state.request()).status === 'ignored' && !h.native.length, 'unmounted entry points cannot open delayed native dialogs')
h = harness('mp-weixin', { enabled: () => false }); h.lifecycle.mount(); check(!await h.state.prepare() && (await h.state.request()).status === 'ignored' && h.reads() === 0 && !h.native.length && !h.toasts.length, 'decoration previews do not read templates, open dialogs or show subscription feedback')
check(fs.readFileSync(path.join(plugin, 'uni-app/components/cooperation/CooperationWorkbench.vue'), 'utf8').includes('subscribeState.request()'), 'lead list notification entry uses the result-aware plugin hook')
check(fs.readFileSync(path.resolve(plugin, '../../../uni-app/src/addon/hsx_lead/composables/useCooperationSubscribe.ts'), 'utf8') === source, 'mounted hook matches installable source')
for (const file of ['components/cooperation/CooperationWorkbench.vue', 'composables/useProfileDiy.ts']) check(fs.readFileSync(path.resolve(plugin, '../../../uni-app/src/addon/hsx_lead', file), 'utf8') === fs.readFileSync(path.join(plugin, 'uni-app', file), 'utf8'), file + ': mounted entry matches the installable source')
console.log(`PASS ${checks} notification authorization UI checks. Real plugin hook, isolated native callbacks; no subscription prompts or notifications were sent.`)
