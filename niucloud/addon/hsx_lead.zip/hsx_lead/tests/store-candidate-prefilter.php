<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $fn)if(function_exists($fn))exit("Disable network functions before isolated testing\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\{Context,CatalogService,CatalogConfigStorage};
use addon\hsx_lead\app\service\cooperation\{ConfigService,CooperationService};
use think\facade\Db;

$checks=0;$pdo=null;$schema='';$failed=false;
function candidateCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $admin=new Context($site,1);$settings=new ConfigService($admin);$config=$settings->get();
    $config['enabled']=true;$config['publishing_required']=false;$config['fee_confirmed']=true;$settings->save($config);
    $model=(new CatalogService($admin))->directory()['items'][0];$model['dimension']='model';
    Db::name('sys_area')->insertAll([
        ['id'=>910200,'pid'=>910000,'name'=>'Second city','level'=>2,'status'=>1],
        ['id'=>910201,'pid'=>910200,'name'=>'Second city district','level'=>3,'status'=>1],
    ]);
    $ids=[];$districtIds=[];$cityIds=[];
    Db::transaction(static function()use($site,$model,&$ids,&$districtIds,&$cityIds):void{
        Db::name('site')->where('site_id',$site)->lock(true)->find();
        for($index=1;$index<=100;$index++){
            $city=$index<=70?910100:910200;$district=$index<=40?910101:($index<=70?910102:910201);
            $name='Store '.str_pad((string)$index,3,'0',STR_PAD_LEFT);
            if($index===97)$name='ÉCHO outlet';
            if($index===98)$name='ECHO outlet';
            if($index===99)$name="Unique KEYxx!\\' Shop";
            if($index===100)$name="Unique KEY%_!\\' Shop";
            $id=(int)Db::name('hsx_lead_merchant')->insertGetId(['site_id'=>$site,'member_id'=>300+$index,'name'=>$name,'contact_name'=>'Agent A','province_id'=>910000,'city_id'=>$city,'district_id'=>$district,'status'=>1]);
            Db::name('hsx_lead_partner')->insert(['site_id'=>$site,'merchant_id'=>$id]);
            CatalogConfigStorage::write($site,'HSX_LEAD_CAPABILITY_'.$id,['business_capabilities'=>[['business_type'=>'purchase','option_ids'=>[$model['id']],'items'=>[$model]]]]);
            $ids[]=$id;if($district===910101)$districtIds[]=$id;if($city===910100)$cityIds[]=$id;
        }
    });
    $database=Db::getConfig();$database['connections'][$database['default']]['trigger_sql']=true;Db::setConfig($database);Db::connect($database['default'],true);
    $sql=[];Db::listen(static function(string $statement)use(&$sql):void{$sql[]=$statement;});
    $base=['province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','demand_ids'=>[$model['id']],'limit'=>100];
    $read=static function(array $params)use($admin,$base,&$sql):array{
        $start=count($sql);$result=(new CooperationService($admin))->stores(array_replace($base,$params));$queries=array_slice($sql,$start);
        $stock=array_values(array_filter($queries,static fn(string $query):bool=>preg_match('/^SELECT\b/i',$query)===1&&str_contains($query,'lt_hsx_lead_inventory')));
        $merchant=array_values(array_filter($queries,static fn(string $query):bool=>preg_match('/^SELECT \* FROM `lt_hsx_lead_merchant` WHERE/i',$query)===1));
        candidateCheck(count($merchant)===1,'one merchant candidate query is issued per request');
        return [$result,count($stock),$merchant[0]];
    };
    [$province,$count,$query]=$read(['scope'=>'province']);
    candidateCheck($province['total']===100&&array_column($province['data'],'id')===$ids&&$count===100,'baseline has 100 ordered candidates and 100 inventory expansions, without truncation');
    [$district,$count,$query]=$read(['scope'=>'district']);
    candidateCheck($district['total']===40&&array_column($district['data'],'id')===$districtIds&&$count===40,'explicit district expands only its 40 merchants, not all 100 province merchants');
    candidateCheck(str_contains($query,'`city_id` = 910100')&&str_contains($query,'`district_id` = 910101'),'explicit district boundaries are present in the actual candidate SQL');
    [$city,$count,$query]=$read(['scope'=>'city']);
    candidateCheck($city['total']===70&&array_column($city['data'],'id')===$cityIds&&$count===70,'explicit city expands its 70 merchants and ignores the optional narrower district');
    candidateCheck(str_contains($query,'`city_id` = 910100')&&!str_contains($query,'`district_id` = 910101'),'explicit city SQL does not accidentally narrow to the supplied district');
    [$unique,$count,$query]=$read(['scope'=>'province','keyword'=>"unique key%_!\\'"]);
    candidateCheck($unique['total']===1&&array_column($unique['data'],'id')===[$ids[99]]&&$count===1,'case-insensitive literal unique keyword expands one merchant, not the province');
    candidateCheck(str_contains($query,'LOWER(CONCAT(')&&str_contains($query,"ESCAPE '!'"),'literal keyword is bound into the actual merchant query before stock expansion');
    foreach(['%','_'] as $literal){[$found,$count]=$read(['scope'=>'province','keyword'=>$literal]);candidateCheck(array_column($found['data'],'id')===[$ids[99]]&&$count===1,'SQL wildcard '.$literal.' is treated as a literal substring');}
    foreach(['!',"\\'"] as $literal){[$found,$count]=$read(['scope'=>'province','keyword'=>$literal]);candidateCheck(array_column($found['data'],'id')===[$ids[98],$ids[99]]&&$count===2,'escape or quote characters remain literal without expanding unrelated merchants');}
    foreach(['écho'=>96,'EcHo'=>97] as $keyword=>$position){[$found,$count]=$read(['scope'=>'province','keyword'=>$keyword]);candidateCheck(array_column($found['data'],'id')===[$ids[$position]]&&$count===1,'case folding preserves literal accents instead of using an accent-insensitive database match');}
    $ormPdo=Db::connect()->getPdo();$originalMode=(string)$ormPdo->query('SELECT @@SESSION.sql_mode')->fetchColumn();
    try{
        $ormPdo->exec("SET SESSION sql_mode='NO_BACKSLASH_ESCAPES'");
        [$noBackslash,$count]=$read(['scope'=>'province','keyword'=>"unique key%_!\\'"]);
        candidateCheck(array_column($noBackslash['data'],'id')===[$ids[99]]&&$count===1,'explicit LIKE escape retains literal backslash and wildcards under NO_BACKSLASH_ESCAPES');
    }finally{$ormPdo->exec('SET SESSION sql_mode='.$ormPdo->quote($originalMode));}
    [$separator,$count]=$read(['scope'=>'province','keyword'=>'sHoP aGeNt']);
    candidateCheck(array_column($separator['data'],'id')===[$ids[98],$ids[99]]&&$count===2,'keyword crossing name/contact separator retains the original PHP matching semantics');
    [$attack,$count]=$read(['scope'=>'province','keyword'=>"' OR 1=1 --"]);
    candidateCheck($attack['total']===0&&$count===0,'SQL metacharacters cannot broaden query or trigger any stock expansion');
    [$countyAuto,$count,$query]=$read(['scope'=>'auto','keyword'=>'STORE 010']);
    candidateCheck($countyAuto['scope']==='district'&&array_column($countyAuto['data'],'id')===[$ids[9]]&&$count===1,'auto still chooses the customer county after keyword matching');
    [$cityAuto,$count,$query]=$read(['scope'=>'auto','keyword'=>'store 050']);
    candidateCheck($cityAuto['scope']==='city'&&array_column($cityAuto['data'],'id')===[$ids[49]]&&$count===1,'auto still expands from empty county to a matching city merchant');
    [$provinceAuto,$count,$query]=$read(['scope'=>'auto','keyword'=>'key%_']);
    candidateCheck($provinceAuto['scope']==='province'&&array_column($provinceAuto['data'],'id')===[$ids[99]]&&$count===1,'auto still reaches a matching merchant in another city of the province');
    candidateCheck(!str_contains($query,'`city_id` = 910100')&&!str_contains($query,'`district_id` = 910101'),'auto candidate SQL retains province fallback and is never pre-narrowed to county/city');
    [$none,$count]=$read(['scope'=>'district','keyword'=>'key%_']);
    candidateCheck($none['total']===0&&$count===0&&$none['scope']==='district','explicit county never silently falls back to the keyword match in another city');
    [$unfilteredAuto,$count]=$read(['scope'=>'auto','limit'=>20,'page'=>2]);
    candidateCheck($unfilteredAuto['scope']==='district'&&$unfilteredAuto['total']===40&&array_column($unfilteredAuto['data'],'id')===array_slice($districtIds,20,20)&&$count===100,'unfiltered auto preserves complete fallback candidates, stable global ordering and second-page totals');
    leadAssertIsolated($schema);
    echo "PASS store candidate prefilter: {$checks} checks; 100 synthetic merchants; actual SQL and stock-query counts; owned random local schema only\n";
}catch(Throwable $error){$failed=true;fwrite(STDERR,'FAIL store candidate prefilter: '.$error->getMessage().' at '.basename($error->getFile()).':'.$error->getLine()."\n".$error->getTraceAsString()."\n");}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
