<?php
declare(strict_types=1);
if (PHP_SAPI!=='cli') exit("CLI only\n");

// Real ThinkPHP helper, private temporary filesystem only. No installed public
// directory writes, database, rendering, QR provider or HTTP request.
$backend=dirname(__DIR__,3);
require_once $backend.'/vendor/autoload.php';
require_once $backend.'/vendor/topthink/framework/src/helper.php';
$plugin=dirname(__DIR__);
$root=sys_get_temp_dir().'/hsx_lead_poster_path_'.bin2hex(random_bytes(8));
$directories=[$root,$root.'/public',$root.'/public/addon',$root.'/public/addon/hsx_lead',$root.'/public/addon/hsx_lead/poster'];
$relative='addon/hsx_lead/poster/share-background.png';
$file=$root.'/public/'.$relative;
$checks=0;
$check=static function(bool $ok,string $label)use(&$checks):void{if(!$ok)throw new RuntimeException($label);$checks++;};
try {
    foreach($directories as$directory)if(!mkdir($directory,0700))throw new RuntimeException('Cannot create owned fixture');
    new \think\App($root);
    $check(copy($plugin.'/resource/poster/share-background.png',$file),'copy only the bundled asset to the private fixture root');
    $check(str_ends_with(public_path($relative),DIRECTORY_SEPARATOR),'real framework helper treats its argument as a directory');
    $check(!is_file(public_path($relative)),'reproduce the old false missing-material error even with a real PNG');
    $path=public_path().$relative;
    $check($path===$file&&!str_ends_with($path,DIRECTORY_SEPARATOR),'join the file name onto the actual public root without a trailing separator');
    $check(is_file($path),'present material passes the corrected file check');
    $check(hash_file('sha256',$path)===hash_file('sha256',$plugin.'/resource/poster/share-background.png'),'asset bytes remain unchanged');
    $size=getimagesize($path);
    $check(is_array($size)&&$size[2]===IMAGETYPE_PNG&&$size[0]>0&&$size[1]>0,'bundled asset is a valid PNG');
    $source=file_get_contents($plugin.'/app/service/cooperation/PosterShareService.php');
    $check(str_contains($source,"is_file(public_path() . '".$relative."')"),'actual production service uses the verified file path expression');
    $check(!str_contains($source,"public_path('".$relative."')"),'directory-helper regression cannot silently return in the service');
    $check(str_contains($source,'$this->data($scene,$channel);'),'the resource fix retains authorization before generation');
    unlink($file);
    clearstatcache(true,$path);
    $check(!is_file($path),'a genuinely missing material remains rejected rather than silently bypassed');
    echo 'PASS '.$checks." poster background path checks; real framework helper, private local filesystem only, no database, rendering or network\n";
} finally {
    if(is_file($file))unlink($file);
    foreach(array_reverse($directories)as$directory)if(is_dir($directory))rmdir($directory);
}
