import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual component render/CSS with synthetic labels; no page/API/store writes.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..')
const require=createRequire(path.join(workspace,'uni-app/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),sass=require('sass'),{renderToString}=require('@vue/server-renderer')
const file=path.join(plugin,'uni-app/components/cooperation/CoopServiceLineIcon.vue'),descriptor=compiler.parse(fs.readFileSync(file,'utf8'),{filename:file}).descriptor
const script=compiler.compileScript(descriptor,{id:'service-line-preview',inlineTemplate:true}),module={exports:{}}
vm.runInNewContext('(function(require,module,exports){'+ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText+'})',{Object,Math,Number,String})(key=>key==='vue'?Vue:(()=>{throw Error('Unexpected import')})(),module,module.exports)
const Icon=module.exports.default,project=loadMobileUtility('cooperation-business-presentation')
const items=project.presentBusinessEntries([{key:'purchase',name:'二手机'},{key:'new_phone',name:'新机'},{key:'rent',name:'租机'},{key:'exchange',name:'回收置换'},{key:'broadband',name:'运营商'},{key:'repair',name:'手机维修'},{key:'home_recycle',name:'上门回收'}])
async function render(size){return renderToString(Vue.createSSRApp({render:()=>Vue.h('div',{class:'icon-grid'},items.map(item=>Vue.h('div',{class:'icon-entry'},[Vue.h('div',{class:'icon-surface',style:{width:size+'px',height:size+'px',background:item.iconBgColor}},[Vue.h(Icon,{shape:item.shape,color:item.iconColor,size:Math.round(size*.75)})]),Vue.h('span',{},item.name)])))}))}
const css=sass.compileString(descriptor.styles[0].content).css
const out=path.join(workspace,'output/hsx-lead-line-icons'),marker=path.join(out,'.owned-preview')
fs.mkdirSync(out,{recursive:true});fs.writeFileSync(marker,'Synthetic local icon preview only\n')
const body=await render(44)
fs.writeFileSync(path.join(out,'index.html'),'<!doctype html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>服务业务 · 彩色线性图标</title><style>body{margin:0;background:#fff;font-family:system-ui,-apple-system,"PingFang SC",sans-serif;color:#273d58}view{display:block}main{max-width:440px;margin:0 auto;padding:20px 12px;box-sizing:border-box}.icon-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:24px 4px}.icon-entry{min-width:0;display:flex;flex-direction:column;align-items:center;gap:10px;padding:8px 0}.icon-surface{display:flex;align-items:center;justify-content:center;border-radius:12px}.icon-entry>span{font-size:14px;line-height:22px;white-space:nowrap}'+css+'</style></head><body><main>'+body+'</main></body></html>')
console.log(JSON.stringify({file:path.join(out,'index.html'),actualComponent:'CoopServiceLineIcon.vue',syntheticData:true,apiCalls:0,businessWrites:0}))
