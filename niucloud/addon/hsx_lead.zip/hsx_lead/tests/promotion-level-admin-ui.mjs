import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Execute the real admin setup. Fake transports do not write configuration or money.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../admin/package.json'))
const Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc')
let checks = 0
const check = (value, label) => { assert.ok(value, label); checks++ }
const filename = 'admin/views/promotion/index.vue'
const source = fs.readFileSync(path.join(plugin, filename), 'utf8')
const parsed = compiler.parse(source, { filename })
check(parsed.errors.length === 0, 'canonical SFC parses')
compiler.compileScript(parsed.descriptor, { id: 'promotion-level-admin' })
check(compiler.compileTemplate({ source: parsed.descriptor.template.content, filename, id: 'promotion-level-admin' }).errors.length === 0, 'dynamic level template compiles')
for (const style of parsed.descriptor.styles) check(compiler.compileStyle({ source: style.content, filename, id: 'promotion-level-admin', scoped: style.scoped }).errors.length === 0, 'styles compile')
const names = 'applyConfigRead,normalizeConfig,config,memberLevels,sourceRows,levelRateRows,setLevelOverride,setLevelRate,saveRules,configError,trialRows,trialError,trialSource,trialAmounts'
const script = parsed.descriptor.scriptSetup.content + `\nexport {${names}}`
const js = ts.transpileModule(script, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } })
check(!js.diagnostics?.length, 'setup TypeScript transpiles')
const writes = [], notices = []
const deps = {
    vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} },
    'element-plus': { ElMessage: { success: value => notices.push(value) }, ElMessageBox: { confirm: async () => {} } },
    '@element-plus/icons-vue': { Refresh: {} },
    '@/stores/modules/user': { default: () => ({ rules: ['hsx_lead_promotion_config', 'hsx_lead_promotion_config_save'] }) },
    '../../composables/navigation': { hasLeadPagePermission: (user, key) => user.rules.includes(key) },
    '../../composables/cooperation': { coopError: (error, fallback) => error?.message || fallback, coopMoney: value => Number(value).toFixed(2), coopTime: value => value },
    '../../api/promotion': { savePromotionConfig: async data => { writes.push(JSON.parse(JSON.stringify(data))); return { data: { ...data, member_levels: levels } } } }
}
const module = { exports: {} }
vm.runInNewContext(`(function(require,module,exports){${js.outputText}})`, { Date, Math, Number, String, Set, Map, JSON, Object, Promise, console })(key => {
    if (key in deps) return deps[key]
    if (key.endsWith('.vue')) return { default: {} }
    throw Error('Unexpected dependency ' + key)
}, module, module.exports)
const state = module.exports
const levels = Array.from({ length: 8 }, (_, i) => ({ code: `ML${701+i}`, level_id: 701+i, name: `合成等级${i+1}`, display_rank: i+1 }))
const rules = () => ({ enabled: true, settlement_days: 3, eligibility_months: 0, member_levels: levels, sources: {
    membership: { enabled: true, normal_rate: '10.00', provider_rate: '30.00', renewal: true, level_rates: { ML701: '20.00', ML702: '0.00', ML999: '12.00' } },
    maintenance: { enabled: true, normal_rate: '5.00', provider_rate: '50.00', renewal: true, level_rates: [] }
} })
state.applyConfigRead(rules())
check(state.memberLevels.value.length === 8 && state.levelRateRows.value.length === 8, 'all dynamic framework levels are shown, not fixed V1-V4')
check(state.levelRateRows.value[0].membership.overridden && state.levelRateRows.value[0].membership.rate === 20, 'existing level override reads back')
check(state.levelRateRows.value[1].membership.overridden && state.levelRateRows.value[1].membership.rate === 0, 'explicit zero is distinct from following the normal rate')
check(!state.levelRateRows.value[2].membership.overridden && state.levelRateRows.value[2].membership.rate === 10, 'missing override follows unpaid ordinary member rate')
check(state.trialRows.value[0].reward === 9.9 && state.trialRows.value[1].reward === 29.7 && state.trialRows.value[2].reward === 19.8 && state.trialRows.value[3].reward === 0, '99 service fee preview compares alternatives without stacking provider and member rewards')
for (const row of state.trialRows.value) check(Math.round((row.reward + row.retained) * 100) === 9900, 'preview conserves the exact service fee per identity ' + row.role)
state.config.sources.membership.normal_rate = 15
check(state.levelRateRows.value[0].membership.rate === 20 && state.levelRateRows.value[2].membership.rate === 15, 'only inherited rows follow changed ordinary rates')
state.setLevelOverride('ML703', 'membership', true)
check(state.config.sources.membership.level_rates.ML703 === 15, 'turning on override starts from the current real normal rate')
state.setLevelRate('ML703', 'membership', 25)
check(state.levelRateRows.value[2].membership.rate === 25 && state.trialRows.value[4].reward === 24.75, 'editing a level updates row data and preview together: ' + JSON.stringify([state.levelRateRows.value[2],state.trialRows.value[4]]))
state.setLevelOverride('ML703', 'membership', false)
check(!Object.prototype.hasOwnProperty.call(state.config.sources.membership.level_rates, 'ML703') && state.levelRateRows.value[2].membership.rate === 15, 'following normal deletes only this explicit override')
state.setLevelOverride('ML1', 'membership', true)
check(!Object.prototype.hasOwnProperty.call(state.config.sources.membership.level_rates, 'ML1'), 'client cannot create overrides for an unlisted level')
state.setLevelRate('ML701', 'membership', 101)
check(state.trialError.value.includes('0—100'), 'invalid level percentage is explained, not coerced to zero')
await state.saveRules()
check(writes.length === 0 && state.configError.value.includes('0—100'), 'invalid level rate prevents configuration PUT')
state.setLevelRate('ML701', 'membership', 20)
await state.saveRules()
check(writes.length === 1 && notices.length === 1, 'valid configuration performs one save and reads the server response')
check(writes[0].sources.membership.level_rates.ML701 === '20.00' && writes[0].sources.membership.level_rates.ML702 === '0.00', 'new payload preserves override precision and deliberate zero')
check(writes[0].sources.membership.level_rates.ML999 === '12.00', 'unlisted inactive level override is not silently deleted')
check(!('member_levels' in writes[0]) && Object.keys(writes[0].sources).join(',') === 'membership,maintenance', 'read-only levels and old income sources cannot hitchhike on PUT')
state.config.enabled = false
check(state.trialRows.value.every(row => row.reward === 0 && row.retained === 99), 'closed promotion does not preview new rewards')
for (const invalid of [null, { ML701: '100.01' }, { bad: '1.00' }, ['10.00']]) {
    const data = rules(); data.sources.membership.level_rates = invalid
    assert.throws(() => state.normalizeConfig(data), /等级分佣/); checks++
}
check(source.includes('普通用户无需购买会员即可邀请得佣') && source.includes('不含押金、经验费') && source.includes('会员等级分佣比例'), 'fee scope, unpaid invitation and grade configuration are visible')
check(source === fs.readFileSync(path.resolve(plugin, '../../../admin/src/addon/hsx_lead/views/promotion/index.vue'), 'utf8'), 'canonical and mounted admin match')
console.log(`Promotion level admin UI: ${checks} checks passed (synthetic transports, no configuration writes).`)
