<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{PromotionService,PromotionRules,PartnerService,ConfigService,PaymentService,PaymentOrderLifecycle,EntityMembershipService,Store};
use addon\hsx_lead\app\support\Data;
use addon\hsx_lead\app\listener\pay\{CooperationPaySuccess,CooperationPayCloseGuard};
use app\dict\pay\{OnlinePayDict,PayDict};
use core\exception\CommonException;
use think\facade\{Db,Event};
final class SyntheticPaymentProvider
{
    public array $calls=[];
    public function __construct(private array $answers,private $closed=true){}
    public function getOrder(string$no){$this->calls[]='query:'.$no;$next=array_shift($this->answers);if($next instanceof Throwable)throw$next;return$next;}
    public function close(string$no){$this->calls[]='close:'.$no;if($this->closed instanceof Throwable)throw$this->closed;return$this->closed;}
}
$checks=0;$pdo=null;$schema='';$failed=false;
function grCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function grDeny(callable$fn,string$label):void{try{$fn();}catch(CommonException$e){grCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();
    foreach(['pay','pay_refund']as$table){$official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m))throw new RuntimeException('Missing receipt DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    $ctx=new Context($site,0,102);$adminCtx=new Context($site,1);
    $settings=ConfigService::defaults();$settings['enabled']=true;$settings['fee_confirmed']=true;(new ConfigService($adminCtx))->save($settings);
    $profile=['name'=>'Synthetic receiver','contact_name'=>'Fixture','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture address','provider'=>''];
    $receiver=(new PartnerService($ctx))->saveProfile($profile);$publisher=(new PartnerService(new Context($site,0,101)))->saveProfile(array_replace($profile,['name'=>'Synthetic publisher','mobile'=>'19900000101']));
    $promotions=PromotionRules::defaults();$promotions['enabled']=true;$promotions['settlement_days']=0;$promotions['sources']['maintenance']=['enabled'=>true,'normal_rate'=>'20.00','provider_rate'=>'30.00','renewal'=>true];$promotions['sources']['membership']=['enabled'=>true,'normal_rate'=>'10.00','provider_rate'=>'20.00','renewal'=>true];(new PromotionService($adminCtx))->saveConfig($promotions);(new PromotionService($ctx))->bind(['mid'=>101,'confirm'=>true]);
    Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    Event::remove('PayClose');Event::listen('PayClose',CooperationPayCloseGuard::class);
    $new=static function(string$label)use($site,$ctx,$publisher,$receiver):array{
        $rule=['purpose'=>'commission','fee_percent'=>'10.00','fee_minimum'=>'9.90','commission_minimum'=>'50.00','fee_confirmed'=>true];
        $lead=(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'SYNTHETIC_'.$label,'request_id'=>'SYNTHETIC_'.$label,'publisher_id'=>$publisher['id'],'receiver_id'=>$receiver['id'],'status'=>'unpaid','rule_json'=>Data::json($rule)]);
        $order=(new PaymentService($ctx))->createOrder(['purpose'=>'commission','lead_id'=>$lead,'amount'=>'50.00','request_id'=>'gateway-'.$label.'-'.bin2hex(random_bytes(4))]);$no='GATEWAY_'.bin2hex(random_bytes(12));
        Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>PayDict::STATUS_ING,'type'=>PayDict::WECHATPAY,'channel'=>'weapp']);
        return[$order,$no];
    };
    $cancel=static function(array$order,SyntheticPaymentProvider$provider,bool$admin=false)use($ctx,$adminCtx):array{
        $factory=static fn(int$s,string$c,string$t):object=>$provider;
        return(new PaymentOrderLifecycle($admin?$adminCtx:$ctx,$factory))->close((int)$order['id'],['confirm'=>true,'reason'=>'Synthetic reconciliation'],$admin);
    };
    $status=static fn(string$state):array=>['status'=>$state];
    [$order,$no]=$new('notpay-closed');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)]);
    $shown=(new PaymentService($ctx))->order((int)$order['id']);grCheck($shown['can_close']&&$shown['close_requires_check']&&$shown['close_action_label']==='核对后取消','online prepay exposes a safe reconciliation cancellation action');
    $closed=$cancel($order,$provider);grCheck($closed['status']==='closed'&&$closed['close_result']==='closed','authoritative NOTPAY then CLOSED closes business');
    grCheck($provider->calls===['query:'.$no,'close:'.$no,'query:'.$no],'queries before and after close, never assumes close response is final');
    grCheck((int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_CANCEL,'confirmed gateway closure persisted through framework payClose');
    [$racing,$raceNo]=$new('notpay-success');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::SUCCESS)]);
    $paid=$cancel($racing,$provider);grCheck($paid['status']==='paid'&&$paid['close_result']==='paid','payment wins a NOTPAY/close race and is not cancelled');
    grCheck((int)Db::name('pay')->where('out_trade_no',$raceNo)->value('status')===(int)PayDict::STATUS_FINISH&&Store::row('coop_order',$site,(int)$racing['id'])['status']==='paid','actual payment and business confirmation survive the outer cancellation transaction');
    grCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$racing['id'])->count()===1,'successful race credits publisher once through real framework hook');
    grCheck(Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$racing['id'])->count()===1,'successful race creates one referral reward based on maintenance');
    PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$racing['id'],'out_trade_no'=>$raceNo]);
    grCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$racing['id'])->count()===1&&Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$racing['id'])->count()===1,'replayed receipt does not repeat income or referral reward');
    foreach([OnlinePayDict::USERPAYING,OnlinePayDict::REFUND,OnlinePayDict::REVOKED,OnlinePayDict::PAYERROR,'UNKNOWN']as$state){
        [$unknown,$unknownNo]=$new(strtolower($state));$provider=new SyntheticPaymentProvider([$status($state)]);$kept=$cancel($unknown,$provider);
        grCheck($kept['status']==='unpaid'&&$kept['close_result']==='uncertain'&&$provider->calls===['query:'.$unknownNo],'non-definitive '.$state.' never calls close or locally cancels');
        grCheck((int)Db::name('pay')->where('out_trade_no',$unknownNo)->value('status')===(int)PayDict::STATUS_ING,'unknown gateway result preserves original processing evidence');
    }
    foreach([[],null,'unexpected',new RuntimeException('Synthetic provider timeout')]as$index=>$answer){
        [$unknown,$unknownNo]=$new('empty-'.$index);$provider=new SyntheticPaymentProvider([$answer]);$kept=$cancel($unknown,$provider);
        grCheck($kept['status']==='unpaid'&&$kept['close_result']==='uncertain'&&count($provider->calls)===1,'empty malformed or failed query cannot authorize cancellation');
    }
    [$uncertain,$uncertainNo]=$new('close-uncertain');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),[]],true);$kept=$cancel($uncertain,$provider,true);
    grCheck($kept['status']==='unpaid'&&$kept['close_result']==='uncertain'&&(int)Db::name('pay')->where('out_trade_no',$uncertainNo)->value('status')===(int)PayDict::STATUS_ING,'even administrator and close=true cannot force a local close without CLOSED proof');
    [$notClosed,$notClosedNo]=$new('still-notpay');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::NOTPAY)],false);$kept=$cancel($notClosed,$provider);
    grCheck($kept['status']==='unpaid'&&(int)Db::name('pay')->where('out_trade_no',$notClosedNo)->value('status')===(int)PayDict::STATUS_ING,'failed close followed by NOTPAY is not a closed order');
    [$already,$alreadyNo]=$new('already-closed');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::CLOSED)]);$closed=$cancel($already,$provider);
    grCheck($closed['status']==='closed'&&$provider->calls===['query:'.$alreadyNo],'already CLOSED is locally synchronized without another close request');
    [$done,$doneNo]=$new('already-success');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::SUCCESS)]);$paid=$cancel($done,$provider);
    grCheck($paid['status']==='paid'&&$provider->calls===['query:'.$doneNo]&&(int)Db::name('pay')->where('out_trade_no',$doneNo)->value('status')===(int)PayDict::STATUS_FINISH,'already SUCCESS confirms and commits receipt without requesting cancellation');
    [$closedDespiteTimeout,$closedNo]=$new('close-timeout');$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)],new RuntimeException('Synthetic close timeout'));
    grCheck($cancel($closedDespiteTimeout,$provider)['status']==='closed','close exception is resolved by a definitive second CLOSED query');
    [$failure,$failureNo]=$new('paid-hook-failure');Event::listen('PaySuccess',static function(array$event):void{throw new RuntimeException('Synthetic downstream hook failed');});$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::SUCCESS)]);$review=$cancel($failure,$provider);
    grCheck($review['status']==='unpaid'&&$review['requires_manual_review']&&$review['close_result']==='paid_pending','known paid result with failed downstream hook is retained for review, never fake cancelled');
    grDeny(fn()=>(new PaymentService($ctx))->assertPayable((int)$failure['id']),'known paid pending review cannot restart payment');Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    Db::name('hsx_lead_coop_order')->where('id',$failure['id'])->update(['create_time'=>time()-121]);
    $contradictory=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY)]);
    $pendingTick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$contradictory);
    grCheck($pendingTick['blocked']===1&&$pendingTick['closed']===0&&$contradictory->calls===['query:'.$failureNo]&&Store::row('coop_order',$site,(int)$failure['id'])['status']==='unpaid','a prior acknowledged receipt is recovered query-only; contradictory NOTPAY cannot trigger a close');
    $recoveryProvider=new SyntheticPaymentProvider([$status(OnlinePayDict::SUCCESS)]);
    $recoveredTick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$recoveryProvider);
    $recovered=PaymentService::presentOrder(Store::row('coop_order',$site,(int)$failure['id']));
    grCheck($recoveredTick['reconciled']===1&&$recoveredTick['closed']===0&&$recovered['status']==='paid'&&!$recovered['requires_manual_review'],'a later sweep heals a transient hook failure using the original receipt, without manual payment or cancellation');
    grCheck($recoveryProvider->calls===['query:'.$failureNo]&&Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',$failure['id'])->count()===1&&Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$failure['id'])->count()===1,'paid recovery performs no second close/debit and credits income/reward once');
    [$due,$dueNo]=$new('scheduled');Db::name('hsx_lead_coop_order')->where('id',$due['id'])->update(['create_time'=>time()-1201]);$provider=new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::CLOSED)]);
    $tick=PaymentOrderLifecycle::tick(5,50,static fn(int$s,string$c,string$t):object=>$provider);
    grCheck($tick['closed']===1&&Store::row('coop_order',$site,(int)$due['id'])['status']==='closed','same safe gateway reconciler completes timed-out real prepay cancellation');
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2,false,['deposit_amount'=>'200.00','cycles'=>[['key'=>'year','name'=>'年付','months'=>12,'enabled'=>true,'price'=>'99.00']]])+['site_id'=>$site]);
    $quote=(new EntityMembershipService($ctx))->quote('ML701','year');$membership=(new PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'year','request_id'=>'gateway-membership-first','quote_token'=>$quote['quote_token']]);$memberNo='GATEWAY_MEMBERSHIP';
    Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$membership['id'],'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'out_trade_no'=>$memberNo,'money'=>$membership['amount'],'status'=>PayDict::STATUS_ING,'type'=>PayDict::WECHATPAY,'channel'=>'weapp']);
    $memberPaid=$cancel($membership,new SyntheticPaymentProvider([$status(OnlinePayDict::NOTPAY),$status(OnlinePayDict::SUCCESS)]));
    $memberState=EntityMembershipService::state($site,(int)$receiver['id']);
    grCheck($memberPaid['status']==='paid'&&$memberState['active']&&$memberState['level_code']==='ML701','membership cancellation race commits real rights, not a rollback or cancellation');
    grCheck((int)Db::name('pay')->where('out_trade_no',$memberNo)->value('status')===(int)PayDict::STATUS_FINISH,'membership gateway SUCCESS receipt remains committed after close returns');
    $memberReward=Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$membership['id'])->find();grCheck($memberReward['base_amount']==='99.00'&&$memberReward['amount']==='9.90','membership success race shares service fee only, excluding actual 200 deposit');
    PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$membership['id'],'out_trade_no'=>$memberNo]);
    grCheck(EntityMembershipService::state($site,(int)$receiver['id'])['expires_at']===$memberState['expires_at']&&Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$membership['id'])->count()===1,'membership receipt replay extends no extra period and creates no duplicate reward');
    $blockedQuote=(new EntityMembershipService($ctx))->quote('ML701','year');$blockedOrder=(new PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'year','request_id'=>'gateway-blocked-renewal','quote_token'=>$blockedQuote['quote_token']]);$blockedNo='GATEWAY_BLOCKED_MEMBERSHIP';
    Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$blockedOrder['id'],'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'out_trade_no'=>$blockedNo,'money'=>$blockedOrder['amount'],'status'=>PayDict::STATUS_ING,'type'=>PayDict::WECHATPAY,'channel'=>'weapp']);
    Store::query('partner',$site)->where('merchant_id',$receiver['id'])->update(['blocked_at'=>time()]);
    $blockedResult=$cancel($blockedOrder,new SyntheticPaymentProvider([$status(OnlinePayDict::SUCCESS)]));
    grCheck($blockedResult['status']==='paid'&&$blockedResult['requires_manual_review']&&$blockedResult['close_result']==='paid_pending','gateway success with blocked membership is paid-pending, not a false completed grant');
    grCheck(Data::decode(Store::row('coop_order',$site,(int)$blockedOrder['id'])['rule_json'])['requires_manual_review']==='merchant_blocked_during_payment','generic gateway recovery must preserve the actual business conflict reason');
    grCheck(EntityMembershipService::state($site,(int)$receiver['id'])['expires_at']===$memberState['expires_at']&&Db::name('hsx_lead_promotion_reward')->where('coop_order_id',$blockedOrder['id'])->count()===0,'blocked renewal adds no period or invitation reward despite the real paid receipt');
    $source=file_get_contents(dirname(__DIR__).'/app/service/cooperation/PaymentGatewayReconciler.php');grCheck(!str_contains($source,'->check(')&&!str_contains($source,'->close($site'),'reconciler never calls recursive CorePayService check or unsafe ING close fallback');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'random localhost schema, gateway doubles and real framework paySuccess/payClose/business hooks, no real gateway or customer data'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$e){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
