<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $fn)if(function_exists($fn))exit("Disable network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\{Context,ProviderChannelService,ConnectionService,SyncService};
use addon\hsx_lead\app\service\cooperation\PartnerService;
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$failed=false;$pdo=null;$schema='';
function displayCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException('Assertion failed: '.$label);$GLOBALS['checks']++;}
function displayDenied(callable $fn,string $label):void{try{$fn();}catch(CommonException $e){displayCheck(true,$label);return;}throw new RuntimeException('Expected rejection: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();$ctx=new Context($site,1);$service=new ProviderChannelService($site);$other=new ProviderChannelService($site+1);
    $defaults=['wanji'=>'W平台','soujike'=>'S平台','aiguanji'=>'A平台','jixiaoer'=>'J平台'];$initial=$service->configuration();
    foreach($initial['items'] as $row){displayCheck($row['name']===$defaults[$row['key']]&&$row['display_name']===$row['name'],'default alias is stable for '.$row['key']);displayCheck($row['technical_name']!==$row['name'],'administrator can identify the real adapter in separate technical metadata');}
    displayCheck($service->displayName('wanjiguanjia')==='W平台','legacy adapter alias resolves the same canonical display name');
    displayCheck(Db::name('sys_config')->where('site_id',$site)->where('config_key',ProviderChannelService::KEY)->count()===0,'default names do not silently write a configuration');
    foreach($service->available() as $row)displayCheck($row['name']===$defaults[$row['key']]&&!array_key_exists('technical_name',$row),'merchant provider list contains only the display name');
    $items=$initial['items'];foreach($items as &$row)if($row['key']==='wanji')$row['display_name']='  本站 W 渠道  ';unset($row);
    $saved=$service->save($ctx,['revision'=>$initial['revision'],'items'=>$items]);
    displayCheck($service->displayName('wanji')==='本站 W 渠道','validated alias is trimmed and persisted');
    displayCheck($other->displayName('wanji')==='W平台','display configuration is isolated by site');
    $configRow=Db::name('sys_config')->where('site_id',$site)->where('config_key',ProviderChannelService::KEY)->find();$raw=Data::decode($configRow['value']);
    displayCheck($raw['display_names']['wanji']==='本站 W 渠道'&&$raw['enabled']['wanji']===true,'display names share the existing policy JSON without changing the switch');
    foreach(['',' ',null,false,24,'<b>平台</b>',"平台\n名称","平台\0名称","平台\u{200B}",str_repeat('界',25),"\xC3\x28"] as $bad){
        $candidate=$saved['items'];$candidate[0]['display_name']=$bad;
        displayDenied(static fn()=>$service->save($ctx,['revision'=>$saved['revision'],'items'=>$candidate]),'invalid alias rejected: '.get_debug_type($bad));
        displayCheck($service->configuration()['revision']===$saved['revision'],'rejected alias does not write or change the revision');
    }
    $flagOnly=array_map(static fn($row)=>['key'=>$row['key'],'enabled'=>$row['key']==='wanji'?false:$row['enabled']],$saved['items']);
    $disabled=$service->save($ctx,['revision'=>$saved['revision'],'items'=>$flagOnly]);
    displayCheck(!$service->enabled('wanji')&&$service->displayName('wanji')==='本站 W 渠道','switch-only update retains the saved alias even for a paused channel');
    displayCheck(!in_array('wanji',array_column($service->available(),'key'),true),'renaming does not bypass a disabled channel');
    $merchant=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'member_id'=>101,'name'=>'Synthetic alias merchant','contact_name'=>'Synthetic operator','mobile'=>'','status'=>1,'subject_code'=>'ABCDEFGH23','create_time'=>time(),'update_time'=>time()]);
    Data::query('connection',$site)->insert(['site_id'=>$site,'merchant_id'=>$merchant,'provider'=>'wanji','enabled'=>1,'store_id'=>'synthetic-store','create_time'=>time(),'update_time'=>time()]);
    Db::name('hsx_lead_partner')->insert(['site_id'=>$site,'merchant_id'=>$merchant,'provider_requested'=>'wanji','create_time'=>time(),'update_time'=>time()]);
    $connection=(new ConnectionService($ctx))->get($merchant);
    displayCheck($connection['provider']==='wanji'&&$connection['provider_name']==='本站 W 渠道'&&$connection['channel_enabled']===false,'existing paused connection projects the current site alias without changing its provider identity');
    $profile=(new PartnerService(new Context($site,0,101)))->bootstrap();
    displayCheck($profile['profile']['provider_requested_name']==='本站 W 渠道'&&$profile['profile']['connection']['provider_name']==='本站 W 渠道','merchant requested source and connection use the same alias');
    displayCheck(!in_array('wanji',array_column($profile['providers'],'key'),true),'profile does not reoffer the renamed paused source');
    displayDenied(static fn()=>$service->save(new Context($site+1,1),['revision'=>$disabled['revision'],'items'=>$disabled['items']]),'cross-site context cannot rename this channel');
    $before=Data::query('connection',$site)->where('merchant_id',$merchant)->find();
    $next=$disabled['items'];foreach($next as &$row)if($row['key']==='wanji')$row['display_name']='W2平台';unset($row);
    $new=$service->save($ctx,['revision'=>$disabled['revision'],'items'=>$next]);
    displayCheck(Data::query('connection',$site)->where('merchant_id',$merchant)->find()===$before,'alias-only change leaves credentials, source scope, synchronization and history untouched');
    displayCheck((new ConnectionService($ctx))->get($merchant)['provider_name']==='W2平台','API presentation immediately reflects the updated alias');
    $connection=Data::query('connection',$site)->where('merchant_id',$merchant)->find();
    $diagnostic='Synthetic real-brand diagnostic: 万机管家 SYNTHETIC_PRIVATE_ACCOUNT';
    $run=(int)Data::query('sync_run',$site)->insertGetId(['site_id'=>$site,'merchant_id'=>$merchant,'connection_id'=>$connection['id'],'config_version'=>$connection['config_version'],'status'=>'failed','error_code'=>'invalid_credentials','error_message'=>$diagnostic,'cursor_json'=>'{}','summary_json'=>'{}','create_time'=>time(),'update_time'=>time()]);
    Data::query('connection',$site)->where('id',$connection['id'])->update(['last_sync_status'=>'failed','last_sync_message'=>$diagnostic]);
    $projected=(new ConnectionService($ctx))->get($merchant);
    displayCheck(!str_contains(json_encode($projected,JSON_UNESCAPED_UNICODE),'SYNTHETIC_PRIVATE_ACCOUNT')&&!str_contains(json_encode($projected,JSON_UNESCAPED_UNICODE),'万机管家'),'connection summary and nested progress never expose historical adapter diagnostics');
    displayCheck(str_contains($projected['last_sync_message'],'账号')&&str_contains($projected['last_sync_message'],'密码'),'credential failures retain actionable locally authored guidance');
    $detail=(new SyncService())->detail($site,$run);
    displayCheck(!str_contains(json_encode($detail,JSON_UNESCAPED_UNICODE),'SYNTHETIC_PRIVATE_ACCOUNT')&&!str_contains(json_encode($detail,JSON_UNESCAPED_UNICODE),'万机管家'),'sync detail API uses the same safe reason without echoing the original diagnostic');
    displayCheck(Data::row('sync_run',$site,$run)['error_message']===$diagnostic&&Data::query('connection',$site)->where('id',$connection['id'])->value('last_sync_message')===$diagnostic,'safe API projections do not rewrite adapter diagnostics or historical records');
    displayDenied(static fn()=>$service->save($ctx,['revision'=>$disabled['revision'],'items'=>$next]),'stale revision cannot overwrite a newer alias');
    $raw=Data::decode(Db::name('sys_config')->where('site_id',$site)->where('config_key',ProviderChannelService::KEY)->value('value'));$raw['display_names']['wanji']='<script>bad</script>';$raw['display_names']['soujike']="S\n平台";
    Db::name('sys_config')->where('site_id',$site)->where('config_key',ProviderChannelService::KEY)->update(['value'=>Data::json($raw)]);
    displayCheck($service->displayName('wanji')==='W平台'&&$service->displayName('soujike')==='S平台','unsafe persisted names fall back to a fixed alias instead of leaking markup/control text');
    displayCheck(!$service->enabled('wanji')&&$service->enabled('soujike'),'display data corruption cannot silently reopen or close an established channel');
    $raw['enabled']['wanji']=true;unset($raw['display_names']);Db::name('sys_config')->where('site_id',$site)->where('config_key',ProviderChannelService::KEY)->update(['value'=>Data::json($raw)]);
    displayCheck($service->displayName('wanji')==='W平台'&&$service->enabled('wanji'),'existing switch-only policy uses stable aliases without migration');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'site ERP display aliases, shared API projections, validation, optimistic locking and unchanged synchronization policy','remote_calls'=>0,'existing_business_rows_read'=>0],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable $e){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($e).': '.$e->getMessage().' at '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
