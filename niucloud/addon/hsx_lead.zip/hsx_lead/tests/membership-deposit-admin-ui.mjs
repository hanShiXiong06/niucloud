import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0
const check=(condition,message)=>{assert.ok(condition,message);checks++}
const read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
const clone=value=>JSON.parse(JSON.stringify(value))
function run(source,deps){const module={exports:{}};const js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,Math,JSON,Promise,Error})(key=>{if(key in deps)return deps[key];if(key.endsWith('.vue'))return{default:{}};throw Error(key)},module,module.exports);return module.exports}
function script(file){const parsed=compiler.parse(read(file),{filename:file});check(!parsed.errors.length,'SFC parses '+file);const built=compiler.compileScript(parsed.descriptor,{id:'deposit-test'});check(!compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'deposit-test',compilerOptions:{bindingMetadata:built.bindings,expressionPlugins:['typescript']}}).errors.length,'template compiles '+file);for(const style of parsed.descriptor.styles)check(!compiler.compileStyle({source:style.content,filename:file,id:'deposit-test',scoped:style.scoped}).errors.length,'styles compile');return built.content}

const transportCalls=[],request=Object.fromEntries(['get','post'].map(method=>[method,async(...args)=>{transportCalls.push([method,...args]);return{data:{}}}]))
const api=run(read('admin/api/deposit.ts'),{'@/utils/request':{default:request}})
await api.getDeposits({status:'pending'});await api.getDeposit(12);await api.reviewDeposit(12,'approve','已核对','a'.repeat(64));await api.refreshDeposit(12)
check(transportCalls[0][1]==='hsx_lead/cooperation/deposits'&&transportCalls[0][2].params.status==='pending','list request passes actual status to tenant-scoped API')
check(transportCalls[1][1]==='hsx_lead/cooperation/deposits/12','original request detail uses anchor id')
check(transportCalls[2][2].decision==='approve'&&!('amount' in transportCalls[2][2]),'browser does not choose refund amount or payment source')
check(transportCalls[2][2].request_version==='a'.repeat(64),'review is bound to the exact request read before confirmation')
check(transportCalls[3][1].endsWith('/12/refresh')&&Object.keys(transportCalls[3][2]).length===0,'refresh sends no new refund identifier or amount')

let current={id:12,request_version:'a'.repeat(64),merchant_name:'合成门店',amount:'300.00',status:'pending',reason:'退出',sources:[{order_id:12,order_no:'FIXTURE12',amount:'300.00',status:'pending'}]}
let writeWork=async(id,decision)=>{current.status=decision==='approve'?'refunding':'rejected'},readWork=async()=>({data:clone(current)}),dialogWork=async()=>{}
let listAdapter,listWork=async()=>({data:{data:[],total:0}})
const writes=[],queries=[],messages=[],cleanups=[],fullRules=['hsx_lead_deposit_manage','hsx_lead_deposit_detail','hsx_lead_deposit_review','hsx_lead_deposit_refresh'],user=Vue.reactive({siteInfo:{site_id:100005},token:'synthetic-admin-a',rules:[...fullRules]})
const deps={vue:{...Vue,onMounted(){},onBeforeUnmount:callback=>cleanups.push(callback)},'element-plus':{ElMessage:{success:value=>messages.push(['success',value]),warning:value=>messages.push(['warning',value])},ElMessageBox:{confirm:(...args)=>dialogWork(...args)}},'@/stores/modules/user':{default:()=>user},'../../composables/navigation':{hasLeadPagePermission:(actor,key)=>actor.rules.includes(key)},'../../composables/cooperation':{coopError:(e,fallback)=>e?.message||fallback,coopMoney:value=>'¥'+value,coopTime:String,useCooperationList:adapter=>{listAdapter=adapter;return({query:Vue.reactive({page:1,limit:20}),rows:Vue.ref([]),total:Vue.ref(0),loading:Vue.ref(false),error:Vue.ref(''),load:async()=>{queries.push('list')},search:async()=>{},changePage:async()=>{}})}},'../../api/deposit':{getDeposits:async()=>listWork(),getDeposit:async()=>readWork(),reviewDeposit:async(...args)=>{writes.push(args);return writeWork(...args)},refreshDeposit:async(id)=>{queries.push(['refresh',id])}}}
const state=run(script('admin/views/cooperation/DepositRequests.vue'),deps).default.setup({},{expose(){}})
await state.open({id:12});check(state.detail.value.id===12&&state.sources.value.length===1,'drawer reads original server request and payment sources')
await state.review('reject');check(writes.length===0&&state.actionError.value.includes('拒绝原因'),'reject requires a useful reason before sending mutation')
let releaseDialog;dialogWork=()=>new Promise(resolve=>{releaseDialog=resolve})
const approval=state.review('approve');await state.review('approve');check(state.busy.value&&writes.length===0,'busy lock includes confirmation and blocks duplicate financial instructions')
releaseDialog();await approval;check(writes.length===1&&state.detail.value.status==='refunding','approval reads persisted refunding state')
check(messages.at(-1)[0]==='warning'&&!messages.at(-1)[1].includes('已确认退还'),'approved or processing is never presented as funds refunded')
await state.refresh();check(queries.some(row=>Array.isArray(row)&&row[0]==='refresh'),'only original refund progress is queried')
dialogWork=async()=>{};current.status='approved';current.can_continue=true;await state.readDetail();await state.review('approve');check(writes.length===2&&state.detail.value.status==='refunding','explicit approved continuation reuses the original request and follows persisted state')
check(read('admin/views/cooperation/DepositRequests.vue').includes('继续已审核退款')&&read('admin/views/cooperation/DepositRequests.vue').includes('沿用已保存的退款号'),'continuation is clearly distinguished from read-only result refresh')
current.can_continue=false
current.status='refunded';await state.readDetail();const beforeRefresh=queries.length;await state.refresh();check(queries.length===beforeRefresh,'completed refund cannot issue more progress or financial actions')

current.status='pending';await state.open({id:12});dialogWork=async()=>{};writeWork=async()=>{throw Error('结果未知，请核对原退款')};await state.review('approve')
check(state.readRequired.value&&state.actionError.value.includes('结果未知'),'unknown mutation result requires a persisted read before any other instruction')
const unknownCount=writes.length;await state.review('approve');await state.refresh();check(writes.length===unknownCount,'unknown result is not blindly repeated')
await state.readDetail();check(!state.readRequired.value,'explicit read restores only currently valid actions')
user.rules=['hsx_lead_deposit_manage','hsx_lead_deposit_detail'];await state.review('approve');check(writes.length===unknownCount,'detail-only privilege cannot review refunds')
await Vue.nextTick();check(!state.visible.value&&!state.detail.value.id,'permission changes clear the selected financial record before another read')
readWork=async()=>({data:clone(current)});await state.open({id:12})
readWork=async()=>({data:{id:13,amount:'300.00',status:'pending',sources:[]}});await state.readDetail();check(state.readRequired.value&&state.detail.value.id===12,'wrong source id cannot replace original request or enable payment instructions')
readWork=async()=>({data:{id:12,amount:'300.00',status:'unknown',sources:[]}});await state.readDetail();check(state.readRequired.value,'unknown refund status remains blocked')
script('admin/views/cooperation/deposits-page.vue')
check(read('admin/views/cooperation/deposits-page.vue').includes('require-all-data'),'finance review keeps framework all-data scope gate')
check(read('admin/views/cooperation/Orders.vue').includes('promotion_base_amount'),'membership receipts show service-only commission base')
user.rules=[...fullRules];readWork=async()=>({data:clone(current)});current.status='pending';await Vue.nextTick();await state.open({id:12})
let releaseApproval;dialogWork=()=>new Promise(resolve=>{releaseApproval=resolve});const permissionApproval=state.review('approve'),beforePermissionWrite=writes.length;user.rules=['hsx_lead_deposit_manage','hsx_lead_deposit_detail'];await Vue.nextTick();releaseApproval();await permissionApproval
check(writes.length===beforePermissionWrite&&!state.visible.value&&!state.detail.value.id,'revoking permission during confirmation cannot send a financial instruction or retain old detail')
user.rules=[...fullRules];await Vue.nextTick();await state.open({id:12});const actorApproval=state.review('approve'),beforeActorWrite=writes.length;user.token='synthetic-admin-b';await Vue.nextTick();releaseApproval();await actorApproval
check(writes.length===beforeActorWrite&&!state.visible.value,'switching actor during confirmation aborts before the API mutation')
let releaseRead;readWork=()=>new Promise(resolve=>{releaseRead=resolve});const delayedRead=state.open({id:12});user.siteInfo.site_id=100006;await Vue.nextTick();releaseRead({data:clone(current)});await delayedRead
check(!state.detail.value.id&&!state.visible.value,'a late response from the prior site cannot repopulate the financial drawer')
user.siteInfo.site_id=100005;readWork=async()=>({data:clone(current)});await Vue.nextTick();await state.open({id:12});dialogWork=async()=>{};let releaseWrite;writeWork=()=>new Promise(resolve=>{releaseWrite=resolve});const lateWrite=state.review('approve');for(let turn=0;turn<8&&!releaseWrite;turn++)await Promise.resolve();check(typeof releaseWrite==='function','fixture reached the explicitly confirmed API write before simulating an identity change');const beforeLateMessages=messages.length,beforeLateQueries=queries.length;user.token='synthetic-admin-c';await Vue.nextTick();releaseWrite();await lateWrite
check(messages.length===beforeLateMessages&&queries.length===beforeLateQueries&&!state.detail.value.id,'an already-sent old-actor response cannot launch new detail/list reads or success messages in the new session')
let releaseList;listWork=()=>new Promise(resolve=>{releaseList=resolve});const lateList=listAdapter({page:1});user.rules=['hsx_lead_deposit_detail'];await Vue.nextTick();releaseList({data:{data:[{id:12}],total:1}});await assert.rejects(lateList,/权限/);checks++
user.rules=[...fullRules];await Vue.nextTick();readWork=async()=>({data:clone(current)});await state.open({id:12});dialogWork=()=>new Promise(resolve=>{releaseApproval=resolve});const unmountApproval=state.review('approve'),beforeUnmountWrite=writes.length;cleanups.forEach(callback=>callback());releaseApproval();await unmountApproval
check(writes.length===beforeUnmountWrite,'unmounting while confirmation is pending prevents a later API write')
console.log(`PASS ${checks} deposit admin checks; actual Vue/SFC and transport doubles, no live API, refunds, gateway or database writes.`)
