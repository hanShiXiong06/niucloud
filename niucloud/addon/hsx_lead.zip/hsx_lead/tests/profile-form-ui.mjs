import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { profileConfigApi } from './profile-config-fixture.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),dom=require('@vue/compiler-dom'),sass=require('sass'),ts=require('typescript')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++},read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
const filename='uni-app/components/cooperation/CoopProfilePanel.vue',source=read(filename),parsed=compiler.parse(source,{filename}),descriptor=parsed.descriptor,script=compiler.compileScript(descriptor,{id:'profile-form-ui'})
check(!parsed.errors.length&&!compiler.compileTemplate({source:descriptor.template.content,filename,id:'profile-form-ui',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'profile and form parse and compile')
const template=descriptor.template.content,css=descriptor.styles.map(style=>style.lang==='scss'?sass.compileString(style.content,{loadPaths:[path.join(plugin,'uni-app/components/cooperation')]}).css:style.content).join('\n')
check(/@media\s*\(max-width:\s*360px\)[\s\S]*\.coop-profile-contact-row\s*\{[^}]*grid-template-columns:\s*minmax\(0,\s*1fr\)/.test(css),'contact fields stack on narrow phones instead of squeezing names and phone numbers')
check(template.indexOf('门店信息')<template.indexOf('照片与资质')&&template.indexOf('照片与资质')<template.indexOf('经营业务与交付能力'),'identity, evidence and capability are separate task groups')
check(template.indexOf('coop-profile-promotion-entry')>template.indexOf('name="erp-settings"'),'secondary promotion entry stays below the profile task, not ahead of the first field')
check(template.includes('name="erp-settings"')&&template.includes(':label="profile.connection?.connected'),'ERP is independently collapsible while a saved connection summary remains visible in its closed header')
check(template.includes('<CoopMembershipEntry ')&&template.includes(':embedded="displayOnly"')&&!template.includes('class="coop-profile-buy"'),'entity benefits are a single comparison entry with an explicit DIY embedded skin')
check(template.includes("hasSection('benefits') && shown('showMembership')"),'benefits section respects its one framework membership visibility flag')
const tree=dom.baseParse(template),nodes=node=>[node,...(node.children||[]).flatMap(nodes)],elements=nodes(tree).filter(node=>node.type===1)
check(elements.filter(node=>node.tag==='u-input').every(node=>node.props.some(prop=>prop.type===7&&prop.arg?.content==='custom-style'&&prop.exp?.content==='cooperationInputStyle')),'all profile inputs use the public shared 48px input style')
check(elements.filter(node=>node.tag==='u-button').every(node=>node.props.some(prop=>prop.type===7&&prop.arg?.content==='custom-style'&&prop.exp?.content==='cooperationButtonStyle')),'the sole footer primary action uses the shared 44px button style')
check(['name','contact','mobile','region','address','capabilities'].every(key=>template.includes(`id="coop-profile-${key}"`)&&template.includes(`fieldError('${key}')`)),'each local validation category has an adjacent error and stable scroll anchor')
const sheet=read('uni-app/components/cooperation/CoopTaskSheet.vue')
check((sheet.match(/:scroll-into-view="scrollIntoView"/g)||[]).length===2&&sheet.includes("scrollIntoView: ''"),'page and popup sheet bodies forward optional native scroll anchors without changing default navigation')
const compiled=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText,module={exports:{}},storage=new Map(),events=[]
vm.runInNewContext('(function(require,module,exports){'+compiled+'\n})',{Date,Math,String,Number,Object,Promise,Map,Set,setTimeout,clearTimeout,uni:{getStorageSync:key=>storage.get(key),setStorageSync:(key,value)=>storage.set(key,value),removeStorageSync:key=>storage.delete(key)}})(key=>{
    if(key==='vue')return Vue
    if(key.endsWith('.vue'))return{default:{}}
    if(key==='../../api/cooperation')return profileConfigApi
    if(key==='@/utils/common')return{img:value=>'normalized:'+value}
    if(key.startsWith('../../utils/'))return loadMobileUtility(path.basename(key))
    throw Error(key)
},module,module.exports)
const props=Vue.reactive({profile:{id:7,site_id:100005,member_id:101,name:'已有门店',contact_name:'已有联系人',mobile:'13900000000',province_id:1,city_id:2,district_id:3,address:'已有地址',storefront_image:'old.png',business_license_token:'a'.repeat(64),business_capabilities:[]},config:{businesses:[{key:'purchase',name:'二手机',enabled:true,dimension:'model'}]},providers:[],editing:true,onboarding:false,page:true,busy:false,displayOnly:false,section:'all',appearance:{}})
const state=module.exports.default.setup(props,{emit:(...args)=>events.push(args),expose(){}})
async function flush(){for(let i=0;i<8;i++){await Promise.resolve();await Vue.nextTick()}}
await flush()
state.form.name='';await flush();state.submit();await flush()
check(state.errorField.value==='name'&&state.fieldError('name')==='请填写门店名称与联系人'&&state.scrollTarget.value==='coop-profile-name'&&!events.length,'first missing identity field stays local and scrolls into view without submitting')
state.form.name='修正门店';await flush();check(!state.localError.value&&!state.errorField.value,'editing the failing field clears that local error only')
state.form.contact_name='';await flush();state.submit();await flush();check(state.errorField.value==='contact'&&state.scrollTarget.value==='coop-profile-contact','missing contact gets its own location instead of pointing to the name field')
state.form.address='别的字段改动';await flush();check(state.errorField.value==='contact','editing an unrelated field does not hide the actual failing field')
state.form.contact_name='联系人';state.form.mobile='123';await flush();state.submit();await flush();check(state.errorField.value==='mobile'&&state.fieldError('mobile')==='请填写有效联系电话','existing phone rule is retained with a nearby error')
state.form.mobile='13900000000';state.form.district_id=0;await flush();state.submit();await flush();check(state.errorField.value==='region'&&state.scrollTarget.value==='coop-profile-region','missing complete region locates the searchable region control')
state.form.district_id=3;state.form.address='';await flush();state.submit();await flush();check(state.errorField.value==='address'&&state.scrollTarget.value==='coop-profile-address','missing street address is separate from the region selector')
state.form.address='保留原有草稿地址';state.selectedBusinesses.value=['purchase'];await flush();state.submit();await flush();check(state.errorField.value==='capabilities'&&state.localError.value==='请选择二手机的具体交付能力，或取消该业务','selected business still requires its own real capability selection')
state.capabilityChoices.purchase=[{id:'model-a',title:'合成型号'}];await flush();state.licenseUploading.value=true;state.submit();state.openPromotion();state.close();check(!events.length&&state.locked.value,'ongoing license upload locks save, leaving the task and secondary navigation')
state.licenseUploading.value=false;state.submit();check(events.at(-1)?.[0]==='submit'&&events.at(-1)[1].business_license_token==='a'.repeat(64)&&events.at(-1)[1].business_capabilities[0].option_ids[0]==='model-a','success preserves opaque license token and the original capability payload')
check(events.at(-1)[1].address==='保留原有草稿地址'&&state.form.storefront_image==='old.png','validation and scrolling preserve other form edits and existing picture')
state.openPromotion();check(events.at(-1)?.[0]==='promotion'&&events.at(-1)?.[1]==='overview','the moved promotion link retains its established destination')
const draft=[...storage.values()].find(value=>value?.form);check(draft.form.name==='修正门店'&&!Object.hasOwn(draft.form,'business_license_token')&&!JSON.stringify(draft).includes('data:image')&&draft.capabilityIds.purchase[0]==='model-a','scoped compact draft retains edits and selected IDs, never a private document token or image bytes')
props.editing=false;props.displayOnly=true;props.appearance={};await flush()
check(state.tools.value.map(tool=>tool.key).join(',')==='profile,capability,inventory,connection','saved DIY missing new switches still exposes essential owner profile, delivery and ERP tools')
props.appearance={showProfile:0,showCapability:false,showInventory:0,showConnection:'0'};await flush()
check(state.tools.value.length===0&&!state.hasConfiguredTools.value,'explicit off switches hide legacy tools when a standard framework GraphicNav supplies navigation')
props.appearance={profileText:'编辑我的门店',profileImage:'custom/profile.png',titleColor:'#123456',textColor:'#234567',iconColor:'#345678',panelColor:'#fafafa',titleSize:20};await flush()
check(state.tools.value[0].label==='编辑我的门店'&&state.tools.value[0].image==='normalized:custom/profile.png','owner tool text and selected icon consume actual DIY values')
check(state.displayStyle.value['--lead-diy-title']==='#123456'&&state.displayStyle.value['--lead-diy-text']==='#234567'&&state.displayStyle.value['--lead-diy-icon']==='#345678'&&state.displayStyle.value['--lead-diy-panel']==='#fafafa'&&state.displayStyle.value['--lead-diy-title-size']==='20px','rendered profile style uses shared configured colors and type size')
props.appearance={subtitle:'',noticeImage:'custom/bell.png'};await flush()
check(state.text('subtitle','fallback')===''&&state.noticeImage.value==='normalized:custom/bell.png','an intentionally blank subtitle remains hidden while notice artwork uses the resource resolver')
props.profile.permissions={can_manage_billing:false,can_manage_erp:false};await flush()
check(state.tools.value.map(tool=>tool.key).join(',')==='inventory','staff do not gain owner profile or ERP controls through missing DIY flags')
props.profile.cooperation_stats={outgoing:7,incoming:0};check(state.statCount('outgoing')===7&&state.statCount('incoming')===0,'identity counters use actual bootstrap counts, including real zero')
props.profile.cooperation_stats={outgoing:null};check(state.statCount('outgoing')==='—'&&state.statCount('incoming')==='—','unknown counters are not converted into successful empty counts')
const beforeTool=events.length;props.busy=true;state.toolAction('inventory');check(events.length===beforeTool,'busy or decoration context cannot dispatch a profile tool action');props.busy=false
check(!template.includes('CoopPromotionEntryCard')&&!template.includes('promotion-entry__art')&&template.includes("$emit('promotion','application')"),'compact promotion retains the real service-provider application route without an invented status or poster')
console.log(`PASS ${checks} profile grouping, plans entry, native error navigation and draft/upload checks; real Vue/SFC with synthetic inputs only.`)
