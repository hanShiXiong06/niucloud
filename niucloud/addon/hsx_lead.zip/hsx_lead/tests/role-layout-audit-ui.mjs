import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'

// A layout regression, not a browser claim. Real Workbench/useCooperation state
// and template are SSR-rendered while bootstrap is deliberately unresolved.
// Native component geometry below is an explicit CSS model at width 390.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript'), sfc = require('@vue/compiler-sfc')
const { compile } = require('@vue/compiler-dom'), { renderToString } = require('@vue/server-renderer')
const mobile = path.join(plugin, 'uni-app'), filename = path.join(mobile, 'components/cooperation/CooperationWorkbench.vue')
const source = fs.readFileSync(filename, 'utf8'), descriptor = sfc.parse(source, { filename }).descriptor
const script = sfc.compileScript(descriptor, { id: 'role-layout-audit' })
let checks = 0
const check = (value, message) => { assert.ok(value, message); checks++ }
function execute(input, dependencies = {}, globals = {}) {
    const module = { exports: {} }, code = ts.transpileModule(viteFixture(input), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + code + '})', { Date, Math, Number, String, Object, Array, Map, Set, Promise, JSON, console, ...globals })(key => key in dependencies ? dependencies[key] : key.endsWith('.vue') ? { default: {} } : key.startsWith('../../utils/') ? loadMobileUtility(path.basename(key)) : (() => { throw Error('Unexpected dependency ' + key) })(), module, module.exports)
    return module.exports
}
const template = new Function('Vue', compile(descriptor.template.content, { mode: 'function', prefixIdentifiers: true, isCustomElement: name => ['view', 'text', 'scroll-view', 'button'].includes(name) }).code)(Vue)
const nativeTag = { inheritAttrs: false, setup(_props, { slots }) { return () => Vue.h('div', slots.default?.()) } }
async function render(state, props) {
    const context = { ...state, ...props, themeColor: () => ({}) }; delete context.__isScriptSetup
    const app = Vue.createSSRApp({ setup: () => context, render: template })
    app.config.warnHandler = () => {}
    for (const tag of new Set([...descriptor.template.content.matchAll(/<([A-Z][\w-]*|z-paging|u-button|pay)\b/g)].map(match => match[1]))) if (!['CooperationSearch', 'u-button'].includes(tag)) app.component(tag, nativeTag)
    app.component('CooperationSearch', { inheritAttrs: false, props: ['disabled'], setup: props => () => Vue.h('input', { 'data-search': 'true', disabled: props.disabled }) })
    app.component('u-button', { inheritAttrs: false, props: ['disabled', 'text'], setup: props => () => Vue.h('button', { 'data-cta': 'true', disabled: props.disabled }, props.text) })
    return renderToString(app)
}
const hasClass = (html, name) => new RegExp('class="[^"]*\\b' + name + '\\b').test(html)
function geometry(html, width = 390, height = 844, safe = 0) {
    const rpx = width / 750, nav = 44 + rpx // nav includes its one-rpx border
    // Actual CooperationSearch: 44px u-search + 2*2px padding + 2*1px border.
    const controls = hasClass(html, 'coop-delivery-controls') ? 50 + (14 + 10 + 78 + 1) * rpx : 0
    const dock = hasClass(html, 'coop-publish-dock') ? 44 + (16 + 20) * rpx : 0
    const tabbar = hasClass(html, 'coop-framework-tabbar') ? 51 + safe : 0
    return { controls: +controls.toFixed(2), dock: +dock.toFixed(2), tabbar, content_top: +(nav + controls).toFixed(2), content_bottom: +(height - dock - tabbar).toFixed(2), body: +(height - nav - controls - dock - tabbar).toFixed(2) }
}
const searchDisabled = html => /<input\b[^>]*data-search="true"[^>]* disabled/.test(html)
const ctaDisabled = html => /<button\b[^>]*data-cta="true"[^>]* disabled/.test(html)
async function scenario(direction, failure = false) {
    let release, reject
    const bootstrap = new Promise((resolve, fail) => { release = resolve; reject = fail }), calls = [], navigation = []
    const api = { cooperationPageUrls: { deliveries: '/addon/hsx_lead/pages/workbench/index', stores: '/addon/hsx_lead/pages/stores/index' }, coopError: value => value.message, coopMoney: value => String(value), cooperationBootstrap: () => { calls.push('bootstrap'); return bootstrap } }
    const hook = execute(fs.readFileSync(path.join(mobile, 'composables/useCooperation.ts'), 'utf8'), { vue: Vue, '@/utils/common': { getSiteId:()=>100005, getToken: () => 'synthetic-member' }, '../api/cooperation': api })
    const runtime = { getStorageSync: () => '', setStorageSync() {}, removeStorageSync() {}, setNavigationBarTitle() {} }
    const component = execute(script.content, { vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} }, '@/utils/common': { getSiteId:()=>100005, getToken: () => 'synthetic-member' }, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack() {} }) }, '../../composables/useCooperationSubscribe': { useCooperationSubscribe:()=>({loading:Vue.ref(false), prepare: async () => false, request() {} }) }, '../../composables/useCooperation': hook, '../../api/cooperation': api, '../../utils/cooperation-navigation': { openCooperationTask: (...args) => navigation.push(args) } }, { uni: runtime }).default
    const props = { initialId: 0, initialTab: direction === 'outgoing' ? 'stores' : 'deliveries', initialDirection: direction, initialPromotion: false, initialInviter: 0, initialPaymentId: 0, task: '' }
    const state = component.setup(props, { expose() {} }), before = await render(state, props)
    check(state.ui.loggedIn.value && !before.includes('登录后参与商户协作'), direction + ' signed-in first render never impersonates a guest')
    const reading = state.initialize(), waiting = await render(state, props)
    check(state.ui.loggedIn.value && state.ui.loading.value && !state.ui.ready.value, direction + ' fixture is a real signed-in unresolved bootstrap, not guessed flags')
    check(searchDisabled(waiting) && (direction === 'incoming' || ctaDisabled(waiting)), direction + ' initial controls stay in layout but cannot search or publish')
    const revision = state.leadPagingRevision.value
    state.leadKeyword.value = 'uncommitted-loading'; state.searchLeads(); state.filterStatus('assigned'); state.openPublish()
    check(state.ui.query.keyword === '' && state.ui.query.status === '' && state.leadPagingRevision.value === revision && navigation.length === 0, direction + ' direct handlers also reject keyboard/tap events before identity data is ready')
    if (failure) reject(Error('Synthetic bootstrap unavailable'))
    else release({ data: { profile: { id: 7 }, config: { enabled: true }, providers: [], stats: {} } })
    await reading; await Vue.nextTick()
    const ready = await render(state, props)
    check(calls.length === 1 && state.ui.ready.value === !failure, direction + ' bootstrap settles once without list/API/native mount side effects')
    if (failure) {
        check(state.ui.error.value && searchDisabled(ready) && ctaDisabled(ready), 'bootstrap error preserves disabled visible shell and its retry message')
        check(JSON.stringify(geometry(waiting)) === JSON.stringify(geometry(ready)), 'bootstrap error does not collapse header/footer reserves')
        return { state, props, ready }
    }
    const result = { direction, before: geometry(before), waiting: geometry(waiting), ready: geometry(ready) }
    console.log(JSON.stringify(result))
    check(hasClass(ready, 'coop-delivery-controls') && hasClass(ready, 'coop-main-paging'), direction + ' final real template contains one filter shell and one pager')
    check(hasClass(ready, 'coop-publish-dock') === (direction === 'outgoing'), direction + ' receiving role never inherits publisher CTA space')
    check(JSON.stringify(result.before) === JSON.stringify(result.waiting) && JSON.stringify(result.waiting) === JSON.stringify(result.ready), direction + ' first render/bootstrap waiting/ready have zero top and bottom geometry delta')
    check(!searchDisabled(ready) && (direction === 'incoming' || !ctaDisabled(ready)), direction + ' successful bootstrap enables controls without replacing the shell')
    return { state, props, ready, result }
}
const outgoing = await scenario('outgoing'), incoming = await scenario('incoming')
const initialTabbarSequence = [outgoing.result.before.tabbar, outgoing.result.waiting.tabbar, outgoing.result.ready.tabbar]
check(JSON.stringify(initialTabbarSequence) === '[51,51,51]', 'signed-in initial lifecycle keeps the same fixed tabbar reserve')
outgoing.state.confirming.value = true
const busyHtml = await render(outgoing.state, outgoing.props), modal = geometry(busyHtml)
check(modal.tabbar === 51 && modal.content_bottom === outgoing.result.ready.content_bottom && !outgoing.state.showFrameworkTabbar.value, 'confirmation hides interactive tabbar mount but retains its outer geometry')
check(searchDisabled(busyHtml) && ctaDisabled(busyHtml), 'busy controls are semantically disabled, not only transparent pointer blockers')
const busyRevision = outgoing.state.leadPagingRevision.value
outgoing.state.searchLeads(); outgoing.state.filterStatus('assigned'); outgoing.state.openPublish()
check(outgoing.state.ui.query.keyword === '' && outgoing.state.ui.query.status === '' && outgoing.state.leadPagingRevision.value === busyRevision, 'busy direct events cannot alter the committed paging query')
outgoing.state.confirming.value = false
outgoing.state.leadKeyword.value = 'ready-query'; outgoing.state.searchLeads(); outgoing.state.filterStatus('assigned')
check(outgoing.state.ui.query.keyword === 'ready-query' && outgoing.state.ui.query.status === 'assigned', 'valid ready controls remain usable after confirmation completes')
outgoing.state.overlay.value = 'detail'
check(JSON.stringify(geometry(await render(outgoing.state, outgoing.props))) === JSON.stringify(outgoing.result.ready), 'opening an overlay does not remove underlying role shell reserves')
outgoing.state.overlay.value = ''; outgoing.state.ui.profile.value = {}
check(outgoing.state.onboarding.value && !outgoing.state.leadControlsVisible.value && !outgoing.state.showFrameworkTabbar.value && outgoing.state.reserveFrameworkTabbar.value, 'confirmed onboarding removes unavailable role controls without exposing private navigation')
await scenario('outgoing', true)
check(outgoing.result.ready.content_bottom < incoming.result.ready.content_bottom, 'different role CTA is intentional but it must not be confused with duplicated tab content')
const navFile = path.join(mobile, 'components/cooperation/CooperationNav.vue'), nav = sfc.parse(fs.readFileSync(navFile, 'utf8'), { filename: navFile }).descriptor
const navScript = sfc.compileScript(nav, { id: 'role-layout-nav' })
for (const title of ['找客户', '找门店']) {
    const state = execute(navScript.content, { vue: { ...Vue, useSlots: () => ({}), onMounted() {}, onBeforeUnmount() {} } }).default.setup({ title, subtitle: '', back: false, actions: [{ key: 'refresh' }], actionsWidth: 44, safeAreaInsetTop: true }, { emit() {}, expose() {} })
    check(state.navHeight.value === 44, title + ' real shared header remains44px; title is not a second-row cause')
}
const frameworkTabbar = fs.readFileSync(path.resolve(plugin, '../../../uni-app/src/components/tabbar/tabbar.vue'), 'utf8')
check(frameworkTabbar.includes("redirect({ url, mode: 'reLaunch' })"), 'native framework tab click reconstructs the page through reLaunch, so every tab switch can repeat bootstrap shell transitions')
console.log(`PASS ${checks} role-layout stability checks; actual Workbench SSR/bootstrap and explicit CSS geometry model, not browser/native measurements. No network/database/build operations.`)
