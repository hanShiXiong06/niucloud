<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityMembershipService,MembershipCatalogService,PartnerService,PaymentService,Store};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\PayDict;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function mvsCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site,[1,2,5,10,15,20,25,30]);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund']as$table){if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match))throw new RuntimeException('Missing official receipt DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));}
    $ctx=new Context($site,0,101);$admin=new Context($site,1);$settings=new ConfigService($admin);$config=$settings->get();$config['enabled']=true;$settings->save($config);
    $merchant=(int)(new PartnerService($ctx))->saveProfile(['name'=>'Synthetic visual shop','contact_name'=>'Owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road'])['id'];
    $membership=new EntityMembershipService($ctx);$billing=new PaymentService($ctx);
    $beforePersonal=Db::name('member')->where('site_id',$site)->where('member_id',101)->field('growth,growth_get,member_level,balance')->find();
    $initial=$membership->summary();mvsCheck($initial['level_visual']['preset']==='neutral'&&!$initial['active'],'ordinary current appearance remains neutral, not fabricated VIP');
    mvsCheck(array_column(array_column($initial['tiers'],'level_visual'),'preset')===['bronze','silver','gold','sapphire','amethyst','obsidian','obsidian','obsidian'],'actual framework directory resolves more than four visual levels by display rank');
    mvsCheck($initial['next_level']['level_visual']['preset']==='bronze'&&$initial['next_level']['level_color']===$initial['next_level']['level_visual']['accent_color'],'next-level experience shares the exact resolved accent and skin');
    $writeVisual=static function(array$visual)use($site):void{$raw=Db::name('member_level')->where('site_id',$site)->where('level_id',701)->value('level_benefits');$json=Data::decode($raw);$json['hsx_lead_subject']['visual']=$visual;$json['hsx_lead_subject']['level_color']='#000000';Db::name('member_level')->where('site_id',$site)->where('level_id',701)->update(['level_benefits'=>Data::json($json)]);};
    $quote=$membership->quote('ML701','month');mvsCheck($quote['can_purchase']&&$quote['payable_amount']==='19.00','genuine quote has normal entry price and qualification');
    $writeVisual(['preset'=>'gold','card_image'=>'/upload/test/level.webp','avatar_effect'=>false]);
    $order=$billing->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'month','request_id'=>'visual-change-after-quote','quote_token'=>$quote['quote_token']]);
    mvsCheck($order['status']==='unpaid'&&$order['amount']==='19.00','visual-only directory edit does not invalidate original signed price or create a second charge');
    $beforePaymentRule=Data::decode(Store::row('coop_order',$site,(int)$order['id'])['rule_json']);mvsCheck(!isset($beforePaymentRule['level_visual'])&&$beforePaymentRule['schema_version']===EntityMembershipService::SNAPSHOT_SCHEMA,'new appearance is not added to required financial snapshot and schema remains v3');
    $writeVisual(['preset'=>'sapphire','angle'=>180,'avatar_effect'=>true]);$billing->assertPayable((int)$order['id']);mvsCheck(true,'editing visual again while unpaid does not block cashier continuation');
    $event=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>'VISUAL_MEMBERSHIP_RECEIPT'];Db::name('pay')->insert($event+['main_type'=>PayDict::MEMBER,'main_id'=>101,'from_main_id'=>101,'money'=>$order['amount'],'status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);PaymentService::confirm($event);
    $paid=Store::row('coop_order',$site,(int)$order['id']);$beforeState=$membership->summary();mvsCheck($beforeState['active']&&$beforeState['level_visual']['preset']==='sapphire'&&$beforeState['level_color']==='#3769AD','actual paid state uses current skin and its accent, never the old independent colour field');
    $writeVisual(['preset'=>'custom','start_color'=>'#111111','end_color'=>'#333333','text_color'=>'#FFFFFF','accent_color'=>'#AA8844','card_image'=>'https://cdn.example.com/level.png','avatar_effect'=>false]);
    $afterState=$membership->summary();mvsCheck($afterState['level_visual']['preset']==='custom'&&$afterState['level_visual']['card_image']==='https://cdn.example.com/level.png'&&!$afterState['level_visual']['avatar_effect'],'current custom skin and effect preference are projected without changing membership status');
    mvsCheck($afterState['level_color']==='#AA8844'&&$afterState['level_visual']['text_color']==='#FFFFFF','simple consumers receive the same safe accent as full skin consumers');
    foreach(['active','level_code','rank','display_rank','expires_at','account_limit','unlimited','capabilities','benefits','experience']as$key)mvsCheck($afterState[$key]===$beforeState[$key],'appearance cannot change '.$key);
    mvsCheck(Store::row('coop_order',$site,(int)$order['id'])===$paid,'reading current appearance never writes the original paid order or frozen rule');
    mvsCheck($billing->order((int)$order['id'])['level_color']===$beforePaymentRule['level_color'],'original payment display snapshot is not rewritten to the current skin');
    $profile=(new PartnerService($ctx))->bootstrap()['profile'];mvsCheck($profile['membership']['level_visual']===$afterState['level_visual'],'merchant profile and membership page share one normalized current skin');
    Db::name('member_level')->where('site_id',$site)->where('level_id',701)->delete();$deleted=$membership->summary();mvsCheck($deleted['active']&&$deleted['expires_at']===$beforeState['expires_at']&&$deleted['capabilities']===$beforeState['capabilities'],'deleting the current visual definition never invalidates already-paid rights');
    mvsCheck($deleted['level_visual']['preset']==='bronze'&&$deleted['level_color']===$deleted['level_visual']['accent_color'],'a deleted presentation definition falls back safely by frozen display rank');
    mvsCheck(Db::name('member')->where('site_id',$site)->where('member_id',101)->field('growth,growth_get,member_level,balance')->find()===$beforePersonal,'no personal growth, level, account balance or data was altered by appearance projection');
    leadAssertIsolated($schema);echo 'PASS '.$checks." current membership visual/paid snapshot isolation checks; real services in random owned localhost schema, synthetic receipt, no live image/API/payment.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
