import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),ts=require('typescript'),sfc=require('@vue/compiler-sfc'),pre=require('@dcloudio/uni-cli-shared'),mobile=path.join(plugin,'uni-app')
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++}
function run(source,deps={},globals={}){const module={exports:{}},js=ts.transpileModule(viteFixture(source),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext('(function(require,module,exports){'+js+'})',{Date,Math,Number,String,Object,Array,Map,Set,Promise,JSON,console,...globals})(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:key.startsWith('../../utils/')?loadMobileUtility(path.basename(key)):(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports);return module.exports}
const filename=path.join(mobile,'components/cooperation/CooperationWorkbench.vue'),source=fs.readFileSync(filename,'utf8'),descriptor=sfc.parse(source,{filename}).descriptor,compiled=sfc.compileScript(descriptor,{id:'lead-delayed-native-ref'})
const pagerTag=descriptor.template.content.match(/<z-paging\b[^>]*>/)?.[0]||'',automatic=/:auto="true"/.test(pagerTag)
const zdir=path.resolve(plugin,'../../../uni-app/node_modules/z-paging/components/z-paging/js'),enumValues=run(fs.readFileSync(path.join(zdir,'z-paging-enum.js'),'utf8')).default
const methodNames=['reload','_preReload','_reload','_emitQuery']
function installedMethods(file,property){const ast=ts.createSourceFile(file,fs.readFileSync(path.join(zdir,file),'utf8'),ts.ScriptTarget.ES2020,true,ts.ScriptKind.JS),value=ast.statements.find(ts.isExportAssignment).expression;return property?value.properties.find(item=>item.name?.text===property):value}
const methodsAst=installedMethods('modules/data-handle.js','methods'),mainAst=installedMethods('z-paging-main.js'),mountedAst=mainAst.properties.find(item=>item.name?.text==='mounted')
// The actual installed methods retain their platform branches after the same
// uni preprocessing. This test never supplies a synchronous parent reload stub.
pre.initPreContext('mp-weixin')
const nativeSource=pre.preJs('export default {'+mountedAst.getText()+',methods:{'+methodsAst.initializer.properties.filter(item=>methodNames.includes(item.name?.text)).map(item=>item.getText()).join(',')+'}}')
pre.initPreContext('h5')
const app={globalData:{}},interceptor=run(fs.readFileSync(path.join(zdir,'z-paging-interceptor.js'),'utf8'),{},{getApp:()=>app}).default
async function settle(){for(let n=0;n<8;n++){await Promise.resolve();await Vue.nextTick()}}
async function scenario(direction){
    const scheduled=[],calls=[],completions=[],storage=new Map([['wap_site_id',100005]])
    const runtime={getStorageSync:key=>storage.get(key),setStorageSync:(key,value)=>storage.set(key,value),removeStorageSync:key=>storage.delete(key),setNavigationBarTitle(){},showToast(){}}
    const api={cooperationPageUrls:{deliveries:'/addon/hsx_lead/pages/workbench/index',stores:'/addon/hsx_lead/pages/stores/index'},coopError:err=>err?.message||'失败',cooperationBootstrap:async()=>{calls.push(['bootstrap']);return{data:{profile:{id:7},config:{enabled:true},providers:[],stats:{}}}},cooperationLeads:async query=>{calls.push(['list',query]);return{data:{data:[{id:direction==='outgoing'?101:201}],total:1}}}}
    const hook=run(fs.readFileSync(path.join(mobile,'composables/useCooperation.ts'),'utf8'),{vue:Vue,'@/utils/common':{getSiteId:()=>100005,getToken:()=> 'synthetic-member'},'../api/cooperation':api})
    const component=run(compiled.content,{vue:{...Vue,onMounted(){},onBeforeUnmount(){}},'@/utils/common':{getSiteId:()=>100005,getToken:()=> 'synthetic-member'},'@/hooks/useLogin':{useLogin:()=>({setLoginBack(){},isLoginCancelled:()=>false})},'../../composables/useCooperationSubscribe':{useCooperationSubscribe:()=>({loading:Vue.ref(false),prepare:async()=>false,request(){}})},'../../api/cooperation':api,'../../api/promotion':{promotionOverview:async()=>{throw Error('No unrelated read allowed')}},'../../composables/useCooperation':hook,'../../utils/cooperation-navigation':{}},{uni:runtime}).default
    const state=component.setup({initialId:0,initialTab:direction==='outgoing'?'stores':'deliveries',initialDirection:direction,initialPromotion:false,initialInviter:0,initialPaymentId:0,initialPurpose:'',task:''},{expose(){}})
    // Complete bootstrap and all Vue ticks while the native v-if child/ref has
    // not attached yet. Mini Program attachment is not guaranteed by nextTick.
    await Promise.all([state.initialize(),state.initialize()]);await settle()
    check(state.ui.ready.value&&state.leadListVisible.value&&state.leadPagingRef.value===null,'bootstrap finished before the native '+direction+' pager ref exists')
    check(calls.filter(row=>row[0]==='bootstrap').length===1&&calls.filter(row=>row[0]==='list').length===0,'before native mounting there is one bootstrap and no parent-timer list request')
    const utility={getTime:()=>100,getSystemInfoSync:()=>({platform:'ios'}),delay:callback=>scheduled.push(callback)}
    const installed=run(nativeSource,{},{u:utility,c:{delayTime:0},Enum:enumValues,interceptor,setTimeout:callback=>scheduled.push(callback)}).default
    const paging={...installed.methods,auto:automatic,createdReload:false,isOnly:false,finalUseCache:false,finalRefresherEnabled:false,useCustomRefresher:false,showRefresherWhenReload:false,showLoadingMoreWhenReload:false,autoScrollToTopWhenReload:false,layoutOnly:false,usePageScroll:false,autoHeight:false,defaultPageNo:1,defaultPageSize:20,pageNo:1,totalData:[],realTotalData:[],dataPromiseResultMap:{},fetch:null,loading:false,
        $nextTick(callback){return Vue.nextTick(callback?.bind(this))},$emit(event,...args){if(event==='query')this.pending=Promise.resolve(state.leadPagingQuery.value(...args))},
        _startLoading(){this.loading=true},_refresherEnd(){},_cleanRefresherEndTimeout(){},_callMyParentQuery(){},updateFixedLayout(){},_updateCachedSuperContentHeight(){},_updateScrollViewHeight(){},updatePageScrollTopHeight(){},updatePageScrollBottomHeight(){},updateLeftAndRightWidth(){},_onEmit(){},_getCssSafeAreaInsetBottom(){},
        completeByNoMore(rows,noMore){completions.push({rows:[...rows],noMore});this.loading=false;for(const value of Object.values(this.dataPromiseResultMap))value.resolve({totalList:rows,noMore});return Promise.resolve()},complete(){this.loading=false;return Promise.resolve()}}
    state.leadPagingRef.value=Vue.markRaw(paging);installed.mounted.call(paging)
    for(let step=0;step<12;step++){const queue=scheduled.splice(0);for(const work of queue)work.call(paging);await settle()}
    const lists=calls.filter(row=>row[0]==='list')
    console.log(JSON.stringify({scenario:direction,auto:automatic,bootstrap:calls.filter(row=>row[0]==='bootstrap').length,list_requests:lists.length,completed:completions.length}))
    check(lists.length===1,'native delayed '+direction+' mount must issue exactly one first-page request without manual refresh')
    check(lists[0][1].direction===direction&&lists[0][1].page===1,'first native request uses the committed role and page one')
    check(state.ui.rows.value.length===1&&state.leadFirstPageReady.value&&!paging.loading&&completions.length===1,'the initial response is completed into the currently mounted native pager')
}
await scenario('outgoing');await scenario('incoming')
check(!source.includes('setTimeout('),'the fix must use mounted ownership, not a timer that retries the initial list request')
console.log(`PASS ${checks} delayed native lead paging checks; actual Workbench/useCooperation and installed z-paging mounted/reload/query methods, synthetic attachment/API/completion only; no browser/network/database.`)
