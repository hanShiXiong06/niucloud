import fs from 'node:fs'
import path from 'node:path'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
const workspace=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../../../..')
const admin=path.join(workspace,'admin'), require=createRequire(path.join(admin,'package.json'))
const {build}=require('vite'),vue=require('@vitejs/plugin-vue'),autoImport=require('unplugin-auto-import/vite'),components=require('unplugin-vue-components/vite'),{ElementPlusResolver}=require('unplugin-vue-components/resolvers')
const area=path.resolve(workspace,process.env.HSX_LEAD_ADMIN_BUILD_OUTPUT||'output/hsx-lead-acceptance-20261105/admin'),marker=path.join(area,'.hsx-lead-local-build')
if(!area.startsWith(path.join(workspace,'output')+path.sep))throw Error('Build output must remain inside workspace output')
if(fs.existsSync(area)&&!fs.existsSync(marker))throw Error('Refusing an unmarked output directory')
fs.mkdirSync(area,{recursive:true});fs.writeFileSync(marker,'Local build output only; not site business data\n')
process.chdir(admin)
// The framework routes live at /site, /admin and /decorate. /admin is only
// the static asset directory; using it as router base breaks getAppType().
await build({configFile:false,root:admin,envDir:admin,base:'',plugins:[(vue.default||vue)(),(autoImport.default||autoImport)({dts:false,resolvers:[ElementPlusResolver()]}),(components.default||components)({dts:false,resolvers:[ElementPlusResolver()]})],resolve:{alias:{'@':path.join(admin,'src'),assets:path.join(admin,'src/assets'),'vue-i18n':'vue-i18n/dist/vue-i18n.cjs.js'}},build:{outDir:area,emptyOutDir:false,sourcemap:false}})
console.log(JSON.stringify({compiled:true,output:area,installed:false,deployed:false,source:'Current installed admin sources; declaration generation disabled; no publish.cjs'}))
