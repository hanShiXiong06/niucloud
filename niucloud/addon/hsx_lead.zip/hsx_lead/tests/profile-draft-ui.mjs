import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'
import {profileConfigApi} from './profile-config-fixture.mjs'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),drafts=loadMobileUtility('profile-draft')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++},plain=value=>JSON.parse(JSON.stringify(value))
const scope='100005:101:7',now=Date.now(),source={name:'测试门店',mobile:'13900000000',address:'测试街道',province_id:1,storefront_image:'public/storefront.jpg',business_license_token:'DO_NOT_CACHE_PRIVATE_TOKEN',permissions:{admin:true},membership:{level:99},password:'secret',profile_form:{answer:'private'}}
const compact=drafts.createProfileDraft(scope,source,['purchase','purchase','__proto__'],{purchase:[{id:'model-a',title:'型号名不进入草稿',aliases:['many']},{id:'model-a'},{id:2}]},now)
const requestCalls=[],apiModule={exports:{}},apiCode=ts.transpileModule(fs.readFileSync(path.join(plugin,'uni-app/api/cooperation.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext('(function(require,module,exports){'+apiCode+'\n})')(()=>({default:{get:(...args)=>requestCalls.push(args)}}),apiModule,apiModule.exports);apiModule.exports.getCooperationProfileForm()
check(requestCalls.length===1&&requestCalls[0][0]==='hsx_lead/cooperation/profile-form'&&Object.keys(requestCalls[0][1]).length===0&&requestCalls[0][2].showErrorMessage===false,'profile rules adapter sends quiet as request config, never as query parameters or duplicate global toast')
check(compact.version===2&&compact.scope===scope&&compact.expires_at-now===24*60*60*1000,'draft has explicit actor/shop scope, format and one-day expiry')
check(Object.keys(compact.form).sort().join(',')==='address,mobile,name,province_id,storefront_image','only explicit editable basic fields are persisted')
check(!JSON.stringify(compact).includes('PRIVATE')&&!JSON.stringify(compact).includes('secret')&&!JSON.stringify(compact).includes('型号名'),'private document token, arbitrary profile fields and option metadata never enter cache')
check(compact.selectedBusinesses.join(',')==='purchase'&&compact.capabilityIds.purchase.join(',')==='model-a,2','business and choice identifiers are normalized and deduplicated')
check(drafts.readProfileDraft(compact,scope,now)?.form.name==='测试门店','current scoped draft restores')
check(!drafts.readProfileDraft(compact,'100005:102:7',now)&&!drafts.readProfileDraft(compact,'100006:101:7',now)&&!drafts.readProfileDraft(compact,'100005:101:8',now),'draft never crosses user, tenant or merchant')
check(!drafts.readProfileDraft(compact,scope,compact.expires_at)&&!drafts.readProfileDraft({...compact,expires_at:compact.expires_at+1},scope,now),'expired or invalid-lifetime drafts are rejected')
check(!drafts.profileDraftKey(':101:7')&&!drafts.profileDraftKey('100005:0:7')&&!drafts.profileDraftKey('100005:101:NaN')&&!!drafts.profileDraftKey('100005:101:0'),'unknown identities are not persisted under a shared fallback key')
check(!drafts.createProfileDraft(':0:0',source,[],{},now),'no unscoped persistence payload is manufactured')
const legacy=drafts.readLegacyProfileDraft({form:{...source,id:7},selectedBusinesses:['purchase'],capabilityChoices:{purchase:[{id:'legacy-a',title:'旧名称',secret:'PRIVATE'}]}},scope)
check(legacy?.capabilityIds.purchase[0]==='legacy-a'&&!JSON.stringify(legacy).includes('PRIVATE'),'one-time old cache read sanitizes full option objects and private fields')
check(!drafts.readLegacyProfileDraft({form:{id:8,name:'another shop'}},scope),'old cache without matching merchant identity cannot overwrite another shop')
const restored=drafts.restoreProfileChoices(['model-a','removed-id'],[{id:'model-a',title:'实时名称'}])
check(restored[0].title==='实时名称'&&restored[1].id==='removed-id'&&Object.keys(restored[1]).length===1,'current server names are reused and unknown IDs remain removable without inventing metadata')

const file=path.join(plugin,'uni-app/components/cooperation/CoopProfilePanel.vue'),parsed=compiler.parse(fs.readFileSync(file,'utf8'),{filename:file}),script=compiler.compileScript(parsed.descriptor,{id:'profile-draft-ui'})
check(!parsed.errors.length&&!compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'profile-draft-ui',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'actual profile SFC compiles')
const code=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
async function flush(){for(let i=0;i<8;i++){await Promise.resolve();await Vue.nextTick()}}
function create(overrides={},seed=[]){
 const storage=new Map(seed),writes=[],removed=[],timers=new Map(),cleanup=[],events=[],navigation=[];let serial=0,writeFails=false
 const native={getStorageSync:key=>storage.get(key),setStorageSync:(key,value)=>{if(writeFails)throw Error('synthetic storage full');const clone=plain(value);writes.push([key,clone]);storage.set(key,clone)},removeStorageSync:key=>{removed.push(key);storage.delete(key)},navigateTo:input=>navigation.push(input),showToast(){}}
 const module={exports:{}};vm.runInNewContext('(function(require,module,exports){'+code+'\n})',{Date,Math,String,Number,Object,Promise,Map,Set,uni:native,setTimeout:fn=>{timers.set(++serial,fn);return serial},clearTimeout:id=>timers.delete(id)})(key=>{
  if(key==='vue')return{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)}
  if(key.endsWith('.vue'))return{default:{}}
  if(key==='../../api/cooperation')return profileConfigApi
  if(key==='@/utils/common')return{img:value=>value}
  if(key==='../../utils/cooperation-navigation'){
   const navigationModule={exports:{}},navigationCode=ts.transpileModule(fs.readFileSync(path.join(plugin,'uni-app/utils/cooperation-navigation.ts'),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
   vm.runInNewContext('(function(exports){'+navigationCode+'\n})',{uni:native})(navigationModule.exports);return navigationModule.exports
  }
  if(key.startsWith('../../utils/'))return loadMobileUtility(path.basename(key))
  throw Error(key)
 },module,module.exports)
 const props=Vue.reactive({profile:{id:7,site_id:100005,member_id:101,name:'原门店',contact_name:'负责人',mobile:'13900000000',province_id:1,city_id:2,district_id:3,address:'街道地址',business_license_token:'SERVER_PRIVATE_TOKEN',business_capabilities:[]},member:{member_id:101},config:{businesses:[{key:'purchase',name:'二手机',enabled:true,dimension:'model'}]},providers:[],editing:true,onboarding:false,page:true,busy:false,displayOnly:false,section:'all',appearance:{},onboardingInviter:{},...overrides})
 const effect=Vue.effectScope();let state;effect.run(()=>{state=module.exports.default.setup(props,{emit:(...args)=>events.push(args),expose(){}})})
 return{props,state,storage,writes,removed,timers,events,navigation,failWrites:()=>writeFails=true,drain(){const jobs=[...timers.values()];timers.clear();for(const job of jobs)job()},unmount(){cleanup.forEach(fn=>fn());effect.stop()}}
}

const first=create();await flush();check(!first.timers.size&&!first.writes.length,'initial hydration does not create a cache write or a debounce timer')
let metadataReads=0
const options=Array.from({length:5000},(_,i)=>({id:'leaf-'+i,get title(){metadataReads++;return '长分类型号 '.repeat(20)},aliases:Array(10).fill('same')}))
first.state.selectedBusinesses.value=['purchase'];first.state.capabilityChoices.purchase=options;await flush();metadataReads=0
for(let i=0;i<12;i++){first.state.form.address='逐字输入 '+i;await flush()}
check(first.writes.length===0&&first.timers.size===1,'rapid typing and 5000 selections coalesce into one pending write, not synchronous writes per character')
check(metadataReads===0,'typing never traverses option titles or aliases through a deep watcher')
first.drain();check(first.writes.length===1&&!first.timers.size,'one idle debounce performs one persistence write')
const saved=first.writes[0][1]
check(saved.capabilityIds.purchase.length===5000&&!saved.capabilityChoices&&Object.keys(saved.form).every(key=>drafts.PROFILE_DRAFT_FIELDS.includes(key)),'all 5000 selected IDs survive without metadata or arbitrary profile objects')
check(JSON.stringify(saved).length<65000&&metadataReads===0,'large draft is compact and serialization never touches heavy option metadata')
check(!JSON.stringify(saved).includes('SERVER_PRIVATE_TOKEN')&&first.state.form.business_license_token==='SERVER_PRIVATE_TOKEN','private license remains in editing memory only and is not lost from the actual submission')
first.state.form.name='离开前的改动';await flush();first.state.close();check(first.writes.length===2&&first.writes.at(-1)[1].form.name==='离开前的改动'&&!first.timers.size,'explicit return flushes pending edits before closing')
first.state.form.name='卸载前改动';await flush();first.unmount();check(first.writes.length===3&&first.writes.at(-1)[1].form.name==='卸载前改动'&&!first.timers.size,'native page/component disposal flushes the active scope once')

const quota=create();await flush();quota.failWrites();quota.state.form.address='quota edit';await flush();quota.drain();check(quota.state.draftNotice.value.includes('离开前请保存资料')&&!quota.state.localError.value,'storage failure is non-blocking, visible and does not masquerade as a form save failure');quota.unmount()
const cleared=create();await flush();cleared.state.form.name='待清理';await flush();cleared.state.clearDraft();cleared.drain();cleared.unmount();check(!cleared.writes.length&&!cleared.storage.has(drafts.profileDraftKey(scope)),'successful business save/clear cannot be followed by a stale timer resurrecting its draft')

const changed=create();await flush();changed.state.form.name='A账号输入';await flush();changed.state.openModelCatalog('purchase');const selected=changed.navigation.at(-1).events.selected
changed.state.form.address='A旧延迟';await flush();changed.props.profile={id:9,site_id:100006,member_id:102,name:'B账号门店',business_capabilities:[]};changed.props.member={member_id:102};changed.drain();await flush();selected([{id:'A-private-selection'}]);await flush();changed.drain()
check(changed.state.form.name==='B账号门店'&&!changed.state.capabilityChoices.purchase,'late picker callbacks cannot inject previous-user choices into a new account')
check(!changed.writes.some(([key,value])=>key.includes('100006:102')&&(value.form.name==='A账号输入'||value.form.address==='A旧延迟')),'a timer scheduled before an actor change cannot write old input under the new scope')
check(!changed.timers.size,'switching account cancels pending old work and does not autosave hydration');changed.unmount()

const actorDraft=drafts.createProfileDraft(scope,{name:'已缓存门店',address:'草稿地址',business_license_token:'CACHE_PRIVATE'},['purchase'],{purchase:[{id:'model-a'},{id:'model-b'}]})
const reenter=create({profile:{id:7,site_id:100005,member_id:101,name:'后端名称',business_license_token:'REAL_PRIVATE',business_capabilities:[{business_type:'purchase',items:[{id:'model-a',title:'后端型号名称'}]}]}},[[drafts.profileDraftKey(scope),actorDraft]])
await flush();check(reenter.state.form.name==='已缓存门店'&&reenter.state.capabilityChoices.purchase.length===2&&reenter.state.capabilityChoices.purchase[0].title==='后端型号名称','reopening restores compact selected IDs and current known labels')
check(reenter.state.form.business_license_token==='REAL_PRIVATE','cache cannot overwrite the current private document token');reenter.unmount()
const oldCache={form:{...source,id:7},selectedBusinesses:['purchase'],capabilityChoices:{purchase:[{id:'legacy-model',title:'old name'}]}}
const old=create({},[['hsx_lead_profile_draft:100005:101',oldCache]]);await flush();check(old.state.form.name==='测试门店'&&old.state.capabilityChoices.purchase[0].id==='legacy-model','same-actor same-shop legacy edit and selection survive a one-time sanitized read')
check(!old.storage.has('hsx_lead_profile_draft:100005:101')&&old.state.form.business_license_token==='SERVER_PRIVATE_TOKEN','old full-object storage is retired without restoring its certificate token');old.unmount()
const expired=create({},[[drafts.profileDraftKey(scope),{...actorDraft,saved_at:now-2*drafts.PROFILE_DRAFT_TTL,expires_at:now-drafts.PROFILE_DRAFT_TTL}]]);await flush();check(expired.state.form.name==='原门店'&&!expired.storage.has(drafts.profileDraftKey(scope)),'expired local edits are removed instead of overriding current server data');expired.unmount()

const readonly=create({displayOnly:true,editing:false});await flush();readonly.props.profile={id:9,site_id:100005,member_id:101,name:'只读门店'};await flush();readonly.state.form.name='不可保存的隐藏值';await flush();readonly.drain();check(!readonly.writes.length&&!readonly.timers.size,'read-only DIY/identity view never writes profile drafts on account refresh');readonly.unmount()
const unknown=create({profile:{},member:{}});await flush();unknown.state.form.name='未返回身份';await flush();unknown.drain();check(!unknown.writes.length,'missing member/site context never writes a shared anonymous draft');unknown.unmount()
console.log(`PASS ${checks} compact profile draft, privacy, debounce, 5000-option and lifecycle checks; actual Vue setup with fake local storage/timers, no network or business writes.`)
