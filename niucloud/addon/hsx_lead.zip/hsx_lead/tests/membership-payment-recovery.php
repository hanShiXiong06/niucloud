<?php
declare(strict_types=1);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect'] as $name) if (function_exists($name)) exit("Disable external network functions\n");
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';
require __DIR__ . '/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService, PartnerService, EntityMembershipService, PaymentService, PaymentOrderRecovery, Store};
use addon\hsx_lead\app\support\Data;
use addon\hsx_lead\app\listener\pay\{CooperationPaySuccess, CooperationPayCloseGuard, CooperationPayCreate};
use app\service\core\pay\CorePayService;
use app\dict\pay\{OnlinePayDict, PayDict};
use core\exception\CommonException;
use think\facade\{Db, Event};

final class RecoverySyntheticProvider
{
    public array $calls = [];
    public function __construct(private array $answers) {}
    public function getOrder(string $no) { $this->calls[] = 'query:' . $no; $answer = array_shift($this->answers); if ($answer instanceof Throwable) throw $answer; return $answer; }
    public function close(string $no) { $this->calls[] = 'close:' . $no; return true; }
}
$checks = 0; $pdo = null; $schema = ''; $failed = false;
function recoveryCheck(bool $condition, string $label): void { if (!$condition) throw new RuntimeException($label); $GLOBALS['checks']++; }
function recoveryReject(callable $operation, string $label): void { try { $operation(); } catch (CommonException $error) { recoveryCheck(true, $label); return; } throw new RuntimeException('Not rejected: ' . $label); }
try {
    [$app, $pdo, $schema, $site] = leadBoot();
    $ddl = file_get_contents(dirname(__DIR__, 3) . '/app/install/source/database.sql');
    foreach (['pay','pay_refund'] as $table) {
        if (!preg_match('/CREATE TABLE\s+`' . $table . '`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si', $ddl, $match)) throw new RuntimeException('Missing official receipt fixture');
        $pdo->exec(str_replace('CREATE TABLE `' . $table . '`', 'CREATE TABLE `lt_' . $table . '`', $match[0]));
    }
    $config = ConfigService::defaults(); $config['enabled'] = true; $config['fee_confirmed'] = true;
    (new ConfigService(new Context($site, 1)))->save($config);
    Db::name('member_level')->insert(leadMembershipDefinition(701, 1, 2, false, ['deposit_amount'=>'200.00','cycles'=>[['key'=>'year','name'=>'年付','months'=>12,'enabled'=>true,'price'=>'99.00']]]) + ['site_id'=>$site]);
    Event::remove('PaySuccess'); Event::listen('PaySuccess', CooperationPaySuccess::class);
    Event::remove('PayClose'); Event::listen('PayClose', CooperationPayCloseGuard::class);
    Event::remove('PayCreate'); Event::listen('PayCreate', CooperationPayCreate::class);
    $number = 200;
    $new = static function (string $label, $status = null) use ($site, &$number): array {
        $member = ++$number;
        Db::name('member')->insert(['member_id'=>$member,'site_id'=>$site,'nickname'=>'Recovery fixture ' . $member,'mobile'=>sprintf('199%08d', $member)]);
        $ctx = new Context($site, 0, $member);
        $profile = (new PartnerService($ctx))->saveProfile(['name'=>'Recovery ' . $label,'contact_name'=>'Fixture','mobile'=>sprintf('199%08d', $member),'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture address','provider'=>'']);
        $quote = (new EntityMembershipService($ctx))->quote('ML701','year');
        $order = (new PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'year','request_id'=>'recovery-' . $label,'quote_token'=>$quote['quote_token']]);
        $no = 'RECOVERY_' . $member;
        if ($status !== null) Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>$member,'from_main_id'=>$member,'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>$status,'type'=>PayDict::WECHATPAY,'channel'=>'weapp','pay_time'=>$status === PayDict::STATUS_FINISH ? time() : 0]);
        return [$ctx, $order, $no, (int)$profile['id']];
    };
    $resume = static function (Context $ctx, array $order, RecoverySyntheticProvider $provider): array {
        return (new PaymentOrderRecovery($ctx, static fn(int $s, string $c, string $t): object => $provider))->resume((int)$order['id']);
    };
    $status = static fn(string $state): array => ['status'=>$state];
    [$ctx, $order, $no] = $new('never-started'); $provider = new RecoverySyntheticProvider([]);
    $ready = $resume($ctx, $order, $provider);
    recoveryCheck($ready['status'] === 'unpaid' && $ready['can_pay'] && $ready['payment_recovery']['state'] === 'ready' && $provider->calls === [], 'never-started cashier continues the same business order without gateway calls');
    [$ctx, $order, $no] = $new('abandoned', PayDict::STATUS_ING); $provider = new RecoverySyntheticProvider([$status(OnlinePayDict::NOTPAY), $status(OnlinePayDict::CLOSED)]);
    $beforeCount = Store::query('coop_order', $site)->count(); $ready = $resume($ctx, $order, $provider);
    recoveryCheck((int)$ready['id'] === (int)$order['id'] && $ready['status'] === 'unpaid' && $ready['can_pay'] && $ready['payment_recovery']['state'] === 'ready', 'abandoned WeChat cashier becomes payable on the original business order');
    recoveryCheck($provider->calls === ['query:' . $no,'close:' . $no,'query:' . $no], 'continuation requires original NOTPAY, close request and authoritative CLOSED');
    recoveryCheck((int)Db::name('pay')->where('out_trade_no', $no)->value('status') === (int)PayDict::STATUS_CANCEL && Store::query('coop_order', $site)->count() === $beforeCount, 'only the original prepay is cancelled, no replacement membership order is created');
    recoveryCheck((new PaymentService($ctx))->assertPayable((int)$order['id'])['can_pay'], 'existing strict cashier guard accepts the safely recovered order without bypass');
    $repeat = new RecoverySyntheticProvider([]); recoveryCheck($resume($ctx, $order, $repeat)['can_pay'] && !$repeat->calls, 'repeated continuation performs no additional channel cancellation');
    $cashier = (new CorePayService())->checkOrCreate($site, PaymentService::TRADE_TYPE, (int)$order['id']);
    recoveryCheck((int)$cashier['trade_id'] === (int)$order['id'] && (int)$cashier['status'] === (int)PayDict::STATUS_WAIT && $cashier['out_trade_no'] !== $no && (new PaymentService($ctx))->assertPayable((int)$order['id'])['can_pay'], 'actual framework cashier can reopen after proven old-prepay closure, with one business order and no guard bypass');
    foreach ([OnlinePayDict::USERPAYING, 'UNKNOWN', new RuntimeException('Synthetic timeout')] as $index => $answer) {
        [$ctx, $unknown, $no] = $new('uncertain-' . $index, PayDict::STATUS_ING); $provider = new RecoverySyntheticProvider([$answer instanceof Throwable ? $answer : $status($answer)]);
        $kept = $resume($ctx, $unknown, $provider);
        recoveryCheck($kept['status'] === 'unpaid' && !$kept['can_pay'] && $kept['payment_recovery']['state'] === 'uncertain' && $provider->calls === ['query:' . $no], 'unknown, paying and timeout results keep one original order with self-service retry');
        recoveryCheck((int)Db::name('pay')->where('out_trade_no', $no)->value('status') === (int)PayDict::STATUS_ING, 'uncertain channel evidence remains intact');
        recoveryReject(static fn() => (new PaymentService($ctx))->assertPayable((int)$unknown['id']), 'unknown payment still fails the untouched duplicate-charge guard');
    }
    [$ctx, $racing, $no, $merchant] = $new('paid-race', PayDict::STATUS_ING); $provider = new RecoverySyntheticProvider([$status(OnlinePayDict::NOTPAY), $status(OnlinePayDict::SUCCESS)]);
    $paid = $resume($ctx, $racing, $provider);
    recoveryCheck($paid['status'] === 'paid' && EntityMembershipService::state($site, $merchant)['active'], 'a successful payment winning the close race restores the real membership rather than charging again');
    $before = EntityMembershipService::state($site, $merchant); $repeat = new RecoverySyntheticProvider([]);
    recoveryCheck($resume($ctx, $racing, $repeat)['status'] === 'paid' && !$repeat->calls && EntityMembershipService::state($site, $merchant)['expires_at'] === $before['expires_at'], 'repeated paid recovery does not extend membership or query/charge again');
    [$ctx, $localPaid, $no, $merchant] = $new('known-receipt', PayDict::STATUS_FINISH); $provider = new RecoverySyntheticProvider([]);
    recoveryCheck($resume($ctx, $localPaid, $provider)['status'] === 'paid' && !$provider->calls && EntityMembershipService::state($site, $merchant)['active'], 'an already persisted successful receipt restores missing membership without asking the customer to pay again');
    [$ctx, $blockedPaid, $no, $merchant] = $new('blocked-known-receipt', PayDict::STATUS_FINISH);
    Store::query('partner', $site)->where('merchant_id', $merchant)->update(['blocked_at'=>time()]);
    $provider = new RecoverySyntheticProvider([]); $attention = $resume($ctx, $blockedPaid, $provider);
    recoveryCheck($attention['status'] === 'paid' && $attention['requires_manual_review'] && $attention['payment_recovery']['state'] === 'attention' && !$attention['can_pay'], 'a persisted receipt with blocked membership is paid but attention, never reported as delivered rights');
    recoveryCheck(str_contains($attention['payment_recovery']['message'], '未开通权益') && !EntityMembershipService::state($site, $merchant)['active'] && !$provider->calls, 'blocked receipt explains the undelivered entitlement without another channel query or charge');
    $repeat = $resume($ctx, $blockedPaid, new RecoverySyntheticProvider([]));
    recoveryCheck($repeat['payment_recovery']['state'] === 'attention' && $repeat['requires_manual_review'] && !$repeat['can_pay'], 'repeated receipt review retains paid attention rather than a false success');
    [$ctx, $expired, $no] = $new('expired', PayDict::STATUS_ING); $raw = Store::row('coop_order', $site, (int)$expired['id']); $rule = Data::decode($raw['rule_json']); $rule['quoted_at'] = time() - 601;
    Store::query('coop_order', $site)->where('id', $expired['id'])->update(['rule_json'=>Data::json($rule),'create_time'=>time()-601]);
    $provider = new RecoverySyntheticProvider([$status(OnlinePayDict::NOTPAY), $status(OnlinePayDict::CLOSED)]); $closed = $resume($ctx, $expired, $provider);
    recoveryCheck($closed['status'] === 'closed' && !$closed['can_pay'], 'expired quote safely closes only after original channel closure proof');
    recoveryCheck($closed['closed_by'] === 'timeout', 'expired recovery is audited as automatic timeout, not a fabricated customer cancellation');
    $fresh = (new EntityMembershipService($ctx))->quote('ML701','year');
    recoveryCheck($fresh['existing_order_id'] === 0 && $fresh['can_purchase'] && $fresh['quote_token'] !== '', 'confirmed expiration releases a fresh signed quotation without creating a new order or manual intervention');
    [$ctx, $expiredUnknown, $no] = $new('expired-unknown', PayDict::STATUS_ING); $raw = Store::row('coop_order', $site, (int)$expiredUnknown['id']); $rule = Data::decode($raw['rule_json']); $rule['quoted_at'] = time()-601;
    Store::query('coop_order', $site)->where('id', $expiredUnknown['id'])->update(['rule_json'=>Data::json($rule),'create_time'=>time()-601]);
    $provider = new RecoverySyntheticProvider([$status(OnlinePayDict::USERPAYING)]); $kept = $resume($ctx, $expiredUnknown, $provider);
    recoveryCheck($kept['status'] === 'unpaid' && !$kept['can_pay'] && $kept['quote_expired'] && (new EntityMembershipService($ctx))->quote('ML701','year')['existing_order_id'] === (int)$expiredUnknown['id'], 'expired but still uncertain gateway remains one original order; it cannot release a new signed checkout');
    [$owner, $private, $privateNo] = $new('ownership', PayDict::STATUS_ING);
    $provider = new RecoverySyntheticProvider([$status(OnlinePayDict::CLOSED)]);
    recoveryReject(static fn() => $resume($ctx, $private, $provider), 'another member cannot recover the owner payment');
    recoveryCheck($provider->calls === [], 'ownership is verified before transmitting anything to a payment provider');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'original membership payment continuation, paid race, expired quote, unknown/timeout and ownership; random localhost schema and synthetic providers only'], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true; fwrite(STDERR, 'FAIL recovery after ' . $checks . ' checks: ' . get_class($error) . ': ' . $error->getMessage() . ' @ ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally { if ($pdo instanceof PDO && $schema !== '') leadCleanup($pdo, $schema); }
exit($failed ? 1 : 0);
