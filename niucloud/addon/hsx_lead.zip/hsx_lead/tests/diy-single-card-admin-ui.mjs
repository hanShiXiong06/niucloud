import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json')),Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++},read=file=>fs.readFileSync(path.join(plugin,file),'utf8')
function moduleOf(source,deps={},globals={}){const module={exports:{}},code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{String,Number,Object,Array,JSON,...globals})(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:key.endsWith('.png')?{default:'/synthetic-art.png'}:(()=>{throw Error('Unexpected import '+key)})(),module,module.exports);return module.exports}
function setup(file,props,deps={},globals={}){const parsed=compiler.parse(read(file),{filename:file}),script=compiler.compileScript(parsed.descriptor,{id:'single-card'});check(parsed.errors.length===0&&compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'single-card',compilerOptions:{bindingMetadata:script.bindings}}).errors.length===0,file+' parses and compiles');return moduleOf(script.content,deps,globals).default.setup(props,{expose(){},emit:deps.emit||(()=>{})})}
const helpers=moduleOf(read('admin/composables/roleEntry.ts'))
const row=Vue.reactive({componentName:'LeadRoleEntry',role:'stores'}),store=Vue.reactive({editTab:'content',value:[row],get editComponent(){return this.value[0]}}),mounted=[]
const editor=setup('admin/views/diy/components/edit-lead-role-entry.vue',{}, {vue:{...Vue,onMounted:fn=>mounted.push(fn)},'@/stores/modules/diy':{default:()=>store},'../../../composables/roleEntry':helpers})
mounted.forEach(fn=>fn());check(row.title==='找门店'&&row.buttonStyle==='solid'&&row.verify(0).code,'new single card initializes coherent fixed store role and CTA')
row.image='upload/own.png';row.buttonColor='#225588';editor.changeRole('customers');check(row.role==='customers'&&row.title==='找客户'&&row.buttonText==='查看客户'&&row.buttonStyle==='link','switching default role updates still-default labels together with its fixed purpose')
check(row.image==='upload/own.png'&&row.buttonColor==='#225588','switching role does not overwrite custom illustration or colors')
const navigations=[]
const card=setup('uni-app/components/cooperation/CoopRoleEntryCard.vue',Vue.reactive({role:row.role,appearance:row,preview:false}),{
    vue:Vue,'@/app/stores/diy':{default:()=>({mode:''})},'@/utils/common':{img:String},
    '../../utils/cooperation-diy-frame':loadMobileUtility('cooperation-diy-frame'),
    '../../utils/cooperation-diy-style':loadMobileUtility('cooperation-diy-style'),
    '../../utils/bundled-image':loadMobileUtility('bundled-image'),
    '../../utils/interaction-feedback':{interactionFeedback(){}},
},{uni:{navigateTo:value=>navigations.push(value)}})
card.go();check(card.settings.value.title==='找客户'&&navigations[0].url==='/addon/hsx_lead/pages/workbench/index','real runtime displays the changed customer label and navigates to the customer role route')
row.title='我自己的标题';row.subtitle='定制说明';row.buttonText='定制行动';editor.changeRole('stores');check(row.title==='我自己的标题'&&row.subtitle==='定制说明'&&row.buttonText==='定制行动','explicit custom text is preserved instead of replaced when changing role')
editor.changeRole('https://invalid.example');check(row.role==='stores','arbitrary URL cannot be used as a role')
const source={storeTitle:'旧门店标题',customerTitle:'旧客户标题',storeImage:'upload/old-store.png',customerImage:'upload/old-customer.png',titleColor:'#445566',buttonTextColor:'#ffffff',componentStartBgColor:'#fefefe',componentBgUrl:'upload/outer.png',unknown_setting:{retained:true}}
const before=JSON.stringify(source),fallback=helpers.comboRoleFallback(source,'stores')
check(JSON.stringify(source)===before&&fallback.title==='旧门店标题'&&fallback.image==='upload/old-store.png'&&fallback.titleColor==='#445566','old combination fallback is a read-only projection of existing copy, image and style')
check(fallback.componentStartBgColor===''&&fallback.componentEndBgColor===''&&fallback.componentBgUrl===''&&fallback.topRounded===undefined,'combined-card editing does not falsely clone the parent outer background or corners')
check(helpers.comboRoleFallback({},'stores').itemRadius===8&&helpers.comboRoleFallback({},'customers').buttonStyle==='link','fallback controls agree with actual card default geometry and role CTA style')
const nested=Vue.reactive({buttonColor:'#123456'}),emits=[]
const fields=setup('admin/views/diy/components/RoleEntryEditorFields.vue',{modelValue:nested,fallback,section:'all',nested:true},{vue:Vue,emit:(...args)=>emits.push(args)})
fields.patch('componentBgUrl','upload/card-only.png');const override=emits[0][1]
check(Object.keys(override).sort().join(',')==='buttonColor,componentBgUrl'&&override.componentBgUrl==='upload/card-only.png','editing one card emits sparse overrides rather than filling all defaults over old data')
check(nested.componentBgUrl===undefined&&JSON.stringify(source)===before,'reusable editor does not mutate its props or the other card')
const projected=loadMobileUtility('cooperation-role-entry').cooperationRoleAppearance({...source,storesAppearance:override},'stores')
check(projected.image==='upload/old-store.png'&&projected.title==='旧门店标题'&&projected.componentBgUrl==='upload/card-only.png','the actual runtime mapper consumes a single nested override while retaining old copy and illustration')
check(read('admin/views/diy/components/RoleEntryEditorFields.vue').includes("item.key!=='buttonTextColor'||values.buttonStyle==='solid'")&&read('admin/views/diy/components/RoleEntryEditorFields.vue').includes("nested || item.key!=='itemRadius'"),'controls hide irrelevant link text color and independent-card duplicate corner setting')
const heroRow=Vue.reactive({componentName:'LeadCooperationHero'}),heroMounted=[],heroStore={editTab:'content',value:[heroRow],editComponent:heroRow}
setup('admin/views/diy/components/edit-lead-cooperation-hero.vue',{}, {vue:{...Vue,onMounted:fn=>heroMounted.push(fn)},'@/stores/modules/diy':{default:()=>heroStore}});heroMounted.forEach(fn=>fn());check(heroRow.caption&&heroRow.title&&heroRow.verify(0).code,'independent hero uses its own caption/title contract without role or payment data')
console.log(`PASS ${checks} independent role admin checks; actual editors/runtime setup, synthetic navigation only; no database or network writes.`)
