import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.join(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), sass = require('sass')
const { renderToString } = require('@vue/server-renderer')
const { compile } = require('@vue/compiler-dom')
const file = path.join(plugin, 'uni-app/components/cooperation/CoopStorePicker.vue')
const source = fs.readFileSync(file, 'utf8'), parsed = compiler.parse(source, { filename: file })
let checks = 0
const check = (condition, label) => { assert.ok(condition, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
check(!parsed.errors.length, 'real picker SFC parses')
const script = compiler.compileScript(parsed.descriptor, { id: 'internal-picker' })
check(!compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'internal-picker', compilerOptions: { bindingMetadata: script.bindings } }).errors.length, 'real picker template compiles')
const js = ts.transpileModule(script.content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
const own = () => ({ id: 7, name: '本店', is_internal: true, internal_assignees: [{ member_id: 12, name: '李四', role_label: '门店成员' }, { member_id: 13, name: '王五', role_label: '负责人' }] })
const outside = () => ({ id: 8, name: '外部门店', is_internal: false })
async function flush() { for (let i = 0; i < 5; i++) { await Promise.resolve(); await Vue.nextTick() } }
function fixture() {
    const props = Vue.reactive({ show: false, lead: { id: 101,status:'selecting',can_assign:true }, profile: { id: 7 }, config: {}, busy: false })
    const events = [], calls = []
    const control = { work: async () => ({ data: { data: [own(), outside()], total: 2 } }) }
    const deps = {
        vue: { ...Vue, onBeforeUnmount() {} },
        '../../utils/cooperation-navigation': {},
        '../../utils/mobile-ui': loadMobileUtility('mobile-ui'),
        '../../utils/cooperation-business': loadMobileUtility('cooperation-business'),
        '../../api/cooperation': { cooperationStores: (query, id) => { calls.push({ query: structuredClone(query), id }); return control.work(query, id) }, coopError: e => e.message }
    }
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Set, Map, Number, String, Array })(key => {
        if (key in deps) return deps[key]
        if (key.endsWith('.vue')) return { default: {} }
        throw Error(key)
    }, module, module.exports)
    const state = module.exports.default.setup(props, { expose() {}, emit: (...args) => events.push(args) })
    return { props, events, calls, control, state, component: module.exports.default, open: async () => { props.show = true; await flush() } }
}
const h = fixture(); await h.open()
check(h.calls.length === 1 && h.calls[0].id === 101, 'opening the actual lead picker reads matching stores once')
h.state.choose(h.state.rows.value[0])
check(h.state.isInternal.value && h.state.selectedAssigneeId.value === 0 && !h.state.canAssign.value, 'choosing own store never silently assigns its first member')
h.state.confirmAssignment(); check(h.events.length === 0, 'an internal store without an explicit person cannot emit assignment')
h.state.chooseAssignee(999); check(h.state.selectedAssigneeId.value === 0, 'a client-only recipient outside the server roster is ignored')
h.state.chooseAssignee(12)
check(h.state.selectedAssignee.value.name === '李四' && h.state.internalButtonText.value === '交给李四' && h.state.canAssign.value, 'choosing a real recipient identifies the person and enables the single CTA')
h.state.confirmAssignment(); h.state.confirmAssignment()
check(h.events.length === 1 && h.events[0][0] === 'assign' && h.events[0][1].id === 7 && h.events[0][1].assignee_member_id === 12, 'same-tick double click emits one explicit store-plus-person handoff')
await flush(); h.props.busy = true; await flush(); h.state.confirmAssignment(); h.state.choose(h.state.rows.value[1]); h.state.chooseAssignee(13)
check(h.events.length === 1 && h.state.selected.value.id === 7 && h.state.selectedAssigneeId.value === 12, 'parent write busy state freezes both selection and repeated submission')
h.props.busy = false; await flush()
h.state.rows.value[1] = { ...outside(), assignee_member_id: 99 }
h.state.choose(h.state.rows.value[1])
check(!h.state.isInternal.value && h.state.selectedAssigneeId.value === 0 && h.state.canAssign.value, 'switching to an external store clears the internal person')
h.state.confirmAssignment()
check(h.events.length === 2 && h.events[1][1].id === 8 && !Object.hasOwn(h.events[1][1], 'assignee_member_id'), 'external delivery never forwards a stale internal recipient')
await flush(); h.state.choose(h.state.rows.value[0]); h.state.chooseAssignee(13)
h.control.work = async () => ({ data: { data: [{ ...own(), internal_assignees: [] }], total: 2 } })
await h.state.load(true); await flush()
check(h.state.internalAssignees.value.length === 0 && h.state.selectedAssigneeId.value === 0 && !h.state.canAssign.value, 'an appended roster update invalidates a removed selected member immediately')
h.state.confirmAssignment(); check(h.events.length === 2, 'invalidated member cannot be submitted from the previous card snapshot')
h.state.rows.value = [{ ...own(), internal_assignees: [{ member_id: 12, name: '李四' }, { member_id: 12, name: '重复' }, { member_id: -1, name: '无效' }, { member_id: 14, name: '' }] }]
equal(h.state.internalAssignees.value.map(x => x.member_id), [12], 'front-end roster projection rejects invalid IDs, blank names and duplicate accounts')
h.state.chooseAssignee(12); h.props.show = false; await flush()
check(!h.state.selected.value && h.state.selectedAssigneeId.value === 0, 'closing the page clears person and store drafts')

const search = fixture(); await search.open(); search.state.keyword.value = '旧值'
let finishSearch, finishClear
search.control.work = query => new Promise(resolve => { if (query.keyword === '3') finishSearch = resolve; else finishClear = resolve })
const pending = search.state.searchStores('3')
check(search.calls.at(-1).query.keyword === '3' && search.state.keyword.value === '3', 'submitted search value is committed before delayed v-model delivery')
const beforeDuplicate = search.calls.length; search.state.searchStores('3')
check(search.calls.length === beforeDuplicate, 'paired keyboard/button submission of one in-flight query is deduplicated')
const cleared = search.state.clearSearch()
check(search.calls.at(-1).query.keyword === '' && search.state.keyword.value === '', 'clear explicitly submits an empty query instead of the old draft')
finishClear({ data: { data: [outside()], total: 1 } }); await cleared
finishSearch({ data: { data: [{ id: 99, name: '旧条件张3' }], total: 1 } }); await pending; await flush()
equal(search.state.rows.value.map(x => x.id), [8], 'late search results cannot replace a more recent clear result')
search.control.work = async () => { throw Error('Synthetic search failure') }
await search.state.searchStores('3'); check(search.state.error.value && !search.state.loading.value, 'failed search exposes retry state and finishes loading')
search.control.work = async () => ({ data: { data: [outside()], total: 1 } })
const beforeRetry = search.calls.length; await search.state.searchStores('3')
check(search.calls.length === beforeRetry + 1 && !search.state.error.value, 'same-word retry is allowed after the previous request has finished')
search.state.choose(search.state.rows.value[0]); search.props.lead = { id: 202 }; await flush()
check(search.calls.at(-1).id === 202 && !search.state.selected.value, 'changing the lead while open invalidates its old store/person selection')
const css = sass.compileString(parsed.descriptor.styles[0].content).css
check(css.includes('min-height: 58px') && css.includes('min-width: 0'), 'recipient rows have mobile touch height and shrink-safe names')
check((source.match(/<template #footer>/g) || []).length === 1 && source.includes('@click="confirmAssignment"'), 'one footer and one guarded assign handler own the workflow')
check(source.includes('选择接收成员') && source.includes('店内转交不收协作费'), 'person selection and the internal fee rule have explicit user wording')
const preview = fixture(); await preview.open(); preview.state.choose(preview.state.rows.value[0])
const render = new Function('Vue', compile(parsed.descriptor.template.content, { mode: 'function', prefixIdentifiers: true, isCustomElement: tag => ['view', 'text'].includes(tag) }).code)(Vue)
async function renderPicker() {
    const Component = { ...preview.component, setup: () => ({ ...preview.state }), render }
    const app = Vue.createSSRApp({ render: () => Vue.h(Component, preview.props) }); app.config.warnHandler = () => {}
    app.component('CoopTaskSheet', { setup: (_, { slots }) => () => Vue.h('section', {}, [slots.filters?.(), slots.default?.(), Vue.h('footer', {}, slots.footer?.())]) })
    for (const name of ['CoopStoreCard', 'CoopStoreInventory', 'CoopRegionFields', 'CoopState', 'CooperationSearch']) app.component(name, { setup: () => () => null })
    app.component('u-icon', { setup: () => () => Vue.h('i') })
    app.component('u-button', { props: ['text', 'disabled', 'loading'], setup: props => () => Vue.h('button', { disabled: props.disabled || props.loading, 'data-main-action': true }, props.text) })
    return renderToString(app)
}
let html = await renderPicker()
check(html.includes('选择接收成员') && html.includes('李四') && html.includes('王五') && /<button[^>]*disabled[^>]*data-main-action[^>]*>请选择接收成员<\/button>/.test(html), 'actual SSR shows recipient list and a disabled CTA before a person is chosen')
preview.state.chooseAssignee(12); html = await renderPicker()
check(html.includes('交给本店成员：李四') && /<button[^>]*data-main-action[^>]*>交给李四<\/button>/.test(html) && (html.match(/<footer>/g) || []).length === 1, 'actual SSR shows one recipient-specific confirmation footer')
console.log(`PASS ${checks} internal assignment picker checks; real SFC, Vue state and synthetic transports; no live business writes.`)
