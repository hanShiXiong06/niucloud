import fs from 'node:fs'
import path from 'node:path'
import http from 'node:http'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { execFileSync } from 'node:child_process'
import assert from 'node:assert/strict'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'), workspace=path.resolve(plugin,'../../..')
const require=createRequire('/tmp/package.json'), {chromium}=require('playwright')
const build=path.join(workspace,'output/hsx-lead-live-build/h5'), output=path.join(workspace,'output/hsx-lead-phase1-20261105/visual')
fs.mkdirSync(output,{recursive:true})
const php=process.env.PHP_BIN||'php'
const dictionaries=JSON.parse(execFileSync(php,['-r',`require '${path.join(workspace,'niucloud/vendor/autoload.php')}'; echo json_encode(['pages'=>require '${plugin}/app/dict/diy/pages.php','config'=>\\addon\\hsx_lead\\app\\service\\cooperation\\ConfigService::defaults(),'bottom'=>\\addon\\hsx_lead\\app\\listener\\BottomNavigationListener::defaults()]);`],{encoding:'utf8'}))
const config={...dictionaries.config,enabled:true,publishing_required:false,fee_confirmed:true}
const profile={id:7,member_id:101,name:'协作体验门店',contact_name:'体验负责人',mobile:'19900000101',province_id:1,city_id:2,district_id:3,region_text:'河北省 / 石家庄市 / 长安区',business_capabilities:[],manual_models:[],certification_status:'none',connection:{connected:false},blocked_at:0}
const content=dictionaries.pages.DIY_HSX_LEAD_INDEX.hsx_lead_index.data
const requests=[], errors=[], outside=[]
const server=http.createServer((req,res)=>{const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);let relative=pathname.replace(/^\/wap\/(?:100005\/)?/,'').replace(/^\//,'');const resource=relative.startsWith('addon/hsx_lead/diy/'),base=resource?path.join(plugin,'resource'):build;let file=path.resolve(base,resource?relative.slice('addon/hsx_lead/'.length):relative);if(!file.startsWith(base+path.sep))return res.writeHead(403).end();if(!fs.existsSync(file)||fs.statSync(file).isDirectory())file=path.join(build,'index.html');const ext=path.extname(file);res.setHeader('Content-Type',({'.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.html':'text/html'})[ext]||'application/octet-stream');res.end(fs.readFileSync(file))})
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin=`http://127.0.0.1:${server.address().port}`
const chrome=process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
const browser=await chromium.launch({headless:true,...(fs.existsSync(chrome)?{executablePath:chrome}:{})}), context=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:1})
let page
try{
 await context.addInitScript(()=>{for(const key of ['wapToken','site100005.wapToken'])localStorage.setItem(key,'synthetic-browser-session');for(const key of ['wap_site_id','site100005.wap_site_id'])localStorage.setItem(key,JSON.stringify({type:'number',data:100005}))})
 await context.route('**/*',async route=>{
  const req=route.request(),url=new URL(req.url());if(url.origin!==origin){outside.push(url.origin);return route.abort()}
  if(!url.pathname.startsWith('/api/'))return route.continue()
  const key=url.pathname.slice(5);requests.push({method:req.method(),key});let data={}
  if(key==='init') data={tabbar_list:[{key:'hsx_lead',info:{type:'app'},value:dictionaries.bottom}],map_config:{is_open:0,valid_time:0,map_type:'tencent',key:''},theme_list:{app:{theme:{'--primary-color':'#398aff'}}},site_info:{site_id:100005,site_name:'本地合成体验',app:['hsx_lead'],site_addons:[]},member_level:[],login_config:{is_username:1,is_mobile:0,is_auth_register:0,is_force_access_user_info:0,is_bind_mobile:0,agreement_show:0},member_exist:1,app_config:{},copyright:{}}
  else if(key==='diy/diy')data={id:0,site_id:100005,title:'同城商户协作',name:'DIY_HSX_LEAD_INDEX',type:'DIY_HSX_LEAD_INDEX',mode:'diy',value:JSON.stringify(content),share:''}
  else if(key==='member'||key==='member/member')data={member_id:101,nickname:'合成体验会员',mobile:'19900000101',wx_openid:'synthetic'}
  else if(key==='hsx_lead/cooperation/bootstrap')data={profile,config,providers:[],stats:{selecting:0,assigned:0,following:0},wallet:{}}
  else if(key==='hsx_lead/cooperation/catalog') {const type=url.searchParams.get('business_type');const business=config.businesses.find(row=>row.key===type);data=business?.options?.length?business.options:[{id:'fixture_phone',title:'iPhone 17 Pro Max',brand:'苹果',category_name:'手机',path:['手机','苹果','iPhone 17 Pro Max']}]}
  else if(key==='hsx_lead/cooperation/leads')data={data:[],total:0}
  else if(key==='hsx_lead/cooperation/regions')data={data:[{id:3,name:'长安区',level:3,province_id:1,city_id:2,district_id:3,region_text:'河北省 / 石家庄市 / 长安区'}],total:1}
  else if(key==='area/0')data=[{id:1,name:'河北省'}]
  else if(key==='area/1')data=[{id:2,name:'石家庄市'}]
  else if(key==='area/2')data=[{id:3,name:'长安区'}]
  else if(key==='diy/tabbar/list')data=[{key:'hsx_lead',info:{type:'app'},value:dictionaries.bottom}]
  return route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({code:1,msg:'合成测试响应',data})})
 })
 page=await context.newPage();page.setDefaultTimeout(7000);page.on('pageerror',error=>errors.push(error.message))
 await page.goto(origin+'/wap/addon/hsx_lead/pages/index');await page.getByText('把客户交给合适的门店',{exact:true}).waitFor({timeout:15000});await page.screenshot({path:path.join(output,'home-390.png'),fullPage:true})
 await page.locator('.lead-entry-action.is-store').click();await page.waitForURL('**/pages/stores/index');await page.getByText('按客户所在地找交付伙伴',{exact:true}).waitFor({timeout:10000});assert.match(page.url(),/pages\/stores\/index/)
 await page.goBack();await page.getByText('把客户交给合适的门店',{exact:true}).waitFor()
 await page.locator('.lead-entry-business-list').getByText('宽带',{exact:false}).click();await page.getByText('发布客户需求',{exact:true}).waitFor();assert.match(page.url(),/task=publish/)
 const footerAtBottom=await page.evaluate(()=>[...document.querySelectorAll('.coop-sheet.is-page .coop-sheet__footer')].some(el=>{const box=el.getBoundingClientRect();return box.height>0&&Math.abs(box.bottom-window.innerHeight)<3}));assert.ok(footerAtBottom,'closed framework cashier must not consume half the task page; footer stays at viewport bottom')
 await page.screenshot({path:path.join(output,'publish-broadband-390.png'),fullPage:true})
 await page.locator('.region-trigger').click();const search=page.locator('.region-search input');await search.fill('长安区');await page.locator('.region-result').first().waitFor();await page.locator('.region-result').first().click();assert.ok(await page.getByText('河北省 / 石家庄市 / 长安区',{exact:true}).count())
 await page.locator('.coop-search-trigger').click();await page.waitForURL('**/pages/catalog/index');await page.locator('.catalog-model').first().click();await page.locator('.coop-sheet__footer .u-button').filter({hasText:'确认选择（1）'}).click();await page.waitForURL('**/pages/task/index?**');assert.ok(await page.locator('.coop-search-trigger').innerText().then(text=>text.includes('已选 1 项')),'native catalog confirmation returns selected count to the same form')
 await page.setViewportSize({width:320,height:740});await page.screenshot({path:path.join(output,'publish-broadband-320.png'),fullPage:true})
 const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>window.innerWidth+1);assert.equal(overflow,false,'mobile page must not overflow horizontally')
 assert.deepEqual(errors,[],'no JavaScript page errors')
 console.log(JSON.stringify({passed:true,requests:requests.length,blocked_external_requests:outside.length,screenshots:3,viewports:[390,320],output,scope:'built real H5 sources; all APIs synthetic and all non-local requests blocked; not WeChat device acceptance'}))
}catch(error){console.error(JSON.stringify({url:page?.url(),errors,requests,outside,body:await page?.locator('body').innerText().catch(()=>'' )}));if(page)await page.screenshot({path:path.join(output,'failure.png'),fullPage:true});throw error}
finally{await browser.close();await new Promise(resolve=>server.close(resolve))}
