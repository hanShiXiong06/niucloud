<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{PromotionService,PromotionRules};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function pcCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function pcDenied(callable $fn,string $label):void{try{$fn();}catch(CommonException $e){pcCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();$admin=new PromotionService(new Context($site,1));
    $raw=['enabled'=>true,'settlement_days'=>7,'eligibility_months'=>12,'sources'=>[
        'publishing'=>['enabled'=>true,'normal_rate'=>'20.00','provider_rate'=>'30.00','renewal'=>true],
        'certification'=>['enabled'=>true,'normal_rate'=>'40.00','provider_rate'=>'50.00','renewal'=>false],
        'maintenance'=>['enabled'=>true,'normal_rate'=>'8.76','provider_rate'=>'23.45','renewal'=>true],
    ]];
    $json=json_encode($raw,JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT|JSON_THROW_ON_ERROR);
    Db::name('sys_config')->insert(['site_id'=>$site,'config_key'=>PromotionService::CONFIG_KEY,'value'=>$json,'status'=>1,'create_time'=>time(),'update_time'=>time()]);
    $orderId=(int)Db::name('hsx_lead_coop_order')->insertGetId(['site_id'=>$site,'order_no'=>'SYNTHETIC_OLD_PROMOTION_ORDER','purpose'=>'publishing','merchant_id'=>0,'member_id'=>101,'business_key'=>'synthetic-read-only-history','request_id'=>'synthetic-read-only-history','amount'=>'99.00','status'=>'paid','rule_json'=>Data::json(['frozen_legacy_promotion'=>['rate'=>'20.00']])]);
    Db::name('hsx_lead_promotion_reward')->insert(['site_id'=>$site,'coop_order_id'=>$orderId,'source'=>'publishing','payer_member_id'=>101,'provider_member_id'=>102,'base_amount'=>'99.00','rate'=>'20.00','amount'=>'19.80','status'=>'pending','rule_json'=>Data::json(['frozen'=>'unchanged'])]);
    $beforeOrder=Db::name('hsx_lead_coop_order')->where('id',$orderId)->find();$beforeRewards=Db::name('hsx_lead_promotion_reward')->select()->toArray();$beforeAudit=Data::query('audit',$site)->count();
    $read=$admin->adminConfig();
    pcCheck($read['requires_review']===true&&$read['ignored_source_keys']===['publishing','certification'],'admin GET returns usable current rules plus explicit legacy review metadata');
    pcCheck(array_keys($read['sources'])===['membership','maintenance'],'admin read projects exactly the two current income sources');
    pcCheck(!$read['sources']['membership']['enabled']&&$read['sources']['membership']['normal_rate']==='0.00'&&$read['sources']['membership']['provider_rate']==='0.00','retired fee rates never automatically become membership service rates');
    pcCheck($read['sources']['maintenance']['normal_rate']==='8.76'&&$read['sources']['maintenance']['provider_rate']==='23.45','explicit maintenance rates survive unchanged');
    pcCheck($read['settlement_days']===7&&$read['eligibility_months']===12&&$read['enabled']===true,'unrelated valid promotion settings are preserved');
    pcCheck(Db::name('sys_config')->where('site_id',$site)->where('config_key',PromotionService::CONFIG_KEY)->value('value')===$json,'reading does not rewrite even whitespace in the original configuration JSON');
    pcCheck(Data::query('audit',$site)->count()===$beforeAudit,'read projection performs no migration or audit mutation');
    pcCheck(!PromotionService::configuration($site+1)['requires_review'],'another tenant configuration is independent');
    pcDenied(static fn()=>$admin->saveConfig($raw),'saving retired source keys remains forbidden');
    pcDenied(static fn()=>$admin->saveConfig(['sources'=>['other_income'=>[]]]),'unknown write source remains forbidden');
    pcCheck(Db::name('sys_config')->where('site_id',$site)->where('config_key',PromotionService::CONFIG_KEY)->value('value')===$json,'rejected save leaves the original raw evidence intact');
    $next=$read;$next['sources']['membership']=['enabled'=>true,'normal_rate'=>'12.34','provider_rate'=>'56.78','renewal'=>true];
    $saved=$admin->saveConfig($next);$stored=Data::decode(Db::name('sys_config')->where('site_id',$site)->where('config_key',PromotionService::CONFIG_KEY)->value('value'));
    pcCheck(!$saved['requires_review']&&$saved['ignored_source_keys']===[]&&$saved['review_message']==='','explicit confirmed current-source save returns fresh cleared review metadata');
    pcCheck(array_keys($stored['sources'])===['membership','maintenance']&&!array_key_exists('requires_review',$stored),'only the current business rules are persisted, not review metadata or retired sources');
    pcCheck($stored['sources']['membership']['normal_rate']==='12.34'&&$stored['sources']['membership']['provider_rate']==='56.78','new membership rates come only from the explicit submitted current rule');
    pcCheck($stored['sources']['maintenance']['normal_rate']==='8.76'&&$stored['sources']['maintenance']['provider_rate']==='23.45','saving reviewed rules does not change the maintenance rate');
    pcCheck(Db::name('hsx_lead_coop_order')->where('id',$orderId)->find()===$beforeOrder&&Db::name('hsx_lead_promotion_reward')->select()->toArray()===$beforeRewards,'reads and current configuration save do not migrate, delete or reprice historical payment/reward snapshots');
    pcCheck(Db::name('member_account_log')->count()===0,'configuration review never credits, recovers or moves commission');
    $mixed=$raw;$mixed['sources']['membership']=$next['sources']['membership'];Db::name('sys_config')->where('site_id',$site)->where('config_key',PromotionService::CONFIG_KEY)->update(['value'=>Data::json($mixed)]);
    pcCheck($admin->adminConfig()['sources']['membership']===$stored['sources']['membership'],'an explicit current membership source remains authoritative alongside old keys');
    $mixed['sources']['unknown_future_source']=[];Db::name('sys_config')->where('site_id',$site)->where('config_key',PromotionService::CONFIG_KEY)->update(['value'=>Data::json($mixed)]);
    pcDenied(static fn()=>$admin->adminConfig(),'only the two proven retired keys receive read projection; unknown sources still require intervention');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'real promotion configuration GET/save with known retired keys; random isolated localhost schema; no existing data or real payment; no automatic rate migration'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable $e){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
