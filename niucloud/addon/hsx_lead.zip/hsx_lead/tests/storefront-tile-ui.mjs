import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.join(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),dom=require('@vue/compiler-dom'),sass=require('sass'),{renderToString}=require('@vue/server-renderer')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
const file=path.join(plugin,'uni-app/components/cooperation/CoopStorefrontUpload.vue'),descriptor=compiler.parse(fs.readFileSync(file,'utf8'),{filename:file}).descriptor,script=compiler.compileScript(descriptor,{id:'storefront-tile'})
check(!compiler.compileTemplate({source:descriptor.template.content,filename:file,id:'storefront-tile',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'photo tile template compiles')
const css=sass.compileString(descriptor.styles[0].content).css
check(/\.coop-storefront-upload__row\s*\{\s*display:\s*block/.test(css),'field title is a separate row, not a far-left label in a space-between row')
check(/\.coop-storefront-upload__controls\s*\{[^}]*width:\s*112px/.test(css)&&/\.coop-storefront-upload__tile\s*\{[^}]*height:\s*96px/.test(css),'photo is a fixed moderate left-aligned tile instead of a full-width upload slab')
check(/\.coop-storefront-upload__more\s*\{[^}]*width:\s*44px[^}]*height:\s*44px/.test(css),'photo actions have an independent 44 by 44 touch target')
const tree=dom.baseParse(descriptor.template.content)
function nodes(node){return[node,...(node.children||[]).flatMap(nodes)]}
const elements=nodes(tree).filter(node=>node.type===1),classes=node=>node.props.find(prop=>prop.type===6&&prop.name==='class')?.value?.content||''
const more=elements.find(node=>classes(node).split(' ').includes('coop-storefront-upload__more')),preview=elements.find(node=>classes(node).split(' ').includes('coop-storefront-upload__preview'))
check(more.props.some(prop=>prop.type===7&&prop.arg?.content==='tap'&&prop.modifiers.some(modifier=>(modifier.content||modifier)==='stop')&&prop.exp?.content==='openActions'),'more action stops propagation instead of previewing/deleting the photo')
check(preview.props.some(prop=>prop.type===7&&prop.arg?.content==='tap'&&prop.exp?.content==='preview'),'photo tap is preview only')
check(!descriptor.template.content.includes('__remove')&&!descriptor.template.content.includes('<text>更换</text>'),'no independent horizontal change button or destructive X remains')
const installed=fs.readFileSync(path.resolve(plugin,'../../../uni-app/node_modules/uview-plus/components/u-upload/u-upload.vue'),'utf8')
check(installed.includes('methods: {')&&installed.includes('chooseFile() {')&&installed.includes('@tap="chooseFile"'),'installed uview Options API exposes the same public chooseFile used by its own upload slot')
let actionSheet,modal,previewed,uploadWork=async()=>({data:{path:'uploads/new-owned.png'}}),uploads=0,chooseCalls=0
const events=[],cleanups=[],runtime={showActionSheet:value=>{actionSheet=value},showModal:value=>{modal=value},previewImage:value=>{previewed=value}}
const module={exports:{}},js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext('(function(require,module,exports){'+js+'\n})',{Number,String,Promise,uni:runtime})(key=>{
    if(key==='vue')return{...Vue,onBeforeUnmount:callback=>cleanups.push(callback)}
    if(key==='@/utils/common')return{img:value=>'/owned/'+value}
    if(key==='../../api/cooperation')return{coopError:(cause,fallback)=>cause?.message||fallback,uploadCooperationStorefront:async file=>{uploads++;return uploadWork(file)}}
    throw Error(key)
},module,module.exports)
const props=Vue.reactive({modelValue:'uploads/previous.png',disabled:false}),state=module.exports.default.setup(props,{emit:(...args)=>events.push(args),expose(){}})
state.uploader.value={chooseFile:()=>chooseCalls++}
state.preview();check(previewed.current==='/owned/uploads/previous.png'&&!modal&&!actionSheet&&!events.length,'photo preview neither opens actions nor changes an attachment')
state.openActions();check(actionSheet.itemList.join('|')==='更换照片|移除照片','only the compact menu offers replace and remove')
check(!events.length&&chooseCalls===0,'opening or cancelling the action sheet does not mutate the old photo')
actionSheet.success({tapIndex:0});check(chooseCalls===1&&!events.length,'replace invokes the existing uploader without clearing the previous photo')
state.openActions();actionSheet.success({tapIndex:1});check(modal.title==='移除门头照片？'&&!events.length,'remove is still behind the explicit confirmation dialog')
modal.success({confirm:false});check(!events.length&&props.modelValue==='uploads/previous.png','remove cancellation retains the existing photo')
modal.success({confirm:true});check(events.at(-1)?.[0]==='update:modelValue'&&events.at(-1)?.[1]==='','only confirmed removal clears the display reference')
events.length=0;actionSheet=null;props.disabled=true;state.openActions();check(!actionSheet&&chooseCalls===1,'disabled control does not open a file chooser or menu');props.disabled=false
let resolveUpload;uploadWork=()=>new Promise(resolve=>{resolveUpload=resolve});const uploading=state.afterRead({file:{url:'local-image.png',type:'image/png',size:100}})
check(state.uploading.value&&events.at(-1)?.[0]==='pending'&&events.at(-1)?.[1]===true,'in-flight photo upload visibly locks the parent save contract')
const oldPreview=previewed;actionSheet=null;state.openActions();state.preview();await state.afterRead({file:{url:'second.png',type:'image/png',size:100}})
check(!actionSheet&&previewed===oldPreview&&uploads===1,'busy overlay blocks menu, preview and duplicate uploads')
resolveUpload({data:{path:'uploads/server-owned.png'}});await uploading
check(events.at(-2)?.[1]==='uploads/server-owned.png'&&events.at(-1)?.[0]==='pending'&&events.at(-1)?.[1]===false&&!state.uploading.value,'successful upload emits only the actual server reference and releases parent pending')
events.length=0;uploadWork=async()=>{throw Error('合成上传失败')};await state.afterRead({file:{url:'failed.png',type:'image/png',size:100}})
check(state.error.value==='合成上传失败'&&!events.some(event=>event[0]==='update:modelValue')&&events.at(-1)?.[1]===false,'failed replacement retains original image and finally releases pending')
events.length=0;uploadWork=async()=>({data:{path:''}});await state.afterRead({file:{url:'invalid.png',type:'image/png',size:100}})
check(state.error.value.includes('有效门头图片')&&!events.some(event=>event[0]==='update:modelValue'),'invalid upload responses do not replace the photo with a local temporary URL')
events.length=0;const beforeOversize=uploads;await state.afterRead({file:{url:'oversize.png',type:'image/png',size:5242881}})
check(uploads===beforeOversize&&!events.length&&state.error.value.includes('5 MB'),'oversize is rejected without acquiring parent pending')
const render=new Function('Vue',dom.compile(descriptor.template.content,{mode:'function',prefixIdentifiers:true,isCustomElement:tag=>['view','text','image'].includes(tag)}).code)(Vue)
async function html(){const app=Vue.createSSRApp({setup:()=>({...state}),props:['modelValue','disabled'],render},{...props});app.config.warnHandler=()=>{};app.config.globalProperties.img=value=>'/owned/'+value;app.component('u-upload',{props:['customStyle'],setup:(props,{slots})=>()=>Vue.h('div',{style:props.customStyle},slots.default?.())});app.component('u-icon',{props:['name'],setup:props=>()=>Vue.h('i',{'data-icon':props.name})});app.component('u-loading-icon',{setup:()=>()=>Vue.h('i',{'data-loading':'true'})});return renderToString(app)}
state.error.value='';props.modelValue='';let markup=await html();check(markup.includes('添加照片')&&!markup.includes('门头照片操作')&&!markup.includes('预览门头照片'),'empty render is just the clickable add-photo tile')
props.modelValue='uploads/previous.png';markup=await html();check(markup.includes('预览门头照片')&&markup.includes('门头照片操作')&&!markup.includes('移除门头照片'),'saved render has preview and menu, not an exposed destructive action')
state.uploading.value=true;markup=await html();check(markup.includes('coop-storefront-upload__busy')&&markup.includes('上传中')&&markup.includes('disabled'),'saved photo upload uses a visible tile overlay with a disabled menu')
state.uploading.value=false;cleanups.forEach(callback=>callback());actionSheet=null;state.openActions();check(!actionSheet,'an unmounted uploader cannot reopen native photo actions')
console.log(`PASS ${checks} storefront tile layout/action/upload checks; actual SFC/SCSS and installed uview method, synthetic dialogs/uploads only.`)
