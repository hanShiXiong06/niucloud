<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external sender functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{PaymentService,Store};
use addon\hsx_lead\app\support\{AdminKeywordSearch,Data};
use core\exception\CommonException;
use think\facade\Db;

$pdo=null;$schema='';$checks=0;$failed=false;
function phoneCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function phoneIds(array$page):array{return array_map('intval',array_column($page['data'],'id'));}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['pay','pay_refund']as$table){
        if(!preg_match('/CREATE TABLE\s+`'.preg_quote($table,'/').'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match))throw new RuntimeException('Missing official payment fixture DDL');
        $pdo->exec(preg_replace('/CREATE TABLE\s+`'.preg_quote($table,'/').'`/i','CREATE TABLE `lt_'.$table.'`',$match[0],1));
    }
    Db::name('member')->where('member_id',101)->update(['nickname'=>'Current Store Owner','member_no'=>'OWNER-101','mobile'=>'18811110001']);
    Db::name('member')->where('member_id',102)->update(['nickname'=>'Original Payer','member_no'=>'PAYER-102','mobile'=>'+86 188-1111-0002','status'=>0]);
    Db::name('member')->where('member_id',103)->update(['nickname'=>'Foreign Payer','member_no'=>'FOREIGN-103','mobile'=>'18811110003']);
    $shop=(int)Data::query('merchant',$site)->insertGetId(['site_id'=>$site,'member_id'=>101,'name'=>'Order Store','contact_name'=>'Store Contact','mobile'=>'18811110004','status'=>1]);
    $foreignShop=(int)Data::query('merchant',$site+1)->insertGetId(['site_id'=>$site+1,'member_id'=>103,'name'=>'Foreign Store','contact_name'=>'Foreign Contact','mobile'=>'18811110009','status'=>1]);
    $lead=(int)Store::query('collaboration',$site)->insertGetId(['site_id'=>$site,'lead_no'=>'PHONE-LEAD','publisher_id'=>$shop,'receiver_id'=>$shop,'customer_name'=>'Lead Customer','mobile'=>'18811110005','request_id'=>'phone-lead','status'=>'following']);
    $foreignLead=(int)Store::query('collaboration',$site+1)->insertGetId(['site_id'=>$site+1,'lead_no'=>'FOREIGN-LEAD','publisher_id'=>$foreignShop,'receiver_id'=>$foreignShop,'customer_name'=>'Foreign Customer','mobile'=>'18811110008','request_id'=>'foreign-lead','status'=>'following']);
    $make=static function(string$suffix,array$extra=[])use($site,$shop,$lead):int{return(int)Store::query('coop_order',(int)($extra['site_id']??$site))->insertGetId(array_replace([
        'site_id'=>$site,'order_no'=>'PHONE-'.$suffix,'purpose'=>'commission','merchant_id'=>$shop,'member_id'=>102,'lead_id'=>$lead,'request_id'=>'phone-'.$suffix,'business_key'=>'phone-'.$suffix,'amount'=>'50.00','status'=>'closed','create_time'=>time(),'update_time'=>time()],$extra));};
    $a=$make('A');$b=$make('B');$bad=$make('FOREIGN-LINKS',['member_id'=>103,'merchant_id'=>$foreignShop,'lead_id'=>$foreignLead]);
    $foreign=$make('FOREIGN-SITE',['site_id'=>$site+1]);$missing=$make('MISSING',['member_id'=>999999,'merchant_id'=>999999,'lead_id'=>999999]);
    $before=Store::query('coop_order',$site)->order('id')->select()->toArray();$payments=new PaymentService(new Context($site,1));
    foreach(['18811110002','+8618811110002','8618811110002','+86 188-1111-0002','188 1111 0002']as$input){
        $page=$payments->adminOrders(['mobile'=>$input]);phoneCheck($page['total']===2&&phoneIds($page)===[$b,$a],'full original-payer phone and China country-code variants: '.$input);
        $row=$page['data'][0];phoneCheck($row['payer_name']==='Original Payer'&&$row['payer_member_no']==='PAYER-102'&&$row['payer_mobile']==='+86 188-1111-0002','original payer shown even if account is suspended');
        phoneCheck($row['mobile_match_sources']===['payer'],'exact match labels actual payer source');
    }
    phoneCheck($payments->adminOrders(['mobile'=>'18811110001'])['total']===0,'current store owner does not replace historical payer');
    foreach(['payer'=>'18811110003','customer'=>'18811110008','store'=>'18811110009']as$scope=>$phone){
        phoneCheck($payments->adminOrders(['mobile'=>$phone,'mobile_scope'=>$scope])['total']===0,'invalid foreign relation cannot leak across tenants: '.$scope);
        phoneCheck($payments->adminOrders(['mobile'=>$phone,'mobile_scope'=>'all'])['total']===0,'all-source OR retains tenant relation: '.$scope);
    }
    foreach(['customer'=>'18811110005','store'=>'18811110004']as$scope=>$phone){
        $page=$payments->adminOrders(['mobile'=>$phone,'mobile_scope'=>$scope]);phoneCheck($page['total']===2&&$page['data'][0]['mobile_match_sources']===[$scope],'explicit alternate phone source resolves exact linked record: '.$scope);
        phoneCheck($payments->adminOrders(['mobile'=>$phone])['total']===0,'default caller search cannot silently select another phone source');
        phoneCheck($payments->adminOrders(['mobile'=>$phone,'mobile_scope'=>'all'])['total']===2,'all-source search retains exact role match');
    }
    phoneCheck($payments->adminOrders(['mobile'=>'18811110002','status'=>'paid'])['total']===0,'phone OR cannot override payment state');
    phoneCheck($payments->adminOrders(['mobile'=>'18811110002','purpose'=>'membership'])['total']===0,'phone cannot override payment purpose');
    phoneCheck($payments->adminOrders(['mobile'=>'18811110002','keyword'=>'PHONE-A'])['total']===1,'phone composes with existing keyword');
    phoneCheck($payments->adminOrders(['mobile'=>'18811110002','start_time'=>time()+100])['total']===0,'phone retains time range');
    phoneCheck($payments->adminOrders(['mobile'=>'18811110002','payment_type'=>'wechatpay'])['total']===0,'phone retains gateway filter');
    phoneCheck($payments->adminOrders(['mobile'=>'18811110002','refund_status'=>'refunded'])['total']===0,'phone retains refund filter');
    $page=$payments->adminOrders(['mobile'=>'18811110002','page'=>2,'limit'=>1]);phoneCheck($page['total']===2&&phoneIds($page)===[$a],'exact phone paginates in SQL without losing total');
    foreach(['0002','123456','18811110002%','18811110002 OR 1=1','18811110002/','18811110002\n',str_repeat('1',21),['18811110002'],true,1.5]as$invalid){
        try{$payments->adminOrders(['mobile'=>$invalid]);throw new RuntimeException('invalid phone accepted');}catch(CommonException$error){phoneCheck($error->getCode()===400&&str_contains($error->getMessage(),'手机号'),'invalid phone rejected explicitly, never becomes an all-orders query');}
    }
    foreach(['wrong',[],true]as$invalid){try{$payments->adminOrders(['mobile_scope'=>$invalid]);throw new RuntimeException('invalid scope accepted');}catch(CommonException$error){phoneCheck($error->getCode()===400,'invalid source rejected');}}
    $page=$payments->adminOrders(['id'=>$missing]);$row=$page['data'][0];phoneCheck($row['payer_name']===''&&$row['payer_mobile']===''&&$row['payer_member_no']===''&&$row['customer_mobile']===''&&$row['merchant_mobile']==='','missing identities never borrow current owner or fake phone');
    $row=$payments->adminOrders(['id'=>$bad])['data'][0];phoneCheck($row['payer_mobile']===''&&$row['customer_mobile']===''&&$row['merchant_mobile']==='','invalid foreign identity links never appear in result DTO');
    $database=Db::getConfig();$database['connections']['mysql']['trigger_sql']=true;Db::setConfig($database);Db::connect(null,true);
    $readCount=0;Db::listen(static function(string$sql)use(&$readCount):void{if(preg_match('/^SELECT .*FROM `lt_(member|hsx_lead_merchant|hsx_lead_collaboration)`/i',$sql))$readCount++;});
    AdminKeywordSearch::orderContacts([$before[0]],$site);$readCount=0;AdminKeywordSearch::orderContacts(array_fill(0,20,$before[0]),$site);$many=$readCount;
    $readCount=0;AdminKeywordSearch::orderContacts([$before[0]],$site);phoneCheck($readCount===3&&$many===3,'three batched identity queries independent of row count, no payer N+1');
    (new app\service\core\menu\CoreMenuService())->refreshAddonMenu('hsx_lead');
    foreach([['hsx_lead_manage_all_data'],['hsx_lead_cooperation_finance']]as$index=>$rules){
        $uid=11+$index;$role=(int)Db::name('sys_role')->insertGetId(['site_id'=>$site,'role_name'=>'Phone role '.$uid,'rules'=>Data::json($rules),'status'=>1]);
        Db::name('sys_user')->insert(['uid'=>$uid,'username'=>'phone-'.$uid,'status'=>1]);Db::name('sys_user_role')->insert(['uid'=>$uid,'site_id'=>$site,'role_ids'=>Data::json([$role]),'is_admin'=>0,'status'=>1]);
        try{(new PaymentService(new Context($site,$uid)))->adminOrders(['mobile'=>'18811110002']);throw new RuntimeException('missing privilege accepted');}catch(CommonException$error){phoneCheck(true,'both finance and all-data privileges remain required');}
    }
    phoneCheck(Store::query('coop_order',$site)->order('id')->select()->toArray()===$before,'lookup leaves financial states, amounts and snapshots unchanged');leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'Actual PHP8 ORM reads in owned random local schema only; no gateway, notification or existing business writes'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
