<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,PartnerService,Store};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function erpCheck(bool$value,string$label):void{if(!$value)throw new RuntimeException($label);$GLOBALS['checks']++;}
function erpDeny(callable$action,string$label):void{try{$action();}catch(CommonException$error){erpCheck(true,$label);return;}throw new RuntimeException('Expected denial: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $admin=new Context($site,1);$settings=new ConfigService($admin);$member=new Context($site,0,101);$partner=new PartnerService($member);
    erpCheck(ConfigService::erpVisible($site),'existing installations retain visible ERP by default');
    $config=$settings->get();$config['enabled']=true;$settings->save($config);
    $profile=['name'=>'Synthetic ERP policy shop','contact_name'=>'Synthetic owner','mobile'=>'18800000001','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road','provider'=>'wanji'];
    $saved=$partner->saveProfile($profile);$mid=(int)$saved['id'];
    $cid=(int)Data::query('connection',$site)->insertGetId(['site_id'=>$site,'merchant_id'=>$mid,'provider'=>'wanji','enabled'=>1]);
    $connection=Data::row('connection',$site,$cid);$storedPartner=Store::partner($site,$mid);
    $config['erp_visible']=false;$readback=$settings->save($config);
    erpCheck($readback['erp_visible']===false&&!ConfigService::erpVisible($site),'saved switch is persisted and freshly read back');
    erpCheck(ConfigService::publicAccess($site)['erp_visible']===false,'anonymous access policy exposes only visibility, not ERP accounts');
    erpCheck(ConfigService::erpVisible($site+1),'switch is scoped to the current site');
    $boot=$partner->bootstrap();
    erpCheck($boot['providers']===[]&&$boot['config']['erp_visible']===false,'onboarded member gets no login-provider choices');
    erpCheck($boot['profile']['erp_visible']===false&&$boot['profile']['connection']===['connected'=>false],'public profile does not expose a hidden connection');
    erpCheck($boot['profile']['provider_requested']===''&&!$boot['profile']['permissions']['can_manage_erp'],'hidden ERP supplies neither a pending provider nor actionable permission');
    erpCheck($boot['profile']['id']===$mid&&$boot['profile']['is_owner'],'owner and shop collaboration identity remain intact');
    $unbound=(new PartnerService(new Context($site,0,102)))->bootstrap();
    erpCheck($unbound['providers']===[]&&$unbound['needs_onboarding'],'new merchant may onboard without any ERP choice');
    $edited=$partner->saveProfile(array_replace($profile,['name'=>'Edited while ERP hidden','provider'=>'untrusted-old-client-provider']));
    erpCheck($edited['name']==='Edited while ERP hidden','hidden ERP does not block ordinary profile edits');
    erpCheck(Store::partner($site,$mid)['provider_requested']===$storedPartner['provider_requested'],'stale mobile choice cannot switch or erase original provider');
    erpCheck(Data::row('connection',$site,$cid)===$connection,'visibility changes and profile saves do not modify credentials, sync settings or history');
    erpCheck((new PartnerService($admin))->present(Data::row('merchant',$site,$mid),true)['connection']['connection_id']===$cid,'administrator retains the original connection management view');
    erpDeny(fn()=>ConfigService::assertErpVisible($site),'hidden frontend service guard refuses direct entry');
    request()->memberId(101);$controller=new \addon\hsx_lead\app\api\controller\Cooperation($app);
    foreach(['connection','challenge','probe','activate','connectionSettings','sync']as$method)erpDeny(fn()=>$controller->$method(),'direct frontend '.$method.' is blocked before external requests');
    erpDeny(fn()=>$controller->syncInfo(999),'sync detail cannot bypass the visibility switch');
    erpDeny(fn()=>$controller->advanceSync(999),'sync advancement cannot bypass the visibility switch');
    erpDeny(fn()=>$controller->storeInventory($mid),'inventory deep link cannot bypass the visibility switch');
    foreach(['invalid',[],null]as$bad){$invalid=$settings->get();$invalid['erp_visible']=$bad;if($bad===null)continue;erpDeny(fn()=>$settings->save($invalid),'malformed switch rejected');}
    $config=$settings->get();$config['erp_visible']=true;$settings->save($config);
    erpCheck(ConfigService::erpVisible($site)&&count($partner->bootstrap()['providers'])>0,'re-enable restores provider choices without reauthorizing or migrating data');
    erpCheck(Data::row('connection',$site,$cid)===$connection,'re-enable preserves the same connection and automatic-sync state');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'owned random localhost schema; ERP frontend policy, direct API guards, preserved authorization and scheduler state; no remote calls'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL ERP frontend policy: '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine()."\n".$error->getTraceAsString()."\n");}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
