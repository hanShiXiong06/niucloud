<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';require_once dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{PromotionService,PartnerService,ConfigService,PaymentService,EntityMembershipService,PaymentOrderLifecycle,CooperationService,Store};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\PayDict;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function poCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function poDeny(callable $fn,string $label):void{try{$fn();}catch(CommonException $e){poCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();
    foreach(['pay','pay_refund']as$table){$official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$m))throw new RuntimeException('Missing receipt DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$m[0]));}
    $ctx=new Context($site,0,102);$life=new PaymentOrderLifecycle($ctx);$other=new PaymentOrderLifecycle(new Context($site,0,101));$admin=new PaymentOrderLifecycle(new Context($site,1));
    Db::name('member_level')->insert(leadMembershipDefinition(701,1,2,false,['all_models'=>true,'cycles'=>[['key'=>'year','name'=>'年付','months'=>12,'enabled'=>true,'price'=>'99.00']]])+['site_id'=>$site]);
    $settings=ConfigService::defaults();$settings['enabled']=true;$settings['publishing_required']=false;$settings['fee_confirmed']=true;$settings['businesses'][0]['commission_minimum']='50.00';(new ConfigService(new Context($site,1)))->save($settings);
    $profile=['name'=>'Synthetic receiver','contact_name'=>'Fixture','mobile'=>'19900000102','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture address','provider'=>''];
    $receiver=(new PartnerService($ctx))->saveProfile($profile);$publisher=(new PartnerService(new Context($site,0,101)))->saveProfile(array_replace($profile,['name'=>'Synthetic publisher','mobile'=>'19900000101']));
    $new=static function()use($ctx):array{$quote=(new EntityMembershipService($ctx))->quote('ML701','year');return(new PaymentService($ctx))->createOrder(['purpose'=>'membership','level_code'=>'ML701','cycle'=>'year','request_id'=>'order-lifecycle-'.bin2hex(random_bytes(8)),'quote_token'=>$quote['quote_token']]);};
    $receipt=static function(array$order,int$status)use($site):array{$no='SYNTHETIC_'.bin2hex(random_bytes(10));Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'out_trade_no'=>$no,'money'=>$order['amount'],'status'=>$status,'pay_time'=>time()]);return['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$no];};
    $first=$new();poCheck($first['can_close']&&$first['can_pay']&&$first['expires_at']>time(),'new order exposes truthful actions and expiry');
    poCheck($life->orders()['total']===1&&$other->orders()['total']===0,'payer list excludes another member');
    poDeny(fn()=>$other->close((int)$first['id'],['confirm'=>true]),'another payer cannot close order');poDeny(fn()=>$life->close((int)$first['id']),'explicit close confirmation required');
    $closed=$life->close((int)$first['id'],['confirm'=>true]);poCheck($closed['status']==='closed'&&!$closed['can_pay']&&!$closed['can_close']&&$closed['closed_by']==='member','payer may cancel a never-submitted order');
    poCheck($life->close((int)$first['id'],['confirm'=>true])['close_at']===$closed['close_at'],'repeat close returns same original closure');
    $wait=$new();$waitFact=$receipt($wait,(int)PayDict::STATUS_WAIT);$life->close((int)$wait['id'],['confirm'=>true]);
    poCheck((int)Db::name('pay')->where('out_trade_no',$waitFact['out_trade_no'])->value('status')===(int)PayDict::STATUS_CANCEL,'WAIT cashier record closes through framework service');
    $ing=$new();$ingFact=$receipt($ing,(int)PayDict::STATUS_ING);
    poCheck(!(new PaymentService($ctx))->order((int)$ing['id'])['can_close'],'unknown processing payment has no direct close action');
    poCheck($life->close((int)$ing['id'],['confirm'=>true])['close_result']==='uncertain','provider processing state cannot be assumed cancelled');
    poCheck($admin->close((int)$ing['id'],['confirm'=>true,'reason'=>'Manual fixture'],true)['status']==='unpaid','administrator cannot force-close uncertain payment');
    Db::name('pay')->where('out_trade_no',$ingFact['out_trade_no'])->update(['status'=>PayDict::STATUS_CANCEL]);
    poDeny(fn()=>$admin->close((int)$ing['id'],['confirm'=>true],true),'administrator close requires reason');
    $manual=$admin->close((int)$ing['id'],['confirm'=>true,'reason'=>'Synthetic manual cancellation'],true);poCheck($manual['closed_by']==='admin'&&$manual['closure_reason']==='Synthetic manual cancellation','admin reason and actor persisted');
    $timeout=$new();$raw=Store::row('coop_order',$site,(int)$timeout['id']);$rule=Data::decode($raw['rule_json']);$rule['quoted_at']=time()-601;Db::name('hsx_lead_coop_order')->where('id',$timeout['id'])->update(['create_time'=>time()-601,'rule_json'=>Data::json($rule)]);
    poDeny(fn()=>(new PaymentService($ctx))->assertPayable((int)$timeout['id']),'expired membership cannot start new payment');
    $tick=PaymentOrderLifecycle::tick();poCheck($tick['closed']===1&&Store::row('coop_order',$site,(int)$timeout['id'])['status']==='closed','framework scheduler closes overdue safe order');
    poCheck(PaymentOrderLifecycle::tick()['closed']===0,'scheduler is repeat-safe');
    $paid=$new();$paidFact=$receipt($paid,(int)PayDict::STATUS_FINISH);PaymentService::confirm($paidFact);
    poDeny(fn()=>$life->close((int)$paid['id'],['confirm'=>true]),'paid membership cannot be cancelled instead of refunded');
    $p=new CooperationService(new Context($site,0,101));$r=new CooperationService($ctx);$model=$p->catalog()[0];$lead=$p->create(['request_id'=>'lifecycle-real-lead','customer_name'=>'Synthetic customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'consent'=>true,'attachments'=>[]]);
    $p->assign((int)$lead['id'],['merchant_id'=>$receiver['id'],'assignment_version'=>0]);$r->action((int)$lead['id'],['action'=>'accept','assignment_version'=>1]);$r->action((int)$lead['id'],['action'=>'deal','assignment_version'=>1]);
    $payments=new PaymentService($ctx);$co=$payments->createOrder(['purpose'=>'commission','lead_id'=>$lead['id'],'amount'=>'50.00','request_id'=>'lifecycle-commission-one']);
    $life->close((int)$co['id'],['confirm'=>true]);poCheck(Store::row('collaboration',$site,(int)$lead['id'])['status']==='unpaid','cancel payment retains actual deal and commission obligation');
    $replacement=$payments->createOrder(['purpose'=>'commission','lead_id'=>$lead['id'],'amount'=>'50.00','request_id'=>'lifecycle-commission-two']);
    poCheck((int)$replacement['id']!==(int)$co['id']&&$replacement['net_amount']===$co['net_amount']&&$replacement['fee_amount']===$co['fee_amount'],'commission can be recreated at same frozen price after verified closure');
    $late=$receipt($co,(int)PayDict::STATUS_FINISH);PaymentService::confirm($late);PaymentService::confirm($late);
    $lateRow=(new PaymentService($ctx))->order((int)$co['id']);poCheck($lateRow['status']==='closed'&&$lateRow['requires_manual_review']&&str_contains($lateRow['review_message'],'已核实收到款项'),'late commission receipt is retained for manual review without reopening');
    poCheck(Db::name('member_account_log')->where('from_type',PaymentService::INCOME_TYPE)->count()===0,'late old payment never duplicates publisher income');
    poCheck(Store::row('collaboration',$site,(int)$lead['id'])['payment_order_id']==$replacement['id'],'late old payment does not overwrite replacement reference');
    Db::name('hsx_lead_coop_order')->where('id',$replacement['id'])->update(['create_time'=>time()-1201]);$pendingFact=$receipt($replacement,(int)PayDict::STATUS_ING);
    $blocked=PaymentOrderLifecycle::tick();poCheck($blocked['blocked']===1&&Store::row('coop_order',$site,(int)$replacement['id'])['status']==='unpaid','timeout cannot turn provider uncertainty into cancellation');
    poDeny(fn()=>$payments->assertPayable((int)$replacement['id']),'expired commission cannot start new payment');
    poCheck($life->orders(['status'=>'closed'])['total']===5&&$life->orders(['purpose'=>'commission'])['total']===2,'own orders filter state and business type');
    poCheck((new PaymentOrderLifecycle(new Context($site+1,0,103)))->orders()['total']===0,'list is tenant-scoped');
    poDeny(fn()=>(new PaymentOrderLifecycle(new Context($site+1,1)))->close((int)$replacement['id'],['confirm'=>true,'reason'=>'cross-site'],true),'admin cannot cross tenant close');
    poCheck(Db::name('hsx_lead_promotion_reward')->count()===0,'closure and timeout create no fictitious referral commission');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'random localhost schema; real services with synthetic receipts only; no gateway/courier/notices/deployment'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$e){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($e).': '.$e->getMessage().' @ '.basename($e->getFile()).':'.$e->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
