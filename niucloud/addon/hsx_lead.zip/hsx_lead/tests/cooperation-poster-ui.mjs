import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc'), sass = require('sass')
const read = file => fs.readFileSync(path.join(plugin, 'uni-app', file), 'utf8')
let checks = 0
function check(ok, message) { assert.ok(ok, message); checks++ }
function moduleOf(source, deps = {}, globals = {}) {
    const module = { exports: {} }
    const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Object, Array, Boolean, JSON, Promise, console, ...globals })(key => {
        if (key in deps) return deps[key]
        if (key.endsWith('.vue')) return { default: {} }
        throw Error('Unexpected focused test dependency: ' + key)
    }, module, module.exports)
    return module.exports
}
const helpers = moduleOf(read('api/cooperation.ts'), { '@/utils/request': { default: {} } })
const deferred = () => { let resolve, reject; const promise = new Promise((yes, no) => { resolve = yes; reject = no }); return { promise, resolve, reject } }
function fixture() {
    let token = 'synthetic-member-a', site = 100005, createWork = null
    const creates = [], downloads = [], saves = [], previews = [], toasts = [], cleanups = []
    const runtime = {
        getStorageSync: () => site,
        downloadFile: input => downloads.push(input),
        saveImageToPhotosAlbum: input => saves.push(input),
        previewImage: input => previews.push(input),
        showToast: input => toasts.push(input),
    }
    const common = { getToken: () => token, getSiteId: () => site, img: source => /^https?:\/\//i.test(source) ? source : 'https://poster.test/' + source }
    const api = { createCooperationPoster: async scene => { creates.push(scene); return createWork ? createWork(scene) : { data: { url: 'poster-' + creates.length + '.png', scene } } } }
    const hooks = { ...Vue, onBeforeUnmount: fn => cleanups.push(fn) }
    const controller = moduleOf(read('composables/useCooperationPoster.ts'), { vue: hooks, '@/utils/common': common, '../api/poster': api, '../api/cooperation': helpers }, { uni: runtime })
    return { state: controller.useCooperationPoster(), creates, downloads, saves, previews, toasts, cleanups, controller, hooks,
        set token(value) { token = value }, set site(value) { site = value }, set createWork(value) { createWork = value } }
}
async function ready(f, scene = 'promotion') { await f.state.generate(scene); f.state.loaded(f.state.url.value) }
async function tick() { await Promise.resolve(); await Promise.resolve(); await Vue.nextTick() }

// Execute the transport module: only the scene may cross the public boundary.
const transportCalls = [], transport = moduleOf(read('api/poster.ts'), { '@/utils/request': { default: { post: (...args) => transportCalls.push(args) } } })
transport.createCooperationPoster('entity')
check(transportCalls[0][0] === 'hsx_lead/cooperation/poster', 'poster uses its authenticated plugin route')
check(JSON.stringify(transportCalls[0][1]) === '{"scene":"entity"}', 'poster request cannot supply another member, subject code, URL or merchant')
check(transportCalls[0][2].showErrorMessage === false, 'inline retry owns the error presentation')

let f = fixture(), s = f.state, pending = deferred()
f.createWork = () => pending.promise
const first = s.generate('promotion')
check(s.loading.value && !s.ready.value && s.url.value === '', 'generation immediately presents visible loading rather than a stale image')
await s.generate('promotion')
check(f.creates.length === 1, 'repeated tap cannot duplicate a request while generating')
pending.resolve({ data: { scene: 'promotion', url: 'one.png' } }); await first
check(s.url.value === 'https://poster.test/one.png' && s.loading.value && !s.ready.value, 'API completion waits for the actual image load before enabling save')
await s.save(); s.preview()
check(!f.downloads.length && !f.previews.length, 'not-yet-loaded image cannot be saved or previewed')
s.loaded('https://poster.test/other.png')
check(s.loading.value && !s.ready.value, 'late unrelated image event cannot complete this preview')
s.loaded(s.url.value)
check(s.ready.value && !s.loading.value && !s.error.value, 'actual matching image load enables the final action')
s.preview(); check(f.previews.length === 1 && f.previews[0].urls[0] === s.url.value, 'preview uses only the actual generated image')

f = fixture(); s = f.state; await ready(f, 'promotion')
const previousPoster = s.url.value
s.close(); await ready(f, 'promotion')
check(f.creates.length === 2 && f.creates.every(scene => scene === 'promotion') && s.url.value !== previousPoster, 'reopening the same scene requests the server again instead of retaining a local template/image cache')

f = fixture(); s = f.state; f.createWork = async () => { throw { msg: '小程序码尚未配置，请联系平台' } }
await s.generate('entity')
check(!s.loading.value && !s.ready.value && s.error.value.includes('尚未配置'), 'provider/configuration error is explicit and does not close the preview')
f.createWork = null; await ready(f, 'entity')
check(s.ready.value && !s.error.value && f.creates.length === 2, 'explicit retry uses the same scene and clears old failure')
s.imageFailed(s.url.value)
check(!s.ready.value && !s.url.value && s.error.value.includes('图片未加载'), 'image load error is retryable, not presented as a ready poster')
await ready(f, 'entity'); check(s.ready.value && !s.error.value, 'image failure can recover without reentering the page')
f.createWork = async () => ({ data: { scene: 'promotion', url: 'other.png' } }); await s.generate('entity')
check(!s.ready.value && s.error.value.includes('未完整返回'), 'cross-scene response is rejected')
f.createWork = async () => ({ data: { scene: 'entity', url: '' } }); await s.generate('entity')
check(!s.ready.value && s.error.value.includes('未完整返回'), 'empty server image is not a successful poster')
for (const reason of ['close', 'unmount', 'account', 'site']) {
    f = fixture(); s = f.state; pending = deferred(); f.createWork = () => pending.promise
    const work = s.generate('entity')
    if (reason === 'close') s.close()
    if (reason === 'unmount') f.cleanups.forEach(fn => fn())
    if (reason === 'account') f.token = 'synthetic-member-b'
    if (reason === 'site') f.site = 100006
    pending.resolve({ data: { scene: 'entity', url: 'private-old.png' } }); await work
    check(!s.url.value && !s.loading.value && !s.ready.value, reason + ' invalidates a late old-identity/old-page response')
}
f = fixture(); s = f.state; f.token = ''; await s.generate('entity')
check(!f.creates.length && s.error.value.includes('登录'), 'anonymous user does not call generation')
f = fixture(); s = f.state; f.cleanups.forEach(fn => fn()); await s.generate('promotion')
check(!f.creates.length, 'unmounted controller cannot restart generation')

// Real callback contracts, no real download or album mutation.
f = fixture(); s = f.state; await ready(f)
let saveWork = s.save(); await s.save()
check(s.saving.value && f.downloads.length === 1, 'save is busy and single-flight across download and album write')
f.downloads[0].success({ statusCode: 200, tempFilePath: '/synthetic/poster.png' }); await tick()
check(f.saves.length === 1 && !f.toasts.length, 'successful download alone never claims album success')
f.saves[0].success({}); await saveWork
check(!s.saving.value && f.toasts.length === 1 && f.toasts[0].title.includes('已保存到相册'), 'only actual album success emits success feedback')

for (const failure of [{ statusCode: 404, tempFilePath: '/synthetic/error.png' }, { statusCode: 500, tempFilePath: '/synthetic/error.png' }, { tempFilePath: '/synthetic/unknown-status.png' }, { statusCode: '200', tempFilePath: '/synthetic/not-a-status.png' }, { statusCode: 200, tempFilePath: '' }]) {
    f = fixture(); s = f.state; await ready(f); saveWork = s.save(); f.downloads[0].success(failure); await saveWork
    check(!f.saves.length && !f.toasts.length && !s.saving.value && s.saveError.value.includes('下载未完成'), 'invalid download never reaches the photo album: ' + JSON.stringify(failure))
}
for (const [error, expected, settings] of [
    [{ errMsg: 'saveImageToPhotosAlbum:fail auth deny' }, '相册权限', true],
    [{ errMsg: 'saveImageToPhotosAlbum:fail:auth denied' }, '相册权限', true],
    [{ errMsg: 'saveImageToPhotosAlbum:fail cancel' }, '取消保存', false],
    [{ errno: 104, errMsg: 'saveImageToPhotosAlbum:fail privacy permission' }, '隐私授权', false],
]) {
    f = fixture(); s = f.state; await ready(f); saveWork = s.save(); f.downloads[0].success({ statusCode: 200, tempFilePath: '/synthetic/poster.png' }); await tick(); f.saves[0].fail(error); await saveWork
    check(!s.saving.value && !f.toasts.length && s.saveError.value.includes(expected) && s.needsSettings.value === settings, 'album failure has actionable feedback without false success: ' + error.errMsg)
}
f = fixture(); s = f.state; await ready(f); saveWork = s.save(); s.close(); f.downloads[0].success({ statusCode: 200, tempFilePath: '/synthetic/poster.png' }); await saveWork
check(!f.saves.length && !f.toasts.length, 'closing while downloading cannot later open an album write')
f = fixture(); s = f.state; await ready(f); saveWork = s.save(); f.downloads[0].success({ statusCode: 200, tempFilePath: '/synthetic/poster.png' }); await tick(); f.token = 'synthetic-member-b'; f.saves[0].success({}); await saveWork
check(!f.toasts.length, 'late album completion after login change cannot show success in another identity')
f = fixture(); s = f.state; await ready(f); s.preview(); const oldPreview = f.previews[0]; s.close(); await ready(f); oldPreview.fail({})
check(!s.saveError.value, 'late old-preview failure cannot poison a new session')

// Parse the framework's actual helper, not a recreated scene parser.
const commonPath = path.resolve(plugin, '../../../uni-app/src/utils/common.ts')
const commonSource = fs.readFileSync(commonPath, 'utf8'), ast = ts.createSourceFile(commonPath, commonSource, ts.ScriptTarget.Latest, true)
const sceneNode = ast.statements.find(node => ts.isFunctionDeclaration(node) && node.name?.text === 'handleOnloadParams')
assert.ok(sceneNode, 'framework scene helper must exist')
const storage = [], framework = moduleOf(sceneNode.getText(ast), {}, { uni: { setStorageSync: (...args) => storage.push(args) } })
const invite = moduleOf(read('utils/cooperation-invite.ts'), { '@/utils/common': framework })
let options = invite.cooperationInviteParams({ scene: encodeURIComponent('subject_code-ABCD234567') })
check(options.subject_code === 'ABCD234567' && !options.mid && !options.promotion_invite, 'subject poster scan never becomes a promotion invitation')
options = invite.cooperationInviteParams({ scene: encodeURIComponent('mid-12&pi-1') })
check(options.mid === '12' && options.promotion_invite === 1 && storage.some(row => row[0] === 'pid' && row[1] === '12'), 'compact promotion scan preserves the actual framework mid contract')
options = invite.cooperationInviteParams({ mid: 12, promotion_invite: 1 })
check(options.mid === 12 && options.promotion_invite === 1, 'ordinary native-share query still works')
check(Object.keys(invite.cooperationInviteParams({ scene: '%E0%A4%A' })).length === 0, 'malformed scene cannot crash the page')
check(Object.keys(invite.cooperationInviteParams(null)).length === 0 && Object.keys(invite.cooperationInviteParams([])).length === 0, 'invalid options fail closed')

const posterFile = 'components/cooperation/CoopInvitePoster.vue', posterSource = read(posterFile)
const descriptor = compiler.parse(posterSource, { filename: posterFile }).descriptor, script = compiler.compileScript(descriptor, { id: 'poster-focused' })
check(!compiler.compileTemplate({ source: descriptor.template.content, filename: posterFile, id: 'poster-focused', compilerOptions: { bindingMetadata: script.bindings } }).errors.length, 'poster real Vue template compiles')
for (const style of descriptor.styles) {
    check(style.scoped, 'poster owns its styles without affecting other framework popups')
    const css = style.lang === 'scss' ? sass.compileString(style.content).css : style.content
    check(!compiler.compileStyle({ source: css, filename: posterFile, id: 'poster-focused', scoped: true }).errors.length, 'poster real SCSS compiles')
}
check(posterSource.includes('v-if="state.loading.value"') && posterSource.includes('正在生成邀请海报'), 'loading animation and text remain rendered until image-ready')
check(posterSource.includes('@load="imageLoaded"') && posterSource.includes(':data-source="state.url.value"'), 'image completion is bound to its actual node source')
check(posterSource.includes('<!-- #ifdef H5 -->') && posterSource.includes('查看海报，长按保存') && posterSource.includes('<!-- #ifndef H5 -->'), 'H5 uses preview/long-press while native platform uses its album API')
check(posterSource.includes('open-type="openSetting"') && posterSource.includes('重新生成') && posterSource.includes('@close="close"'), 'permission, retry and close exits exist without forcing page navigation')
check(/^\s*<view class="coop-poster-mount"><u-popup/.test(descriptor.template.content),'a closed popup is isolated from sibling task-page flex sizing without unmounting its transition')
check(/\.coop-poster-mount\s*\{[^}]*flex:\s*none;[^}]*height:\s*0;[^}]*min-height:\s*0;/.test(posterSource),'poster mount cannot claim the hidden u-popup root flex share')
check(posterSource.includes('100dvh - 32px - env(safe-area-inset-top) - env(safe-area-inset-bottom)')&&/\.coop-poster__preview\s*\{\s*min-height:\s*0;/.test(posterSource),'short H5 viewport constrains the poster and allows preview to shrink before controls are clipped')
f = fixture(); s = f.state
const Poster = moduleOf(script.content, { vue: f.hooks, '../../composables/useCooperationPoster': { useCooperationPoster: () => s }, '../../utils/mobile-ui': { cooperationButtonStyle: {} } }).default
const props = Vue.reactive({ show: false, scene: 'entity', allowed: true }), emitted = []
const panel = Poster.setup(props, { emit: (...args) => emitted.push(args), expose() {} })
check(!f.creates.length, 'closed reusable popup does not preload a private poster')
props.show = true; await tick()
check(f.creates.length === 1 && s.loading.value, 'opening the actual component starts exactly one scene request')
panel.imageLoaded({ currentTarget: { dataset: { source: 'https://poster.test/old.png' } } })
check(!s.ready.value, 'actual source-bound image callback rejects an old node event')
panel.imageLoaded({ currentTarget: { dataset: { source: s.url.value } } })
check(s.ready.value, 'actual image event enables the corresponding component preview')
props.allowed = false; await tick()
check(!s.url.value && !s.ready.value && !s.loading.value, 'revoked owner/invitation permission removes the visible private poster immediately')
props.allowed = true; await tick(); panel.close()
check(!s.url.value && emitted.at(-1)?.[0] === 'close', 'both reusable close exits clear state and delegate closure to their caller')
props.show = false; await tick(); const beforeReopen = f.creates.length
props.show = true; await tick()
check(f.creates.length === beforeReopen + 1 && !s.ready.value, 'actual popup reopen regenerates its scene and waits for the returned image rather than reusing the previously loaded poster')
const promotion = read('components/cooperation/CoopPromotionPanel.vue'), entity = read('pages/entity/index.vue'), profile = read('pages/profile/index.vue')
check(promotion.includes('scene="promotion"') && promotion.includes('open-type="share"'), 'promotion keeps native sharing and independently adds a poster')
check(entity.includes('scene="entity"') && entity.includes('team.is_owner === true') && entity.includes('申请加入这家门店'), 'entity poster is owner-only and the invitee must explicitly apply')
check(entity.includes('cooperationInviteParams(raw)') && profile.includes('cooperationInviteParams(raw)'), 'both actual landing pages consume the framework scene decoder')

console.log(JSON.stringify({ passed: true, checks, scope: 'Actual plugin transport, Vue controller/compiler and framework scene helper with synthetic callbacks; no live APIs, downloads, album writes or sharing' }))
