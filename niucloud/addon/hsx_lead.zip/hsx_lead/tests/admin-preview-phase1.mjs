import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import { execFileSync } from 'node:child_process'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'

// Local visual fixture only: actual plugin components, framework CSS and PHP
// defaults. No app request module, tenant token, backend proxy or publishing.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const workspace=path.resolve(plugin,'../../..'),admin=path.join(workspace,'admin')
const require=createRequire(path.join(admin,'package.json'))
const {createServer}=require('vite'),vue=require('@vitejs/plugin-vue').default
const {chromium}=createRequire('/tmp/package.json')('playwright')
const output=path.join(workspace,'output/hsx-lead-phase1-20261105/visual')
fs.mkdirSync(output,{recursive:true})
const php=`require ${JSON.stringify(path.join(plugin,'app/service/cooperation/BusinessService.php'))};require ${JSON.stringify(path.join(plugin,'app/service/cooperation/ConfigService.php'))};echo json_encode(\\addon\\hsx_lead\\app\\service\\cooperation\\ConfigService::defaults(),JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR);`
const config=JSON.parse(execFileSync(process.env.PHP_BIN||'php',['-d','display_errors=stderr','-d','error_reporting=0','-r',php],{encoding:'utf8'}))
assert.equal(config.businesses.find(row=>row.key==='broadband').commission_minimum,'200.00')
const importFile=relative=>JSON.stringify('/@fs/'+path.join(plugin,relative))
const entry=`
import {createApp,h,reactive} from 'vue'
import ElementPlus,{ElForm} from 'element-plus'
import 'element-plus/dist/index.css'
import ${importFile('../hsx_components/admin/styles/theme.scss')}
import ${importFile('admin/views/components/lead.css')}
import ${importFile('admin/views/cooperation/cooperation.css')}
import BusinessSettings from ${importFile('admin/views/cooperation/BusinessSettings.vue')}
import BusinessCapabilities from ${importFile('admin/views/components/BusinessCapabilities.vue')}
import {normalizeBusinesses} from ${importFile('admin/composables/business.ts')}
const state=reactive({config:${JSON.stringify(config)},businesses:[],capabilities:[],feeChanges:0})
state.businesses=normalizeBusinesses(state.config.businesses)
const capabilityDefinition={...state.businesses.find(row=>row.key==='broadband'),selection_mode:'single',selection_limit:1}
window.__hsxAdminPhase1={snapshot:()=>JSON.parse(JSON.stringify(state))}
createApp({render(){return h('main',{class:'lead-workbench coop-space preview-shell'},[
    h('header',{class:'coop-head'},[h('div',[h('h2','业务配置'),h('p','本地合成默认配置预览 · 无后端、无保存动作')])]),
    h(ElForm,{labelPosition:'top',class:'coop-form'},()=>h(BusinessSettings,{modelValue:state.businesses,canEditCatalog:false,onFeeChange:()=>state.feeChanges++})),
    h('section',{class:'coop-surface preview-capabilities'},[h('h2','商户能力验收'),h('p','本业务客户需求配置为单选1项，商户能力仍可同时选择三个运营商。'),h(ElForm,{labelPosition:'top'},()=>h(BusinessCapabilities,{modelValue:state.capabilities,definitions:[capabilityDefinition],'onUpdate:modelValue':value=>state.capabilities=value}))])
])}}).use(ElementPlus).mount('#app')
`
const virtual='virtual:hsx-admin-phase1',resolved='\0'+virtual
const fixturePlugin={
    name:'hsx-admin-phase1-fixture',
    resolveId:id=>id===virtual?resolved:null,
    load:id=>id===resolved?entry:null,
    configureServer(server){
        server.middlewares.use((req,res,next)=>{
            if(req.url!=='/')return next()
            res.setHeader('Content-Type','text/html;charset=utf-8')
            res.end('<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>客资协作后台本地验收</title><style>body{margin:0;background:#f4f6f8;font-family:Arial,"PingFang SC",sans-serif}.preview-shell{box-sizing:border-box;max-width:1240px;margin:0 auto;padding:24px}.preview-shell>.coop-head{margin-bottom:18px}.preview-capabilities{margin:24px 0}.preview-capabilities h2{font-size:16px}.preview-capabilities>p{font-size:13px;color:#606266;line-height:1.7}</style></head><body><div id="app"></div><script type="module" src="/@vite/client"></script><script type="module" src="/@id/'+virtual+'"></script></body></html>')
        })
    }
}
const server=await createServer({configFile:false,root:admin,plugins:[fixturePlugin,vue()],css:{postcss:{plugins:[]}},resolve:{dedupe:['vue'],alias:{vue:path.join(admin,'node_modules/vue/dist/vue.runtime.esm-bundler.js')}},optimizeDeps:{entries:[],include:['vue','element-plus']},server:{host:'127.0.0.1',port:0,strictPort:true,hmr:false,fs:{allow:[workspace]}}})
let browser
const errors=[],blocked=[],checks=[]
try{
    await server.listen()
    const address=server.httpServer.address(),origin=`http://127.0.0.1:${address.port}`
    browser=await chromium.launch({headless:true,executablePath:process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disable-component-update','--no-first-run']})
    const context=await browser.newContext({viewport:{width:1280,height:720},deviceScaleFactor:1,reducedMotion:'reduce'})
    await context.route('**/*',route=>{const url=route.request().url();if(url.startsWith(origin+'/')||url.startsWith('data:'))return route.continue();blocked.push(url);return route.abort('blockedbyclient')})
    const page=await context.newPage()
    page.on('pageerror',error=>errors.push(error.message))
    await page.goto(origin,{waitUntil:'networkidle',timeout:60000})
    await page.getByRole('tab',{name:'宽带',exact:true}).click()
    await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))))
    const pane=page.locator('#pane-broadband')
    assert.equal(Number(await pane.getByRole('spinbutton').nth(1).inputValue()),200);checks.push('宽带最低协作费用来自实际PHP默认值200.00')
    assert.equal(await pane.getByRole('radio',{name:'多选',exact:true}).isChecked(),true);assert.equal(Number(await pane.getByRole('spinbutton').nth(0).inputValue()),0);checks.push('宽带客户默认需求为多选，数量上限0')
    await page.screenshot({path:path.join(output,'admin-business-1280.png'),fullPage:false})
    await pane.getByRole('button',{name:/补充表单字段/}).click()
    await pane.getByRole('button',{name:'添加补充字段',exact:true}).click()
    await pane.getByPlaceholder('例如：期望月租').fill('安装带宽')
    await pane.getByPlaceholder('例如 monthly_rent').fill('speed')
    await pane.locator('.business-field .el-select').click()
    await page.getByRole('option',{name:'下拉选择',exact:true}).click()
    await pane.getByRole('button',{name:'添加下拉选项',exact:true}).click()
    await pane.getByPlaceholder('选项值（保持稳定）').fill('100m')
    await pane.getByPlaceholder('选项显示名称').fill('100M')
    await pane.getByRole('spinbutton').nth(1).fill('225')
    await pane.getByRole('spinbutton').nth(1).press('Tab')
    const edited=await page.evaluate(()=>window.__hsxAdminPhase1.snapshot())
    assert.equal(edited.businesses.find(row=>row.key==='broadband').fields[0].options[0].label,'100M')
    assert.equal(edited.businesses.find(row=>row.key==='broadband').commission_minimum,225)
    assert.ok(edited.feeChanges>0);checks.push('实际ElementPlus字段可展开、新增、改下拉选项并编辑费用')
    const overflow=await page.evaluate(()=>({viewport:innerWidth,document:document.documentElement.scrollWidth,body:document.body.scrollWidth,surface:[...document.querySelectorAll('.coop-surface')].map(node=>({client:node.clientWidth,scroll:node.scrollWidth}))}))
    assert.ok(overflow.document<=1280&&overflow.body<=1280&&overflow.surface.every(row=>row.scroll<=row.client+1));checks.push('1280x720无文档或业务面板横向溢出')
    await pane.locator('.business-field').scrollIntoViewIfNeeded()
    await page.screenshot({path:path.join(output,'admin-business-fields-1280.png'),fullPage:false})
    const capability=page.locator('.business-capabilities')
    await capability.getByRole('button',{name:/宽带 · 已选0项/}).click()
    await capability.locator('.el-select').click()
    for(const name of ['移动','联通','电信'])await page.getByRole('option').filter({hasText:name}).click()
    await page.keyboard.press('Escape')
    await page.locator('.preview-capabilities > h2').click()
    await page.locator('.el-select-dropdown:visible').waitFor({state:'hidden'})
    const selected=await page.evaluate(()=>window.__hsxAdminPhase1.snapshot().capabilities)
    assert.equal(selected[0].option_ids.length,3);checks.push('真实商户能力组件在客户单选1项配置下仍可同时选移动联通电信')
    await capability.scrollIntoViewIfNeeded()
    await page.screenshot({path:path.join(output,'admin-capabilities-1280.png'),fullPage:false})
    assert.deepEqual(errors,[])
    fs.writeFileSync(path.join(output,'admin-business-report.json'),JSON.stringify({viewport:{width:1280,height:720},checks,overflow,blockedRequests:blocked,consoleErrors:errors,scope:'Real admin SFCs + actual PHP defaults + synthetic local reactive state only; no backend or publishing'},null,2))
    console.log(JSON.stringify({passed:true,checks,overflow,blockedRequests:blocked,screenshot:path.join(output,'admin-business-1280.png')}))
}finally{await browser?.close();await server.close()}
