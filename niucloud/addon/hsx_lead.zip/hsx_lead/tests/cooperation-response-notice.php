<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external transports\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\{Context,FrameworkNoticeGateway};
use addon\hsx_lead\app\service\notice\{AccountNoticePolicyService,FinancialNoticeService,NoticeTaskRuntime,NoticeEventCatalog,CooperationResponseNotices};
use addon\hsx_lead\app\service\cooperation\{ConfigService,CooperationService,CooperationNoticeOutbox,PartnerService,Store};
use addon\hsx_lead\app\listener\notice\AccountNoticeData;
use addon\hsx_lead\app\support\Data;
use think\facade\{Db,Event,Cache};
$checks=0;$pdo=null;$schema='';$failed=false;
function responseCheck(bool $value,string $label):void{if(!$value)throw new RuntimeException('Assertion failed: '.$label);$GLOBALS['checks']++;}
function responseDeny(callable $action,string $label):void{try{$action();}catch(Throwable $error){responseCheck(true,$label);return;}throw new RuntimeException('Expected rejection: '.$label);}
function responseTasks(int $site,int $lead,string $event=''):array{$q=Db::name('hsx_lead_notice_task')->where('site_id',$site)->where('source_type','collaboration_assignment')->where('source_id',$lead);if($event!=='')$q->where('event_key',$event);return$q->order('id')->select()->toArray();}
/** Move owned synthetic source and task timestamps together; no wall-clock sleeps or production records. */
function responseAge(int $site,int $lead,int $seconds):void
{
    $row=Store::row('collaboration',$site,$lead);$rule=Data::decode($row['rule_json']);$plan=$rule['response_notice_plan'];$plan['assigned_at']-=$seconds;$plan['deadline']-=$seconds;$rule['response_notice_plan']=$plan;
    Store::query('collaboration',$site)->where('id',$lead)->update(['response_deadline'=>(int)$row['response_deadline']-$seconds,'rule_json'=>Data::json($rule)]);
    foreach(responseTasks($site,$lead)as$task){$snapshot=Data::decode($task['payload_json']);foreach(['response_deadline','planned_at','occurred_at']as$field)$snapshot[$field]-=$seconds;
        Db::name('hsx_lead_notice_task')->where('site_id',$site)->where('id',$task['id'])->update(['payload_json'=>Data::json($snapshot),'next_retry_at'=>(int)$task['next_retry_at']-$seconds,'expires_at'=>(int)$task['expires_at']-$seconds]);}
}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
    Db::name('member_level')->where('site_id',$site)->where('level_id',704)->update(['level_benefits'=>leadMembershipDefinition(704,4,10,false,['all_models'=>true])['level_benefits']]);
    Db::name('member')->insert(['member_id'=>104,'site_id'=>$site,'nickname'=>'Third store','mobile'=>'19900000104']);
    foreach([101,102,104]as$member)Db::name('member')->where('member_id',$member)->update(['weapp_openid'=>'fixture-notice-'.$member]);
    $admin=new Context($site,1);$config=new ConfigService($admin);$cfg=$config->get();$cfg['enabled']=true;$cfg['publishing_required']=false;$cfg['fee_confirmed']=true;$cfg['response_minutes']=30;$config->save($cfg);
    $base=['name'=>'Publisher','contact_name'=>'Fixture','mobile'=>'18800000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road','provider'=>''];$shops=[];
    foreach([101,102,104]as$member)$shops[$member]=(new PartnerService(new Context($site,0,$member)))->saveProfile(array_replace($base,['name'=>'Fixture Store '.$member,'mobile'=>'18800000'.$member]));
    leadSetEntryDefinition($site,704);leadMembershipGrant($site,102,'ML704');leadMembershipGrant($site,104,'ML704');
    $publisher=new CooperationService(new Context($site,0,101));$receiver=new CooperationService(new Context($site,0,102));$third=new CooperationService(new Context($site,0,104));
    $model=$publisher->catalog(['keyword'=>'iPhone'])[0];$input=['customer_name'=>'Private fixture buyer','mobile'=>'13800000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'attachments'=>[],'remark'=>'Private customer note','consent'=>true];$sequence=0;
    $create=static function()use(&$sequence,$publisher,$input):int{return(int)$publisher->create($input+['request_id'=>'response-test-'.(++$sequence)])['id'];};
    $assign=static function(int $id)use($publisher,$shops):array{return$publisher->assign($id,['merchant_id'=>(int)$shops[102]['id'],'assignment_version'=>0]);};
    $legacy=$create();$assign($legacy);$receiver->action($legacy,['action'=>'accept','assignment_version'=>1]);
    $legacyEvents=Data::query('audit',$site)->where('entity_type',CooperationNoticeOutbox::TYPE)->where('entity_id',$legacy)->select()->toArray();
    responseCheck(count(array_filter($legacyEvents,static fn($r)=>(Data::decode($r['detail_json'])['action']??'')==='accept'))===1,'new scenes default off preserves legacy accept producer');
    responseCheck(responseTasks($site,$legacy)===[],'new scenes default off never create typed tasks');
    $policy=new AccountNoticePolicyService();$events=[];
    foreach([CooperationResponseNotices::REMINDER,CooperationResponseNotices::OVERDUE,CooperationResponseNotices::ACCEPTED]as$key)$events[]=['event_key'=>$key,'enabled'=>true,'channels'=>['weapp'=>true],
        'weapp'=>['tid'=>'987654','kid_list'=>[1,2,3],'scene_desc'=>'Synthetic isolated assignment reminder','confirmed'=>true,'fields'=>[
            ['keyword'=>'character_string1','variable'=>'task_no','label'=>'编号'],['keyword'=>'thing2','variable'=>'notice_remark','label'=>'提示'],['keyword'=>'time3','variable'=>'occurred_at','label'=>'时间']]]];
    $policy->save($admin,['enabled'=>true,'response_reminder_minutes'=>[30,10,5,1],'events'=>$events]);
    foreach($events as$event)Db::name('sys_notice')->where('site_id',$site)->where('key',NoticeEventCatalog::key($event['event_key']))->update(['is_weapp'=>1,'weapp_template_id'=>'synthetic-'.$event['event_key']]);
    Event::remove('NoticeData');Event::listen('NoticeData',AccountNoticeData::class);$sent=[];
    $gateway=new FrameworkNoticeGateway(static function($channel,$payload)use(&$sent){$sent[]=$payload;return['accepted'=>true,'provider_code'=>'0','channel'=>$channel];});$runtime=new NoticeTaskRuntime([$gateway,'dispatch']);
    $id=$create();$assigned=$assign($id);$tasks=responseTasks($site,$id);
    responseCheck(count($tasks)===4,'new assignment schedules 10,5,1 minute receiver reminders and one publisher overdue reminder');
    responseCheck(count(responseTasks($site,$id,CooperationResponseNotices::REMINDER))===3,'initial 30-minute event does not duplicate immediate assignment notice');
    responseCheck($assigned['response_remaining_seconds']<=1800&&$assigned['response_remaining_seconds']>1790&&$assigned['server_time']>0,'countdown anchored to real server deadline');
    responseCheck($sent===[],'assignment records future tasks without external notification');
    CooperationResponseNotices::recordCurrent($site,$id);responseCheck(count(responseTasks($site,$id))===4,'replayed planning is idempotent');
    $initial=$tasks[0];$runtime->process($site,(int)$initial['id']);responseCheck($sent===[],'future delayed task cannot send early');
    responseAge($site,$id,22*60);$reminders=responseTasks($site,$id,CooperationResponseNotices::REMINDER);$runtime->process($site,(int)$reminders[0]['id']);
    responseCheck(count($sent)===1&&$sent[0]['to']['member_id']===102,'current countdown node notifies only receiving store identity');
    responseCheck(!str_contains(Data::json($sent),'Private fixture buyer')&&!str_contains(Data::json($sent),'13800000000'),'reminder never exposes hidden customer contacts');
    responseAge($site,$id,9*60);$before=count($sent);foreach(responseTasks($site,$id)as$task)$runtime->process($site,(int)$task['id']);
    responseCheck(count($sent)===$before+1&&end($sent)['to']['member_id']===101,'overdue sends one prompt to publishing member, no obsolete intermediate reminders');
    $late=$receiver->detail($id);responseCheck($late['status']==='assigned'&&$late['can_accept']&&$late['response_overdue'],'timeout neither rejects acceptance nor automatically reassigns');
    responseCheck($publisher->detail($id)['can_reassign'],'publisher may choose another store while unaccepted');
    $receiver->action($id,['action'=>'accept','assignment_version'=>1]);$receiver->action($id,['action'=>'no_deal','assignment_version'=>1]);
    $accepted=responseTasks($site,$id,CooperationResponseNotices::ACCEPTED);responseCheck(count($accepted)===1,'acceptance creates one immutable publishing-member fact');
    $runtime->process($site,(int)$accepted[0]['id']);responseCheck(end($sent)['to']['member_id']===101&&end($sent)['vars']['status_text']==='已接单','acceptance fact still sends after immediate outcome progression');
    $legacyRows=Data::query('audit',$site)->where('entity_type',CooperationNoticeOutbox::TYPE)->where('entity_id',$id)->select()->toArray();
    responseCheck(count(array_filter($legacyRows,static fn($r)=>(Data::decode($r['detail_json'])['action']??'')==='accept'))===0,'typed accept explicitly suppresses legacy accept producer');
    $count=count($sent);$runtime->process($site,(int)$accepted[0]['id']);responseCheck(count($sent)===$count,'accepted fact never resends');
    // Atomic selection: merely opening or cancelling a picker does not withdraw anything.
    $replaceId=$create();$original=$assign($replaceId);$publisher->stores(['scope'=>'auto'],$replaceId);
    responseCheck($publisher->detail($replaceId)['receiver']['id']===$shops[102]['id'],'opening selection keeps original receiver');
    responseDeny(static fn()=>$publisher->assign($replaceId,['replace'=>true,'merchant_id'=>999999,'assignment_version'=>1]),'invalid replacement is rejected atomically');
    responseCheck($publisher->detail($replaceId)['assignment_version']===1&&$publisher->detail($replaceId)['receiver']['id']===$shops[102]['id'],'failed replacement does not lose existing assignment');
    responseDeny(static fn()=>$third->assign($replaceId,['replace'=>true,'merchant_id'=>(int)$shops[104]['id'],'assignment_version'=>1]),'another merchant cannot replace publisher assignment');
    $replacement=$publisher->assign($replaceId,['replace'=>true,'merchant_id'=>(int)$shops[104]['id'],'assignment_version'=>1]);
    responseCheck($replacement['assignment_version']===2&&$replacement['receiver']['id']===$shops[104]['id'],'replacement changes receiver and version in one transaction');
    responseDeny(static fn()=>$receiver->action($replaceId,['action'=>'accept','assignment_version'=>1]),'old receiver loses acceptance authority after replacement wins');
    $oldVersion=array_values(array_filter(responseTasks($site,$replaceId),static fn($r)=>(Data::decode($r['payload_json'])['assignment_version']??0)===1));
    responseCheck($oldVersion!==[]&&count(array_filter($oldVersion,static fn($r)=>$r['status']!=='obsolete'))===0,'old replacement reminders become obsolete without touching delivery receipts');
    $third->action($replaceId,['action'=>'accept','assignment_version'=>2]);
    responseDeny(static fn()=>$publisher->assign($replaceId,['replace'=>true,'merchant_id'=>(int)$shops[102]['id'],'assignment_version'=>2]),'acceptance winning race prevents later replacement');
    responseDeny(static fn()=>(new CooperationService(new Context($site+1,0,103)))->assign($replaceId,['replace'=>true,'merchant_id'=>(int)$shops[102]['id'],'assignment_version'=>2]),'cross-site replacement denied');
    // Producer choice is frozen at acceptance, not re-evaluated later by a worker.
    $switchId=$create();$assign($switchId);$policy->save($admin,['events'=>[['event_key'=>CooperationResponseNotices::ACCEPTED,'enabled'=>false]]]);
    $receiver->action($switchId,['action'=>'accept','assignment_version'=>1]);$policy->save($admin,['events'=>[['event_key'=>CooperationResponseNotices::ACCEPTED,'enabled'=>true]]]);CooperationResponseNotices::recordCurrent($site,$switchId);
    responseCheck(responseTasks($site,$switchId,CooperationResponseNotices::ACCEPTED)===[],'enabling typed later never recreates a legacy acceptance fact');
    $switch2=$create();$assign($switch2);$receiver->action($switch2,['action'=>'accept','assignment_version'=>1]);$typed=responseTasks($site,$switch2,CooperationResponseNotices::ACCEPTED)[0];
    $policy->save($admin,['events'=>[['event_key'=>CooperationResponseNotices::ACCEPTED,'enabled'=>false]]]);$runtime->process($site,(int)$typed['id']);
    responseCheck(Db::name('hsx_lead_notice_task')->where('id',$typed['id'])->value('status')==='paused','disabling typed event pauses its fixed producer rather than falling back to legacy');
    $legacyRows=Data::query('audit',$site)->where('entity_type',CooperationNoticeOutbox::TYPE)->where('entity_id',$switch2)->select()->toArray();responseCheck(count(array_filter($legacyRows,static fn($r)=>(Data::decode($r['detail_json'])['action']??'')==='accept'))===0,'typed-disabled-after-fact never creates duplicate legacy event');
    // Explicit expiry: existing published business stays manageable, but no new free publications.
    $expiryId=$create();$assign($expiryId);$expiredGrant=leadMembershipGrant($site,101,'ML704');
    // First establish a valid grant, then move every synthetic original quote/receipt/period consistently into the past.
    // Backdating only pay_time would deliberately trigger the payment safety gate, not create an expired membership.
    $expiredRow=Store::row('coop_order',$site,(int)$expiredGrant['id']);$expiredRule=Data::decode($expiredRow['rule_json']);$past=time()-70*86400;
    $expiredRule['quoted_at']=$past;$expiredRule['period_start_at']=$past;$expiredRule['period_end_at']=\addon\hsx_lead\app\service\cooperation\Rules::addMonths($past,(int)$expiredRule['months']);
    if(isset($expiredRule['quoted_period_start_at']))$expiredRule['quoted_period_start_at']=$past;
    if(isset($expiredRule['quoted_period_end_at']))$expiredRule['quoted_period_end_at']=$expiredRule['period_end_at'];
    Store::query('coop_order',$site)->where('id',$expiredRow['id'])->update(['rule_json'=>Data::json($expiredRule),'pay_time'=>$past,'create_time'=>$past,'update_time'=>$past]);
    Db::name('pay')->where('site_id',$site)->where('trade_id',$expiredRow['id'])->where('out_trade_no',$expiredRow['out_trade_no'])->update(['pay_time'=>$past]);
    Store::query('partner',$site)->where('merchant_id',$shops[101]['id'])->update(['membership_until'=>$expiredRule['period_end_at']]);
    $expiryState=\addon\hsx_lead\app\service\cooperation\EntityMembershipService::state($site,(int)$shops[101]['id']);
    responseCheck(!$expiryState['active']&&!$expiryState['review_required']&&$expiryState['level_code']==='ML704'&&$expiryState['expires_at']<time(),'expiry fixture has a verified real expired entitlement, not a receipt conflict');
    $cfg=$config->get();$cfg['publishing_required']=true;$config->save($cfg);
    $publisher->action($expiryId,['action'=>'withdraw','assignment_version'=>1]);$reopened=$publisher->assign($expiryId,['merchant_id'=>(int)$shops[104]['id'],'assignment_version'=>2]);
    responseCheck($reopened['status']==='assigned'&&$reopened['assignment_version']===3,'expired publisher can withdraw and reselect for its existing lead');
    responseDeny(static fn()=>$create(),'expired publisher still cannot create a new publication');
    responseDeny(static fn()=>$receiver->assign($expiryId,['replace'=>true,'merchant_id'=>(int)$shops[102]['id'],'assignment_version'=>3]),'expiry accommodation does not let another merchant steal the lead');
    // Only the current configured node is reconstructed, never prior assignments without an opt-in plan.
    $policy->save($admin,['response_reminder_minutes'=>[1,10,10,5]]);responseCheck($policy->get($site)['response_reminder_minutes']===[10,5,1],'nodes canonicalize without duplicate deliveries');
    responseDeny(static fn()=>$policy->save($admin,['response_reminder_minutes'=>[0]]),'invalid reminder minutes rejected');
    foreach([106,107]as$member)Db::name('member')->insert(['member_id'=>$member,'site_id'=>$site,'nickname'=>'Publishing fixture '.$member,'mobile'=>'19900000'.$member,'weapp_openid'=>'fixture-publisher-'.$member]);
    $staffShop=(new PartnerService(new Context($site,0,106)))->saveProfile(array_replace($base,['name'=>'Employee publication shop','mobile'=>'18800000106']));leadMembershipGrant($site,106,'ML704');
    Db::name('hsx_lead_merchant_member')->insert(['site_id'=>$site,'merchant_id'=>(int)$staffShop['id'],'member_id'=>107,'role'=>'member','status'=>'active','create_time'=>time(),'update_time'=>time()]);
    $staffPublisher=new CooperationService(new Context($site,0,107));$staffLead=(int)$staffPublisher->create($input+['request_id'=>'response-staff-published'])['id'];
    $policy->save($admin,['events'=>[['event_key'=>CooperationResponseNotices::ACCEPTED,'enabled'=>true]]]);
    $staffPublisher->assign($staffLead,['merchant_id'=>(int)$shops[102]['id'],'assignment_version'=>0]);responseAge($site,$staffLead,31*60);
    $staffOverdue=responseTasks($site,$staffLead,CooperationResponseNotices::OVERDUE)[0];$runtime->process($site,(int)$staffOverdue['id']);
    responseCheck(end($sent)['to']['member_id']===107,'employee publication overdue reminder goes to actual publishing employee, not store owner');
    $receiver->action($staffLead,['action'=>'accept','assignment_version'=>1]);$staffAccept=responseTasks($site,$staffLead,CooperationResponseNotices::ACCEPTED)[0];$runtime->process($site,(int)$staffAccept['id']);
    responseCheck(end($sent)['to']['member_id']===107,'acceptance fact notifies original publishing employee only');
    $beforeHistorical=Db::name('hsx_lead_notice_task')->count();CooperationResponseNotices::recoverSite($site,200);
    responseCheck(responseTasks($site,$legacy)===[]&&Db::name('hsx_lead_notice_task')->count()===$beforeHistorical,'recovery excludes legacy unplanned acceptances and never rebuilds them into typed tasks');
    $cfg=$config->get();$cfg['response_minutes']=0;$config->save($cfg);$noDeadline=(int)$staffPublisher->create($input+['request_id'=>'response-without-deadline'])['id'];
    $staffPublisher->assign($noDeadline,['merchant_id'=>(int)$shops[102]['id'],'assignment_version'=>0]);responseCheck(responseTasks($site,$noDeadline)===[],'no reminder time produces neither countdown nodes nor overdue tasks');
    $receiver->action($noDeadline,['action'=>'accept','assignment_version'=>1]);$noDeadlineTask=responseTasks($site,$noDeadline,CooperationResponseNotices::ACCEPTED)[0];$runtime->process($site,(int)$noDeadlineTask['id']);$noDeadlineVars=end($sent)['vars'];
    responseCheck(end($sent)['to']['member_id']===107&&$noDeadlineVars['status_text']==='已接单','acceptance without a deadline still notifies original publishing employee');
    responseCheck(!isset($noDeadlineVars['response_deadline'])&&!isset($noDeadlineVars['remaining_minutes'])&&!str_contains(Data::json($noDeadlineVars),'1970'),'acceptance variables omit nonexistent reminder time and remaining minutes');
    $acceptedMetadata=array_values(array_filter($policy->get($site)['events'],static fn($e)=>$e['event_key']===CooperationResponseNotices::ACCEPTED))[0];
    responseCheck(!isset($acceptedMetadata['variables']['response_deadline'])&&!isset($acceptedMetadata['variables']['remaining_minutes'])&&!in_array('response_deadline',$acceptedMetadata['field_types']['time'],true)&&$acceptedMetadata['field_types']['number']===[],'acceptance template editor cannot map unavailable deadline or remaining-minute fields');
    $invalidAccepted=$events[2];$invalidAccepted['weapp']['fields'][2]['variable']='response_deadline';responseDeny(static fn()=>$policy->save($admin,['events'=>[$invalidAccepted]]),'acceptance configuration rejects meaningless deadline field');
    echo 'PASS cooperation response notice assertions: '.$checks.PHP_EOL;
}catch(Throwable $error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().PHP_EOL.$error->getTraceAsString().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
