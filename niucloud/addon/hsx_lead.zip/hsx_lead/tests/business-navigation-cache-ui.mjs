import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Actual shared metadata helper. No API, browser, storage or installed data.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const cache=loadMobileUtility('cooperation-business-cache');let checks=0,reads=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
const data=name=>({data:{profile:{name:'never-cache'},wallet:{balance:'never-cache'},config:{businesses:[{key:'purchase',name,enabled:true,fee:'private'},{key:'disabled',name:'off',enabled:false}]}}})
cache.clearCooperationBusinessCache()
let release
const loader=()=>{reads++;return new Promise(resolve=>{release=resolve})}
const a=cache.readCooperationBusinessEntries('site-a:member-a',loader),b=cache.readCooperationBusinessEntries('site-a:member-a',loader)
check(reads===1,'two separate DIY business blocks share one pending request')
release(data('业务A'));const [first,second]=await Promise.all([a,b])
check(JSON.stringify(first)==='[{"key":"purchase","name":"业务A"}]','cache keeps enabled names/keys, never profile, fee or wallet data')
first[0].name='改了第一个组件';check(second[0].name==='业务A','each renderer receives independent rows')
const cached=await cache.readCooperationBusinessEntries('site-a:member-a',async()=>{reads++;return data('unexpected')})
check(reads===1&&cached[0].name==='业务A','same-turn remounts reuse a bounded one-second display cache')
const switched=await cache.readCooperationBusinessEntries('site-b:member-a',async()=>{reads++;return data('业务B')})
check(reads===2&&switched[0].name==='业务B','site identity never reuses a different site projection')
await cache.readCooperationBusinessEntries('',async()=>{throw Error('anonymous API forbidden')})
check(true,'anonymous state clears cache without making a request')
let oldResolve
const stale=cache.readCooperationBusinessEntries('site-a:old',()=>new Promise(resolve=>{oldResolve=resolve}))
await cache.readCooperationBusinessEntries('site-a:new',async()=>data('新会员'))
oldResolve(data('迟到旧会员'));await stale
const current=await cache.readCooperationBusinessEntries('site-a:new',async()=>{throw Error('new cache lost')})
check(current[0].name==='新会员','an old pending response never replaces current-identity cache')
cache.clearCooperationBusinessCache()
await assert.rejects(cache.readCooperationBusinessEntries('site-a:new',async()=>({data:{profile:{}}})));checks++
check((await cache.readCooperationBusinessEntries('site-a:new',async()=>data('恢复')))[0].name==='恢复','a failed read is not cached as an empty success')
const entry=fs.readFileSync(path.join(plugin,'uni-app/components/diy/lead-cooperation-entry/index.vue'),'utf8')
const wrapper=fs.readFileSync(path.join(plugin,'uni-app/components/diy/lead-business-navigation/index.vue'),'utf8')
check(entry.includes('<CoopBusinessNavigation ')&&wrapper.includes('<CoopBusinessNavigation '),'combined and standalone layouts use the same business renderer')
check(!entry.includes('cooperationBootstrap')&&!wrapper.includes('cooperationBootstrap'),'thin role/wrapper components do not duplicate private business reads')
check(entry.includes('showTools:0')&&entry.includes('showBusinesses:0'),'default home roles do not inject extra tools or a repeated business list')
const helper=fs.readFileSync(path.join(plugin,'uni-app/utils/cooperation-business-cache.ts'),'utf8')
check(helper.includes('type BusinessReader = () => Promise<any>')&&helper.includes('identity: string, read: BusinessReader'),'function callback types are named aliases, avoiding the installed uni inline-signature rewriting bug')
check(!/function\s+\w+\([^\n]*:\s*\(\s*\)\s*=>/.test(helper),'shared helper contains no inline callback type in a function argument list')
console.log(`PASS ${checks} shared business projection/cache contracts; no live requests, browser, storage or deployment writes.`)
