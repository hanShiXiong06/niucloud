import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { loadFrameworkInvite } from './framework-invite.mjs'
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.join(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), sass = require('sass')
const read = file => fs.readFileSync(path.join(plugin, 'uni-app', file), 'utf8')
let checks = 0
const check = (ok, message) => { assert.ok(ok, message); checks++ }
function moduleOf(source, deps, globals = {}) {
    const module = { exports: {} }, js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Number, String, Boolean, Object, Array, Map, Set, Promise, Math, JSON, console, ...globals })(key => {
        if (key in deps) return deps[key]
        if (key.endsWith('.vue')) return { default: {} }
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        throw Error('Unexpected test dependency ' + key)
    }, module, module.exports)
    return module.exports
}
function parse(file) {
    const descriptor = compiler.parse(read(file), { filename: file }).descriptor, script = compiler.compileScript(descriptor, { id: 'entity-test' })
    check(!compiler.compileTemplate({ source: descriptor.template.content, filename: file, id: 'entity-test', compilerOptions: { bindingMetadata: script.bindings } }).errors.length, file + ' real template compiles')
    for (const style of descriptor.styles) { check(style.scoped, file + ' owns its CSS'); check(!compiler.compileStyle({ source: style.lang === 'scss' ? sass.compileString(style.content).css : style.content, filename: file, id: 'entity-test', scoped: true }).errors.length, file + ' style compiles') }
    return script.content
}
const scripts = Object.fromEntries(['pages/entity/index.vue', 'pages/membership/index.vue', 'components/cooperation/CoopMembershipEntry.vue'].map(file => [file, parse(file)]))
const utility = loadMobileUtility('entity-membership')
for (const value of ['S', 'A', 'premium', 4, true, 'V1', 'V5', 'ML0', 'ML-2']) check(utility.entityLevel(value) === '', 'old/arbitrary identity is not a framework membership: ' + value)
check(utility.entityLevel('ML708') === 'ML708' && utility.membershipState({ level_code: 'ML708', active: false }) === 'expired', 'arbitrary framework level supports an expired badge')
check(utility.entityAccounts({ account_limit: 2 }) === '2 人' && utility.entityAccounts({ unlimited: true }) === '不限人数', 'account count and unlimited are explicit')
check(utility.entityPageLink('S-AB12').includes('subject_code=S-AB12') && !utility.entityPageLink('S-AB12').includes('mid='), 'subject invitations do not reuse personal promotion IDs')
const baseTier = { code: 'ML701', name: '合成等级1', rank: 1, display_rank: 1, enabled: true, account_limit: 1, unlimited: false, cycles: [{ key: 'month', name: '月付', months: 1, enabled: false, price: '0.00' }, { key: 'quarter', name: '季付', months: 3, enabled: true, price: '39.00' }, { key: 'year', name: '年付', months: 12, enabled: true, price: '99.00' }], benefits: [{ key: 'can_publish', title: '发布客户需求', desc: '按门店共用', icon: 'order', enabled: true }] }
const testTiers = Array.from({ length: 8 }, (_, index) => ({ ...baseTier, code: `ML${701 + index}`, name: `合成等级${index + 1}`, rank: index + 1, display_rank: index + 1, account_limit: index + 1 }))
const costParts = (extra = {}) => ({ deposit_required:'100.00',deposit_balance:'100.00',deposit_amount:'0.00',service_full_amount:'199.00',service_credit_amount:'100.00',service_amount:'99.00',buy_experience:false,experience_purchase_enabled:false,experience_unit_price:'0.00',experience_quantity:'0.00',experience_amount:'0.00',payable_amount:'99.00',promotion_base_amount:'99.00',...extra })
const receipt = (id, extra = {}) => ({ ...costParts(), id, member_id: 101, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'unpaid', can_pay: true, amount: '99.00', ...extra })
function fixture(page) {
    let token = 'synthetic-member-a', site = 100005, membership = { merchant_id: 7, level_code: 'ML701', level_name: '合成等级1', display_rank: 1, active: true, expires_at: 1900000000, can_manage: true, is_owner: true, account_limit: 1, used_accounts: 1, tiers: testTiers }, team = { merchant_id: 0, name: '', members: [], pending_entity: null }
    const calls = [], shows = [], hides = [], loads = [], shares = [], cleanups = [], cashier = [], navigations = [], copies = [], modals = []
    let deferModal = false, pendingRead = null, quoteWork = null, orderWork = null, createWork = null, depositWork = null, depositApplyWork = null, closeWork = null
    let deposit = { merchant_id:7,is_owner:true,balance:'100.00',can_apply:true,blocking_reasons:[],cooperation_exited:false,request:null }
    const quoteData = () => ({ ...costParts(), purpose: 'membership', merchant_id: 7, level_code: state.selected.value, level_name: '会员', cycle: state.cycle.value, can_purchase: true, full_amount: '199.00', credit_amount: '100.00', period_start_at: 1800000000, period_end_at: 1900000000, quote_token: 'signed-by-server', expires_at: Math.floor(Date.now() / 1000) + 600 })
    const api = {
        entityMembership: async () => { calls.push(['membership']); return pendingRead ? pendingRead() : { data: membership } },
        entityTeam: async () => { calls.push(['team']); return pendingRead ? pendingRead() : { data: team } },
        entityLookup: async code => { calls.push(['lookup', code]); return { data: { merchant_id: 7, name: '合成门店' } } },
        entityJoin: async code => { calls.push(['join', code]); team = { merchant_id: 0, pending_entity: { merchant_id: 7, name: '合成门店', status: 'pending' } }; return { data: team } },
        entityReview: async (...args) => { calls.push(['review', ...args]); return { data: {} } },
        entityRemove: async (...args) => { calls.push(['remove', ...args]); return { data: {} } },
        entityLeave: async () => { calls.push(['leave']); team = { merchant_id: 0, pending_entity: null }; return { data: {} } },
        entityQuote: async (...args) => { calls.push(['quote', ...args]); return quoteWork ? quoteWork(...args) : { data: quoteData() } },
        entityCloseOrder: async id => { calls.push(['close-order', id]); return closeWork ? closeWork(id) : { data: receipt(id, { status: 'closed' }) } },
        entityDeposit: async () => { calls.push(['deposit']); return depositWork ? depositWork() : { data:deposit } },
        entityApplyDepositRefund: async (...args) => { calls.push(['deposit-apply',...args]); if(depositApplyWork)return depositApplyWork(...args); deposit={...deposit,can_apply:false,request:{id:91,status:'pending',status_name:'待审核',amount:'100.00',sources:[]}};return{data:deposit} },
    }
    const common = { getToken: () => token, getSiteId: () => site }, runtime = {
        getStorageSync: () => site, showToast() {}, showModal: data => { modals.push(data); if (!deferModal) data.success({ confirm: true }) },
        navigateTo: data => navigations.push(data), setClipboardData: data => copies.push(data.data),
    }
    const helpers = moduleOf(read('api/cooperation.ts'), { '@/utils/request': { default: {} } })
    const lifecycle = { onLoad: fn => loads.push(fn), onShow: fn => shows.push(fn), onHide: fn => hides.push(fn), onShareAppMessage: fn => shares.push(fn) }
    const hooks = { ...Vue, onBeforeUnmount: fn => cleanups.push(fn) }
    const controller = moduleOf(read('composables/useEntityPage.ts'), { vue: hooks, '@/utils/common': common, '../api/cooperation': helpers }, { uni: runtime })
    const deps = {
        vue: hooks, '@dcloudio/uni-app': lifecycle, '@/utils/common': common, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: data => calls.push(['login', data]) }) },
        '../../api/entity': api, '../../api/cooperation': { ...helpers,
            resumeCooperationOrder: async id => { calls.push(['order', id]); return orderWork ? orderWork(id) : { data: receipt(id) } },
            createCooperationOrder: async data => { calls.push(['create-order', data]); return createWork ? createWork(data) : { data: receipt(22, { level_code: data.level_code, cycle: data.cycle, entitlement_months: membership.tiers.find(tier => tier.code === data.level_code)?.cycles.find(c => c.key === data.cycle)?.months }) } },
        }, '../../composables/useEntityPage': controller,
        '../../utils/cooperation-navigation': { backCooperationTask: () => navigations.push('back') },
        '../../utils/cooperation-invite': loadFrameworkInvite(runtime),
    }
    const state = moduleOf(scripts[`pages/${page}/index.vue`], deps, { uni: runtime }).default.setup({}, { expose() {} })
    if (state.payRef) state.payRef.value = { open: (...args) => cashier.push(args) }
    return { state, calls, cashier, navigations, copies, modals, shows, hides, loads, shares, cleanups, set token(v) { token = v }, set site(v) { site = v }, set team(v) { team = v }, set membership(v) { membership = v }, set pendingRead(v) { pendingRead = v }, set deferModal(v) { deferModal = v }, set quoteWork(v) { quoteWork = v }, set orderWork(v) { orderWork = v }, set createWork(v) { createWork = v }, set closeWork(v) { closeWork = v },set deposit(v){deposit=v},set depositWork(v){depositWork=v},set depositApplyWork(v){depositApplyWork=v} }
}
let f = fixture('entity'), s = f.state
f.loads.forEach(fn => fn({ mode: 'join', subject_code: ' abc12 ' })); await s.refresh()
check(s.code.value === 'ABC12' && f.calls.every(call => call[0] !== 'lookup'), 'invitation prefills code but never silently sends a joining request')
await s.lookup(); check(f.calls.at(-1)[0] === 'lookup' && s.found.value.name === '合成门店', 'explicit lookup returns a named door before joining')
await s.join(); check(s.team.value.pending_entity.status === 'pending' && !s.team.value.merchant_id, 'submitting join is pending, never active rights')
await s.leave(); check(!s.team.value.pending_entity && f.calls.some(call => call[0] === 'leave'), 'pending applicant can explicitly withdraw')
f.team = { merchant_id: 7, name: '合成门店', subject_code: 'SUBJ1234', is_owner: true, members: [{ member_id: 1, role: 'owner', status: 'active' }, { member_id: 2, nickname: '新同事', role: 'member', status: 'pending' }], membership: { account_limit: 2, used_accounts: 1, unlimited: false } }; await s.refresh(); s.copyCode()
check(f.copies.at(-1) === 'SUBJ1234' && f.shares[0]().path.includes('subject_code=SUBJ1234'), 'owner code is copied/shared through the actual registered native page')
check(s.hasCapacity.value, 'unfilled membership has capacity including its owner')
s.team.value.membership.used_accounts = 2; await s.review({ member_id: 2 }, true)
check(!s.hasCapacity.value && !f.calls.some(call => call[0] === 'review') && s.state.writeError.value.includes('名额已满'), 'full membership blocks approval before confirmation with a clear upgrade/remove reason')
s.team.value.membership.unlimited = true; check(s.hasCapacity.value, 'explicit unlimited membership remains eligible with any used count')
s.team.value.membership.unlimited = false; s.team.value.membership.used_accounts = 1
f.deferModal = true; const first = s.review({ member_id: 2, nickname: '新同事' }, true), second = await s.review({ member_id: 2 }, true)
check(f.modals.length === 2 && !f.calls.some(call => call[0] === 'review'), 'one extra owner confirmation is open; repeated approval does not send a write')
f.modals.at(-1).success({ confirm: true }); await first
check(f.calls.filter(call => call[0] === 'review').length === 1, 'approval sends one actual owner-scoped request')
f.team = { merchant_id: 7, is_owner: false, members: [] }; await s.refresh(); const before = f.calls.length; await s.review({ member_id: 3 }, true); await s.remove({ member_id: 3 }); s.copyCode()
check(f.calls.length === before && f.copies.length === 1, 'member UI does not attempt owner approval/removal or expose the code')
let release; f.pendingRead = () => new Promise(resolve => { release = resolve }); const readOld = s.refresh(); f.token = 'synthetic-member-b'; release({ data: { merchant_id: 99, subject_code: 'private-old' } }); await readOld
check(s.team.value.merchant_id !== 99, 'late old-account read cannot show another entity')
let staleWrite = false; const rejectedWrite = await s.state.write(async () => { staleWrite = true; return { data: {} } })
check(rejectedWrite === null && !staleWrite, 'old form cannot establish write authorization for a new login without a fresh read')

f = fixture('membership'); s = f.state; await s.refresh()
check(s.summary.value.level_code === 'ML701' && s.quote.value.payable_amount === '99.00' && f.calls.filter(call => call[0] === 'quote').length === 1, 'member page reads actual framework rights and one server-owned fee quotation')
check(s.tiers.value.length === 8 && s.tiers.value.at(-1).rank === 8 && s.cycles.value.length === 2 && s.cycle.value === 'quarter', 'eight framework tiers render; disabled monthly price is absent and first enabled quarter is selected')
const beforeDisabledCycle = f.calls.length; s.selectCycle('month'); check(f.calls.length === beforeDisabledCycle && s.cycle.value === 'quarter', 'disabled cycle never issues a quotation')
check(utility.membershipBenefits({ benefits: [{ key: 'dynamic', title: '后台权益', enabled: false, icon: 'unsafe-path' }] })[0].icon === 'checkmark-circle', 'dynamic benefit icons use a bounded local whitelist')
await s.submitMembershipPayment(); check(f.cashier.length === 1 && f.cashier[0][0] === 'hsx_lead_cooperation' && f.cashier[0][1] === 22, 'confirmed order uses the existing framework cashier contract')
check(f.calls.find(call => call[0] === 'create-order')[1].quote_token === 'signed-by-server', 'cashier order creation sends the exact quoted contract, no client price')
f.orderWork = async () => { throw { msg: '原单状态暂未核实' } }; await s.submitMembershipPayment()
check(f.cashier.length === 1 && s.paymentMessage.value === '原单状态暂未核实', 'failed refresh cannot reopen cashier from a stale unpaid result')
f.orderWork = async id => ({ data: { id, merchant_id: 8, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'unpaid', amount: '99.00' } }); await s.submitMembershipPayment()
check(f.cashier.length === 1 && s.paymentMessage.value.includes('不一致'), 'another entity payment response is rejected before cashier')
f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'paid', amount: '99.00', requires_manual_review: true, review_message: '真实收款待核对' } }); await s.verifyPayment()
check(s.paymentMessage.value === '真实收款待核对' && s.paymentLocked.value, 'paid-but-ungranted result remains explicit and cannot be shown as active success')
await s.submitMembershipPayment(); check(f.cashier.length === 1, 'manual-review receipt cannot reopen the cashier')
f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'paid', quote_expired: true, amount: '99.00' } }); await s.verifyPayment()
check(!s.paymentLocked.value && s.mainLabel.value.includes('支付已确认'), 'completed receipt is not labeled as an uncertain pending order')
await s.submitMembershipPayment(); check(f.navigations.at(-1) === 'back' && f.cashier.length === 1, 'completed payment returns without paying again even after quotation time has elapsed')
f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'paid', amount: '99.00', membership_refund_status: 'refunded' } }); await s.verifyPayment()
check(s.paymentMessage.value.includes('原单已退款') && !s.paymentMessage.value.includes('权益已更新') && s.mainLabel.value === '退款已确认，返回', 'full refund is not mislabeled as a fresh successful activation even though the original receipt remains paid')
await s.submitMembershipPayment(); check(f.navigations.at(-1) === 'back' && f.cashier.length === 1, 'refunded paid receipt only returns and never reopens payment')

f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'unpaid', amount: '99.00', quote_expired: true } }); await s.refresh()
check(s.order.value.id === 35 && s.paymentMessage.value.includes('过期'), 'cashier return retains the original order and reads expired result')
await s.submitMembershipPayment(); check(!f.cashier.length, 'expired original quote cannot continue paying')
await s.closeOrder(); check(f.calls.some(call => call[0] === 'close-order' && call[1] === 35) && s.order.value.id === 35 && s.order.value.status === 'closed' && !f.calls.some(call => call[0] === 'quote'), 'confirmed cancellation retains the closed receipt without auto-generating an old-price quotation')

f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: id === 35 ? receipt(35, { status: 'closed', replacement_order_id: 36 }) : receipt(36, { ...costParts({ service_full_amount:'119.00',service_amount:'19.00',payable_amount:'19.00',promotion_base_amount:'19.00' }), amount:'19.00',reprices_order_id:35 }) }); await s.refresh()
check(s.order.value.id === 36 && s.order.value.amount === '19.00' && s.paymentMessage.value.includes('平台已调整服务费') && !f.calls.some(call => call[0] === 'quote'), 'old membership link follows a proven replacement and shows adjusted costs without asking for old catalog price')
await s.submitMembershipPayment(); check(f.cashier.at(-1)?.[1] === 36 && !f.calls.some(call => call[0] === 'create-order'), 'adjusted membership opens the original replacement cashier, never creates a second trade')
f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: id === 35 ? receipt(35, { status: 'closed', replacement_order_id: 36 }) : receipt(36, { merchant_id:8,reprices_order_id:35 }) }); await s.refresh()
check(s.order.value.id === 35 && s.orderReadFailed.value && !f.cashier.length, 'replacement for a different entity cannot take over the old membership page')
f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: receipt(id, { status:'unpaid' }) }); await s.refresh(); f.closeWork = async id => ({ data: receipt(id, { status:'paid',close_message:'渠道已收款，不能取消' }) }); await s.closeOrder()
check(s.order.value.status === 'paid' && s.paymentMessage.value === '渠道已收款，不能取消' && !f.calls.some(call => call[0] === 'quote'), 'cancellation that discovers a paid receipt remains paid and does not clear or requote the order')

f = fixture('membership'); s = f.state; await s.refresh(); f.createWork = async () => { throw { msg: '结果待核实' } }; await s.submitMembershipPayment(); await s.submitMembershipPayment()
const sent = f.calls.filter(call => call[0] === 'create-order')
check(sent.length === 2 && sent[0][1].request_id === sent[1][1].request_id && !f.cashier.length, 'uncertain creation reuses one idempotency key instead of manufacturing another payment')
f = fixture('membership'); s = f.state; f.membership = { merchant_id: 7, level_code: 'ML702', can_manage: false, active: true, tiers: [baseTier] }; await s.refresh(); await s.submitMembershipPayment()
check(!f.calls.some(call => ['quote', 'create-order'].includes(call[0])) && !f.cashier.length, 'ordinary employees read shared membership without purchasing or entering cashier')
f = fixture('membership'); s = f.state; f.membership = { merchant_id: 7, can_manage: true, tiers: [{ ...testTiers[7], cycles: [{ key: 'activity_6', name: '活动半年卡', months: 6, enabled: true, price: '66.00' }] }] }; await s.refresh()
check(s.selected.value === 'ML708' && s.cycle.value === 'activity_6' && s.cycles.value[0].name === '活动半年卡', 'custom activity duration is supplied by the actual catalog without a month/year whitelist')
await s.submitMembershipPayment(); check(f.cashier.length === 1 && f.calls.find(call => call[0] === 'create-order')[1].cycle === 'activity_6', 'custom cycle reaches the framework cashier through the same server quotation contract')
f = fixture('membership'); s = f.state; f.membership = { merchant_id: 7, can_manage: true, tiers: [{ ...baseTier, cycles: baseTier.cycles.map(cycle => ({ ...cycle, enabled: false })) }] }; await s.refresh(); await s.submitMembershipPayment()
check(!s.cycle.value && !f.calls.some(call => ['quote', 'create-order'].includes(call[0])) && !f.cashier.length, 'a tier with all periods disabled displays no purchasable cycle and cannot create a payment')
check(read('pages/profile/index.vue').includes('加入已有门店') && read('pages/profile/index.vue').includes('pendingEntity'), 'personal page has both onboarding and pending-approval entry')
check(!read('pages/task/index.vue').includes("name === 'plans'"), 'retired standalone subscription task is not kept as a second membership entry')
check(read('pages/membership/index.vue').includes("import Pay from '@/components/pay/pay.vue'"), 'membership explicitly registers the existing framework cashier on native platforms')
check(read('pages/membership/index.vue').includes('v-if="chosen && summary.can_manage && !order.id"'), 'a returned payment shows the original receipt rather than a duplicate fee panel stuck on loading copy')
const memberDescriptor = compiler.parse(read('pages/membership/index.vue')).descriptor
const memberBindings = compiler.compileScript(memberDescriptor, { id: 'actual-member-bindings' }).bindings
const dom = compiler.compileTemplate({ source: memberDescriptor.template.content, filename: 'membership.vue', id: 'actual-member-bindings', compilerOptions: { bindingMetadata: memberBindings } })
const ssr = compiler.compileTemplate({ source: memberDescriptor.template.content, filename: 'membership.vue', id: 'actual-member-bindings', ssr: true, ssrCssVars: [], compilerOptions: { bindingMetadata: memberBindings } })
check(!dom.errors.length && dom.code.includes('$setup["Pay"]') && !dom.code.includes('_createVNode($setup["submitMembershipPayment"]'), 'real H5 component bindings resolve cashier to imported Pay, not the submit action')
check(!ssr.errors.length && ssr.code.includes('$setup["Pay"]') && !ssr.code.includes('_ssrRenderComponent($setup["submitMembershipPayment"]'), 'real SSR component bindings do not invoke an async payment action during rendering')
check(read('pages/entity/index.vue').includes(':disabled="locked || !hasCapacity"') && read('pages/entity/index.vue').includes('账号名额已满，升级会员或移除成员后可继续加入'), 'full-seat native approval is visibly disabled with a readable recovery path')
// Missing receipts must not leave an enabled "confirm renewal" action that only
// repeats quote/order reads, or authorize a new payment from an absent receipt.
const pendingQuote = (id = 404) => ({ data: { purpose: 'membership', merchant_id: 7, level_code: 'ML701', cycle: 'quarter', existing_order_id: id, can_purchase: false, reason: '请先核对原付款单' } })
const freshQuote = () => ({ data: { ...costParts(), purpose: 'membership', merchant_id: 7, level_code: 'ML701', cycle: 'quarter', existing_order_id: 0, can_purchase: true, full_amount: '199.00', credit_amount: '100.00', period_start_at: 1800000000, period_end_at: 1900000000, quote_token: 'fresh-verified-server-quote', expires_at: Math.floor(Date.now() / 1000) + 600 } })
f = fixture('membership'); s = f.state; await s.refresh(); await s.submitMembershipPayment(); const originalCashiers = f.cashier.length
f.orderWork = async id => ({ data: receipt(id, { can_pay: false, payment_recovery: { state: 'uncertain', message: '原单已保留，稍后重试核对' } }) }); await s.submitMembershipPayment()
check(s.mainLabel.value === '核对并继续付款' && s.paymentMessage.value.includes('原单已保留') && f.cashier.length === originalCashiers && f.calls.filter(call => call[0] === 'create-order').length === 1, 'an abandoned but uncertain payment has an actionable retry, not another checkout or a forced manual workflow')
f.orderWork = async id => ({ data: receipt(id, { can_pay: true, payment_recovery: { state: 'ready', message: '原付款已核实，可继续支付' } }) }); await s.submitMembershipPayment()
check(f.cashier.length === originalCashiers + 1 && f.cashier.at(-1)[1] === 22 && f.calls.filter(call => call[0] === 'create-order').length === 1, 'confirmed recovery reopens the original membership business order with no second creation')
f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: receipt(id, { status: 'closed', can_pay: false, quote_expired: true }) }); await s.refresh()
check(!s.order.value.id && s.quote.value.can_purchase && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'authoritatively closed abandoned membership returns to a fresh fee quote without charging or requiring manual cancellation')
await s.submitMembershipPayment(); check(f.cashier.length === 1 && f.calls.filter(call => call[0] === 'create-order').length === 1, 'only the customer confirming the refreshed quotation creates the next checkout')
f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: receipt(id, { status: 'closed', can_pay: false }) }); f.quoteWork = async () => pendingQuote(35); await s.refresh()
check(f.calls.filter(call => call[0] === 'order').length === 1 && f.calls.filter(call => call[0] === 'quote').length === 1 && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'inconsistent closed/pending responses cannot produce an automatic request loop or a new payment')
f = fixture('membership'); s = f.state; await s.refresh(); await s.submitMembershipPayment(); let releasePreHidePayment
f.orderWork = async id => new Promise(resolve => { releasePreHidePayment = () => resolve({ data: receipt(id, { payment_recovery: { state: 'ready', message: 'PRE_HIDE_RESPONSE_APPLIED' } }) }) })
const preHidePayment = s.verifyPayment(); f.hides.forEach(fn => fn()); f.orderWork = async id => ({ data: receipt(id, { payment_recovery: { state: 'ready', message: 'CURRENT_VISIBLE_PAYMENT' } }) }); f.shows.forEach(fn => fn())
for (let i = 0; i < 8; i++) { await Promise.resolve(); await Vue.nextTick() }
releasePreHidePayment(); await preHidePayment
check(s.paymentMessage.value === 'CURRENT_VISIBLE_PAYMENT' && !s.checking.value && f.calls.filter(call => call[0] === 'order').length === 2, 'hide/show starts a current recovery and rejects the old same-account response instead of reviving it')
f = fixture('membership'); s = f.state; await s.refresh(); await s.submitMembershipPayment(); let releaseOldPayment, releaseCurrentPayment
f.orderWork = async id => new Promise(resolve => { releaseOldPayment = () => resolve({ data: receipt(id, { payment_recovery: { state: 'ready', message: 'OLD_BEFORE_REFRESH' } }) }) }); const oldPayment = s.verifyPayment()
f.orderWork = async id => new Promise(resolve => { releaseCurrentPayment = () => resolve({ data: receipt(id, { payment_recovery: { state: 'ready', message: 'CURRENT_AFTER_REFRESH' } }) }) }); const currentRefresh = s.refresh()
for (let i = 0; i < 5; i++) { await Promise.resolve(); await Vue.nextTick() }
releaseOldPayment(); await oldPayment
check(s.checking.value && s.paymentMessage.value !== 'OLD_BEFORE_REFRESH' && typeof releaseCurrentPayment === 'function', 'superseded recovery cannot clear the current request loading lock or paint stale state')
releaseCurrentPayment(); await currentRefresh
check(s.paymentMessage.value === 'CURRENT_AFTER_REFRESH' && !s.checking.value, 'current recovery alone releases its loading state after completion')
f = fixture('membership'); s = f.state; await s.refresh(); await s.submitMembershipPayment(); let releaseDisposedPayment
f.orderWork = async id => new Promise(resolve => { releaseDisposedPayment = () => resolve({ data: receipt(id, { payment_recovery: { state: 'ready', message: 'DISPOSED_RESPONSE' } }) }) }); const disposedPayment = s.verifyPayment(); f.cleanups.forEach(fn => fn()); releaseDisposedPayment(); await disposedPayment
check(s.paymentMessage.value !== 'DISPOSED_RESPONSE' && !s.checking.value, 'unmounted membership never accepts a late recovery response or leaves its loading state stuck')
f = fixture('membership'); s = f.state; f.quoteWork = async () => pendingQuote(); f.orderWork = async () => { throw { msg: '记录不存在，或不属于本站' } }; await s.refresh()
check(s.orderReadFailed.value && s.orderCheckKind.value === 'missing' && s.mainLabel.value === '重新核对付款单' && s.paymentMessage.value.includes('不会直接重新下单'), 'missing original receipt has a truthful retry action instead of a misleading renewal action')
await s.submitMembershipPayment(); check(s.order.value.id === 404 && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'retry that still reports a pending original receipt cannot drop it, create a duplicate or open the cashier')
f.orderWork = async id => ({ data: receipt(id) }); await s.submitMembershipPayment()
check(!s.orderReadFailed.value && s.mainLabel.value === '继续原单付款' && !f.cashier.length, 'successful retry restores the original unpaid action but does not automatically pay')
await s.submitMembershipPayment(); check(f.cashier.length === 1 && f.cashier[0][1] === 404 && !f.calls.some(call => call[0] === 'create-order'), 'a second explicit payment action uses the verified original order, never a new order')
f = fixture('membership'); s = f.state; f.quoteWork = async () => pendingQuote(); f.orderWork = async () => { throw { errMsg: 'request:fail timeout' } }; await s.refresh(); const quoteReadsBeforeRetry = f.calls.filter(call => call[0] === 'quote').length; await s.submitMembershipPayment()
check(s.orderReadFailed.value && s.orderCheckKind.value === 'unknown' && s.order.value.id === 404 && f.calls.filter(call => call[0] === 'quote').length === quoteReadsBeforeRetry && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'a network failure retries only the original read and cannot assume no pending order')
f.orderWork = async id => ({ data: receipt(id, { status: 'paid', requires_manual_review: true, review_message: '已收款待平台核对' }) }); await s.retryPaymentOrder()
check(!s.orderReadFailed.value && s.order.value.requires_manual_review && s.mainLabel.value === '已收款，需平台核对' && !f.cashier.length, 'retry preserves a real paid/manual-review lock instead of treating it as missing')
f = fixture('membership'); s = f.state; f.quoteWork = async () => pendingQuote(); f.orderWork = async () => { throw { msg: '记录不存在，或不属于本站' } }; await s.refresh(); f.quoteWork = async () => freshQuote(); await s.submitMembershipPayment()
check(!s.order.value.id && !s.orderReadFailed.value && s.quote.value.quote_token === 'fresh-verified-server-quote' && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'only an authoritative current-merchant quote with explicit no-pending-order releases the UI stub, without creating or paying anything')
await s.submitMembershipPayment(); check(f.calls.filter(call => call[0] === 'create-order').length === 1 && f.cashier.length === 1, 'a separately confirmed fresh quote may then create one new membership order')
f = fixture('membership'); s = f.state; f.quoteWork = async () => pendingQuote(); f.orderWork = async () => { throw { msg: '记录不存在，或不属于本站' } }; await s.refresh(); f.quoteWork = async () => ({ data: { ...freshQuote().data, merchant_id: 8 } }); await s.retryPaymentOrder()
check(s.orderReadFailed.value && s.order.value.id === 404 && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'another merchant quotation cannot release a missing original receipt')
f.quoteWork = async () => { const value = freshQuote().data; delete value.existing_order_id; return { data: value } }; await s.retryPaymentOrder()
check(s.orderReadFailed.value && s.order.value.id === 404, 'an omitted pending-order flag is not treated as authoritative absence')
f.orderWork = async id => ({ data: receipt(id, { status: 'paid' }) }); await s.retryPaymentOrder(); await s.submitMembershipPayment()
check(s.mainLabel.value === '支付已确认，返回' && f.navigations.at(-1) === 'back' && !f.cashier.length && !f.calls.some(call => call[0] === 'create-order'), 'retry that discovers a paid receipt returns safely without a new payment')
const combinedCost = (buy = false) => costParts({ deposit_balance:'0.00',deposit_amount:'100.00',experience_purchase_enabled:true,experience_unit_price:'2.00',buy_experience:buy,experience_quantity:buy?'120.00':'0.00',experience_amount:buy?'240.00':'0.00',payable_amount:buy?'439.00':'199.00' })
check(utility.membershipCosts(combinedCost(true))?.total==='439.00'&&utility.membershipCosts(combinedCost(false))?.experience==='0.00','three server-supplied cost components reconcile without inventing free membership or delivery counts')
check(!utility.membershipCosts({...combinedCost(true),payable_amount:'438.00'})&&!utility.membershipCosts({...combinedCost(false),experience_amount:'1.00'}),'unbalanced or silently charged experience cost is rejected')
check(utility.membershipCosts(costParts({buy_experience:true,experience_purchase_enabled:true,experience_unit_price:'2.00'}))?.quantity==='0.00','an explicitly selected supplement may become zero cost when the current gap has already closed')
f=fixture('membership');s=f.state;await s.refresh();f.membership={...s.summary.value,deposit_balance:'0.00',experience:{value:'0.00',earned_value:'0.00',purchased_value:'0.00',completed_orders:0},tiers:[{...baseTier,deposit_amount:'100.00',experience_eligible:false,experience_remaining:'120.00',experience_purchase_enabled:true,experience_unit_price:'2.00'}]}
f.quoteWork=async(code,cycle,buy)=>({data:{...freshQuote().data,...combinedCost(buy),level_code:code,cycle,can_purchase:buy,reason:buy?'':'经验不足，请自主选择是否补足'}});await s.refresh()
check(s.buyExperience.value===false&&s.experienceOffer.value&&s.mainLabel.value==='经验未达标'&&!s.quote.value.can_purchase&&f.calls.filter(call=>call[0]==='quote').at(-1)[3]===false,'experience purchase is opt-in and the initial server quote keeps the original experience gate')
await s.submitMembershipPayment();check(!f.calls.some(call=>call[0]==='create-order')&&!f.cashier.length,'not choosing the supplement cannot bypass the experience requirement')
s.selectExperience(true);for(let n=0;n<4;n++){await Promise.resolve();await Vue.nextTick()}
check(s.buyExperience.value&&s.quote.value.can_purchase&&s.displayedCosts.value.total==='439.00'&&s.mainLabel.value!=='经验未达标','an explicit supplement obtains a new signed three-part quotation before enabling payment')
f.createWork=async data=>({data:receipt(44,{...combinedCost(true),amount:'439.00',buy_experience:data.buy_experience})});await s.submitMembershipPayment()
check(f.calls.filter(call=>call[0]==='create-order').length===1&&f.calls.find(call=>call[0]==='create-order')[1].buy_experience===true&&f.cashier.length===1&&f.cashier[0][1]===44,'deposit, service and chosen experience are submitted once and use one framework payment')
s.selectExperience(false);check(s.buyExperience.value===true&&s.order.value.id===44,'a created receipt freezes its original experience option rather than silently changing the order')
check(!utility.quoteMatches({...freshQuote().data,...combinedCost(true)},7,'ML701','quarter',false)&&utility.quoteMatches({...freshQuote().data,...combinedCost(true)},7,'ML701','quarter',true),'a signed quotation cannot be reused with a different experience-purchase choice')
const transportCalls=[],entityTransport=moduleOf(read('api/entity.ts'),{'@/utils/request':{default:{get:(...args)=>transportCalls.push(['get',...args]),post:(...args)=>transportCalls.push(['post',...args])}}})
entityTransport.entityQuote('ML701','year');entityTransport.entityQuote('ML701','year',true);entityTransport.entityApplyDepositRefund('request_id_123','退出说明')
check(transportCalls[0][2].buy_experience===0&&transportCalls[1][2].buy_experience===1&&transportCalls[2][2].confirm===true&&transportCalls[2][2].request_id==='request_id_123','actual entity API encodes explicit supplement choice and confirmed deposit request without client-supplied refund amounts')
const recoveryCalls = [], recoveryTransport = moduleOf(read('api/cooperation.ts'), {'@/utils/request': { default: { post: (...args) => recoveryCalls.push(args) } } })
recoveryTransport.resumeCooperationOrder(35)
check(recoveryCalls.length === 1 && recoveryCalls[0][0] === 'hsx_lead/cooperation/orders/35/resume' && Object.keys(recoveryCalls[0][1]).length === 0, 'payment recovery uses an authenticated POST for the original ID and accepts no client amount or fake gateway status')
f=fixture('membership');s=f.state;await s.refresh();check(!f.calls.some(call=>call[0]==='deposit'),'collapsed exit controls do not add a background deposit request')
s.toggleDeposit([{name:'exit',status:'open'}]);for(let n=0;n<4;n++){await Promise.resolve();await Vue.nextTick()};check(s.depositLoaded.value&&s.depositInfo.value.balance==='100.00','opening exit controls reads the actual owner-scoped deposit summary')
await s.applyDeposit();check(s.depositInfo.value.request.status==='pending'&&s.depositFrozen.value&&f.calls.filter(call=>call[0]==='deposit-apply').length===1&&f.modals[0].content.includes('服务费及补足经验费用不退'),'explicit owner confirmation creates a pending review, not a completed refund')
await s.applyDeposit();await s.submitMembershipPayment();check(f.calls.filter(call=>call[0]==='deposit-apply').length===1&&!f.calls.some(call=>call[0]==='create-order'),'a pending exit request cannot be repeated or start a new membership payment')
f=fixture('membership');s=f.state;await s.refresh();f.deposit={merchant_id:7,is_owner:true,balance:'100.00',can_apply:false,blocking_reasons:[{key:'unfinished',title:'有未完成交付',count:1}],cooperation_exited:false,request:null};await s.loadDeposit();await s.applyDeposit();check(!f.modals.length&&!f.calls.some(call=>call[0]==='deposit-apply')&&s.depositInfo.value.blocking_reasons.length===1,'server blockers remain visible and stop an application before confirmation')
f=fixture('membership');s=f.state;await s.refresh();await s.loadDeposit();f.depositApplyWork=async()=>{throw{msg:'申请结果待核实'}};await s.applyDeposit();await s.applyDeposit();check(s.depositUncertain.value&&f.calls.filter(call=>call[0]==='deposit-apply').length===1&&f.calls.filter(call=>call[0]==='deposit').length===2,'an uncertain write triggers only a read-back and never a blind duplicate application')
f.deposit={merchant_id:7,is_owner:true,balance:'100.00',can_apply:false,blocking_reasons:[],cooperation_exited:false,request:{id:98,status:'refunding',status_name:'退款处理中',amount:'100.00',sources:[]}};await s.loadDeposit();check(!s.depositUncertain.value&&s.depositFrozen.value&&s.depositInfo.value.request.status==='refunding','authoritative read-back resolves uncertainty without calling processing a successful refund')
f=fixture('membership');s=f.state;await s.refresh();await s.loadDeposit();f.deferModal=true;const exitConfirm=s.applyDeposit();f.token='different-account';f.modals.at(-1).success({confirm:true});await exitConfirm;check(!f.calls.some(call=>call[0]==='deposit-apply'),'an account switch while the exit confirmation is open cannot submit for the new login')
check(read('components/cooperation/CoopExperienceProgress.vue').includes('真实付佣')&&read('components/cooperation/CoopExperienceProgress.vue').includes('补足经验')&&!read('components/cooperation/CoopExperienceProgress.vue').includes('交付成长'),'visible experience sources do not describe bought experience as real delivery performance')
f=fixture('membership');s=f.state;await s.refresh();f.membership={...s.summary.value,active:false,cooperation_exited:true,expires_at:Math.floor(Date.now()/1000)+86400};await s.refresh()
check(s.currentMembershipCaption.value==='协作已暂停'&&s.currentTierStatus.value==='协作暂停'&&!s.currentMembershipCaption.value.includes('到期'),'an exit pause does not mislabel an unexpired paid membership as expired')
f.deposit={merchant_id:7,is_owner:true,balance:'100.00',can_apply:false,blocking_reasons:[],cooperation_exited:true,request:{id:100,status:'pending',status_name:'待审核',amount:'100.00',sources:[]}};await s.loadDeposit();check(s.currentMembershipCaption.value==='退押金申请审核中','deposit request detail gives a specific non-expiry pause message')
f=fixture('membership');s=f.state;await s.refresh();await s.submitMembershipPayment();f.deferModal=true;const oldCancel=s.closeOrder();f.token='synthetic-new-owner';f.quoteWork=async()=>pendingQuote(77);f.orderWork=async id=>({data:receipt(id)});await s.refresh();f.modals.at(-1).success({confirm:true});await oldCancel
check(s.order.value.id===77&&!f.calls.some(call=>call[0]==='close-order'),'an old cancellation confirmation cannot cancel the new login original payment order')
f=fixture('membership');s=f.state;await s.refresh();await s.loadDeposit();f.deferModal=true;const priorEntityExit=s.applyDeposit();f.membership={...s.summary.value,merchant_id:8};await s.refresh();f.modals.at(-1).success({confirm:true});await priorEntityExit
check(!f.calls.some(call=>call[0]==='deposit-apply'),'an old exit confirmation cannot apply against another entity even when the login token remains the same')
f=fixture('membership');s=f.state;await s.refresh();f.membership={...s.summary.value,cost_review_required:true,cost_review_message:'存在已收款但会员业务尚未核对的付款单，请联系平台处理原单，暂不重复收费或退押金',tiers:[{...baseTier,experience_eligible:false}]};await s.refresh();await s.loadDeposit();await s.submitMembershipPayment();await s.applyDeposit()
check(s.summary.value.cost_review_message.includes('已收款')&&s.mainLabel.value==='款项待核对'&&!f.calls.some(call=>call[0]==='create-order'||call[0]==='deposit-apply')&&!f.cashier.length,'a successful but unreconciled receipt blocks new membership/deposit instructions without mislabeling it as insufficient experience')
check(read('pages/membership/index.vue').includes('summary.cost_review_message ||')&&read('pages/membership/index.vue').includes('重新核对付款与权益'),'the actual membership template shows the authoritative funding warning and an explicit read-only retry')
f=fixture('membership');s=f.state;await s.refresh();await s.submitMembershipPayment();const cashierBeforeFundingReview=f.cashier.length;f.membership={...s.summary.value,cost_review_required:true,cost_review_message:'原收款待核对'};await s.refresh();await s.submitMembershipPayment()
check(s.order.value.id===22&&s.mainLabel.value==='款项待核对'&&f.cashier.length===cashierBeforeFundingReview&&f.calls.filter(call=>call[0]==='create-order').length===1,'a funding-review lock preserves the existing order and cannot continue paying through its old unpaid action')
console.log(`PASS ${checks} subject/member mobile checks; real Vue setup, lifecycle and pure helpers, synthetic API/cashier/modal/clipboard only; no live HTTP, payment or database action.`)
