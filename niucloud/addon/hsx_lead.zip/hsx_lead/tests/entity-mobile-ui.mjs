import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { loadFrameworkInvite } from './framework-invite.mjs'
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), require = createRequire(path.join(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), sass = require('sass')
const read = file => fs.readFileSync(path.join(plugin, 'uni-app', file), 'utf8')
let checks = 0
const check = (ok, message) => { assert.ok(ok, message); checks++ }
function moduleOf(source, deps, globals = {}) {
    const module = { exports: {} }, js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Number, String, Boolean, Object, Array, Map, Set, Promise, Math, JSON, console, ...globals })(key => {
        if (key in deps) return deps[key]
        if (key.endsWith('.vue')) return { default: {} }
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        throw Error('Unexpected test dependency ' + key)
    }, module, module.exports)
    return module.exports
}
function parse(file) {
    const descriptor = compiler.parse(read(file), { filename: file }).descriptor, script = compiler.compileScript(descriptor, { id: 'entity-test' })
    check(!compiler.compileTemplate({ source: descriptor.template.content, filename: file, id: 'entity-test', compilerOptions: { bindingMetadata: script.bindings } }).errors.length, file + ' real template compiles')
    for (const style of descriptor.styles) { check(style.scoped, file + ' owns its CSS'); check(!compiler.compileStyle({ source: style.lang === 'scss' ? sass.compileString(style.content).css : style.content, filename: file, id: 'entity-test', scoped: true }).errors.length, file + ' style compiles') }
    return script.content
}
const scripts = Object.fromEntries(['pages/entity/index.vue', 'pages/membership/index.vue', 'components/cooperation/CoopMembershipEntry.vue'].map(file => [file, parse(file)]))
const utility = loadMobileUtility('entity-membership')
for (const value of ['S', 'A', 'premium', 4, true, 'V1', 'V5', 'ML0', 'ML-2']) check(utility.entityLevel(value) === '', 'old/arbitrary identity is not a framework membership: ' + value)
check(utility.entityLevel('ML708') === 'ML708' && utility.membershipState({ level_code: 'ML708', active: false }) === 'expired', 'arbitrary framework level supports an expired badge')
check(utility.entityAccounts({ account_limit: 2 }) === '2 人' && utility.entityAccounts({ unlimited: true }) === '不限人数', 'account count and unlimited are explicit')
check(utility.entityPageLink('S-AB12').includes('subject_code=S-AB12') && !utility.entityPageLink('S-AB12').includes('mid='), 'subject invitations do not reuse personal promotion IDs')
const baseTier = { code: 'ML701', name: '合成等级1', rank: 1, display_rank: 1, enabled: true, account_limit: 1, unlimited: false, cycles: [{ key: 'month', name: '月付', months: 1, enabled: false, price: '0.00' }, { key: 'quarter', name: '季付', months: 3, enabled: true, price: '39.00' }, { key: 'year', name: '年付', months: 12, enabled: true, price: '99.00' }], benefits: [{ key: 'can_publish', title: '发布客户需求', desc: '按门店共用', icon: 'order', enabled: true }] }
const testTiers = Array.from({ length: 8 }, (_, index) => ({ ...baseTier, code: `ML${701 + index}`, name: `合成等级${index + 1}`, rank: index + 1, display_rank: index + 1, account_limit: index + 1 }))
const receipt = (id, extra = {}) => ({ id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'unpaid', amount: '99.00', ...extra })
function fixture(page) {
    let token = 'synthetic-member-a', site = 100005, membership = { merchant_id: 7, level_code: 'ML701', level_name: '合成等级1', display_rank: 1, active: true, expires_at: 1900000000, can_manage: true, is_owner: true, account_limit: 1, used_accounts: 1, tiers: testTiers }, team = { merchant_id: 0, name: '', members: [], pending_entity: null }
    const calls = [], shows = [], hides = [], loads = [], shares = [], cleanups = [], cashier = [], navigations = [], copies = [], modals = []
    let deferModal = false, pendingRead = null, quoteWork = null, orderWork = null, createWork = null
    const quoteData = () => ({ purpose: 'membership', merchant_id: 7, level_code: state.selected.value, level_name: '会员', cycle: state.cycle.value, can_purchase: true, full_amount: '199.00', credit_amount: '100.00', payable_amount: '99.00', period_start_at: 1800000000, period_end_at: 1900000000, quote_token: 'signed-by-server', expires_at: Math.floor(Date.now() / 1000) + 600 })
    const api = {
        entityMembership: async () => { calls.push(['membership']); return pendingRead ? pendingRead() : { data: membership } },
        entityTeam: async () => { calls.push(['team']); return pendingRead ? pendingRead() : { data: team } },
        entityLookup: async code => { calls.push(['lookup', code]); return { data: { merchant_id: 7, name: '合成门店' } } },
        entityJoin: async code => { calls.push(['join', code]); team = { merchant_id: 0, pending_entity: { merchant_id: 7, name: '合成门店', status: 'pending' } }; return { data: team } },
        entityReview: async (...args) => { calls.push(['review', ...args]); return { data: {} } },
        entityRemove: async (...args) => { calls.push(['remove', ...args]); return { data: {} } },
        entityLeave: async () => { calls.push(['leave']); team = { merchant_id: 0, pending_entity: null }; return { data: {} } },
        entityQuote: async (...args) => { calls.push(['quote', ...args]); return quoteWork ? quoteWork(...args) : { data: quoteData() } },
        entityCloseOrder: async id => { calls.push(['close-order', id]); return { data: {} } },
    }
    const common = { getToken: () => token, getSiteId: () => site }, runtime = {
        getStorageSync: () => site, showToast() {}, showModal: data => { modals.push(data); if (!deferModal) data.success({ confirm: true }) },
        navigateTo: data => navigations.push(data), setClipboardData: data => copies.push(data.data),
    }
    const helpers = moduleOf(read('api/cooperation.ts'), { '@/utils/request': { default: {} } })
    const lifecycle = { onLoad: fn => loads.push(fn), onShow: fn => shows.push(fn), onHide: fn => hides.push(fn), onShareAppMessage: fn => shares.push(fn) }
    const hooks = { ...Vue, onBeforeUnmount: fn => cleanups.push(fn) }
    const controller = moduleOf(read('composables/useEntityPage.ts'), { vue: hooks, '@/utils/common': common, '../api/cooperation': helpers }, { uni: runtime })
    const deps = {
        vue: hooks, '@dcloudio/uni-app': lifecycle, '@/utils/common': common, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: data => calls.push(['login', data]) }) },
        '../../api/entity': api, '../../api/cooperation': { ...helpers,
            cooperationOrder: async id => { calls.push(['order', id]); return orderWork ? orderWork(id) : { data: receipt(id) } },
            createCooperationOrder: async data => { calls.push(['create-order', data]); return createWork ? createWork(data) : { data: receipt(22, { level_code: data.level_code, cycle: data.cycle, entitlement_months: membership.tiers.find(tier => tier.code === data.level_code)?.cycles.find(c => c.key === data.cycle)?.months }) } },
        }, '../../composables/useEntityPage': controller,
        '../../utils/cooperation-navigation': { backCooperationTask: () => navigations.push('back') },
        '../../utils/cooperation-invite': loadFrameworkInvite(runtime),
    }
    const state = moduleOf(scripts[`pages/${page}/index.vue`], deps, { uni: runtime }).default.setup({}, { expose() {} })
    if (state.payRef) state.payRef.value = { open: (...args) => cashier.push(args) }
    return { state, calls, cashier, navigations, copies, modals, shows, hides, loads, shares, cleanups, set token(v) { token = v }, set site(v) { site = v }, set team(v) { team = v }, set membership(v) { membership = v }, set pendingRead(v) { pendingRead = v }, set deferModal(v) { deferModal = v }, set quoteWork(v) { quoteWork = v }, set orderWork(v) { orderWork = v }, set createWork(v) { createWork = v } }
}
let f = fixture('entity'), s = f.state
f.loads.forEach(fn => fn({ mode: 'join', subject_code: ' abc12 ' })); await s.refresh()
check(s.code.value === 'ABC12' && f.calls.every(call => call[0] !== 'lookup'), 'invitation prefills code but never silently sends a joining request')
await s.lookup(); check(f.calls.at(-1)[0] === 'lookup' && s.found.value.name === '合成门店', 'explicit lookup returns a named door before joining')
await s.join(); check(s.team.value.pending_entity.status === 'pending' && !s.team.value.merchant_id, 'submitting join is pending, never active rights')
await s.leave(); check(!s.team.value.pending_entity && f.calls.some(call => call[0] === 'leave'), 'pending applicant can explicitly withdraw')
f.team = { merchant_id: 7, name: '合成门店', subject_code: 'SUBJ1234', is_owner: true, members: [{ member_id: 1, role: 'owner', status: 'active' }, { member_id: 2, nickname: '新同事', role: 'member', status: 'pending' }], membership: { account_limit: 2, used_accounts: 1, unlimited: false } }; await s.refresh(); s.copyCode()
check(f.copies.at(-1) === 'SUBJ1234' && f.shares[0]().path.includes('subject_code=SUBJ1234'), 'owner code is copied/shared through the actual registered native page')
check(s.hasCapacity.value, 'unfilled membership has capacity including its owner')
s.team.value.membership.used_accounts = 2; await s.review({ member_id: 2 }, true)
check(!s.hasCapacity.value && !f.calls.some(call => call[0] === 'review') && s.state.writeError.value.includes('名额已满'), 'full membership blocks approval before confirmation with a clear upgrade/remove reason')
s.team.value.membership.unlimited = true; check(s.hasCapacity.value, 'explicit unlimited membership remains eligible with any used count')
s.team.value.membership.unlimited = false; s.team.value.membership.used_accounts = 1
f.deferModal = true; const first = s.review({ member_id: 2, nickname: '新同事' }, true), second = await s.review({ member_id: 2 }, true)
check(f.modals.length === 2 && !f.calls.some(call => call[0] === 'review'), 'one extra owner confirmation is open; repeated approval does not send a write')
f.modals.at(-1).success({ confirm: true }); await first
check(f.calls.filter(call => call[0] === 'review').length === 1, 'approval sends one actual owner-scoped request')
f.team = { merchant_id: 7, is_owner: false, members: [] }; await s.refresh(); const before = f.calls.length; await s.review({ member_id: 3 }, true); await s.remove({ member_id: 3 }); s.copyCode()
check(f.calls.length === before && f.copies.length === 1, 'member UI does not attempt owner approval/removal or expose the code')
let release; f.pendingRead = () => new Promise(resolve => { release = resolve }); const readOld = s.refresh(); f.token = 'synthetic-member-b'; release({ data: { merchant_id: 99, subject_code: 'private-old' } }); await readOld
check(s.team.value.merchant_id !== 99, 'late old-account read cannot show another entity')
let staleWrite = false; const rejectedWrite = await s.state.write(async () => { staleWrite = true; return { data: {} } })
check(rejectedWrite === null && !staleWrite, 'old form cannot establish write authorization for a new login without a fresh read')

f = fixture('membership'); s = f.state; await s.refresh()
check(s.summary.value.level_code === 'ML701' && s.quote.value.payable_amount === '99.00' && f.calls.filter(call => call[0] === 'quote').length === 1, 'member page reads actual framework rights and one server-owned fee quotation')
check(s.tiers.value.length === 8 && s.tiers.value.at(-1).rank === 8 && s.cycles.value.length === 2 && s.cycle.value === 'quarter', 'eight framework tiers render; disabled monthly price is absent and first enabled quarter is selected')
const beforeDisabledCycle = f.calls.length; s.selectCycle('month'); check(f.calls.length === beforeDisabledCycle && s.cycle.value === 'quarter', 'disabled cycle never issues a quotation')
check(utility.membershipBenefits({ benefits: [{ key: 'dynamic', title: '后台权益', enabled: false, icon: 'unsafe-path' }] })[0].icon === 'checkmark-circle', 'dynamic benefit icons use a bounded local whitelist')
await s.submitMembershipPayment(); check(f.cashier.length === 1 && f.cashier[0][0] === 'hsx_lead_cooperation' && f.cashier[0][1] === 22, 'confirmed order uses the existing framework cashier contract')
check(f.calls.find(call => call[0] === 'create-order')[1].quote_token === 'signed-by-server', 'cashier order creation sends the exact quoted contract, no client price')
f.orderWork = async () => { throw { msg: '原单状态暂未核实' } }; await s.submitMembershipPayment()
check(f.cashier.length === 1 && s.paymentMessage.value === '原单状态暂未核实', 'failed refresh cannot reopen cashier from a stale unpaid result')
f.orderWork = async id => ({ data: { id, merchant_id: 8, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'unpaid', amount: '99.00' } }); await s.submitMembershipPayment()
check(f.cashier.length === 1 && s.paymentMessage.value.includes('不一致'), 'another entity payment response is rejected before cashier')
f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'paid', amount: '99.00', requires_manual_review: true, review_message: '真实收款待核对' } }); await s.verifyPayment()
check(s.paymentMessage.value === '真实收款待核对' && s.paymentLocked.value, 'paid-but-ungranted result remains explicit and cannot be shown as active success')
await s.submitMembershipPayment(); check(f.cashier.length === 1, 'manual-review receipt cannot reopen the cashier')
f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'paid', quote_expired: true, amount: '99.00' } }); await s.verifyPayment()
check(!s.paymentLocked.value && s.mainLabel.value.includes('支付已确认'), 'completed receipt is not labeled as an uncertain pending order')
await s.submitMembershipPayment(); check(f.navigations.at(-1) === 'back' && f.cashier.length === 1, 'completed payment returns without paying again even after quotation time has elapsed')
f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'paid', amount: '99.00', membership_refund_status: 'refunded' } }); await s.verifyPayment()
check(s.paymentMessage.value.includes('原单已退款') && !s.paymentMessage.value.includes('权益已更新') && s.mainLabel.value === '退款已确认，返回', 'full refund is not mislabeled as a fresh successful activation even though the original receipt remains paid')
await s.submitMembershipPayment(); check(f.navigations.at(-1) === 'back' && f.cashier.length === 1, 'refunded paid receipt only returns and never reopens payment')

f = fixture('membership'); s = f.state; f.loads.forEach(fn => fn({ payment_order_id: '35' })); f.orderWork = async id => ({ data: { id, merchant_id: 7, purpose: 'membership', level_code: 'ML701', cycle: 'quarter', entitlement_months: 3, status: 'unpaid', amount: '99.00', quote_expired: true } }); await s.refresh()
check(s.order.value.id === 35 && s.paymentMessage.value.includes('过期'), 'cashier return retains the original order and reads expired result')
await s.submitMembershipPayment(); check(!f.cashier.length, 'expired original quote cannot continue paying')
await s.closeOrder(); check(f.calls.some(call => call[0] === 'close-order' && call[1] === 35) && !s.order.value.id, 'only explicitly confirmed cancellation clears the pending order then rereads quotation')

f = fixture('membership'); s = f.state; await s.refresh(); f.createWork = async () => { throw { msg: '结果待核实' } }; await s.submitMembershipPayment(); await s.submitMembershipPayment()
const sent = f.calls.filter(call => call[0] === 'create-order')
check(sent.length === 2 && sent[0][1].request_id === sent[1][1].request_id && !f.cashier.length, 'uncertain creation reuses one idempotency key instead of manufacturing another payment')
f = fixture('membership'); s = f.state; f.membership = { merchant_id: 7, level_code: 'ML702', can_manage: false, active: true, tiers: [baseTier] }; await s.refresh(); await s.submitMembershipPayment()
check(!f.calls.some(call => ['quote', 'create-order'].includes(call[0])) && !f.cashier.length, 'ordinary employees read shared membership without purchasing or entering cashier')
f = fixture('membership'); s = f.state; f.membership = { merchant_id: 7, can_manage: true, tiers: [{ ...testTiers[7], cycles: [{ key: 'activity_6', name: '活动半年卡', months: 6, enabled: true, price: '66.00' }] }] }; await s.refresh()
check(s.selected.value === 'ML708' && s.cycle.value === 'activity_6' && s.cycles.value[0].name === '活动半年卡', 'custom activity duration is supplied by the actual catalog without a month/year whitelist')
await s.submitMembershipPayment(); check(f.cashier.length === 1 && f.calls.find(call => call[0] === 'create-order')[1].cycle === 'activity_6', 'custom cycle reaches the framework cashier through the same server quotation contract')
f = fixture('membership'); s = f.state; f.membership = { merchant_id: 7, can_manage: true, tiers: [{ ...baseTier, cycles: baseTier.cycles.map(cycle => ({ ...cycle, enabled: false })) }] }; await s.refresh(); await s.submitMembershipPayment()
check(!s.cycle.value && !f.calls.some(call => ['quote', 'create-order'].includes(call[0])) && !f.cashier.length, 'a tier with all periods disabled displays no purchasable cycle and cannot create a payment')
check(read('pages/profile/index.vue').includes('加入已有门店') && read('pages/profile/index.vue').includes('pendingEntity'), 'personal page has both onboarding and pending-approval entry')
check(!read('pages/task/index.vue').includes("name === 'plans'"), 'retired standalone subscription task is not kept as a second membership entry')
check(read('pages/membership/index.vue').includes("import Pay from '@/components/pay/pay.vue'"), 'membership explicitly registers the existing framework cashier on native platforms')
check(read('pages/membership/index.vue').includes('v-if="chosen && summary.can_manage && !order.id"'), 'a returned payment shows the original receipt rather than a duplicate fee panel stuck on loading copy')
const memberDescriptor = compiler.parse(read('pages/membership/index.vue')).descriptor
const memberBindings = compiler.compileScript(memberDescriptor, { id: 'actual-member-bindings' }).bindings
const dom = compiler.compileTemplate({ source: memberDescriptor.template.content, filename: 'membership.vue', id: 'actual-member-bindings', compilerOptions: { bindingMetadata: memberBindings } })
const ssr = compiler.compileTemplate({ source: memberDescriptor.template.content, filename: 'membership.vue', id: 'actual-member-bindings', ssr: true, ssrCssVars: [], compilerOptions: { bindingMetadata: memberBindings } })
check(!dom.errors.length && dom.code.includes('$setup["Pay"]') && !dom.code.includes('_createVNode($setup["submitMembershipPayment"]'), 'real H5 component bindings resolve cashier to imported Pay, not the submit action')
check(!ssr.errors.length && ssr.code.includes('$setup["Pay"]') && !ssr.code.includes('_ssrRenderComponent($setup["submitMembershipPayment"]'), 'real SSR component bindings do not invoke an async payment action during rendering')
check(read('pages/entity/index.vue').includes(':disabled="locked || !hasCapacity"') && read('pages/entity/index.vue').includes('账号名额已满，升级会员或移除成员后可继续加入'), 'full-seat native approval is visibly disabled with a readable recovery path')
console.log(`PASS ${checks} subject/member mobile checks; real Vue setup, lifecycle and pure helpers, synthetic API/cashier/modal/clipboard only; no live HTTP, payment or database action.`)
