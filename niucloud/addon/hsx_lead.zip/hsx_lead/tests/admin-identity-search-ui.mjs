import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),ts=require('typescript'),compiler=require('@vue/compiler-sfc')
const read=name=>fs.readFileSync(path.join(plugin,name),'utf8')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
const cleanup=[]
const source=ts.transpileModule(read('admin/composables/useLeadUi.ts'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
const module={exports:{}}
vm.runInNewContext(`(function(require,module,exports){${source}\n})`,{console,Date,Number,String,Array,Math,Promise})(key=>{if(key!=='vue')throw Error('Unexpected dependency '+key);return{...Vue,onBeforeUnmount:fn=>cleanup.push(fn)}},module,module.exports)
let response={data:{data:[],total:0}},calls=[]
let work=async()=>response
const list=module.exports.useLeadList(async query=>{calls.push(query);return work(query)})
await list.load();check(list.rows.value.length===0&&list.total.value===0&&!list.error.value&&!list.loading.value,'genuine empty response remains a successful empty state')
response={data:{data:[{id:1}],total:1}};await list.load();check(list.rows.value[0].id===1&&list.total.value===1,'valid rows render')
for(const invalid of [undefined,null,{}, {data:null},{data:{}},{data:{data:[],total:null}},{data:{data:[],total:''}},{data:{data:[],total:'  '}},{data:{data:[],total:-1}},{data:{data:[],total:'bad'}},{data:{data:[],total:1.5}},{data:{data:{},total:0}},{data:{data:[],total:true}},{data:{data:[],total:[]}}]){
    response=invalid;await list.load();check(list.error.value.includes('列表格式不完整')&&list.rows.value.length===0&&list.total.value===0&&!list.loading.value,'malformed list is an explicit error, never a successful empty result')
}
response={data:{data:[],total:'0'}};await list.load();check(!list.error.value&&list.total.value===0,'numeric JSON count strings remain compatible')
list.query.page=4;list.query.keyword='18800000001';await list.search();check(calls.at(-1).page===1&&calls.at(-1).keyword==='18800000001','search submits the current keyword and resets pagination')
let firstResolve,secondResolve
work=query=>new Promise(resolve=>{if(query.keyword==='old')firstResolve=resolve;else secondResolve=resolve})
list.query.keyword='old';const old=list.load();list.query.keyword='new';const current=list.load()
check(list.loading.value&&!list.error.value,'pending query has an explicit loading state')
secondResolve({data:{data:[{id:2}],total:1}});await current;firstResolve({data:{data:{},total:0}});await old
check(list.rows.value[0].id===2&&!list.error.value&&!list.loading.value,'late malformed response cannot overwrite a newer success')
let unmountResolve;work=()=>new Promise(resolve=>{unmountResolve=resolve});const unmount=list.load();cleanup.forEach(fn=>fn());unmountResolve({data:{data:[{id:3}],total:1}});await unmount
check(list.rows.value[0].id===2,'unmounted list does not accept late rows')
for(const name of ['admin/views/cooperation/Leads.vue','admin/views/cooperation/Entities.vue','admin/views/cooperation/Orders.vue','admin/views/promotion/PromotionInviters.vue']){
    const parsed=compiler.parse(read(name),{filename:name});check(parsed.errors.length===0,name+' parses')
    compiler.compileScript(parsed.descriptor,{id:'admin-search'})
    check(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:name,id:'admin-search',compilerOptions:{expressionPlugins:['typescript']}}).errors.length===0,name+' compiles')
}
check(read('admin/views/cooperation/Orders.vue').includes('付款会员或手机号'),'payment search advertises the actual payer lookup')
check(read('admin/views/promotion/PromotionInviters.vue').includes('手机号或 ID'),'promoter search advertises exact member ID')
for(const name of ['admin/composables/useLeadUi.ts','admin/views/cooperation/Orders.vue','admin/views/promotion/PromotionInviters.vue'])check(read(name)===fs.readFileSync(path.resolve(plugin,'../../../admin/src/addon/hsx_lead',name.slice(6)),'utf8'),name+' installed mirror matches')
console.log(`PASS ${checks} admin identity-search/list-contract UI checks; real Vue state and SFC compiler, synthetic reads only; no backend, database or payment calls.`)
