/** Inactive supplement fixture for existing UI suites whose focus is elsewhere. */
export const profileConfigFixture = () => ({ version: 'synthetic-profile-schema', fields: { storefront_image: { visible: true, required: false, sort: 0 }, business_license: { visible: true, required: false, sort: 1 } }, extra_form: { enabled: false, form_id: 0 } })
export const profileConfigApi = { getCooperationProfileForm: async () => ({ data: profileConfigFixture() }), coopError: (cause, fallback) => cause?.message || fallback }
