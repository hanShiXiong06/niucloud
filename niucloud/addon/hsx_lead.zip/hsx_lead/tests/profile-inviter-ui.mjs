import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'
import { profileConfigApi } from './profile-config-fixture.mjs'

// Actual Vue setup/API state with local transport and clipboard doubles only.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript'), sass = require('sass')
const preprocess = require('@dcloudio/uni-cli-shared/dist/preprocess')
const storage = new Map(), events = [], copies = [], notices = [], read = file => fs.readFileSync(path.join(plugin, file), 'utf8')
let checks = 0, copyFails = false
const check = (value, label) => { assert.ok(value, label); checks++ }
const uni = {
    getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, value), removeStorageSync: key => storage.delete(key),
    setClipboardData: options => { copies.push(options.data); (copyFails ? options.fail : options.success)?.() },
    showToast: value => notices.push(value)
}
function execute(source, dependencies) {
    const module = { exports: {} }
    const code = ts.transpileModule(viteFixture(source), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + code + '\n})', { Date, Math, String, Number, Object, Array, Promise, Map, Set, JSON, uni, console })(key => {
        if (key === 'vue') return Vue
        if (key in dependencies) return dependencies[key]
        if (key.endsWith('.vue')) return { default: {} }
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        throw Error('Unexpected dependency ' + key)
    }, module, module.exports)
    return module.exports
}
function component(file, dependencies = {}) {
    const parsed = compiler.parse(read(file), { filename: file }), script = compiler.compileScript(parsed.descriptor, { id: 'profile-inviter-ui' })
    check(!parsed.errors.length && !compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'profile-inviter-ui', compilerOptions: { bindingMetadata: script.bindings } }).errors.length, file + ' compiles')
    for (const style of parsed.descriptor.styles) if (style.lang === 'scss') sass.compileString(style.content, { loadPaths: [path.join(plugin, 'uni-app/components/cooperation')], logger: { warn() {}, debug() {} } })
    return { definition: execute(script.content, dependencies).default, template: parsed.descriptor.template.content }
}
async function flush() { for (let index = 0; index < 6; index++) { await Promise.resolve(); await Vue.nextTick() } }
const profileFile = 'uni-app/components/cooperation/CoopProfilePanel.vue'
const profileComponent = component(profileFile, { '../../api/cooperation': profileConfigApi, '@/utils/common': { img: value => value } })
function profileSetup(overrides = {}) {
    const props = Vue.reactive({
        profile: {}, member: {}, config: { businesses: [] }, providers: [], editing: true, onboarding: true,
        onboardingInviter: { editable: true, locked: false, current_inviter: null, outcome: null, message: '' },
        page: true, busy: false, displayOnly: false, section: 'all', appearance: {}, ...overrides
    })
    const state = profileComponent.definition.setup(props, { emit: (...args) => events.push(args), expose() {} })
    Object.assign(state.form, { name: '合成测试门店', contact_name: '测试联系人', mobile: '13900000000', province_id: 1, city_id: 2, district_id: 3, address: '合成地址' })
    return { state, props }
}
const first = profileSetup()
await flush()
check(first.state.inviterEditable.value && !first.state.inviterHelpOpen.value, 'only server-authorized first onboarding has the optional field; explanation starts collapsed')
first.state.form.inviter_member_no = ' 0001 '
first.state.submit()
check(events.at(-1)[1].inviter_member_no === '0001', 'first save sends the exact string and preserves leading zeroes')
first.state.form.inviter_member_no = ''
first.state.submit()
check(events.at(-1)[1].inviter_member_no === '' && !first.state.localError.value, 'empty promotion ID never blocks an otherwise valid profile')
first.state.form.inviter_member_no = 'not-a-real-number'
first.state.submit()
check(events.at(-1)[1].inviter_member_no === 'not-a-real-number' && !first.state.localError.value, 'the server resolves unavailable/invalid optional IDs without a frontend hard failure')
first.state.form.inviter_member_no = 'PREFIX-00000001'
first.state.submit()
check(events.at(-1)[1].inviter_member_no === 'PREFIX-00000001', 'framework-configured prefixes are not stripped, parsed as numbers or padded')
const count = events.length
first.props.busy = true; first.state.submit()
check(events.length === count, 'profile submission stays locked while the existing write is pending')
// A successful save returns the canonical profile. Do not rely on the removed
// shared anonymous draft to reconstruct fields from an ID-only fake response.
first.props.busy = false; first.props.profile = { ...first.state.form, id: 7 }; await flush()
check(!first.state.inviterEditable.value && first.state.form.inviter_member_no === '', 'successful first save removes editability and clears the old invitation draft field')
first.state.form.inviter_member_no = '0002'; first.state.submit()
check(!Object.hasOwn(events.at(-1)[1], 'inviter_member_no'), 'subsequent merchant saves never send a hidden or manipulated invitation field')
const locked = profileSetup({ onboardingInviter: { editable: true, locked: true, current_inviter: { name: '原邀请人', member_no: '0001' } } })
await flush()
locked.state.form.inviter_member_no = '0002'; locked.state.submit()
check(!locked.state.inviterEditable.value && !Object.hasOwn(events.at(-1)[1], 'inviter_member_no'), 'an existing locked relationship is not overwritten by stale form input')
const alreadyBound = profileSetup({ onboardingInviter: { editable: true, locked: false, current_inviter: { name: '扫码邀请人', member_no: '0001' } } })
await flush()
alreadyBound.state.form.inviter_member_no = '0002'; alreadyBound.state.submit()
check(!alreadyBound.state.inviterEditable.value && !Object.hasOwn(events.at(-1)[1], 'inviter_member_no'), 'an existing inviter hides and omits replacement input even when an older server says the first form is editable')
const missing = profileSetup({ onboardingInviter: {} })
await flush()
missing.state.submit()
check(!missing.state.inviterEditable.value && !Object.hasOwn(events.at(-1)[1], 'inviter_member_no'), 'an older or missing backend permission contract safely hides and omits the input')
const employee = profileSetup({ profile: { id: 7, permissions: { can_manage_billing: false } } })
const beforeEmployee = events.length; employee.state.submit()
check(!employee.state.canEdit.value && events.length === beforeEmployee, 'staff cannot use onboarding to create or rebind another merchant')
check(profileComponent.template.includes('type="text" maxlength="255"') && profileComponent.template.includes(':custom-style="cooperationInputStyle"'), 'invitation input reuses the framework text input and real member-number capacity')
check(profileComponent.template.includes('v-if="inviterHelpOpen"') && profileComponent.template.includes('查看推广ID填写说明'), 'explanation has an explicit accessible touch target rather than always occupying the form')

const account = { member_id: 11, member_no: '0001', name: '合成会员' }
let authenticated = true
const promotionState = {
    overview: Vue.ref({ member: account, role: 'normal', promotion_allowed: true, share: { path: '/synthetic-invite' }, rules: {}, stats: {} }),
    ready: Vue.ref(true), loading: Vue.ref(false), saving: Vue.ref(false), application: Vue.ref({}),
    resume: () => authenticated, stop() {}, reload: async () => true, loadTeam: async () => true
}
const panel = component('uni-app/components/cooperation/CoopPromotionPanel.vue', {
    '@dcloudio/uni-app': { onHide() {} }, '@/utils/common': { redirect() {} }, '@/hooks/useShare': { useShare: () => ({ setShare() {} }) },
    '@/stores/system': { default: () => ({ site: {}, shareOptions: {}, $patch() {} }) },
    '../../composables/usePromotion': { usePromotion: () => promotionState }, '../../api/cooperation': { coopDate() {}, coopMoney() {} }
})
const promotionProps = Vue.reactive({ show: false, page: true, initialTab: 'overview' })
const promotion = panel.definition.setup(promotionProps, { emit() {}, expose() {} })
promotionProps.show = true; await flush()
check(promotion.promotionId.value === '0001', 'ordinary unpaid members display their own real framework number as promotion ID')
promotion.copyPromotionId()
check(copies.at(-1) === '0001' && notices.at(-1).title === '推广 ID 已复制', 'copy writes only the exact promotion ID, not a merchant subject code or numeric database ID')
promotionState.overview.value = { ...promotionState.overview.value, role: 'provider', member: { ...account, member_no: 'VIP000001' } }
promotion.copyPromotionId()
check(copies.at(-1) === 'VIP000001', 'service providers reuse the same framework promotion identifier including configured prefixes')
promotionState.overview.value = { ...promotionState.overview.value, member: { member_id: 777, subject_code: 'ABCD234567' } }
const beforeMissing = copies.length; promotion.copyPromotionId()
check(!promotion.promotionId.value && copies.length === beforeMissing, 'missing member_no does not fabricate an ID or fall back to a staff-join subject code')
promotionState.overview.value = { ...promotionState.overview.value, member: account }
authenticated = false; promotion.copyPromotionId()
check(copies.length === beforeMissing, 'logout or identity replacement blocks copying stale account data')
authenticated = true; promotionState.loading.value = true; promotion.copyPromotionId()
check(copies.length === beforeMissing, 'an in-flight identity refresh blocks stale identifier copies')
promotionState.loading.value = false; copyFails = true; promotion.copyPromotionId()
check(notices.at(-1).title === '复制失败，请重试', 'clipboard failure offers a retry rather than claiming success')
check((panel.template.match(/aria-label="复制我的推广ID"/g) || []).length === 2 && panel.template.includes('@tap.stop="copyPromotionId"'), 'overview and invite views expose the same accessible isolated copy action')
for (const platform of ['h5', 'mp-weixin']) {
    preprocess.initPreContext(platform)
    const source = preprocess.preJs(preprocess.preHtml(read('uni-app/components/cooperation/CoopPromotionPanel.vue')))
    const parsed = compiler.parse(source, { filename: 'CoopPromotionPanel.vue' })
    compiler.compileScript(parsed.descriptor, { id: 'inviter-' + platform })
    check(!parsed.errors.length && source.includes('data:promotionId.value,') && source.includes('data:url,'), platform + ' conditional preprocessing preserves both actual clipboard payloads and valid script syntax')
}

let token = 'member-a', bootstrapData = { config: {}, profile: {}, onboarding_inviter: { editable: true, locked: false, current_inviter: null } }
const stateModule = execute(read('uni-app/composables/useCooperation.ts'), {
    '@/utils/common': { getSiteId: () => 100005, getToken: () => token },
    '../api/cooperation': { cooperationBootstrap: async () => ({ data: bootstrapData }), coopError: (cause, fallback) => cause?.message || fallback }
})
const state = stateModule.useCooperation('profile')
check(await state.bootstrap() && state.onboardingInviter.value.editable === true, 'bootstrap preserves the server-owned onboarding invitation contract even without a merchant')
bootstrapData = { ...bootstrapData, profile: { id: 7 }, onboarding_inviter: { editable: false, locked: true, current_inviter: { member_no: '0001' }, outcome: 'bound' } }
await state.bootstrap()
check(state.onboardingInviter.value.locked && state.onboardingInviter.value.current_inviter.member_no === '0001', 'post-save bootstrap uses the authoritative locked relationship')
token = 'member-b'; state.resume()
check(!Object.keys(state.onboardingInviter.value).length && !state.ready.value, 'changing login identity clears prior onboarding permission and inviter data')
const workbench = read('uni-app/components/cooperation/CooperationWorkbench.vue')
check((workbench.match(/:onboarding-inviter="ui\.onboardingInviter\.value"/g) || []).length === 2, 'both existing profile entry points use the same bootstrap contract')
check(workbench.includes('value.onboarding_inviter?.message') && workbench.includes("invitationMessage || '门店资料已保存'"), 'profile confirmation shows the server outcome without inventing a successful binding or blocking the saved shop')

for (const file of [profileFile, 'uni-app/components/cooperation/CoopPromotionPanel.vue', 'uni-app/components/cooperation/CooperationWorkbench.vue', 'uni-app/composables/useCooperation.ts']) {
    const installed = path.resolve(plugin, '../../../uni-app/src/addon/hsx_lead', file.slice('uni-app/'.length))
    check(fs.readFileSync(installed, 'utf8') === read(file), file + ' matches its installed source mirror')
}
console.log(`PASS ${checks} profile inviter and promotion ID checks; real Vue setup and state, isolated transport/clipboard, no member relationship or financial writes.`)
