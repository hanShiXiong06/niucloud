import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'

// Actual catalog SFC setup and scoped CSS; all data/transport is synthetic.
// No browser, live catalog, storage, backend or business operation is touched.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),postcss=require('postcss')
const file=path.join(plugin,'uni-app/components/cooperation/ModelCatalogPicker.vue'),source=fs.readFileSync(file,'utf8'),parsed=compiler.parse(source,{filename:file})
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
const equal=(actual,expected,label)=>{assert.deepEqual(JSON.parse(JSON.stringify(actual)),expected,label);checks++}
check(parsed.errors.length===0,'catalog SFC parses')
const script=compiler.compileScript(parsed.descriptor,{id:'catalog-layout'})
check(compiler.compileTemplate({source:parsed.descriptor.template.content,filename:file,id:'catalog-layout',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length===0,'actual picker template compiles')
const data=Array.from({length:7},(_,index)=>({id:String(index+1),title:'iPhone '+(index+11),brand:'苹果',category_name:'手机'})).concat([{id:'8',title:'iPad Air',brand:'苹果',category_name:'平板电脑'}])
const catalog=loadMobileUtility('catalog-selection'),cleanup=[]
function fixture(options={}){
    const props=Vue.reactive({show:true,page:true,modelValue:[],title:'不可用于判断用途的任意标题',max:5,businessType:'purchase',selectionMode:'multiple',initialView:'browse',bulkActions:true,...options}),events=[],requests=[],module={exports:{}}
    const js=ts.transpileModule(script.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
    const deps={vue:{...Vue,onBeforeUnmount:callback=>cleanup.push(callback)},'../../utils/mobile-ui':loadMobileUtility('mobile-ui'),'../../utils/catalog-selection':catalog,'../../utils/interaction-feedback':{interactionFeedback(){}},'../../api/cooperation':{cooperationCatalog:async(keyword,args)=>{requests.push({keyword,args});return{data}},coopError:(cause,fallback)=>cause?.message||fallback}}
    vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,JSON,Set,Map,Object})(key=>key.endsWith('.vue')?{default:{}}:key in deps?deps[key]:(()=>{throw Error('Unexpected dependency '+key)})(),module,module.exports)
    const state=module.exports.default.setup(props,{emit:(...args)=>events.push(args),expose(){}})
    return{props,state,events,requests}
}
const flush=async()=>{for(let n=0;n<6;n++){await Promise.resolve();await Vue.nextTick()}}
const demand=fixture();await flush()
check(demand.state.rows.value.length===8&&!demand.state.allowBulk.value,'bounded customer demands do not expose batch controls')
equal(demand.requests[0],{keyword:'',args:{browse:1,business_type:'purchase'}},'business-specific directory contract is unchanged')
demand.state.batch('select_all');check(demand.state.chosen.value.length===0,'hidden customer batch actions cannot change the selection')
for(const item of demand.state.rows.value.slice(0,5))demand.state.toggle(item)
check(demand.state.chosen.value.length===5,'normal individual selection reaches the configured demand limit')
demand.state.toggle(demand.state.rows.value[5]);check(demand.state.chosen.value.length===5&&demand.state.selectionError.value.includes('5 项'),'a sixth item stays unselected with a clear limit error')
check(demand.state.selectionHint.value==='最多可选 5 项','customer footer contains only the relevant limit')
demand.state.keyword.value=' iPhone 11 ';demand.state.search();check(demand.state.keyword.value==='iPhone 11'&&demand.state.visibleRows.value.length===1,'shared search button applies the current local query')
demand.state.clearSearch();check(demand.state.query.value===''&&demand.state.visibleRows.value.length===7,'clear search restores the current category')
demand.state.toggleSelectedView();check(demand.state.selectedView.value&&demand.state.visibleRows.value.length===5,'selected summary opens a review without changing choices')
demand.state.toggle(demand.state.chosen.value[0]);check(demand.state.chosen.value.length===4,'a selected item can be removed in selected-only view')
demand.state.confirm();check(demand.events.some(event=>event[0]==='update:modelValue'&&event[1].length===4)&&demand.events.at(-1)[0]==='close','confirmation returns selected rows and closes through the existing contract')
const capability=fixture({max:0});await flush();check(capability.state.allowBulk.value,'unlimited multiple merchant capabilities retain batch controls')
capability.state.batch('select_all');check(capability.state.chosen.value.length===7,'merchant all-select applies only to the displayed category')
capability.state.batch('invert');check(capability.state.chosen.value.length===0,'merchant inverse selection remains available')
capability.state.batch('select_all');capability.state.batch('clear');check(capability.state.chosen.value.length===0,'merchant clear range remains available')
check(capability.state.selectionHint.value==='批量操作仅影响当前显示范围','merchant batch scope remains explicit without long explanations')
const unlimitedDemand=fixture({max:0,bulkActions:false});await flush();check(!unlimitedDemand.state.allowBulk.value,'customer unlimited demand still has no batch actions')
unlimitedDemand.state.batch('select_all');check(!unlimitedDemand.state.chosen.value.length,'an explicitly disabled batch handler remains inactive even when limit is zero')
unlimitedDemand.state.toggle(unlimitedDemand.state.rows.value[0]);check(unlimitedDemand.state.chosen.value.length===1&&unlimitedDemand.state.selectionHint.value==='可选择多项','unlimited demand remains individually selectable without a false zero-item limit')
const single=fixture({max:0,selectionMode:'single'});await flush();check(!single.state.allowBulk.value,'single selection does not show bulk actions')
single.state.toggle(single.state.rows.value[0]);single.state.toggle(single.state.rows.value[1]);equal(single.state.chosen.value.map(item=>item.id),['2'],'single selection still replaces the first choice')
single.state.toggle(single.state.rows.value[1]);check(single.state.chosen.value.length===0,'single choice can still be cancelled')
check(source.includes('v-if="allowBulk" class="catalog-bulk"')&&!source.includes("title.includes("),'batch visibility is based on request contracts, not display titles')
const search=parsed.descriptor.template.content.match(/<view class="catalog-search">([\s\S]*?)<\/view>/)?.[1]||''
check(search.includes('show-action="true"')&&search.includes('action-text="搜索"')&&search.includes('@custom="search"')&&search.includes('@clear="clearSearch"'),'search reuses the public search component and its action/clear events')
check(!search.includes('catalog-selected-toggle')&&source.includes('class="catalog-selection-summary"'),'selected count and review control do not squeeze the search input')
let css='';for(const style of parsed.descriptor.styles){const result=compiler.compileStyle({source:style.content,filename:file,id:'catalog-layout',preprocessLang:style.lang,scoped:false});check(result.errors.length===0,'catalog scoped CSS compiles');css+=result.code}
const declarations=selector=>{const result={};postcss.parse(css).walkRules(rule=>{if(rule.selector===selector)rule.walkDecls(decl=>{result[decl.prop]=decl.value})});return result}
const tabs=declarations('.catalog-category-tabs>view')
// Sass may normalize combinator whitespace. Inspect both normalized variants.
const normalizedTabs=Object.keys(tabs).length?tabs:declarations('.catalog-category-tabs > view')
check(normalizedTabs.flex==='0 0 auto'&&normalizedTabs['flex-direction']==='row'&&normalizedTabs['white-space']==='nowrap'&&normalizedTabs['flex-wrap']==='nowrap','each top category remains a single non-shrinking horizontal tab')
const count=declarations('.catalog-category-count');check(count['white-space']==='nowrap','category counts stay on one compact line')
check(source.includes('{{ categoryCount(item.key) }}/{{ item.count }}'),'compact counts contain no breakable slash spacing')
const publish=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopPublishForm.vue'),'utf8'),profile=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopProfilePanel.vue'),'utf8')
check(publish.includes('allow_bulk: false')&&profile.includes('allow_bulk: true'),'business callers explicitly declare batch capability independent of quantity')
check(source.includes('bulkActions: true'),'direct existing component callers keep the declared default capability')
const pageFile=path.join(plugin,'uni-app/pages/catalog/index.vue'),pageSource=fs.readFileSync(pageFile,'utf8'),page=compiler.parse(pageSource,{filename:pageFile}),pageScript=compiler.compileScript(page.descriptor,{id:'catalog-page-contract'}),pageModule={exports:{}}
let loadPage,initialize
const channel={on(event,callback){if(event==='initialize')initialize=callback},emit(){}}
const pageJs=ts.transpileModule(pageScript.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${pageJs}\n})`,{Number,String,Math,Array})(key=>key==='vue'?{...Vue,getCurrentInstance:()=>({proxy:{getOpenerEventChannel:()=>channel}})}:key==='@dcloudio/uni-app'?{onLoad:callback=>{loadPage=callback}}:key==='../../utils/cooperation-navigation'?{backCooperationTask(){}}:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected page dependency '+key)})(),pageModule,pageModule.exports)
const pageState=pageModule.exports.default.setup({},{expose(){}})
check(pageState.bulkActions.value===false&&pageSource.includes(':bulk-actions="bulkActions"'),'native page defaults to no bulk capability and forwards it explicitly')
loadPage();initialize({max:0,selection_mode:'multiple',allow_bulk:true});check(pageState.bulkActions.value===true,'merchant initialization explicitly enables bulk controls')
initialize({max:0,selection_mode:'multiple',allow_bulk:false});check(pageState.bulkActions.value===false,'customer initialization keeps bulk controls disabled even without a quantity cap')
initialize({max:0,selection_mode:'multiple'});check(pageState.bulkActions.value===false,'missing event option cannot infer merchant powers from unlimited count')
initialize({max:0,selection_mode:'multiple',allow_bulk:'true'});check(pageState.bulkActions.value===false,'non-boolean event option remains fail-closed')
for(const stop of cleanup)stop()
console.log(`PASS ${checks} catalog demand/capability/search/layout checks; actual Vue setup and CSS with synthetic data only.`)
