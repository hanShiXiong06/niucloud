import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Real form setup, native-page template rendering and Vue component-event dispatch.
// Only the leaf picker and uni transport are synthetic; no API, DB or payment is used.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const mobile = path.join(plugin, 'uni-app'), require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
let checks = 0, requestSequence = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const equal = (value, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(value)), expected, label); checks++ }
const copy = value => JSON.parse(JSON.stringify(value))
const storage = new Map([['wap_site_id', 100005], ['wap_member_id', 101]])
const navigations = [], scopes = [], apps = []
const uni = {
    getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, copy(value)), removeStorageSync: key => storage.delete(key),
    navigateTo: value => navigations.push(value), navigateBack: value => navigations.push({ back: value }), redirectTo: value => navigations.push({ redirect: value }), showToast() {},
}
function execute(source, deps = {}, globals = {}) {
    const js = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    const module = { exports: {} }
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Array, JSON, Set, Map, Promise, console, uni, ...globals })(key => {
        if (key in deps) return deps[key]
        if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key))
        if (key.endsWith('.vue')) return { default: {} }
        throw Error('Unexpected import ' + key)
    }, module, module.exports)
    return module.exports
}
const navigation = execute(fs.readFileSync(path.join(mobile, 'utils/cooperation-navigation.ts'), 'utf8'), {}, {
    getCurrentPages: () => [{ route: 'addon/hsx_lead/pages/task/index' }, { route: 'addon/hsx_lead/pages/catalog/index' }],
})
const api = { coopRequestId: () => 'catalog-return-' + (++requestSequence), coopMoney: value => '¥' + Number(value).toFixed(2) }
const businesses = [
    { key: 'purchase', name: '二手机', enabled: true, dimension: 'model', selection_mode: 'multiple', selection_limit: 5, fields: [], options: [], commission_minimum: '100.00' },
    { key: 'new_phone', name: '新机', enabled: true, dimension: 'brand', selection_mode: 'multiple', selection_limit: 3, fields: [], options: [], commission_minimum: '100.00' },
    { key: 'broadband', name: '宽带', enabled: true, dimension: 'operator', selection_mode: 'single', selection_limit: 0, fields: [], options: [], commission_minimum: '200.00' },
]
function form(name, values) {
    const file = path.join(mobile, 'components/cooperation', name + '.vue')
    const parsed = compiler.parse(fs.readFileSync(file, 'utf8'), { filename: file })
    check(!parsed.errors.length, name + ' SFC parses')
    const script = compiler.compileScript(parsed.descriptor, { id: 'catalog-return-' + name })
    const actual = execute(script.content, { vue: Vue, '../../api/cooperation': api, '../../utils/cooperation-navigation': navigation, '@/utils/common': { img: value => value } }).default
    const props = Vue.reactive(values), events = [], scope = Vue.effectScope(), exposed = {}
    const state = scope.run(() => actual.setup(props, { expose: methods => Object.assign(exposed, methods), emit: (...args) => events.push(args) }))
    scopes.push(scope)
    return { state, props, events, exposed }
}
// A tiny in-memory Vue host exercises real compiled parent listener lookup.
// Native WXML binding is checked separately by check-mobile-build.mjs: the H5
// compiler can merge listeners that the mini-program compiler drops.
const node = (type, text = '') => ({ type, text, props: {}, children: [], parent: null })
const renderer = Vue.createRenderer({
    createElement: type => node(type), createText: text => node('#text', text), createComment: text => node('#comment', text),
    insert(child, parent, anchor) { if (child.parent) this.remove(child); const index = anchor ? parent.children.indexOf(anchor) : -1; parent.children.splice(index < 0 ? parent.children.length : index, 0, child); child.parent = parent },
    remove(child) { const parent = child.parent; if (parent) { const index = parent.children.indexOf(child); if (index >= 0) parent.children.splice(index, 1) }; child.parent = null },
    setText: (target, text) => { target.text = text }, setElementText: (target, text) => { target.text = text; target.children = [] },
    parentNode: target => target.parent, nextSibling: target => target.parent?.children[target.parent.children.indexOf(target) + 1] || null,
    patchProp: (target, key, _old, value) => { target.props[key] = value },
})
async function settle() { for (let step = 0; step < 6; step++) { await Promise.resolve(); await Vue.nextTick() } }
async function pageFor(call, collision = false) {
    check(call?.url === '/addon/hsx_lead/pages/catalog/index', 'real navigation opens the shared catalog page')
    const listeners = new Map(Object.entries(call.events || {})), emitted = []
    const channel = { on: (name, listener) => listeners.set(name, listener), emit(name, value) { emitted.push({ name, value: copy(value) }); listeners.get(name)?.(value) } }
    let leaf, onLoad, state
    const picker = { name: 'ModelCatalogPicker', props: ['modelValue', 'businessType', 'selectionMode', 'max'], emits: ['update:modelValue', 'close'], setup(props, context) { leaf = { props, emit: context.emit }; return () => Vue.h('picker-fixture') } }
    const file = path.join(mobile, 'pages/catalog/index.vue')
    let source = fs.readFileSync(file, 'utf8')
    if (collision) source = source.replace(':model-value="items"', 'v-model="items"')
    else check(!source.includes('v-model="items"') && source.includes(':model-value="items"'), 'catalog page has one explicit update listener, not a competing generated v-model setter')
    const parsed = compiler.parse(source, { filename: file }), script = compiler.compileScript(parsed.descriptor, { id: 'catalog-return-page' })
    const output = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: file, id: 'catalog-return-page', compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
    check(!parsed.errors.length && !output.errors.length, 'actual catalog page setup and template compile')
    const actual = execute(script.content, {
        vue: { ...Vue, getCurrentInstance: () => ({ proxy: { getOpenerEventChannel: () => channel } }) },
        '@dcloudio/uni-app': { onLoad: callback => { onLoad = callback } },
        '../../components/cooperation/ModelCatalogPicker.vue': { default: picker },
        '../../utils/cooperation-navigation': navigation,
    }).default
    const render = execute(output.code, { vue: Vue }).render
    const component = { ...actual, render, setup(props, context) { state = actual.setup(props, context); return state } }
    const app = renderer.createApp(component); app.config.warnHandler = () => {}; app.config.globalProperties.themeColor = () => ({})
    app.mount(node('root')); apps.push(app); onLoad(); call.success({ eventChannel: channel }); await settle()
    check(!!leaf, 'initialize event renders the real page child binding')
    return { leaf, state, emitted, async confirm(items) { leaf.emit('update:modelValue', copy(items)); leaf.emit('close'); await settle() }, async cancel() { leaf.emit('close'); await settle() } }
}
try {
    // Cross-platform control: H5 alone can pass with the old conflicting syntax.
    // This is why the native generated handler test must also remain in the suite.
    let oldReturn = 0
    navigation.openCooperationCatalog({ business_type: 'purchase', items: [] }, () => { oldReturn++ })
    const old = await pageFor(navigations.at(-1), true)
    await old.confirm([{ id: 'phone-old', title: '旧模板选择' }])
    check(oldReturn === 1 && old.state.items.value.length === 1, 'H5 control still merges the old duplicate listener; H5 success must not stand in for native WXML acceptance')

    const publisher = form('CoopPublishForm', { show: true, page: true, merchantId: 7, config: { businesses, fee_confirmed: true }, busy: false, error: '' })
    Object.assign(publisher.state.form, { customer_name: '合成客户', mobile: '18800000000', province_id: 1, city_id: 2, district_id: 3, consent: true })
    publisher.state.submit()
    check(publisher.state.localError.value === '请至少选择一个意向型号' && publisher.events.length === 0, 'genuinely empty demand remains required before navigation')
    publisher.state.chooseDemand(); const first = await pageFor(navigations.at(-1))
    equal(first.leaf.props.modelValue, [], 'new selector starts with the actual empty publishing draft')
    await first.confirm([{ id: 'phone-1', title: '合成型号一' }, { id: 'phone-2', title: '合成型号二' }])
    equal(publisher.state.models.value.map(row => row.id), ['phone-1', 'phone-2'], 'compiled page event dispatch returns chosen rows to the publishing form')
    check(first.emitted.filter(event => event.name === 'selected').length === 1, 'one confirmation returns through EventChannel exactly once')
    check(publisher.state.localError.value === '', 'successful return clears a previous empty-selection error')
    publisher.state.submit()
    equal(publisher.events.find(event => event[0] === 'submit')[1].demand_ids, ['phone-1', 'phone-2'], 'published payload contains returned model IDs rather than an empty list')

    publisher.state.chooseDemand(); const cancelled = await pageFor(navigations.at(-1))
    equal(cancelled.leaf.props.modelValue.map(row => row.id), ['phone-1', 'phone-2'], 'reopening seeds the selector with the previous confirmed draft')
    await cancelled.cancel()
    equal(publisher.state.models.value.map(row => row.id), ['phone-1', 'phone-2'], 'cancel does not erase previously confirmed models')
    check(cancelled.emitted.every(event => event.name !== 'selected'), 'cancel sends no selection-change event')

    publisher.state.form.business_type = 'new_phone'; publisher.state.chooseDemand(); const brands = await pageFor(navigations.at(-1))
    check(brands.leaf.props.businessType === 'new_phone', 'new-phone selection stays in its brand business')
    await brands.confirm([{ id: 'brand_apple', title: '苹果' }]); publisher.state.submit()
    const brandPayload = publisher.events.filter(event => event[0] === 'submit').at(-1)[1]
    equal([brandPayload.business_type, brandPayload.demand_ids], ['new_phone', ['brand_apple']], 'new-phone payload sends brand IDs, not prior used-phone models')
    publisher.state.form.business_type = 'broadband'; publisher.state.chooseDemand(); const operators = await pageFor(navigations.at(-1))
    check(operators.leaf.props.selectionMode === 'single', 'broadband demand keeps the server-defined single-operator mode')
    await operators.confirm([{ id: 'operator_mobile', title: '移动' }]); publisher.state.submit()
    equal(publisher.events.filter(event => event[0] === 'submit').at(-1)[1].demand_ids, ['operator_mobile'], 'operator demand returns through the same real template binding')
    publisher.state.form.business_type = 'purchase'
    equal(publisher.state.models.value.map(row => row.id), ['phone-1', 'phone-2'], 'switching businesses preserves independent previous model choices')
    publisher.state.chooseDemand(); const cleared = await pageFor(navigations.at(-1)); await cleared.confirm([])
    const beforeClearSubmit = publisher.events.filter(event => event[0] === 'submit').length; publisher.state.submit()
    check(publisher.state.localError.value === '请至少选择一个意向型号' && publisher.events.filter(event => event[0] === 'submit').length === beforeClearSubmit, 'explicit confirmed clearing removes models and blocks an empty publication')
    publisher.state.form.business_type = 'new_phone'
    equal(publisher.state.models.value.map(row => row.id), ['brand_apple'], 'clearing used-phone models does not erase another business selection')

    const profile = form('CoopProfilePanel', { profile: { id: 7, member_id: 101, business_capabilities: [] }, config: { businesses }, providers: [], page: true, editing: true, busy: false, error: '' })
    Object.assign(profile.state.form, { name: '合成门店', contact_name: '合成联系人', mobile: '18800000000', province_id: 1, city_id: 2, district_id: 3, address: '合成地址' })
    profile.state.selectedBusinesses.value = ['purchase', 'broadband']
    profile.state.openModelCatalog('purchase'); const capability = await pageFor(navigations.at(-1))
    check(capability.leaf.props.max === 0 && capability.leaf.props.selectionMode === 'multiple', 'merchant capabilities retain independent unlimited multiple-selection policy')
    await capability.confirm([{ id: 'phone-1', title: '合成型号一' }])
    equal(profile.state.capabilityChoices.purchase.map(row => row.id), ['phone-1'], 'same page fix returns merchant capability selections too')
    profile.state.openModelCatalog('broadband'); const carrierCapability = await pageFor(navigations.at(-1))
    check(carrierCapability.leaf.props.selectionMode === 'multiple', 'merchant may support several operators even when a customer demand is single-select')
    await carrierCapability.confirm([{ id: 'operator_mobile', title: '移动' }, { id: 'operator_unicom', title: '联通' }]); profile.state.submit()
    equal(profile.events.find(event => event[0] === 'submit')[1].business_capabilities, [{ business_type: 'purchase', option_ids: ['phone-1'] }, { business_type: 'broadband', option_ids: ['operator_mobile', 'operator_unicom'] }], 'merchant submit persists each returned capability under its own business')
    profile.state.openModelCatalog('purchase'); const cancelCapability = await pageFor(navigations.at(-1)); await cancelCapability.cancel()
    equal(profile.state.capabilityChoices.purchase.map(row => row.id), ['phone-1'], 'canceling capability edit preserves confirmed choices')
    check(navigations.some(entry => entry.back), 'confirmation and cancellation use native back navigation rather than re-launching the application')
    console.log(`PASS ${checks} catalog-return checks; actual page template/Vue emits and real publish/profile setup, synthetic picker/transport only; no live API or business writes.`)
} finally {
    for (const app of apps.reverse()) app.unmount()
    for (const scope of scopes) scope.stop()
}
