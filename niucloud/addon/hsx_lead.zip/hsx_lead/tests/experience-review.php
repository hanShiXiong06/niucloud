<?php
declare(strict_types=1);

// Independent regression: real cooperation/payment/membership services, owned
// disposable localhost schema only. No gateway or existing site data is used.
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,CooperationService,EntityExperienceService,EntityMembershipService,PartnerService,PaymentService,Store};
use app\dict\pay\{PayDict,RefundDict};
use core\exception\CommonException;
use think\facade\Db;

$checks=0;$pdo=null;$schema='';$failed=false;
function erCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function erDeny(callable$run,string$label):void{try{$run();}catch(CommonException$error){erCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
    // Configure the legitimate entry explicitly; never boost personal growth
    // or lower the paid higher-tier threshold to make a fixture pass.
    $entry=Db::name('member_level')->where('site_id',$site)->where('level_id',701)->value('level_benefits');$entry=json_decode($entry,true);$entry['hsx_lead_subject']['is_entry']=true;
    Db::name('member_level')->where('site_id',$site)->where('level_id',701)->update(['level_benefits'=>json_encode($entry,JSON_THROW_ON_ERROR)]);
    $secondDefinition=Db::name('member_level')->where('site_id',$site)->where('level_id',702)->value('level_benefits');
    $conflicting=leadMembershipDefinition(702,2,2,false,['is_entry'=>true]);
    Db::name('member_level')->where('site_id',$site)->where('level_id',702)->update(['level_benefits'=>$conflicting['level_benefits']]);
    erDeny(fn()=>(new ConfigService(new Context($site,1)))->get(),'two active zero-experience entry tiers fail closed');
    Db::name('member_level')->where('site_id',$site)->where('level_id',702)->update(['level_benefits'=>$secondDefinition]);
    $config=(new ConfigService(new Context($site,1)))->get();$config['enabled']=true;$config['publishing_required']=false;$config['fee_confirmed']=true;
    $config['fee_percent']='0.00';$config['fee_minimum']='0.00';$config['businesses'][0]['commission_minimum']='0.01';
    (new ConfigService(new Context($site,1)))->save($config);
    $publisher=new CooperationService(new Context($site,0,101));$receiver=new CooperationService(new Context($site,0,102));
    $model=$publisher->catalog(['business_type'=>'purchase','browse'=>1])[0];
    $profile=static function(int$member)use($site,$model):array{return(new PartnerService(new Context($site,0,$member)))->saveProfile(['name'=>'Experience review '.$member,'contact_name'=>'Synthetic owner','mobile'=>'18800000'.$member,'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road','business_capabilities'=>[['business_type'=>'purchase','option_ids'=>[$model['id']]]]]);};
    $a=$profile(101);$b=$profile(102);$aId=(int)$a['id'];$bId=(int)$b['id'];
    $memberBefore=Db::name('member')->where('site_id',$site)->whereIn('member_id',[101,102])->field('member_id,growth,growth_get,member_level')->order('member_id')->select()->toArray();
    leadMembershipGrant($site,102,'ML701');
    $experience=static fn():array=>EntityExperienceService::summary($site,$bId);
    erCheck($experience()['value']==='0.00','membership purchase itself awards no delivery experience');
    $membership=new EntityMembershipService(new Context($site,0,102));$billing=new PaymentService(new Context($site,0,102));
    erCheck(!$membership->quote('ML702','month')['can_purchase'],'a higher framework threshold cannot be bought with money alone');
    Db::name('member_level')->where('site_id',$site)->where('level_id',701)->update(['status'=>0]);
    $remainingTiers=(new ConfigService(new Context($site,1)))->get()['membership_levels'];
    erCheck($remainingTiers[0]['code']==='ML702'&&$remainingTiers[0]['experience_required']==='200.00'&&!$remainingTiers[0]['is_entry'],'disabling the explicit entry tier does not give the next enabled tier a zero threshold');
    erCheck(!$membership->quote('ML702','month')['can_purchase'],'the next remaining paid tier still requires its own experience');
    Db::name('member_level')->where('site_id',$site)->where('level_id',701)->update(['status'=>1]);
    $receipt=static function(array$order,string$number)use($site):void{Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$number,'main_type'=>PayDict::MEMBER,'main_id'=>102,'from_main_id'=>102,'money'=>$order['amount'],'status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$order['id'],'out_trade_no'=>$number]);};
    $commission=static function(string$amount,string$label)use($publisher,$receiver,$billing,$receipt,$model,$bId):array{
        $lead=$publisher->create(['request_id'=>'experience-'.$label,'customer_name'=>'Synthetic customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'attachments'=>[],'consent'=>true]);
        $publisher->assign((int)$lead['id'],['merchant_id'=>$bId,'assignment_version'=>0]);$receiver->action((int)$lead['id'],['action'=>'accept','assignment_version'=>1]);$receiver->action((int)$lead['id'],['action'=>'deal','assignment_version'=>1]);
        $order=$billing->createOrder(['purpose'=>'commission','lead_id'=>$lead['id'],'amount'=>$amount,'request_id'=>'experience-payment-'.$label]);
        $number='EXPERIENCE_'.strtoupper($label);$receipt($order,$number);return['order'=>$order,'lead'=>$lead,'number'=>$number];
    };
    $first=$commission('199.99','first');
    erCheck($experience()['value']==='199.99','experience is confirmed gross cooperation commission, with exact cents');
    erCheck(EntityExperienceService::summary($site,$aId)['value']==='0.00','publisher income does not masquerade as receiver delivery experience');
    erCheck(!$membership->quote('ML702','month')['can_purchase'],'a one-cent threshold shortfall remains ineligible');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_PENDING','out_trade_no'=>$first['number'],'money'=>'10.00','status'=>RefundDict::WAIT]);
    erCheck($experience()['value']==='199.99','an application for refund is not a completed refund');
    Db::name('pay_refund')->where('refund_no','EXPERIENCE_PENDING')->update(['status'=>RefundDict::CANCEL]);
    $second=$commission('0.01','second');
    erCheck($experience()['value']==='200.00'&&$experience()['completed_orders']===2,'fractional commissions accumulate before comparison, never per-order rounding');
    $quote=$membership->quote('ML702','month');erCheck($quote['can_purchase'],'exact framework threshold opens an upgrade quote');
    $pending=$billing->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','request_id'=>'experience-upgrade-pending','quote_token'=>$quote['quote_token']]);
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_PARTIAL','out_trade_no'=>$first['number'],'money'=>'0.01','status'=>RefundDict::SUCCESS]);
    erCheck($experience()['value']==='199.99'&&$experience()['refunded_amount']==='0.01','a successful partial refund removes only its exact experience');
    erCheck($experience()['value']==='199.99','reading/replaying a refund does not subtract the amount twice');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_PARTIAL','out_trade_no'=>$first['number'],'money'=>'0.01','status'=>RefundDict::SUCCESS]);
    erCheck($experience()['value']==='199.99','duplicate rows for one framework refund number do not deduct the same completed refund twice');
    erDeny(fn()=>$billing->assertPayable((int)$pending['id']),'cashier continuation rechecks a threshold lost after quotation');
    erCheck(!$membership->quote('ML702','month')['can_purchase'],'an existing unpaid order does not overwrite current experience ineligibility');
    $membership->closeUnpaid((int)$pending['id']);
    $third=$commission('1.00','third');erCheck($experience()['value']==='200.99','a later real payment restores eligibility without rewriting prior facts');
    $quote=$membership->quote('ML702','month');$upgrade=$billing->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','request_id'=>'experience-upgrade-confirmed','quote_token'=>$quote['quote_token']]);$receipt($upgrade,'EXPERIENCE_UPGRADE_RECEIPT');
    erCheck($membership->summary()['active']&&$membership->summary()['level_code']==='ML702','qualified upgrade is granted only after its matching receipt');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_REMAINDER','out_trade_no'=>$first['number'],'money'=>'199.98','status'=>RefundDict::SUCCESS]);
    erCheck($experience()['value']==='1.01'&&$experience()['refunded_amount']==='199.99','multiple successful partial refunds are summed per original commission');
    erCheck($membership->summary()['active']&&$membership->summary()['level_code']==='ML702','experience correction never retroactively downgrades already-paid active rights');
    erCheck(!$membership->quote('ML702','month')['can_purchase'],'a new same-tier renewal rechecks current experience without revoking the original purchased term');
    $ordersBeforeRenewal=Store::query('coop_order',$site)->count();
    erDeny(fn()=>$billing->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','request_id'=>'experience-renewal-insufficient','quote_token'=>$quote['quote_token']]),'an earlier eligible upgrade token cannot bypass the renewed experience threshold');
    erCheck(Store::query('coop_order',$site)->count()===$ordersBeforeRenewal,'ineligible renewal creates no second membership or cash order');
    erCheck(!$membership->quote('ML703','month')['can_purchase'],'a new higher upgrade still requires the new threshold');

    // Fault injection remains entirely inside this disposable fixture schema.
    Db::name('pay')->where('out_trade_no',$third['number'])->update(['money'=>'2.00']);
    erCheck($experience()['value']==='0.01','amount-mismatched payment cannot create experience');
    Db::name('pay')->where('out_trade_no',$third['number'])->update(['money'=>'1.00','main_id'=>101]);
    erCheck($experience()['value']==='0.01','another payer cannot be substituted for the original order identity');
    Db::name('pay')->where('out_trade_no',$third['number'])->update(['main_id'=>102]);
    Store::query('collaboration',$site)->where('id',$third['lead']['id'])->update(['status'=>'unpaid']);
    erCheck($experience()['value']==='0.01','a paid marker without the completed cooperation state is not delivery experience');
    Store::query('collaboration',$site)->where('id',$third['lead']['id'])->update(['status'=>'paid','publisher_id'=>$bId]);
    erCheck($experience()['value']==='0.01','internal same-subject work is not charged and never earns commission experience');
    Store::query('collaboration',$site)->where('id',$third['lead']['id'])->update(['publisher_id'=>$aId]);
    erCheck($experience()['value']==='1.01','restoring a valid original relationship restores only its derived total');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_OVER_REFUND','out_trade_no'=>$third['number'],'money'=>'2.00','status'=>RefundDict::SUCCESS]);
    erCheck($experience()['value']==='0.01','over-refunded corrupt input is clamped per original order and does not erase another valid order');
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_NEGATIVE_REFUND','out_trade_no'=>$second['number'],'money'=>'-0.10','status'=>RefundDict::SUCCESS]);
    erCheck(in_array($experience()['value'],['0.00','0.01'],true)&&$experience()['excluded_orders']>0,'a corrupt negative refund never turns into added or negative experience and is explicitly excluded');
    $fourth=$commission('400.00','late-source');$lateQuote=$membership->quote('ML703','month');erCheck($lateQuote['can_purchase'],'new verified external commission can legitimately qualify the next tier');
    $late=$billing->createOrder(['purpose'=>'membership','level_code'=>'ML703','cycle'=>'month','request_id'=>'experience-late-paid','quote_token'=>$lateQuote['quote_token']]);
    $beforeLate=$membership->summary();
    Db::name('pay_refund')->insert(['site_id'=>$site,'refund_no'=>'EXPERIENCE_BEFORE_LATE_CASH','out_trade_no'=>$fourth['number'],'money'=>'400.00','status'=>RefundDict::SUCCESS]);
    erCheck($experience()['value']==='0.00','a refund committed after opening the cashier removes its supporting experience');
    erDeny(fn()=>$billing->assertPayable((int)$late['id']),'a not-yet-charged cashier cannot proceed after losing qualification');
    $receipt($late,'EXPERIENCE_LATE_MEMBERSHIP_RECEIPT');$lateOrder=$billing->order((int)$late['id']);
    erCheck($lateOrder['status']==='paid'&&$lateOrder['requires_manual_review'],'an actual late payment is preserved as paid and routed to explicit review, not reported unpaid');
    $afterLate=$membership->summary();
    erCheck($afterLate['level_code']==='ML702'&&$afterLate['active']&&$afterLate['expires_at']===$beforeLate['expires_at'],'an ineligible late receipt grants no higher tier and never reduces the valid existing term');
    erCheck(Db::name('pay_refund')->where('site_id',$site)->where('out_trade_no','EXPERIENCE_LATE_MEMBERSHIP_RECEIPT')->count()===0,'eligibility failure does not silently initiate a refund of actual funds');
    PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$late['id'],'out_trade_no'=>'EXPERIENCE_LATE_MEMBERSHIP_RECEIPT']);
    erDeny(fn()=>$billing->assertPayable((int)$late['id']),'a replayed late receipt never becomes a second cashier opportunity');
    erCheck($experience()['value']==='0.00','paid membership review receipts never turn into commission experience');
    $before=Db::name('member')->where('site_id',$site)->whereIn('member_id',[101,102])->field('member_id,growth,growth_get,member_level')->order('member_id')->select()->toArray();
    erCheck($before===$memberBefore,'enterprise experience never writes personal growth, growth gifts or member level');
    leadAssertIsolated($schema);echo 'PASS '.$checks." independent experience review checks; real service flow, random owned localhost schema, synthetic receipts, no gateway or existing data.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
