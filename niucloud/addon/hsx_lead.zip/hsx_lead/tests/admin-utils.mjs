import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json')),Vue=require('vue'),ts=require('typescript'),cache=new Map()
/** Load actual plugin composables with lifecycle-only doubles; never replaces their business state. */
export function loadAdminUtility(name){
 if(cache.has(name))return cache.get(name)
 if(!['useRemoteOptions','accountNotice'].includes(name))throw Error('Unsupported admin utility '+name)
 const source=fs.readFileSync(path.join(plugin,'admin/composables',name+'.ts'),'utf8'),module={exports:{}}
 const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
 vm.runInNewContext(`(function(require,module,exports){${code}\n})`,{setTimeout,clearTimeout,console,Date,Number,String,Array,Object,JSON,Promise,Math,Set,Map,Error})(key=>{if(key==='vue')return{...Vue,onBeforeUnmount(){},onMounted(){}};throw Error('Unexpected admin utility dependency '+key)},module,module.exports)
 cache.set(name,module.exports);return module.exports
}
