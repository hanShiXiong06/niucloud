<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityMembershipService,MembershipCostService,PartnerService,PaymentService,PaymentOrderLifecycle,Rules,Store};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\{PayDict,RefundDict};
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function srCheck(bool $value,string $label):void{if(!$value)throw new RuntimeException($label);$GLOBALS['checks']++;}
function srDeny(callable $work,string $label):void{try{$work();}catch(CommonException$error){srCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund']as$table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match);if(empty($match[0]))throw new RuntimeException('Missing official DDL');$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));}
    $definition=leadMembershipDefinition(702,2,2,false,['deposit_amount'=>'200.00','experience_purchase_enabled'=>true,'experience_unit_price'=>'1.00']);Db::name('member_level')->where('site_id',$site)->where('level_id',702)->update(['level_benefits'=>$definition['level_benefits']]);
    $admin=new Context($site,1);$config=(new ConfigService($admin))->get();$config['enabled']=true;$config['fee_confirmed']=true;(new ConfigService($admin))->save($config);
    $ctx=new Context($site,0,101);$profile=(new PartnerService($ctx))->saveProfile(['name'=>'Reprice fixture','contact_name'=>'Owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Fixture road']);
    $memberships=new EntityMembershipService($ctx);$payments=new PaymentService($ctx);$quote=$memberships->quote('ML702','month',true);
    srCheck($quote['can_purchase']&&$quote['deposit_amount']==='200.00'&&$quote['experience_amount']==='200.00'&&$quote['service_amount']==='38.00','fixture has separate deposit, purchased experience and service revenue');
    $order=$payments->createOrder(['purpose'=>'membership','level_code'=>'ML702','cycle'=>'month','buy_experience'=>true,'request_id'=>'service-reprice-source','quote_token'=>$quote['quote_token']]);$id=(int)$order['id'];$raw=Store::row('coop_order',$site,$id);$rule=Data::decode($raw['rule_json']);$meta=['operator_uid'=>1,'reason'=>'本地合成管理员优惠','at'=>time()];
    $next=EntityMembershipService::prepareRepricedSnapshot($site,$raw,'20.00',$meta);
    srCheck($next['amount']==='420.00'&&$next['rule']['service_amount']==='20.00'&&$next['rule']['promotion_base_amount']==='20.00','only service revenue participates in the adjustment and promotion base');
    foreach(['deposit_required','deposit_balance','deposit_amount','experience_unit_price','experience_quantity','experience_amount','service_credit_amount','credit_amount','credit_sources','quoted_at','period_start_at','period_end_at','base_fingerprint','cost_fingerprint']as$key)srCheck($next['rule'][$key]===$rule[$key],'immutable source field preserved: '.$key);
    srCheck(Store::row('coop_order',$site,$id)['amount']==='438.00','preview does not mutate the original payment amount');
    srDeny(fn()=>EntityMembershipService::prepareRepricedSnapshot($site,array_replace($raw,['status'=>'paid']),'20.00',$meta),'paid order cannot be repriced');
    srDeny(fn()=>EntityMembershipService::prepareRepricedSnapshot($site+1,$raw,'20.00',$meta),'cross-site source cannot be repriced');
    srDeny(fn()=>EntityMembershipService::prepareRepricedSnapshot($site,$raw,'38.00',$meta),'unchanged amount cannot create a duplicate trade');
    srDeny(fn()=>EntityMembershipService::prepareRepricedSnapshot($site,$raw,'20.00',['operator_uid'=>0,'reason'=>'missing operator']),'operator provenance is required');
    $expired=$rule;$expired['quoted_at']=time()-601;srDeny(fn()=>EntityMembershipService::prepareRepricedSnapshot($site,array_replace($raw,['rule_json'=>Data::json($expired)]),'20.00',$meta),'repricing cannot extend an expired quote');
    $intent=$rule;$intent['pricing_intent']=['request_id'=>'synthetic'];$intent['closure']=['at'=>time(),'reason'=>'synthetic'];srCheck(MembershipCostService::pricingFingerprint($raw,$intent)===MembershipCostService::pricingFingerprint($raw,$rule),'runtime intent and closure do not invalidate immutable source proof');
    $closed=(new PaymentOrderLifecycle($ctx))->close($id,['confirm'=>true]);srCheck($closed['status']==='closed','source business is closed before another trade is created');$raw=Store::row('coop_order',$site,$id);$next=EntityMembershipService::prepareRepricedSnapshot($site,$raw,'20.00',$meta);
    $replacement=(int)Store::query('coop_order',$site)->insertGetId(['site_id'=>$site,'order_no'=>Data::number('CO'),'purpose'=>'membership','lead_id'=>0,'merchant_id'=>$profile['id'],'member_id'=>101,'business_key'=>'membership:replacement:service-reprice','request_id'=>'service-reprice-new','amount'=>$next['amount'],'fee_amount'=>'0.00','net_amount'=>'0.00','rule_json'=>Data::json($next['rule']),'status'=>'unpaid','create_time'=>time(),'update_time'=>time()]);
    srCheck($replacement!==$id,'replacement has a different trade ID');$payments->assertPayable($replacement);srCheck(true,'real payment guard accepts the separately proven service-fee override');
    $tampered=$next['rule'];$tampered['deposit_required']='300.00';$tampered['deposit_amount']='300.00';$tampered['payable_amount']='520.00';Store::query('coop_order',$site)->where('id',$replacement)->update(['amount'=>'520.00','rule_json'=>Data::json($tampered)]);srDeny(fn()=>$payments->assertPayable($replacement),'coherent-looking deposit edits are rejected by immutable source proof');Store::query('coop_order',$site)->where('id',$replacement)->update(['amount'=>$next['amount'],'rule_json'=>Data::json($next['rule'])]);
    $no='REPRICE_SYNTHETIC_PAID';Db::name('pay')->insert(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$replacement,'out_trade_no'=>$no,'main_type'=>PayDict::MEMBER,'main_id'=>101,'from_main_id'=>101,'money'=>$next['amount'],'status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);$event=['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$replacement,'out_trade_no'=>$no];PaymentService::confirm($event);$paid=Store::row('coop_order',$site,$replacement);$summary=$memberships->summary();
    srCheck($paid['status']==='paid'&&$summary['active']&&$summary['level_code']==='ML702','matching adjusted receipt grants the original member rights');srCheck($summary['deposit_balance']==='200.00'&&$summary['experience']['purchased_value']==='200.00','receipt preserves deposit and purchased experience');srCheck(MembershipCostService::promotionBase($paid)===2000,'promotion only sees adjusted service revenue');PaymentService::confirm($event);srCheck($memberships->summary()['deposit_balance']==='200.00','callback replay does not duplicate deposit');
    $paidRule=Data::decode($paid['rule_json']);srCheck($paidRule['full_amount']==='20.00'&&$paidRule['credit_amount']==='0.00','future upgrade valuation uses real adjusted service value, not undiscounted catalog revenue');
    Db::name('pay_refund')->insert(['site_id'=>$site,'out_trade_no'=>$no,'refund_no'=>'REPRICE_FULL_REFUND','money'=>$paid['amount'],'status'=>RefundDict::SUCCESS]);EntityMembershipService::refund($site,$paid,['refund_no'=>'REPRICE_FULL_REFUND','money'=>$paid['amount'],'status'=>RefundDict::SUCCESS]);$refunded=$memberships->summary();srCheck(!$refunded['active']&&$refunded['deposit_balance']==='0.00','full adjusted refund revokes rights and original deposit');
    echo 'PASS '.$checks." membership service repricing checks; isolated local schema and matching synthetic receipts only, no provider/payment calls.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL '.$error->getMessage()."\n".$error->getTraceAsString()."\n");}
finally{if($pdo&&$schema!==''){leadAssertIsolated($schema);$pdo->exec('DROP DATABASE `'.$schema.'`');}}
exit($failed?1:0);
