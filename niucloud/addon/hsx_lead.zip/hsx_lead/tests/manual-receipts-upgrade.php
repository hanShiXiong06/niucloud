<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql; owned localhost schema only.\n");
require __DIR__.'/bootstrap.php';
define('HSX_LEAD_MANUAL_RECEIPTS_LIBRARY_ONLY',true);
require dirname(__DIR__).'/scripts/upgrade-manual-receipts.php';
use addon\hsx_lead\scripts\ManualReceiptsUpgrade;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$fixture='';
function mrCheck(bool $value,string $label):void {global $checks;if(!$value)throw new RuntimeException($label);$checks++;}
function mrDeny(callable $call,string $label):void {try{$call();}catch(Throwable $error){mrCheck(true,$label);return;}throw new RuntimeException('Not rejected: '.$label);}
function mrTables():array {return array_column(Db::query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() ORDER BY TABLE_NAME'),'TABLE_NAME');}
function mrProtected():array {$out=[];foreach(['member'=>'member_id','member_account_log'=>'id','hsx_lead_coop_order'=>'id','sys_config'=>'id','sys_role'=>'role_id','sys_schedule'=>'id']as$table=>$key)$out[$table]=Db::name($table)->order($key)->select()->toArray();return$out;}
try{
 [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
 $fixture=rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema.'/manual-schema';mkdir($fixture,0700,true);$command=new ManualReceiptsUpgrade($fixture);
 mrCheck($command->check()['pending_statements']===0,'fresh installation matches the strict new receipt schema');
 Db::name('member_account_log')->insert(['site_id'=>$site,'member_id'=>101,'account_type'=>'balance','account_data'=>'99.00','account_sum'=>'99.00','memo'=>'PROTECTED_FINANCIAL_FACT']);
 $protected=mrProtected();Db::execute('DROP TABLE `lt_hsx_lead_manual_receipt`');$before=mrTables();
 $report=$command->check();mrCheck($report['pending_statements']===1&&$report['missing_tables']===['hsx_lead_manual_receipt'],'plans exactly one missing evidence table');
 mrCheck(!$report['business_row_writes']&&!$report['backfill_receipts']&&!$report['changes_existing_fields_or_indexes'],'no ledger mutation, history replay or automatic alterations');
 mrCheck(!is_dir($fixture.'/runtime')&&mrTables()===$before&&mrProtected()===$protected,'check has no filesystem/schema/business writes');
 Db::startTrans();try{mrDeny(fn()=>$command->apply(),'refuses DDL inside a business transaction');}finally{Db::rollback();}
 mrCheck(!is_dir($fixture.'/runtime'),'transaction refusal happens before backup');
 $key='lead_manual_receipt:'.substr(hash('sha256',$schema.':lt_'),0,40);$pdo->query('SELECT GET_LOCK('.$pdo->quote($key).',0)');
 try{mrDeny(fn()=>$command->apply(),'refuses another holder of the exact database/prefix lock');}finally{$pdo->query('SELECT RELEASE_LOCK('.$pdo->quote($key).')');}
 $applied=$command->apply();mrCheck($applied['applied']&&$applied['created_tables']===['hsx_lead_manual_receipt']&&$applied['pending_statements']===0,'explicit apply creates and reads back exactly one table');
 mrCheck(array_values(array_diff(mrTables(),$before))===['lt_hsx_lead_manual_receipt'],'no unrelated table creation');
 mrCheck(mrProtected()===$protected,'all protected original business and financial rows remain identical');
 mrCheck((fileperms($applied['backup'])&0777)===0600&&(fileperms(dirname($applied['backup']))&0777)===0700,'metadata backup is private');
 $backup=file_get_contents($applied['backup']);mrCheck(!str_contains($backup,'PROTECTED_FINANCIAL_FACT')&&!str_contains($backup,'password')&&!str_contains($backup,'username'),'metadata backup contains no business rows or credentials');
 mrCheck($command->apply()['applied']===false,'repeat apply performs no new DDL');
 $row=['site_id'=>$site,'kind'=>'payment','order_id'=>1,'member_id'=>101,'request_id'=>'receipt-schema-fixture','method'=>'bank','account_label'=>'TEST ACCOUNT','external_no'=>'TEST-EXTERNAL-1','reference_hash'=>hash('sha256','fixture'),'amount'=>'99.00','received_at'=>time(),'operator_uid'=>1,'status'=>'recorded','reason'=>'synthetic verified receipt','snapshot_json'=>'{}','create_time'=>time(),'update_time'=>time()];
 Db::name('hsx_lead_manual_receipt')->insert($row);
 mrDeny(fn()=>Db::name('hsx_lead_manual_receipt')->insert(array_replace($row,['reference_hash'=>hash('sha256','other')])),'duplicate same-site request is rejected');
 mrDeny(fn()=>Db::name('hsx_lead_manual_receipt')->insert(array_replace($row,['request_id'=>'another-request'])),'one external receipt cannot be registered twice');
 Db::name('hsx_lead_manual_receipt')->insert(array_replace($row,['site_id'=>$site+1]));mrCheck(Db::name('hsx_lead_manual_receipt')->count()===2,'unique constraints preserve site isolation');
 Db::name('hsx_lead_manual_receipt')->insert(array_replace($row,['kind'=>'refund','reference_hash'=>hash('sha256','opposite-direction')]));mrCheck(Db::name('hsx_lead_manual_receipt')->count()===3,'separate payment/refund directions have distinct request identities');
 $saved=Db::name('hsx_lead_manual_receipt')->order('id')->select()->toArray();mrCheck($command->apply()['applied']===false&&Db::name('hsx_lead_manual_receipt')->order('id')->select()->toArray()===$saved,'repeat apply preserves all evidence rows');
 Db::execute('ALTER TABLE `lt_hsx_lead_manual_receipt` DROP INDEX `uk_reference`');$backups=glob($fixture.'/runtime/hsx_lead_upgrade/manual-receipts-*');
 mrDeny(fn()=>$command->check(),'detects a missing critical uniqueness constraint');mrDeny(fn()=>$command->apply(),'does not silently alter an anomalous financial table');
 mrCheck(glob($fixture.'/runtime/hsx_lead_upgrade/manual-receipts-*')===$backups,'invalid table stops before another backup or DDL');
 Db::execute('ALTER TABLE `lt_hsx_lead_manual_receipt` ADD UNIQUE KEY `uk_reference` (`site_id`,`reference_hash`)');
 Db::execute('ALTER TABLE `lt_hsx_lead_manual_receipt` MODIFY COLUMN `amount` decimal(10,2) NOT NULL');mrDeny(fn()=>$command->check(),'rejects a different amount precision');
 mrCheck(mrProtected()===$protected&&Db::name('hsx_lead_manual_receipt')->order('id')->select()->toArray()===$saved,'schema failure never edits financial/evidence facts');
 echo 'PASS '.$checks." manual receipt schema checks; random owned localhost schema only.\n";
}catch(Throwable$error){fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);$failed=true;}
finally{
 if($fixture!==''&&$schema!==''&&str_starts_with($fixture,rtrim((string)realpath(sys_get_temp_dir()),'/').'/'.$schema.'/')&&is_dir($fixture)){foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($fixture,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST)as$entry){if($entry->isFile()||$entry->isLink())unlink($entry->getPathname());else rmdir($entry->getPathname());}rmdir($fixture);}
 if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);
}
exit(!empty($failed)?1:0);
