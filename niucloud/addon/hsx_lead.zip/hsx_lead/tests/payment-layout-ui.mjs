import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {loadMobileUtility} from './mobile-utils.mjs'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.join(plugin,'../../../uni-app/package.json'))
const {renderToString}=require('@vue/server-renderer')
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript'),dom=require('@vue/compiler-dom'),sass=require('sass')
let checks=0
const check=(value,label)=>{assert.ok(value,label);checks++}
function execute(source,deps){const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{String,Number,Date,Math})(key=>{if(key in deps)return deps[key];throw Error(key)},module,module.exports);return module.exports}
const api=execute(fs.readFileSync(path.join(plugin,'uni-app/api/cooperation.ts'),'utf8'),{'@/utils/request':{}})
const filename=path.join(plugin,'uni-app/components/cooperation/CoopPaymentSummary.vue'),descriptor=compiler.parse(fs.readFileSync(filename,'utf8'),{filename}).descriptor,script=compiler.compileScript(descriptor,{id:'payment-layout',inlineTemplate:true})
check(!compiler.compileTemplate({source:descriptor.template.content,filename,id:'payment-layout',compilerOptions:{bindingMetadata:script.bindings}}).errors.length,'payment summary template compiles')
const component=execute(script.content,{vue:Vue,'../../api/cooperation':api}).default
async function summary(props){const app=Vue.createSSRApp({render:()=>Vue.h(component,props)});app.config.warnHandler=()=>{};app.component('u-icon',{setup:()=>()=>Vue.h('i')});return renderToString(app)}
let html=await summary({amount:undefined})
check(api.coopMoney(undefined)==='—'&&html.includes('—')&&!html.includes('¥0.00'),'unknown commission amount never appears as free or paid')
html=await summary({amount:'125.00',orderCreated:true})
check(html.includes('协作佣金')&&html.includes('¥125.00')&&html.includes('按原付款单继续支付'),'existing commission summary keeps its actual order amount and original-payment instruction')
check(!html.includes('套餐')&&!html.includes('权益期限'),'commission summary cannot imply membership terms or a second admission product')
html=await summary({amount:125,loading:true});check(html.includes('正在核对本笔付款结果'),'read in progress has an explicit nonterminal state')
html=await summary({amount:125,error:'原单待核对',message:'忽略的成功文案'});check(html.includes('原单待核对')&&!html.includes('忽略的成功文案'),'error feedback takes priority over stale success copy')
html=await summary({amount:125,completed:true,message:'支付已确认'});check(html.includes('本单已付款')&&html.includes('is-confirmed'),'only confirmed payment renders the completed state')
const sheetFile=path.join(plugin,'uni-app/components/cooperation/CoopTaskSheet.vue'),sheet=compiler.parse(fs.readFileSync(sheetFile,'utf8')).descriptor,tree=dom.baseParse(sheet.template.content)
const elementChildren=node=>(node.children||[]).filter(child=>child.type===1)
const rootPopup=elementChildren(tree).find(node=>node.tag==='u-popup')
check(!rootPopup,'a closed popup cannot remain a direct flex sibling of the active task page')
const mount=elementChildren(tree).find(node=>node.props.some(prop=>prop.name==='class'&&prop.value?.content==='coop-popup-mount'))
check(mount&&elementChildren(mount).some(node=>node.tag==='u-popup'),'non-page popup is preserved inside an owned mount rather than losing native close transitions')
const css=sass.compileString(sheet.styles[0].content).css
check(/\.coop-popup-mount\s*\{[^}]*flex:\s*none/.test(css)&&/\.coop-popup-mount\s*\{[^}]*height:\s*0/.test(css),'mount cannot take half the page height')
check(/\.coop-popup-mount\s*\{[^}]*overflow:\s*visible/.test(css),'native fixed popup is not clipped by its mount')
const source=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CooperationWorkbench.vue'),'utf8')
check(!source.includes('cooperationQuote')&&!source.includes('CoopPlanComparison')&&!source.includes("overlay === 'payment'"),'workbench has no second legacy membership quote or purchase surface')
check(source.includes('if (paymentId.value) { await resumePayment(); return }')&&source.includes('validatePaymentOrder(value, id, context)'),'commission creation preserves original-order protection and validates context before the cashier')
check(fs.readFileSync(path.join(plugin,'uni-app/components/cooperation/CoopCommissionForm.vue'),'utf8').includes('<CoopPaymentSummary v-if="locked" :amount="lead.commission_amount" order-created embedded />'),'an existing commission reuses the small read-only summary instead of showing a second editable amount')
check(!/request\.(post|put)|createCooperationOrder|\.pay\(/.test(descriptor.scriptSetup.content),'presentational summary cannot create or execute payment')
console.log(`PASS ${checks} payment layout checks; actual SFC/API and popup mount style contract, no site reads or payment writes.`)
