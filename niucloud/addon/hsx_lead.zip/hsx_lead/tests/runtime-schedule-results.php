<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$fn)if(function_exists($fn))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\cooperation\CooperationNoticeOutbox;
use addon\hsx_lead\app\support\Data;
use app\service\core\schedule\CoreScheduleService;
use think\facade\Db;
$pdo=null;$schema='';$checks=0;$failed=false;
function srCheck(bool$ok,string$label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $templates=require dirname(__DIR__).'/app/dict/schedule/schedule.php';$keys=['hsx_lead_unpaid_order_close','hsx_lead_order_refund_reconcile','hsx_lead_notice_recover'];$results=[];
    $orphan=(int)Data::query('audit',$site)->insertGetId(['site_id'=>$site,'entity_type'=>CooperationNoticeOutbox::TYPE,'entity_id'=>999999,'action'=>'notice_pending','detail_json'=>Data::json(['action'=>'assigned','assignment_version'=>1,'lead_status'=>'assigned','status'=>'pending','attempts'=>0]),'create_time'=>time()-300,'update_time'=>time()-300]);
    foreach($templates as$template){
        if(!in_array($template['key'],$keys,true))continue;
        $id=(int)Db::name('sys_schedule')->insertGetId(['addon'=>'hsx_lead','key'=>$template['key'],'time'=>Data::json($template['time']),'status'=>1,'count'=>10]);
        $schedule=array_replace($template,Db::name('sys_schedule')->where('id',$id)->find());
        (new CoreScheduleService())->execute($schedule,'');
        $log=Db::name('sys_schedule_log')->where('schedule_id',$id)->order('id desc')->find();$body=json_decode((string)$log['execute_result'],true);
        srCheck($log['status']==='success'&&is_array($body)&&is_string($body['message']??null),'actual framework schedule persists structured job result, not generic success: '.$template['key']);
        srCheck((int)Db::name('sys_schedule')->where('id',$id)->value('count')===11,'framework task execution counter retained/incremented once');
        $results[$template['key']]=$body;
    }
    $close=$results['hsx_lead_unpaid_order_close'];srCheck($close['examined']===0&&$close['closed']===0&&$close['reconciled']===0&&$close['blocked']===0,'empty close sweep retains distinct closed/recovered/review counts');
    $refund=$results['hsx_lead_order_refund_reconcile'];srCheck($refund['orders']['examined']===0&&$refund['deposits']['examined']===0&&str_contains($refund['message'],'原退款'),'refund log separates ordinary and deposit reconciliation without new transfers');
    $notice=$results['hsx_lead_notice_recover'];srCheck($notice['examined']===1&&$notice['processed']===0&&str_contains($notice['message'],'不代表用户已收到'),'notice log distinguishes examined intent from channel acceptance/delivery');
    srCheck(Data::row('audit',$site,$orphan)['action']==='notice_failed','orphan notice is visibly terminal rather than poisoning the next schedule');
    srCheck(Db::name('hsx_lead_coop_order')->count()===0&&Db::name('member_account_log')->count()===0,'diagnostic job logging creates no payment/financial fact');
    leadAssertIsolated($schema);echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'actual CoreScheduleService and three plugin jobs, persisted JSON result logs in owned local schema; no external delivery or financial transfers'],JSON_UNESCAPED_UNICODE),PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL after '.$checks.' checks: '.get_class($error).': '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
if($failed)exit(1);
