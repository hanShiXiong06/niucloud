import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'

// Actual mobile SFCs, actual request-state hook and installed z-paging data methods.
// No browser, network, database, uploads or payment operations.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), mobile = path.join(plugin, 'uni-app')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json')), Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc')
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
function execute(source, deps = {}, globals = {}) {
    const module = { exports: {} }, js = ts.transpileModule(viteFixture(source), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Date, Math, Number, String, Map, Set, Promise, JSON, console, ...globals })(key => { if (key in deps) return deps[key]; if (key === '../../api/promotion') return { promotionOverview: async () => { throw Error('Paging must not read marketing rules') } }; if (key.endsWith('.vue')) return { default: {} }; if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key)); throw Error('Unexpected dependency ' + key) }, module, module.exports)
    return module.exports
}
async function settle() { for (let step = 0; step < 8; step++) { await Promise.resolve(); await Vue.nextTick() } }
function sfc(name) {
    const filename = path.join(mobile, 'components/cooperation', name + '.vue'), source = fs.readFileSync(filename, 'utf8'), parsed = compiler.parse(source, { filename })
    check(!parsed.errors.length, name + ' SFC parses')
    const script = compiler.compileScript(parsed.descriptor, { id: name }), render = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename, id: name, compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
    check(!render.errors.length, name + ' real template compiles')
    return { source, script: script.content, template: parsed.descriptor.template.content }
}
const zDirectory = path.resolve(plugin, '../../../uni-app/node_modules/z-paging/components/z-paging/js')
const enumeration = execute(fs.readFileSync(path.join(zDirectory, 'z-paging-enum.js'), 'utf8')).default
// Installed delay/addData/_addData/model-emission/load-more implementations,
// with a deterministic timer queue so the real late-write window is exercised.
const timers = new Map(); let timerId = 0
const zUtils = execute(fs.readFileSync(path.join(zDirectory, 'z-paging-utils.js'), 'utf8'), { '../config/index': { default: {} }, './z-paging-constant': { default: { delayTime: 0 } } }, { setTimeout: callback => { timers.set(++timerId, callback); return timerId }, clearTimeout: id => timers.delete(id) }).default
const zDependencies = { '.././z-paging-utils': { default: zUtils }, '.././z-paging-constant': { default: { delayTime: 0 } }, '.././z-paging-enum': { default: enumeration }, '../z-paging-interceptor': { default: {} } }
const dataModule = execute(fs.readFileSync(path.join(zDirectory, 'modules/data-handle.js'), 'utf8'), zDependencies).default
const moreModule = execute(fs.readFileSync(path.join(zDirectory, 'modules/load-more.js'), 'utf8'), zDependencies).default
// Preserve the installed mounted scheduling, not a synchronous parent reload stub.
const mainAst = ts.createSourceFile('z-paging-main.js', fs.readFileSync(path.join(zDirectory, 'z-paging-main.js'), 'utf8'), ts.ScriptTarget.ES2020, true, ts.ScriptKind.JS)
const mountedSource = mainAst.statements.find(ts.isExportAssignment).expression.properties.find(item => item.name?.text === 'mounted').getText(mainAst)
const mounted = execute('export default {' + mountedSource + '}', {}, { u: { ...zUtils, getTime: () => 1, getSystemInfoSync: () => ({ platform: 'ios' }) }, c: { delayTime: 0 }, setTimeout: callback => { timers.set(++timerId, callback); return timerId } }).default.mounted
async function flush() {
    for (let step = 0; step < 20; step++) {
        await settle()
        const batch = [...timers.values()]; timers.clear()
        for (const callback of batch) callback()
    }
}
function pager(query, initial = []) {
    let totalData = [...initial]
    const state = { ...Object.fromEntries(Object.entries(dataModule.methods).filter(([, value]) => typeof value === 'function')), pageNo: 1, defaultPageNo: 1, defaultPageSize: 2, concat: false, privateConcat: true, customNoMore: -1, currentData: [], realTotalData: [...initial], loading: false, loadingStatus: enumeration.More.Default, isLoadFailed: false, completions: [], emissions: [], pending: Promise.resolve(), scrollTop: 145, requestTimeStamp: 0, minDelay: 0, delay: 0, callNetworkReject: false, dataPromiseResultMap: {}, autoCleanListWhenReload: false, isUserReload: true,
        get isFirstPage() { return this.pageNo === 1 }, get finalConcat() { return dataModule.computed.finalConcat.call(this) },
        get totalData() { return totalData }, set totalData(value) { const old = totalData; totalData = value; dataModule.methods._totalDataChange.call(this, value, old) },
        $nextTick(callback) { return Vue.nextTick(callback?.bind(this)) }, $emit(event, value) { this.emissions.push({ event, value }) },
        _endSystemLoadingAndRefresh() {}, _refresherEnd() { this.loading = false }, _doCheckScrollViewShouldFullHeight() {}, _callMyParentList() {}, _callMyParentQuery() {}, _getNodeClientRect: async () => [{ height: 0 }],
        _startLoading(reload) { this.loading = true; this.loadingType = reload ? enumeration.LoadingType.Refresher : enumeration.LoadingType.LoadMore },
        _emitQuery(page, size, from) { this.pending = Promise.resolve(query(page, size, from)); return this.pending },
        complete(data) { this.completions.push({ success: data !== false }); return dataModule.methods.complete.call(this, data) },
        completeByNoMore(data, noMore) { this.completions.push({ success: true, noMore }); return dataModule.methods.completeByNoMore.call(this, data, noMore) },
        reload() { this.pageNo = 1; this.firstPageLoaded = true; this._startLoading(true); return this._emitQuery(1, this.defaultPageSize, 'reload') },
        pull() { this.pageNo = 1; this.firstPageLoaded = true; this._startLoading(true); return this._emitQuery(1, this.defaultPageSize, 'user-pull-down') },
        more() { if (!this.loading && this.loadingStatus !== enumeration.More.NoMore) moreModule.methods._doLoadingMore.call(this); return this.pending }
    }
    Object.assign(state, { auto: true, createdReload: false, isOnly: false, finalUseCache: false, finalRefresherEnabled: false, useCustomRefresher: false,
        updateFixedLayout() {}, _updateCachedSuperContentHeight() {}, _updateScrollViewHeight() {}, updatePageScrollTopHeight() {}, updatePageScrollBottomHeight() {}, updateLeftAndRightWidth() {}, _onEmit() {}, _nUpdateRefresherWidth() {}, _getCssSafeAreaInsetBottom() {}, _cleanRefresherEndTimeout() {} })
    return Vue.markRaw(state)
}
function mountPager(state, reference, revision, query, rows) {
    let attachment=0
    Vue.watch([state.leadListVisible,state[revision]],async([visible,renderRevision])=>{
        const queryHandler=state[query].value
        const turn=++attachment;state[reference].value=null
        if(!visible)return
        // Native v-if attachment/ref registration can follow the parent's tick.
        // First query belongs to the real installed child mounted lifecycle.
        await Vue.nextTick();await Vue.nextTick()
        if(turn!==attachment||renderRevision!==state[revision].value||!state.leadListVisible.value)return
        const value=pager(queryHandler,rows());state[reference].value=value;mounted.call(value)
    },{immediate:true,flush:'post'})
    return () => state[reference].value
}
async function activateMountedPagers(){const queued=[...timers.values()];timers.clear();for(const callback of queued)callback();await settle()}
const workbench = sfc('CooperationWorkbench'), inventoryComponent = sfc('CoopStoreInventory'), sheet = sfc('CoopTaskSheet')
check(workbench.source.includes("from 'z-paging/components/z-paging/z-paging.vue'") && inventoryComponent.source.includes("from 'z-paging/components/z-paging/z-paging.vue'"), 'both lists import the existing installed component, not a copied or new paging library')
for (const [name, component] of [['lead', workbench], ['inventory', inventoryComponent]]) check(component.template.includes(':fixed="false"') && component.template.includes(':auto="true"') && component.template.includes(':concat="false"') && component.template.includes(':safe-area-inset-bottom="false"') && component.template.includes(':call-network-reject="false"'), name + ' pager has one cumulative data owner and parent-owned safe area; initial load belongs to mounted')
for (const [name, component] of [['lead', workbench], ['inventory', inventoryComponent]]) check(component.template.includes(':key=') && component.template.includes(':model-value=') && !/v-model="(?:rows|ui\.rows\.value)"/.test(component.template) && !component.template.includes('@update:model-value'), name + ' remounts pager revisions and never grants delayed model emissions ownership of request rows')
check(!workbench.template.includes('@scrolltolower') && !workbench.template.includes('点击加载更多') && !inventoryComponent.template.includes('加载更多库存'), 'manual reach-bottom and load-more paths are removed')
check(workbench.template.indexOf('coop-delivery-controls') < workbench.template.indexOf('<z-paging') && workbench.template.indexOf('</z-paging>') < workbench.template.indexOf('coop-publish-dock'), 'role/search filters and publisher footer remain outside the only lead scroller')
check(inventoryComponent.template.includes('fixed-body') && sheet.template.includes('v-if="fixedBody"') && inventoryComponent.template.includes('#filters'), 'inventory pager is inside a non-scrolling sheet body while search and footer stay fixed')

const storage = new Map([['wap_site_id', 100005]]), titles = []
const runtime = { getStorageSync: key => storage.get(key), setStorageSync: (key, value) => storage.set(key, value), removeStorageSync: key => storage.delete(key), setNavigationBarTitle: value => titles.push(value.title), showToast() {}, showModal() {} }
function fixture() {
    const calls = [], controls = { list: async query => ({ data: { data: query.page === 1 ? [{ id: 1 }, { id: 2 }] : [{ id: 3 }], total: 3 } }) }
    const api = { cooperationPageUrls: { deliveries: '/addon/hsx_lead/pages/workbench/index' }, coopError: error => error.message, cooperationBootstrap: async () => { calls.push({ type: 'bootstrap' }); return { data: { profile: { id: 7 }, config: { enabled: true }, providers: [], stats: {} } } }, cooperationLeads: async query => { calls.push({ type: 'list', ...query }); return controls.list(query) } }
    const hook = execute(fs.readFileSync(path.join(mobile, 'composables/useCooperation.ts'), 'utf8'), { vue: Vue, '@/utils/common': { getSiteId:()=>100005, getToken: () => 'member-a' }, '../api/cooperation': api })
    const component = execute(workbench.script, { vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} }, '@/utils/common': { getSiteId:()=>100005, getToken: () => 'member-a' }, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack() {} }) }, '../../composables/useCooperationSubscribe': { useCooperationSubscribe:()=>({loading:Vue.ref(false), prepare: async () => false, request() {} }) }, '../../api/cooperation': api, '../../composables/useCooperation': hook, '../../utils/cooperation-navigation': {} }, { uni: runtime })
    const state = component.default.setup({ initialId: 0, initialTab: 'deliveries', initialDirection: 'outgoing', initialPromotion: false, initialInviter: 0, initialPaymentId: 0, initialPurpose: '', task: '' }, { expose() {} })
    const current = mountPager(state, 'leadPagingRef', 'leadPagingRevision', 'leadPagingQuery', () => state.ui.rows.value)
    return { state, get paging() { return current() }, calls, controls, listCalls: () => calls.filter(call => call.type === 'list'), bootstrapCalls: () => calls.filter(call => call.type === 'bootstrap') }
}
const h = fixture(); await Promise.all([h.state.initialize(), h.state.initialize()]); await flush()
check(h.listCalls().length === 1 && h.bootstrapCalls().length === 1, 'simultaneous mounted/show initialization produces one bootstrap and exactly one first-page list query')
check(titles.at(-1) === '找门店', 'native title identifies the publishing workspace without a duplicated role bar')
equal(h.paging.totalData.map(row => row.id), [1, 2], 'actual z-paging concat=false receives the cumulative first page once')
h.paging.more(); await flush(); equal(h.paging.totalData.map(row => row.id), [1, 2, 3], 'appending through the existing hook does not make z-paging concatenate the accumulated first page again')
const atLastPage = h.listCalls().length; h.paging.more(); await flush(); check(h.listCalls().length === atLastPage && h.paging.loadingStatus === enumeration.More.NoMore, 'server total marks the last page and prevents another upward request')
h.paging.pull(); await flush(); check(h.bootstrapCalls().length === 2 && h.listCalls().length === atLastPage + 1 && h.listCalls().at(-1).page === 1, 'one pull refresh updates metadata once and queries the reset list exactly once')
h.state.leadKeyword.value = '搜索'; h.state.searchLeads(); await flush()
check(h.listCalls().at(-1).keyword === '搜索' && h.listCalls().at(-1).page === 1, 'search resets the paging owner and preserves the entered query')

// Exercise the installed u-search event order, not only a pre-updated parent
// ref. Its keyword watcher emits v-model asynchronously, while custom/search
// synchronously submit the actual input value. The submitted value wins.
const sharedSearch = sfc('CooperationSearch')
const nativeSearchFile = path.resolve(plugin, '../../../uni-app/node_modules/uview-plus/components/u-search/u-search.vue')
const nativeSearchScript = compiler.parse(fs.readFileSync(nativeSearchFile, 'utf8'), { filename: nativeSearchFile }).descriptor.script.content
const nativeSearchAst = ts.createSourceFile('installed-u-search.js', nativeSearchScript, ts.ScriptTarget.ES2020, true, ts.ScriptKind.JS)
const nativeOptions = nativeSearchAst.statements.find(ts.isExportAssignment).expression
const nativeMethods = nativeOptions.properties.find(item => item.name?.text === 'methods').initializer
const nativeWatch = nativeOptions.properties.find(item => item.name?.text === 'watch').initializer
const selectedMethods = nativeMethods.properties.filter(item => ['inputChange', 'search', 'custom'].includes(item.name?.text)).map(item => item.getText(nativeSearchAst)).join(',')
const keywordWatcher = nativeWatch.properties.find(item => item.name?.text === 'keyword').getText(nativeSearchAst)
const installedSearch = execute('export default {' + selectedMethods + ',' + keywordWatcher + '}', {}, { uni: { hideKeyboard() {} } }).default
function searchDriver(owner) {
    const searchComponent = execute(sharedSearch.script, { vue: Vue }).default
    const emitted = []
    const shared = searchComponent.setup({ modelValue: owner.state.leadKeyword.value, placeholder: '搜索客户或意向型号', showAction: true, actionText: '查询', disabled: false, loading: false, compact: false }, { expose() {}, emit(event, value) {
        emitted.push({ event, value })
        if (event === 'update:modelValue') owner.state.leadKeyword.value = String(value)
        else if (event === 'search' || event === 'custom') owner.state.searchLeads(value)
    } })
    const native = { keyword: owner.state.leadKeyword.value, $emit(event, value) {
        if (event === 'update:modelValue') shared.update(value)
        else if (event === 'custom') shared.custom(value)
        else if (event === 'search') shared.search(value)
    } }
    return { emitted, native,
        input(value) { installedSearch.inputChange.call(native, { detail: { value } }) },
        custom() { installedSearch.custom.call(native) },
        search() { installedSearch.search.call(native, { detail: { value: native.keyword } }) },
        flushModel() { installedSearch.keyword.call(native, native.keyword) }
    }
}
for (const direction of ['outgoing', 'incoming']) {
    const immediate = fixture()
    await immediate.state.initialize(); await flush()
    if (direction === 'incoming') { immediate.state.changeLeadDirection('incoming'); await flush() }
    immediate.controls.list = async query => ({ data: { data: query.keyword === '3' ? [{ id: 303, customer_name: '张3' }] : [], total: query.keyword === '3' ? 1 : 0 } })
    const input = searchDriver(immediate), readsBefore = immediate.listCalls().length
    input.input('3'); input.custom()
    check(input.emitted[0].event === 'custom' && input.emitted[0].value === '3', direction + ': installed native custom event carries the current input before the queued parent model update')
    input.flushModel(); await flush()
    check(immediate.listCalls().length === readsBefore + 1 && immediate.listCalls().at(-1).keyword === '3', direction + ': typing then immediately querying commits the submitted value and makes exactly one first-page request')
    equal(immediate.state.ui.rows.value.map(row => row.customer_name), ['张3'], direction + ': matching customer is shown after query without requiring pull-to-refresh')
    const beforeDuplicate = immediate.listCalls().length
    input.input('张3'); input.search(); input.custom(); input.flushModel(); await flush()
    check(immediate.listCalls().length === beforeDuplicate + 1 && immediate.listCalls().at(-1).keyword === '张3', direction + ': paired native keyboard/action submissions are coalesced into one committed query')
    const beforeClear = immediate.listCalls().length
    immediate.state.leadKeyword.value = '仍未回传的旧文本'; immediate.state.clearLeadSearch(); await flush()
    check(immediate.listCalls().length === beforeClear + 1 && immediate.listCalls().at(-1).keyword === '' && immediate.state.leadKeyword.value === '', direction + ': clear explicitly commits an empty query even before native model clearing has propagated')
}

{
    const racing = fixture(); let releaseOriginal, releaseCurrent
    racing.controls.list = query => new Promise(resolve => { if (query.keyword === '') releaseOriginal = resolve; else releaseCurrent = resolve })
    await racing.state.initialize(); await settle(); await activateMountedPagers()
    check(typeof releaseOriginal === 'function' && racing.state.ui.listLoading.value, 'new-filter race begins while the original native first-page request is still in flight')
    const input = searchDriver(racing)
    input.input('3'); input.custom(); input.flushModel(); await settle()
    // The new keyed native pager is mounted, but its scheduled initial query
    // has not run yet. A formerly valid API response must not repopulate it.
    releaseOriginal({ data: { data: [{ id: 999, customer_name: '旧条件客户' }], total: 1 } }); await settle()
    equal(racing.state.ui.rows.value, [], 'old-filter API data cannot refill the current list between filter commit and the next native mounted query')
    await activateMountedPagers(); await settle()
    check(typeof releaseCurrent === 'function' && racing.listCalls().at(-1).keyword === '3', 'latest filter starts its own native first-page request without pull refresh')
    releaseCurrent({ data: { data: [{ id: 303, customer_name: '张3' }], total: 1 } }); await flush()
    equal(racing.state.ui.rows.value.map(row => row.customer_name), ['张3'], 'only the latest submitted filter owns visible rows after the in-flight request race')
}
{
    const staleFailure = fixture(); let rejectOriginal
    staleFailure.controls.list = query => query.keyword === '' ? new Promise((resolve, reject) => { rejectOriginal = reject }) : Promise.resolve({ data: { data: [{ id: 303, customer_name: '张3' }], total: 1 } })
    await staleFailure.state.initialize(); await settle(); await activateMountedPagers()
    const input = searchDriver(staleFailure)
    input.input('3'); input.custom(); input.flushModel(); await settle()
    rejectOriginal(new Error('旧条件延迟失败')); await settle()
    check(staleFailure.state.ui.listError.value === '', 'an old-query rejection cannot attach its error to a newly committed filter before the next mounted request')
    await activateMountedPagers(); await flush()
    equal(staleFailure.state.ui.rows.value.map(row => row.customer_name), ['张3'], 'latest query remains usable after an obsolete query fails')
}
{
    const retry = fixture(); await retry.state.initialize(); await flush()
    const input = searchDriver(retry)
    retry.controls.list = async () => { throw Error('当前搜索暂时失败') }
    input.input('3'); input.custom(); input.flushModel(); await flush()
    check(!!retry.state.ui.listError.value && !retry.state.ui.listLoading.value && !retry.state.ui.rows.value.length, 'a current search failure is visible and releases loading')
    const beforeRetry = retry.listCalls().length
    retry.controls.list = async () => ({ data: { data: [{ id: 303, customer_name: '张3' }], total: 1 } })
    input.custom(); await flush()
    check(retry.listCalls().length === beforeRetry + 1 && retry.listCalls().at(-1).keyword === '3', 'same-keyword event de-duplication does not suppress an explicit retry after a completed failure')
    equal(retry.state.ui.rows.value.map(row => row.customer_name), ['张3'], 'explicit search retry shows the customer without requiring a refresh gesture')
}
h.state.filterStatus('following'); await flush()
check(h.listCalls().at(-1).status === 'following' && h.listCalls().at(-1).page === 1, 'status selection resets to page one through the same owner')
h.state.changeLeadDirection('incoming'); await flush()
check(titles.at(-1) === '找客户', 'shared role state keeps the native title aligned with the actual query direction')
check(h.listCalls().at(-1).direction === 'incoming' && h.listCalls().at(-1).keyword === '' && h.listCalls().at(-1).status === '', 'role changes clear role-specific query state and make exactly the incoming request')

let finishOld; h.controls.list = query => query.direction === 'incoming' ? new Promise(resolve => { finishOld = resolve }) : Promise.resolve({ data: { data: [{ id: 40 }], total: 1 } })
h.state.reloadLeads(); await settle(); await activateMountedPagers(); const obsolete = h.paging.pending; h.state.changeLeadDirection('outgoing'); await flush()
finishOld({ data: { data: [{ id: 999 }], total: 1 } }); await obsolete; await flush()
equal(h.paging.totalData.map(row => row.id), [40], 'late incoming data cannot overwrite a newer outgoing role selection')

const late = fixture(); late.controls.list = async () => ({ data: { data: [{ id: 101 }], total: 1 } }); await late.state.initialize(); await settle(); await activateMountedPagers()
const oldRolePager = late.paging, oldRoleQuery = late.state.leadPagingQuery.value
check(oldRolePager.completions.length === 1 && !oldRolePager.emissions.some(event => event.event === 'update:modelValue'), 'the test stops after actual addData nextTick and before its delayed model emission')
let releaseNewRole; late.controls.list = () => new Promise(resolve => { releaseNewRole = resolve }); late.state.changeLeadDirection('incoming'); await flush()
check(late.paging !== oldRolePager && oldRolePager.emissions.some(event => event.event === 'update:modelValue' && event.value[0]?.id === 101), 'switching roles remounts the pager while the old installed data path really emits its queued outgoing rows')
equal(late.state.ui.rows.value, [], 'the old queued model emission cannot repopulate incoming with outgoing rows')
const beforeOldQuery = late.listCalls().length; await oldRoleQuery(1, 2, 'reload'); check(late.listCalls().length === beforeOldQuery, 'queued query callbacks from an obsolete keyed instance are ignored')
releaseNewRole({ data: { data: [{ id: 201 }], total: 1 } }); await flush(); equal(late.state.ui.rows.value.map(row => row.id), [201], 'only the current role response populates the new list')

const lateFilter = fixture(); lateFilter.controls.list = async () => ({ data: { data: [{ id: 102 }], total: 1 } }); await lateFilter.state.initialize(); await settle(); await activateMountedPagers()
const oldFilterPager = lateFilter.paging; let releaseFilter
lateFilter.controls.list = () => new Promise(resolve => { releaseFilter = resolve }); lateFilter.state.leadKeyword.value = '已提交条件'; lateFilter.state.searchLeads(); await flush()
check(lateFilter.paging !== oldFilterPager && oldFilterPager.emissions.some(event => event.event === 'update:modelValue'), 'submitted filters isolate the same installed delayed completion window, not just direction changes')
equal(lateFilter.state.ui.rows.value, [], 'previous-filter data remains cleared even when its queued completion emits after reload')
releaseFilter({ data: { data: [{ id: 202 }], total: 1 } }); await flush()
equal(lateFilter.state.ui.rows.value.map(row => row.id), [202], 'new-filter data is not combined with the previous completed result')

const draft = fixture(); let releaseDraft
draft.controls.list = () => new Promise(resolve => { releaseDraft = resolve }); await draft.state.initialize(); await settle(); await activateMountedPagers()
draft.state.leadKeyword.value = '尚未提交的输入'; releaseDraft({ data: { data: [{ id: 111 }], total: 1 } }); await flush()
check(draft.state.ui.query.keyword === '' && draft.state.leadKeyword.value === '尚未提交的输入' && !draft.paging.loading && draft.paging.completions.length === 1, 'typing during a pending read does not invalidate its applied signature or leave z-paging loading forever')
equal(draft.state.ui.rows.value.map(row => row.id), [111], 'unsubmitted search text preserves the completed applied-query result')
draft.controls.list = async () => ({ data: { data: [{ id: 112 }], total: 1 } }); draft.paging.pull(); await flush()
check(draft.listCalls().at(-1).keyword === '' && draft.state.leadKeyword.value === '尚未提交的输入', 'pull refresh uses the applied keyword and preserves an unsubmitted search draft')

const failed = fixture(); await failed.state.initialize(); await flush()
failed.controls.list = async () => { throw Error('合成第二页失败') }; failed.paging.more(); await flush()
equal(failed.state.ui.rows.value.map(row => row.id), [1, 2], 'append failure retains previously loaded content')
check(!failed.paging.loading && failed.paging.pageNo === 1 && failed.paging.loadingStatus === enumeration.More.Fail && failed.state.ui.listError.value.includes('第二页失败'), 'failed load-more releases loading and rolls back the pager for a retry of the same page')
failed.controls.list = async () => ({ data: { data: [{ id: 3 }], total: 3 } }); failed.paging.more(); await flush()
check(failed.listCalls().at(-1).page === 2 && failed.paging.loadingStatus === enumeration.More.NoMore, 'retry requests page two rather than skipping to page three and then recognizes the end')
failed.controls.list = async () => { throw Error('合成筛选失败') }; failed.state.leadKeyword.value = '新搜索'; failed.state.searchLeads(); await flush()
check(!failed.state.ui.rows.value.length && !failed.state.ui.total.value && failed.paging.isLoadFailed, 'failed new filtering clears old-query results and presents a retryable first-page error')
failed.controls.list = async () => ({ data: { data: [{ id: 202 }], total: 1 } }); failed.paging.more(); await flush()
check(failed.listCalls().at(-1).page === 1 && failed.listCalls().at(-1).keyword === '新搜索', 'actual footer _doLoadingMore after a first-page failure restarts page one instead of requesting page two')
equal(failed.state.ui.rows.value.map(row => row.id), [202], 'first-page retry cannot mix previous-query rows into the new result')
failed.controls.list = async () => { throw Error('同条件刷新失败') }; failed.paging.pull(); await flush()
check(failed.state.ui.rows.value[0]?.id === 202 && !failed.paging.loading && !failed.state.ui.listLoading.value, 'a same-condition pull failure retains already-read rows and releases both loading states')
failed.controls.list = async () => ({ data: { data: [{ id: 203 }], total: 1 } }); failed.paging.more(); await flush()
check(failed.listCalls().at(-1).page === 1 && failed.state.ui.rows.value.length === 1 && failed.state.ui.rows.value[0].id === 203, 'footer retry after a failed same-condition pull also retries page one instead of appending an unverified page two')

const empty = fixture(); empty.controls.list = async () => { throw Error('合成首屏失败') }; await empty.state.initialize(); await flush()
check(empty.paging.isLoadFailed && !empty.state.ui.rows.value.length && workbench.template.includes('#empty="{ isLoadFailed }"'), 'first-page failure has a retryable error empty state, not a false successful empty result')
empty.controls.list = async () => ({ data: { data: [], total: 0 } }); empty.state.reloadLeads(); await flush()
check(!empty.paging.isLoadFailed && empty.paging.loadingStatus === enumeration.More.NoMore && !empty.state.ui.listError.value, 'a successful empty response clears the failure and terminates pagination')

const resumed = fixture(); await resumed.state.initialize(); await flush()
let releaseRead; resumed.controls.list = () => new Promise(resolve => { releaseRead = resolve }); const hiddenRead = resumed.paging.more(); resumed.state.pausePage(); releaseRead({ data: { data: [{ id: 999 }], total: 3 } }); await hiddenRead
resumed.controls.list = async () => ({ data: { data: [{ id: 3 }], total: 3 } }); const beforeResume = resumed.listCalls().length, beforeBoot = resumed.bootstrapCalls().length
const resumedInitialization = resumed.state.initialize(); await flush(); await resumedInitialization
check(resumed.listCalls().length === beforeResume + 1 && resumed.bootstrapCalls().length === beforeBoot, 'only an actually interrupted append is resumed; no extra bootstrap or duplicate pager query occurs')
equal(resumed.paging.totalData.map(row => row.id), [1, 2, 3], 'resumed append repairs pager state while retaining prior pages')
const stableReads = resumed.listCalls().length; resumed.state.pausePage(); await resumed.state.initialize()
check(resumed.listCalls().length === stableReads && resumed.paging.scrollTop === 145, 'leaving and returning after completion retains scroll/data without a new read')

const stockCalls = [], stockControls = { read: async query => ({ data: { data: query.page === 1 ? [{ id: 1, model: '型号' }, { id: 2, model: '型号' }] : [{ id: 3, model: '型号' }], total: 3, snapshot_at: 100 } }) }
const stockProps = Vue.reactive({ show: false, page: true, store: { id: 7, name: '合成门店' } })
const stock = execute(inventoryComponent.script, { vue: { ...Vue, onBeforeUnmount() {} }, '../../api/cooperation': { cooperationStoreInventory: async (id, query) => { stockCalls.push({ id, ...query }); return stockControls.read(query) }, coopError: error => error.message, coopDate: String, coopMoney: String } }, { uni: runtime }).default.setup(stockProps, { expose() {}, emit() {} })
let stockMountSequence = 0
Vue.watch([() => stockProps.show, stock.pagingRevision], async ([show]) => {
    const mountSequence = ++stockMountSequence
    stock.pagingRef.value = null
    if (!show) return
    await Vue.nextTick()
    if (mountSequence !== stockMountSequence || !stockProps.show) return
    const value = pager(stock.pagingQuery.value, stock.rows.value)
    stock.pagingRef.value = value
    mounted.call(value)
}, { immediate: true, flush: 'post' })
const currentStockPager = () => stock.pagingRef.value
stockProps.show = true; await flush()
check(stockCalls.length === 1 && stockCalls[0].id === 7, 'opening inventory performs exactly one initial query for the selected store')
currentStockPager().more(); await flush(); equal(currentStockPager().totalData.map(row => row.id), [1, 2, 3], 'inventory uses cumulative replacement without duplicate concatenation')
const stockAtEnd = stockCalls.length; currentStockPager().more(); await flush(); check(stockCalls.length === stockAtEnd, 'inventory stops at the server total')
stock.keyword.value = '苹果'; stock.search(); await flush()
check(stockCalls.at(-1).page === 1 && stockCalls.at(-1).keyword === '苹果', 'inventory search reloads page one with its current keyword')
stockControls.read = async () => { throw Error('合成库存失败') }; currentStockPager().more(); await flush(); check(currentStockPager().loadingStatus === enumeration.More.Fail && stock.rows.value.length === 2 && !!stock.error.value && !stock.loading.value, 'inventory failure retains reference rows and releases request loading despite the non-rejecting pending completion promise')
const beforeSameStore = stockCalls.length; stockProps.store = { id: 7, name: '同一门店更新名称' }; await Vue.nextTick(); await Vue.nextTick()
check(stockCalls.length === beforeSameStore && stock.keyword.value === '苹果', 'updating the same store metadata does not reset inventory search or randomly reload')
stock.keyword.value = '新条件'; stock.search(); await flush()
check(!stock.rows.value.length && !stock.total.value && currentStockPager().isLoadFailed, 'failed inventory search clears previous-keyword rows and shows a first-page failure')
stockControls.read = async () => ({ data: { data: [{ id: 501 }], total: 1 } }); currentStockPager().more(); await flush()
check(stockCalls.at(-1).page === 1 && stockCalls.at(-1).keyword === '新条件', 'inventory actual footer _doLoadingMore retries page one after a failed new search')
equal(stock.rows.value.map(row => row.id), [501], 'inventory footer retry never appends page two to a previous query')
let releaseStockDraft; stockControls.read = () => new Promise(resolve => { releaseStockDraft = resolve })
stock.keyword.value = '已提交库存'; stock.search(); await flush(); stock.keyword.value = '未提交库存输入'
releaseStockDraft({ data: { data: [{ id: 502 }], total: 1 } }); await flush()
check(stock.appliedKeyword.value === '已提交库存' && stock.keyword.value === '未提交库存输入' && !currentStockPager().loading, 'inventory records the requested keyword, not text typed while that request is pending')
const oldStockPager = currentStockPager(); stockControls.read = async () => ({ data: { data: [{ id: 503 }], total: 1 } }); stock.keyword.value = '库存旧结果'; stock.search(); await settle()
const stockMountedTimers = [...timers.values()]; timers.clear(); for (const callback of stockMountedTimers) callback(); await settle()
const pendingStockPager = currentStockPager(); check(pendingStockPager !== oldStockPager && !pendingStockPager.emissions.some(event => event.event === 'update:modelValue'), 'inventory delayed-completion test stops at the actual dependency timer boundary')
let releaseNewStock; stockControls.read = () => new Promise(resolve => { releaseNewStock = resolve }); stock.keyword.value = '库存新结果'; stock.search(); await flush()
check(pendingStockPager.emissions.some(event => event.event === 'update:modelValue' && event.value[0]?.id === 503) && !stock.rows.value.length, 'a real old inventory model emission cannot restore rows cleared for a newer search')
releaseNewStock({ data: { data: [{ id: 504 }], total: 1 } }); await flush(); equal(stock.rows.value.map(row => row.id), [504], 'only the current inventory search result is rendered')

// The installed footer retry advances pageNo even when a pull of page one
// failed with old rows retained. Income/orders must restart the keyed pager.
function mountSimplePager(state, active, getRows) {
    let attachment = 0
    Vue.watch([active, state.revision], async ([visible, revision]) => {
        const turn = ++attachment, query = state.pagingQuery.value
        state.pagingRef.value = null
        if (!visible) return
        await Vue.nextTick(); await Vue.nextTick()
        if (turn !== attachment || revision !== state.revision.value || !active.value) return
        const value = pager(query, getRows()); state.pagingRef.value = value; mounted.call(value)
    }, { immediate: true, flush: 'post' })
    return () => state.pagingRef.value
}
for (const kind of ['income', 'orders']) {
    const pages = [], controls = { fail: false, id: 601 }, common = { getSiteId: () => 100005, getToken: () => 'member-a' }
    const readPage = async query => {
        pages.push(query.page)
        if (controls.fail) throw Error('合成首屏刷新失败')
        const data = { data: [{ id: controls.id, income_type: 'membership', status: 'settled' }], total: 5 }
        return { data: kind === 'income' ? { account: { available: '9.90' }, entries: data } : data }
    }
    let state, active, rows, readError
    if (kind === 'income') {
        const incomeHook = execute(fs.readFileSync(path.join(mobile, 'composables/useCooperationIncome.ts'), 'utf8'), {
            vue: Vue, '@/utils/common': common,
            '../api/cooperation': { coopError: error => error.message },
            '../api/promotion': { promotionIncome: readPage },
            '../utils/cooperation-income': loadMobileUtility('cooperation-income')
        }, { uni: runtime })
        const component = sfc('CoopIncomePanel'), props = Vue.reactive({ active: true, initialType: 'all', initialStatus: '' })
        state = execute(component.script, { vue: { ...Vue, onBeforeUnmount() {} }, '@/utils/common': common, '../../api/cooperation': { coopMoney: String, coopDate: String }, '../../composables/useCooperationIncome': incomeHook }, { uni: runtime }).default.setup(props, { expose() {}, emit() {} })
        active = Vue.computed(() => props.active); rows = state.ui.rows; readError = state.ui.error
    } else {
        const lifecycle = {}, source = fs.readFileSync(path.join(mobile, 'pages/orders/index.vue'), 'utf8')
        const script = compiler.parse(source).descriptor.scriptSetup.content + '\nexport { active, rows, error, revision, pagingRef, pagingQuery };'
        state = execute(script, { vue: Vue, '@/utils/common': common, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack() {} }) }, '@dcloudio/uni-app': { onLoad() {}, onHide() {}, onShow: callback => lifecycle.show = callback }, '../../api/cooperation': { cooperationOrders: readPage, coopError: error => error.message, coopMoney: String, coopDate: String } }, { uni: runtime })
        lifecycle.show(); active = state.active; rows = state.rows; readError = state.error
    }
    const currentPager = mountSimplePager(state, active, () => rows.value)
    await flush()
    equal(pages, [1], kind + ' mounted pager loads page one once')
    controls.fail = true; currentPager().pull(); await flush()
    check(rows.value[0]?.id === 601 && !!readError.value && currentPager().loadingStatus === enumeration.More.Fail, kind + ' failed pull keeps prior rows but ends loading with a retryable failure')
    const obsoletePager = currentPager(); controls.fail = false; controls.id = 602
    obsoletePager.more(); await flush()
    equal(pages, [1, 1, 1], kind + ' footer retry after failed page one never requests page two')
    check(currentPager() !== obsoletePager && currentPager().pageNo === 1 && rows.value.length === 1 && rows.value[0].id === 602 && !readError.value, kind + ' restarts the current keyed pager and replaces retained rows rather than mixing snapshots')
    controls.id = 603; currentPager().more(); await flush()
    check(pages.at(-1) === 2 && rows.value.length === 2, kind + ' permits page two only after the replacement page one succeeded')
}

const lifecycle = {}, pageHook = execute(fs.readFileSync(path.join(mobile, 'composables/useCooperationPage.ts'), 'utf8'), { vue: Vue, '@/hooks/useShare': { useShare: () => ({ onShareAppMessage() {} }) }, '@dcloudio/uni-app': Object.fromEntries(['onHide', 'onLoad', 'onPullDownRefresh', 'onReachBottom', 'onShow'].map(name => [name, callback => { lifecycle[name] = callback }])) }, { uni: runtime })
pageHook.useCooperationPage('incoming', true)
check(!lifecycle.onPullDownRefresh && !lifecycle.onReachBottom && !!lifecycle.onShow && !!lifecycle.onHide, 'managed role pages disable native duplicate paging events but retain lifecycle recovery')
const dictionary = fs.readFileSync(path.join(plugin, 'package/uni-app-pages.php'), 'utf8').match(/<<<EOT\s*([\s\S]*?)\s*EOT/)[1], pageDefinitions = JSON.parse('[' + dictionary.replace(/\/\/[^\n]*/g, '').trim().replace(/,$/, '') + ']')[0].pages
for (const name of ['pages/workbench/index', 'pages/stores/index']) check(pageDefinitions.find(page => page.path === name).style.enablePullDownRefresh === false, name + ' disables native page pull-down because z-paging owns refresh')
const visitorEntries=['pages/index','pages/profile/index','pages/stores/index','pages/workbench/index','pages/invite/index']
check(visitorEntries.every(name => pageDefinitions.find(page => page.path === name).needLogin === false) && pageDefinitions.filter(page => !visitorEntries.includes(page.path)).every(page => page.needLogin === true), 'four visitor shells and the promotion login entry are anonymous; all actual tasks, catalog, membership and wallet routes retain login protection')
const protectedEntries=['pages/task/index','pages/catalog/index','pages/entity/index','pages/membership/index','pages/orders/index','pages/wallet/index','pages/notifications/index']
check(pageDefinitions.filter(page=>page.needLogin===true).map(page=>page.path).sort().join(',')===protectedEntries.sort().join(','),'the complete protected task/catalog/entity/membership/orders/wallet and notification-preference route set retains login protection')
console.log(`PASS ${checks} z-paging integration checks; actual SFC/hook/installed paging methods, synthetic asynchronous transports only.`)
