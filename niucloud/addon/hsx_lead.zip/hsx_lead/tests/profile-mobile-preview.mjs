import assert from 'node:assert/strict'
import fs from 'node:fs'
import http from 'node:http'
import path from 'node:path'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'

// Serve the real compiled uni H5 app. All API responses are synthetic and no
// remote request is allowed through; this is layout/interaction, not live data acceptance.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),workspace=path.resolve(plugin,'../../..')
const artifact=process.env.HSX_PROFILE_H5_DIR||'/private/tmp/hsx-lead-profile-draft-h5-final-20261109',output=path.join(workspace,'output/hsx-lead-profile-mobile-20261109')
const {chromium}=createRequire('/tmp/package.json')('playwright')
fs.mkdirSync(output,{recursive:true})
const types={'.html':'text/html;charset=utf-8','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.woff2':'font/woff2','.ttf':'font/ttf'}
const server=http.createServer((req,res)=>{
 const pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname),relative=pathname.replace(/^\/wap\//,'')
 const file=path.resolve(artifact,relative),candidate=file.startsWith(artifact+path.sep)&&fs.existsSync(file)&&fs.statSync(file).isFile()?file:path.join(artifact,'index.html')
 res.setHeader('Content-Type',types[path.extname(candidate)]||'application/octet-stream');res.end(fs.readFileSync(candidate))
})
const profile={id:7,site_id:100006,member_id:101,name:'测试街区手机协作服务门店',contact_name:'测试负责人',mobile:'13900000000',province_id:130000,city_id:130100,district_id:130102,region_text:'河北省 / 石家庄市 / 长安区',address:'测试街道与门牌，实际地址不连接线上 '.repeat(12),provider_requested:'',storefront_image:'',business_license_token:'',permissions:{can_manage_billing:true,can_manage_erp:true},business_capabilities:[{business_type:'purchase',items:Array.from({length:5000},(_,i)=>({id:'model-'+i,title:'合成型号 '+i}))}],membership:{active:false,level_name:'普通会员'}}
const member={member_id:101,member_no:'NIU0000101',nickname:'本地验收负责人',mobile:'13900000000',headimg:'',balance:'0.00',wx_openid:'synthetic-no-authorization'}
const businesses=[['purchase','二手机','model'],['new_phone','新机','brand'],['rental','租机','model'],['replacement','回收置换','model'],['broadband','运营商','operator'],['repair','手机维修','model'],['recycle','上门回收','model']].map(([key,name,dimension])=>({key,name,dimension,enabled:true,selection_mode:'multiple',options:[],fields:[]}))
const rules={version:'local-visual-only',fields:{storefront_image:{visible:true,required:false,sort:10},business_license:{visible:true,required:false,sort:20}},extra_form:{enabled:false,form_id:0}}
const init={tabbar_list:{},map_config:{is_open:0,valid_time:0,map_type:'tencent',key:'',tianditu_map_web_key:''},theme_list:[],site_info:{site_id:100006,site_name:'本地验收',app:['hsx_lead'],site_addons:[{key:'hsx_lead'}],site_logo:''},copyright:{},member_level:[],login_config:{is_username:1,is_mobile:0,is_auth_register:0,is_force_access_user_info:0,is_bind_mobile:0,agreement_show:0,wechat_error:'',bg_url:'',logo:'',desc:''},member_exist:1}
let browser,page,mode='ok';const errors=[],requests=[],blocked=[],offlineAssets=[],checks=[],sizes=[],errorSizes=[]
try{
 await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));const origin='http://127.0.0.1:'+server.address().port
 browser=await chromium.launch({headless:true,executablePath:process.env.HSX_TEST_CHROME||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',args:['--disable-background-networking','--disable-component-update','--no-first-run']})
 const context=await browser.newContext({viewport:{width:390,height:844},deviceScaleFactor:1,reducedMotion:'reduce',isMobile:true,hasTouch:true})
 await context.addInitScript(()=>{
  localStorage.setItem('wapToken','synthetic-profile-visual-only')
  localStorage.setItem('wap_member_id',JSON.stringify({type:'number',data:101}))
  localStorage.setItem('wap_site_id',JSON.stringify({type:'number',data:100006}))
  localStorage.setItem('wap_member_info',JSON.stringify({type:'object',data:{member_id:101,member_no:'NIU0000101',mobile:'13900000000'}}))
 })
 await context.route('**/*',async route=>{
  const request=route.request(),url=new URL(request.url()),p=url.pathname.replace(/^\/api\//,'/');
  if(url.origin===origin)return route.continue()
  if(url.hostname==='at.alicdn.com'&&url.pathname.endsWith('.ttf')||url.hostname==='cdn.dcloud.net.cn'&&url.pathname==='/img/shadow-grey.png'){offlineAssets.push(url.origin+url.pathname);return route.abort('blockedbyclient')}
  if(url.hostname==='sass.hsxbk.top'){
   requests.push({path:p,method:request.method()});let data={},code=1,msg='合成验收响应'
   if(p==='/init')data=init
   else if(p==='/member/member')data=member
   else if(p==='/hsx_lead/cooperation/bootstrap')data={current_member_id:101,profile,config:{enabled:true,erp_visible:true,businesses},providers:[],stats:{},wallet:{}}
   else if(p==='/hsx_lead/cooperation/profile-form'){
    if(mode==='delay')await new Promise(resolve=>setTimeout(resolve,650))
    if(mode==='fail'){code=0;msg='门店资料要求读取失败，请重新读取'}else data=rules
   }else if(p.includes('/share'))data={}
   else if(p.includes('template'))data=[]
   else if(p==='/file/config')data={image:{size:5,ext:['jpg','png']}}
   else if(p==='/site')data=init.site_info
   return route.fulfill({status:200,contentType:'application/json',headers:{'Access-Control-Allow-Origin':origin,'Access-Control-Allow-Headers':'*','Access-Control-Allow-Methods':'*'},body:JSON.stringify({code,msg,data})})
  }
  blocked.push(url.origin+url.pathname);return route.abort('blockedbyclient')
 })
 page=await context.newPage();page.on('pageerror',error=>errors.push(error.message))
 const url=origin+'/wap/addon/hsx_lead/pages/task/index?task=profile-edit'
 await page.goto(url,{waitUntil:'networkidle',timeout:60000})
 const save=page.locator('.coop-sheet__footer').getByText('保存门店资料',{exact:true})
 await save.waitFor({timeout:30000});await page.getByText('已选 5000 项',{exact:true}).waitFor()
 assert.equal(await page.locator('.coop-business-capability').count(),7);checks.push('实际编译H5读取7项业务，5000项能力仅展示数量，不渲染5000个标签')
 for(const width of[320,390,430]){
  await page.setViewportSize({width,height:844});await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))))
  const size=await page.locator('.coop-sheet.is-page').evaluate(node=>{const body=node.querySelector('.coop-sheet__body'),scroll=[...body.querySelectorAll('.uni-scroll-view')].find(el=>getComputedStyle(el).overflowY==='auto')||body,footer=node.querySelector('.coop-sheet__footer'),nav=node.firstElementChild;return{viewport:innerWidth,document:document.documentElement.scrollWidth,bodyWidth:body.clientWidth,bodyScrollWidth:scroll.scrollWidth,bodyHeight:body.clientHeight,contentHeight:scroll.scrollHeight,footerTop:footer.getBoundingClientRect().top,footerBottom:footer.getBoundingClientRect().bottom,navTop:nav.getBoundingClientRect().top,height:innerHeight}})
  sizes.push(size)
  assert.ok(size.document<=width+1&&size.bodyScrollWidth<=size.bodyWidth+1&&size.bodyHeight>100&&size.footerBottom<=size.height+1&&size.contentHeight>size.bodyHeight)
  await page.screenshot({path:path.join(output,'profile-mobile-'+width+'.png'),fullPage:false})
 }
 checks.push('320/390/430长地址及长表单无横向溢出，底部保存始终可见')
 const footerBefore=await page.locator('.coop-sheet__footer').boundingBox()
 await page.locator('.coop-sheet__body').evaluate(node=>{const inner=[...node.querySelectorAll('.uni-scroll-view')].find(el=>getComputedStyle(el).overflowY==='auto')||node;inner.scrollTop=inner.scrollHeight});await page.waitForTimeout(150)
 const footerAfter=await page.locator('.coop-sheet__footer').boundingBox();assert.ok(Math.abs(footerAfter.y-footerBefore.y)<1);checks.push('滚动长表单时底部操作栏位置稳定，不随正文离屏')
 await page.setViewportSize({width:390,height:480});const short=await page.locator('.coop-sheet__footer').boundingBox();assert.ok(short.y+short.height<=481);await page.screenshot({path:path.join(output,'profile-mobile-short-390.png'),fullPage:false});checks.push('短屏480px仍保留保存入口；该模拟不冒称原生键盘验收')
 mode='fail';await page.setViewportSize({width:390,height:844});await page.reload({waitUntil:'networkidle'});await page.locator('.coop-profile-config-error').getByText('门店资料要求读取失败，请重新读取',{exact:true}).waitFor();assert.equal(await page.locator('.uni-simple-toast__text').filter({hasText:'门店资料要求读取失败'}).count(),0)
 const button=page.locator('.coop-sheet__footer .u-button');assert.equal(await button.getAttribute('disabled')==='true'||await button.evaluate(node=>node.classList.contains('u-button--disabled')||node.getAttribute('aria-disabled')==='true'),true)
 for(const width of[320,390]){
  await page.setViewportSize({width,height:844});await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))))
  const errorSize=await page.locator('.coop-profile-config-error').evaluate(node=>{
   const text=node.querySelector('uni-text'),button=node.querySelector('uni-button'),range=document.createRange();range.selectNodeContents(text)
   const b=button.getBoundingClientRect(),box=text.getBoundingClientRect(),outer=node.getBoundingClientRect(),lines=[...range.getClientRects()].map(r=>r.toJSON())
   return{viewport:innerWidth,text:text.textContent,textBox:box.toJSON(),buttonBox:b.toJSON(),outer:outer.toJSON(),lines,scrollWidth:text.scrollWidth,clientWidth:text.clientWidth}
  })
  const overlap=(a,b)=>a.left<b.right-.5&&a.right>b.left+.5&&a.top<b.bottom-.5&&a.bottom>b.top+.5
  assert.equal(errorSize.text,'门店资料要求读取失败，请重新读取');assert.ok(errorSize.scrollWidth<=errorSize.clientWidth+1&&errorSize.lines.length>0&&!overlap(errorSize.textBox,errorSize.buttonBox))
  assert.ok(errorSize.lines.every(line=>line.left>=errorSize.outer.left-1&&line.right<=errorSize.outer.right+1&&line.top>=errorSize.outer.top-1&&line.bottom<=errorSize.outer.bottom+1&&!overlap(line,errorSize.buttonBox)))
  errorSizes.push(errorSize);await page.screenshot({path:path.join(output,'profile-mobile-error-'+width+'.png'),fullPage:false})
 }
 checks.push('配置加载失败显示重试并禁止保存；320/390错误全文换行可见，与固定宽度按钮无重叠')
 mode='ok';await page.getByText('重新读取',{exact:true}).click();await page.getByText('已选 5000 项',{exact:true}).waitFor();await page.waitForFunction(()=>!document.querySelector('.coop-profile-config-error'))
 checks.push('明确重试后恢复当前配置，已填长地址及能力选择保持')
 await page.locator('#coop-profile-name input').fill('');await page.locator('.coop-sheet__footer .u-button').click();await page.locator('#coop-profile-name .coop-profile-field-error').getByText('请填写门店名称与联系人',{exact:true}).waitFor();await page.waitForTimeout(300)
 assert.equal(await page.locator('#coop-profile-address textarea').inputValue(),profile.address);await page.screenshot({path:path.join(output,'profile-mobile-validation-390.png'),fullPage:false});checks.push('本地必填错误定位到字段，其他长地址与能力不丢失，不发无效保存请求')
 assert.deepEqual(errors,[]);assert.deepEqual(blocked,[])
 const businessWrites=requests.filter(row=>row.method!=='GET'&&row.method!=='OPTIONS'&&/hsx_lead|file\/image/.test(row.path));assert.deepEqual(businessWrites,[])
 const report={passed:true,checks,sizes,errorSizes,errors,blocked,offline_assets:offlineAssets,api_requests:requests,scope:'Actual isolated compiled uni-app H5; synthetic browser-routed API only. No backend, production, upload, payment, notification or database writes. Existing third-party icon font is blocked offline, so icon artwork is not accepted by these screenshots. H5 visual test is not WeChat real-device or native-keyboard acceptance.'}
 fs.writeFileSync(path.join(output,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({passed:true,checks:checks.length,output,errors,blocked}))
}catch(error){console.error(JSON.stringify({error:String(error),body:page?await page.locator('body').innerText():'',scroll:page?await page.locator('.coop-sheet__body').evaluateAll(nodes=>nodes.map(n=>({tag:n.tagName,html:n.innerHTML.slice(0,1100),rect:n.getBoundingClientRect().toJSON(),desc:[...n.querySelectorAll('*')].filter(x=>x.className?.includes?.('scroll')).slice(0,10).map(x=>({tag:x.tagName,class:x.className,height:x.clientHeight,scroll:x.scrollHeight,overflow:getComputedStyle(x).overflowY}))}))):[],sizes,errors,blocked,requests}));throw error}finally{await browser?.close();await new Promise(resolve=>server.close(resolve))}
