import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Actual homepage SFC and configured image/style projection. No API or saved DIY.
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
const filename=path.join(plugin,'uni-app/components/diy/lead-cooperation-entry/index.vue')
const source=fs.readFileSync(filename,'utf8'),parsed=compiler.parse(source,{filename})
assert.deepEqual(parsed.errors,[])
const compiled=compiler.compileScript(parsed.descriptor,{id:'homepage-assets'})
assert.deepEqual(compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'homepage-assets',compilerOptions:{bindingMetadata:compiled.bindings,expressionPlugins:['typescript']}}).errors,[])
let checks=2,requests=0
const js=ts.transpileModule(compiled.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
const module={exports:{}},converted=[],store=Vue.reactive({mode:'page',value:[]})
function dependency(key){
    if(key==='vue')return{...Vue,onMounted(){},onBeforeUnmount(){}}
    if(key==='@/app/stores/diy')return{default:()=>store}
    if(key==='@/utils/common')return{getToken:()=>'',img:value=>{converted.push(value);return 'normalized:'+value}}
    if(key==='../../../api/cooperation')return{cooperationBootstrap:()=>{requests++;throw Error('Live API forbidden')},coopError:String}
    if(key.endsWith('/utils/interaction-feedback'))return{interactionFeedback(){throw Error('Navigation forbidden')}}
    if(key.includes('/utils/'))return loadMobileUtility(path.basename(key))
    if(key.endsWith('.png'))return{default:'bundled:'+path.basename(key)}
    if(key.endsWith('.vue'))return{default:{}}
    throw Error('Unexpected dependency '+key)
}
vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,Object,console})(dependency,module,module.exports)
const component=Vue.reactive({titleColor:'#123456',textColor:'#234567',iconColor:'#345678',subtleColor:'#456789',panelColor:'#fefefe',titleSize:20,storeImage:'',customerImage:''})
const state=module.exports.default.setup({component,index:0},{expose(){},emit(){}})
const cardFile=path.join(plugin,'uni-app/components/cooperation/CoopRoleEntryCard.vue'),cardSource=fs.readFileSync(cardFile,'utf8'),cardParsed=compiler.parse(cardSource,{filename:cardFile}),cardModule={exports:{}}
const cardJs=ts.transpileModule(compiler.compileScript(cardParsed.descriptor,{id:'shared-role'}).content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${cardJs}\n})`,{Number,String,Object,console})(dependency,cardModule,cardModule.exports)
const cardProps=Vue.reactive({role:'stores',appearance:component}),card=cardModule.exports.default.setup(cardProps,{expose(){},emit(){}})
function picture(value,name){cardProps.role=name==='delivery-capability'?'customers':'stores';component.image=value;return card.picture.value}
assert.deepEqual(Array.from(module.exports.default.props),['component','index','global']);checks++
for(const value of ['',undefined,null,'   ',0,{}]){assert.equal(picture(value,'store-discovery'),'bundled:store-discovery.png','classic restores the original bundled illustration');checks++}
component.layoutPreset='compact';assert.equal(picture('','store-discovery'),'','compact may use its shared icon rather than forcing the classic artwork');checks++
component.layoutPreset='soft';assert.equal(picture('','store-discovery'),'bundled:store-discovery.png','soft image preset preserves its promised original store artwork');assert.equal(picture('','delivery-capability'),'bundled:delivery-capability.png','soft also restores the customer artwork without a forced background');checks+=2
component.layoutPreset='classic';component.usePresetImages=0;assert.equal(picture('','store-discovery'),'','the user can disable original default imagery');checks++
component.usePresetImages=1
assert.equal(picture(' upload/site/example.png ','store-discovery'),'normalized:upload/site/example.png');checks++
assert.equal(picture('https://cdn.example.invalid/header.png','delivery-capability'),'normalized:https://cdn.example.invalid/header.png');checks++
assert.equal(converted.length,2);checks++
for(const [key,value]of Object.entries({'--lead-diy-title':'#123456','--lead-diy-text':'#234567','--lead-diy-icon':'#345678','--lead-diy-subtle':'#456789','--lead-diy-panel':'#fefefe','--lead-diy-title-size':'20px'})){assert.equal(state.entryStyle.value[key],value,'configured style reaches renderer '+key);checks++}
component.titleColor='#654321';assert.equal(state.entryStyle.value['--lead-diy-title'],'#654321','live DIY changes reach actual render variables');checks++
assert.ok(source.includes('<CoopRoleEntryCard ')&&cardSource.includes('CoopBusinessIcon v-else')&&source.includes('roleEntries')&&state.roleEntries.value.length===2,'combined and independent task entries share one rendering and icon system');checks++
assert.ok(cardSource.includes('store-discovery.png')&&cardSource.includes('delivery-capability.png')&&!source.includes('linear-gradient'),'classic assets are preserved without forcing a background gradient');checks++
assert.ok(source.includes('background:transparent')&&!source.includes('background:#f6f7f8')&&state.entryStyle.value.background===undefined,'without a configured native frame, internal UI does not cover the page background');checks++
assert.equal(state.settings.value.showTools,0);assert.equal(state.settings.value.showBusinesses,0);checks+=2
assert.ok(source.includes('v-if="shown(settings.showTools)"'),'my-store and wallet entries are an explicit opt-in rather than unconditional content');checks++
assert.ok(source.includes('v-if="shown(settings.showTitle)&&settings.title"'),'the configured title switch hides redundant page headings');checks++
assert.equal(requests,0);checks++
assert.ok(source.includes('function refresh()')&&source.includes('defineExpose({refresh})')&&!/defineExpose\(\{\s*refresh\s*:\s*\(\)\s*=>/.test(source),'role renderer exposes a named refresh function that survives the installed uni TypeScript lowering');checks++
const wrapper=fs.readFileSync(path.join(plugin,'uni-app/components/diy/lead-business-navigation/index.vue'),'utf8')
assert.ok(wrapper.includes('function refresh()')&&wrapper.includes('defineExpose({refresh})')&&!/defineExpose\(\{\s*refresh\s*:\s*\(\)\s*=>/.test(wrapper),'standalone business wrapper uses the same safe named-expose contract');checks++
console.log(`PASS ${checks} homepage custom-image, shared-icon and live DIY style checks; actual SFC setup, no browser/API/database or deployment writes.`)
