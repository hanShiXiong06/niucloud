<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';
use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ConfigService,EntityMembershipService,MembershipDepositService,PartnerService,Store};
use addon\hsx_lead\app\support\Data;
use app\dict\pay\RefundDict;
use think\facade\Db;
$pdo=null;$schema='';$failed=false;$checks=0;
function batchCheck(bool $condition,string $label):void{if(!$condition)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site,[2]);
    $settings=ConfigService::defaults();$settings['enabled']=true;(new ConfigService(new Context($site,1)))->save($settings);
    $config=(new ConfigService(new Context($site,1)))->get();$ids=[];$orders=[];
    foreach([101,102]as$owner){
        $row=(new PartnerService(new Context($site,0,$owner)))->saveProfile(['name'=>'Synthetic '.$owner,'contact_name'=>'Fixture','mobile'=>'19900000'.$owner,'province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Synthetic road']);
        $ids[]=(int)$row['id'];$paid=leadMembershipGrant($site,$owner,'ML701');$orders[$owner]=Store::row('coop_order',$site,(int)$paid['id']);
    }
    $now=time();$assertSame=static function(string $label)use($site,$ids,$config,$now):array{
        $states=EntityMembershipService::states($site,$ids,$config,$now);
        foreach($ids as$id)batchCheck($states[$id]===EntityMembershipService::state($site,$id,$config,$now),$label.' merchant '.$id);
        return$states;
    };
    batchCheck(EntityMembershipService::states($site,[])===[],'empty page needs no fake membership');
    $active=$assertSame('active paid state matches single financial ledger');batchCheck($active[$ids[0]]['active']&&$active[$ids[1]]['active'],'both matching receipts activate actual rights');
    $before=Store::query('partner',$site)->count();$missing=EntityMembershipService::states($site,[999999],$config,$now);
    batchCheck(!$missing[999999]['active']&&Store::query('partner',$site)->count()===$before,'read-only batch never inserts a missing partner');
    Db::name('pay')->where('site_id',$site)->where('out_trade_no',$orders[101]['out_trade_no'])->update(['main_id'=>999]);
    $bad=$assertSame('wrong payer remains invalid');batchCheck(!$bad[$ids[0]]['active'],'batch cannot grant from another payer receipt');
    Db::name('pay')->where('site_id',$site)->where('out_trade_no',$orders[101]['out_trade_no'])->update(['main_id'=>101]);
    Db::name('pay_refund')->insert(['site_id'=>$site,'out_trade_no'=>$orders[101]['out_trade_no'],'refund_no'=>'BATCH_SUCCESS','money'=>$orders[101]['amount'],'status'=>RefundDict::SUCCESS]);
    $refunded=$assertSame('successful full refund matches single');batchCheck(!$refunded[$ids[0]]['active'],'successfully refunded service never grants rights');
    Db::name('pay_refund')->insert(['site_id'=>$site,'out_trade_no'=>$orders[102]['out_trade_no'],'refund_no'=>'BATCH_PENDING','money'=>$orders[102]['amount'],'status'=>RefundDict::WAIT]);
    $assertSame('pending refund preserves existing single-read semantics');
    Db::name('pay_refund')->where('site_id',$site)->where('refund_no','BATCH_PENDING')->delete();
    $rule=Data::decode($orders[102]['rule_json']);$rule['membership_deposit_return']=['status'=>'approved'];
    Store::query('coop_order',$site)->where('id',$orders[102]['id'])->update(['rule_json'=>Data::json($rule)]);
    $exited=$assertSame('approved deposit exit matches single');batchCheck(!$exited[$ids[1]]['active']&&$exited[$ids[1]]['cooperation_exited'],'deposit exit revokes new collaboration rights in batch');
    $copy=$orders[102];unset($copy['id']);$copy['order_no']='BATCH_EXIT_NEW';$copy['business_key']='BATCH_EXIT_NEW';$copy['request_id']='BATCH_EXIT_NEW';$copy['status']='closed';$copy['out_trade_no']='';$copy['rule_json']=Data::json(['membership_deposit_return'=>['status'=>'rejected']]);
    Store::query('coop_order',$site)->insert($copy);
    batchCheck(!MembershipDepositService::exited($site,$ids[1])&&!MembershipDepositService::exitedMany($site,$ids)[$ids[1]],'latest rejected exit supersedes the older approved embedded request');
    $assertSame('latest request selection parity');
    Store::query('coop_order',$site)->where('id',$orders[102]['id'])->update(['out_trade_no'=>'']);
    Db::name('pay')->where('site_id',$site)->where('out_trade_no',$orders[102]['out_trade_no'])->update(['out_trade_no'=>'']);
    Db::name('pay_refund')->insert(['site_id'=>$site,'out_trade_no'=>'','refund_no'=>'BATCH_EMPTY_REFERENCE','money'=>$orders[102]['amount'],'status'=>RefundDict::SUCCESS]);
    $blank=$assertSame('empty receipt reference cannot hide a matching refund');batchCheck(!$blank[$ids[1]]['active'],'malformed empty reference remains subject to original refund checks');
    $other=EntityMembershipService::states($site+1,$ids,$config,$now);
    batchCheck(!$other[$ids[0]]['active']&&!$other[$ids[1]]['active'],'same merchant IDs cannot expose another tenant receipts');
    $future=EntityMembershipService::states($site,$ids,$config,$now+400*86400);
    batchCheck(!$future[$ids[0]]['active']&&!$future[$ids[1]]['active'],'expiry cannot be bypassed by the list read model');
    echo 'PASS '.$checks." batch membership checks; same authoritative financial rules, random isolated schema only.\n";
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL '.$error->getMessage()."\n");}
finally{if($pdo instanceof PDO&&$schema!==''){leadCleanup($pdo,$schema);echo "CLEANUP_CONFIRMED owned schema dropped\n";}}
if($failed)exit(1);
