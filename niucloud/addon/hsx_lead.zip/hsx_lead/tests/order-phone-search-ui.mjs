import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),sfc=require('@vue/compiler-sfc'),ts=require('typescript'),{renderToString}=require('@vue/server-renderer')
let checks=0;const check=(ok,label)=>{assert.ok(ok,label);checks++},read=name=>fs.readFileSync(path.join(plugin,name),'utf8')
function run(source,deps={}){const module={exports:{}},code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext('(function(require,module,exports){'+code+'})',{console,Date,Number,String,Object,Array,Math,Promise,Error,Set,Map,JSON})(key=>{if(key in deps)return deps[key];if(key.endsWith('.vue'))return{default:{}};throw Error('Unexpected dependency '+key)},module,module.exports);return module.exports}
const hooks={...Vue,onBeforeUnmount(){},onMounted(){}}
const coop=run(read('admin/composables/cooperation.ts'),{vue:hooks,'@/stores/modules/user':{default:()=>({})},'./useLeadUi':{errorText:(e,f)=>e?.message||f,timestampParts:value=>({full:String(value)})},'./navigation':{hasLeadPagePermission:()=>false},'./business':{demandNames:()=>[]}})
const calls=[];let work=async()=>({data:{data:[],total:0}})
const list=coop.useCooperationList(async params=>{calls.push({...params});return work(params)})
const filename='admin/views/cooperation/Orders.vue',source=read(filename),parsed=sfc.parse(source,{filename})
check(!parsed.errors.length,'actual Orders SFC parses')
const built=sfc.compileScript(parsed.descriptor,{id:'order-phone',inlineTemplate:true})
check(!sfc.compileTemplate({source:parsed.descriptor.template.content,filename,id:'order-phone',compilerOptions:{bindingMetadata:built.bindings}}).errors.length,'actual template compiles')
for(const style of parsed.descriptor.styles)check(!sfc.compileStyle({source:style.content,filename,id:'order-phone',scoped:style.scoped}).errors.length,'actual phone search styles compile')
const deps={vue:hooks,'element-plus':{ElMessage:{},ElMessageBox:{}},'../../api/cooperation':{},'../../composables/business':{},'../../composables/cooperation':{...coop,useCooperationAccess:()=>({allows:()=>false}),useCooperationList:()=>list}}
const state=run(parsed.descriptor.scriptSetup.content+'\nexport {mobile,mobileScope,mobileError,search,resetExtraFilters,query,load,changePage,rows,total,loading,error,purpose,paymentType,paymentChannel,refundStatus,reviewOnly,showDetail,selected}',deps)
check(state.mobileScope.value==='payer'&&!state.mobile.value,'caller lookup defaults to original payment member')
state.query.page=4;state.mobile.value='+86 188-1111-0002';state.purpose.value='membership';state.paymentType.value='wechatpay';state.paymentChannel.value='weapp';state.refundStatus.value='none';state.reviewOnly.value=true
await state.search({keyword:'PAYER-102',status:'unpaid',start_time:10,end_time:20})
check(calls.length===1&&calls[0].page===1&&calls[0].mobile==='+86 188-1111-0002'&&calls[0].mobile_scope==='payer','query button submits phone immediately once and resets page')
check(calls[0].keyword==='PAYER-102'&&calls[0].purpose==='membership'&&calls[0].status==='unpaid'&&calls[0].payment_type==='wechatpay'&&calls[0].payment_channel==='weapp'&&calls[0].refund_status==='none'&&calls[0].start_time===10&&calls[0].end_time===20&&calls[0].requires_manual_review==='1','phone composes with all existing finance filters')
await state.changePage({page:2,limit:20});check(calls.at(-1).page===2&&calls.at(-1).mobile_scope==='payer'&&calls.at(-1).mobile==='+86 188-1111-0002','pagination retains exact caller scope')
for(const bad of ['0002','123456','18811110002%','18811110002/','18811110002 OR 1=1','18811110002\n7','1'.repeat(21)]){const before=calls.length;state.mobile.value=bad;await state.search();check(calls.length===before&&state.mobileError.value.includes('完整手机号'),'invalid or tail-only input never requests every order')}
state.mobile.value='18811110005';state.mobileScope.value='customer';await state.search();check(calls.at(-1).mobile_scope==='customer'&&!state.mobileError.value,'alternate customer scope is explicit, not silently treated as payer')
state.resetExtraFilters();await state.search();check(calls.at(-1).mobile===''&&calls.at(-1).mobile_scope==='payer'&&!calls.at(-1).purpose&&!calls.at(-1).payment_type&&!calls.at(-1).refund_status&&!state.mobileError.value,'clear removes phone, scope and all extra dimensions')
let resolve;work=()=>new Promise(done=>{resolve=done});state.mobile.value='18811110002';const pending=state.search();check(state.loading.value,'exact lookup has real list loading state');resolve({data:{data:[{id:1}],total:1}});await pending;check(!state.loading.value&&state.rows.value[0].id===1,'response updates rows without pull-to-refresh')
work=async()=>{throw Error('合成的手机号查询失败')};await state.search();check(state.error.value==='合成的手机号查询失败'&&!state.rows.value.length&&!state.loading.value,'failed lookup is explicit, not a misleading successful empty state')
const pass={setup:(_,{slots,attrs})=>()=>Vue.h('div',attrs,[slots.prepend?.(),slots.default?.()])},dialog={props:['modelValue'],setup:(p,{slots})=>()=>p.modelValue?Vue.h('aside',slots.default?.()):null}
const table={props:['columns','data'],setup:(p,{slots})=>()=>Vue.h('table',p.data.map(row=>Vue.h('tr',p.columns.map(col=>Vue.h('td',slots[col.slot]?.({row}))))))}
const component=run(built.content,{...deps,'@/addon/hsx_components/components/HsxTable/index.vue':{default:table},'@/addon/hsx_components/components/HsxPagination/index.vue':{default:pass},'./CooperationFilter.vue':{default:pass},'./OrderRefundDialog.vue':{default:pass},'./ManualReceiptDialog.vue':{default:pass}}).default
async function html(row){state.rows.value=[row];const app=Vue.createSSRApp({render:()=>Vue.h(component)});app.config.warnHandler=()=>{};for(const name of ['el-input','el-select','el-option','el-checkbox','el-alert','el-tag','el-button','el-collapse','el-collapse-item','el-descriptions','el-descriptions-item','el-input-number','el-form','el-form-item'])app.component(name,pass);app.component('el-dialog',dialog);return renderToString(app)}
const row={id:1,order_no:'SYNTHETIC-ORDER',purpose:'membership',status:'unpaid',amount:'99.00',merchant_name:'现在的门店',payer_name:'原付款人',payer_member_no:'PAY-102',payer_mobile:'18811110002',mobile_match_sources:['customer'],customer_name:'线索客户甲',customer_mobile:'18811110005'}
let markup=await html(row);check(markup.includes('原付款人')&&markup.includes('UID：PAY-102')&&markup.includes('18811110002'),'real table slot renders original payer name, member number and phone')
check(markup.includes('线索客户：线索客户甲 · 18811110005'),'customer phone match renders explicit provenance separately from payer')
markup=await html({...row,payer_name:'',payer_member_no:'',payer_mobile:'',mobile_match_sources:[]});check(markup.includes('原付款会员资料未返回')&&markup.includes('未登记付款手机号')&&!markup.includes('UID：PAY-102')&&!markup.includes('线索客户甲'),'missing payer cannot be replaced with a current store owner or stale match')
markup=await html({...row,mobile_match_sources:['store'],merchant_contact_name:'联系人乙',merchant_mobile:'18811110004'});check(markup.includes('门店联系人：联系人乙 · 18811110004'),'store phone match states its source')
check(source===fs.readFileSync(path.resolve(plugin,'../../../admin/src/addon/hsx_lead/views/cooperation/Orders.vue'),'utf8'),'canonical and mounted order component match')
console.log(`PASS ${checks} phone-order admin UI checks; real Vue list state, SFC compiler and SSR table slots; synthetic reads only, no live API/payment/database.`)
