import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..')
const require=createRequire(path.resolve(plugin,'../../../uni-app/package.json'))
const Vue=require('vue'), compiler=require('@vue/compiler-sfc'), ts=require('typescript'), dom=require('@vue/compiler-dom')
let checks=0
const check=(ok,label)=>{assert.ok(ok,label);checks++}
let pending, rejectUpload, resolveUpload, modal, previewed
const cleanups=[], emitted=[]
const filename=path.join(plugin,'uni-app/components/cooperation/CoopStorefrontUpload.vue')
const parsed=compiler.parse(fs.readFileSync(filename,'utf8'),{filename});check(!parsed.errors.length,'storefront parses')
const compiled=compiler.compileScript(parsed.descriptor,{id:'onboarding-experience'})
check(!compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'onboarding-experience',compilerOptions:{bindingMetadata:compiled.bindings}}).errors.length,'storefront template compiles')
const module={exports:{}}
const js=ts.transpileModule(compiled.content,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText
vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{Number,String,Promise,console,uni:{showModal:options=>{modal=options},previewImage:options=>{previewed=options}}})(key=>{
  if(key==='vue')return{...Vue,onBeforeUnmount:callback=>cleanups.push(callback)}
  if(key==='@/utils/common')return{img:value=>'/synthetic-owned/'+value}
  if(key==='../../api/cooperation')return{coopError:error=>error.message||error.msg||'failed',uploadCooperationStorefront:()=>new Promise((resolve,reject)=>{pending=true;resolveUpload=resolve;rejectUpload=reject})}
  throw Error('Unexpected dependency '+key)
},module,module.exports)
const props=Vue.reactive({modelValue:'upload/test/previous.png',disabled:false})
const state=module.exports.default.setup(props,{emit:(...args)=>emitted.push(args),expose(){}})
state.preview();check(previewed.urls[0]==='/synthetic-owned/upload/test/previous.png','thumbnail previews the existing owned photo')
state.remove();check(modal?.title==='移除门头照片？'&&!emitted.length,'remove is explicit and does not clear until confirmed')
modal.success({confirm:false});check(!emitted.length,'cancel preserves photo')
modal.success({confirm:true});check(emitted.at(-1)[0]==='update:modelValue'&&emitted.at(-1)[1]==='','confirm clears display reference, not stored attachment')
emitted.length=0;props.disabled=true;modal=null;state.remove();check(modal===null,'disabled photo cannot be removed');props.disabled=false
await state.afterRead({file:{url:'synthetic',type:'image/gif',size:100}});check(state.error.value.includes('JPG')&&!pending,'unsupported images do not begin upload')
const first=state.afterRead({file:{url:'synthetic',type:'image/png',size:100}})
check(state.uploading.value&&emitted.at(-1)[0]==='pending'&&emitted.at(-1)[1]===true,'upload has a visible busy state and locks parent save')
rejectUpload(new Error('本地上传失败'));await first
check(!state.uploading.value&&state.error.value==='本地上传失败'&&!emitted.some(row=>row[0]==='update:modelValue'),'failed upload preserves previous image')
const second=state.afterRead({file:{url:'synthetic-2',type:'image/png',size:100}})
resolveUpload({data:{path:'upload/test/new.png'}});await second
check(emitted.at(-2)[0]==='update:modelValue'&&emitted.at(-2)[1]==='upload/test/new.png'&&emitted.at(-1)[1]===false,'successful upload returns server-owned path before unlocking')
state.imageFailed.value=true;props.modelValue='upload/test/another.png';await Vue.nextTick();check(!state.imageFailed.value,'replacing a failed thumbnail resets its image fallback')
const third=state.afterRead({file:{url:'synthetic-3',type:'image/png',size:100}});cleanups.forEach(callback=>callback());const before=emitted.length;resolveUpload({data:{path:'upload/test/disposed.png'}});await third;check(emitted.length===before,'unmounted upload cannot mutate a replacement page')
function find(node,predicate){if(predicate(node))return node;for(const child of node.children||[]){const match=find(child,predicate);if(match)return match}}
for(const name of ['CoopProfilePanel','CoopPublishForm']){
  const source=fs.readFileSync(path.join(plugin,'uni-app/components/cooperation',name+'.vue'),'utf8'),descriptor=compiler.parse(source).descriptor
  const tree=dom.baseParse(descriptor.template.content),footer=find(tree,node=>node.type===1&&node.tag==='template'&&node.props.some(prop=>prop.type===7&&prop.name==='slot'&&prop.arg?.content==='footer'))
  check(!!find(footer,node=>node.type===1&&node.props.some(prop=>prop.type===6&&prop.name==='role'&&prop.value?.content==='alert')),name+' submission errors remain visible next to the fixed main action, not hidden below the scroll')
}
console.log(`PASS ${checks} onboarding/photo interaction checks; actual SFC setup and template AST, synthetic uploads/modal responses only, no network, database or file upload.`)
