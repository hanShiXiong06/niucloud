<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions before isolated testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';

use addon\hsx_lead\app\service\{CatalogConfigStorage as Storage, CatalogService, Context};
use addon\hsx_lead\app\service\cooperation\ConfigService;
use core\exception\CommonException;
use think\facade\Db;

$checks = 0; $failed = false; $pdo = null; $schema = ''; $trigger = false;
function largeCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function largeReject(callable $operation, string $label): void
{
    try { $operation(); }
    catch (Throwable $error) {
        if (!$error instanceof CommonException && !$error instanceof PDOException && !$error instanceof \think\db\exception\PDOException && !$error instanceof RuntimeException) throw $error;
        largeCheck(true, $label); return;
    }
    throw new RuntimeException('Expected refusal: ' . $label);
}

try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    $ormPdo = Db::connect()->getPdo();
    if (!$ormPdo instanceof PDO) throw new RuntimeException('Cannot inspect owned ORM connection');
    $columnsBefore = Db::query('SHOW COLUMNS FROM `lt_sys_config`');
    $column = array_values(array_filter($columnsBefore, static fn(array $row): bool => $row['Field'] === 'value'))[0];
    largeCheck(strtolower($column['Type']) === 'text', 'fixture uses the actual official TEXT column, not an enlarged schema');
    $settings = new ConfigService(new Context($site, 1)); $catalog = new CatalogService(new Context($site, 1));
    $config = $settings->get(); $config['enabled'] = true; $config['publishing_required'] = false; $config['fee_confirmed'] = true;
    $settings->save($config);
    foreach ($config['businesses'] as $business) $catalog->save(['business_type' => $business['key'], 'format' => 'json', 'content' => json_encode([[
        'id' => 'original_' . $business['key'], 'title' => 'Original ' . $business['key'], 'brand' => 'Fixture',
        'category_name' => 'Original', 'path' => ['Original', $business['key']], 'aliases' => [],
    ]], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
    $encode = static fn($value): string => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);
    $rawRows = static function (int $count, string $label = '目录'): array {
        $rows = [];
        for ($index = 1; $index <= $count; $index++) $rows[] = [
            'id' => (string) $index, 'title' => $label . ' iPhone ' . $index, 'brand' => '苹果',
            'category_name' => '手机', 'path' => ['手机', '苹果系列', $label . ' iPhone ' . $index], 'aliases' => ['型号' . $index],
        ];
        return $rows;
    };
    $payload = static fn(array $rows, bool $preview = false): array => ['business_type' => 'purchase', 'format' => 'json', 'content' => $encode($rows), 'preview' => $preview];
    $storedProjection = static fn(array $rows): array => array_map(static function (array $row): array { unset($row['dimension']); return $row; }, $rows);
    $rawConfigs = static function (?int $tenant = null) use ($pdo): array {
        $statement = $pdo->prepare('SELECT * FROM `lt_sys_config`' . ($tenant === null ? '' : ' WHERE site_id=?') . ' ORDER BY site_id,config_key,id');
        $statement->execute($tenant === null ? [] : [$tenant]); return $statement->fetchAll(PDO::FETCH_ASSOC);
    };
    $rawBase = static function (int $tenant, string $key) use ($rawConfigs): array {
        $rows = array_values(array_filter($rawConfigs($tenant), static fn(array $row): bool => $row['config_key'] === $key));
        largeCheck(count($rows) === 1, $key . ' has exactly one base configuration row');
        return $rows[0];
    };
    $prefix = static fn(string $key): string => 'HSX_LEAD_CFG_' . substr(hash('sha256', $key), 0, 32) . '_';
    $chunkRows = static function (int $tenant, string $key) use ($rawConfigs, $prefix): array {
        return array_values(array_filter($rawConfigs($tenant), static fn(array $row): bool => str_starts_with($row['config_key'], $prefix($key))));
    };
    $writeStorage = static function (int $tenant, string $key, array $value): void {
        Db::transaction(static function () use ($tenant, $key, $value): void {
            Db::name('site')->where('site_id', $tenant)->lock(true)->find(); Storage::write($tenant, $key, $value);
        });
    };
    $snapshot = static function () use ($rawConfigs, $site): array {
        return ['config' => $rawConfigs(), 'audit' => Db::name('hsx_lead_audit')->where('site_id', $site)->order('id')->select()->toArray()];
    };
    $assertLiveChunks = static function (int $tenant, string $key) use ($rawBase, $chunkRows, $prefix): void {
        $base = json_decode($rawBase($tenant, $key)['value'], true, 512, JSON_THROW_ON_ERROR);
        $parts = $chunkRows($tenant, $key);
        if (($base['_hsx_lead_catalog_storage'] ?? '') !== 'chunks.v1') {
            largeCheck($parts === [], $key . ' has no leftover parts when stored inline'); return;
        }
        $expected = [];
        for ($i = 0; $i < $base['parts']; $i++) $expected[] = $prefix($key) . $base['generation'] . '_' . str_pad((string) $i, 4, '0', STR_PAD_LEFT);
        $actual = array_column($parts, 'config_key'); sort($actual); sort($expected);
        largeCheck($actual === $expected, $key . ' contains exactly its current manifest generation and no orphan prior parts');
        foreach ($parts as $part) largeCheck(strlen($part['value']) <= 65535, $key . ' part fits the official TEXT byte limit');
    };

    $foreign = $site + 1;
    $writeStorage($foreign, CatalogService::KEY, ['items' => $rawRows(600, '另一站点'), 'updated_at' => 123]);
    $foreignBefore = $rawConfigs($foreign);
    $merchant = (int) Db::name('hsx_lead_merchant')->insertGetId(['site_id' => $site, 'member_id' => 101, 'name' => 'Large catalog fixture']);
    $lead = (int) Db::name('hsx_lead_collaboration')->insertGetId([
        'site_id' => $site, 'lead_no' => 'LC-LARGE-STORAGE-FIXTURE', 'publisher_id' => $merchant,
        'request_id' => 'large-storage-historic', 'models_json' => '[{"id":"old","title":"Old model"}]', 'rule_json' => '{"fee_percent":"10.00"}',
    ]);
    $historyBefore = Db::name('hsx_lead_collaboration')->where('id', $lead)->find();
    $db = Db::getConfig(); $db['connections'][$db['default']]['trigger_sql'] = true; Db::setConfig($db); Db::connect($db['default'], true); Db::query('SELECT 1'); $ormPdo = Db::connect()->getPdo();
    $sql = []; Db::listen(static function (string $statement) use (&$sql): void { $sql[] = $statement; });
    $rows845 = $rawRows(845);
    largeCheck(strlen($encode(['items' => $rows845])) > 65535, '845-row fixture genuinely exceeds TEXT bytes before compression or chunking');
    foreach (['STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION', 'NO_ENGINE_SUBSTITUTION'] as $mode) {
        $ormPdo->exec('SET SESSION sql_mode=' . $ormPdo->quote($mode)); $pdo->exec('SET SESSION sql_mode=' . $pdo->quote($mode));
        $beforePreview = $snapshot(); $preview = $catalog->save($payload($rows845, true));
        largeCheck($preview['count'] === 845 && $preview['items'] === $rows845, $mode . ' 845 preview returns the complete original directory');
        largeCheck($snapshot() === $beforePreview, $mode . ' 845 preview writes no base, fragment or audit rows');
        $saved = $catalog->save($payload($rows845));
        largeCheck($saved['count'] === 845 && $storedProjection($saved['items']) === $rows845, $mode . ' 845 save performs complete readback rather than echoing truncated input');
        largeCheck($catalog->directory()['items'] === $rows845, $mode . ' persisted directory contains every item and path');
        largeCheck(Storage::read($site, CatalogService::KEY)['items'] === $rows845, $mode . ' storage reconstructs all fragments');
        $assertLiveChunks($site, CatalogService::KEY);
    }

    $catalog->save(['business_type' => 'rent', 'format' => 'json', 'content' => $encode($rows845)]);
    $config = $settings->get(); $config['listing_login_required'] = true;
    largeCheck(strlen($encode($config)) > 65535, 'sibling business options also force the cooperation config above TEXT size');
    $settings->save($config);
    $savedConfig = $settings->get(); $rent = array_values(array_filter($savedConfig['businesses'], static fn(array $row): bool => $row['key'] === 'rent'))[0];
    largeCheck($rent['options'] === $rows845 && $savedConfig['fee_confirmed'] === true, 'large sibling business config preserves its complete options and fee confirmation');
    $visitorBusinesses=array_map(static fn(array $row):array=>['key'=>$row['key'],'name'=>$row['name'],'dimension'=>$row['dimension']],array_values(array_filter($savedConfig['businesses'],static fn(array $row):bool=>$row['enabled'])));
    largeCheck(ConfigService::publicAccess($site) === ['login_required' => true,'erp_visible'=>true,'visitor'=>['enabled'=>true,'businesses'=>$visitorBusinesses]], 'chunked public configuration exposes flags and enabled business names, never large directory options');
    $assertLiveChunks($site, ConfigService::KEY);

    $rows5000 = $rawRows(5000, '完整五千项');
    $before5000 = $snapshot(); $preview5000 = $catalog->save($payload($rows5000, true));
    largeCheck($preview5000['count'] === 5000 && $preview5000['items'] === $rows5000 && $snapshot() === $before5000, '5000-row preview remains complete and read-only');
    $saved5000 = $catalog->save($payload($rows5000));
    largeCheck($saved5000['count'] === 5000 && $storedProjection($saved5000['items']) === $rows5000 && $catalog->directory()['items'] === $rows5000, '5000-row upper boundary saves and reconstructs completely');
    $assertLiveChunks($site, CatalogService::KEY); $assertLiveChunks($site, ConfigService::KEY);
    $partsBeforeRepeat = count($chunkRows($site, CatalogService::KEY));
    $catalog->save($payload($rows5000));
    largeCheck(count($chunkRows($site, CatalogService::KEY)) === $partsBeforeRepeat, 'reimport does not accumulate stale chunks');
    $assertLiveChunks($site, CatalogService::KEY);
    $catalog->save($payload(array_slice($rows845, 0, 4)));
    largeCheck($catalog->directory()['items'] === array_slice($rows845, 0, 4), 'switching back to four items retains accurate content');
    $assertLiveChunks($site, CatalogService::KEY); $assertLiveChunks($site, ConfigService::KEY);
    $catalog->save(['business_type' => 'rent', 'format' => 'json', 'content' => $encode(array_slice($rows845, 0, 1))]);
    $settings->save($settings->get()); $assertLiveChunks($site, ConfigService::KEY);

    $catalog->save($payload($rows845));
    $beforeFailure = $snapshot();
    $pattern = '^' . $prefix(CatalogService::KEY) . '[a-f0-9]{16}_0001$';
    $pdo->exec('CREATE TRIGGER `lt_large_storage_fail_fixture` BEFORE INSERT ON `lt_sys_config` FOR EACH ROW BEGIN IF NEW.site_id=' . $site . ' AND NEW.config_key REGEXP ' . $pdo->quote($pattern) . " THEN SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='Synthetic second chunk insert failure'; END IF; END"); $trigger = true;
    largeReject(fn() => $catalog->save($payload($rawRows(845, '应当失败的新目录'))), 'real part-write failure propagates safely');
    largeCheck($snapshot() === $beforeFailure && $catalog->directory()['items'] === $rows845, 'failed multipart save rolls back base, fragments, sibling config and audit; old directory stays intact');
    $pdo->exec('DROP TRIGGER `lt_large_storage_fail_fixture`'); $trigger = false;

    $manifest = json_decode($rawBase($site, CatalogService::KEY)['value'], true, 512, JSON_THROW_ON_ERROR);
    $parts = $chunkRows($site, CatalogService::KEY); $firstPart = $parts[0];
    $corruption = static function (callable $mutate, string $label) use ($site): void {
        Db::startTrans();
        try { $mutate(); largeReject(fn() => Storage::read($site, CatalogService::KEY), $label); }
        finally { Db::rollback(); }
    };
    $corruption(static fn() => Db::name('sys_config')->where('id', $firstPart['id'])->delete(), 'missing fragment never degrades to a shorter or default catalog');
    $badPart = json_decode($firstPart['value'], true, 512, JSON_THROW_ON_ERROR); $badPart['data'] = 'not-valid-base64%%';
    $corruption(static fn() => Db::name('sys_config')->where('id', $firstPart['id'])->update(['value' => $encode($badPart)]), 'invalid base64 fragment is rejected');
    $badHash = $manifest; $badHash['sha256'] = str_repeat('0', 64);
    $corruption(static fn() => Db::name('sys_config')->where('site_id', $site)->where('config_key', CatalogService::KEY)->update(['value' => $encode($badHash)]), 'overall checksum mismatch is rejected');
    $missingHash = $manifest; unset($missingHash['sha256']);
    $corruption(static fn() => Db::name('sys_config')->where('site_id', $site)->where('config_key', CatalogService::KEY)->update(['value' => $encode($missingHash)]), 'manifest without its checksum is rejected');
    $wrongIndex = json_decode($firstPart['value'], true, 512, JSON_THROW_ON_ERROR); $wrongIndex['index']++;
    $corruption(static fn() => Db::name('sys_config')->where('id', $firstPart['id'])->update(['value' => $encode($wrongIndex)]), 'fragment metadata cannot claim a different position');
    $changedData = json_decode($firstPart['value'], true, 512, JSON_THROW_ON_ERROR);
    $decodedPart = base64_decode($changedData['data'], true); $decodedPart[0] = $decodedPart[0] === 'A' ? 'B' : 'A'; $changedData['data'] = base64_encode($decodedPart);
    $corruption(static fn() => Db::name('sys_config')->where('id', $firstPart['id'])->update(['value' => $encode($changedData)]), 'valid-base64 fragment corruption still fails the full payload checksum');
    $badCount = $manifest; $badCount['parts']++;
    $corruption(static fn() => Db::name('sys_config')->where('site_id', $site)->where('config_key', CatalogService::KEY)->update(['value' => $encode($badCount)]), 'forged fragment count is rejected');
    $corruption(static fn() => Db::name('sys_config')->insert(['site_id' => $site, 'config_key' => CatalogService::KEY, 'value' => $encode($manifest)]), 'duplicate base rows are refused rather than chosen arbitrarily');
    largeCheck($catalog->directory()['items'] === $rows845, 'rollback of corruption fixtures restores the valid original directory');

    // Exercise both supported storage keys exactly at the byte boundary. This
    // uses another owned fixture site, not a real tenant or the integration site.
    $boundarySite = $site + 2;
    Db::name('site')->insert(['site_id' => $boundarySite, 'site_name' => 'Storage boundary fixture', 'app_type' => 'site', 'app' => '["hsx_lead"]', 'addons' => '[]', 'group_id' => 0]);
    $inlineBytes = 48 * 1024; $overhead = strlen($encode(['payload' => '']));
    foreach ([CatalogService::KEY, ConfigService::KEY] as $key) {
        $exact = ['payload' => str_repeat('a', $inlineBytes - $overhead)];
        largeCheck(strlen($encode($exact)) === $inlineBytes, $key . ' boundary fixture uses exact encoded bytes');
        $writeStorage($boundarySite, $key, $exact);
        largeCheck(Storage::read($boundarySite, $key) === $exact && !str_contains($rawBase($boundarySite, $key)['value'], 'chunks.v1'), $key . ' exact 48KiB value remains inline');
        $above = ['payload' => $exact['payload'] . 'b']; $writeStorage($boundarySite, $key, $above);
        largeCheck(Storage::read($boundarySite, $key) === $above && str_contains($rawBase($boundarySite, $key)['value'], 'chunks.v1'), $key . ' one byte above boundary is chunked losslessly');
        $assertLiveChunks($boundarySite, $key);
        $unicode = ['payload' => str_repeat('苹果🍎', 6000)]; $writeStorage($boundarySite, $key, $unicode);
        largeCheck(Storage::read($boundarySite, $key) === $unicode, $key . ' reconstructs UTF-8 even when a raw chunk cuts a multibyte character');
        $writeStorage($boundarySite, $key, ['items' => []]); $assertLiveChunks($boundarySite, $key);
    }
    largeReject(fn() => Storage::write($site, CatalogService::KEY, ['items' => []]), 'storage writes require an existing caller-owned transaction');
    largeReject(fn() => Storage::read($site, 'HSX_LEAD_PROMOTION'), 'storage cannot read or rewrite unrelated framework settings');
    largeReject(fn() => Storage::read(0, CatalogService::KEY), 'storage requires an explicit positive tenant');
    largeCheck($rawConfigs($foreign) === $foreignBefore, 'all large saves and corruptions leave another tenant byte-for-byte unchanged');
    largeCheck(Db::name('hsx_lead_collaboration')->where('id', $lead)->find() === $historyBefore, 'large imports leave historic model and fee snapshots untouched');
    largeCheck(!preg_match('/\bALTER\s+TABLE\b|\b(?:FROM|JOIN)\s+`?lt_hsx_lead_inventory\b/i', implode("\n", $sql)), 'large storage uses neither schema ALTER nor inventory classification scans');
    largeCheck(Db::query('SHOW COLUMNS FROM `lt_sys_config`') === $columnsBefore, 'official configuration schema remains identical after all operations');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => '845/5000 row catalogs, official TEXT column, owned random localhost schema, no external requests', 'remote_calls' => 0], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true; fwrite(STDERR, 'FAIL large catalog storage: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    if ($pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    if ($pdo instanceof PDO && $trigger) $pdo->exec('DROP TRIGGER IF EXISTS `lt_large_storage_fail_fixture`');
    if ($pdo instanceof PDO && $schema !== '') {
        try { leadCleanup($pdo, $schema); }
        catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL owned schema cleanup\n"); }
    }
}
exit($failed ? 1 : 0);
