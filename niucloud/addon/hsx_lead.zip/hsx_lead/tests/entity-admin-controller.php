<?php
declare(strict_types=1);
namespace core\base { class BaseAdminController { public $request; } }
namespace core\exception { class CommonException extends \RuntimeException {} }
namespace addon\hsx_lead\app\service\cooperation {
    final class TeamService {
        public static array $calls=[];
        public function __construct($context) {}
        public function adminReview(int $id,int $member,bool $approve): array { self::$calls[]=[$id,$member,$approve];return ['approve'=>$approve]; }
    }
}
namespace {
    function success($data) { return $data; }
    $plugin=dirname(__DIR__);
    require $plugin.'/app/service/Context.php';
    require $plugin.'/app/adminapi/controller/Entity.php';
    $controller=new \addon\hsx_lead\app\adminapi\controller\Entity();
    $request=new class {public $approve;public function siteId():int{return 100005;}public function uid():int{return 1;}public function param($key){return $this->approve;}};
    $controller->request=$request;$checks=0;
    foreach([true,false] as $value){$request->approve=$value;$out=$controller->review(9,17);if($out['approve']!==$value)throw new \RuntimeException('Boolean review must be preserved');$checks++;}
    foreach(['false','true','0','1',0,1,null,[],['true']] as $value){$request->approve=$value;try{$controller->review(9,17);throw new \RuntimeException('Invalid review accepted');}catch(\core\exception\CommonException $error){$checks++;}}
    if(count(\addon\hsx_lead\app\service\cooperation\TeamService::$calls)!==2)throw new \RuntimeException('Invalid values reached service');
    echo "PASS {$checks} strict admin review request checks; fake service only, no database or network\n";
}
