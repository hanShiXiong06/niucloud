import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'
import { viteFixture } from './vite-fixture.mjs'

// Actual plugin navigation, page lifecycle, state hook and SFC setup. Synthetic transports only.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), mobile = path.join(plugin, 'uni-app')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json')), Vue = require('vue'), ts = require('typescript'), compiler = require('@vue/compiler-sfc')
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const equal = (actual, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(actual)), expected, label); checks++ }
async function settle() { for (let step = 0; step < 8; step++) await Vue.nextTick() }
function execute(source, dependencies, globals = {}) {
    const module = { exports: {} }, js = ts.transpileModule(viteFixture(source), { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '})', { Date, Math, Number, String, Map, Promise, JSON, console, ...globals })(key => { if (key in dependencies) return dependencies[key]; if (key.endsWith('.vue')) return { default: {} }; if (key.startsWith('../../utils/')) return loadMobileUtility(path.basename(key)); throw Error('Unexpected import ' + key) }, module, module.exports)
    return module.exports
}
const routes = [], titles = [], stores = new Map([['wap_site_id', 100005]]); let history = []
const runtime = { getStorageSync: key => stores.get(key), setStorageSync: (key, value) => stores.set(key, value), removeStorageSync: key => stores.delete(key), navigateBack: args => routes.push({ action: 'back', ...args }), redirectTo: args => routes.push({ action: 'redirect', ...args }), navigateTo: args => routes.push({ action: 'navigate', ...args }), setNavigationBarTitle: value => titles.push(value.title), showToast() {}, showModal() {} }
const navigation = execute(fs.readFileSync(path.join(mobile, 'utils/cooperation-navigation.ts'), 'utf8'), {}, { uni: runtime, getCurrentPages: () => history })
const task = { route: 'addon/hsx_lead/pages/task/index' }, home = { route: 'addon/hsx_lead/pages/index' }
history = [home, task]; navigation.backCooperationTask(); equal(routes.at(-1), { action: 'back', delta: 1 }, 'normal predecessor returns exactly one page without disturbing its state')
history = [home, { route: 'app/pages/auth/login' }, task]; navigation.backCooperationTask(); equal(routes.at(-1), { action: 'back', delta: 2 }, 'onboarding return skips the adjacent auth login page')
history = [home, { route: '/app/pages/auth/index' }, { $page: { fullPath: '/app/pages/auth/login?type=username' } }, task]; navigation.backCooperationTask(); equal(routes.at(-1), { action: 'back', delta: 3 }, 'multiple adjacent authentication screens are skipped as one login flow')
history = [{ route: 'app/pages/auth/login' }, task]; navigation.backCooperationTask(); check(routes.at(-1).action === 'redirect' && routes.at(-1).url === navigation.cooperationHomeUrl, 'direct login-to-onboarding entry falls back to plugin home when no safe history exists')
history = [task]; navigation.backCooperationTask(); check(routes.at(-1).url === navigation.cooperationHomeUrl, 'a single direct task entry also returns home')
history = [{}, { route: 'app/pages/auth/register' }, task]; navigation.backCooperationTask(); check(routes.at(-1).action === 'redirect', 'unknown or authentication-only history is not treated as a safe destination')

const hookSource = fs.readFileSync(path.join(mobile, 'composables/useCooperationPage.ts'), 'utf8')
function page(defaultDirection, options, managedPaging = false) {
    const callbacks = {}, deps = { vue: Vue, '@/hooks/useShare': { useShare: () => ({ onShareAppMessage() {} }) }, '@dcloudio/uni-app': Object.fromEntries(['onHide', 'onLoad', 'onPullDownRefresh', 'onReachBottom', 'onShow'].map(name => [name, callback => { callbacks[name] = callback }])) }
    const state = execute(hookSource, deps, { uni: runtime }).useCooperationPage(defaultDirection, managedPaging); callbacks.onLoad(options); return state
}
check(page('incoming', {}).initialDirection.value === 'incoming', 'the customer workspace defaults to the receiving merchant role')
check(page('incoming', { direction: 'outgoing' }).initialDirection.value === 'outgoing', 'unmanaged page hooks retain their explicitly requested direction')
check(page('outgoing', {}).initialDirection.value === 'outgoing', 'the old stores destination retains the publishing merchant role')
check(page('outgoing', { direction: 'incoming' }).initialDirection.value === 'incoming', 'non-list unmanaged hooks retain the existing direction contract')
check(page('incoming', { direction: 'outgoing' }, true).initialDirection.value === 'incoming', 'fixed customer tab ignores an opposing query direction')
check(page('outgoing', { direction: 'incoming' }, true).initialDirection.value === 'outgoing', 'fixed store tab ignores an opposing query direction')
const routedIds = page('outgoing', { direction: 'incoming', collaboration_id: '71', promotion_invite: '1', mid: '19' }, true)
check(routedIds.collaborationId.value === 71 && routedIds.promotionRequested.value && routedIds.promotionInviter.value === 19, 'locking a role preserves the referenced collaboration and legitimate invitation intent')

const workbenchSource = fs.readFileSync(path.join(mobile, 'components/cooperation/CooperationWorkbench.vue'), 'utf8')
const parsed = compiler.parse(workbenchSource, { filename: path.join(mobile, 'components/cooperation/CooperationWorkbench.vue') }), script = compiler.compileScript(parsed.descriptor, { id: 'roles' })
const compiledTemplate = compiler.compileTemplate({ source: parsed.descriptor.template.content, filename: 'roles.vue', id: 'roles', compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
check(!compiledTemplate.errors.length, 'the role workspace and entitlement gate compile as real Vue templates')
const zDirectory=path.resolve(plugin,'../../../uni-app/node_modules/z-paging/components/z-paging/js')
const zAst=ts.createSourceFile('z-paging-main.js',fs.readFileSync(path.join(zDirectory,'z-paging-main.js'),'utf8'),ts.ScriptTarget.ES2020,true,ts.ScriptKind.JS)
const zMountedSource=zAst.statements.find(ts.isExportAssignment).expression.properties.find(item=>item.name?.text==='mounted').getText(zAst)
const zEnum=execute(fs.readFileSync(path.join(zDirectory,'z-paging-enum.js'),'utf8'),{}).default
function fixture(overrides = {}, config = {}) {
    const calls = [], nav = [], loginReturns = [], profile = { id: 7, publisher_until: 0 }, policy = { enabled: true, publishing_required: false, publishing_price: '9.90', fee_confirmed: true, ...config }
    const api = { cooperationPageUrls: { deliveries: '/addon/hsx_lead/pages/workbench/index', stores: '/addon/hsx_lead/pages/stores/index' }, coopMoney: value => value == null ? '—' : '¥' + Number(value).toFixed(2), coopRequestId: () => 'fixture', coopError: error => error.message,
        cooperationBootstrap: async () => { calls.push('bootstrap'); return { data: { profile: { ...profile }, config: { ...policy }, providers: [], stats: { outgoing: 3, selecting: 1, assigned: 1, following: 1, unpaid: 1 }, wallet: {} } } },
        cooperationLeads: async query => { calls.push({ name: 'leads', ...query }); return { data: { data: [], total: 0 } } }, cooperationOrder: async () => { throw Error('No payment should be requested by this fixture') } }
    const hook = execute(fs.readFileSync(path.join(mobile, 'composables/useCooperation.ts'), 'utf8'), { vue: Vue, '@/utils/common': { getSiteId:()=>100005, getToken: () => 'fixture' }, '../api/cooperation': api })
    const dependencies = { vue: { ...Vue, onMounted() {}, onBeforeUnmount() {} }, '@/utils/common': { getSiteId:()=>100005, getToken: () => 'fixture' }, '@/hooks/useLogin': { useLogin: () => ({ setLoginBack: value => loginReturns.push(value) }) }, '../../composables/useCooperationSubscribe': { useCooperationSubscribe:()=>({loading:Vue.ref(false), prepare: async () => false, request() {} }) }, '../../composables/useCooperation': hook, '../../api/cooperation': api, '../../utils/cooperation-navigation': { ...navigation, openCooperationTask: (task, params) => nav.push({ task, params }) } }
    dependencies['../../api/promotion'] = { promotionOverview: async () => { throw Error('Role list must not read marketing rules') } }
    const props = { initialId: 0, initialTab: 'deliveries', initialInviter: 0, initialPromotion: false, task: '', initialStoreId: 0, initialPurpose: '', initialPaymentId: 0, initialPromotionTab: 'overview', initialBusinessType: '', initialDirection: 'incoming', ...overrides }
    const state = execute(script.content, dependencies, { uni: runtime }).default.setup(props, { expose() {} })
    const timers=[],schedule=callback=>timers.push(callback),u={delay:schedule,getTime:()=>1,getSystemInfoSync:()=>({platform:'ios'}),gc:(_key,fallback)=>fallback}
    const data=execute(fs.readFileSync(path.join(zDirectory,'modules/data-handle.js'),'utf8'),{'.././z-paging-utils':{default:u},'.././z-paging-constant':{default:{delayTime:0}},'.././z-paging-enum':{default:zEnum},'../z-paging-interceptor':{default:{}}}).default
    const nativeMounted=execute('export default {'+zMountedSource+'}',{},{u,c:{delayTime:0},setTimeout:schedule}).default.mounted
    let mountEpoch=0
    Vue.watch([state.leadListVisible,state.leadPagingRevision],async([visible,revision])=>{
        const epoch=++mountEpoch,query=state.leadPagingQuery.value;state.leadPagingRef.value=null
        if(!visible)return
        await Vue.nextTick();await Vue.nextTick()
        if(epoch!==mountEpoch||revision!==state.leadPagingRevision.value||!state.leadListVisible.value)return
        const paging={auto:true,createdReload:false,isOnly:false,finalUseCache:false,finalRefresherEnabled:false,useCustomRefresher:false,showRefresherWhenReload:false,usePageScroll:false,autoHeight:false,layoutOnly:false,defaultPageNo:1,defaultPageSize:20,pageNo:1,totalData:[],realTotalData:[],dataPromiseResultMap:{},autoScrollToTopWhenReload:false,
            $nextTick(callback){return Vue.nextTick(callback?.bind(this))},_emitQuery:(page,size,from)=>query(page,size,from),
            _startLoading(){},_refresherEnd(){},_cleanRefresherEndTimeout(){},_callMyParentQuery(){},updateFixedLayout(){},_updateCachedSuperContentHeight(){},_updateScrollViewHeight(){},updatePageScrollTopHeight(){},updatePageScrollBottomHeight(){},updateLeftAndRightWidth(){},_onEmit(){},_nUpdateRefresherWidth(){},_getCssSafeAreaInsetBottom(){},completeByNoMore:async()=>{},complete:async()=>{}}
        for(const key of ['reload','_preReload','_reload'])paging[key]=data.methods[key].bind(paging)
        state.leadPagingRef.value=Vue.markRaw(paging);nativeMounted.call(paging)
    },{immediate:true,flush:'post'})
    const flush=async()=>{for(let n=0;n<12;n++){await settle();const queued=timers.splice(0);for(const callback of queued)callback()}}
    return { state, calls, nav, profile, policy, loginReturns,flush }
}
const outgoing = fixture({ initialTab: 'stores', initialDirection: 'outgoing' }); await outgoing.state.initialize();await outgoing.flush()
check(outgoing.state.ui.tab.value === 'deliveries' && outgoing.state.ui.direction.value === 'outgoing', 'legacy stores route normalizes to the real outgoing lead workspace, not a store-discovery panel')
check(outgoing.calls.find(call => call.name === 'leads').direction === 'outgoing', 'legacy stores entry reads publisher leads through the actual authoritative hook')
check(outgoing.state.workspaceTitle.value === '找门店' && titles.at(-1) === '找门店', 'publishing workspace and native header both identify the actual fixed store role')
check(outgoing.state.visibleStatusOptions.value.find(item => item.value === 'assigned').label === '待对方接单', 'publisher statuses describe the receiving store progress rather than claiming a receiving role')
const incoming = fixture(); await incoming.state.initialize();await incoming.flush()
check(incoming.calls.find(call => call.name === 'leads').direction === 'incoming' && !incoming.state.visibleStatusOptions.value.some(item => item.value === 'selecting'), 'separate customer tab reads only incoming leads and only receiving filters')
check(incoming.state.workspaceTitle.value === '找客户' && titles.at(-1) === '找客户', 'receiving workspace and native header both identify the actual fixed customer role')
check(!parsed.descriptor.template.content.includes('coop-direction-tabs') && !parsed.descriptor.template.content.includes('coop-role-hint') && !parsed.descriptor.template.content.includes('我有客户：') && !parsed.descriptor.template.content.includes('我来承接：'), 'fixed role screens have no duplicate inner role tab or explanatory subtitle')
check(parsed.descriptor.template.content.includes('<CooperationNav :title="workspaceTitle"') && !workbenchSource.includes('StoreDiscoveryPanel'), 'one shared workbench header presents the current role without a second discovery implementation')
check(/ui\.direction\.value === 'outgoing'[^\n]+class="coop-publish-dock"/.test(workbenchSource), 'the publishing CTA belongs exclusively to the outgoing role')
check(workbenchSource.includes(':show="overlay === \'select\'"') && !workbenchSource.includes("overlay === 'select' || overlay === 'stores'"), 'the store list is mounted only as the lead-specific selection step')
const storeWrapper = fs.readFileSync(path.join(mobile, 'pages/stores/index.vue'), 'utf8'), customerWrapper = fs.readFileSync(path.join(mobile, 'pages/workbench/index.vue'), 'utf8')
check(storeWrapper.includes(':initial-direction="initialDirection"') && storeWrapper.includes("useCooperationPage('outgoing', true)") && customerWrapper.includes("useCooperationPage('incoming', true)"), 'the two framework tab pages keep distinct fixed-role defaults while reusing one workbench and paging lifecycle')
check([storeWrapper, customerWrapper].every(source => source.includes("import CooperationWorkbench from '../../components/cooperation/CooperationWorkbench.vue'")) && workbenchSource.includes("import CooperationNav from './CooperationNav.vue'"), 'both role pages reuse the same workbench and public navigation header rather than forked UI copies')
const navFilename = path.join(mobile, 'components/cooperation/CooperationNav.vue')
const navParsed = compiler.parse(fs.readFileSync(navFilename, 'utf8'), { filename: navFilename })
const navScript = compiler.compileScript(navParsed.descriptor, { id: 'role-header' })
const navCss = compiler.compileStyle({ source: navParsed.descriptor.styles.map(style => style.content).join('\n'), filename: navFilename, id: 'role-header', scoped: false, preprocessLang: 'scss' })
check(!navParsed.errors.length && !navCss.errors.length, 'shared role header SFC and actual SCSS compile')
const headingCss = navCss.code.match(/\.cooperation-nav__title\s*\{([^}]*)\}/)?.[1] || ''
check(/font-size:\s*20px/.test(headingCss) && /font-weight:\s*700/.test(headingCss) && /line-height:\s*28px/.test(headingCss), 'all shared navigation titles use the requested larger twenty-pixel bold heading')
check(/white-space:\s*nowrap/.test(headingCss) && /text-overflow:\s*ellipsis/.test(headingCss), 'larger headings retain one-line overflow protection on narrow screens')
const navState = execute(navScript.content, { vue: { ...Vue, useSlots: () => ({}), onMounted() {}, onBeforeUnmount() {} } }).default.setup({ title: '找客户', subtitle: '', back: false, disabled: false, actions: [], actionsWidth: 44, background: '', safeAreaInsetTop: true }, { emit() {}, expose() {} })
check(navState.navHeight.value === 44, 'larger shared heading does not add a second row or increase the standard forty-four-pixel navigation height')
outgoing.state.login(); incoming.state.login()
check(outgoing.loginReturns[0].url === '/addon/hsx_lead/pages/stores/index' && incoming.loginReturns[0].url === '/addon/hsx_lead/pages/workbench/index', 'login returns to the correct distinct store or customer route')
check(!('direction' in outgoing.loginReturns[0].param) && !('direction' in incoming.loginReturns[0].param), 'fixed-role login return cannot reintroduce an opposing query direction')
const restoredPublisher = fixture({ initialTab: 'stores', initialDirection: page('outgoing', { direction: 'incoming' }, true).initialDirection.value }); await restoredPublisher.state.initialize();await restoredPublisher.flush()
check(restoredPublisher.state.ui.direction.value === 'outgoing' && restoredPublisher.calls.find(call => call.name === 'leads').direction === 'outgoing', 'conflicting deep-link direction cannot make the store tab show receiving data')

const gate=fixture({task:'publish',initialBusinessType:'broadband'},{publishing_required:true});let cleared=0
gate.state.publishRef.value={clear:()=>{cleared++}};await gate.state.initialize()
check(routes.at(-1).url==='/addon/hsx_lead/pages/membership/index'&&gate.state.needsMembershipEntitlement.value&&!cleared,'a direct publication checks server capability and navigates to the native membership page without clearing a draft')
gate.profile.can_publish=true;stores.set('hsx_lead_coop_changed',1);gate.state.pausePage();await gate.state.initialize()
check(gate.state.overlay.value==='publish'&&!cleared,'confirmed server publication rights allow the normal form without clearing its draft')
stores.delete('hsx_lead_coop_changed')
const free=fixture({task:'publish'},{publishing_required:false});await free.state.initialize();check(free.state.overlay.value==='publish','an explicit site exemption does not force membership payment')
console.log(`PASS ${checks} role/navigation/entitlement checks; real Vue setup, native navigation doubles and actual request hook, no browser/database/payment operations.`)
