<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli') exit(1);
require_once dirname(__DIR__, 3) . '/vendor/autoload.php';
define('HSX_LEAD_CATALOG_STORAGE_CHECK_LIBRARY_ONLY', true);
require dirname(__DIR__) . '/scripts/check-catalog-storage.php';

use addon\hsx_lead\scripts\CatalogStorageCheckCommand as Command;
use addon\hsx_lead\app\service\CatalogConfigStorage as Storage;
use think\facade\Db;

$checks = 0; $pdo = null; $schema = ''; $failed = false;
function storageCheckAssert(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
try {
    storageCheckAssert(Command::arguments(['--site=100005']) === ['site' => 100005, 'local_only' => false], 'explicit site parsed');
    storageCheckAssert(Command::arguments(['--local-only', '--site=1'])['local_only'], 'local-only supported');
    foreach ([[], ['--site=0'], ['--site=-1'], ['--site=01'], ['--site=1.0'], ['--site=1e3'], ['--site= 1'], ['--site=1', '--site=2'], ['--site=99999999999999999999999999'], ['--site=1', '--apply']] as $arguments) {
        try { Command::arguments($arguments); throw new LogicException('Invalid arguments accepted'); }
        catch (RuntimeException $error) { storageCheckAssert(!$error instanceof LogicException, 'invalid or unsafe arguments refused'); }
    }
    $encode = static fn(array $value): string => json_encode($value, JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE);
    $valid = [Storage::MARKER => Storage::MANIFEST_VERSION, 'generation' => '0123456789abcdef', 'parts' => 3,
        'bytes' => 50000, 'sha256' => str_repeat('a', 64), 'row_ids' => [11, 12, 13]];
    storageCheckAssert(Command::metadata($encode($valid))['problems'] === [], 'valid manifest metadata passes');
    storageCheckAssert(Command::metadata('')['problems'] === [] && Command::metadata(null)['storage'] === 'empty', 'reader-compatible empty values are not false corruption');
    $legacy = $valid; unset($legacy['row_ids']);
    $legacyReport = Command::metadata($encode($legacy));
    storageCheckAssert($legacyReport['problems'] === ['row_ids_missing'] && $legacyReport['manifest']['row_ids']['present'] === false, 'missing old primary index diagnosed without repair');
    foreach ([['11', 12, 13], [11, 11, 13], [1 => 11, 2 => 12, 3 => 13], [11, 12]] as $ids) {
        storageCheckAssert(Command::metadata($encode(array_replace($valid, ['row_ids' => $ids])))['problems'] !== [], 'invalid index shape rejected');
    }
    foreach (['{bad', 'null', '42'] as $raw) storageCheckAssert(!Command::metadata($raw)['json_valid'], 'invalid JSON shape diagnosed');
    $private = 'PRIVATE-CREDENTIAL-NEVER-PRINT';
    $metadata = Command::metadata($encode([Storage::MARKER => $private, 'generation' => $private, 'sha256' => $private, 'data' => $private]));
    storageCheckAssert(strpos($encode($metadata), $private) === false, 'arbitrary manifest values never printed');
    storageCheckAssert(Command::metadata($encode(['password' => $private]))['storage'] === 'inline', 'inline catalog summary only');
    storageCheckAssert(strpos($encode(Command::safeReadError(new RuntimeException($private))), $private) === false, 'raw driver exceptions redacted');
    $source = (string)file_get_contents(dirname(__DIR__) . '/scripts/check-catalog-storage.php');
    storageCheckAssert(strpos($source, 'Cache::') === false && strpos($source, 'Storage::write') === false, 'diagnostic contains no cache mutation or storage writes');

    if (in_array('--isolated-local-mysql', $argv, true)) {
        foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) if (function_exists($function)) throw new RuntimeException('Disable external network functions before isolated testing');
        if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) throw new RuntimeException('Disable allow_url_fopen');
        require __DIR__ . '/bootstrap.php';
        [$app, $pdo, $schema, $site] = leadBoot(); leadAssertIsolated($schema);
        $write = static function (int $tenant, string $key, array $value): void {
            Db::transaction(static function () use ($tenant, $key, $value): void {
                Db::name('site')->where('site_id', $tenant)->lock(true)->find(); Storage::write($tenant, $key, $value);
            });
        };
        $large = ['items' => array_map(static fn(int $i): array => ['id' => (string)$i, 'title' => str_repeat('测试型号', 20)], range(1, 600))];
        $write($site, 'HSX_LEAD_DEMAND_CATALOG', $large);
        $write($site, 'HSX_LEAD_COOPERATION', ['businesses' => [], 'secret_test' => $private]);
        $write($site, 'HSX_LEAD_CAPABILITY_71', $large);
        $write($site + 1, 'HSX_LEAD_COOPERATION', ['foreign_secret' => $private]);
        $old = Db::name('sys_config')->where('site_id', $site)->where('config_key', 'HSX_LEAD_DEMAND_CATALOG')->find();
        $manifest = json_decode($old['value'], true, 512, JSON_THROW_ON_ERROR); unset($manifest['row_ids']);
        Db::name('sys_config')->where('id', $old['id'])->update(['value' => $encode($manifest)]);
        $snapshot = static fn(): array => $pdo->query('SELECT * FROM lt_sys_config ORDER BY id')->fetchAll(PDO::FETCH_ASSOC);
        $before = $snapshot(); $report = Command::check($site);
        storageCheckAssert($before === $snapshot(), 'all local and foreign fixture config bytes unchanged');
        storageCheckAssert(!$report['passed'] && count($report['stored_configs']) === 3, 'broken old root detected and only intended key families reported');
        $byKey = array_column($report['service_reads'], null, 'config_key');
        storageCheckAssert($byKey['HSX_LEAD_DEMAND_CATALOG']['read']['status'] === 'failed', 'old manifest fails real strict reader');
        storageCheckAssert($byKey['HSX_LEAD_COOPERATION']['read']['status'] === 'passed', 'real inline service read passes');
        storageCheckAssert($byKey['HSX_LEAD_CAPABILITY_71']['read']['status'] === 'passed', 'real chunked service read passes in read-only transaction');
        storageCheckAssert(strpos($encode($report), $private) === false, 'read-only report excludes payload and foreign values');
        storageCheckAssert(!Db::connect()->getPdo()->inTransaction(), 'diagnostic transaction always closed');
        leadAssertIsolated($schema);
    }
    echo json_encode(['passed' => true, 'checks' => $checks, 'isolated_database' => $schema !== '', 'production_calls' => 0, 'diagnostic_writes' => 0], JSON_THROW_ON_ERROR), "\n";
} catch (Throwable $error) {
    $failed = true; fwrite(STDERR, 'FAIL catalog storage check command: ' . $error->getMessage() . "\n");
} finally {
    if ($pdo instanceof PDO && $schema !== '') try { leadCleanup($pdo, $schema); }
    catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL isolated fixture cleanup\n"); }
}
exit($failed ? 1 : 0);
