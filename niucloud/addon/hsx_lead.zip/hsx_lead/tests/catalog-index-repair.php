<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) exit("Requires --isolated-local-mysql\n");
foreach (['curl_exec', 'curl_multi_exec', 'fsockopen', 'pfsockopen', 'stream_socket_client', 'socket_connect'] as $function) {
    if (function_exists($function)) exit("Disable external network functions before isolated testing\n");
}
if (filter_var(ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN)) exit("Disable allow_url_fopen\n");
require __DIR__ . '/bootstrap.php';
define('HSX_LEAD_CATALOG_INDEX_REPAIR_LIBRARY_ONLY', true);
require dirname(__DIR__) . '/scripts/repair-catalog-index.php';

use addon\hsx_lead\app\service\CatalogConfigStorage as Storage;
use addon\hsx_lead\scripts\CatalogIndexRepair;
use think\facade\Db;

$checks = 0; $failed = false; $pdo = null; $schema = ''; $backupRoot = '';
function indexCheck(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    $GLOBALS['checks']++;
}
function indexReject(callable $operation, string $label): void
{
    try { $operation(); }
    catch (Throwable $error) {
        if (!$error instanceof RuntimeException && !$error instanceof \core\exception\CommonException) throw $error;
        indexCheck(true, $label); return;
    }
    throw new RuntimeException('Expected refusal: ' . $label);
}
try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    $testParent = realpath(sys_get_temp_dir()) . '/' . $schema;
    if (!is_dir($testParent)) mkdir($testParent, 0700);
    $backupRoot = $testParent . '/index-backup';
    $repair = new CatalogIndexRepair($backupRoot);
    $key = 'HSX_LEAD_DEMAND_CATALOG';
    $foreign = $site + 1;
    $encode = static fn(array $value): string => json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR);
    $content = ['items' => array_map(static fn(int $i): array => ['id' => (string)$i, 'title' => '苹果 iPhone ' . $i, 'path' => ['手机', '苹果', '型号' . $i]], range(1, 845))];
    $write = static function (int $tenant, string $base, array $value): void {
        Db::transaction(static function () use ($tenant, $base, $value): void {
            Db::name('site')->where('site_id', $tenant)->lock(true)->find();
            Storage::write($tenant, $base, $value);
        });
    };
    $snapshot = static fn(): array => Db::name('sys_config')->order('id')->select()->toArray();
    $write($site, $key, $content);
    $write($foreign, $key, $content);
    $root = Db::name('sys_config')->where('site_id', $site)->where('config_key', $key)->find();
    $manifest = json_decode($root['value'], true, 512, JSON_THROW_ON_ERROR);
    indexCheck(count($manifest['row_ids']) > 1, 'fixture genuinely requires multiple official-TEXT fragments');
    $legacy = $manifest; unset($legacy['row_ids']);
    Db::name('sys_config')->where('id', $root['id'])->update(['value' => $encode($legacy)]);
    $before = $snapshot();
    indexReject(static fn() => Storage::read($site, $key), 'current strict runtime reproduces the exact missing-index failure');
    $check = $repair->run($site, $key);
    indexCheck($check['status'] === 'repairable', 'check identifies only verified missing indices as repairable');
    indexCheck($snapshot() === $before && !file_exists($backupRoot), 'check performs no row, cache or backup writes');
    $done = $repair->run($site, $key, true);
    indexCheck($done['status'] === 'repaired', 'explicit apply repairs the verified index');
    indexCheck(Storage::read($site, $key) === $content, 'all 845 original directory entries are restored without content replacement');
    $afterRoot = Db::name('sys_config')->where('id', $root['id'])->find();
    $afterManifest = json_decode($afterRoot['value'], true, 512, JSON_THROW_ON_ERROR);
    $expected = $legacy; $expected['row_ids'] = $manifest['row_ids'];
    indexCheck($afterManifest === $expected, 'manifest changes only by adding original fragment primary IDs');
    foreach ($before as $old) {
        $after = Db::name('sys_config')->where('id', $old['id'])->find();
        if ((int)$old['id'] === (int)$root['id']) { unset($old['value'], $after['value']); }
        indexCheck($old === $after, 'root timestamps, fragments and other tenants remain byte-for-byte unchanged');
    }
    $backups = [];
    if (is_dir($backupRoot)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($backupRoot, FilesystemIterator::SKIP_DOTS));
        foreach ($iterator as $file) if ($file->isFile()) $backups[] = $file->getPathname();
    }
    indexCheck(count($backups) > 0, 'apply creates a private backup before writing');
    $backupText = '';
    foreach ($backups as $backup) {
        indexCheck((fileperms($backup) & 0777) === 0600, 'backup files are not public or group-readable');
        $backupText .= file_get_contents($backup);
    }
    indexCheck(str_contains($backupText, 'HSX_LEAD_DEMAND_CATALOG'), 'backup identifies the original root configuration');
    $stable = $snapshot(); $repeat = $repair->run($site, $key, true);
    indexCheck($repeat['status'] === 'no_repair_needed' && $snapshot() === $stable, 'second apply is idempotent and does not rewrite valid data');

    $mutations = [
        'existing malformed indices' => static function (array $m): array { $m['row_ids'] = [1]; return $m; },
        'unknown storage version' => static function (array $m): array { $m[Storage::MARKER] = 'chunks.v9'; return $m; },
        'missing original checksum' => static function (array $m): array { unset($m['sha256']); return $m; },
        'invalid original checksum' => static function (array $m): array { $m['sha256'] = str_repeat('0', 64); return $m; },
        'forged byte length' => static function (array $m): array { $m['bytes']++; return $m; },
    ];
    foreach ($mutations as $label => $mutate) {
        Db::name('sys_config')->where('id', $root['id'])->update(['value' => $encode($mutate($legacy))]);
        $corruptBefore = $snapshot();
        indexReject(static fn() => $repair->run($site, $key, true), $label . ' is refused rather than laundered');
        indexCheck($snapshot() === $corruptBefore, $label . ' refusal changes no business data');
    }
    Db::name('sys_config')->where('id', $root['id'])->update(['value' => $encode($legacy)]);
    $first = Db::name('sys_config')->where('id', $manifest['row_ids'][0])->find();
    Db::name('sys_config')->where('id', $first['id'])->update(['site_id' => $foreign]);
    indexReject(static fn() => $repair->run($site, $key, true), 'another tenant cannot supply a missing fragment');
    Db::name('sys_config')->where('id', $first['id'])->update(['site_id' => $site]);
    $duplicate = $first; unset($duplicate['id']);
    $duplicateId = (int)Db::name('sys_config')->insertGetId($duplicate);
    indexReject(static fn() => $repair->run($site, $key, true), 'duplicate named fragments are refused');
    Db::name('sys_config')->where('id', $duplicateId)->delete();
    $duplicate = $root; unset($duplicate['id']); $duplicate['value'] = $encode($legacy);
    $duplicateId = (int)Db::name('sys_config')->insertGetId($duplicate);
    indexReject(static fn() => $repair->run($site, $key, true), 'duplicate root rows are refused');
    Db::name('sys_config')->where('id', $duplicateId)->delete();
    Db::startTrans();
    try { indexReject(static fn() => $repair->run($site, $key, true), 'repair refuses an existing outer transaction and stale RR snapshot'); }
    finally { Db::rollback(); }
    indexReject(static fn() => $repair->run(0, $key, true), 'invalid tenant is refused');
    indexReject(static fn() => $repair->run($site, 'HSX_LEAD_PROMOTION', true), 'unrelated configuration is outside repair scope');
    $repair->run($site, $key, true);
    indexCheck(Storage::read($site, $key) === $content && Storage::read($foreign, $key) === $content, 'all negative cases leave both tenants original contents recoverable');
    leadAssertIsolated($schema);
    echo json_encode(['passed' => true, 'checks' => $checks, 'scope' => 'verified missing-index repair; owned random localhost schema only; no external requests'], JSON_UNESCAPED_UNICODE), PHP_EOL;
} catch (Throwable $error) {
    $failed = true; fwrite(STDERR, 'FAIL catalog index repair: ' . $error->getMessage() . ' at ' . basename($error->getFile()) . ':' . $error->getLine() . PHP_EOL);
} finally {
    try { if (Db::connect()->getPdo() instanceof PDO && Db::connect()->getPdo()->inTransaction()) Db::rollback(); } catch (Throwable $ignored) {}
    if ($pdo instanceof PDO && $pdo->inTransaction()) $pdo->rollBack();
    if ($pdo instanceof PDO && $schema !== '') {
        try { leadCleanup($pdo, $schema); } catch (Throwable $error) { $failed = true; fwrite(STDERR, "FAIL owned schema cleanup\n"); }
    }
    if ($backupRoot !== '' && is_dir($backupRoot)) {
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($backupRoot, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
        foreach ($iterator as $entry) $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
        rmdir($backupRoot);
    }
}
exit($failed ? 1 : 0);
