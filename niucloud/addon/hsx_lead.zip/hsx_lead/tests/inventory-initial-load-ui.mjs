import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import { createRequire } from 'node:module'
import { fileURLToPath } from 'node:url'
import { loadMobileUtility } from './mobile-utils.mjs'

// Real inventory setup/template and the installed z-paging mounted/_preReload
// scheduling. Only popup visibility/layout and transport are synthetic.
// No live API, member session, database or external ERP is touched.
const plugin = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const require = createRequire(path.resolve(plugin, '../../../uni-app/package.json'))
const Vue = require('vue'), compiler = require('@vue/compiler-sfc'), ts = require('typescript')
const filename = path.join(plugin, 'uni-app/components/cooperation/CoopStoreInventory.vue')
const source = fs.readFileSync(filename, 'utf8')
const zDirectory = path.resolve(plugin, '../../../uni-app/node_modules/z-paging/components/z-paging/js')
let checks = 0
const check = (ok, label) => { assert.ok(ok, label); checks++ }
const equal = (value, expected, label) => { assert.deepEqual(JSON.parse(JSON.stringify(value)), expected, label); checks++ }
function execute(content, deps = {}, globals = {}) {
    const module = { exports: {} }
    const js = ts.transpileModule(content, { compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020 } }).outputText
    vm.runInNewContext('(function(require,module,exports){' + js + '\n})', { Date, Math, Number, String, Array, JSON, Set, Map, Promise, console, ...globals })(name => {
        if (name in deps) return deps[name]
        if (name.endsWith('.vue')) return { default: { render: () => null } }
        throw Error('Unexpected dependency: ' + name)
    }, module, module.exports)
    return module.exports
}
const zAst = ts.createSourceFile('z-paging-main.js', fs.readFileSync(path.join(zDirectory, 'z-paging-main.js'), 'utf8'), ts.ScriptTarget.ES2020, true, ts.ScriptKind.JS)
const mountedSource = zAst.statements.find(ts.isExportAssignment).expression.properties.find(item => item.name?.text === 'mounted').getText(zAst)
const enumeration = execute(fs.readFileSync(path.join(zDirectory, 'z-paging-enum.js'), 'utf8')).default
const node = (type, text = '') => ({ type, text, props: {}, children: [], parent: null })
const remove = child => { const parent = child.parent; if (parent) { const index = parent.children.indexOf(child); if (index >= 0) parent.children.splice(index, 1) }; child.parent = null }
const renderer = Vue.createRenderer({
    createElement: type => node(type), createText: text => node('#text', text), createComment: text => node('#comment', text),
    insert(child, parent, anchor) { if (child.parent) remove(child); const index = anchor ? parent.children.indexOf(anchor) : -1; parent.children.splice(index < 0 ? parent.children.length : index, 0, child); child.parent = parent },
    remove, setText: (target, text) => { target.text = text }, setElementText: (target, text) => { target.text = text; target.children = [] },
    parentNode: target => target.parent, nextSibling: target => target.parent?.children[target.parent.children.indexOf(target) + 1] || null,
    patchProp: (target, key, _old, value) => { target.props[key] = value },
})
const visibleText = target => [target.text, ...target.children.map(visibleText)].join(' ')
const fixtures = []
async function settle() { for (let step = 0; step < 8; step++) { await Promise.resolve(); await Vue.nextTick() } }
function fixture({ delayed = false, legacy = false, show = true, storeId = 7 } = {}) {
    const timers = new Map(), calls = [], pagers = [], gate = Vue.ref(!delayed)
    let timerId = 0, state
    const schedule = callback => { timers.set(++timerId, callback); return timerId }
    const u = { delay: schedule, getTime: () => 1, getSystemInfoSync: () => ({ platform: 'ios' }) }
    const data = execute(fs.readFileSync(path.join(zDirectory, 'modules/data-handle.js'), 'utf8'), {
        '.././z-paging-utils': { default: { ...u, gc: (_key, fallback) => fallback } },
        '.././z-paging-constant': { default: { delayTime: 0 } }, '.././z-paging-enum': { default: enumeration }, '../z-paging-interceptor': { default: {} },
    }).default
    const mounted = execute('export default {' + mountedSource + '}', {}, { u, c: { delayTime: 0 }, setTimeout: schedule }).default.mounted
    const controls = { read: async (id, query) => ({ data: { data: [{ id: id * 100 + query.page, model: '合成库存' + id }], total: 1, snapshot_at: 100 } }) }
    const Pager = {
        name: 'ZPaging', props: ['auto', 'modelValue', 'defaultPageSize'], emits: ['query'],
        setup(props, { emit, expose, slots }) {
            const paging = {
                auto: props.auto, createdReload: false, isOnly: false, finalUseCache: false, finalRefresherEnabled: false, useCustomRefresher: false,
                defaultPageNo: 1, defaultPageSize: Number(props.defaultPageSize) || 20, pageNo: 1, dataPromiseResultMap: {}, realTotalData: [], completions: [], manualReloads: 0,
                $nextTick(callback) { return Vue.nextTick(callback?.bind(this)) },
                _emitQuery(page, size, from) { emit('query', page, size, from) },
                _startLoading() {}, _refresherEnd() {}, _cleanRefresherEndTimeout() {}, _callMyParentQuery() {}, _scrollToTop() {},
                updateFixedLayout() {}, _updateCachedSuperContentHeight() {}, _updateScrollViewHeight() {}, updatePageScrollTopHeight() {}, updatePageScrollBottomHeight() {}, updateLeftAndRightWidth() {}, _onEmit() {}, _nUpdateRefresherWidth() {}, _getCssSafeAreaInsetBottom() {},
                completeByNoMore(rows, noMore) { this.completions.push({ rows, noMore }); return Promise.resolve() }, complete(ok) { this.completions.push({ ok }); return Promise.resolve() },
            }
            for (const key of ['_preReload', '_reload']) paging[key] = data.methods[key].bind(paging)
            const actualReload = data.methods.reload.bind(paging)
            paging.reload = () => { paging.manualReloads++; return actualReload() }
            pagers.push(paging); expose(paging)
            Vue.onMounted(() => mounted.call(paging))
            return () => Vue.h('pager-fixture', slots.default?.())
        },
    }
    const Sheet = { props: ['show'], setup(props, { slots }) { return () => props.show && gate.value ? Vue.h('sheet-fixture', slots.default?.()) : null } }
    let content = source
    if (legacy) content = content.replace("import { computed,", "import { nextTick, computed,").replace(':auto="true"', ':auto="false"').replace('function reloadInventory(', 'async function reloadInventory(').replace('pagingRevision.value++', 'const revision = ++pagingRevision.value; await nextTick(); if (!props.show || revision !== pagingRevision.value) return; return pagingRef.value?.reload()')
    const descriptor = compiler.parse(content, { filename }).descriptor
    const script = compiler.compileScript(descriptor, { id: 'inventory-initial' })
    const template = compiler.compileTemplate({ source: descriptor.template.content, filename, id: 'inventory-initial', compilerOptions: { bindingMetadata: script.bindings, expressionPlugins: ['typescript'] } })
    check(!template.errors.length, 'real inventory template compiles')
    const actual = execute(script.content, {
        vue: Vue, 'z-paging/components/z-paging/z-paging.vue': { default: Pager }, './CoopTaskSheet.vue': { default: Sheet },
        '../../utils/mobile-ui': loadMobileUtility('mobile-ui'),
        '../../api/cooperation': { cooperationStoreInventory: (id, query) => { calls.push({ id, ...query }); return controls.read(id, query) }, coopDate: String, coopMoney: String, coopError: cause => cause?.message || '读取失败' },
    }).default
    const rendered = execute(template.code, { vue: Vue }).render
    const component = { ...actual, render: rendered, setup(props, context) { state = actual.setup(props, context); return state } }
    const props = Vue.reactive({ show, page: !delayed, store: { id: storeId, name: '合成门店' } })
    const root = node('root'), app = renderer.createApp({ render: () => Vue.h(component, props) })
    app.config.warnHandler = () => {}; app.mount(root)
    const value = { props, gate, controls, calls, pagers, root, app, get state() { return state }, async flush() { for (let step = 0; step < 12; step++) { await settle(); const batch = [...timers.values()]; timers.clear(); for (const callback of batch) callback() } } }
    fixtures.push(value)
    return value
}
try {
    check(source.includes(':auto="true"') && !source.includes('pagingRef.value?.reload()'), 'initial request belongs to installed pager mounted, not an optional early parent ref call')
    const legacy = fixture({ delayed: true, legacy: true }); await legacy.flush()
    check(legacy.calls.length === 0 && legacy.pagers.length === 0, 'negative control: parent ticks pass before delayed popup mounts its pager')
    legacy.gate.value = true; await legacy.flush()
    check(legacy.calls.length === 0 && legacy.pagers.length === 1, 'negative control: original auto=false leaves stock empty after the missed reload')
    legacy.pagers[0].reload(); await legacy.flush()
    check(legacy.calls.length === 1 && legacy.state.rows.value.length === 1, 'negative control reproduces manual refresh making the same inventory appear')

    const h = fixture({ delayed: true }); await h.flush()
    check(h.calls.length === 0 && h.state.pagingRef.value === null, 'delayed initial slot may pass many parent nextTicks without needing a ref')
    h.gate.value = true; await h.flush()
    check(h.calls.length === 1 && h.calls[0].id === 7 && h.calls[0].page === 1, 'real mounted automatically reads the delayed first page exactly once')
    check(h.pagers.every(pager => pager.manualReloads === 0), 'initial load never uses a parent manual reload fallback')
    check(h.state.firstPageReady.value && h.state.rows.value.length === 1 && visibleText(h.root).includes('合成库存7'), 'first response renders actual inventory rows without user interaction')
    await h.flush(); check(h.calls.length === 1, 'settling more render/lifecycle turns does not duplicate the first read')
    h.state.keyword.value = ' 苹果 '; h.state.search(); await h.flush()
    equal(h.calls.at(-1), { id: 7, keyword: '苹果', page: 1, limit: 20 }, 'search remount uses the frozen trimmed keyword and first page')
    check(h.calls.length === 2 && h.pagers.every(pager => pager.manualReloads === 0), 'search has one mounted request, not mounted plus parent reload')
    h.state.keyword.value = '未提交的输入'; await h.flush(); check(h.calls.length === 2, 'typing does not request or clear applied inventory')
    h.props.store = { id: 7, name: '同店改名' }; await h.flush(); check(h.calls.length === 2 && h.state.keyword.value === '未提交的输入', 'same store metadata preserves search and avoids reload')

    let finishOld
    h.controls.read = () => new Promise(resolve => { finishOld = resolve })
    h.state.keyword.value = '旧查询'; h.state.search(); await h.flush()
    const old = h.pagers.at(-1), beforeSwitch = h.calls.length
    h.controls.read = async id => ({ data: { data: [{ id: 801, model: '新门店库存' }], total: 1 } })
    h.props.store = { id: 8, name: '另一家门店' }; await h.flush()
    check(h.calls.length === beforeSwitch + 1 && h.calls.at(-1).id === 8 && h.calls.at(-1).keyword === '', 'store change resets keyword and automatically reads only the new store')
    finishOld({ data: { data: [{ id: 799, model: '旧门店迟到库存' }], total: 1 } }); await h.flush()
    equal(h.state.rows.value.map(row => row.id), [801], 'late old-store response cannot replace current-store inventory')
    const beforeOldQuery = h.calls.length; old._emitQuery(1, 20); await h.flush(); check(h.calls.length === beforeOldQuery, 'obsolete keyed pager query is ignored')

    let finishClosed
    h.controls.read = () => new Promise(resolve => { finishClosed = resolve }); h.state.search(); await h.flush()
    h.props.show = false; await h.flush(); finishClosed({ data: { data: [{ id: 888 }], total: 1 } }); await h.flush()
    check(!h.state.loading.value && h.state.rows.value.every(row => row.id !== 888), 'closing cancels pending response ownership and releases loading')
    h.controls.read = async id => ({ data: { data: [{ id: id * 100 + 2, model: '重开库存' }], total: 1 } })
    const beforeReopen = h.calls.length; h.props.show = true; await h.flush()
    check(h.calls.length === beforeReopen + 1 && h.state.rows.value[0].id === 802, 'reopening has one automatic fresh first-page read')
    h.controls.read = async () => { throw Error('合成库存失败') }; h.state.keyword.value = '失败条件'; h.state.search(); await h.flush()
    check(h.state.error.value.includes('合成库存失败') && !h.state.loading.value && !h.state.rows.value.length, 'failed fresh search shows an error, not unrelated previous rows')
    h.controls.read = async () => ({ data: { data: [], total: 0 } }); h.state.search(); await h.flush()
    check(h.state.firstPageReady.value && h.state.total.value === 0 && !h.state.error.value && !h.state.rows.value.length, 'successful empty result finishes correctly and clears the previous error')
    const immediate = fixture(); await immediate.flush(); check(immediate.calls.length === 1 && immediate.state.rows.value.length === 1, 'ordinary native page without popup delay also loads automatically once')
    const waitingIdentity = fixture({ storeId: 0 }); await waitingIdentity.flush(); check(waitingIdentity.calls.length === 0, 'missing store identity never queries another or zero store')
    waitingIdentity.props.store = { id: 9, name: '延迟返回的门店' }; await waitingIdentity.flush(); check(waitingIdentity.calls.length === 1 && waitingIdentity.calls[0].id === 9, 'late-arriving valid store automatically loads without user refresh')
} finally {
    for (const fixture of fixtures) fixture.app.unmount()
}
console.log(`PASS ${checks} inventory initial-load checks; actual inventory template and installed pager mounted scheduling, delayed synthetic popup/transport, no live API or business writes.`)
