<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli')exit(1);
require dirname(__DIR__,3).'/vendor/autoload.php';
use addon\hsx_lead\app\service\CatalogConfigStorage;
use core\exception\CommonException;
$method=new ReflectionMethod(CatalogConfigStorage::class,'identity');$method->setAccessible(true);$checks=0;
foreach(['HSX_LEAD_DEMAND_CATALOG','HSX_LEAD_COOPERATION','HSX_LEAD_CAPABILITY_1','HSX_LEAD_CAPABILITY_1234567890','HSX_LEAD_CAPABILITY_9999999999']as$key){$method->invoke(null,100005,$key);$checks++;}
foreach(['HSX_LEAD_CAPABILITY_0','HSX_LEAD_CAPABILITY_01','HSX_LEAD_CAPABILITY_-1','HSX_LEAD_CAPABILITY_','HSX_LEAD_CAPABILITY_10000000000','HSX_LEAD_CAPABILITY_1_extra','HSX_LEAD_PROMOTION','site_config_cacheHSX_LEAD_COOPERATION_100005','HSX_LEAD_CFG_arbitrary',"HSX_LEAD_CAPABILITY_1\n"]as$key){
    try{$method->invoke(null,100005,$key);}catch(CommonException$error){$checks++;continue;}throw new RuntimeException('Unexpected storage key accepted');
}
foreach([0,-1]as$site){try{$method->invoke(null,$site,'HSX_LEAD_CAPABILITY_1');}catch(CommonException$error){$checks++;continue;}throw new RuntimeException('Unexpected tenant accepted');}
echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'pure key allowlist validation; no database or external requests']),PHP_EOL;
