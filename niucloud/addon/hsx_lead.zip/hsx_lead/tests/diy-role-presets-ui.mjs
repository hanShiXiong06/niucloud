import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import vm from 'node:vm'
import {createRequire} from 'node:module'
import {fileURLToPath} from 'node:url'
import {execFileSync} from 'node:child_process'
const plugin=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),require=createRequire(path.resolve(plugin,'../../../admin/package.json'))
const Vue=require('vue'),compiler=require('@vue/compiler-sfc'),ts=require('typescript')
let checks=0;const check=(value,label)=>{assert.ok(value,label);checks++}
function moduleOf(source,deps={}){const module={exports:{}},js=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2020}}).outputText;vm.runInNewContext(`(function(require,module,exports){${js}\n})`,{String,Object,Array,Number,Promise})(key=>key in deps?deps[key]:key.endsWith('.vue')?{default:{}}:(()=>{throw Error('Unexpected import '+key)})(),module,module.exports);return module.exports}
const presets=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/diyPresets.ts'),'utf8'))
const roleEntry=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/roleEntry.ts'),'utf8'))
check(presets.leadHomePresets.map(row=>row.key).join(',')==='classic,compact,clean,soft','classic illustration, compact, clean and soft alternatives remain available')
check(presets.leadHomePreset('invalid')===null,'unknown preset never changes live layout')
for(const key of ['classic','compact','clean','soft']){const patch=presets.leadHomePreset(key);check(patch.layoutPreset===key&&patch.panelColor===''&&patch.componentStartBgColor,'preset writes a native framework background instead of an opaque inner panel: '+key);check(!['title','storeTitle','storeImage','customerImage','showTools','showBusinesses'].some(field=>field in patch),'preset preserves custom content, uploaded images and business switches: '+key)}
check(new Set(presets.leadHomePresets.map(row=>presets.leadHomePreset(row.key).borderColor)).size===4,'each explicitly applied preset includes its intended fine border, including transparent clean style')
const filename=path.join(plugin,'admin/views/diy/components/edit-lead-cooperation-entry.vue'),parsed=compiler.parse(fs.readFileSync(filename,'utf8'),{filename}),script=compiler.compileScript(parsed.descriptor,{id:'role-presets'})
check(parsed.errors.length===0&&compiler.compileTemplate({source:parsed.descriptor.template.content,filename,id:'role-presets',compilerOptions:{bindingMetadata:script.bindings,expressionPlugins:['typescript']}}).errors.length===0,'shared role/business editor parses and compiles')
check(script.content.includes("from '@/components/upload-image/index.vue'")&&parsed.descriptor.template.content.includes('<UploadImage v-model="diyStore.editComponent.storeImage"')&&parsed.descriptor.template.content.includes('<UploadImage v-model="diyStore.editComponent.customerImage"'),'dynamic role editor explicitly depends on the existing framework uploader for both image inputs')
let confirm=async()=>{},calls=0
function fixture(mode='roles',initial={}){
    const mounted=[],row=Vue.reactive({componentName:mode==='business'?'LeadBusinessNavigation':'LeadCooperationEntry',...initial}),store=Vue.reactive({editTab:'content',currentIndex:0,value:[row],predefineColors:[],get editComponent(){return this.value[this.currentIndex]}})
    const helper=moduleOf(fs.readFileSync(path.join(plugin,'admin/composables/diyBusinessPreview.ts'),'utf8'))
    const state=moduleOf(script.content,{vue:{...Vue,onMounted:fn=>mounted.push(fn),onBeforeUnmount(){}},'element-plus':{ElMessageBox:{confirm:async(...args)=>{calls++;return confirm(...args)}}},'@/stores/modules/diy':{default:()=>store},'@/stores/modules/user':{default:()=>({siteInfo:{site_id:100005}})},'../../../api/cooperation':{getCooperationConfig:async()=>{throw Error('Must not read without permission')}},'../../../composables/navigation':{hasLeadPagePermission:()=>false},'../../../composables/diyBusinessPreview':helper,'../../../composables/diyPresets':presets,'../../../composables/roleEntry':roleEntry}).default.setup({mode},{expose(){}})
    mounted.forEach(fn=>fn());return{row,store,state}
}
const f=fixture('roles',{title:'我自己的标题',titleColor:'#123456',componentStartBgColor:'#abcdef',storeImage:'own-store.png',showTools:0,showBusinesses:0})
check(f.row.layoutPreset==='classic'&&f.row.usePresetImages===1,'new default restores original illustrated role cards')
check(f.row.titleColor==='#123456'&&f.row.componentStartBgColor==='#abcdef','opening editor does not overwrite saved colors or native background')
f.state.presetChoice.value='soft';check(f.row.layoutPreset==='classic'&&f.row.titleColor==='#123456','selecting a preset alone has no implicit preview or persisted recoloring')
confirm=async()=>{throw Error('cancel')};await f.state.applyPreset();check(f.row.layoutPreset==='classic'&&f.row.titleColor==='#123456','cancel keeps original design intact')
confirm=async()=>{};await f.state.applyPreset();check(f.row.layoutPreset==='soft'&&f.row.componentStartBgColor==='#eef5ff','explicit confirmation applies the chosen layout and native background')
check(f.row.title==='我自己的标题'&&f.row.storeImage==='own-store.png'&&f.row.showTools===0&&f.row.showBusinesses===0,'applying preset retains copy, uploaded image and user-selected switches')
let resolve;confirm=()=>new Promise(done=>{resolve=done});f.state.presetChoice.value='clean';const pending=f.state.applyPreset(),before=calls;await f.state.applyPreset();check(calls===before&&f.state.applyingPreset.value,'pending confirmation is locked against duplicate applies')
const other={componentName:'LeadCooperationEntry',titleColor:'#ff0000'};f.store.value.push(other);f.store.currentIndex=1;resolve();await pending;check(f.store.editComponent.titleColor==='#ff0000'&&f.row.layoutPreset==='soft','switching selected block during confirmation cannot modify another block or stale target')
const business=fixture('business');check(business.row.layoutPreset==='compact'&&business.row.showTitle===1&&business.row.title==='服务业务','business block initializes its own independent title and layout')
check(!('storeTitle'in business.row)&&!('showTools'in business.row),'business editor does not inject role-entry or tool controls')
const callCount=calls;await business.state.applyPreset();check(calls===callCount,'role card presets cannot accidentally repaint the independent business block')
const php=`echo json_encode(require ${JSON.stringify(path.join(plugin,'app/dict/diy/pages.php'))},JSON_UNESCAPED_UNICODE);`,dict=JSON.parse(execFileSync(process.env.PHP_BIN||'php',['-d','error_reporting=0','-r',php],{encoding:'utf8'})),page=dict.DIY_HSX_LEAD_INDEX.hsx_lead_index
check(page.data.global.pageStartBgColor==='#eef5ff','blue-white template background remains an editable native global field')
check(page.data.value.map(row=>row.componentName).join(',')==='LeadCooperationHero,LeadRoleEntry,LeadRoleEntry,LeadBusinessNavigation','hero and both role cards can be arranged or removed independently from business navigation')
const combined=dict.DIY_HSX_LEAD_INDEX.hsx_lead_combined.data.value[0]
check(combined.componentName==='LeadCooperationEntry'&&combined.showTools===0&&combined.showBusinesses===0,'optional combined template remains available without duplicated bottom tools or businesses')
check(parsed.descriptor.template.content.includes(':allow-panel="false"')&&parsed.descriptor.template.content.includes('<slot name="style" />'),'role and business skins expose native outer background controls rather than competing inner background controls')
console.log(`PASS ${checks} independent DIY role preset/editor contracts; actual Vue/PHP with synthetic state, no browser or database writes.`)
