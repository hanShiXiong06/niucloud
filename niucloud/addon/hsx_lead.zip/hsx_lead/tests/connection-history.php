<?php
declare(strict_types=1);

/** In-memory query doubles: no framework bootstrap, database, ERP transport, credentials or fixtures are read. */
namespace addon\hsx_lead\app\support {
    final class HistoryRows
    {
        public function __construct(private array $rows) {}
        public function toArray(): array { return $this->rows; }
    }
    final class HistoryQuery
    {
        private array $conditions=[];
        private ?array $fields=null;
        private int $limit=PHP_INT_MAX;
        private bool $descending=false;
        public function __construct(private string $table) {}
        public function where(string $field,$value): self { $this->conditions[$field]=$value;return $this; }
        public function field(string $value): self { $this->fields=explode(',',$value);return $this; }
        public function order(string $value): self { if($value!=='id desc')throw new \RuntimeException('Unexpected order');$this->descending=true;return $this; }
        public function limit(int $value): self { $this->limit=$value;return $this; }
        private function rows(): array
        {
            $rows=array_values(array_filter(Data::$tables[$this->table]??[],function(array $row):bool {
                foreach($this->conditions as $key=>$value)if(($row[$key]??null)!=$value)return false;
                return true;
            }));
            if($this->descending)usort($rows,static fn(array $a,array $b):int=>$b['id']<=>$a['id']);
            return $rows;
        }
        public function count(): int { return count($this->rows()); }
        public function find(): ?array { return $this->rows()[0]??null; }
        public function select(): HistoryRows
        {
            $rows=array_slice($this->rows(),0,$this->limit);
            if($this->fields!==null)$rows=array_map(fn(array $row):array=>array_intersect_key($row,array_flip($this->fields)),$rows);
            return new HistoryRows($rows);
        }
    }
    final class Data
    {
        public static array $tables=[];
        public static function query(string $table,int $site): HistoryQuery
        {
            if($site<=0||!in_array($table,['connection','sync_run'],true))throw new \RuntimeException('Unexpected query');
            return (new HistoryQuery($table))->where('site_id',$site);
        }
        public static function decode($value): array { return is_string($value)?(json_decode($value,true)?:[]):[]; }
    }
    final class Cipher { public static function decrypt(...$args): array { return []; } }
}
namespace addon\hsx_lead\app\provider {
    final class ProviderDefinition
    {
        public function key(): string { return 'synthetic'; }
        public function metadata(): array { return ['name'=>'Synthetic ERP']; }
        public function publicCredentials(array $value): array { return []; }
        public function renewalStatus(array $value): array { return ['automatic'=>false,'ready'=>false]; }
        public function renewable(array $value): bool { return false; }
    }
    final class ProviderRegistry { public function definition(string $value): ProviderDefinition { return new ProviderDefinition(); } }
}
namespace addon\hsx_lead\app\service {
    final class Context
    {
        public function __construct(public int $site,public int $memberId,private int $merchantId) {}
        public function connectionMerchant(int $id): array
        {
            if($id!==$this->merchantId)throw new \RuntimeException('Foreign merchant denied');
            return ['id'=>$id];
        }
    }
    final class ProviderChannelService
    {
        public static bool $enabled=true;
        public function __construct(int $site) {}
        public function enabled(string $provider): bool { return self::$enabled; }
        public function displayName(string $provider): string { return 'Synthetic ERP'; }
    }
}
namespace {
    if(PHP_SAPI!=='cli')exit(1);
    require dirname(__DIR__).'/app/support/ProviderPublicMessage.php';
    require dirname(__DIR__).'/app/support/SyncStatus.php';
    require dirname(__DIR__).'/app/service/ConnectionService.php';
    use addon\hsx_lead\app\service\{ConnectionService,Context,ProviderChannelService};
    use addon\hsx_lead\app\support\Data;
    $checks=0;
    function historyCheck(bool $condition,string $message): void { if(!$condition)throw new \RuntimeException($message);$GLOBALS['checks']++; }
    $site=100005;$merchant=5;$connection=7;
    Data::$tables['connection']=[['id'=>$connection,'site_id'=>$site,'merchant_id'=>$merchant,'provider'=>'synthetic',
        'expected_tenant_id'=>'synthetic-tenant','store_id'=>'synthetic-store','enabled'=>1,'sync_interval_minutes'=>60,
        'config_version'=>2,'last_sync_status'=>'completed','last_sync_at'=>200,'last_sync_message'=>'last result',
        'active_run_id'=>0,'published_run_id'=>13,'next_sync_at'=>300,'credentials_cipher'=>'not-a-real-cipher']];
    $base=['site_id'=>$site,'merchant_id'=>$merchant,'connection_id'=>$connection,'config_version'=>2,'trigger_type'=>'scheduled',
        'status'=>'completed','page_count'=>2,'record_count'=>150,'started_at'=>100,'finished_at'=>200,
        'error_code'=>'','error_message'=>'NEVER_RETURN_ACCOUNT_PASSWORD','cursor_json'=>'{"source_total":150,"token":"NEVER_RETURN_TOKEN"}',
        'summary_json'=>'{"raw":"NEVER_RETURN_PAYLOAD"}','create_time'=>90,'update_time'=>200];
    Data::$tables['sync_run']=[];
    for($id=1;$id<=14;$id++)Data::$tables['sync_run'][]=$base+['id'=>$id];
    Data::$tables['sync_run'][13]=array_replace(Data::$tables['sync_run'][13],['status'=>'failed','error_code'=>'auth_required','finished_at'=>201]);
    Data::$tables['sync_run'][11]=array_replace(Data::$tables['sync_run'][11],['status'=>'running','finished_at'=>0]);
    Data::$tables['sync_run'][]=array_replace($base,['id'=>999,'site_id'=>$site+1]);
    Data::$tables['sync_run'][]=array_replace($base,['id'=>998,'merchant_id'=>$merchant+1]);
    Data::$tables['sync_run'][]=array_replace($base,['id'=>997,'connection_id'=>$connection+1]);
    $service=new ConnectionService(new Context($site,101,$merchant));
    $result=$service->get($merchant);$runs=$result['recent_runs'];
    historyCheck(count($runs)===10&&$result['recent_runs_limit']===10,'history is strictly bounded to ten');
    historyCheck($result['recent_runs_total']===14&&$result['recent_runs_has_more']===true,'total and truncation are truthful');
    historyCheck(array_column($runs,'id')===range(14,5),'current site, merchant and connection are all isolated before descending limit');
    historyCheck($runs[0]['status']==='failed'&&$runs[0]['error_code']==='auth_required','failed state retains a recognized safe reason');
    historyCheck(str_contains($runs[0]['error_message'],'重新验证'),'failure provides a locally authored next action');
    historyCheck($runs[1]['is_current_snapshot']&&$runs[1]['complete'],'current complete publication is identified');
    historyCheck(!$runs[3]['is_current_snapshot']&&$runs[3]['complete'],'old completion is not falsely the current snapshot');
    historyCheck($runs[2]['status']==='interrupted'&&$runs[2]['stored_status']==='running'&&!$runs[2]['complete'],'orphaned old runs are not presented as still collecting');
    historyCheck($runs[0]['page_count']===2&&$runs[0]['record_count']===150&&$runs[0]['total_records']===150,'record and source totals are separate facts');
    historyCheck($runs[0]['started_at']===100&&$runs[0]['finished_at']===201&&$runs[0]['create_time']===90,'run timestamps do not masquerade as last publication time');
    $encoded=json_encode($runs);
    historyCheck(!str_contains($encoded,'NEVER_RETURN_')&&!str_contains($encoded,'cursor_json')&&!str_contains($encoded,'summary_json'),'raw provider payload and account details are absent');
    historyCheck(!str_contains(json_encode($result),'NEVER_RETURN_')&&!str_contains($result['last_sync_message'],'last result'),'connection summary and nested progress also strip historical provider diagnostics');
    historyCheck(!array_key_exists('sellable_count',$runs[0])&&!array_key_exists('source_read_count',$runs[0]),'unrecorded aggregates are not fabricated as zero');
    $before=Data::$tables;$service->get($merchant);
    historyCheck(Data::$tables===$before,'reading history never mutates business or run records');
    try{$service->get($merchant+1);throw new \RuntimeException('Expected owner denial');}catch(\RuntimeException $error){historyCheck($error->getMessage()==='Foreign merchant denied','connection read preserves owner authorization');}
    Data::$tables['sync_run'][13]['error_code']='NEVER_RETURN_UNKNOWN_CODE';
    $unknown=$service->get($merchant)['recent_runs'][0];
    historyCheck($unknown['error_code']==='sync_failed'&&!str_contains(json_encode($unknown),'NEVER_RETURN'),'unknown error content falls back safely');
    Data::$tables['sync_run'][13]['cursor_json']='{}';
    $unknownTotal=$service->get($merchant)['recent_runs'][0];
    historyCheck($unknownTotal['total_records']===null&&$unknownTotal['progress_percent']===null,'unknown source total stays unknown');
    Data::$tables['connection'][0]['active_run_id']=12;Data::$tables['connection'][0]['last_sync_status']='running';
    ProviderChannelService::$enabled=false;
    $paused=$service->get($merchant)['recent_runs'][2];
    historyCheck($paused['status']==='paused'&&!$paused['complete'],'closed channels project the active run as paused');
    Data::$tables['sync_run'][11]['config_version']=1;
    $oldConfig=$service->get($merchant)['recent_runs'][2];
    historyCheck($oldConfig['status']==='interrupted'&&!$oldConfig['is_current_configuration'],'old configuration cannot resume as the current run');
    Data::$tables['connection']=[];
    $empty=$service->get($merchant);
    historyCheck($empty['recent_runs']===[]&&$empty['recent_runs_total']===0&&!$empty['recent_runs_has_more'],'unconnected merchant has an explicit empty history');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'ConnectionService get with in-memory site/owner/connection query doubles; no database or ERP requests'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}
