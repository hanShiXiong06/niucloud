<?php
declare(strict_types=1);

if (PHP_SAPI !== 'cli' || !in_array('--isolated-local-mysql', $argv, true)) {
    fwrite(STDERR, "Requires --isolated-local-mysql; creates and removes only its own random localhost schema.\n");
    exit(2);
}
require __DIR__ . '/bootstrap.php';
define('HSX_LEAD_UPGRADE_LIBRARY_ONLY', true);
require dirname(__DIR__) . '/scripts/upgrade.php';

use addon\hsx_lead\scripts\UpgradeCommand;
use think\facade\Db;

function upgradeAssert(bool $condition, string $label): void
{
    if (!$condition) throw new RuntimeException($label);
    echo '[PASS] ' . $label . "\n";
}
function upgradeSnapshot(): string
{
    $data = [];
    foreach (['sys_menu', 'sys_schedule', 'sys_notice', 'sys_config', 'sys_user', 'sys_user_role', 'member', 'hsx_lead_merchant'] as $table) {
        $data[$table] = Db::name($table)->order($table === 'member' ? 'member_id' : ($table === 'sys_user' ? 'uid' : 'id'))->select()->toArray();
    }
    return json_encode($data, JSON_THROW_ON_ERROR);
}
function upgradeTreeHash(string $root): string
{
    $data = [];
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($root, FilesystemIterator::SKIP_DOTS)) as $entry) {
        if ($entry->isFile()) $data[substr($entry->getPathname(), strlen($root))] = hash_file('sha256', $entry->getPathname());
    }
    ksort($data);
    return hash('sha256', json_encode($data));
}
function upgradeRemoveFixture(string $path, string $schema): void
{
    $expected = rtrim((string)realpath(sys_get_temp_dir()), '/') . '/' . $schema . '/upgrade-command';
    if ($path !== $expected || strpos($schema, 'hsx_lead_test_') !== 0) throw new RuntimeException('Refusing unowned fixture removal');
    if (!is_dir($path)) return;
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $entry) {
        if ($entry->isLink() || $entry->isFile()) unlink($entry->getPathname());
        elseif ($entry->isDir()) rmdir($entry->getPathname());
    }
    rmdir($path);
}

$pdo = null; $schema = ''; $fixture = '';
try {
    [$app, $pdo, $schema, $site] = leadBoot();
    leadAssertIsolated($schema);
    $fixture = rtrim((string)realpath(sys_get_temp_dir()), '/') . '/' . $schema . '/upgrade-command';
    $backend = $fixture . '/backend'; $project = $fixture . '/project';
    foreach ([$backend . '/public', $project . '/admin/src/addon', $project . '/uni-app/src/addon/components/diy/group',
        $project . '/uni-app/src/locale'] as $directory) mkdir($directory, 0700, true);
    file_put_contents($project . '/uni-app/src/pages.json', "{\"pages\":[],\"subPackages\":[\n// {{ PAGE_BEGAIN }}\n// {{ PAGE_END }}\n]}\n");
    file_put_contents($project . '/uni-app/src/addon/components/diy/group/index.vue', '<template>fixture</template>');
    file_put_contents($project . '/uni-app/src/locale/zh-Hans.json', '{"fixture":"preserved"}');
    Db::name('sys_menu')->insert(['menu_name' => 'Other addon', 'menu_key' => 'fixture_other', 'app_type' => 'site', 'addon' => 'fixture_other', 'source' => 'system']);
    Db::name('sys_schedule')->insert(['key' => 'hsx_lead_inventory_sync', 'addon' => 'hsx_lead', 'status' => 1,
        'time' => '{"type":"min","min":23}', 'count' => 19, 'last_time' => 1711111111, 'next_time' => 1711112222]);
    Db::name('sys_schedule')->insert(['key' => 'fixture_other', 'addon' => 'fixture_other', 'status' => 1, 'time' => '{}']);
    Db::name('sys_notice')->insert(['site_id' => $site, 'key' => 'hsx_lead_task_assigned', 'is_weapp' => 1,
        'weapp_template_id' => 'fixture_template', 'is_sms' => 1, 'sms_id' => 'fixture_sms']);
    Db::name('sys_config')->insertAll([
        ['site_id' => $site, 'config_key' => 'HSX_LEAD_PROMOTION', 'value' => '{"enabled":false}'],
        ['site_id' => $site, 'config_key' => 'HSX_LEAD_CAPTCHA_2CAPTCHA', 'value' => '{"credentials_cipher":"DO_NOT_BACKUP_SECRET"}'],
    ]);
    $command = new UpgradeCommand(dirname(__DIR__), $backend, $project);
    $beforeDb = upgradeSnapshot(); $beforeFiles = upgradeTreeHash($fixture);
    $report = $command->check();
    upgradeAssert($report['tables'] === 15 && $report['ddl'] === false, 'Preflight recognizes fifteen canonical plugin tables without implicit DDL');
    foreach(['task'=>['uk_site_dedupe'],'attempt'=>['uk_attempt','uk_request'],'preference'=>['uk_preference']]as$table=>$keys){
        $indexes=Db::query('SHOW INDEX FROM `lt_hsx_lead_notice_'.$table.'`');
        foreach($keys as$key)upgradeAssert(count(array_filter($indexes,static fn(array$row):bool=>$row['Key_name']===$key&&(int)$row['Non_unique']===0))>0,'notice runtime unique index is present: '.$table.'.'.$key);
    }
    upgradeAssert(upgradeSnapshot() === $beforeDb && upgradeTreeHash($fixture) === $beforeFiles, '--check does not change database or frontend files');
    upgradeAssert(!file_exists($backend . '/runtime'), '--check creates no backup directory or lock');
    chmod($fixture, 0555);
    try { $command->check(); } finally { chmod($fixture, 0700); }
    upgradeAssert(true, 'Read-only ancestors do not block writable deployment targets');
    mkdir($fixture . '/symlink-target', 0700);
    symlink($fixture . '/symlink-target', $project . '/admin/src/addon/hsx_lead');
    $linked = false;
    try { $command->check(); } catch (RuntimeException $error) { $linked = strpos($error->getMessage(), '符号链接') !== false; }
    unlink($project . '/admin/src/addon/hsx_lead');
    upgradeAssert($linked, 'Symlinked mount rejected before copying or mutation');
    $pdo->exec('RENAME TABLE lt_hsx_lead_promotion_reward TO lt_fixture_reward_hidden');
    $blocked = false;
    try { $command->apply(); } catch (RuntimeException $error) { $blocked = strpos($error->getMessage(), 'hsx_lead_promotion_reward') !== false; }
    upgradeAssert($blocked && !file_exists($backend . '/runtime'), 'Missing reward table blocks --apply before mutation or silent table creation');
    upgradeAssert(Db::query("SHOW TABLES LIKE 'lt_hsx_lead_promotion_reward'") === [], 'Missing table remains missing; updater never creates it');
    $pdo->exec('RENAME TABLE lt_fixture_reward_hidden TO lt_hsx_lead_promotion_reward');
    foreach(['task','attempt','preference']as$table){
        $name='lt_hsx_lead_notice_'.$table;$hidden='lt_fixture_notice_'.$table;
        $pdo->exec('RENAME TABLE `'.$name.'` TO `'.$hidden.'`');$blocked=false;
        try{$command->apply();}catch(RuntimeException$error){$blocked=str_contains($error->getMessage(),'hsx_lead_notice_'.$table)&&str_contains($error->getMessage(),'upgrade-notice-runtime.php');}
        upgradeAssert($blocked&&!file_exists($backend.'/runtime'),'missing notice '.$table.' blocks general updater and names the explicit three-table upgrade');
        upgradeAssert(Db::query('SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=?',[$name])===[],'general updater never implicitly creates missing notice '.$table);
        $pdo->exec('RENAME TABLE `'.$hidden.'` TO `'.$name.'`');
    }
    $existingSchedule = Db::name('sys_schedule')->where('addon', 'hsx_lead')->find();
    $existingNotice = Db::name('sys_notice')->where('site_id', $site)->where('key', 'hsx_lead_task_assigned')->find();
    $otherMenu = Db::name('sys_menu')->where('addon', 'fixture_other')->find();
    $users = Db::name('sys_user')->select()->toArray(); $roles = Db::name('sys_user_role')->select()->toArray();
    $configs = Db::name('sys_config')->select()->toArray();
    mkdir($project . '/uni-app/src/addon/hsx_lead/utils', 0700, true);
    file_put_contents($project . '/uni-app/src/addon/hsx_lead/utils/cooperation-plans.ts', 'retired fixture');
    mkdir($backend . '/addon/hsx_lead/app/service/cooperation', 0700, true);
    file_put_contents($backend . '/addon/hsx_lead/app/service/cooperation/MembershipPlanService.php', '<?php // retired fixture');
    $result = $command->apply();
    upgradeAssert($result['status'] === 'complete' && $result['compile_or_publish'] === false, '--apply completes source and metadata refresh without compile/publish');
    upgradeAssert(Db::name('sys_menu')->where('addon', 'hsx_lead')->count() > 0, 'Plugin menus actually persisted');
    upgradeAssert(Db::name('sys_menu')->where('addon', 'fixture_other')->find() === $otherMenu, 'Other plugin menu unchanged');
    upgradeAssert(Db::name('sys_user')->select()->toArray() === $users && Db::name('sys_user_role')->select()->toArray() === $roles, 'User/password rows and roles unchanged');
    upgradeAssert(Db::name('sys_config')->select()->toArray() === $configs, 'Business and credential configuration unchanged');
    upgradeAssert(Db::name('sys_schedule')->where('id', $existingSchedule['id'])->find() === $existingSchedule, 'Existing enabled schedule, counters and timing preserved');
    upgradeAssert((int)Db::name('sys_schedule')->where('key', 'hsx_lead_promotion_settle')->value('status') === 2, 'New schedule registered OFF');
    upgradeAssert((int)Db::name('sys_schedule')->where('key', 'hsx_lead_unpaid_order_close')->value('status') === 2
        && (int)Db::name('sys_schedule')->where('key', 'hsx_lead_notice_recover')->value('status') === 2, 'Payment and notification recovery schedules registered OFF for deliberate activation');
    upgradeAssert((int)Db::name('sys_schedule')->where('key','hsx_lead_financial_notice_recover')->value('status')===2,'new granular financial-notice recovery schedule is registered OFF and requires deliberate activation');
    upgradeAssert((int)Db::name('sys_schedule')->where('key','hsx_lead_order_refund_reconcile')->value('status')===2,'Original-refund reconciliation schedule is registered OFF without automatically refunding');
    upgradeAssert(Db::name('sys_notice')->where('site_id', $site)->where('key', 'hsx_lead_task_assigned')->find() === $existingNotice, 'Existing notice channels and template identifiers preserved');
    upgradeAssert(Db::name('sys_notice')->where('site_id', $site + 1)->where('is_weapp', 0)->where('is_wechat', 0)->where('is_sms', 0)->count() === 2, 'Missing assigned-site notices inserted with all channels OFF');
    $backup = $result['backup'];
    upgradeAssert(strpos($backup, $backend . '/runtime/') === 0 && (fileperms($backup) & 0777) === 0700, 'Backup private, outside public directory');
    upgradeAssert((fileperms($backup . '/metadata.json') & 0777) === 0600 && strpos((string)file_get_contents($backup . '/metadata.json'), 'DO_NOT_BACKUP_SECRET') === false, 'Backup excludes secret configurations and uses private file permissions');
    upgradeAssert(!file_exists($project . '/uni-app/src/addon/hsx_lead/utils/cooperation-plans.ts') && !file_exists($backend . '/addon/hsx_lead/app/service/cooperation/MembershipPlanService.php'), 'Retired plugin-only source paths are actually removed rather than left callable after directory copy');
    upgradeAssert(is_file($backup . '/files/backend/addon/hsx_lead/app/service/cooperation/MembershipPlanService.php') && is_file($backup . '/files/project/uni-app/src/addon/hsx_lead/utils/cooperation-plans.ts'), 'Retired backend and mounted frontend files were backed up before deletion');
    upgradeAssert(hash_file('sha256', dirname(__DIR__) . '/uni-app/pages/profile/index.vue') === hash_file('sha256', $project . '/uni-app/src/addon/hsx_lead/pages/profile/index.vue'), 'Mobile source copied and SHA256 verified');
    $pages = file_get_contents($project . '/uni-app/src/pages.json');
    upgradeAssert(substr_count($pages, 'HSX_LEAD_PAGE_BEGIN') === 1 && strpos($pages, '"navigationStyle": "custom"') !== false, 'Official pages generator registers plugin routes and custom navigation');
    $after = upgradeSnapshot();
    $repeat = $command->apply();
    // System menu IDs can be regenerated by the official refresh. Compare stable row counts and protected data.
    $expectedSchedules=count(require dirname(__DIR__).'/app/dict/schedule/schedule.php');
    upgradeAssert($repeat['menu_count'] === $result['menu_count'] && Db::name('sys_schedule')->where('addon', 'hsx_lead')->count() === $expectedSchedules
        && Db::name('sys_notice')->count() === 4, 'Repeated --apply creates no duplicate menus, schedules or notices');
    upgradeAssert(Db::name('sys_config')->select()->toArray() === $configs && Db::name('sys_user_role')->select()->toArray() === $roles, 'Repeated update still preserves business settings and roles');
    Db::name('sys_schedule')->where('id', $existingSchedule['id'])->update(['status' => 2]);
    $disabledSchedule = Db::name('sys_schedule')->where('id', $existingSchedule['id'])->find();
    $command->apply();
    upgradeAssert(Db::name('sys_schedule')->where('id', $existingSchedule['id'])->find() === $disabledSchedule, 'Existing disabled schedule remains disabled without timing or counter reset');
    echo "All isolated upgrade checks passed. No existing business schema or deployed source was modified.\n";
} catch (Throwable $error) {
    fwrite(STDERR, '[FAIL] ' . get_class($error) . ': ' . $error->getMessage() . "\n" . $error->getTraceAsString() . "\n");
    $failed = true;
} finally {
    if ($fixture !== '' && $schema !== '') upgradeRemoveFixture($fixture, $schema);
    if ($pdo instanceof PDO && $schema !== '') leadCleanup($pdo, $schema);
}
exit(!empty($failed) ? 1 : 0);
