<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$f)if(function_exists($f))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';
use addon\hsx_lead\app\service\{Context,CatalogService,CatalogConfigStorage};
use addon\hsx_lead\app\service\cooperation\{BusinessService,ConfigService,Store};
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;
$checks=0;$pdo=null;$schema='';$failed=false;
function ccCheck(bool $value,string $label):void{if(!$value)throw new RuntimeException($label);$GLOBALS['checks']++;}
try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);$ctx=new Context($site,1);$settings=new ConfigService($ctx);$catalog=new CatalogService($ctx);
    $initial=$settings->get();$initial['enabled']=true;$initial['fee_confirmed']=true;$settings->save($initial);
    $find=static function(array $config,string $key):array{foreach($config['businesses']as$row)if($row['key']===$key)return$row;throw new RuntimeException('Missing fixture business');};
    $beforeRepair=$find($settings->get(),'repair');$repairOptions=(new BusinessService($ctx))->options($beforeRepair);
    ccCheck($beforeRepair['options']===[]&&!array_key_exists('catalog_configured',$beforeRepair)&&count($repairOptions)>0,'initial unset model directory retains existing shared fallback');
    $catalog->save(['business_type'=>'rent','format'=>'json','content'=>Data::json([['id'=>'A','title'=>'租机A','path'=>['租机','A']]])]);
    $oldPage=$settings->get();$current=$catalog->items(['business_type'=>'rent']);$catalog->add(['business_type'=>'rent','revision'=>$current['revision'],'item'=>['id'=>'B','title'=>'租机B','path'=>['租机','B']]]);
    ccCheck(array_column($catalog->get(['business_type'=>'rent'])['items'],'id')===['A','B'],'second admin creates a new catalog item after first admin loaded settings');
    $paid=(int)Store::query('coop_order',$site)->insertGetId(['site_id'=>$site,'order_no'=>'SYNTHETIC-PAID-KEEP','purpose'=>'commission','lead_id'=>1,'merchant_id'=>1,'member_id'=>101,'business_key'=>'SYNTHETIC-PAID-KEEP','request_id'=>'synthetic-paid-keep','amount'=>'100.00','fee_amount'=>'10.00','net_amount'=>'90.00','status'=>'paid','out_trade_no'=>'SYNTHETIC-RECEIPT','rule_json'=>'{"purpose":"commission"}']);$paidBefore=Store::row('coop_order',$site,$paid);
    $oldPage['response_minutes']=45;$saved=$settings->save($oldPage);
    ccCheck($saved['response_minutes']===45,'ordinary setting change still persists');
    ccCheck(array_column($catalog->get(['business_type'=>'rent'])['items'],'id')===['A','B'],'saving stale settings cannot overwrite another admin catalog addition');
    ccCheck($find($saved,'rent')['catalog_configured']===true,'current independent directory ownership marker survives stale settings save');
    foreach(['A','B']as$id){$current=$catalog->items(['business_type'=>'rent']);$catalog->remove($id,['business_type'=>'rent','revision'=>$current['revision']]);}
    $oldPage['contact_hours']=30;$settings->save($oldPage);
    ccCheck($catalog->get(['business_type'=>'rent'])['items']===[]&&$find($settings->get(),'rent')['catalog_configured']===true,'stale settings cannot resurrect deliberately emptied directory or reset its marker');
    $current=$settings->get();foreach($current['businesses']as&$row){unset($row['options'],$row['catalog_configured']);}unset($row);$saved=$settings->save($current);
    ccCheck($catalog->get(['business_type'=>'rent'])['items']===[],'front-end payload without catalog properties still preserves explicit emptiness');
    $repair=$find($saved,'repair');ccCheck($repair['options']===[]&&!array_key_exists('catalog_configured',$repair)&&(new BusinessService($ctx))->options($repair)===$repairOptions,'unconfigured legacy model directory is not silently marked empty');
    Db::name('sys_user')->insert(['uid'=>2,'username'=>'settings-only','real_name'=>'Settings only','status'=>1]);
    Db::name('sys_role')->insert(['role_id'=>2,'site_id'=>$site,'role_name'=>'Settings only','rules'=>Data::json(['hsx_lead_cooperation_config','hsx_lead_cooperation_config_save']),'status'=>1]);
    Db::name('sys_user_role')->insert(['uid'=>2,'site_id'=>$site,'status'=>1,'is_admin'=>0,'role_ids'=>'[2]']);
    foreach(['hsx_lead_cooperation_config','hsx_lead_cooperation_config_save']as$key)Db::name('sys_menu')->insert(['menu_key'=>$key,'app_type'=>'site','menu_name'=>'Settings','menu_type'=>2,'status'=>1]);
    $limited=new ConfigService(new Context($site,2));$malicious=$limited->get();foreach($malicious['businesses']as&$row)if($row['key']==='rent'){$row['options']=[['id'=>'INJECTED','title'=>'越权目录']];$row['catalog_configured']=false;}unset($row);$malicious['response_minutes']=46;$limited->save($malicious);
    ccCheck($settings->get()['response_minutes']===46&&$catalog->get(['business_type'=>'rent'])['items']===[]&&$find($settings->get(),'rent')['catalog_configured']===true,'settings-only permission cannot bypass catalog write permissions using copied JSON');
    $custom=$settings->get();$new=BusinessService::defaults()[0];$new['key']='custom_fixture';$new['name']='合成自定义业务';$new['dimension']='brand';$new['options']=[['id'=>'UNTRUSTED','title'=>'伪造预设']];$new['catalog_configured']=true;$custom['businesses'][]=$new;$saved=$settings->save($custom);
    ccCheck($find($saved,'custom_fixture')['options']===[]&&!array_key_exists('catalog_configured',$find($saved,'custom_fixture')),'new custom business cannot smuggle an arbitrary initial catalog through settings');
    ccCheck(Store::row('coop_order',$site,$paid)===$paidBefore,'configuration fix performs no paid-order mutation or migration');
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'owned random localhost schema; stale settings/catalog ownership, explicit empty and permission projection; existing paid fixture unchanged','remote_calls'=>0],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable$error){$failed=true;fwrite(STDERR,'FAIL config catalog ownership: '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine()."\n".$error->getTraceAsString()."\n");}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
