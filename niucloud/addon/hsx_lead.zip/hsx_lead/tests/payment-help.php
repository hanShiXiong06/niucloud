<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$function)if(function_exists($function))exit("Disable external HTTP/network functions before testing\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\PaymentHelpService;
use addon\hsx_lead\app\support\Data;
use core\exception\CommonException;
use think\facade\Db;

$pdo=null;$schema='';$failed=false;$checks=0;
function paymentHelpCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function paymentHelpDeny(callable $call,string $label):void{try{$call();}catch(CommonException $error){paymentHelpCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}

try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');
    foreach(['sys_attachment','pay','pay_refund']as$table){
        if(!preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$match))throw new RuntimeException('Missing official fixture DDL');
        $pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$match[0]));
    }
    $admin=new Context($site,1);$member=new Context($site,0,101);$other=new Context($site+1,0,103);
    foreach(['hsx_lead_cooperation_config','hsx_lead_cooperation_config_save']as$key)Db::name('sys_menu')->insert(['menu_key'=>$key,'menu_name'=>'Payment help fixture','app_type'=>'site','status'=>1]);
    foreach([2=>'hsx_lead_cooperation_config',3=>'hsx_lead_cooperation_config_save']as$uid=>$permission){
        Db::name('sys_user')->insert(['uid'=>$uid,'username'=>'help-fixture-'.$uid,'status'=>1]);
        Db::name('sys_role')->insert(['role_id'=>$uid,'site_id'=>$site,'role_name'=>'Isolated permission','rules'=>Data::json([$permission]),'status'=>1]);
        Db::name('sys_user_role')->insert(['uid'=>$uid,'site_id'=>$site,'status'=>1,'is_admin'=>0,'role_ids'=>Data::json([$uid])]);
    }
    $readOnly=new Context($site,2);$saveOnly=new Context($site,3);
    $attachment=static function(int $owner,string $path,string $url='',string $type='image'):int{
        return(int)Db::name('sys_attachment')->insertGetId(['site_id'=>$owner,'path'=>$path,'url'=>$url,'att_type'=>$type]);
    };
    $path='upload/payment-help-fixture/support.png';$url='https://cdn.example.invalid/help/support.png';
    $attachment($site,$path,$url);$foreign='upload/payment-help-fixture/foreign.png';$attachment($site+1,$foreign);
    $private='upload/private/license.png';$attachment($site,$private);
    $chat='upload/payment-help-fixture/chat.jpg';$chatId=$attachment($site,$chat);
    $member->audit('cooperation_attachment',$chatId,'uploaded',[]);
    $attachment($site,'upload/payment-help-fixture/not-image.png','','video');
    $attachment($site,'upload/payment-help-fixture/active.svg');
    $order=(int)Db::name('hsx_lead_coop_order')->insertGetId(['site_id'=>$site,'order_no'=>'HELP_UNPAID','purpose'=>'membership','merchant_id'=>1,'member_id'=>101,'business_key'=>'help-fixture-unpaid','request_id'=>'help-fixture-request','amount'=>'99.00','status'=>'unpaid']);
    Db::name('pay')->insert(['site_id'=>$site,'main_id'=>101,'main_type'=>'member','out_trade_no'=>'HELP_CORE_PENDING','trade_type'=>'hsx_lead_cooperation','trade_id'=>$order,'type'=>'wechatpay','status'=>1,'money'=>'99.00']);
    Db::name('sys_config')->insert(['site_id'=>$site,'config_key'=>'HELP_UNRELATED','value'=>Data::json(['unchanged'=>'unrelated-secret-fixture'])]);
    $protected=['member','member_level','member_account_log','member_cash_out','hsx_lead_merchant','hsx_lead_partner','hsx_lead_coop_order','pay','pay_refund','hsx_lead_promotion_reward','hsx_lead_notice_task','hsx_lead_notice_attempt'];
    $snapshot=static function()use($protected):array{$out=[];foreach($protected as$table)$out[$table]=Db::name($table)->select()->toArray();return$out;};
    $before=$snapshot();$tables=Db::query('SHOW TABLES');
    $defaults=PaymentHelpService::get($admin,true);
    paymentHelpCheck($defaults===PaymentHelpService::defaults()&&!$defaults['enabled']&&$defaults['qr_image']==='','admin initially sees an explicit disabled default without sample QR or billing data');
    $hidden=['enabled'=>false,'title'=>'','content'=>'','qr_image'=>'','remark'=>''];
    paymentHelpCheck(PaymentHelpService::get($member)===$hidden,'mobile starts hidden, not with an invented customer-support address');
    paymentHelpCheck(Db::name('sys_config')->where('config_key',PaymentHelpService::KEY)->count()===0,'reading defaults does not create persistent rows');
    $settings=['enabled'=>true,'title'=>'付款问题咨询','content'=>"支付遇到问题？请联系客服核对。\n联系时提供订单号。",'qr_image'=>$url,'remark'=>'添加好友请备注您的订单号'];
    $saved=PaymentHelpService::save($admin,$settings);$canonical=array_replace($settings,['qr_image'=>$path]);
    paymentHelpCheck($saved===$canonical,'registered URL resolves to the canonical current-site relative image path');
    paymentHelpCheck(PaymentHelpService::get($member)===$canonical,'authenticated member sees the authoritative saved help configuration');
    paymentHelpCheck(PaymentHelpService::get($readOnly,true)===$canonical,'read permission exposes configuration without granting save');
    paymentHelpCheck(PaymentHelpService::get($other)===$hidden,'another site never receives this site contact image or editing content');
    paymentHelpDeny(fn()=>PaymentHelpService::get($member,true),'member cannot read the administrative endpoint');
    paymentHelpDeny(fn()=>PaymentHelpService::save($member,$settings),'member cannot change customer-service configuration');
    paymentHelpDeny(fn()=>PaymentHelpService::save($readOnly,$settings),'configuration read permission does not imply save permission');
    paymentHelpDeny(fn()=>PaymentHelpService::get($saveOnly,true),'configuration save permission does not imply read permission');
    paymentHelpCheck(PaymentHelpService::save($saveOnly,$settings)===$canonical,'save endpoint does not wrongly require an additional read permission');
    paymentHelpDeny(fn()=>PaymentHelpService::get(new Context($site+1,0,101)),'forged same member id in another site cannot read contact data');
    paymentHelpDeny(fn()=>PaymentHelpService::get($admin),'administrator identity is not substituted for mobile member authentication');
    paymentHelpDeny(fn()=>PaymentHelpService::get(new Context($site+1,1),true),'administrator without this site role cannot read another site configuration');
    $audit=Db::name('hsx_lead_audit')->where('site_id',$site)->where('entity_type','payment_help_config')->order('id desc')->find();
    $safe=Data::decode($audit['detail_json']);
    paymentHelpCheck((int)$audit['operator_uid']===3&&$safe['enabled']===true&&$safe['has_qr_image']===true,'audit records the actual approver context and safe shape information');
    foreach([$settings['title'],$settings['content'],$settings['remark'],$path,$url]as$secret)paymentHelpCheck(!str_contains($audit['detail_json'],$secret),'audit does not duplicate support content, contact remark or QR location');
    $disabled=PaymentHelpService::save($admin,array_replace($canonical,['enabled'=>false]));
    paymentHelpCheck(PaymentHelpService::get($member)===$hidden,'disabling hides every retained mobile text and image field');
    paymentHelpCheck(PaymentHelpService::get($admin,true)===$disabled&&$disabled['content']===$canonical['content'],'administrator can edit retained disabled contact content');
    PaymentHelpService::save($admin,$canonical);
    // Invoke the real controllers, not an imitation response or a test HTTP
    // server. Identity is assigned by the authenticated request context only.
    $request=static function(int $uid,int $memberId,array $input=[],string $method='GET',?int $identitySite=null)use($app,$site):void{
        $auth=new ReflectionProperty(\app\Request::class,'auth_info');$auth->setAccessible(true);$auth->setValue(null,[]);
        $request=new \app\Request();$request->siteId($identitySite??$site);$request->uid($uid);$request->memberId($memberId);
        $request->appType($uid>0?'site':'api');$request->withServer(['REQUEST_METHOD'=>$method]);
        if($method==='PUT')$request->withHeader(['content-type'=>'application/json'])->withInput(Data::json($input));
        else $request->withGet($input);
        $app->instance('request',$request);
    };
    $request(2,0,['section'=>'payment_help','site_id'=>$site+1,'member_id'=>103]);
    $response=(new \addon\hsx_lead\app\adminapi\controller\Cooperation($app))->config();
    paymentHelpCheck($response->getData()['data']===$canonical,'real admin config section returns only five help fields from authenticated site identity');
    paymentHelpCheck($response->getHeader('Cache-Control')==='private, no-store','real admin config response is explicitly non-cacheable');
    paymentHelpCheck(!str_contains(json_encode($response->getData()),'unrelated-secret-fixture'),'admin payment-help section does not expose unrelated private configuration');
    $request(3,0,$canonical+['section'=>'payment_help'],'PUT');
    $response=(new \addon\hsx_lead\app\adminapi\controller\Cooperation($app))->saveConfig();
    paymentHelpCheck($response->getData()['data']===$canonical&&$response->getHeader('Cache-Control')==='private, no-store','real save controller removes its section selector and returns authoritative non-cacheable data with save-only permission');
    $request(2,0,$canonical+['section'=>'payment_help'],'PUT');
    paymentHelpDeny(fn()=>(new \addon\hsx_lead\app\adminapi\controller\Cooperation($app))->saveConfig(),'real admin save route enforces save permission independently of read permission');
    $request(3,0,['section'=>'payment_help']);
    paymentHelpDeny(fn()=>(new \addon\hsx_lead\app\adminapi\controller\Cooperation($app))->config(),'real admin read route enforces read permission independently of save permission');
    $request(3,0,$canonical+['section'=>'payment_help','site_id'=>$site+1],'PUT');
    paymentHelpDeny(fn()=>(new \addon\hsx_lead\app\adminapi\controller\Cooperation($app))->saveConfig(),'admin save cannot use a submitted site_id to change another site');
    $request(0,101,['site_id'=>$site+1,'member_id'=>103,'section'=>'erp_channels']);
    $response=(new \addon\hsx_lead\app\api\controller\Cooperation($app))->paymentHelp();
    paymentHelpCheck($response->getData()['data']===$canonical&&$response->getHeader('Cache-Control')==='private, no-store','real mobile help action ignores injected site/member/section and uses authenticated context with no-store');
    paymentHelpCheck(!str_contains(json_encode($response->getData()),'unrelated-secret-fixture'),'mobile action cannot disclose unrelated private configuration');
    $request(0,103,['site_id'=>$site,'member_id'=>101], 'GET',$site+1);
    paymentHelpCheck((new \addon\hsx_lead\app\api\controller\Cooperation($app))->paymentHelp()->getData()['data']===$hidden,'other-site mobile identity cannot retrieve this site help via request parameters');
    $request(0,0,['site_id'=>$site,'member_id'=>101]);
    paymentHelpDeny(fn()=>(new \addon\hsx_lead\app\api\controller\Cooperation($app))->paymentHelp(),'a guest cannot forge mobile identity through member_id parameters');
    PaymentHelpService::save($admin,array_replace($canonical,['enabled'=>false]));
    $request(0,101);
    $response=(new \addon\hsx_lead\app\api\controller\Cooperation($app))->paymentHelp();
    paymentHelpCheck($response->getData()['data']===$hidden&&$response->getHeader('Cache-Control')==='private, no-store','disabled mobile response remains no-store and never returns retained QR/text');
    PaymentHelpService::save($admin,$canonical);
    $route=file_get_contents(dirname(__DIR__).'/app/api/route/cooperation.php');
    paymentHelpCheck(str_contains($route,"Route::get('payment-help',\$c.'paymentHelp')")&&str_contains($route,'->middleware(ApiCheckToken::class,true)'),'payment-help is registered inside the authenticated mobile group, not the public visitor action');
    $auditBefore=Db::name('hsx_lead_audit')->where('entity_type','payment_help_config')->count();
    $invalid=[
        ['enabled'=>null],['enabled'=>'false'],['title'=>str_repeat('字',41)],['content'=>str_repeat('字',601)],['remark'=>str_repeat('字',121)],
        ['title'=>[]],['content'=>123],['remark'=>true],['content'=>'<img src=x onerror=alert(1)>'],['title'=>'&#60;script&#62;'],['content'=>"text\0secret"],['title'=>"多\n行"],
        ['qr_image'=>str_repeat('x',1001)],['qr_image'=>[]],['qr_image'=>$foreign],['qr_image'=>$private],['qr_image'=>$chat],['qr_image'=>'upload/payment-help-fixture/not-image.png'],['qr_image'=>'upload/payment-help-fixture/active.svg'],
        ['qr_image'=>'javascript:alert(1)'],['qr_image'=>'data:image/png;base64,AA'],['qr_image'=>'//cdn.example.invalid/help/support.png'],['qr_image'=>'https://other.invalid/support.png'],['qr_image'=>$url.'?token=secret'],['qr_image'=>$url.'#fragment'],['qr_image'=>'https://user:pass@cdn.example.invalid/help/support.png'],
        ['qr_image'=>'upload/../support.png'],['qr_image'=>'upload/%2e%2e/support.png'],['qr_image'=>'upload/%252e%252e/support.png'],['qr_image'=>'upload\\support.png'],['qr_image'=>'upload//support.png'],['qr_image'=>'storage/private/support.png'],
        ['enabled'=>true,'content'=>''],['enabled'=>true,'qr_image'=>''],['site_id'=>$site+1],['status'=>'paid'],['amount'=>'0.01'],
    ];
    foreach($invalid as$index=>$bad){
        paymentHelpDeny(fn()=>PaymentHelpService::save($admin,array_replace($canonical,$bad)),'unsafe, oversized, cross-site, private or financial payload #'.$index);
        paymentHelpCheck(PaymentHelpService::get($admin,true)===$canonical,'invalid save preserves the previous persisted configuration #'.$index);
    }
    paymentHelpCheck(Db::name('hsx_lead_audit')->where('entity_type','payment_help_config')->count()===$auditBefore,'rejected updates do not produce success audit records');
    $max=array_replace($canonical,['title'=>str_repeat('字',40),'content'=>str_repeat('字',600),'remark'=>str_repeat('字',120),'qr_image'=>'/'.$path]);
    $boundary=PaymentHelpService::save($admin,$max);
    paymentHelpCheck($boundary['title']===$max['title']&&$boundary['content']===$max['content']&&$boundary['remark']===$max['remark']&&$boundary['qr_image']===$path,'multibyte field limits and leading-slash canonical normalization are exact');
    PaymentHelpService::save($admin,$canonical);
    Db::name('member')->where('member_id',101)->update(['status'=>0]);paymentHelpDeny(fn()=>PaymentHelpService::get($member),'disabled member cannot use the authenticated help endpoint');Db::name('member')->where('member_id',101)->update(['status'=>1]);
    $pdo->exec("CREATE TRIGGER help_forced_failure BEFORE UPDATE ON lt_sys_config FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='PRIVATE_SYNTHETIC_SQL_DETAIL'");
    try{
        PaymentHelpService::save($admin,array_replace($canonical,['title'=>'不得保存']));throw new RuntimeException('Expected isolated write failure');
    }catch(CommonException $error){paymentHelpCheck(str_contains($error->getMessage(),'未保存')&&!str_contains($error->getMessage(),'PRIVATE_'),'persistence error is actionable and never exposes raw SQL or private data');}
    finally{$pdo->exec('DROP TRIGGER help_forced_failure');}
    paymentHelpCheck(PaymentHelpService::get($admin,true)===$canonical,'failed persistence retains the last committed help configuration');
    $pdo->exec("CREATE TRIGGER help_forced_audit_failure BEFORE INSERT ON lt_hsx_lead_audit FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='PRIVATE_SYNTHETIC_AUDIT_DETAIL'");
    try{
        PaymentHelpService::save($admin,array_replace($canonical,['title'=>'不可缺少审计']));throw new RuntimeException('Expected isolated audit failure');
    }catch(CommonException $error){paymentHelpCheck(str_contains($error->getMessage(),'未保存')&&!str_contains($error->getMessage(),'PRIVATE_'),'audit failure cannot report success or expose database internals');}
    finally{$pdo->exec('DROP TRIGGER help_forced_audit_failure');}
    paymentHelpCheck(PaymentHelpService::get($admin,true)===$canonical,'audit failure rolls back configuration and success audit atomically');
    paymentHelpCheck(Db::name('sys_config')->where('site_id',$site)->where('config_key',PaymentHelpService::KEY)->count()===1,'repeated saves never create duplicate configuration rows');
    Db::name('sys_attachment')->where('site_id',$site)->where('path',$path)->delete();
    paymentHelpDeny(fn()=>PaymentHelpService::get($member),'removed image cannot be exposed as a valid enabled QR');
    // An obsolete attachment must not lock the administrative editor out of
    // replacing or disabling the entry. Read-back is a repairable draft only;
    // it must never make an incomplete enabled entry public or valid to save.
    $repairable=array_replace($canonical,['qr_image'=>'']);
    paymentHelpCheck(PaymentHelpService::get($admin,true)===$repairable,'admin can read a five-field repair draft after the registered QR is deleted');
    paymentHelpCheck(PaymentHelpService::get($readOnly,true)===$repairable,'read-only admin sees repairable text without the obsolete QR');
    paymentHelpDeny(fn()=>PaymentHelpService::save($admin,$repairable),'incomplete enabled repair draft still cannot bypass strict save validation');
    paymentHelpDeny(fn()=>PaymentHelpService::get($member),'admin repair read does not mutate or publish the incomplete retained configuration');
    foreach([$foreign,$private,$chat]as$unsafeQr){
        Db::name('sys_config')->where('site_id',$site)->where('config_key',PaymentHelpService::KEY)->update(['value'=>Data::json(array_replace($canonical,['qr_image'=>$unsafeQr]))]);
        paymentHelpCheck(PaymentHelpService::get($admin,true)===$repairable,'administrative repair draft never exposes foreign, private or business-evidence images');
        paymentHelpDeny(fn()=>PaymentHelpService::get($member),'unsafe retained attachment remains fail-closed for mobile members');
    }
    $disabledRepair=PaymentHelpService::save($admin,array_replace($repairable,['enabled'=>false]));
    paymentHelpCheck($disabledRepair===array_replace($repairable,['enabled'=>false])&&PaymentHelpService::get($member)===$hidden,'administrator can disable an invalid attachment entry while retaining editable text');
    $replacement='upload/payment-help-fixture/replacement.png';$attachment($site,$replacement);
    $repaired=PaymentHelpService::save($admin,array_replace($canonical,['qr_image'=>$replacement]));
    paymentHelpCheck(PaymentHelpService::get($member)===$repaired,'replacing the obsolete QR restores the actual enabled member entry');
    PaymentHelpService::save($admin,['enabled'=>false]);
    paymentHelpCheck(PaymentHelpService::get($member)===$hidden,'administrator can explicitly disable and clear an obsolete contact configuration');
    paymentHelpCheck($snapshot()===$before,'help configuration never changes payment, refund, membership, balance, promotion or notification facts');
    paymentHelpCheck(Data::decode(Db::name('sys_config')->where('config_key','HELP_UNRELATED')->value('value'))===['unchanged'=>'unrelated-secret-fixture'],'unrelated configuration remains untouched');
    paymentHelpCheck(Db::query('SHOW TABLES')===$tables,'feature neither creates tables nor changes the application schema');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'payment-help configuration only; owned random localhost schema; registered synthetic image references; no uploads, external calls, payments, refunds or messages'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable $error){$failed=true;fwrite(STDERR,'FAIL payment help after '.$checks.': '.get_class($error).' '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
