<?php
declare(strict_types=1);
error_reporting(E_ALL & ~E_DEPRECATED);
if(PHP_SAPI!=='cli'||!in_array('--isolated-local-mysql',$argv,true))exit("Requires --isolated-local-mysql\n");
foreach(['curl_exec','curl_multi_exec','fsockopen','pfsockopen','stream_socket_client','socket_connect']as$function)if(function_exists($function))exit("Disable external network functions\n");
if(filter_var(ini_get('allow_url_fopen'),FILTER_VALIDATE_BOOLEAN))exit("Disable allow_url_fopen\n");
require __DIR__.'/bootstrap.php';require __DIR__.'/membership-fixtures.php';

use addon\hsx_lead\app\service\Context;
use addon\hsx_lead\app\service\cooperation\{ManualPaymentService,ConfigService,PartnerService,PaymentService,EntityMembershipService,PaymentOrderLifecycle,Store,MembershipCostService,CooperationService,CapabilityService};
use addon\hsx_lead\app\support\Data;
use addon\hsx_lead\app\listener\pay\{CooperationPayCreate,CooperationPaySuccess};
use app\dict\pay\{PayDict,OnlinePayDict};
use core\exception\CommonException;
use think\facade\{Db,Event};

final class ManualSyntheticProvider
{
    public array $calls=[];
    public function __construct(private array $answers){}
    public function getOrder(string $number):array{$this->calls[]='query';return array_shift($this->answers)??['status'=>'UNKNOWN'];}
    public function close(string $number):bool{$this->calls[]='close';return true;}
}
$pdo=null;$schema='';$checks=0;$failed=false;
function manualCheck(bool $ok,string $label):void{if(!$ok)throw new RuntimeException($label);$GLOBALS['checks']++;}
function manualDeny(callable $operation,string $label):void{try{$operation();}catch(CommonException $error){manualCheck(true,$label);return;}throw new RuntimeException('Not denied: '.$label);}

/** Independent workers receive only the owned random schema over private
 * stdin. They never load a configured business database or clean parent data. */
function manualWorker():void
{
    try{
        $payload=json_decode((string)fgets(STDIN,131072),true,32,JSON_THROW_ON_ERROR);$schema=$payload['schema']??'';$database=$payload['database']??[];$connection=$database['connections']['mysql']??[];
        if(!is_string($schema)||!preg_match('/^hsx_lead_test_[a-f0-9]{16}$/D',$schema)||($database['default']??'')!=='mysql'||($connection['hostname']??'')!=='127.0.0.1'||($connection['database']??'')!==$schema||($connection['prefix']??'')!=='lt_'||!empty($connection['deploy'])||(int)($payload['site']??0)!==900000031||!in_array($payload['uid']??0,[1,3],true))throw new RuntimeException('Unsafe owned worker configuration');
        $root=dirname(__DIR__,3);require_once$root.'/vendor/autoload.php';$app=new \think\App($root);require_once$app->getThinkPath().'helper.php';require_once$root.'/app/common.php';
        $app->config->set($database,'database');$app->config->set(['default'=>'file','stores'=>['file'=>['type'=>'File','path'=>sys_get_temp_dir().'/'.$schema.'/cache/']]],'cache');$app->config->set(['default'=>'file','channels'=>['file'=>['type'=>'File','path'=>sys_get_temp_dir().'/'.$schema.'/log/']]],'log');$app->env->set('app.auth_key',$payload['auth_key']);$app->env->set('queue.state',false);$app->instance('request',new \app\Request());request()->siteId($payload['site']);request()->uid($payload['uid']);request()->appType('site');$manager=new \think\DbManager();$manager->setConfig($database);$app->instance('think\DbManager',$manager);$GLOBALS['hsx_lead_test_owned_schema']=$schema;leadAssertIsolated($schema);
        Event::listen('PayCreate',CooperationPayCreate::class);Event::listen('PaySuccess',CooperationPaySuccess::class);
        echo json_encode(['phase'=>'ready','connection_id'=>(int)Db::query('SELECT CONNECTION_ID() AS id')[0]['id']]).PHP_EOL;fflush(STDOUT);
        if(trim((string)fgets(STDIN))!=='GO')throw new RuntimeException('Start barrier missing');echo json_encode(['phase'=>'attempting']).PHP_EOL;fflush(STDOUT);
        try{$receipt=(new ManualPaymentService(new Context($payload['site'],$payload['uid'])))->confirm((int)$payload['order_id'],$payload['input']);$answer=['accepted'=>true,'receipt_id'=>$receipt['id'],'status'=>$receipt['status'],'message'=>$receipt['message']];}
        catch(CommonException $error){$answer=['accepted'=>false,'reason'=>$error->getMessage()];}
        if(($answer['status']??'')==='attention'){$app->log->save();$logs=[];$base=sys_get_temp_dir().'/'.$schema.'/log/';if(is_dir($base)){foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base,FilesystemIterator::SKIP_DOTS))as$file)if($file->isFile())$logs[]=substr((string)file_get_contents($file->getPathname()),-3000);}$answer['diagnostic']=$logs;}
        leadAssertIsolated($schema);echo json_encode(['phase'=>'result']+$answer,JSON_UNESCAPED_UNICODE).PHP_EOL;fflush(STDOUT);exit(0);
    }catch(Throwable $error){fwrite(STDERR,'Isolated manual worker failed: '.get_class($error).' '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);exit(2);}
}
if(in_array('--manual-worker',$argv,true))manualWorker();

function manualWorkerLine(array &$worker):array
{
    $deadline=microtime(true)+15;
    while(microtime(true)<$deadline){
        if(($position=strpos($worker['buffer'],"\n"))!==false){$line=substr($worker['buffer'],0,$position);$worker['buffer']=substr($worker['buffer'],$position+1);$value=json_decode($line,true,32,JSON_THROW_ON_ERROR);if(!is_array($value))throw new RuntimeException('Invalid worker response');return$value;}
        $read=[$worker['pipes'][1]];$write=null;$except=null;if(stream_select($read,$write,$except,0,200000)===false)throw new RuntimeException('Worker pipe failure');
        if($read)$worker['buffer'].=(string)fread($worker['pipes'][1],65536);
        if(!proc_get_status($worker['process'])['running']&&strpos($worker['buffer'],"\n")===false)throw new RuntimeException('Worker exited before bounded response: '.substr((string)stream_get_contents($worker['pipes'][2]),0,2000));
    }throw new RuntimeException('Worker exceeded bounded response deadline');
}

function manualPair($app,PDO $pdo,string $schema,int $site,array $jobs):array
{
    $children=[];$results=[];leadAssertIsolated($schema);
    try{
        $pdo->beginTransaction();$statement=$pdo->prepare('SELECT site_id FROM lt_site WHERE site_id=? FOR UPDATE');$statement->execute([$site]);$statement->fetchColumn();$statement->closeCursor();
        foreach($jobs as$job){$pipes=[];$process=proc_open([PHP_BINARY,'-d','allow_url_fopen=0','-d','disable_functions=curl_exec,curl_multi_exec,fsockopen,pfsockopen,stream_socket_client,socket_connect',__FILE__,'--isolated-local-mysql','--manual-worker'],[['pipe','r'],['pipe','w'],['pipe','w']],$pipes);if(!is_resource($process))throw new RuntimeException('Could not create isolated child');foreach([1,2]as$index)stream_set_blocking($pipes[$index],false);$children[]=['process'=>$process,'pipes'=>$pipes,'buffer'=>''];$payload=$job+['schema'=>$schema,'database'=>$app->config->get('database'),'auth_key'=>(string)$app->env->get('app.auth_key'),'site'=>$site];fwrite($pipes[0],json_encode($payload,JSON_THROW_ON_ERROR).PHP_EOL);fflush($pipes[0]);}
        $connections=[];foreach($children as&$child){$ready=manualWorkerLine($child);manualCheck(($ready['phase']??'')==='ready','independent financial worker reached its owned schema barrier');$connections[]=$ready['connection_id'];}unset($child);manualCheck(count(array_unique($connections))===count($jobs),'financial workers use distinct live MySQL connections');
        foreach($children as$child){fwrite($child['pipes'][0],"GO\n");fflush($child['pipes'][0]);}
        foreach($children as&$child){manualCheck((manualWorkerLine($child)['phase']??'')==='attempting','both workers have started the unmodified confirm operation');}unset($child);
        $pdo->commit();foreach($children as&$child){$answer=manualWorkerLine($child);manualCheck(($answer['phase']??'')==='result','concurrent operation returned a bounded result');$results[]=$answer;}unset($child);
    }finally{if($pdo->inTransaction())$pdo->rollBack();foreach($children as$child){foreach($child['pipes']as$pipe)if(is_resource($pipe))fclose($pipe);if(proc_get_status($child['process'])['running'])proc_terminate($child['process']);proc_close($child['process']);}}
    return$results;
}

try{
    [$app,$pdo,$schema,$site]=leadBoot();leadAssertIsolated($schema);leadMembershipSeed($site);
    $official=file_get_contents(dirname(__DIR__,3).'/app/install/source/database.sql');foreach(['pay','pay_refund']as$table){preg_match('/CREATE TABLE\s+`'.$table.'`\s*\(.*?\)\s*ENGINE\s*=\s*InnoDB[^;]*;/si',$official,$matches);$pdo->exec(str_replace('CREATE TABLE `'.$table.'`','CREATE TABLE `lt_'.$table.'`',$matches[0]));}
    $admin=new Context($site,1);$owner=new Context($site,0,101);$other=new Context($site,0,102);
    $settings=new ConfigService($admin);$config=$settings->get();$config['enabled']=true;$config['publishing_required']=false;$config['fee_confirmed']=true;$settings->save($config);
    $profile=['name'=>'Actual receipt synthetic shop','contact_name'=>'Synthetic owner','mobile'=>'19900000101','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'address'=>'Isolated address'];
    $merchant=(new PartnerService($owner))->saveProfile($profile);$otherMerchant=(new PartnerService($other))->saveProfile(array_replace($profile,['name'=>'Synthetic other shop','mobile'=>'19900000102']));
    Event::listen('PayCreate',CooperationPayCreate::class);Event::listen('PaySuccess',CooperationPaySuccess::class);
    $manual=new ManualPaymentService($admin);
    $newMembership=static function(Context $payer,string $suffix,string $code='ML701',bool $buy=false)use($site):array{
        $quote=(new EntityMembershipService($payer))->quote($code,'month',$buy);if(!$quote['can_purchase'])throw new RuntimeException('Fixture cannot purchase: '.$quote['reason']);
        return(new PaymentService($payer))->createOrder(['purpose'=>'membership','request_id'=>'manual-fixture-'.$suffix,'level_code'=>$code,'cycle'=>'month','buy_experience'=>$buy,'quote_token'=>$quote['quote_token']]);
    };
    $payload=static function(array $order,string $suffix,?string $amount=null)use($manual):array{
        $preview=$manual->preview((int)$order['id']);return['request_id'=>'manual-confirm-'.$suffix,'amount'=>$amount??$preview['order_amount'],'confirm'=>true,'expected_fingerprint'=>$preview['source_fingerprint']];
    };
    $original=$newMembership($owner,'normal');$beforeMember=Db::name('member')->where('member_id',101)->find();$preview=$manual->preview((int)$original['id']);
    manualCheck($preview['default_amount']==='99.00'&&$preview['order_amount']==='19.00'&&!$preview['amount_matches']&&$preview['can_confirm']&&count($preview['methods'])===1,'compact preview defaults input to 99 but separately displays the exact unchanged order amount');
    manualCheck($preview['payer']['member_id']===101&&$preview['payer']['mobile']==='19900000101','receipt preview identifies the original payer, never the current financial administrator');
    manualCheck(Db::name('hsx_lead_manual_receipt')->count()===0&&Db::name('pay')->count()===0,'preview creates no receipt, cashier or money movement');
    manualDeny(fn()=>(new ManualPaymentService($owner))->preview((int)$original['id']),'member cannot impersonate financial administrator');
    manualDeny(fn()=>(new ManualPaymentService(new Context($site+1,1)))->confirm((int)$original['id'],$payload($original,'cross')),'another site cannot confirm this order');
    $input=$payload($original,'normal');$posted=$manual->confirm((int)$original['id'],$input);
    manualCheck($posted['status']==='posted'&&$posted['order']['status']==='paid'&&$posted['order']['amount']==='19.00'&&$posted['order_id']===$posted['target_order_id'],'one operator action funds and pays the unchanged original order through the framework balance driver');
    $core=Db::name('pay')->where('out_trade_no',$posted['out_trade_no'])->find();$paid=Store::row('coop_order',$site,(int)$original['id']);
    manualCheck($core['type']===PayDict::BALANCEPAY&&(int)$core['status']===(int)PayDict::STATUS_FINISH&&$core['trade_no']===$posted['registration_no'],'core payment truth records balance payment and an internal operation registration, not a fake WeChat trade reference');
    manualCheck($posted['settlement_mode']===ManualPaymentService::BALANCE_MODE&&$posted['recharge_log_id']>0&&$posted['debit_log_id']>0&&$posted['recharge_log_id']!==$posted['debit_log_id'],'typed receipt references two independent real framework account logs');
    ManualPaymentService::assertPaymentReceipt($site,$paid,$core);manualCheck(true,'normal hook is backed by exact typed receipt proof');
    manualCheck(EntityMembershipService::state($site,(int)$merchant['id'])['active'],'formal receipt activates the existing subject entitlement ledger');
    $afterMember=Db::name('member')->where('member_id',101)->find();
    manualCheck($afterMember['balance']===$beforeMember['balance']&&$afterMember['member_level']===$beforeMember['member_level']&&$afterMember['balance_get']==='19.00','real recharge and consumption preserve the original balance and personal level while recording actual total recharged funds');
    $walletLogs=Db::name('member_account_log')->whereIn('id',[$posted['recharge_log_id'],$posted['debit_log_id']])->order('id')->select()->toArray();
    manualCheck($walletLogs[0]['account_data']==='19.00'&&$walletLogs[1]['account_data']==='-19.00'&&$walletLogs[0]['from_type']===ManualPaymentService::RECHARGE_TYPE&&$walletLogs[1]['from_type']==='order','the positive recharge and negative order consumption use the framework account ledger with correct signs');
    $count=Db::name('hsx_lead_manual_receipt')->count();$pays=Db::name('pay')->count();
    manualCheck($manual->confirm((int)$original['id'],$input)['id']===$posted['id']&&$manual->retry($posted['id'])['status']==='posted'&&Db::name('pay')->count()===$pays&&Db::name('hsx_lead_manual_receipt')->count()===$count,'duplicate confirmation and retry return the same once-only posted receipt');
    manualDeny(fn()=>$manual->confirm((int)$original['id'],array_replace($input,['amount'=>'99.00'])),'same request cannot silently change real received amount');
    $normalRead=$manual->read($posted['id']);manualCheck($normalRead['external_no']===''&&$normalRead['registration_no']!==''&&!isset($normalRead['snapshot_json']),'new financial view labels only an internal registration and does not invent an external WeChat transaction');
    $otherOrder=$newMembership($other,'unknown');$unknownInput=$payload($otherOrder,'unknown');
    $no='MANUAL_OLD_UNKNOWN';Db::name('pay')->insert(['site_id'=>$site,'main_type'=>PayDict::MEMBER,'main_id'=>102,'out_trade_no'=>$no,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$otherOrder['id'],'money'=>$otherOrder['amount'],'type'=>PayDict::WECHATPAY,'channel'=>'weapp','status'=>PayDict::STATUS_ING]);
    $unknownProvider=new ManualSyntheticProvider([['status'=>'UNKNOWN']]);$uncertain=(new ManualPaymentService($admin,fn()=>$unknownProvider))->confirm((int)$otherOrder['id'],$unknownInput);
    manualCheck($uncertain['status']==='attention'&&$uncertain['order']['status']==='unpaid'&&$unknownProvider->calls===['query'],'unknown old online payment retains actual offline money evidence without a second successful charge');
    manualDeny(fn()=>(new PaymentService($other))->assertPayable((int)$otherOrder['id']),'pending real offline receipt blocks the user from another online payment');
    manualDeny(fn()=>$manual->confirm((int)$otherOrder['id'],array_replace($unknownInput,['request_id'=>$input['request_id']])),'the same confirmed request cannot be reused for another order');
    $closedProvider=new ManualSyntheticProvider([['status'=>OnlinePayDict::NOTPAY],['status'=>OnlinePayDict::CLOSED]]);
    $recovered=(new ManualPaymentService($admin,fn()=>$closedProvider))->retry($uncertain['id']);
    manualCheck($recovered['status']==='posted'&&$closedProvider->calls===['query','close','query'],'retry reconciles the same old online order before formal offline posting');
    manualCheck((int)Db::name('pay')->where('out_trade_no',$no)->value('status')===(int)PayDict::STATUS_CANCEL,'old online cashier is proved closed, not simply overwritten to offline');
    $renew=$newMembership($owner,'discount');$discountInput=$payload($renew,'discount','29.00');$beforeMismatch=Db::name('hsx_lead_manual_receipt')->count();$beforeMismatchOrder=Store::row('coop_order',$site,(int)$renew['id']);
    manualDeny(fn()=>$manual->confirm((int)$renew['id'],$discountInput),'actual amount differing from the order cannot silently reprice or partially pay the order');
    manualCheck(Db::name('hsx_lead_manual_receipt')->count()===$beforeMismatch&&Store::row('coop_order',$site,(int)$renew['id'])===$beforeMismatchOrder,'amount mismatch creates no receipt, wallet entry, replacement order or original-order mutation');
    manualDeny(fn()=>$manual->preview((int)$renew['id'],['site_id'=>$site+1]),'preview rejects supplied tenant identity instead of treating it as a filter');
    (new PaymentOrderLifecycle($admin))->close((int)$renew['id'],['confirm'=>true,'reason'=>'隔离测试结束关闭未付款'],true);
    $closed=$newMembership($owner,'closed');(new PaymentOrderLifecycle($admin))->close((int)$closed['id'],['confirm'=>true,'reason'=>'合成测试关闭未付款'],true);
    $closedBefore=Store::row('coop_order',$site,(int)$closed['id']);$beforeClosed=Db::name('hsx_lead_manual_receipt')->count();$closedOrderCount=Store::query('coop_order',$site)->count();
    manualCheck(!$manual->preview((int)$closed['id'])['can_confirm'],'closed order preview permits no collection action');
    manualDeny(fn()=>$manual->confirm((int)$closed['id'],$payload($closed,'closed')),'closed order cannot receive money or be reopened or replaced');
    manualCheck(Store::row('coop_order',$site,(int)$closed['id'])===$closedBefore&&Db::name('hsx_lead_manual_receipt')->count()===$beforeClosed&&Store::query('coop_order',$site)->count()===$closedOrderCount,'closed confirmation refusal leaves the order, receipt count and purchase count unchanged');
    $expired=$newMembership($owner,'expired');$expiredRule=Data::decode(Store::row('coop_order',$site,(int)$expired['id'])['rule_json']);$expiredRule['quoted_at']=time()-700;
    Store::query('coop_order',$site)->where('id',$expired['id'])->update(['rule_json'=>Data::json($expiredRule),'create_time'=>time()-700]);
    manualDeny(fn()=>$manual->confirm((int)$expired['id'],$payload($expired,'expired')),'expired pending quotation cannot be extended or replaced by an administrator collection action');
    manualCheck((int)Data::decode(Store::row('coop_order',$site,(int)$expired['id'])['rule_json'])['quoted_at']===(int)$expiredRule['quoted_at'],'expired original quote time remains immutable');
    (new PaymentOrderLifecycle($admin))->close((int)$expired['id'],['confirm'=>true,'reason'=>'隔离测试结束关闭过期单'],true);
    // A costly membership has three independent components. Discounting actual
    // received money can change service revenue, never erase required deposits.
    $level=Db::name('member_level')->where('level_id',702)->find();$benefits=Data::decode($level['level_benefits']);$benefits['hsx_lead_subject']['deposit_amount']='100.00';$benefits['hsx_lead_subject']['experience_purchase_enabled']=true;$benefits['hsx_lead_subject']['experience_unit_price']='1.00';Db::name('member_level')->where('level_id',702)->update(['level_benefits'=>Data::json($benefits)]);
    $costly=$newMembership($other,'costly','ML702',true);$beforeCostly=Db::name('hsx_lead_manual_receipt')->count();
    manualDeny(fn()=>$manual->confirm((int)$costly['id'],$payload($costly,'costly','1.00')),'underpayment cannot erase deposit/experience requirements or grant a higher tier');
    manualCheck(Db::name('hsx_lead_manual_receipt')->count()===$beforeCostly,'insufficient actual payment creates no attestation or wallet effect');
    manualCheck((int)Db::name('pay')->where('trade_id',$costly['id'])->where('status',PayDict::STATUS_FINISH)->count()===0,'insufficient actual payment never creates a fake successful core payment');
    $pendingOrder=$newMembership($owner,'pending-projection');$pendingInput=$payload($pendingOrder,'pending-projection');Event::listen('PaySuccess',static function():void{throw new RuntimeException('SYNTHETIC_HOLD');});$pendingReceipt=$manual->confirm((int)$pendingOrder['id'],$pendingInput);Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    $pending=ManualPaymentService::pendingMany($site,[(int)$pendingOrder['id'],(int)$original['id']]);
    manualCheck(($pending[(int)$pendingOrder['id']]['can_pay']??true)===false&&!isset($pending[(int)$original['id']]),'safe pending projection disables another client payment without blocking old posted receipts or future orders');
    manualCheck(array_keys($pending[(int)$pendingOrder['id']])===['manual_payment_status','manual_payment_message','can_pay']&&!str_contains(Data::json($pending),'SYS-MANUAL'),'payer projection contains no account, registration number, receipt identifier or administrator reason');
    manualCheck(ManualPaymentService::pendingMany($site+1,[(int)$pendingOrder['id']])===[],'pending projection never crosses site identity even for the same numeric order id');
    $scoped=ManualPaymentService::withPendingScope($site,[(int)$pendingOrder['id'],(int)$original['id']],static fn():array=>[ManualPaymentService::pending($site,(int)$pendingOrder['id']),ManualPaymentService::pending($site,(int)$original['id'])]);
    manualCheck($scoped[0]===$pending[(int)$pendingOrder['id']]&&$scoped[1]===[],'shared list scope resolves positive and known empty pending states consistently');
    manualCheck($manual->retry($pendingReceipt['id'])['status']==='posted','the same pending receipt can resume once the synthetic callback failure is removed');
    $actor=static function(int $memberId)use($site,$profile):Context{
        Db::name('member')->insert(['site_id'=>$site,'member_id'=>$memberId,'nickname'=>'Isolated manual owner '.$memberId,'mobile'=>'19900000'.$memberId]);$ctx=new Context($site,0,$memberId);
        (new PartnerService($ctx))->saveProfile(array_replace($profile,['name'=>'Receipt fixture shop '.$memberId,'mobile'=>'19900000'.$memberId]));return$ctx;
    };
    // Model a quote created a few seconds earlier without changing the machine
    // clock or sleeping. A real grant shifts the period to verified pay_time.
    $delayedOwner=$actor(104);$delayed=$newMembership($delayedOwner,'delayed');$delayedRow=Store::row('coop_order',$site,(int)$delayed['id']);$delayedRule=Data::decode($delayedRow['rule_json']);$delayedRule['quoted_at']=time()-3;$delayedRule['period_start_at']=$delayedRule['quoted_at'];$delayedRule['period_end_at']=\addon\hsx_lead\app\service\cooperation\Rules::addMonths($delayedRule['quoted_at'],1);Store::query('coop_order',$site)->where('id',$delayed['id'])->update(['rule_json'=>Data::json($delayedRule)]);
    $delayedInput=$payload($delayed,'delayed');$receiptCount=Db::name('hsx_lead_manual_receipt')->count();
    foreach([
        ['confirm'=>false],['external_no'=>''],['account_label'=>''],['reason'=>'短'],['method'=>'bank'],['received_at'=>time()+3600],['amount'=>'0.00'],['amount'=>'100000000.00'],['expected_fingerprint'=>str_repeat('0',64)],['member_id'=>102],['site_id'=>$site+1],['status'=>'posted'],
    ]as$index=>$bad)manualDeny(fn()=>$manual->confirm((int)$delayed['id'],array_replace($delayedInput,$bad)),'incomplete, unsafe, stale or forged financial input #'.$index);
    manualCheck(Db::name('hsx_lead_manual_receipt')->count()===$receiptCount,'rejected data never produces an attested receipt or financial side effects');
    $delayedPosted=$manual->confirm((int)$delayed['id'],$delayedInput);$delayedPaid=Store::row('coop_order',$site,(int)$delayed['id']);$delayedPaidRule=Data::decode($delayedPaid['rule_json']);$delayedCore=Db::name('pay')->where('out_trade_no',$delayedPosted['out_trade_no'])->find();
    manualCheck($delayedPosted['status']==='posted'&&(int)$delayedPaidRule['quoted_period_start_at']===(int)$delayedRule['quoted_at']&&(int)$delayedPaidRule['period_start_at']>(int)$delayedRule['quoted_at'],'membership grant can shift period after a quote without invalidating receipt delivery');
    ManualPaymentService::assertPaymentReceipt($site,$delayedPaid,$delayedCore);manualCheck(true,'post-grant and future refund guards recognize the original quoted-period proof');
    $tampered=$delayedCore;$tampered['money']='0.01';manualDeny(fn()=>ManualPaymentService::assertPaymentReceipt($site,$delayedPaid,$tampered),'a matching receipt number cannot authorize a different payment amount');
    $tampered=$delayedCore;$tampered['main_id']=102;manualDeny(fn()=>ManualPaymentService::assertPaymentReceipt($site,$delayedPaid,$tampered),'receipt cannot authorize another member');
    $tampered=$delayedCore;$tampered['trade_no']='FORGED';manualDeny(fn()=>ManualPaymentService::assertPaymentReceipt($site,$delayedPaid,$tampered),'receipt cannot authorize a different external bank reference');
    manualDeny(fn()=>ManualPaymentService::assertPaymentReceipt($site+1,$delayedPaid,$delayedCore),'receipt cannot authorize a different tenant');
    foreach(['hsx_lead_cooperation_finance','hsx_lead_cooperation_order_manual_receipt','hsx_lead_manage_all_data','hsx_lead_cooperation_order_price','hsx_lead_cooperation_order_close']as$key)Db::name('sys_menu')->insert(['menu_key'=>$key,'menu_name'=>'Manual receipt fixture','app_type'=>'site','status'=>1]);
    Db::name('sys_user')->insert(['uid'=>2,'username'=>'manual-exact-only','status'=>1]);Db::name('sys_role')->insert(['role_id'=>2,'site_id'=>$site,'role_name'=>'Exact receipt only','status'=>1,'rules'=>Data::json(['hsx_lead_cooperation_finance','hsx_lead_cooperation_order_manual_receipt','hsx_lead_manage_all_data'])]);Db::name('sys_user_role')->insert(['uid'=>2,'site_id'=>$site,'role_ids'=>'[2]','status'=>1,'is_admin'=>0]);
    $limited=new ManualPaymentService(new Context($site,2));$limitedOwner=$actor(105);$limitedOrder=$newMembership($limitedOwner,'limited');$limitedInput=$payload($limitedOrder,'limited');
    manualCheck(!$limited->preview((int)$limitedOrder['id'],['amount'=>'99.00'])['can_confirm'],'manual receipt permission does not implicitly grant price adjustment permission');
    $beforeLimited=Db::name('hsx_lead_manual_receipt')->count();manualDeny(fn()=>$limited->confirm((int)$limitedOrder['id'],array_replace($limitedInput,['amount'=>'99.00'])),'actual amount change requires the existing price/close permissions before recording');
    manualCheck(Db::name('hsx_lead_manual_receipt')->count()===$beforeLimited&&Store::row('coop_order',$site,(int)$limitedOrder['id'])['status']==='unpaid','denied implicit repricing creates no partial receipt or closure');
    manualCheck($limited->confirm((int)$limitedOrder['id'],$limitedInput)['status']==='posted','proper exact-amount receipt is allowed without price/close privileges');
    // Roll back failed business delivery but retain the previously committed
    // actual transfer evidence for the same authorized retry/compensation.
    $retryOwner=$actor(106);$retryOrder=$newMembership($retryOwner,'callback-failure');$retryInput=$payload($retryOrder,'callback-failure');
    Db::name('member')->where('site_id',$site)->where('member_id',106)->update(['balance'=>'123.45','balance_get'=>'200.00']);$retryMemberBefore=Db::name('member')->where('member_id',106)->find();$retryLogsBefore=Db::name('member_account_log')->where('member_id',106)->count();
    Event::listen('PaySuccess',static function():void{throw new RuntimeException('PRIVATE_SYNTHETIC_CALLBACK_FAILURE');});
    $retryReceipt=$manual->confirm((int)$retryOrder['id'],$retryInput);
    manualCheck($retryReceipt['status']==='attention'&&$retryReceipt['order']['status']==='unpaid'&&!str_contains($retryReceipt['message'],'PRIVATE_'),'business callback failure preserves recorded money and hides internal details');
    manualCheck((int)Db::name('pay')->where('trade_id',$retryOrder['id'])->where('status',PayDict::STATUS_FINISH)->count()===0,'failed callback does not leave a forged successful cashier after rollback');
    $retryMemberAfter=Db::name('member')->where('member_id',106)->find();manualCheck($retryMemberAfter['balance']===$retryMemberBefore['balance']&&$retryMemberAfter['balance_get']===$retryMemberBefore['balance_get']&&Db::name('member_account_log')->where('member_id',106)->count()===$retryLogsBefore,'failed membership callback rolls back both the real recharge and consumption including total credited balance');
    Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    $recovery=ManualPaymentService::tick(50);$restored=$manual->read($retryReceipt['id']);
    manualCheck($recovery['posted']>=1&&$restored['status']==='posted'&&$restored['id']===$retryReceipt['id'],'scheduled compensation posts the original verified receipt without a second human approval');
    manualCheck(Db::name('hsx_lead_manual_receipt')->where('order_id',$retryOrder['id'])->count()===1,'compensation never manufactures a second received transfer');
    $retryMemberDone=Db::name('member')->where('member_id',106)->find();manualCheck($retryMemberDone['balance']==='123.45'&&$retryMemberDone['balance_get']==='219.00'&&Db::name('member_account_log')->where('member_id',106)->where('account_type','balance')->count()===$retryLogsBefore+2,'retry credits and consumes exactly once while preserving an existing unrelated member balance');
    $revokedOwner=$actor(107);$revokedOrder=$newMembership($revokedOwner,'revoked');$revokedInput=$payload($revokedOrder,'revoked');
    Event::listen('PaySuccess',static function():void{throw new RuntimeException('SYNTHETIC_RETRY_HOLD');});$held=$limited->confirm((int)$revokedOrder['id'],$revokedInput);Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    Db::name('sys_role')->where('role_id',2)->update(['status'=>0]);$revokedTick=ManualPaymentService::tick(50);$heldRead=$manual->read($held['id']);
    manualCheck($revokedTick['blocked']>=1&&$heldRead['status']==='attention'&&str_contains($heldRead['message'],'权限'),'task rechecks current original operator authority and cannot promote itself after permission revocation');
    manualCheck(Store::row('coop_order',$site,(int)$revokedOrder['id'])['status']==='unpaid','revoked authority cannot grant or charge during compensation');
    $raceOwner=$actor(108);$raceOrder=$newMembership($raceOwner,'online-wins');$raceInput=$payload($raceOrder,'online-wins');$raceNo='ONLINE_RECEIPT_WINS';Db::name('pay')->insert(['site_id'=>$site,'main_type'=>PayDict::MEMBER,'main_id'=>108,'out_trade_no'=>$raceNo,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$raceOrder['id'],'money'=>$raceOrder['amount'],'type'=>PayDict::WECHATPAY,'channel'=>'weapp','status'=>PayDict::STATUS_ING]);
    $paidProvider=new ManualSyntheticProvider([['status'=>OnlinePayDict::SUCCESS]]);$onlineWins=(new ManualPaymentService($admin,fn()=>$paidProvider))->confirm((int)$raceOrder['id'],$raceInput);
    manualCheck($onlineWins['status']==='attention'&&Store::row('coop_order',$site,(int)$raceOrder['id'])['status']==='paid','a newly discovered real online payment wins while the separate offline money remains an explicit exception');
    manualCheck(Db::name('pay')->where('trade_id',$raceOrder['id'])->count()===1,'online/offline race creates no second cashier success or duplicated entitlement');
    $lockOwner=$actor(109);$lockOrder=$newMembership($lockOwner,'locked');$lockInput=$payload($lockOrder,'locked');$connection=Db::connect();$scope=(string)$connection->getConfig('database').':'.(string)$connection->getConfig('prefix');$key='lead_coop_pay:'.substr(hash('sha256',$scope.':'.$site.':'.$lockOrder['id']),0,40);$statement=$pdo->prepare('SELECT GET_LOCK(?,0)');$statement->execute([$key]);manualCheck((int)$statement->fetchColumn()===1,'independent local connection owns the established payment mutex');
    try{manualDeny(fn()=>$manual->confirm((int)$lockOrder['id'],$lockInput),'simultaneous payment operation cannot enter offline delivery');}
    finally{$statement=$pdo->prepare('SELECT RELEASE_LOCK(?)');$statement->execute([$key]);}
    $waiting=Db::name('hsx_lead_manual_receipt')->where('request_id',$lockInput['request_id'])->find();manualCheck($waiting&&$waiting['status']==='recorded'&&Store::row('coop_order',$site,(int)$lockOrder['id'])['status']==='unpaid','mutex refusal retains actual evidence but creates no payment or member grant');
    manualCheck($manual->retry((int)$waiting['id'])['status']==='posted','same receipt proceeds safely after the original payment mutex is released');
    // Missing event registration must still be repaired through the same
    // authoritative idempotent business service, never displayed as a grant
    // merely because a framework pay row is FINISH.
    $fallbackOwner=$actor(110);$fallbackOrder=$newMembership($fallbackOwner,'missing-hook');Event::remove('PaySuccess');$fallback=$manual->confirm((int)$fallbackOrder['id'],$payload($fallbackOrder,'missing-hook'));Event::listen('PaySuccess',CooperationPaySuccess::class);
    manualCheck($fallback['status']==='posted'&&$fallback['order']['status']==='paid'&&EntityMembershipService::state($site,(int)(new Context($site,0,110))->merchant()['id'])['active'],'missing event hook has explicit idempotent business recovery before posted is shown');
    $fallbackPay=Db::name('pay')->where('out_trade_no',$fallback['out_trade_no'])->find();ManualPaymentService::assertReceipt($site,Store::row('coop_order',$site,(int)$fallbackOrder['id']),$fallbackPay,true);manualCheck(true,'explicit fallback leaves a formally verifiable typed offline receipt');
    Db::name('sys_user')->insert(['uid'=>3,'username'=>'second-finance-administrator','status'=>1]);Db::name('sys_user_role')->insert(['uid'=>3,'site_id'=>$site,'status'=>1,'is_admin'=>1]);
    $pairOwner=$actor(111);$pairOrder=$newMembership($pairOwner,'pair');$pairInput=$payload($pairOrder,'pair');
    $pair=manualPair($app,$pdo,$schema,$site,[['uid'=>1,'order_id'=>(int)$pairOrder['id'],'input'=>$pairInput],['uid'=>3,'order_id'=>(int)$pairOrder['id'],'input'=>array_replace($pairInput,['request_id'=>'manual-pair-other-request'])]]);
    manualCheck(count(array_filter($pair,static fn(array$row):bool=>$row['accepted']))===1,'two administrators with different request ids cannot both confirm the same original order');
    manualCheck(Db::name('hsx_lead_manual_receipt')->where('order_id',$pairOrder['id'])->count()===1&&Db::name('pay')->where('trade_id',$pairOrder['id'])->where('status',PayDict::STATUS_FINISH)->count()===1,'simultaneous same-order confirmations create one typed receipt and one successful cashier: '.Data::json($pair));
    manualCheck(Db::name('member_account_log')->where('site_id',$site)->where('member_id',111)->where('account_type','balance')->count()===2,'concurrent administrators produce exactly one recharge and one consumption');
    $pairA=$newMembership($actor(112),'pair-a');$pairB=$newMembership($actor(113),'pair-b');$inputA=$payload($pairA,'same-request');$inputB=$payload($pairB,'same-request');
    $conflict=manualPair($app,$pdo,$schema,$site,[['uid'=>1,'order_id'=>(int)$pairA['id'],'input'=>$inputA],['uid'=>3,'order_id'=>(int)$pairB['id'],'input'=>$inputB]]);
    manualCheck(count(array_filter($conflict,static fn(array$row):bool=>$row['accepted']))===1,'the same internal confirmation request cannot be simultaneously allocated to two different orders');
    manualCheck(Db::name('hsx_lead_manual_receipt')->where('request_id',$inputA['request_id'])->count()===1,'database unique request identity survives real independent concurrent workers');
    // Commission repricing must use the original lead's frozen split, rather
    // than treating all incoming money as platform service revenue.
    $publisher=new CooperationService($owner);$receiver=new CooperationService($other);$model=$publisher->catalog()[0];
    (new CapabilityService($other))->save((int)$otherMerchant['id'],['business_capabilities'=>[['business_type'=>'purchase','option_ids'=>[$model['id']]]]]);
    $commissionLead=$publisher->create(['request_id'=>'manual-commission-lead','customer_name'=>'Synthetic commission customer','mobile'=>'13900000000','province_id'=>910000,'city_id'=>910100,'district_id'=>910101,'business_type'=>'purchase','model_ids'=>[$model['id']],'consent'=>true,'attachments'=>[]]);$publisher->assign((int)$commissionLead['id'],['merchant_id'=>$otherMerchant['id'],'assignment_version'=>0]);$receiver->action((int)$commissionLead['id'],['action'=>'accept','assignment_version'=>1]);$receiver->action((int)$commissionLead['id'],['action'=>'deal','assignment_version'=>1]);
    $commission=(new PaymentService($other))->createOrder(['purpose'=>'commission','lead_id'=>$commissionLead['id'],'amount'=>'100.00','request_id'=>'manual-commission-order']);$commissionReceipt=$manual->confirm((int)$commission['id'],$payload($commission,'commission'));
    manualCheck($commissionReceipt['status']==='posted'&&$commissionReceipt['order']['amount']==='100.00'&&$commissionReceipt['order']['fee_amount']==='10.00'&&$commissionReceipt['order']['net_amount']==='90.00','balance-funded collaboration payment preserves the original platform and publisher split without repricing');
    manualCheck(Db::name('member_account_log')->where('site_id',$site)->where('from_type',PaymentService::INCOME_TYPE)->where('related_id',(string)$commissionReceipt['target_order_id'])->count()===1,'publisher receives one real framework commission income log');
    $beforeLate=Db::name('member')->where('member_id',101)->find();$lateNo='SYNTHETIC_LATE_ORIGINAL_COMMISSION';Db::name('pay')->insert(['site_id'=>$site,'main_type'=>PayDict::MEMBER,'main_id'=>102,'out_trade_no'=>$lateNo,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$commission['id'],'money'=>'100.00','type'=>PayDict::WECHATPAY,'channel'=>'weapp','status'=>PayDict::STATUS_FINISH,'pay_time'=>time()]);manualDeny(fn()=>PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$commission['id'],'out_trade_no'=>$lateNo]),'a late second online payment is never accepted as a second business settlement');
    manualCheck(Db::name('member')->where('member_id',101)->find()['commission']===$beforeLate['commission'],'late original receipt does not repeat publisher income or grant a second commission');
    $writeOwner=$actor(114);$writeOrder=$newMembership($writeOwner,'write-failure');$writeInput=$payload($writeOrder,'write-failure');$beforeWrite=Db::name('hsx_lead_manual_receipt')->count();
    $pdo->exec("CREATE TRIGGER manual_record_failure BEFORE INSERT ON lt_hsx_lead_manual_receipt FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT='PRIVATE_SYNTHETIC_BANK_DETAIL'");
    try{$manual->confirm((int)$writeOrder['id'],$writeInput);throw new RuntimeException('Expected receipt persistence failure');}
    catch(CommonException $error){manualCheck(str_contains($error->getMessage(),'未完成')&&!str_contains($error->getMessage(),'PRIVATE_'),'receipt persistence failure never reports success or exposes private database details');}
    finally{$pdo->exec('DROP TRIGGER manual_record_failure');}
    manualCheck(Db::name('hsx_lead_manual_receipt')->count()===$beforeWrite&&Db::name('pay')->where('trade_id',$writeOrder['id'])->count()===0,'failed receipt persistence cannot create a cashier or entitlement');
    manualDeny(fn()=>Db::transaction(fn()=>$manual->confirm((int)$writeOrder['id'],$writeInput)),'external caller cannot wrap provider reconciliation in a long business transaction');
    manualCheck($manual->confirm((int)$writeOrder['id'],$writeInput)['status']==='posted','same original request can be retried after actual evidence storage recovers');
    $recreatedOwner=$actor(115);$recreatedOld=$newMembership($recreatedOwner,'customer-recreated-old');(new PaymentOrderLifecycle($admin))->close((int)$recreatedOld['id'],['confirm'=>true,'reason'=>'合成客户自行取消'],true);$recreatedCurrent=$newMembership($recreatedOwner,'customer-recreated-current');$beforeRecreate=Store::query('coop_order',$site)->count();
    manualDeny(fn()=>$manual->confirm((int)$recreatedOld['id'],$payload($recreatedOld,'customer-recreated')),'closed original cannot reuse a different customer-created pending order');
    manualCheck(Store::row('coop_order',$site,(int)$recreatedCurrent['id'])['status']==='unpaid'&&Store::query('coop_order',$site)->count()===$beforeRecreate,'refusing closed-order collection leaves the separate new purchase unchanged');
    $fakeOrder=$newMembership($owner,'forged');$fakeNo='FORGED_OFFLINE_NO_EVIDENCE';Db::name('pay')->insert(['site_id'=>$site,'main_type'=>PayDict::MEMBER,'main_id'=>101,'out_trade_no'=>$fakeNo,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$fakeOrder['id'],'money'=>$fakeOrder['amount'],'type'=>PayDict::OFFLINEPAY,'status'=>PayDict::STATUS_FINISH]);
    manualDeny(fn()=>PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$fakeOrder['id'],'out_trade_no'=>$fakeNo]),'merely marking an offline core payment successful cannot bypass typed evidence verification');
    manualCheck(Store::row('coop_order',$site,(int)$fakeOrder['id'])['status']==='unpaid','forged offline success grants no membership or business payment');
    // A deployment may have copied code before running the explicit additive
    // upgrade. Only the authorized manual feature reports that action; normal
    // online payment preconditions remain usable and no HTTP request runs DDL.
    $onlineOwner=$actor(116);$onlineOrder=$newMembership($onlineOwner,'schema-optional-online');
    $protected=static function():string{$rows=[];foreach(['pay','pay_refund','member','member_account_log','hsx_lead_coop_order','hsx_lead_audit']as$table)$rows[$table]=Db::name($table)->select()->toArray();return hash('sha256',Data::json($rows));};
    $beforeMissing=$protected();$pdo->exec('RENAME TABLE lt_hsx_lead_manual_receipt TO lt_hsx_lead_manual_receipt_unavailable_fixture');
    try{
        foreach([
            'preview'=>fn()=>$manual->preview((int)$original['id']),
            'confirm'=>fn()=>$manual->confirm((int)$original['id'],$input),
            'read'=>fn()=>$manual->read($posted['id']),
            'retry'=>fn()=>$manual->retry($posted['id']),
        ]as$name=>$operation){
            try{$operation();throw new RuntimeException('Expected explicit upgrade guidance: '.$name);}
            catch(CommonException $error){manualCheck(str_contains($error->getMessage(),'人工收款结构未就绪')&&str_contains($error->getMessage(),'upgrade-manual-receipts.php')&&str_contains($error->getMessage(),'--check')&&str_contains($error->getMessage(),'--apply')&&!str_contains($error->getMessage(),'SQLSTATE'),'manual '.$name.' gives authorized actionable upgrade guidance without exposing raw SQL');}
        }
        try{(new ManualPaymentService($owner))->preview((int)$original['id']);throw new RuntimeException('Expected member rejection before schema read');}
        catch(CommonException $error){manualCheck(!str_contains($error->getMessage(),'upgrade-manual-receipts.php'),'unauthorized member receives no internal schema/deployment details');}
        (new PaymentService($onlineOwner))->assertPayable((int)$onlineOrder['id']);$onlineInfo=PaymentService::paymentInfo($site,(int)$onlineOrder['id']);
        manualCheck($onlineInfo['main_id']===116&&$onlineInfo['money']===$onlineOrder['amount'],'missing optional manual schema does not break the normal online payment business checks');
        manualCheck(ManualPaymentService::tick(1)['available']===false&&ManualPaymentService::pendingMany($site,[(int)$onlineOrder['id']])===[],'optional read/recovery helpers remain explicitly unavailable without inventing receipt rows');
        manualCheck($protected()===$beforeMissing,'missing-schema entry attempts leave payment, refund, member, order and audit facts untouched');
        $missing=$pdo->query("SHOW TABLES LIKE 'lt_hsx_lead_manual_receipt'")->fetchColumn();manualCheck($missing===false,'manual entry points and ordinary payment guards never implicitly recreate the evidence table');
    }finally{$pdo->exec('RENAME TABLE lt_hsx_lead_manual_receipt_unavailable_fixture TO lt_hsx_lead_manual_receipt');}
    manualCheck($manual->read($posted['id'])['status']==='posted','manual feature immediately reads the original receipt after schema availability returns, without a stale negative cache');
    $proofLog=Db::name('member_account_log')->where('id',$posted['debit_log_id'])->find();Db::name('member_account_log')->where('id',$posted['debit_log_id'])->update(['account_data'=>'-0.01']);
    try{manualDeny(fn()=>ManualPaymentService::assertPaymentReceipt($site,$paid,$core),'matching successful balance pay cannot authorize benefits if its real consumption ledger has a different amount');}
    finally{Db::name('member_account_log')->where('id',$posted['debit_log_id'])->update(['account_data'=>$proofLog['account_data']]);}
    ManualPaymentService::assertPaymentReceipt($site,$paid,$core);manualCheck(true,'restoring the original unmodified consumption proof immediately restores verification');
    $closedPendingOwner=$actor(117);$closedPendingOrder=$newMembership($closedPendingOwner,'closed-pending');Event::listen('PaySuccess',static function():void{throw new RuntimeException('SYNTHETIC_CLOSED_PENDING');});$closedPending=$manual->confirm((int)$closedPendingOrder['id'],$payload($closedPendingOrder,'closed-pending'));Event::remove('PaySuccess');Event::listen('PaySuccess',CooperationPaySuccess::class);
    manualCheck($closedPending['status']==='attention','synthetic failed callback leaves one attested pending receipt before testing an independently closed original');
    Store::query('coop_order',$site)->where('id',$closedPendingOrder['id'])->update(['status'=>'closed']);
    $closedFacts=static function()use($site,$closedPending,$closedPendingOrder):string{return Data::json([
        Store::row('coop_order',$site,(int)$closedPendingOrder['id']),Db::name('hsx_lead_manual_receipt')->where('id',$closedPending['id'])->find(),Db::name('member')->where('member_id',117)->find(),
        Db::name('member_account_log')->where('site_id',$site)->where('member_id',117)->select()->toArray(),Db::name('pay')->where('site_id',$site)->where('trade_id',$closedPendingOrder['id'])->select()->toArray(),Store::query('coop_order',$site)->where('member_id',117)->select()->toArray(),
    ]);};$beforeClosedPending=$closedFacts();
    manualCheck(!$manual->preview((int)$closedPendingOrder['id'])['can_confirm']&&!$manual->read($closedPending['id'])['can_retry'],'an already-closed original removes both confirm and retry actions even when a pending receipt exists');
    $closedRetry=$manual->retry($closedPending['id']);$closedTick=ManualPaymentService::tick(50);
    manualCheck(!$closedRetry['can_retry']&&$closedTick['blocked']>=1&&$closedFacts()===$beforeClosedPending,'read, explicit retry and scheduled recovery of a closed pending receipt make no mutation, recharge, debit or new purchase');
    $fakeBalanceOrder=$newMembership($actor(118),'forged-balance');$fakeBalanceNo='FORGED_BALANCE_NO_REAL_LEDGER';Db::name('pay')->insert(['site_id'=>$site,'main_type'=>PayDict::MEMBER,'main_id'=>118,'out_trade_no'=>$fakeBalanceNo,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$fakeBalanceOrder['id'],'money'=>$fakeBalanceOrder['amount'],'type'=>PayDict::BALANCEPAY,'status'=>PayDict::STATUS_FINISH,'voucher'=>'manual-receipt:999999']);
    manualDeny(fn()=>PaymentService::confirm(['site_id'=>$site,'trade_type'=>PaymentService::TRADE_TYPE,'trade_id'=>$fakeBalanceOrder['id'],'out_trade_no'=>$fakeBalanceNo]),'a fake internal balance payment marker without actual manual funding evidence cannot grant membership');
    manualCheck(Store::row('coop_order',$site,(int)$fakeBalanceOrder['id'])['status']==='unpaid'&&Db::name('member_account_log')->where('member_id',118)->count()===0,'forged balance-success inputs create no entitlement or member funding ledger');
    leadAssertIsolated($schema);
    echo json_encode(['passed'=>true,'checks'=>$checks,'scope'=>'actual manual receipt service, real framework balance recharge/debit/PaySuccess; exact original order only; owned random localhost schema; synthetic WeChat receipt attestation; no external payment or real data'],JSON_UNESCAPED_UNICODE).PHP_EOL;
}catch(Throwable $error){$failed=true;fwrite(STDERR,'FAIL manual payment after '.$checks.': '.get_class($error).' '.$error->getMessage().' @ '.basename($error->getFile()).':'.$error->getLine().PHP_EOL);}
finally{if(class_exists(Event::class)){Event::remove('PayCreate');Event::remove('PaySuccess');}if($pdo instanceof PDO&&$schema!=='')leadCleanup($pdo,$schema);}
exit($failed?1:0);
