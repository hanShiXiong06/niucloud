<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\home_service\app\model\cash_out;

use addon\home_service\app\dict\coupon\CouponDict;
use core\base\BaseModel;
use think\db\Query;

/**
 * 提现账户模型
 */
class CashOutAccount extends BaseModel
{


    /**
     * 数据表主键
     * @var string
     */
    protected $pk = 'account_id';

    /**
     * 模型名称
     * @var string
     */
    protected $name = 'home_service_cash_out_account';


}
