<template>
  <div>
    <h1>Clipboard Upload</h1>
  </div>
</template>

<script setup lang="ts">
//导入global-clipboard
import  "@/addon/hsx_clipboard_upload/static/global-clipboard.js";
import  "@/addon/hsx_clipboard_upload/static/global-drag-upload.js";
</script>

<style scoped lang="scss"></style>