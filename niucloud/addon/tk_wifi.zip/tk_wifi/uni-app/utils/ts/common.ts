
export function truncateMiddle(text: string, start: number = 2, end: number = 4): string {
	if (!text) return '';
	if (text.length <= start + end) return text;

	const startText = text.substring(0, start);
	const endText = text.substring(text.length - end);

	return `${startText}...${endText}`;
}

export async function downloadFileEvent(url: string): Promise<void> {
	try {
		const platform = uni.getSystemInfoSync().platform;

		// 微信小程序环境
		// #ifdef MP-WEIXIN
		// 检查链接是否有效
		if (!url || typeof url !== 'string') {
			uni.showToast({
				title: '下载链接无效',
				icon: 'none'
			});
			return;
		}

		// 判断文件类型
		const isVideo = url.match(/\.(mp4|avi|mov|wmv|flv|mkv)$/i);
		const isAudio = url.match(/\.(mp3|wav|ogg|aac|m4a)$/i);

		// 显示下载提示
		uni.showLoading({
			title: '准备下载...',
			mask: true
		});

		// 处理视频和音频文件
		if (isVideo || isAudio) {
			const fileType = isVideo ? '视频' : '音频';

			try {
				// 先将链接保存到本地临时文件
				const downloadRes = await new Promise<UniApp.DownloadSuccessData>((resolve, reject) => {
					const downloadTask = uni.downloadFile({
						url,
						success: resolve,
						fail: reject
					});

					// 添加下载进度监听
					downloadTask.onProgressUpdate((res) => {
						uni.showLoading({
							title: `下载中 ${res.progress}%`,
							mask: true
						});
					});
				});

				if (downloadRes.statusCode === 200) {
					uni.hideLoading();
					uni.showToast({
						title: '下载完成',
						icon: 'success',
						duration: 1500
					});

					// 保存到手机相册
					if (isVideo) {
						uni.saveVideoToPhotosAlbum({
							filePath: downloadRes.tempFilePath,
							success: () => {
								uni.showToast({
									title: '视频已保存到相册',
									icon: 'success'
								});
							},
							fail: (err) => {
								console.error('保存视频到相册失败:', err);
								// 如果是权限问题，引导用户授权
								if (err.errMsg && err.errMsg.includes('authorize')) {
									uni.showModal({
										title: '提示',
										content: '需要授权保存到相册',
										success: (res) => {
											if (res.confirm) {
												uni.openSetting();
											}
										}
									});
								} else {
									uni.showToast({
										title: '保存到相册失败',
										icon: 'none'
									});
								}
							}
						});
					} else if (isAudio) {
						// 音频文件处理 - 提供预览或播放选项
						uni.showModal({
							title: '下载成功',
							content: '音频文件已下载，是否立即播放？',
							confirmText: '播放',
							cancelText: '关闭',
							success: (res) => {
								if (res.confirm) {
									const innerAudioContext = uni.createInnerAudioContext();
									innerAudioContext.src = downloadRes.tempFilePath;
									innerAudioContext.play();
									uni.showToast({
										title: '播放中...',
										icon: 'none',
										duration: 2000
									});
								}
							}
						});
					}
				} else {
					uni.hideLoading();
					throw new Error(`下载失败，状态码: ${downloadRes.statusCode}`);
				}
			} catch (error: any) {
				uni.hideLoading();
				console.error(`${fileType}下载失败:`, error);
				uni.showToast({
					title: error.message || `${fileType}下载失败，请稍后重试`,
					icon: 'none'
				});
			}
		} else {
			// 其他类型文件的处理
			try {
				const downloadTask = uni.downloadFile({
					url,
					success: (res) => {
						if (res.statusCode === 200) {
							uni.hideLoading();
							// 保存文件到本地
							uni.saveFile({
								tempFilePath: res.tempFilePath,
								success: (saveRes) => {
									uni.showToast({
										title: '文件已保存',
										icon: 'success'
									});
									// 打开文档预览
									uni.openDocument({
										filePath: saveRes.savedFilePath,
										showMenu: true,
										success: () => {
											console.log('打开文档成功');
										},
										fail: (err) => {
											console.error('打开文档失败:', err);
											uni.showToast({
												title: '无法预览此类型文件',
												icon: 'none'
											});
										}
									});
								},
								fail: (err) => {
									uni.hideLoading();
									console.error('保存文件失败:', err);
									uni.showToast({
										title: '保存文件失败',
										icon: 'none'
									});
								}
							});
						} else {
							uni.hideLoading();
							uni.showToast({
								title: `下载失败，状态码: ${res.statusCode}`,
								icon: 'none'
							});
						}
					},
					fail: (err) => {
						uni.hideLoading();
						console.error('下载文件失败:', err);
						uni.showToast({
							title: '下载失败',
							icon: 'none'
						});
					}
				});

				// 添加下载进度监听
				downloadTask.onProgressUpdate((res) => {
					uni.showLoading({
						title: `下载中 ${res.progress}%`,
						mask: true
					});
				});
			} catch (error: any) {
				uni.hideLoading();
				console.error('下载过程发生错误:', error);
				uni.showToast({
					title: error.message || '下载失败，请稍后重试',
					icon: 'none'
				});
			}
		}
		// #endif

		// 其他平台环境处理
		// #ifndef MP-WEIXIN
		// H5 环境
		// #ifdef H5
		const ua = window.navigator.userAgent.toLowerCase();
		const isWeixin = ua.indexOf('micromessenger') !== -1;

		if (isWeixin) {
			copy(url, '');
			uni.showToast({
				title: '链接已复制，请在浏览器中打开下载',
				icon: 'none'
			});
		} else {
			try {
				const a = document.createElement('a');
				a.href = url;
				a.download = url.substring(url.lastIndexOf('/') + 1);
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);

				uni.showToast({
					title: '开始下载',
					icon: 'none'
				});
			} catch (error) {
				console.error('H5下载文件失败:', error);
				uni.showToast({
					title: '下载失败，请稍后重试',
					icon: 'none'
				});
			}
		}
		// #endif
		// #endif
	} catch (error) {
		uni.hideLoading();
		console.error('下载文件过程中发生未知错误:', error);
		uni.showToast({
			title: '下载失败，请稍后重试',
			icon: 'none'
		});
	}
}
