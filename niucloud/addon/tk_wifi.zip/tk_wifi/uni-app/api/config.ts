import request from '@/utils/request'

export function getShareInfo(data?: any) {
    return request.get(`tk_wifi/getshare`, data)
}

export function getShortLink(data?: any) {
    return request.get(`tk_wifi/getshortlink`, data)
}
