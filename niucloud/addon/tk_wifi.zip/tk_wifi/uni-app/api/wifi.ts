
import request from '@/utils/request'

/***************************************************** WIFI码接口 ****************************************************/

/**
 * 检查开店宝权限
 * @returns 
 */
export function checkPartner() {
    return request.get(`tk_wifi/check/partner`)
}
/**
 * 添加wifi二维码
 * @param params 
 * @returns 
 */
export function addWifi(params: any) {
    return request.post(`tk_wifi/tkwifilist`, params)
}
/**
 * 获取wifi二维码列表
 * @param params 
 * @returns 
 */
export function getWifiList(params: any) {
    return request.get(`tk_wifi/tkwifilist`, params)
}
export function getWifiCreateList(params: any) {
    return request.get(`tk_wifi/tkwifilist/create`, params)
}
/**
 * 删除wifi二维码
 * @param id 
 * @returns 
 */
export function delWifiQrcode(id: any) {
    return request.delete(`tk_wifi/tkwifilist/${id}`)
}
/**
 * 编辑wifi信息
 * @param params 
 * @returns 
 */
export function editeWifiQrcode(params: any) {
    return request.put(`tk_wifi/tkwifilist/${params.id}`, params)
}
/**
 * 获取wifi信息
 * @param id 
 * @returns 
 */
export function getWifiInfo(id: any) {
    return request.get(`tk_wifi/tkwifilist/${id}`)
}
/**
 * 获取配置
 * @returns 
 */
export function getConfig() {
    return request.get(`tk_wifi/getconfig`)
}
/**
 * 申请分销
 * @param params 
 * @returns 
 */
export function applySharer(params) {
    return request.post(`tk_wifi/apply/sharer`, params)
}
/**
 * 检查推广权限
 * @param params 
 * @returns 
 */
export function checkSharer(params) {
    return request.post('tk_wifi/check/sharer', params)
}
/**
 * 连接wifi(兼容旧入口:普通模式/H5直接连接)
 */
export function addContact(id: any) {
    return request.get(`tk_wifi/addcontact/${id}`)
}
/**
 * 广告链路上报
 * @param id wifi_id
 * @param action view=开始观看 complete=看完 exit=中途退出 nofill=无广告填充 fallback=异常放行 connect=普通连接
 */
export function reportAd(id: any, action: string) {
    return request.get(`tk_wifi/ad/report/${id}`, { action })
}
/**
 * 我的码 连接/看广告明细(含未发放原因)
 * @param params reward_status: ''=全部 1=已发放 3=未发放
 */
export function getAdRecords(params: any) {
    return request.get(`tk_wifi/fee/records`, params)
}
/**
 * 我的码 漏斗概览
 */
export function getFeeFunnel() {
    return request.get(`tk_wifi/fee/funnel`)
}
/**
 * 获取团队数据统计
 */
export function getStat() {
    return request.get(`tk_wifi/member/stat`)
}
/**
 * 获取收益统计
 */
export function getFeeStat() {
    return request.get(`tk_wifi/fee/stat`)
}
/**
 * 获取收益明细列表
 * @param params type: own=店主 first=直推 second=间推 all=全部
 */
export function getFeeList(params: any) {
    return request.get(`tk_wifi/fee/lists`, params)
}