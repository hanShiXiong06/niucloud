<template>
    <view class="min-h-screen" style="background-color: #F7F8FA;">
        <!-- 漏斗概览 -->
        <view class="px-4 pt-3">
            <view class="grid grid-cols-4 gap-2">
                <view class="bg-white rounded-2xl p-3 shadow-sm border border-gray-50 text-center">
                    <view style="color:#2563eb;font-size:36rpx;font-weight:bold;">{{ funnel.view_num }}</view>
                    <view class="text-gray-400" style="font-size:22rpx;">看广告</view>
                </view>
                <view class="bg-white rounded-2xl p-3 shadow-sm border border-gray-50 text-center">
                    <view style="color:#0891b2;font-size:36rpx;font-weight:bold;">{{ funnel.complete_num }}</view>
                    <view class="text-gray-400" style="font-size:22rpx;">看完</view>
                </view>
                <view class="bg-white rounded-2xl p-3 shadow-sm border border-gray-50 text-center">
                    <view style="color:#16a34a;font-size:36rpx;font-weight:bold;">{{ funnel.reward_num }}</view>
                    <view class="text-gray-400" style="font-size:22rpx;">已发放</view>
                </view>
                <view class="bg-white rounded-2xl p-3 shadow-sm border border-gray-50 text-center">
                    <view style="color:#dc2626;font-size:36rpx;font-weight:bold;">{{ funnel.skip_num }}</view>
                    <view class="text-gray-400" style="font-size:22rpx;">未发放</view>
                </view>
            </view>
        </view>

        <!-- 筛选 -->
        <view class="px-4 mt-3">
            <view class="flex bg-white rounded-full p-1 shadow-sm border border-gray-50">
                <view v-for="tab in tabs" :key="tab.value"
                    class="flex-1 text-center rounded-full transition-all"
                    style="padding-top:12rpx;padding-bottom:12rpx;font-size:26rpx;"
                    :style="rewardStatus === tab.value
                        ? 'background:#1f2937;color:#fff;font-weight:600;'
                        : 'color:#6b7280;'"
                    @click="switchTab(tab.value)">
                    {{ tab.label }}
                </view>
            </view>
        </view>

        <!-- 明细列表 -->
        <mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="getListFn" :top="0">
            <template v-if="list && list.length > 0">
                <view v-for="(item, index) in list" :key="index"
                    class="mx-4 mt-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-50">
                    <view class="flex items-center justify-between">
                        <view class="flex items-center gap-2 min-w-0">
                            <up-icon name="wifi" size="18" color="#C4AF68"></up-icon>
                            <text class="truncate" style="color:#1f2937;font-size:28rpx;font-weight:500;max-width:300rpx;">
                                {{ item.wifi_name || item.wifi_id_name || ('码#' + item.wifi_id) }}
                            </text>
                        </view>
                        <!-- 佣金状态 -->
                        <view class="shrink-0">
                            <text v-if="Number(item.reward_status) === 1" style="font-size:26rpx;font-weight:bold;color:#16a34a;">
                                +¥{{ myFee(item) }}
                            </text>
                            <text v-else class="px-2 py-0.5 rounded-full"
                                style="font-size:22rpx;color:#9ca3af;background:#f3f4f6;">未发放</text>
                        </view>
                    </view>

                    <view class="flex items-center flex-wrap gap-2 mt-2">
                        <!-- 广告状态标签 -->
                        <text class="px-2 py-0.5 rounded"
                            :style="adTagStyle(item.ad_status)" style="font-size:22rpx;">
                            {{ item.ad_status_name || '-' }}
                        </text>
                        <!-- 观看人 -->
                        <text class="text-gray-400" style="font-size:22rpx;">
                            观看：{{ item.view_member_name || (item.member_id ? ('用户' + item.member_id) : '未登录') }}
                        </text>
                        <text class="text-gray-300" style="font-size:22rpx;">{{ formatTime(item.create_time) }}</text>
                    </view>

                    <!-- 未发放原因 -->
                    <view v-if="Number(item.reward_status) !== 1 && item.reason_desc"
                        class="mt-2 px-3 py-2 rounded-lg"
                        style="background:#fff7ed;border:1px solid #fed7aa;">
                        <text style="font-size:22rpx;color:#c2410c;">原因：{{ item.reason_desc }}</text>
                    </view>
                </view>
            </template>
            <up-empty v-else-if="list && list.length == 0" mode="list" text="暂无记录" class="py-12"></up-empty>
        </mescroll-body>

        <tabbar addon="tk_wifi" />
    </view>
</template>

<script setup lang="ts">
import { ref, reactive } from 'vue';
import { moneyFormat, handleOnloadParams } from '@/utils/common';
import useMemberStore from '@/stores/member';
import { onLoad, onPageScroll, onReachBottom } from '@dcloudio/uni-app';
import MescrollBody from '@/components/mescroll/mescroll-body/mescroll-body.vue';
import useMescroll from '@/components/mescroll/hooks/useMescroll.js';
import { getAdRecords, getFeeFunnel } from '@/addon/tk_wifi/api/wifi';

const { mescrollInit, downCallback, getMescroll } = useMescroll(onPageScroll, onReachBottom);
const memberStore = useMemberStore();
const myId = ref<any>(memberStore.info?.member_id);

const list = ref<any[]>([]);
const rewardStatus = ref<string>(''); // ''=全部 1=已发放 3=未发放
const tabs = [
    { label: '全部', value: '' },
    { label: '已发放', value: '1' },
    { label: '未发放', value: '3' },
];

const funnel = reactive({ view_num: 0, complete_num: 0, reward_num: 0, skip_num: 0 });

const loadFunnel = async () => {
    try {
        const res = await getFeeFunnel();
        Object.assign(funnel, res.data || {});
    } catch (e) { }
};
loadFunnel();

// 当前会员在该记录里实际拿到的佣金（店主/一级/二级）
const myFee = (item: any) => {
    let fee = 0;
    if (item.own_member_id == myId.value) fee += Number(item.own_fee || 0);
    if (item.first_member_id == myId.value) fee += Number(item.first_fee || 0);
    if (item.second_member_id == myId.value) fee += Number(item.second_fee || 0);
    if (fee === 0) {
        // 兜底：取该行任意已发放金额
        fee = Number(item.own_fee || 0) + Number(item.first_fee || 0) + Number(item.second_fee || 0);
    }
    return moneyFormat(fee);
};

const adTagStyle = (s: any) => {
    const n = Number(s);
    if (n === 2) return 'background:#dcfce7;color:#16a34a;';   // 看完
    if (n === 3) return 'background:#fee2e2;color:#dc2626;';   // 退出
    if (n === 4 || n === 5) return 'background:#fef3c7;color:#b45309;'; // 无广告/异常
    if (n === 6) return 'background:#e0f2fe;color:#0369a1;';   // 无需广告
    return 'background:#f3f4f6;color:#6b7280;';
};

const getListFn = (mescroll: any) => {
    const data = {
        page: mescroll.num,
        limit: mescroll.size,
        reward_status: rewardStatus.value,
    };
    getAdRecords(data)
        .then((res) => {
            const newArr = (res.data.data || []) as Array<any>;
            mescroll.endSuccess(newArr.length);
            if (mescroll.num == 1) list.value = [];
            list.value = list.value.concat(newArr);
        })
        .catch(() => {
            mescroll.endErr();
        });
};

const switchTab = (val: string) => {
    if (rewardStatus.value === val) return;
    rewardStatus.value = val;
    const mescroll = getMescroll();
    if (mescroll) {
        mescroll.resetUpScroll();
    }
};

const formatTime = (time: any): string => {
    if (!time) return '-';
    let t = Number(time);
    if (!t) return String(time);
    if (t < 1e12) t = t * 1000;
    const d = new Date(t);
    const pad = (n: number) => n < 10 ? '0' + n : '' + n;
    return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

onLoad((option) => {
    // #ifdef MP-WEIXIN
    option = handleOnloadParams(option);
    // #endif
    myId.value = memberStore.info?.member_id;
});
</script>

<style lang="scss" scoped>
page {
    background-color: #F7F8FA;
}

::-webkit-scrollbar {
    display: none;
    width: 0;
    height: 0;
    color: transparent;
}

.mescroll-upwarp { min-height: 0rpx; }
.mescroll-empty { min-height: 0rpx; }
</style>
