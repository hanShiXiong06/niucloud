<template>
    <view class="min-h-screen" :style="'background-color: #F7F8FA; ' + themeColor()" v-if="memberStore.info">
        <!-- 收益统计主卡片 -->
        <view class="mt-3 mx-3 rounded-2xl overflow-hidden shadow-lg relative"
            style="background: linear-gradient(145deg, rgba(58,59,53,1) 0%, rgba(47,48,43,1) 60%, rgba(42,43,38,1) 100%); box-shadow: 0 4rpx 16rpx rgba(0,0,0,0.15);">

            <view class="p-5 pb-6">
                <view class="flex items-center justify-between">
                    <view @click="redirect({ url: '/app/pages/member/commission' })"
                        class="cursor-pointer flex-1" style="opacity: 0.8;">
                        <view class="flex items-center" style="gap: 6rpx; margin-bottom: 10rpx;">
                            <up-icon name="wifi" size="15" color="#9A9B8A"></up-icon>
                            <text style="color: #9A9B8A; font-size: 24rpx;">WIFI收益</text>
                        </view>
                        <view class="flex items-baseline" style="gap: 4rpx;">
                            <text style="color: #ffffff; font-size: 40rpx; font-weight: bold; letter-spacing: -0.5rpx;">
                                {{ statInfo ? moneyFormat(statInfo.own_total) : '0.00' }}
                            </text>
                        </view>
                    </view>

                    <!-- 分割线 -->
                    <view style="width: 1px; height: 56rpx; background: linear-gradient(to bottom, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.1) 50%, transparent 100%); margin: 0 20rpx;"></view>

                    <view class="flex-1">
                        <view class="flex items-center" style="gap: 6rpx; margin-bottom: 10rpx;">
                            <up-icon name="rmb-circle" size="15" color="#9A9B8A"></up-icon>
                            <text style="color: #9A9B8A; font-size: 24rpx;">可提现金额</text>
                        </view>
                        <view class="flex items-baseline" style="gap: 4rpx;">
                            <text style="color: #ffffff; font-size: 40rpx; font-weight: bold; letter-spacing: -0.5rpx;">
                                {{ memberStore.info ? moneyFormat(memberStore.info.commission) : '0.00' }}
                            </text>
                        </view>
                    </view>

                    <!-- 去提现按钮 -->
                    <view @click="applyCashOut()" class="ml-3 shrink-0 relative">
                        <view
                            class="relative px-5 rounded-full text-sm font-bold shadow-md"
                            style="padding-top: 10rpx; padding-bottom: 10rpx; color: #3a3828; background: linear-gradient(135deg, #F0E4A8 0%, #E9D88B 50%, #DFD08A 100%);">
                            去提现
                        </view>
                    </view>
                </view>
            </view>

            <!-- 底部装饰光效 -->
            <view class="absolute bottom-0" style="left: 50%; transform: translateX(-50%); width: 66%; height: 24rpx; background: rgba(233,216,139,0.08); border-radius: 9999px; filter: blur(16rpx);"></view>
        </view>

        <!-- 数据概览行 -->
        <view class="px-4 mt-3 relative z-10" v-if="statInfo">
            <view class="grid grid-cols-2 gap-3">
                <!-- 店主收益 -->
                <view class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                    <view class="flex items-center mb-3" style="gap: 8rpx;">
                        <view class="rounded-full" style="width: 3rpx; height: 16rpx; background: linear-gradient(180deg, #E9D88B 0%, #c4af68 100%)"></view>
                        <text class="text-gray-400 text-xs">WIFI收益</text>
                    </view>
                    <view class="mb-3">
                        <text style="color: #111827; font-size: 38rpx; font-weight: bold; letter-spacing: -0.5rpx;">{{ moneyFormat(statInfo?.own_total || 0) }}</text>
                    </view>
                    <view class="border-t border-dashed border-gray-100 flex items-center justify-between" style="padding-top: 10rpx;">
                        <view>
                            <text style="font-size: 22rpx; color: #9ca3af;">累计收益</text>
                            <text class="text-xs text-gray-500 font-medium ml-1">{{ statInfo?.own_num || 0 }} 笔</text>
                        </view>
                    </view>
                </view>

                <!-- WiFi连接次数 -->
                <view class="bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
                    <view class="flex items-center mb-3" style="gap: 8rpx;">
                        <view class="rounded-full" style="width: 3rpx; height: 16rpx; background: linear-gradient(180deg, #34d399 0%, #10b981 100%)"></view>
                        <text class="text-gray-400 text-xs">连接次数</text>
                    </view>
                    <view class="mb-3">
                        <text style="color: #111827; font-size: 38rpx; font-weight: bold; letter-spacing: -0.5rpx;">{{ statInfo?.own_num || 0 }}</text>
                        <text class="text-sm text-gray-400" style="margin-left: 6rpx;">次</text>
                    </view>
                    <view class="border-t border-dashed border-gray-100" style="padding-top: 10rpx;">
                        <text style="font-size: 22rpx; color: #9ca3af;">WiFi连接激励收益</text>
                    </view>
                </view>
            </view>
        </view>

        <!-- 收益明细区域标题 -->
        <view class="px-4 mt-5 mb-1">
            <view class="flex items-center justify-between">
                <view class="flex items-center">
                    <view class="rounded-full mr-2" style="width: 4rpx; height: 18rpx; background: linear-gradient(180deg, #E9D88B 0%, #c4af68 100%)"></view>
                    <text class="font-bold" style="font-size: 30rpx; color: #1f2937;">收益明细</text>
                </view>
                <view class="flex items-center gap-1 text-xs px-3 py-1.5 rounded-full"
                    style="background: #FFF7ED; color:#c2410c;"
                    @click="redirect({ url: '/addon/tk_wifi/pages/fee/records' })">
                    <up-icon name="search" size="12" color="#c2410c"></up-icon>
                    <text>连接/未发放明细</text>
                </view>
            </view>
        </view>

        <!-- 收益明细列表 -->
        <mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="getFeeListFn">
            <template v-if="list && list.length > 0">
                <view v-for="(item, index) in list" :key="index"
                    class="mx-4 mt-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-50">
                    <view class="flex items-center gap-3">
                        <view
                            class="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                            style="background: linear-gradient(135deg, rgba(233,216,139,0.15) 0%, rgba(233,216,139,0.05) 100%); border: 1px solid rgba(233,216,139,0.25);">
                            <up-icon name="wifi" size="21" color="#C4AF68"></up-icon>
                        </view>
                        <view class="flex-1 min-w-0">
                            <text class="block truncate leading-relaxed" style="color: #1f2937; font-size: 28rpx; font-weight: 500;">{{
                                item?.wifi_name || item?.name || '-' }}</text>
                            <text class="block mt-1" style="color: #9ca3af; font-size: 24rpx;">{{ item.create_time ?
                                formatTime(item.create_time) : '-' }}</text>
                        </view>
                        <view class="shrink-0 ml-2">
                            <text class="font-bold" style="font-size: 28rpx; color: #16a34a;">
                                +¥{{ moneyFormat(item.own_fee || 0) }}
                            </text>
                        </view>
                    </view>
                </view>
            </template>
            <up-empty v-else-if="list && list.length == 0" mode="list" text="暂无收益记录" class="py-12"></up-empty>
        </mescroll-body>

        <tabbar addon="tk_wifi" />
    </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { img, moneyFormat, handleOnloadParams, redirect } from '@/utils/common';
import useMemberStore from '@/stores/member';
import { onLoad, onPageScroll, onReachBottom } from '@dcloudio/uni-app';
import MescrollBody from '@/components/mescroll/mescroll-body/mescroll-body.vue';
import useMescroll from '@/components/mescroll/hooks/useMescroll.js';
import { getFeeStat, getFeeList } from '@/addon/tk_wifi/api/wifi';

const { mescrollInit, downCallback, getMescroll } = useMescroll(onPageScroll, onReachBottom);

const memberStore = useMemberStore();
const info = computed(() => memberStore.info);

const statInfo = ref<any>();
const list = ref<any[]>([]);
const loading = ref(false);

// 提现
const applyCashOut = () => {
    uni.setStorageSync('cashOutAccountType', 'commission')
    redirect({ url: '/app/pages/member/apply_cash_out' })
}

// 获取收益统计
const getStatInfo = async () => {
    try {
        const res = await getFeeStat();
        statInfo.value = res.data;
    } catch (e) {
        console.log('getFeeStat error:', e);
    }
};
getStatInfo();

// 获取店主收益明细列表
const getFeeListFn = (mescroll: any) => {
    loading.value = true;
    const data = {
        page: mescroll.num,
        limit: mescroll.size,
        type: 'own'
    };
    getFeeList(data)
        .then((res) => {
            const newArr = res.data.data as Array<any>;
            mescroll.endSuccess(newArr.length);
            if (mescroll.num == 1) {
                list.value = [];
            }
            list.value = list.value.concat(newArr);
            loading.value = false;
        })
        .catch(() => {
            loading.value = false;
            mescroll.endErr();
        });
};

// 格式化时间
const formatTime = (time: any): string => {
    if (!time) return '-';
    let t = Number(time);
    if (!t) return String(time);
    if (t < 1e12) t = t * 1000;
    const d = new Date(t);
    const pad = (n: number) => n < 10 ? '0' + n : '' + n;
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

onLoad((option) => {
    // #ifdef MP-WEIXIN
    option = handleOnloadParams(option);
    // #endif
});
</script>

<style lang="scss" scoped>
@import '@/addon/tk_wifi/utils/styles/common.scss';

page {
    background-color: #F5F5F5;
}

::-webkit-scrollbar {
    display: none;
    width: 0;
    height: 0;
    color: transparent;
}

.mescroll-upwarp { min-height: 0rpx; }

.mescroll-empty { min-height: 0rpx; }
</style>