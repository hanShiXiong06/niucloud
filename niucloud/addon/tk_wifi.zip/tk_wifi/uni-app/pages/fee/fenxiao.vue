<template>
    <view class="min-h-screen" :style="'background-color: #F7F8FA; ' + themeColor()" v-if="memberStore.info">
        <!-- 顶部用户信息区域 -->
        <view class="px-4 pt-2 pb-5">
        
            <!-- 收益统计主卡片 -->
            <view class="rounded-2xl overflow-hidden shadow-lg relative"
                style="background: linear-gradient(145deg, rgba(58,59,53,1) 0%, rgba(47,48,43,1) 60%, rgba(42,43,38,1) 100%); box-shadow: 0 4rpx 16rpx rgba(0,0,0,0.15);">
                <view class="p-5 pb-6">
                    <view class="flex items-center justify-between">
                        <view class="cursor-pointer flex-1" style="opacity: 0.8;" :style="{'--tw-opacity': '0.8'}">
                            <view class="flex items-center" style="gap: 6rpx; margin-bottom: 10rpx;">
                                <up-icon name="share" size="15" color="#9A9B8A"></up-icon>
                                <text style="color: #9A9B8A; font-size: 24rpx;">推广收益</text>
                            </view>
                            <text style="display: block; margin-top: 8rpx; color: #ffffff; font-size: 40rpx; font-weight: bold; letter-spacing: -0.5rpx;">
                                {{ statInfo ? moneyFormat(statInfo.fenxiao_total || 0) : '0.00' }}
                            </text>
                        </view>

                        <view style="width: 1px; height: 56rpx; background: linear-gradient(to bottom, rgba(255,255,255,0.2) 0%, rgba(255,255,255,0.1) 50%, transparent 100%); margin: 0 20rpx;"></view>

                        <view class="flex-1">
                            <view class="flex items-center" style="gap: 6rpx; margin-bottom: 10rpx;">
            
                                <text style="color: #9A9B8A; font-size: 24rpx;">可提现金额</text>
                            </view>
                            <text style="display: block; margin-top: 8rpx; color: #ffffff; font-size: 40rpx; font-weight: bold; letter-spacing: -0.5rpx;">
                                {{ memberStore.info ? moneyFormat(memberStore.info.commission) : '0.00' }}
                            </text>
                        </view>

                        <view @click="applyCashOut()"
                            class="ml-3 shrink-0 relative">
                            <view
                                class="relative px-5 rounded-full text-sm font-bold shadow-md"
                                style="padding-top: 10rpx; padding-bottom: 10rpx; color: #3a3828; background: linear-gradient(135deg, #F0E4A8 0%, #E9D88B 50%, #DFD08A 100%);">
                                去提现
                            </view>
                        </view>
                    </view>
                </view>
                <!-- 底部装饰光效 -->
                <view class="absolute bottom-0" style="left: 50%; transform: translateX(-50%); width: 66%; height: 24rpx; background: rgba(233,216,139,0.08); border-radius: 9999px; filter: blur(16rpx);"></view>
            </view>
        </view>

        <!-- 推广明细区域标题 -->
        <view class="px-4 mb-1">
            <view class="flex items-center justify-between">
                    <view class="flex items-center">
                    <view class="rounded-full mr-2" style="width: 4rpx; height: 18rpx; background: linear-gradient(180deg, #E9D88B 0%, #c4af68 100%)"></view>
                    <text class="font-bold" style="font-size: 30rpx; color: #1f2937;">推广明细</text>
                </view>
                <view class="flex items-center gap-1 text-gray-400 text-xs px-3 py-1.5 rounded-full" style="background: #F5F5F5;">
                    <text>共</text>
                    <text class="font-medium text-gray-600">{{ statInfo?.fenxiao_num || 0 }}</text>
                    <text>笔记录</text>
                </view>
            </view>
        </view>

        <!-- 推广明细筛选区域 -->
        <view class="mx-4 bg-white rounded-2xl p-4 shadow-sm border border-gray-100">
            <!-- 直推/间推切换 -->
            <view class="flex gap-3 mb-4">
            <view @click="typeChange('first')"
                class="flex-1 rounded-xl p-3 cursor-pointer"
                :style="type == 'first' ? 'background: #fff7ed; box-shadow: 0 0 0 1px rgba(251,146,60,0.3);' : 'background: #F7F8FA;'">
                <text class="text-xs" :style="type == 'first' ? 'color: #ea580c; font-weight: 500;' : 'color: #6b7280;'">直推收益</text>
                <view class="flex items-baseline mt-1">
                    <text class="text-lg font-bold" :style="type == 'first' ? 'color: #ea580c;' : 'color: #1f2937;'">{{ moneyFormat(statInfo?.first_total || 0) }}</text>
                        <text style="font-size: 20rpx; color: #9ca3af; margin-left: 4rpx;">{{ statInfo?.first_num || 0 }}笔</text>
                    </view>
                </view>
            <view @click="typeChange('second')"
                class="flex-1 rounded-xl p-3 cursor-pointer"
                :style="type == 'second' ? 'background: #eff6ff; box-shadow: 0 0 0 1px rgba(59,130,246,0.3);' : 'background: #F7F8FA;'">
                <text class="text-xs" :style="type == 'second' ? 'color: #2563eb; font-weight: 500;' : 'color: #6b7280;'">间推收益</text>
                <view class="flex items-baseline mt-1">
                    <text class="text-lg font-bold" :style="type == 'second' ? 'color: #2563eb;' : 'color: #1f2937;'">{{ moneyFormat(statInfo?.second_total || 0) }}</text>
                        <text style="font-size: 20rpx; color: #9ca3af; margin-left: 4rpx;">{{ statInfo?.second_num || 0 }}笔</text>
                    </view>
                </view>
            </view>

            <!-- 类型筛选 -->
            <view class="flex gap-2">
                <view v-for="(item, index) in typeList" :key="index"
                    class="shrink-0 px-4 py-1.5 rounded-full text-xs font-medium cursor-pointer"
                    :style="type == item.type ? 'color: #ffffff; background: linear-gradient(135deg, #E9D88B 0%, #c4af68 100%); box-shadow: 0 2rpx 8rpx rgba(0,0,0,0.1);' : 'background: #F5F5F5; color: #6b7280;'"
                    @click="typeChange(item.type)">
                    <text>{{ item.name }}</text>
                </view>
            </view>
        </view>

        <!-- 收益明细列表 -->
        <mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="getFeeListFn">
            <template v-if="list && list.length > 0">
                <view v-for="(item, index) in list" :key="index"
                    class="mx-4 mt-3 p-4 bg-white rounded-2xl shadow-sm border border-gray-50">
                    <view class="flex items-center gap-3">
                        <view class="w-11 h-11 rounded-xl flex items-center justify-center shrink-0"
                            style="background: linear-gradient(135deg, rgba(233,216,139,0.15) 0%, rgba(233,216,139,0.05) 100%); border: 1px solid rgba(233,216,139,0.25);">
                            <up-icon name="share" size="20" color="#C4AF68"></up-icon>
                        </view>
                        <view class="flex-1 min-w-0">
                            <text>{{ item?.wifi_id_name || '-'}}</text>
                            <text class="block truncate leading-relaxed" style="color: #1f2937; font-size: 28rpx; font-weight: 500;">{{
                                item?.wifi_name || item?.name || '-' }}</text>
                        </view>
                        <view class="shrink-0">
                            <text v-if="Number(item.first_fee || 0) > 0 && item.first_member_id == memberId"
                                class="rounded-full font-medium bg-emerald-50 text-emerald-600" style="padding: 4rpx 10rpx; font-size: 22rpx;">直推</text>
                            <text v-else-if="Number(item.second_fee || 0) > 0 && item.second_member_id == memberId"
                                class="rounded-full font-medium bg-blue-50 text-blue-600" style="padding: 4rpx 10rpx; font-size: 22rpx;">间推</text>
                        </view>
                    </view>
                    <view class="flex justify-between items-center mt-3 pt-3 border-t border-dashed border-gray-100">
                        <text style="color: #9ca3af; font-size: 24rpx;">{{ item.create_time ? formatTime(item.create_time) : '-' }}</text>
                        <text class="font-semibold" style="font-size: 28rpx; color: #16a34a;">
                            +¥{{ getProfitAmount(item) }}
                        </text>
                    </view>
                </view>
            </template>
            <up-empty v-else-if="list && list.length == 0" mode="list" text="暂无推广收益记录" class="py-12"></up-empty>
        </mescroll-body>

        <tabbar addon="tk_wifi" />
    </view>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { img, moneyFormat, handleOnloadParams, redirect } from '@/utils/common';
import useMemberStore from '@/stores/member';
import { onLoad, onPageScroll, onReachBottom } from '@dcloudio/uni-app';
import MescrollBody from '@/components/mescroll/mescroll-body/mescroll-body.vue';
import useMescroll from '@/components/mescroll/hooks/useMescroll.js';
import { getFeeStat, getFeeList } from '@/addon/tk_wifi/api/wifi';

const { mescrollInit, downCallback, getMescroll } = useMescroll(onPageScroll, onReachBottom);

const memberStore = useMemberStore();
const info = computed(() => memberStore.info);
const memberId = computed(() => memberStore.info?.member_id || 0);

const statInfo = ref<any>();
const list = ref<any[]>([]);
const loading = ref(false);

const typeList = ref([
    { name: '全部', type: 'fenxiao' },
    { name: '直推', type: 'first' },
    { name: '间推', type: 'second' }
]);
const type = ref('fenxiao');

// 提现
const applyCashOut = () => {
    uni.setStorageSync('cashOutAccountType', 'commission')
    redirect({ url: '/app/pages/member/apply_cash_out' })
}

const typeChange = (e: string) => {
    type.value = e;
    list.value = [];
    getMescroll().resetUpScroll();
};

// 获取收益统计
const getStatInfo = async () => {
    try {
        const res = await getFeeStat();
        statInfo.value = res.data;
    } catch (e) {
        console.log('getFeeStat error:', e);
    }
};
getStatInfo();

// 获取推广收益明细列表
const getFeeListFn = (mescroll: any) => {
    loading.value = true;
    const data = {
        page: mescroll.num,
        limit: mescroll.size,
        type: type.value
    };
    getFeeList(data)
        .then((res) => {
            const newArr = res.data.data as Array<any>;
            mescroll.endSuccess(newArr.length);
            if (mescroll.num == 1) {
                list.value = [];
            }
            list.value = list.value.concat(newArr);
            loading.value = false;
        })
        .catch(() => {
            loading.value = false;
            mescroll.endErr();
        });
};

// 获取当前会员在该记录中的收益金额
const getProfitAmount = (item: any): string => {
    if (Number(item.first_fee || 0) > 0 && item.first_member_id == memberId.value) {
        return moneyFormat(item.first_fee);
    }
    if (Number(item.second_fee || 0) > 0 && item.second_member_id == memberId.value) {
        return moneyFormat(item.second_fee);
    }
    return '0.00';
};

// 获取收益颜色
const getProfitColor = (item: any): string => {
    if (Number(item.first_fee || 0) > 0 && item.first_member_id == memberId.value) return 'text-emerald-600';
    if (Number(item.second_fee || 0) > 0 && item.second_member_id == memberId.value) return 'text-blue-600';
    return 'text-gray-600';
};

// 图标背景
const getTypeBgClass = (item: any): string => {
    if (Number(item.first_fee || 0) > 0 && item.first_member_id == memberId.value) return 'bg-emerald-50';
    if (Number(item.second_fee || 0) > 0 && item.second_member_id == memberId.value) return 'bg-blue-50';
    return 'bg-gray-50';
};

// 图标颜色
const getTypeIconColor = (item: any): string => {
    if (Number(item.first_fee || 0) > 0 && item.first_member_id == memberId.value) return '#34d399';
    if (Number(item.second_fee || 0) > 0 && item.second_member_id == memberId.value) return '#60a5fa';
    return '#9ca3af';
};

// 格式化时间
const formatTime = (time: any): string => {
    if (!time) return '-';
    let t = Number(time);
    if (!t) return String(time);
    if (t < 1e12) t = t * 1000;
    const d = new Date(t);
    const pad = (n: number) => n < 10 ? '0' + n : '' + n;
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

onLoad((option) => {
    // #ifdef MP-WEIXIN
    option = handleOnloadParams(option);
    // #endif
});
</script>

<style lang="scss" scoped>
@import '@/addon/tk_wifi/utils/styles/common.scss';

page {
    background-color: #F7F8FA;
}

::-webkit-scrollbar {
    display: none;
    width: 0;
    height: 0;
    color: transparent;
}

.mescroll-upwarp { min-height: 0rpx; }

.mescroll-empty { min-height: 0rpx; }
</style>