<template>
    <view class="min-h-screen bg-gray-50" :style="themeColor()" v-if="wifi">
        <!-- #ifdef MP-WEIXIN -->
        <view class="p-4 bg-white mt-2 rounded-lg shadow-sm mx-2">
            <!-- WiFi信息卡片 - 微信小程序头部 -->
            <view class="flex items-center justify-between mb-4">
                <view>
                    <view class="text-[36rpx] font-bold text-gray-800">{{ wifi.wifi_name }}</view>
                    <view class="text-blue-400 text-xs mt-1 flex items-center">
                        <view class="w-2 h-2 rounded-full mr-1" :class="isWifiEnabled ? 'bg-green-500' : 'bg-red-500'">
                        </view>
                        {{ wifiStatusText }}
                    </view>
                </view>
                <view v-if="!isWifiEnabled">
                    <button
                        class="px-4 py-1.5 rounded-full bg-[var(--primary-color)] text-white text-sm font-medium shadow-sm"
                        @click="showWifiTips">查看帮助</button>
                </view>
            </view>
        </view>
        <!-- #endif -->

        <!-- #ifdef H5 -->
        <!-- H5环境下的简洁标题 -->
        <view class="px-3 py-2 bg-white shadow-sm mb-2">
            <view class="text-[32rpx] font-medium text-gray-700 flex items-center">
                <up-icon name="home" size="16" color="var(--primary-color)" class="mr-2"></up-icon>
                {{ wifi.wifi_name }}
            </view>
        </view>
        <!-- #endif -->


        <!-- #ifdef MP-WEIXIN -->
        <view class="mb-5 mx-2">
            <!-- WiFi信息区域 - 优化布局 (微信小程序) -->
            <view class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                <!-- WiFi名称 -->
                <view class="flex items-center mb-4">
                    <view class="text-sm text-gray-500 w-20">名称</view>
                    <view class="font-medium text-[32rpx] text-gray-800">{{ wifi.wifi_name }}</view>
                </view>

                <!-- WiFi密码区域 -->
                <view class="flex items-center">
                    <view class="text-sm text-gray-500 w-20">密码</view>
                    <view
                        class="flex-1 bg-white rounded-lg p-3 flex items-center justify-between border border-gray-100">
                        <view class="flex-1 mr-2 overflow-hidden">
                            <view class="text-[32rpx] font-medium block w-full" :class="{ 'truncate': !showPassword }">
                                <text v-if="showPassword && (is_view_adv || config?.type !== 'adv')">{{
                                    wifi.wifi_password }}</text>
                                <text v-else-if="showPassword && !is_view_adv && config?.type === 'adv'"
                                    class="text-gray-400">观看广告后可查看</text>
                                <text v-else>{{ maskPassword }}</text>
                            </view>
                        </view>
                        <view class="w-4 h-8 rounded-full bg-blue-50 flex items-center justify-center flex-shrink-0"
                            @click="handlePasswordAction">
                            <text class="text-blue-500 text-base">{{ showPassword ? '👁️' : '👁️‍🗨️' }}</text>
                        </view>
                    </view>
                    <view class="ml-1 px-3 py-2 rounded-lg text-sm flex items-center"
                        :style="{ backgroundColor: 'var(--primary-color)', color: '#ffffff' }"
                        @click="handleCopyPassword">
                        <text class="text-sm">{{ (config?.type === 'adv' && !is_view_adv) ? '观看广告' : '复制' }}</text>
                    </view>
                </view>
            </view>
        </view>
        <!-- #endif -->

        <!-- #ifdef H5 -->
        <!-- H5环境下的紧凑卡片式WiFi信息显示 -->
        <view class="mx-3 mt-2">
            <view class="bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                <!-- 查看教程链接 - 移到最顶部 -->
                <view class="flex mb-3">
                    <view class="flex items-center text-blue-500 text-sm" @click="showH5ConnectTips"><up-icon
                            name="info-circle" size="14" color="var(--primary-color)" class="mr-1"></up-icon><text
                            class="text-sm">查看连接教程</text></view>
                </view>

                <!-- WiFi名称和密码 -->
                <view class="flex items-center mb-3">
                    <view class="w-8 h-8 rounded-full bg-green-50 flex items-center justify-center mr-3">
                        <up-icon name="wifi" size="20" color="var(--primary-color)"></up-icon>
                    </view>
                    <view class="flex-1">
                        <view class="text-[34rpx] font-medium text-gray-800">{{ wifi.wifi_name }}</view>
                        <view class="text-xs text-gray-500 mt-0.5">WiFi名称</view>
                    </view>
                </view>

                <view class="flex items-center mb-4">
                    <view class="w-8 h-8 rounded-full bg-blue-50 flex items-center justify-center mr-3">
                        <up-icon name="lock" size="18" color="var(--primary-color)"></up-icon>
                    </view>
                    <view class="flex-1">
                        <view class="text-[34rpx] font-medium text-gray-800 word-break">{{ wifi.wifi_password }}</view>
                        <view class="text-xs text-gray-500 mt-0.5">WiFi密码</view>
                    </view>
                    <view class="ml-2 px-3 py-1.5 rounded-lg text-sm flex items-center flex-shrink-0"
                        :style="{ backgroundColor: 'var(--primary-color)', color: '#ffffff' }"
                        @click="handleCopyPassword">
                        <text class="text-sm">复制</text>
                    </view>
                </view>

                <!-- 复制按钮 -->
                <view class="flex justify-center">
                    <view
                        class="flex items-center w-full justify-center rounded-lg py-2.5 shadow-sm bg-[var(--primary-color)] text-white"
                        @click="handleCopyPassword">
                        <up-icon name="file-text" size="18" color="#ffffff" class="mr-2"></up-icon>
                        <text class="text-sm">复制WiFi密码</text>
                    </view>
                </view>

                <!-- 删除原来底部的查看教程链接 -->
            </view>
        </view>
        <!-- #endif -->

        <!-- #ifdef MP-WEIXIN -->
        <!-- WiFi图标 (微信小程序) -->
        <view class="flex flex-col items-center justify-center my-6">
            <view class="relative mb-2">
                <up-icon name="wifi" size="80" color="var(--primary-color)"></up-icon>
            </view>
            <!-- 状态文本 -->
            <view class="text-center" v-if="isWifiEnabled">
                <view class="text-center text-sm text-gray-600">
                    {{ connecting ? '正在尝试连接...' : '点击下方按钮连接WiFi' }}
                </view>
            </view>
        </view>
        <!-- #endif -->

        <!-- #ifdef MP-WEIXIN -->
        <!-- 连接状态提示 - 仅微信小程序 -->
        <view v-if="connecting"
            class="bg-blue-50 rounded-xl p-4 mb-4 flex items-center justify-center border border-blue-100">
            <view class="w-5 h-5 rounded-full border-2 border-t-transparent border-blue-500 animate-spin mr-3">
            </view>
            <text class="text-blue-600 font-medium">正在连接WiFi...</text>
        </view>

        <!-- 连接按钮 - 仅在微信小程序环境下显示 -->
        <view class="flex justify-center mb-4 mx-2">
            <view class="flex items-center w-full justify-center rounded-xl py-3.5 shadow-sm" :style="{
                backgroundColor: getConnectButtonBgColor(),
                color: '#ffffff',
                opacity: '1'
            }" @click="isWifiEnabled ? connectWifi() : showWifiTips()">
                <up-icon name="wifi" size="20" color="#ffffff" class="mr-2"></up-icon>
                <text class="text-base font-medium">{{ getConnectButtonText() }}</text>
            </view>
        </view>
        <!-- #endif -->
        <!-- #ifdef MP-WEIXIN -->
        <!-- 小程序隐私协议 -->
        <wx-privacy-popup ref="wxPrivacyPopupRef"></wx-privacy-popup>
        <!-- #endif -->
        <tabbar :tabbar="tk_wifi" />
    </view>

</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { onLoad, onShow } from '@dcloudio/uni-app'
import { getWifiInfo, getConfig, addContact, reportAd } from '@/addon/tk_wifi/api/wifi'
import { diyRedirect, handleOnloadParams, redirect } from '@/utils/common'
interface WifiInfo {
    id: string | number;
    name: string;
    wifi_name: string;
    wifi_password: string;
}

interface ConfigInfo {
    theme_color?: string;
    type?: string; // 'normal' or 'adv'
    adv_id?: string; // 激励广告单元ID
    link?: any; // 连接成功后跳转链接
}

interface Options {
    id?: string;
}

interface SystemInfoResult {
    wifiEnabled?: boolean;
    platform?: string;
    [key: string]: any;
}

// #ifdef APP-PLUS
declare const plus: {
    os: {
        name: string;
        version: string;
    };
    android: {
        importClass: (className: string) => any;
        runtimeMainActivity: () => any;
    };
    runtime: {
        openURL: (url: string) => void;
    };
};
// #endif

// #ifdef MP-WEIXIN
declare const wx: {
    startWifi: (options: any) => void;
    connectWifi: (options: any) => void;
    openSystemBluetoothSetting: (options: any) => void;
    getSystemInfo: (options: any) => void;
    setClipboardData: (options: any) => void;
    showModal: (options: any) => void;
    showToast: (options: any) => void;
    getSetting: (options: any) => void;
    openSetting: (options: any) => void;
    authorize: (options: any) => void;
    createRewardedVideoAd: (options: { adUnitId: string }) => any;
    onLoad: (callback: () => void) => void;
    onError: (callback: (err: any) => void) => void;
    onClose: (callback: (res: any) => void) => void;
};
// #endif

// 声明uni.getConnectedWifi的接口
declare module '@dcloudio/uni-app' {
    interface Uni {
        getConnectedWifi(options: {
            success?: (result: { wifi?: { SSID: string } }) => void;
            fail?: (error: any) => void;
        }): void;
    }
}

const wifi = ref<WifiInfo | null>(null)
const config = ref<ConfigInfo | null>(null)
const wifiStatus = ref<number>(0) // 0: 未知, 1: 已开启, 2: 未开启
const isWifiEnabled = ref(false) // 改为ref而不是computed
const wifiStatusText = computed(() => {
    switch (wifiStatus.value) {
        case 0: return '状态: 未知';
        case 1: return '状态: 已开启';
        case 2: return '状态: 未开启';
        default: return '状态: 未知';
    }
})

// 平台检测
const isMiniProgram = ref(false)
const hasWifiAuth = ref(false)
const hasLocationAuth = ref(false)
const hasPhoneAuth = ref(false)
const connecting = ref(false)

// 广告相关变量
const is_view_adv = ref(false)
const adUnitId = ref('')
const videoAd = ref<any>(null)
const currentAction = ref<string>('') // 'connect', 'copy', 'view'
const autoConnectAfterAd = ref(false) // 是否在广告结束后自动连接

// 本地缓存相关
const VIEWED_ADS_STORAGE_KEY = 'tk_wifi_viewed_ads'

// 检查是否已观看过广告
const checkViewedAds = (wifiId: string | number) => {
    try {
        const viewedAdsStr = uni.getStorageSync(VIEWED_ADS_STORAGE_KEY)
        if (viewedAdsStr) {
            const viewedAds = JSON.parse(viewedAdsStr)
            return viewedAds.includes(String(wifiId))
        }
    } catch (e) {
        console.error('读取广告缓存失败', e)
    }
    return false
}

// 保存已观看广告记录(仅用于UI:控制是否需要再次观看广告;不再作为是否发佣金的开关)
const saveViewedAd = (wifiId: string | number) => {
    try {
        let viewedAds: string[] = []
        const viewedAdsStr = uni.getStorageSync(VIEWED_ADS_STORAGE_KEY)

        if (viewedAdsStr) {
            viewedAds = JSON.parse(viewedAdsStr)
        }

        if (!viewedAds.includes(String(wifiId))) {
            viewedAds.push(String(wifiId))
            uni.setStorageSync(VIEWED_ADS_STORAGE_KEY, JSON.stringify(viewedAds))
        }
    } catch (e) {
        console.error('保存广告缓存失败', e)
    }
}

// 广告/连接链路上报(发佣金由服务端按真实状态决定,localStorage 不再拦截)
// action: view=开始观看 complete=看完 exit=中途退出 nofill=无广告填充 fallback=异常放行 connect=普通连接
const reportAdStatus = (action: string) => {
    if (!wifi.value?.id) return
    reportAd(wifi.value.id, action).catch(err => {
        console.error('广告状态上报失败', action, err)
    })
}

// 初始化广告
const initAd = () => {
    // #ifdef MP-WEIXIN
    if (config.value?.adv_id && !videoAd.value) {
        try {
            adUnitId.value = config.value.adv_id
            videoAd.value = wx.createRewardedVideoAd({
                adUnitId: adUnitId.value
            })

            videoAd.value.onLoad(() => {
                console.log('激励广告加载成功')
            })

            videoAd.value.onError(() => {
                // 广告加载失败静默处理，errCode -10000 表示当前无广告资源
            })
        } catch (e) {
            console.error('初始化广告组件失败', e)
            // 初始化失败时，允许用户直接操作
            is_view_adv.value = true

            if (wifi.value?.id) {
                saveViewedAd(wifi.value.id) // 记录为已观看
            }
        }

        try {
            videoAd.value.onClose((res: any) => {
                // 用户点击了【关闭广告】按钮
                if (res && res.isEnded) {
                    // 正常播放结束，可以下发奖励
                    is_view_adv.value = true

                    // 上报"看完",由服务端结算佣金
                    reportAdStatus('complete')

                    // 保存已观看广告记录(仅UI)
                    if (wifi.value?.id) {
                        saveViewedAd(wifi.value.id)
                    }

                    // 根据当前操作执行相应动作
                    if (currentAction.value === 'connect' || autoConnectAfterAd.value) {
                        doConnectWifi()
                        autoConnectAfterAd.value = false
                    } else if (currentAction.value === 'copy') {
                        doCopyPassword()
                    } else if (currentAction.value === 'view') {
                        setTimeout(() => {
                            showPassword.value = true
                        }, 300)
                    }

                    currentAction.value = ''
                } else {
                    // 播放中途退出，不下发奖励
                    reportAdStatus('exit')
                    uni.showToast({
                        title: '需要完整观看广告才能解锁功能',
                        icon: 'none'
                    })
                    currentAction.value = ''
                    autoConnectAfterAd.value = false
                }
            })
        } catch (e) {
            console.error('注册广告关闭事件失败', e)
            // 异常情况下允许用户直接操作
            is_view_adv.value = true

            if (wifi.value?.id) {
                saveViewedAd(wifi.value.id) // 记录为已观看
            }
        }
    }
    // #endif
}

// 显示广告
const showAd = (action: string) => {
    currentAction.value = action

    // 检查是否已观看过广告
    if (wifi.value?.id && checkViewedAds(wifi.value.id)) {
        is_view_adv.value = true
        console.log('已观看过该WiFi的广告，无需再次观看')

        // 仍上报一次连接,由服务端决定是否(超过1小时)再次计佣
        reportAdStatus('connect')

        // 直接执行对应操作
        if (currentAction.value === 'connect' || autoConnectAfterAd.value) {
            doConnectWifi()
            autoConnectAfterAd.value = false
        } else if (currentAction.value === 'copy') {
            doCopyPassword()
        } else if (currentAction.value === 'view') {
            setTimeout(() => {
                showPassword.value = true
            }, 300)
        }

        currentAction.value = ''
        return
    }

    // #ifdef MP-WEIXIN
    if (videoAd.value) {
        try {
            // 重新加载广告以确保可用
            videoAd.value.load()
                .then(() => {
                    // 加载成功后显示广告，上报"开始观看"
                    reportAdStatus('view')
                    return videoAd.value.show()
                })
                .catch(() => {
                    // 广告加载/显示失败静默处理，errCode -10000 表示当前无广告资源
                    is_view_adv.value = true
                    // 无广告填充:仍放行并上报，由服务端按配置结算
                    reportAdStatus('nofill')
                    const fallbackAction = currentAction.value
                    const autoConnect = autoConnectAfterAd.value
                    setTimeout(() => {
                        if (fallbackAction === 'connect' || autoConnect) {
                            doConnectWifi()
                        } else if (fallbackAction === 'copy') {
                            doCopyPassword()
                        } else if (fallbackAction === 'view') {
                            showPassword.value = true
                        }
                    }, 300)

                    autoConnectAfterAd.value = false
                    currentAction.value = ''

                    // 保存已观看广告记录，即使失败也算观看过
                    if (wifi.value?.id) {
                        saveViewedAd(wifi.value.id)
                    }
                })
        } catch (e) {
            // 广告加载异常静默处理，允许用户直接操作
            is_view_adv.value = true
            // 异常放行,上报由服务端按配置结算
            reportAdStatus('fallback')
            const fallbackAction = currentAction.value
            const autoConnect = autoConnectAfterAd.value
            setTimeout(() => {
                if (fallbackAction === 'connect' || autoConnect) {
                    doConnectWifi()
                } else if (fallbackAction === 'copy') {
                    doCopyPassword()
                } else if (fallbackAction === 'view') {
                    showPassword.value = true
                }
            }, 300)

            autoConnectAfterAd.value = false
            currentAction.value = ''

            // 保存已观看广告记录，即使异常也算观看过
            if (wifi.value?.id) {
                saveViewedAd(wifi.value.id)
            }
        }
    } else {
        // 广告组件不存在时，允许用户直接操作
        is_view_adv.value = true
        // 无广告组件:仍上报,由服务端按配置结算
        reportAdStatus('nofill')
        // 根据当前操作执行相应动作
        if (currentAction.value === 'connect' || autoConnectAfterAd.value) {
            doConnectWifi()
            autoConnectAfterAd.value = false
        } else if (currentAction.value === 'copy') {
            doCopyPassword()
        } else if (currentAction.value === 'view') {
            setTimeout(() => {
                showPassword.value = true
            }, 300)
        }

        currentAction.value = ''

        // 保存已观看广告记录，即使失败也算观看过
        if (wifi.value?.id) {
            saveViewedAd(wifi.value.id)
        }
    }
    // #endif

    // 非小程序环境下直接设置为已观看
    // #ifndef MP-WEIXIN
    is_view_adv.value = true
    // #endif
}

// 检测当前平台
const checkPlatform = () => {
    uni.getSystemInfo({
        success: (res: SystemInfoResult) => {
            // #ifdef MP-WEIXIN
            isMiniProgram.value = true
            checkAuthStatus()
            // #endif
        }
    })
}

// 检查小程序所有权限状态
const checkAuthStatus = () => {
    // #ifdef MP-WEIXIN
    wx.getSetting({
        success: (res: { authSetting?: { [key: string]: boolean } }) => {
            if (res.authSetting) {
                // 检查位置权限
                hasLocationAuth.value = !!res.authSetting['scope.userLocation']

                // 检查WiFi权限 (位置权限是WiFi连接的前提)
                hasWifiAuth.value = hasLocationAuth.value

                // 检查手机号权限 - 微信没有直接的手机号权限检查，只能在getPhoneNumber回调中处理

                // 如果已有必要权限，并且WiFi已开启，检查是否需要自动连接
                if (hasWifiAuth.value && isWifiEnabled.value) {
                    checkCurrentWifiAndConnect()
                }
            }
        }
    })
    // #endif
}

// 获取手机号授权（小程序需要）
const getPhoneNumber = (e: any) => {
    // #ifdef MP-WEIXIN
    if (e.detail.errMsg === 'getPhoneNumber:ok') {
        // 用户同意授权手机号
        hasPhoneAuth.value = true

        // 继续请求位置权限
        requestLocationAuth()
    } else {
        // 用户拒绝授权手机号
        uni.showModal({
            title: '提示',
            content: '需要授权手机号才能使用WiFi连接功能',
            confirmText: '我知道了',
            showCancel: false
        })
    }
    // #endif
}

// 请求位置权限
const requestLocationAuth = () => {
    // #ifdef MP-WEIXIN
    wx.authorize({
        scope: 'scope.userLocation',
        success: () => {
            hasLocationAuth.value = true
            hasWifiAuth.value = true
            uni.showToast({
                title: '授权成功',
                icon: 'success'
            })

            // 授权成功后检查WiFi状态并尝试连接
            checkWifiStatus()
            if (isWifiEnabled.value) {
                // 如果WiFi已开启，检查是否需要看广告
                if (config.value?.type === 'adv' && !is_view_adv.value) {
                    autoConnectAfterAd.value = true
                    showAd('connect')
                } else {
                    // 不需要看广告，直接尝试连接
                    doConnectWifi()
                }
            } else {
                // WiFi未开启，提示用户手动开启WiFi
                showWifiTips()
            }
        },
        fail: () => {
            wx.showModal({
                title: '提示',
                content: '需要授权位置信息才能连接WiFi',
                confirmText: '去设置',
                success: (res: { confirm: boolean }) => {
                    if (res.confirm) {
                        wx.openSetting({
                            success: (settingRes: { authSetting: { [key: string]: boolean } }) => {
                                if (settingRes.authSetting['scope.userLocation']) {
                                    hasLocationAuth.value = true
                                    hasWifiAuth.value = true

                                    // 授权成功后检查WiFi状态
                                    checkWifiStatus()
                                    if (isWifiEnabled.value) {
                                        // 如果WiFi已开启，尝试连接
                                        if (config.value?.type === 'adv' && !is_view_adv.value) {
                                            autoConnectAfterAd.value = true
                                            showAd('connect')
                                        } else {
                                            doConnectWifi()
                                        }
                                    }
                                }
                            }
                        })
                    }
                }
            })
        }
    })
    // #endif
}

// 检查当前WiFi连接状态并尝试连接
const checkCurrentWifiAndConnect = () => {
    // #ifdef MP-WEIXIN
    if (!hasWifiAuth.value || !wifi.value) return

    // 如果需要看广告且还没看过
    if (config.value?.type === 'adv' && !is_view_adv.value) {
        autoConnectAfterAd.value = true
        // 直接显示广告
        showAd('connect')
        return
    }

    // 检查当前连接的WiFi
    uni.getConnectedWifi({
        success: (res: { wifi?: { SSID: string } }) => {
            if (res.wifi && res.wifi.SSID === wifi.value?.wifi_name) {
                // 已经连接到目标WiFi
                uni.showToast({
                    title: '已连接该WiFi',
                    icon: 'success'
                })

                // 如果配置了跳转链接，则跳转
                if (config.value?.link) {
                    setTimeout(() => {
                        diyRedirect(config.value?.link)
                    }, 1500)
                }
            } else {
                // 连接到了其他WiFi，尝试切换
                doConnectWifi()
            }
        },
        fail: () => {
            // 未连接WiFi，尝试连接
            doConnectWifi()
        }
    })
    // #endif
}

// 密码显示控制
const showPassword = ref(false)
const handlePasswordAction = () => {
    // #ifdef H5
    // H5环境下直接切换密码显示状态
    togglePasswordVisibility()
    // #endif

    // #ifndef H5
    if (config.value?.type === 'adv' && !is_view_adv.value) {
        // 需要观看广告
        uni.showModal({
            title: '提示',
            content: '需要观看一个短视频广告才能查看密码',
            confirmText: '观看广告',
            cancelText: '取消',
            success: (res) => {
                if (res.confirm) {
                    // 显示广告
                    showAd('view')
                }
            }
        })
    } else {
        // 直接切换密码显示状态
        togglePasswordVisibility()
    }
    // #endif
}

const togglePasswordVisibility = () => {
    const willShow = !showPassword.value
    showPassword.value = willShow

    // 非广告模式下显示密码时增加连接记录
    if (willShow && config.value?.type !== 'adv' && wifi.value?.id) {
        addContact(wifi.value.id)
    }
}

// 密码掩码
const maskPassword = computed(() => {
    if (!wifi.value?.wifi_password) return ''
    // 使用固定数量的掩码字符，不管密码长度如何
    return '••••••••'
})

// 处理复制密码
const handleCopyPassword = () => {
    if (!wifi.value?.wifi_password) return

    // #ifdef H5
    // H5环境下直接复制密码
    doCopyPassword()
    // #endif

    // #ifndef H5
    if (config.value?.type === 'adv' && !is_view_adv.value) {
        // 直接显示广告
        showAd('copy')
    } else {
        // 直接复制密码
        doCopyPassword()
    }
    // #endif
}

// 复制密码
const doCopyPassword = () => {
    if (!wifi.value?.wifi_password) return

    // 直接复制密码
    uni.setClipboardData({
        data: wifi.value.wifi_password,
        success: () => {
            uni.showToast({
                title: '密码已复制',
                icon: 'success'
            })
        }
    })
}

// 检查WiFi状态
const checkWifiStatus = () => {
    // #ifdef APP-PLUS || MP-WEIXIN
    uni.getSystemInfo({
        success: (res: SystemInfoResult) => {
            if (res.wifiEnabled !== undefined) {
                wifiStatus.value = res.wifiEnabled ? 1 : 2
                isWifiEnabled.value = res.wifiEnabled // 直接设置isWifiEnabled

                // 如果WiFi已开启且有权限，检查当前连接状态
                if (wifiStatus.value === 1 && hasWifiAuth.value && wifi.value) {
                    checkCurrentWifiAndConnect()
                }
            }
        }
    })
    // #endif
}

// 连接WiFi
const connectWifi = () => {
    // #ifndef MP-WEIXIN
    uni.showToast({
        title: '请手动连接WiFi',
        icon: 'none'
    })
    return
    // #endif

    if (!wifi.value) return

    // 检查WiFi是否开启
    if (!isWifiEnabled.value) {
        showWifiTips()
        return
    }

    // 检查是否需要观看广告
    if (config.value?.type === 'adv' && !is_view_adv.value) {
        // 直接显示广告
        autoConnectAfterAd.value = true
        showAd('connect')
    } else {
        // 继续连接WiFi
        doConnectWifi()
    }
}

// 显示手动连接提示
const showManualConnectTips = () => {
    uni.showModal({
        title: '手动连接WiFi',
        content: '请在手机设置中找到 ' + wifi.value?.wifi_name + ' 并使用密码 ' + wifi.value?.wifi_password + ' 连接',
        confirmText: '复制密码',
        cancelText: '我知道了',
        success: (res) => {
            if (res.confirm) {
                handleCopyPassword()
            }
        }
    })
}

// H5环境下显示连接步骤
const showH5ConnectTips = () => {
    // 使用简单的弹窗显示连接步骤
    const deviceType = getDeviceType()
    let steps = ''

    if (deviceType === 'iOS') {
        steps = '1. 打开iPhone的"设置"\n' +
            '2. 点击"Wi-Fi"\n' +
            '3. 确保Wi-Fi已开启\n' +
            '4. 在网络列表中找到 "' + wifi.value?.wifi_name + '"\n' +
            '5. 点击该网络名称\n' +
            '6. 输入密码: ' + wifi.value?.wifi_password + '\n' +
            '7. 点击"加入"按钮'
    } else if (deviceType === 'Android') {
        steps = '1. 打开Android手机的"设置"\n' +
            '2. 点击"网络和互联网"或"连接"\n' +
            '3. 点击"Wi-Fi"\n' +
            '4. 确保Wi-Fi已开启\n' +
            '5. 在网络列表中找到 "' + wifi.value?.wifi_name + '"\n' +
            '6. 点击该网络名称\n' +
            '7. 输入密码: ' + wifi.value?.wifi_password + '\n' +
            '8. 点击"连接"按钮'
    } else {
        steps = '1. 打开设备的WiFi设置\n' +
            '2. 确保WiFi已开启\n' +
            '3. 在网络列表中找到 "' + wifi.value?.wifi_name + '"\n' +
            '4. 点击该网络名称\n' +
            '5. 输入密码: ' + wifi.value?.wifi_password + '\n' +
            '6. 点击连接按钮'
    }

    uni.showModal({
        title: 'WiFi连接详细步骤',
        content: steps,
        confirmText: '复制密码',
        cancelText: '我知道了',
        success: (res) => {
            if (res.confirm) {
                handleCopyPassword()
            }
        }
    })
}

// 获取设备类型
const getDeviceType = () => {
    const ua = navigator.userAgent
    if (/iPhone|iPad|iPod/i.test(ua)) {
        return 'iOS'
    } else if (/Android/i.test(ua)) {
        return 'Android'
    } else {
        return 'Other'
    }
}

// 实际连接WiFi的逻辑
const doConnectWifi = () => {
    // 检查WiFi是否开启
    if (!isWifiEnabled.value) {
        showWifiTips()
        return
    }

    connecting.value = true

    // #ifdef MP-WEIXIN
    try {
        // 微信小程序连接WiFi
        wx.startWifi({
            success: () => {
                // 先检查当前是否已连接WiFi
                uni.getConnectedWifi({
                    success: (connectedRes: { wifi?: { SSID: string } }) => {
                        if (connectedRes.wifi && connectedRes.wifi.SSID === wifi.value?.wifi_name) {
                            uni.showToast({
                                title: '已连接该WiFi',
                                icon: 'success'
                            })
                            // 如果配置了跳转链接，则跳转
                            if (config.value?.link) {
                                setTimeout(() => {
                                    diyRedirect(config.value?.link)
                                }, 1500)
                            }
                            connecting.value = false
                            return
                        }

                        // 尝试连接新WiFi
                        wx.connectWifi({
                            SSID: wifi.value?.wifi_name || '',
                            password: wifi.value?.wifi_password || '',
                            success: () => {
                                uni.showToast({
                                    title: 'WiFi连接成功',
                                    icon: 'success'
                                })
                                // 如果配置了跳转链接，则跳转
                                if (config.value?.link) {
                                    setTimeout(() => {
                                        diyRedirect(config.value?.link)
                                    }, 1500)
                                }
                            },
                            fail: (err: any) => {
                                console.error(err)

                                // 处理不同的错误情况
                                let errMsg = '连接失败，请手动连接'

                                if (err.errCode === 12005) {
                                    // WiFi未开启
                                    errMsg = '请先打开WiFi开关'
                                    showWifiTips()
                                } else if (err.errCode === 12006) {
                                    // 无法自动连接，提示手动连接
                                    errMsg = '小程序无法直接连接WiFi，请手动连接'
                                    showManualConnectTips()
                                } else if (err.errCode === 12007) {
                                    errMsg = '密码错误'
                                } else if (err.errCode === 12008) {
                                    errMsg = '找不到该WiFi'
                                } else if (err.errCode === 12009) {
                                    errMsg = '连接超时'
                                } else if (err.errCode === 12011 || err.errCode === 12013) {
                                    // 用户拒绝授权或系统不支持，提示手动连接
                                    errMsg = '无法自动连接WiFi，请手动连接'
                                    showManualConnectTips()
                                }

                                uni.showToast({
                                    title: errMsg,
                                    icon: 'none'
                                })
                            },
                            complete: () => {
                                connecting.value = false
                            }
                        })
                    },
                    fail: () => {
                        // 无法获取当前连接的WiFi，提示手动连接
                        showManualConnectTips()
                        connecting.value = false
                    }
                })
            },
            fail: () => {
                uni.showToast({
                    title: '无法自动连接WiFi，请手动连接',
                    icon: 'none'
                })
                showManualConnectTips()
                connecting.value = false
            }
        })
    } catch (e) {
        console.error(e)
        uni.showToast({
            title: '连接WiFi失败，请手动连接',
            icon: 'none'
        })
        showManualConnectTips()
        connecting.value = false
    }
    // #endif

    // #ifndef MP-WEIXIN
    // 非微信小程序环境，提示用户手动连接
    uni.showModal({
        title: '手动连接WiFi',
        content: '请在设备WiFi设置中找到 ' + wifi.value?.wifi_name + ' 并使用密码 ' + wifi.value?.wifi_password + ' 连接',
        confirmText: '复制密码',
        cancelText: '我知道了',
        success: (res) => {
            if (res.confirm) {
                handleCopyPassword()
            }
        }
    })
    connecting.value = false
    // #endif
}

// 打开WiFi设置
const openWifiSettings = () => {
    // #ifdef MP-WEIXIN
    try {
        // 微信小程序无法直接打开WiFi设置，只能提示用户手动操作
        showWifiTips()
    } catch (e) {
        console.error(e)
        showWifiTips()
    }
    // #endif

    // #ifndef MP-WEIXIN
    uni.showModal({
        title: '提示',
        content: '请在设备设置中手动开启WiFi并连接到：' + (wifi.value?.wifi_name || ''),
        confirmText: '我知道了',
        showCancel: false
    })
    // #endif
}

// 显示WiFi提示
const showWifiTips = () => {
    // 显示详细的WiFi开启指南弹窗
    uni.showModal({
        title: 'WiFi未开启',
        content: '请按照以下步骤开启WiFi：\n\n1. 打开手机设置\n2. 找到并点击"WiFi"选项\n3. 打开WiFi开关\n4. 返回小程序\n\n开启后，可以连接到：' + (wifi.value?.wifi_name || ''),
        confirmText: '查看密码',
        cancelText: '我知道了',
        success: (res) => {
            if (res.confirm) {
                // 如果需要观看广告且未观看，先显示广告
                if (config.value?.type === 'adv' && !is_view_adv.value) {
                    showAd('view')
                } else {
                    // 已观看广告或不需要观看广告，直接显示密码
                    setTimeout(() => {
                        showPassword.value = true
                    }, 300)
                    // 显示密码弹窗
                    uni.showModal({
                        title: 'WiFi密码',
                        content: `WiFi: ${wifi.value?.wifi_name}\n密码: ${wifi.value?.wifi_password}`,
                        confirmText: '复制密码',
                        cancelText: '关闭',
                        success: (res) => {
                            if (res.confirm) {
                                handleCopyPassword()
                            }
                        }
                    })
                }
            }
        }
    })
}


// 获取连接按钮文本
const getConnectButtonText = () => {
    // #ifdef H5
    return '手动连接WiFi'
    // #endif

    // #ifndef H5
    if (!isWifiEnabled.value) {
        return '请先开启WiFi'
    }
    if (config.value?.type === 'adv' && !is_view_adv.value) {
        return '观看广告免费连接'
    }
    return '一键连接WiFi'
    // #endif
}

// 获取连接按钮背景颜色
const getConnectButtonBgColor = () => {
    if (!isWifiEnabled.value) {
        return '#9ca3af' // 灰色
    }
    if (config.value?.type === 'adv' && !is_view_adv.value) {
        return 'var(--primary-color)' // 主题色
    }
    return 'var(--primary-color)' // 主题色
}

// 主题颜色
const themeColor = () => {
    if (config.value?.theme_color) {
        return {
            '--primary-color': config.value.theme_color
        }
    }
    return {
        '--primary-color': '#3B82F6' // 默认蓝色
    }
}

onLoad((options: Options = {}) => {
    // #ifdef MP-WEIXIN
    // 处理小程序场景值参数
    options = handleOnloadParams(options);
    // #endif
    if (options.id) {
        getWifiInfo(options.id).then((res: any) => {
            wifi.value = res.data
            if (!wifi.value?.name) {
                uni.showToast({
                    title: 'WIFI参数未配置，请先完成配置',
                    icon: 'none'
                })
                redirect({ url: '/addon/tk_wifi/pages/wifi/list' })
            }
            // 获取配置后初始化
            getConfig().then((res: any) => {
                config.value = res.data

                // #ifdef H5
                // H5环境下自动设置为已观看广告和显示密码
                is_view_adv.value = true
                showPassword.value = true
                // 添加记录
                if (wifi.value?.id) {
                    addContact(wifi.value.id).catch(err => {
                        console.error('记录添加失败', err)
                    })
                }
                // #endif

                // #ifndef H5
                // 检查是否已观看过广告
                if (wifi.value?.id && checkViewedAds(wifi.value.id)) {
                    is_view_adv.value = true
                    console.log('已观看过该WiFi的广告，无需再次观看')
                }

                try {
                    // 初始化广告
                    initAd()
                    // 检查平台和WiFi状态
                    checkPlatform()
                    checkWifiStatus()
                } catch (e) {
                    console.error('初始化过程异常', e)
                    // 异常情况下设置为已观看，确保用户体验
                    is_view_adv.value = true
                    if (wifi.value?.id) {
                        saveViewedAd(wifi.value.id)
                    }
                }
                // #endif
            })
        })
    } else {
        uni.navigateBack()
        uni.showToast({
            title: 'wifi参数错误',
            icon: 'none'
        })
    }
})

onShow(() => {
    // 每次页面显示时检查WiFi状态
    checkWifiStatus()

    // 检查小程序权限
    if (isMiniProgram.value) {
        checkAuthStatus()
    }
})
</script>

<style lang="scss" scoped>
.wifi-icon {
    position: relative;
    width: 28px;
    height: 28px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.wifi-circle {
    position: absolute;
    border: 2px solid rgba(59, 130, 246, 0.7);
    border-radius: 50%;

    &:nth-child(1) {
        width: 8px;
        height: 8px;
        background-color: rgba(59, 130, 246, 0.7);
    }

    &:nth-child(2) {
        width: 16px;
        height: 16px;
        border-top: none;
        transform: rotate(45deg);
    }

    &:nth-child(3) {
        width: 24px;
        height: 24px;
        border-top: none;
        transform: rotate(45deg);
    }
}

@keyframes spin {
    to {
        transform: rotate(360deg);
    }
}

.animate-spin {
    animation: spin 1s linear infinite;
}
</style>
