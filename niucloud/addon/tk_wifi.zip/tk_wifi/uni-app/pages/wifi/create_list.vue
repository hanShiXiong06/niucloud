<template>
    <view class="min-h-screen bg-gray-100" :style="themeColor()">


        <mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="getWifiListFn">
            <!-- 搜索框和添加按钮 -->
            <view class="p-4 bg-white mb-2 shadow-sm">
                <view class="flex items-center justify-between gap-3">
                    <!-- 搜索框 -->
                    <view class="flex items-center bg-gray-100 rounded-full px-4 py-2 flex-1">
                        <text class="iconfont icon-search text-gray-400 mr-2"></text>
                        <input type="text" v-model="searchQuery" placeholder="请输入WiFi名称搜索" class="flex-1"
                            @confirm="handleSearch" />
                        <text class="text-gray-500" @tap="handleSearch">搜索</text>
                    </view>

                    <!-- 添加按钮 -->
                    <!-- <view @tap="handleAddWifi"
                        class="bg-[var(--primary-color)] text-white rounded-full py-1 px-4 flex items-center shadow-sm whitespace-nowrap">

                        <text>添加</text>
                    </view> -->
                </view>
            </view>
            <view class="px-3">
                <!-- WiFi列表 -->
                <view v-if="list.length > 0" v-for="item in list" :key="item.id"
                    class="bg-white rounded-lg mb-3 px-3 py-2.5 shadow-sm">
                    <view class="flex items-center">
                        <!-- 左侧内容区 -->
                        <view class="flex-1">
                            <view class="flex items-center">
                                <view class="text-[28rpx] font-bold text-gray-800 truncate">{{ item.name }}</view>
                                <view class="ml-1 bg-blue-50 text-blue-500 text-xs rounded px-1">ID:{{ item.id }}</view>
                            </view>
                            <view class="flex items-center text-[24rpx] text-gray-500 py-2">
                                <view class="mr-1">
                                    <up-icon name="wifi" size="24" color="#666"></up-icon>
                                </view>
                                <text>{{ item.wifi_name }}</text>
                            </view>
                            <view class="flex items-center text-[24rpx] text-gray-500 py-2">
                                <view class="mr-1">
                                    <up-tag :text="item.is_use == 1 ? '已绑定' : '未绑定'"
                                        :type="item.is_use == 1 ? 'primary' : 'error'" size="small"
                                        :plain="item.wifi_password.length > 4" />
                                </view>

                            </view>
                        </view>

                        <!-- 右侧二维码 -->
                        <view class="mr-2">
                            <image :src="img(item.qrcode)" mode="aspectFit" class="w-16 h-16 rounded-sm"></image>
                        </view>
                    </view>
                    <view class="flex justify-between items-center mt-2">
                        <view class="text-gray-400 text-[24rpx]">{{ item.create_time }}</view>
                        <!-- 操作按钮 -->
                        <view class="flex  border-t border-gray-100 text-[22rpx]">
                            <!-- #ifdef MP-WEIXIN -->
                            <view class="flex items-center mr-2" @tap="handlePrint(item)">
                                <view class="mr-1">
                                    <up-icon name="bookmark" size="24" color="#666"></up-icon>
                                </view>
                                <text class="text-gray-600">打印</text>
                            </view>
                            <!-- #endif -->

                            <view class="flex items-center" @tap="handleDelete(item)">
                                <view class="mr-1">
                                    <up-icon name="trash" size="24" color="#666"></up-icon>
                                </view>
                                <text class="text-gray-600">删除</text>
                            </view>

                            <view class="flex items-center ml-2" @tap="handlePreview(item)">
                                <view class="mr-1">
                                    <up-icon name="eye" size="24" color="#666"></up-icon>
                                </view>
                                <text class="text-gray-600">预览</text>
                            </view>
                        </view>
                    </view>

                </view>

                <!-- 空状态 -->
                <view v-if="loading && list.length === 0" class="py-10 flex justify-center items-center">
                    <mescroll-empty></mescroll-empty>
                </view>
            </view>
        </mescroll-body>


        <!-- 预览弹窗 -->
        <up-popup :show="showPreviewPopup" @close="showPreviewPopup = false">
            <view class="p-4">
                <view class="text-[32rpx] font-bold mb-3">WiFi 信息预览</view>

                <!-- WiFi 信息 -->
                <view class="mb-4">
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">商家名称：</text>
                        <text class="font-medium">{{ previewInfo.name }}</text>
                    </view>
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">WiFi名称：</text>
                        <text class="font-medium">{{ previewInfo.wifi_name }}</text>
                    </view>
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">WiFi密码：</text>
                        <text class="font-medium">{{ hidePassword(previewInfo.wifi_password) || '未设置' }}</text>
                    </view>

                </view>

                <!-- 二维码 -->
                <view class="flex flex-col items-center mb-4">
                    <image :src="img(previewInfo.qrcode)" mode="aspectFit" class="w-48 h-48 mb-2"></image>
                    <text class="text-gray-500 text-sm">商家首次扫码即可绑定</text>
                </view>

                <!-- 底部按钮 -->
                <view class="flex border-t border-gray-100 pt-3">
                    <view
                        class="flex-1 py-2 mr-2 text-center text-gray-600 bg-[var(--primary-color-light)] border-r rounded-xl"
                        @tap="showPreviewPopup = false">
                        关闭
                    </view>
                    <view class="flex-1 py-2 text-center text-white bg-[var(--primary-color)] rounded-xl"
                        @tap="downloadQrcode">
                        下载二维码
                    </view>
                </view>
            </view>
        </up-popup>

        <!-- 打印份数选择弹窗 -->
        <up-popup :show="showPrintCopiesPopup" @close="showPrintCopiesPopup = false">
            <view class="p-4 w-80">
                <view class="text-[32rpx] font-bold mb-3">选择打印份数</view>

                <!-- 打印份数选择器 -->
                <view class="flex items-center justify-center mb-4">
                    <view @tap="decreaseCopies"
                        class="bg-gray-200 w-10 h-10 flex items-center justify-center rounded-l-lg">
                        <text class="text-xl font-bold">-</text>
                    </view>
                    <view class="bg-gray-100 w-20 h-10 flex items-center justify-center">
                        <text class="text-xl">{{ printCopies }}</text>
                    </view>
                    <view @tap="increaseCopies"
                        class="bg-gray-200 w-10 h-10 flex items-center justify-center rounded-r-lg">
                        <text class="text-xl font-bold">+</text>
                    </view>
                </view>

                <!-- 底部按钮 -->
                <view class="flex border-t border-gray-100 pt-3">
                    <view
                        class="flex-1 py-2 mr-2 text-center text-gray-600 bg-[var(--primary-color-light)] border-r rounded-xl"
                        @tap="showPrintCopiesPopup = false">
                        取消
                    </view>
                    <view class="flex-1 py-2 text-center text-white bg-[var(--primary-color)] rounded-xl"
                        @tap="confirmPrint">
                        确认打印
                    </view>
                </view>
            </view>
        </up-popup>


        <!-- #ifdef MP-WEIXIN -->
        <!-- 小程序隐私协议 -->
        <wx-privacy-popup ref="wxPrivacyPopupRef"></wx-privacy-popup>
        <!-- #endif -->


        <!-- 添加隐藏的canvas用于lpapi-ble插件 -->
        <!-- #ifdef MP-WEIXIN -->
        <canvas type="2d" :id="lpCanvasId" :canvas-id="lpCanvasId"
            :style="{ width: labelWidth + 'px', height: labelHeight + 'px' }"
            style="position: fixed; left: -9999px; top: -9999px; visibility: hidden;" />
        <!-- #endif -->

        <!-- #ifndef MP-WEIXIN -->
        <canvas :id="lpCanvasId" :canvas-id="lpCanvasId" type="2d"
            :style="{ width: labelWidth + 'px', height: labelHeight + 'px' }"
            style="position: fixed; left: -9999px; top: -9999px; visibility: hidden;" />
        <!-- #endif -->
    </view>
</template>

<script setup lang="ts">
import { ref, reactive, onUnmounted, onMounted, computed } from "vue";
import { downloadFileEvent } from "@/addon/tk_wifi/utils/ts/common"
import { confirm } from "@/addon/tk_wifi/utils/ts/alert"
import { img, copy, redirect } from "@/utils/common";
import { getWifiCreateList, delWifiQrcode, editeWifiQrcode, addWifi } from "@/addon/tk_wifi/api/wifi";
// @ts-ignore
import MescrollBody from "@/components/mescroll/mescroll-body/mescroll-body.vue";
// @ts-ignore
import MescrollEmpty from "@/components/mescroll/mescroll-empty/mescroll-empty.vue";
// @ts-ignore
import useMescroll from "@/components/mescroll/hooks/useMescroll.js";
import { onLoad, onPageScroll, onReachBottom, onTabItemTap } from "@dcloudio/uni-app";
// @ts-ignore
const { mescrollInit, downCallback, getMescroll } = useMescroll(onPageScroll, onReachBottom);

// 引入德佟打印机SDK包装器
// #ifdef MP-WEIXIN || APP-PLUS
// 引入德佟打印机SDK
//import { LPAPIFactory } from "lpapi-ble-uni";
import { LPAPIFactory } from "@/addon/tk_wifi/components/dothan-lpapi-ble/js_sdk/index";
// #endif


// 缓存已连接的打印机信息
const connectedPrinter = ref<any>(null);

// 德佟打印机实例
let lpapi: any = null;
const lpCanvasId = ref<string>("lpapi-ble-canvas");
const labelWidth = ref<number>(384); // 打印纸宽度，根据实际打印机调整（75mm约等于384点）
const labelHeight = ref<number>(600); // 标签高度，根据实际内容调整（120mm约等于600点）
const margin = ref<number>(10); // 边距

// 获取德佟打印机SDK实例
const getLpapiInstance = (options: any): any => {
    // #ifdef MP-WEIXIN || APP-PLUS
    if (LPAPIFactory && typeof LPAPIFactory.getInstance === 'function') {
        try {
            return LPAPIFactory.getInstance(options);
        } catch (e) {
            console.error('获取德佟打印机SDK实例失败:', e);
        }
    }
    // #endif
    return null;
};

// 页面加载时初始化
onLoad(() => {
    console.log('页面加载，初始化蓝牙模块');
    // 初始化蓝牙模块
    initBluetooth();
});

// 页面挂载后初始化SDK
onMounted(() => {
    console.log('页面挂载，准备初始化德佟打印机SDK');

    // #ifdef MP-WEIXIN
    // 微信小程序环境需要获取canvas节点
    setTimeout(() => {
        uni.createSelectorQuery().select(`#${lpCanvasId.value}`).fields({ node: true, size: true }).exec(function (res) {
            if (res && res[0] && res[0].node) {
                const canvas = res[0].node;
                console.log('获取canvas节点成功');

                // 设置canvas的宽高
                canvas.width = labelWidth.value;
                canvas.height = labelHeight.value;

                // 初始化德佟打印机SDK
                lpapi = getLpapiInstance({
                    showLog: 4, // 显示所有调试日志
                    canvasId: lpCanvasId.value, // 画布ID
                    canvas: canvas // 传入canvas节点
                });

                if (lpapi) {
                    console.log('德佟打印机SDK初始化成功(微信小程序)');
                } else {
                    console.error('德佟打印机SDK初始化失败: lpapi为空');
                }
            } else {
                console.error('获取canvas节点失败');
            }
        });
    }, 500);
    // #endif

    // #ifndef MP-WEIXIN
    // 其他平台直接初始化
    lpapi = getLpapiInstance({
        showLog: 4, // 显示所有调试日志
        canvasId: lpCanvasId.value, // 画布ID
    });

    if (lpapi) {
        console.log('德佟打印机SDK初始化成功');
    } else {
        console.error('德佟打印机SDK初始化失败: lpapi为空');
    }
    // #endif
});

// 页面卸载时关闭蓝牙连接
onUnmounted(() => {
    // 关闭蓝牙连接
    if (connectedPrinter.value) {
        try {
            uni.closeBLEConnection({
                deviceId: connectedPrinter.value.deviceId
            });
            uni.closeBluetoothAdapter();
            connectedPrinter.value = null;
        } catch (e) {
            console.error('关闭蓝牙连接失败', e);
        }
    }

    // 释放德佟打印机SDK资源
    if (lpapi) {
        try {
            lpapi.quit();
        } catch (e) {
            console.error('释放德佟打印机SDK资源失败', e);
        }
    }
});



// 初始化蓝牙模块
const initBluetooth = () => {
    // #ifdef MP-WEIXIN
    try {
        console.log('开始初始化蓝牙模块');
        // 先关闭蓝牙适配器，确保状态重置
        try {
            uni.closeBluetoothAdapter({
                complete: () => {
                    console.log('蓝牙适配器已关闭，准备重新打开');
                    // 延迟重新打开蓝牙适配器
                    setTimeout(() => {
                        uni.openBluetoothAdapter({
                            success: () => {
                                console.log('蓝牙初始化成功');
                                // 蓝牙初始化成功后，可以开始搜索设备
                            },
                            fail: (error) => {
                                console.error('蓝牙初始化失败:', error);
                                // 提示用户开启蓝牙
                                uni.showModal({
                                    title: '提示',
                                    content: '请开启蓝牙功能',
                                    showCancel: false
                                });
                            }
                        });
                    }, 300);
                }
            });
        } catch (e) {
            console.error('关闭蓝牙适配器失败:', e);
            // 直接尝试打开蓝牙适配器
            uni.openBluetoothAdapter({
                success: () => {
                    console.log('蓝牙初始化成功');
                    // 蓝牙初始化成功后，可以开始搜索设备
                },
                fail: (error) => {
                    console.error('蓝牙初始化失败:', error);
                }
            });
        }
    } catch (e) {
        console.error('蓝牙初始化异常:', e);
    }
    // #endif
};

// 隐藏密码函数，显示前两位和后两位，中间用星号替代
const hidePassword = (password: string): string => {
    if (!password) return '';
    if (password.length <= 4) return password;

    const prefix = password.substring(0, 2);
    const suffix = password.substring(password.length - 2);
    const stars = '*'.repeat(password.length - 4);

    return prefix + stars + suffix;
};

const list = ref<any[]>([]);
const loading = ref<boolean>(false);
const searchQuery = ref<string>("");


// 预览弹窗相关
const showPreviewPopup = ref<boolean>(false);
const previewInfo = reactive({
    id: "",
    name: "",
    wifi_name: "",
    wifi_password: "",
    qrcode: "",
    closure: ""
});

// 获取WiFi列表
const getWifiListFn = (mescroll: any) => {
    loading.value = true;
    let data = {
        page: mescroll.num,
        limit: mescroll.size,
        keyword: searchQuery.value
    };
    getWifiCreateList(data)
        .then((res: any) => {
            let newArr = [];
            if (res && res.data && res.data.data) {
                newArr = res.data.data;

                //设置列表数据
                if (mescroll.num == 1) {
                    list.value = []; //如果是第一页需手动制空列表
                }
                list.value = [...list.value, ...newArr];
                mescroll.endSuccess(newArr.length);
            } else {
                mescroll.endErr();
            }
            loading.value = false;
        })
        .catch((error: any) => {
            loading.value = false;
            mescroll.endErr(); // 请求失败, 结束加载
        });
};



// 搜索处理
const handleSearch = () => {
    const mescroll = getMescroll();
    if (mescroll) {
        mescroll.resetUpScroll();
    }
};

// 删除处理
const handleDelete = (item: any) => {
    delWifiQrcode(item.id).then((res: any) => {
        if (res.code === 1) {
            uni.showToast({
                title: '删除成功',
                icon: 'success'
            });
            const mescroll = getMescroll();
            if (mescroll) {
                mescroll.resetUpScroll();
            }
        }
    });
};



// 预览处理
const handlePreview = (item: any) => {
    // 设置预览信息
    previewInfo.id = item.id || '';
    previewInfo.name = item.name || '';
    previewInfo.wifi_name = item.wifi_name || '';
    previewInfo.wifi_password = item.wifi_password || '';
    previewInfo.qrcode = item.qrcode || '';
    previewInfo.closure = item.closure || '';

    // 显示预览弹窗
    showPreviewPopup.value = true;
};

// 下载二维码
const downloadQrcode = () => {
    if (!previewInfo.qrcode) {
        uni.showToast({
            title: '二维码不存在',
            icon: 'none'
        });
        return;
    }

    const qrcodeUrl = img(previewInfo.qrcode);

    // #ifdef MP-WEIXIN
    // 微信小程序环境下，使用微信的保存图片到相册API
    uni.showLoading({
        title: '正在保存...',
        mask: true
    });

    // 先下载图片到本地临时文件
    uni.downloadFile({
        url: qrcodeUrl,
        success: (res) => {
            if (res.statusCode === 200) {
                // 保存图片到相册
                uni.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success: () => {
                        uni.hideLoading();
                        uni.showToast({
                            title: '已保存到相册',
                            icon: 'success'
                        });
                    },
                    fail: (err) => {
                        uni.hideLoading();
                        console.error('保存到相册失败:', err);
                        // 如果是用户拒绝授权的情况，提示用户打开权限
                        if (err.errMsg.indexOf('auth deny') >= 0 || err.errMsg.indexOf('authorize') >= 0) {
                            uni.showModal({
                                title: '提示',
                                content: '请允许保存图片到相册的权限',
                                confirmText: '去设置',
                                success: (res) => {
                                    if (res.confirm) {
                                        uni.openSetting();
                                    }
                                }
                            });
                        } else {
                            uni.showToast({
                                title: '保存失败',
                                icon: 'none'
                            });
                        }
                    }
                });
            } else {
                uni.hideLoading();
                uni.showToast({
                    title: '下载图片失败',
                    icon: 'none'
                });
            }
        },
        fail: () => {
            uni.hideLoading();
            uni.showToast({
                title: '下载图片失败',
                icon: 'none'
            });
        }
    });
    // #endif

    // #ifndef MP-WEIXIN
    // 其他平台使用通用下载函数
    downloadFileEvent(qrcodeUrl)
        .then(() => {
            uni.showToast({
                title: '下载成功',
                icon: 'success'
            });
        })
        .catch((err: any) => {
            uni.showToast({
                title: '下载失败',
                icon: 'none'
            });
        });
    // #endif
};

// 打印处理
const handlePrint = (item: any) => {
    // 保存当前要打印的项目
    currentPrintItem.value = item;

    // 显示打印份数选择弹窗
    showPrintCopiesPopup.value = true;
};

// 打印份数增加
const increaseCopies = () => {
    printCopies.value++;
};

// 打印份数减少
const decreaseCopies = () => {
    if (printCopies.value > 1) {
        printCopies.value--;
    }
};

// 确认打印
const confirmPrint = () => {
    showPrintCopiesPopup.value = false;
    if (currentPrintItem.value) {
        executePrint(currentPrintItem.value);
    }
};

// 打印份数
const printCopies = ref<number>(1);
const showPrintCopiesPopup = ref<boolean>(false);
const currentPrintItem = ref<any>(null);

// 实际执行打印操作
const executePrint = (item: any) => {
    console.log('开始执行打印操作，item:', item);

    // 如果有德佟打印机SDK，优先使用德佟SDK打印
    if (lpapi) {
        uni.showLoading({
            title: '准备打印...',
            mask: true
        });

        // 检查蓝牙是否可用
        uni.openBluetoothAdapter({
            success: () => {
                console.log('蓝牙适配器已打开，开始搜索打印机');
                // 蓝牙适配器初始化成功，开始搜索打印机
                lpapi.startBleDiscovery({
                    timeout: 10000, // 10秒超时
                    deviceFound: (devices: any) => {
                        console.log('找到设备:', devices);
                        if (devices && devices.length > 0) {
                            // 找到打印机设备，停止搜索
                            lpapi.stopBleDiscovery();

                            console.log('找到打印机设备:', devices);

                            // 选择第一个找到的打印机
                            const printer = devices[0];

                            // 连接打印机并打印
                            printWifiQrcode(printer, item);
                        } else {
                            // 没有找到设备
                            uni.hideLoading();
                            uni.showModal({
                                title: '提示',
                                content: '未找到打印机设备，请确保打印机已开启并在范围内',
                                showCancel: false
                            });
                        }
                    },
                    complete: (devices: any) => {
                        console.log('搜索完成，结果:', devices);
                        // 搜索完成但未找到设备
                        if (!devices || devices.length === 0) {
                            // 检查是否找到了设备
                            if (!lpapi.isConnected()) {
                                uni.hideLoading();
                                uni.showModal({
                                    title: '提示',
                                    content: '未找到打印机设备，请确保打印机已开启并在范围内',
                                    showCancel: false
                                });
                            }
                        }
                    }
                });
            },
            fail: (error) => {
                console.error('蓝牙初始化失败:', error);
                uni.hideLoading();
                setTimeout(() => {
                    uni.showModal({
                        title: '提示',
                        content: '请开启蓝牙功能',
                        showCancel: false
                    });
                }, 100);

                // 尝试使用原生蓝牙打印
                setTimeout(() => {
                    if (connectedPrinter.value) {
                        connectPrinter(connectedPrinter.value, item);
                    } else {
                        searchPrinter(item);
                    }
                }, 2000);
            }
        });
        return;
    }

    // 如果没有德佟SDK，使用原生蓝牙打印
    // 如果已有连接的打印机，直接使用
    if (connectedPrinter.value) {
        uni.showLoading({
            title: '准备打印...',
            mask: true
        });

        // 检查连接状态
        uni.getBLEDeviceServices({
            deviceId: connectedPrinter.value.deviceId,
            success: () => {
                // 连接正常，直接打印
                connectPrinter(connectedPrinter.value, item);
            },
            fail: () => {
                // 连接已断开，重新搜索打印机
                connectedPrinter.value = null;
                uni.hideLoading();
                setTimeout(() => {
                    searchPrinter(item);
                }, 100);
            }
        });
    } else {
        // 检查蓝牙是否可用
        uni.openBluetoothAdapter({
            success: () => {
                // 蓝牙适配器初始化成功，开始搜索打印机
                searchPrinter(item);
            },
            fail: (error) => {
                console.error('蓝牙初始化失败:', error);
                setTimeout(() => {
                    uni.showModal({
                        title: '提示',
                        content: '请开启蓝牙功能',
                        showCancel: false
                    });
                }, 100);
            }
        });
    }
};


// 使用德佟SDK打印WiFi二维码
const printWifiQrcode = (printer: any, item: any) => {
    try {
        const qrcodeUrl = img(item.qrcode);
        // 打开打印机
        lpapi.openPrinter({
            deviceId: printer.deviceId,
            printerName: printer.name
        })
            .then(() => {
                console.log('打印机连接成功，开始加载二维码图片');

                // 加载已有的二维码图片
                return lpapi.loadImage(qrcodeUrl);
            })
            .then((image: any) => {
                console.log('二维码图片加载成功，开始创建打印任务');
                // 标签宽度，单位毫米
                const labelWidth = 75;
                // 标签高度，单位毫米；
                const labelHeight = 120;


                const margin = 8;
                // 二维码大小
                // 创建打印任务
                const jobInfo = lpapi.startJob({
                    width: 75, // 标签宽度(mm)
                    height: 120, // 标签高度(mm)，只打印二维码所以减小高度
                    orientation: 0, // 不旋转
                    jobName: "WiFi码打印" // 打印任务名称
                });

                if (!jobInfo) {
                    throw new Error('打印任务创建失败');
                }
                // 延迟执行打印，确保canvas尺寸更新完成
                setTimeout(() => {
                    try {
                        // 直接绘制加载的二维码图片
                        lpapi.drawImage({
                            image: image,
                            x: margin,
                            y: margin + 20,
                            width: labelWidth - margin * 2,
                            height: labelWidth - margin * 2
                        });

                        console.log('内容绘制完成，提交打印任务');

                        // 提交打印任务前先隐藏loading
                        uni.hideLoading();

                        // 提交打印任务
                        lpapi.commitJob({
                            copies: printCopies.value, // 打印份数
                            cutType: 1, // 切纸类型：1-全切，2-半切，0-不切
                            complete: (resp: any) => {
                                // 不再调用hideLoading，避免重复调用
                                console.log('打印完成，状态码:', resp ? resp.statusCode : 'unknown');

                                if (resp && resp.statusCode === 0) {
                                    setTimeout(() => {
                                        uni.showToast({
                                            title: '打印成功',
                                            icon: 'success',
                                            duration: 2000
                                        });
                                    }, 100);
                                } else {
                                    console.error('打印失败:', resp);
                                    // 显示错误提示
                                    setTimeout(() => {
                                        uni.showToast({
                                            title: '打印失败',
                                            icon: 'none',
                                            duration: 2000
                                        });
                                    }, 100);
                                }
                            }
                        });
                    } catch (error) {
                        console.error('绘制内容出错:', error);
                        uni.hideLoading();
                        // 显示具体错误信息
                        setTimeout(() => {
                            uni.showToast({
                                title: '绘制内容失败',
                                icon: 'none',
                                duration: 2000
                            });
                        }, 100);
                    }
                }, 300); // 增加延迟时间，确保canvas准备好
            })
            .catch((error: any) => {
                console.error('打印过程出错:', error);
                uni.hideLoading();
                setTimeout(() => {
                    uni.showToast({
                        title: '图片加载失败',
                        icon: 'none',
                        duration: 2000
                    });
                }, 100);
            });
    } catch (error) {
        console.error('打印任务执行出错:', error);
        uni.hideLoading();
        setTimeout(() => {
            uni.showToast({
                title: '打印任务创建失败',
                icon: 'none',
                duration: 2000
            });
        }, 100);
    }
};


// 搜索打印机
const searchPrinter = (item: any) => {
    uni.showLoading({
        title: '搜索打印机...',
        mask: true
    });

    // 开始搜索蓝牙设备
    uni.startBluetoothDevicesDiscovery({
        services: [], // 不限制服务UUID
        allowDuplicatesKey: false,
        success: () => {
            // 监听新设备发现事件
            let deviceFound = false;
            let timeoutId: any = null;

            // 获取已配对的蓝牙设备
            uni.getBluetoothDevices({
                success: (res) => {
                    const devices = res.devices || [];
                    // 查找打印机设备，使用更宽松的匹配条件
                    const printerDevice = devices.find((device: any) => {
                        // 更宽松的匹配条件，支持多种打印机型号
                        return device.name && (
                            device.name.toLowerCase().includes('dp') ||
                            device.name.toLowerCase().includes('printer') ||
                            device.name.toLowerCase().includes('print') ||
                            device.name.toLowerCase().includes('德佟') ||
                            device.name.toLowerCase().includes('dt') ||
                            device.name.toLowerCase().includes('pos') ||
                            device.name.toLowerCase().includes('热敏')
                        );
                    });

                    if (printerDevice) {
                        deviceFound = true;
                        // 停止搜索
                        uni.stopBluetoothDevicesDiscovery();
                        // 连接打印机
                        connectPrinter(printerDevice, item);
                    } else {
                        // 设置超时，如果在指定时间内未找到设备则停止搜索
                        timeoutId = setTimeout(() => {
                            if (!deviceFound) {
                                uni.stopBluetoothDevicesDiscovery();
                                uni.hideLoading();
                                uni.showModal({
                                    title: '提示',
                                    content: '未找到打印机，请确保打印机已开启并在范围内',
                                    showCancel: false
                                });
                            }
                        }, 10000); // 10秒超时
                    }
                },
                fail: (err) => {
                    uni.hideLoading();
                    uni.stopBluetoothDevicesDiscovery();
                    uni.showModal({
                        title: '提示',
                        content: '获取蓝牙设备失败',
                        showCancel: false
                    });
                }
            });

            // 监听新设备
            uni.onBluetoothDeviceFound((res) => {
                if (deviceFound) return;

                const devices = res.devices || [];
                // 查找打印机设备，使用更宽松的匹配条件
                const printerDevice = devices.find((device: any) => {
                    // 更宽松的匹配条件，支持多种打印机型号
                    return device.name && (
                        device.name.toLowerCase().includes('dp') ||
                        device.name.toLowerCase().includes('printer') ||
                        device.name.toLowerCase().includes('print') ||
                        device.name.toLowerCase().includes('德佟') ||
                        device.name.toLowerCase().includes('dt') ||
                        device.name.toLowerCase().includes('pos') ||
                        device.name.toLowerCase().includes('热敏')
                    );
                });

                if (printerDevice) {
                    deviceFound = true;
                    if (timeoutId) {
                        clearTimeout(timeoutId);
                    }
                    // 停止搜索
                    uni.stopBluetoothDevicesDiscovery();
                    // 连接打印机
                    connectPrinter(printerDevice, item);
                }
            });
        },
        fail: (error) => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '搜索蓝牙设备失败',
                showCancel: false
            });
        }
    });
};

// 连接打印机
const connectPrinter = (device: any, item: any) => {
    uni.showLoading({
        title: '连接打印机...',
        mask: true
    });

    // 如果已经连接了这个设备，直接获取服务
    if (connectedPrinter.value && connectedPrinter.value.deviceId === device.deviceId) {
        getDeviceServices(device, item);
        return;
    }

    uni.createBLEConnection({
        deviceId: device.deviceId,
        success: () => {
            // 保存连接的打印机信息
            connectedPrinter.value = device;
            // 获取设备的服务
            getDeviceServices(device, item);
        },
        fail: (error) => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '连接打印机失败',
                showCancel: false
            });
        }
    });
};

// 获取设备服务
const getDeviceServices = (device: any, item: any) => {
    uni.getBLEDeviceServices({
        deviceId: device.deviceId,
        success: (res) => {
            // 查找可写特征值的服务
            const services = res.services || [];

            // 打印服务的UUID (通常打印服务的UUID以"18F0"或"FF00"开头)
            const printService = services.find((service: any) => {
                return service.uuid.toUpperCase().includes('18F0') ||
                    service.uuid.toUpperCase().includes('FF00') ||
                    service.isPrimary;
            });

            if (printService) {
                // 获取服务的特征值
                uni.getBLEDeviceCharacteristics({
                    deviceId: device.deviceId,
                    serviceId: printService.uuid,
                    success: (res) => {
                        const characteristics = res.characteristics || [];

                        // 查找可写的特征值
                        const writableCharacteristic = characteristics.find((characteristic: any) => {
                            return (characteristic.properties.write || characteristic.properties.writeNoResponse);
                        });

                        if (writableCharacteristic) {
                            // 保存连接信息到缓存
                            if (!connectedPrinter.value) {
                                connectedPrinter.value = device;
                            }
                            connectedPrinter.value.serviceId = printService.uuid;
                            connectedPrinter.value.characteristicId = writableCharacteristic.uuid;

                            // 准备打印数据
                            preparePrintData(device.deviceId, printService.uuid, writableCharacteristic.uuid, item);
                        } else {
                            disconnectDevice(device.deviceId);
                            uni.hideLoading();
                            uni.showModal({
                                title: '提示',
                                content: '未找到可写入的特征值',
                                showCancel: false
                            });
                        }
                    },
                    fail: (error) => {
                        disconnectDevice(device.deviceId);
                        uni.hideLoading();
                        uni.showModal({
                            title: '提示',
                            content: '获取特征值失败',
                            showCancel: false
                        });
                    }
                });
            } else {
                disconnectDevice(device.deviceId);
                uni.hideLoading();
                uni.showModal({
                    title: '提示',
                    content: '未找到打印服务',
                    showCancel: false
                });
            }
        },
        fail: (error) => {
            disconnectDevice(device.deviceId);
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '获取服务失败',
                showCancel: false
            });
        }
    });
};

// 准备打印数据
const preparePrintData = (deviceId: string, serviceId: string, characteristicId: string, item: any) => {
    uni.showLoading({
        title: '准备打印...',
        mask: true
    });

    // 微信小程序环境下直接打印文本，不下载二维码图片
    // #ifdef MP-WEIXIN
    sendPrintData(deviceId, serviceId, characteristicId, item);
    return;
    // #endif

    // 其他平台尝试下载二维码图片
    // #ifndef MP-WEIXIN
    // 下载二维码图片
    if (item.qrcode) {
        uni.downloadFile({
            url: img(item.qrcode),
            success: (res) => {
                if (res.statusCode === 200) {
                    // 读取图片为ArrayBuffer
                    uni.getFileSystemManager().readFile({
                        filePath: res.tempFilePath,
                        // 明确指定返回类型为ArrayBuffer
                        encoding: 'binary',
                        success: (fileRes: any) => {
                            // 生成打印数据并发送
                            sendPrintData(deviceId, serviceId, characteristicId, item, fileRes.data as ArrayBuffer);
                        },
                        fail: (error) => {
                            // 如果读取图片失败，也直接打印文本
                            sendPrintData(deviceId, serviceId, characteristicId, item);
                        }
                    });
                } else {
                    // 如果下载失败，直接打印文本
                    sendPrintData(deviceId, serviceId, characteristicId, item);
                }
            },
            fail: (error) => {
                // 如果下载失败，直接打印文本
                sendPrintData(deviceId, serviceId, characteristicId, item);
            }
        });
    } else {
        // 无二维码，只打印文本
        sendPrintData(deviceId, serviceId, characteristicId, item);
    }
    // #endif
};

// 发送打印数据
const sendPrintData = (deviceId: string, serviceId: string, characteristicId: string, item: any, qrcodeBuffer?: ArrayBuffer) => {
    // 德佟D30s打印机使用ESC/POS指令集
    // 初始化打印机
    const initCommand = new Uint8Array([0x1B, 0x40]); // ESC @

    // 设置行间距
    const lineSpacingCommand = new Uint8Array([0x1B, 0x33, 0x30]); // ESC 3 n

    // 设置对齐方式：居中
    const centerAlignCommand = new Uint8Array([0x1B, 0x61, 0x01]); // ESC a 1

    // 设置对齐方式：左对齐
    const leftAlignCommand = new Uint8Array([0x1B, 0x61, 0x00]); // ESC a 0

    // 设置字体加粗
    const boldOnCommand = new Uint8Array([0x1B, 0x45, 0x01]); // ESC E 1
    const boldOffCommand = new Uint8Array([0x1B, 0x45, 0x00]); // ESC E 0

    // 设置字体大小
    const normalSizeCommand = new Uint8Array([0x1D, 0x21, 0x00]); // GS ! 0
    const doubleSizeCommand = new Uint8Array([0x1D, 0x21, 0x11]); // GS ! 17 (双倍宽高)

    // 准备打印内容
    const printCommands = [];

    // 初始化
    printCommands.push(initCommand);

    // 标题居中加粗双倍大小
    printCommands.push(centerAlignCommand);
    printCommands.push(boldOnCommand);
    printCommands.push(doubleSizeCommand);
    printCommands.push(textToUint8Array('WiFi信息'));
    printCommands.push(new Uint8Array([0x0A])); // 换行

    // 恢复正常大小
    printCommands.push(normalSizeCommand);
    printCommands.push(boldOffCommand);
    printCommands.push(new Uint8Array([0x0A])); // 换行

    // 商家名称
    printCommands.push(leftAlignCommand);
    printCommands.push(boldOnCommand);
    printCommands.push(textToUint8Array('商家名称: '));
    printCommands.push(boldOffCommand);
    printCommands.push(textToUint8Array(item.name || ''));
    printCommands.push(new Uint8Array([0x0A])); // 换行

    // WiFi名称
    printCommands.push(boldOnCommand);
    printCommands.push(textToUint8Array('WiFi名称: '));
    printCommands.push(boldOffCommand);
    printCommands.push(textToUint8Array(item.wifi_name || ''));
    printCommands.push(new Uint8Array([0x0A])); // 换行

    // WiFi密码
    printCommands.push(boldOnCommand);
    printCommands.push(textToUint8Array('WiFi密码: '));
    printCommands.push(boldOffCommand);
    printCommands.push(textToUint8Array(item.wifi_password || ''));
    printCommands.push(new Uint8Array([0x0A])); // 换行

    // 如果有截流口令，则打印
    if (item.closure) {
        printCommands.push(boldOnCommand);
        printCommands.push(textToUint8Array('截流口令: '));
        printCommands.push(boldOffCommand);
        printCommands.push(textToUint8Array(item.closure));
        printCommands.push(new Uint8Array([0x0A])); // 换行
    }

    printCommands.push(new Uint8Array([0x0A])); // 换行

    // 直接打印二维码信息，不使用图片
    printCommands.push(centerAlignCommand);

    // 生成WiFi连接的二维码内容
    let wifiQrContent = `WIFI:S:${item.wifi_name};`;
    if (item.wifi_password) {
        wifiQrContent += `P:${item.wifi_password};`;
    }
    wifiQrContent += `T:WPA;;`;

    // 微信小程序环境下，使用不同的二维码生成方式
    // #ifdef MP-WEIXIN
    try {
        // 微信小程序环境下，尝试使用更简单的二维码命令

        // 设置二维码大小 (1-16)
        const qrSizeCmd = new Uint8Array([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, 0x08]);
        printCommands.push(qrSizeCmd);

        // 设置二维码纠错级别 (L:48, M:49, Q:50, H:51)
        const qrErrorCmd = new Uint8Array([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x48]);
        printCommands.push(qrErrorCmd);

        // 存储二维码数据
        const qrData = textToUint8Array(wifiQrContent);

        // 计算pL和pH (低字节和高字节)
        const dataLength = qrData.length + 3;
        const pL = dataLength % 256;
        const pH = Math.floor(dataLength / 256);

        // 存储二维码数据命令
        const qrStoreHeader = new Uint8Array([0x1D, 0x28, 0x6B, pL, pH, 0x31, 0x50, 0x30]);
        printCommands.push(qrStoreHeader);
        printCommands.push(qrData);

        // 打印二维码命令
        const qrPrintCmd = new Uint8Array([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30]);
        printCommands.push(qrPrintCmd);

        // 打印提示文本
        printCommands.push(new Uint8Array([0x0A])); // 换行
        printCommands.push(textToUint8Array('扫描二维码连接WiFi'));
        printCommands.push(new Uint8Array([0x0A])); // 换行
    } catch (e) {
        // 如果生成二维码失败，打印提示文本
        printCommands.push(textToUint8Array('请手动连接WiFi:'));
        printCommands.push(new Uint8Array([0x0A])); // 换行
        printCommands.push(textToUint8Array(item.wifi_name));
        printCommands.push(new Uint8Array([0x0A])); // 换行
        printCommands.push(textToUint8Array('密码:' + (item.wifi_password || '无密码')));
    }
    // #endif

    // 其他平台使用另一种二维码生成方式
    // #ifndef MP-WEIXIN
    try {
        // 模型1 QR码
        const modelQR = new Uint8Array([0x1D, 0x28, 0x6B, 0x04, 0x00, 0x31, 0x41, 0x32, 0x00]);
        printCommands.push(modelQR);

        // 设置QR码大小 (1-16)
        const sizeQR = new Uint8Array([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, 0x08]);
        printCommands.push(sizeQR);

        // 设置QR码纠错等级
        const errorQR = new Uint8Array([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x31]);
        printCommands.push(errorQR);

        // 存储QR码数据
        const qrData = textToUint8Array(wifiQrContent);

        // 计算pL和pH (低字节和高字节)
        const dataLength = qrData.length + 3;
        const pL = dataLength % 256;
        const pH = Math.floor(dataLength / 256);

        // 存储二维码数据命令
        const qrHeader = new Uint8Array([0x1D, 0x28, 0x6B, pL, pH, 0x31, 0x50, 0x30]);
        printCommands.push(qrHeader);
        printCommands.push(qrData);

        // 打印QR码
        const printQR = new Uint8Array([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30]);
        printCommands.push(printQR);

        printCommands.push(new Uint8Array([0x0A])); // 换行
        printCommands.push(textToUint8Array('扫描二维码连接WiFi'));
    } catch (e) {
        // 如果生成二维码失败，打印提示文本
        printCommands.push(textToUint8Array('请手动连接WiFi:'));
        printCommands.push(new Uint8Array([0x0A])); // 换行
        printCommands.push(textToUint8Array(item.wifi_name));
        printCommands.push(new Uint8Array([0x0A])); // 换行
        printCommands.push(textToUint8Array('密码:' + (item.wifi_password || '无密码')));
    }
    // #endif

    // 添加页尾
    printCommands.push(new Uint8Array([0x0A, 0x0A])); // 多换几行
    printCommands.push(centerAlignCommand);
    printCommands.push(textToUint8Array('-- 感谢使用 --'));
    printCommands.push(new Uint8Array([0x0A, 0x0A, 0x0A, 0x0A])); // 打印结束后走纸

    // 切纸命令
    printCommands.push(new Uint8Array([0x1D, 0x56, 0x42, 0x00])); // GS V B 0

    // 发送打印数据
    sendCommandsSequentially(deviceId, serviceId, characteristicId, printCommands, 0);
};

// 文本转Uint8Array (支持中文)，解决TextEncoder未定义的问题
const textToUint8Array = (text: string): Uint8Array => {
    // 兼容处理，微信小程序不支持TextEncoder
    // #ifdef MP-WEIXIN
    const len = text.length;
    const bytes = new Array();
    for (let i = 0; i < len; i++) {
        const c = text.charCodeAt(i);
        if (c < 0x80) {
            bytes.push(c);
        } else if (c < 0x800) {
            bytes.push(0xC0 | (c >> 6));
            bytes.push(0x80 | (c & 0x3F));
        } else if (c < 0x10000) {
            bytes.push(0xE0 | (c >> 12));
            bytes.push(0x80 | ((c >> 6) & 0x3F));
            bytes.push(0x80 | (c & 0x3F));
        } else {
            bytes.push(0xF0 | (c >> 18));
            bytes.push(0x80 | ((c >> 12) & 0x3F));
            bytes.push(0x80 | ((c >> 6) & 0x3F));
            bytes.push(0x80 | (c & 0x3F));
        }
    }
    return new Uint8Array(bytes);
    // #endif

    // 其他平台使用TextEncoder
    // #ifndef MP-WEIXIN
    try {
        const encoder = new TextEncoder();
        return encoder.encode(text);
    } catch (e) {
        // 如果TextEncoder不可用，回退到手动编码
        const len = text.length;
        const bytes = new Array();
        for (let i = 0; i < len; i++) {
            const c = text.charCodeAt(i);
            if (c < 0x80) {
                bytes.push(c);
            } else if (c < 0x800) {
                bytes.push(0xC0 | (c >> 6));
                bytes.push(0x80 | (c & 0x3F));
            } else if (c < 0x10000) {
                bytes.push(0xE0 | (c >> 12));
                bytes.push(0x80 | ((c >> 6) & 0x3F));
                bytes.push(0x80 | (c & 0x3F));
            } else {
                bytes.push(0xF0 | (c >> 18));
                bytes.push(0x80 | ((c >> 12) & 0x3F));
                bytes.push(0x80 | ((c >> 6) & 0x3F));
                bytes.push(0x80 | (c & 0x3F));
            }
        }
        return new Uint8Array(bytes);
    }
    // #endif
};

// 顺序发送命令
const sendCommandsSequentially = (deviceId: string, serviceId: string, characteristicId: string, commands: Uint8Array[], index: number) => {
    if (index >= commands.length) {
        // 所有命令发送完毕
        // 关闭蓝牙连接并重置状态，确保下次可以正常连接
        resetBluetoothConnection(deviceId);

        uni.hideLoading();
        uni.showToast({
            title: '打印成功',
            icon: 'success'
        });
        return;
    }

    // 发送当前命令
    uni.writeBLECharacteristicValue({
        deviceId: deviceId,
        serviceId: serviceId,
        characteristicId: characteristicId,
        // 使用类型断言解决类型不匹配问题
        value: commands[index].buffer as unknown as ArrayBuffer,
        success: () => {
            // 延迟发送下一条命令，确保打印机有足够时间处理
            setTimeout(() => {
                sendCommandsSequentially(deviceId, serviceId, characteristicId, commands, index + 1);
            }, 80); // 增加延迟时间，确保打印机处理完成
        },
        fail: (error: any) => {
            console.error('发送打印数据失败:', error);

            // 如果是因为连接断开导致的失败，尝试重新连接
            if (error && (error.errCode === 10006 || error.errMsg.includes('connection'))) {
                // 清除连接缓存
                connectedPrinter.value = null;
                uni.hideLoading();
                uni.showModal({
                    title: '提示',
                    content: '打印机连接已断开，请重试',
                    showCancel: false
                });
            } else {
                uni.hideLoading();
                uni.showModal({
                    title: '提示',
                    content: '发送打印数据失败',
                    showCancel: false
                });
            }
        }
    } as any); // 使用类型断言绕过类型检查
};

// 断开设备连接
const disconnectDevice = (deviceId: string) => {
    // 不再每次打印后断开连接，而是保持连接状态
    // 只在出错或页面卸载时断开连接
    if (deviceId !== connectedPrinter.value?.deviceId) {
        uni.closeBLEConnection({
            deviceId: deviceId,
            complete: () => {
                // 不关闭蓝牙适配器，以便下次快速连接
            }
        });
    }
};

// 重置蓝牙连接状态，确保下次打印可以正常连接
const resetBluetoothConnection = (deviceId: string) => {
    // 关闭当前蓝牙连接
    uni.closeBLEConnection({
        deviceId: deviceId,
        success: () => {
            console.log('蓝牙连接已关闭，准备下次连接');

            // 重新初始化蓝牙适配器
            uni.closeBluetoothAdapter({
                success: () => {
                    console.log('蓝牙适配器已关闭');

                    // 延迟重新打开蓝牙适配器
                    setTimeout(() => {
                        uni.openBluetoothAdapter({
                            success: () => {
                                console.log('蓝牙适配器已重新初始化');
                                // 清空连接状态
                                connectedPrinter.value = null;
                            },
                            fail: () => {
                                console.log('蓝牙适配器重新初始化失败');
                            }
                        });
                    }, 300);
                }
            });
        },
        fail: () => {
            console.log('关闭蓝牙连接失败');
            // 即使关闭失败，也尝试重置状态
            connectedPrinter.value = null;
        }
    });
};


</script>

<style lang="scss">
.iconfont {
    font-family: "iconfont" !important;
    font-style: normal;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.icon-search:before {
    content: "\e8ef";
}

.icon-print:before {
    content: "\e742";
}

.icon-delete:before {
    content: "\e74b";
}

.icon-edit:before {
    content: "\e66e";
}

.icon-preview:before {
    content: "\e7b9";
}

.icon-more:before {
    content: "\e684";
}

.icon-share:before {
    content: "\e739";
}

.icon-wifi:before {
    content: "\e665";
}

.icon-add:before {
    content: "\e6da";
}

.max-h-80vh {
    max-height: 60vh;
}
</style>
