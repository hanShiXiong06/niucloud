<template>
    <view class="min-h-screen bg-gray-100" :style="themeColor()">
        <!-- 页面标题 -->
        <view class="header bg-white py-4 px-5">
            <view class="text-[32rpx] font-bold text-gray-800">创建WIFI码</view>
            <view class="text-[26rpx] text-gray-500 mt-3">便捷管理店铺WIFI，提供一键安全连接体验</view>
        </view>

        <!-- 功能特点 -->
        <view class="features flex justify-around py-3 bg-white mt-2 rounded-lg mx-4 shadow-sm">
            <view class="feature-item flex flex-col items-center">
                <view class="icon-wrapper bg-blue-50 rounded-full w-8 h-8 flex items-center justify-center">
                    <up-icon name="wifi" size="36" color="var(--primary-color)"></up-icon>
                </view>
                <text class="text-xs mt-2 text-gray-600">一键快速连接</text>
            </view>
            <view class="feature-item flex flex-col items-center">
                <view class="icon-wrapper bg-blue-50 rounded-full w-8 h-8 flex items-center justify-center">
                    <up-icon name="lock" size="36" color="var(--primary-color)"></up-icon>
                </view>
                <text class="text-xs mt-2 text-gray-600">无需告知密码</text>
            </view>
            <view class="feature-item flex flex-col items-center">
                <view class="icon-wrapper bg-blue-50 rounded-full w-8 h-8 flex items-center justify-center">
                    <up-icon name="fingerprint" size="36" color="var(--primary-color)"></up-icon>
                </view>
                <text class="text-xs mt-2 text-gray-600">安全防蹭网</text>
            </view>
        </view>

        <!-- 表单区域 -->
        <view class="form-container bg-white mt-2 mx-4 p-4 rounded-lg shadow-sm">
            <view class="form-item border-b border-gray-100 py-3 flex justify-between items-center">
                <text class="text-[16px] text-gray-700">店铺名称</text>
                <input type="text" v-model="wifiTitle" placeholder="请输入店铺名称"
                    class="text-right flex-1 ml-2 text-gray-600 placeholder:text-gray-300" />
            </view>

            <view class="form-item border-b border-gray-100 py-3 flex justify-between items-center">
                <text class="text-[16px] text-gray-700">WiFi用户名</text>
                <view class="flex items-center w-3/5">
                    <input type="text" v-model="wifiName" placeholder="请输入WiFi用户名"
                        class="text-right flex-1 text-gray-600 placeholder:text-gray-300" />
                    <!-- <view class="ml-2" @click="showWifiSelector">
                        <up-icon name="arrow-down-fill" size="24" color="var(--primary-color)"></up-icon>
                    </view> -->
                </view>
            </view>

            <view class="form-item border-b border-gray-100 py-3 flex justify-between items-center">
                <text class="text-[16px] text-gray-700">WiFi密码</text>
                <input type="text" v-model="wifiPassword" placeholder="请输入WiFi密码"
                    class="text-right flex-1 ml-2 text-gray-600 placeholder:text-gray-300" />
            </view>

            <!-- <view class="form-item py-3 flex justify-between items-center">
                <text class="text-[16px] text-gray-700">截流口令</text>
                <view class="flex items-center">
                    <input type="text" v-model="command" placeholder="输入截流口令（选填）"
                        class="text-right flex-1 text-gray-600 placeholder:text-gray-300" />
                </view>
            </view> -->
        </view>

        <!-- WiFi选择弹窗 -->
        <up-popup v-model="showWifiPopup" mode="bottom" border-radius="16" height="50%">
            <view class="p-4">
                <view class="flex justify-between items-center mb-4 pb-2 border-b border-gray-100">
                    <text class="text-lg font-bold">选择WiFi</text>
                    <view @click="refreshWifiList" class="flex items-center">
                        <text class="text-sm text-[var(--primary-color)] mr-1">刷新</text>
                        <up-icon name="reload" size="28" color="var(--primary-color)"></up-icon>
                    </view>
                </view>

                <scroll-view scroll-y style="max-height: 60vh;">
                    <view v-if="wifiList.length === 0" class="py-10 flex flex-col items-center">
                        <up-icon name="wifi-off" size="48" color="#aaa"></up-icon>
                        <text class="text-gray-500 mt-2">暂无可用WiFi</text>
                    </view>
                    <view v-else>
                        <view v-for="(item, index) in wifiList" :key="index"
                            class="py-3 px-2 border-b border-gray-100 flex items-center" @click="selectWifi(item)">
                            <view class="mr-3">
                                <up-icon name="wifi" size="36"
                                    :color="signalStrengthColor(item.signalStrength)"></up-icon>
                            </view>
                            <view class="flex-1">
                                <text class="text-base">{{ item.SSID }}</text>
                            </view>
                            <view v-if="wifiName === item.SSID">
                                <up-icon name="checkmark-circle" color="var(--primary-color)" size="32"></up-icon>
                            </view>
                        </view>
                    </view>
                </scroll-view>
            </view>
        </up-popup>

        <view class="p-4 shadow-lg">
            <button class="bg-[var(--primary-color)] text-white rounded-full py-3 w-full font-bold text-[16px]"
                @click="createWifiCode">新增WIFI码</button>
        </view>
        <tabbar :tabbar="tk_wifi" />
    </view>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app';
import { redirect } from '@/utils/common';
import { addWifi, checkSharer } from '@/addon/tk_wifi/api/wifi';
const checkShareEvent = () => {
    let pid = uni.getStorageSync("pid");
    checkSharer({ pid: pid }).then(res => {
        if (res.data.is_sharer == 2) {
            uni.$u.toast(res.data.msg)
        }
        if (res.data.is_sharer == 0) {
            redirect({ url: '/addon/tk_wifi/pages/wifi/apply' })
        }
    })
}
checkShareEvent()
// 表单数据
const wifiTitle = ref('');
const wifiName = ref('');
const wifiPassword = ref('');
const command = ref('');

// WiFi列表相关
const wifiList = ref<any[]>([]);
const showWifiPopup = ref(false);

// 页面加载
onLoad(() => getSystemWifiList());

// 获取系统WiFi列表
const getSystemWifiList = () => {
    // #ifdef APP-PLUS
    uni.showLoading({ title: '获取WiFi列表' });
    uni.startWifi({
        success: () => {
            uni.getWifiList({
                success: () => {
                    uni.onGetWifiList((res) => {
                        uni.hideLoading();
                        if (res.wifiList?.length > 0) {
                            // 过滤出有效的WiFi名称
                            wifiList.value = res.wifiList.filter((item: any) => item.SSID && item.SSID !== '');

                            // 默认使用当前连接的WiFi
                            const currentWifi = wifiList.value[0];
                            if (currentWifi && !wifiName.value) {
                                wifiName.value = currentWifi.SSID;
                            }
                        }
                    });
                },
                fail: (err) => {
                    uni.hideLoading();
                    uni.showToast({
                        title: '获取WiFi列表失败',
                        icon: 'none'
                    });
                    console.error('获取WiFi列表失败:', err);
                }
            });
        },
        fail: (err) => {
            uni.hideLoading();
            uni.showToast({
                title: '初始化WiFi模块失败',
                icon: 'none'
            });
            console.error('初始化WiFi模块失败:', err);
        }
    });
    // #endif

};

// 刷新WiFi列表
const refreshWifiList = () => {
    getSystemWifiList();
};

// 显示WiFi选择器
const showWifiSelector = () => {
    // 如果列表为空，先尝试获取
    if (wifiList.value.length === 0) {
        getSystemWifiList();
    }
    showWifiPopup.value = true;
};

// 选择WiFi
const selectWifi = (wifi: any) => {
    wifiName.value = wifi.SSID;
    showWifiPopup.value = false;
};

// 根据信号强度返回颜色
const signalStrengthColor = (strength: number) => {
    if (!strength && strength !== 0) return '#aaa';
    if (strength > 70) return '#4CAF50';
    if (strength > 40) return '#FFC107';
    return '#F44336';
};

// 返回上一页
const goBack = () => uni.navigateBack();

// 创建WiFi码
const createWifiCode = () => {
    if (!wifiName.value) {
        uni.showToast({
            title: '请输入WiFi用户名',
            icon: 'none'
        });
        return;
    }

    // 构建WiFi信息
    const wifiData = {
        name: wifiTitle.value,
        wifi_name: wifiName.value,
        wifi_password: wifiPassword.value,
        closure: command.value
    };

    // 提交数据生成WiFi码
    uni.showLoading({ title: '正在生成' });

    addWifi(wifiData)
        .then(() => {
            uni.hideLoading();
            uni.showToast({
                title: '创建成功',
                icon: 'success'
            });
            setTimeout(() => {
                uni.navigateTo({
                    url: '/addon/tk_wifi/pages/wifi/create_list'
                });
            }, 1500);
        })

};
</script>

<style lang="scss" scoped></style>
