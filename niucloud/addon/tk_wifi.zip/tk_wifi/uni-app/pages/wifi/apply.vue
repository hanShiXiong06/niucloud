<template>
    <view class="min-h-screen bg-gray-100" :style="themeColor()" v-if="config">
        <up-parse :content="config.sharer_content"
            :tagStyle="{ img: 'max-width: 100%; height: auto; vertical-align: top;', p: 'overflow: hidden;word-break:break-word;margin: 10rpx 0;' }">
        </up-parse>
        <view
            class="py-[var(--top-m)] px-[var(--sidebar-m)] footer w-full fixed bottom-0 left-0 right-0 box-border bg-[var(--page-bg-color)] safe-area-inset-bottom">

            <view class="ml-4 mr-4 mt-2">
                <button hover-class="none"
                    class="h-[80rpx] leading-[80rpx] rounded-[24rpx] text-[32rpx] text-[var(--primary-color-light)] w-full"
                    :style="{ background: 'linear-gradient(to right, var(--primary-color), var(--primary-help-color2))' }"
                    @click="apply()">申请推广权限</button>
            </view>
            <up-safe-bottom></up-safe-bottom>
        </view>
    </view>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { onLoad } from '@dcloudio/uni-app';
import { getConfig, applySharer } from '@/addon/tk_wifi/api/wifi';
const config = ref<any>({})
const apply = () => {
    let pid = uni.getStorageSync("pid");
    applySharer({ pid: pid }).then(res => {
        uni.$u.toast('操作成功')
    })
}
onLoad(() => {
    getConfig().then(res => {
        config.value = res.data
    })
})
</script>

<style lang="scss" scoped></style>
