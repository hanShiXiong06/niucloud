<template>
    <view class="min-h-screen bg-gray-100" :style="themeColor()">

        <mescroll-body ref="mescrollRef" @init="mescrollInit" @down="downCallback" @up="getWifiListFn">
            <!-- 搜索框和添加按钮 -->
            <view class="p-4 bg-white mb-2 shadow-sm">
                <view class="flex items-center justify-between gap-3">
                    <!-- 搜索框 -->
                    <view class="flex items-center bg-gray-100 rounded-full px-4 py-2 flex-1">
                        <text class="iconfont icon-search text-gray-400 mr-2"></text>
                        <input type="text" v-model="searchQuery" placeholder="请输入WiFi名称搜索" class="flex-1"
                            @confirm="handleSearch" />
                        <text class="text-gray-500" @tap="handleSearch">搜索</text>
                    </view>

                    <!-- 添加按钮 -->
                    <!-- <view @tap="handleAddWifi"
                        class="bg-[var(--primary-color)] text-white rounded-full py-1 px-4 flex items-center shadow-sm whitespace-nowrap">

                        <text>添加</text>
                    </view> -->
                </view>
            </view>
            <view class="px-3">
                <!-- WiFi列表 -->
                <view v-if="list.length > 0" v-for="item in list" :key="item.id"
                    class="bg-white rounded-lg mb-3 px-3 py-2.5 shadow-sm">
                    <view class="flex items-center">
                        <!-- 左侧内容区 -->
                        <view class="flex-1">
                            <view class="flex items-center">
                                <view class="text-[28rpx] font-bold text-gray-800 truncate">{{ item.name }}</view>
                                <view class="ml-1 bg-blue-50 text-blue-500 text-xs rounded px-1">ID:{{ item.id }}</view>
                            </view>
                            <view class="flex items-center text-[24rpx] text-gray-500 py-2">
                                <view class="mr-1">
                                    <up-icon name="wifi" size="24" color="#666"></up-icon>
                                </view>
                                <text>{{ item.wifi_name }}</text>
                            </view>
                            <view class="flex items-center text-[26rpx]">
                                累计连接 <text class="text-blue-500 mx-1">{{ item.contact_num || 0 }}</text> 次
                                <view v-if="item.closure"
                                    class="ml-2 bg-orange-100 text-orange-600 text-xs px-1 rounded">
                                    已设截流
                                </view>
                            </view>
                        </view>

                        <!-- 右侧二维码 -->
                        <view class="mr-2">
                            <image :src="img(item.qrcode)" mode="aspectFit" class="w-16 h-16 rounded-sm"></image>
                        </view>
                    </view>
                    <view class="flex justify-between items-center mt-2">
                        <view class="text-gray-400 text-[24rpx]">{{ item.create_time }}</view>
                        <!-- 操作按钮 -->
                        <view class="flex  border-t border-gray-100 text-[22rpx]">

                            <view class="flex items-center" @tap="handleDelete(item)">
                                <view class="mr-1">
                                    <up-icon name="trash" size="24" color="#666"></up-icon>
                                </view>
                                <text class="text-gray-600">删除</text>
                            </view>
                            <view class="flex items-center ml-3 mr-3" @tap="handleEdit(item)">
                                <view class="mr-1">
                                    <up-icon name="edit-pen" size="24" color="#666"></up-icon>
                                </view>
                                <text class="text-gray-600">修改</text>
                            </view>
                            <view class="flex items-center" @tap="handlePreview(item)">
                                <view class="mr-1">
                                    <up-icon name="eye" size="24" color="#666"></up-icon>
                                </view>
                                <text class="text-gray-600">预览</text>
                            </view>
                        </view>
                    </view>

                </view>

                <!-- 空状态 -->
                <view v-if="loading && list.length === 0" class="py-10 flex justify-center items-center">
                    <mescroll-empty></mescroll-empty>
                </view>
            </view>
            <view class="h-[100rpx]"></view>
        </mescroll-body>

        <up-popup :show="showEditPopup" @close="showEditPopup = false">
            <view class="p-4">
                <view class="text-[32rpx] font-bold mb-2">{{ currentEditId ? '修改' : '添加' }}WiFi配置信息</view>
                <view class="mb-5">
                    <view class="text-gray-500 mb-2">标记名称</view>
                    <input type="text" v-model="editForm.name" placeholder="请输入标记名称"
                        class="h-12 bg-gray-100 rounded-xl px-4" />
                </view>
                <view class="mb-5">
                    <view class="text-gray-500 mb-2">WiFi名称</view>
                    <view class="flex items-center">
                        <input type="text" v-model="editForm.wifi_name" placeholder="请输入WiFi名称"
                            class="h-12 bg-gray-100 rounded-xl px-4 flex-1" />
                        <view @tap="getWifiNetworks"
                            class="ml-2 bg-[var(--primary-color)] text-white rounded-lg py-2 px-3">
                            <text>获取</text>
                        </view>
                    </view>
                    <!-- WiFi列表选择 -->
                    <view v-if="nearbyWifiList.length > 0"
                        class="mt-2 bg-gray-50 rounded-lg p-2 max-h-40 overflow-auto">
                        <view v-for="(wifi, index) in nearbyWifiList" :key="index" @tap="selectWifi(wifi)"
                            class="py-2 px-2 border-b border-gray-100 flex items-center">
                            <up-icon name="wifi" size="24" color="#666" class="mr-2"></up-icon>
                            <text>{{ wifi.SSID }}</text>
                            <view v-if="wifi.secure" class="ml-2 text-xs text-gray-500">
                                <up-icon name="lock" size="20" color="#999"></up-icon>
                            </view>
                        </view>
                    </view>
                </view>

                <view class="mb-5">
                    <view class="text-gray-500 mb-2">WiFi密码</view>
                    <input type="text" v-model="editForm.wifi_password" placeholder="请输入WiFi密码"
                        class=" h-12 bg-gray-100 rounded-xl px-4" />
                </view>



                <view class="mb-10">
                    <view class="text-gray-500 mb-2">截流口令</view>
                    <input type="text" v-model="editForm.closure" placeholder="请输入截流口令(选填)"
                        class="h-12 bg-gray-100 rounded-xl px-4" />
                </view>


                <!-- 底部按钮 -->
                <view class="flex border-t border-gray-100">
                    <view
                        class="flex-1 py-2 mr-2 text-center text-gray-600 bg-[var(--primary-color-light)] border-r rounded-xl"
                        @tap="showEditPopup = false">
                        取消
                    </view>
                    <view class="flex-1 py-2  text-center text-white bg-[var(--primary-color)] rounded-xl"
                        @tap="submitEdit">
                        确定
                    </view>
                </view>
            </view>
        </up-popup>

        <!-- 预览弹窗 -->
        <up-popup :show="showPreviewPopup" @close="showPreviewPopup = false">
            <view class="p-4">
                <view class="text-[32rpx] font-bold mb-3">WiFi 信息预览</view>

                <!-- WiFi 信息 -->
                <view class="mb-4">
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">备注名称：</text>
                        <text class="font-medium">{{ previewInfo.name }}</text>
                    </view>
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">WiFi名称：</text>
                        <text class="font-medium">{{ previewInfo.wifi_name }}</text>
                    </view>
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">WiFi密码：</text>
                        <text class="font-medium">{{ previewInfo.wifi_password || '未设置' }}</text>
                    </view>
                    <view class="flex items-center mb-2">
                        <text class="text-gray-500 w-24">截流口令：</text>
                        <text class="font-medium">{{ previewInfo.closure || '未设置' }}</text>
                    </view>
                </view>

                <!-- 二维码 -->
                <view class="flex flex-col items-center mb-4">
                    <image :src="img(previewInfo.qrcode)" mode="aspectFit" class="w-48 h-48 mb-2"></image>
                    <text class="text-gray-500 text-sm">WiFi 二维码</text>
                </view>

                <!-- 底部按钮 -->
                <view class="flex border-t border-gray-100 pt-3">
                    <view
                        class="flex-1 py-2 mr-2 text-center text-gray-600 bg-[var(--primary-color-light)] border-r rounded-xl"
                        @tap="showPreviewPopup = false">
                        关闭
                    </view>
                    <view class="flex-1 py-2 text-center text-white bg-[var(--primary-color)] rounded-xl"
                        @tap="downloadQrcode">
                        下载二维码
                    </view>
                </view>
            </view>
        </up-popup>


        <!-- #ifdef MP-WEIXIN -->
        <!-- 小程序隐私协议 -->
        <wx-privacy-popup ref="wxPrivacyPopupRef"></wx-privacy-popup>
        <!-- #endif -->
        <tabbar :tabbar="tk_wifi" />
    </view>
</template>

<script setup lang="ts">
import { ref, reactive, onUnmounted, onMounted, computed } from "vue";
import { downloadFileEvent } from "@/addon/tk_wifi/utils/ts/common"
import { img, copy, redirect } from "@/utils/common";
import { getWifiList, delWifiQrcode, editeWifiQrcode, addWifi } from "@/addon/tk_wifi/api/wifi";
// @ts-ignore
import MescrollBody from "@/components/mescroll/mescroll-body/mescroll-body.vue";
// @ts-ignore
import MescrollEmpty from "@/components/mescroll/mescroll-empty/mescroll-empty.vue";
// @ts-ignore
import useMescroll from "@/components/mescroll/hooks/useMescroll.js";
import { onLoad, onPageScroll, onReachBottom, onTabItemTap } from "@dcloudio/uni-app";
// @ts-ignore
const { mescrollInit, downCallback, getMescroll } = useMescroll(onPageScroll, onReachBottom);

// 声明plus和wx对象，避免TypeScript错误
declare const plus: any;
declare const wx: any;

const list = ref<any[]>([]);
const loading = ref<boolean>(false);
const searchQuery = ref<string>("");

// 附近WiFi列表
const nearbyWifiList = ref<any[]>([]);
const isGettingWifi = ref<boolean>(false);

// 修改弹窗相关
const showEditPopup = ref<boolean>(false);
const currentEditId = ref<string | number>("");
const editForm = reactive({
    wifi_name: "",
    wifi_password: "",
    name: "",
    closure: ""  // 添加截流口令字段
});

// 预览弹窗相关
const showPreviewPopup = ref<boolean>(false);
const previewInfo = reactive({
    id: "",
    name: "",
    wifi_name: "",
    wifi_password: "",
    qrcode: "",
    closure: ""
});

// 获取WiFi列表
const getWifiListFn = (mescroll: any) => {
    loading.value = true;
    let data = {
        page: mescroll.num,
        limit: mescroll.size,
        keyword: searchQuery.value
    };

    getWifiList(data)
        .then((res: any) => {
            let newArr = [];
            if (res && res.data && res.data.data) {
                newArr = res.data.data;

                //设置列表数据
                if (mescroll.num == 1) {
                    list.value = []; //如果是第一页需手动制空列表
                }
                list.value = [...list.value, ...newArr];
                mescroll.endSuccess(newArr.length);
            } else {
                mescroll.endErr();
            }
            loading.value = false;
        })
        .catch((error: any) => {
            loading.value = false;
            mescroll.endErr(); // 请求失败, 结束加载
        });
};

// 获取附近WiFi网络
const getWifiNetworks = () => {
    // 清空之前的列表
    nearbyWifiList.value = [];
    isGettingWifi.value = true;

    // #ifdef APP-PLUS
    try {
        if (typeof plus !== 'undefined' && plus.os && plus.os.name) {
            if (plus.os.name.toLowerCase() === 'android') {
                // Android平台
                try {
                    const wifiManager = plus.android.importClass("android.net.wifi.WifiManager");
                    const context = plus.android.runtimeMainActivity();
                    if (context && typeof context.getApplicationContext === 'function') {
                        const appContext = context.getApplicationContext();
                        if (appContext && wifiManager && typeof appContext.getSystemService === 'function') {
                            const wifiMgr = appContext.getSystemService(wifiManager.WIFI_SERVICE);

                            // 检查WiFi是否开启
                            if (wifiMgr && typeof wifiMgr.isWifiEnabled === 'function' && !wifiMgr.isWifiEnabled()) {
                                uni.showModal({
                                    title: '提示',
                                    content: '请先开启WiFi',
                                    showCancel: false
                                });
                                isGettingWifi.value = false;
                                return;
                            }

                            // 扫描WiFi
                            if (wifiMgr && typeof wifiMgr.startScan === 'function') {
                                wifiMgr.startScan();
                                setTimeout(() => {
                                    if (wifiMgr && typeof wifiMgr.getScanResults === 'function') {
                                        const scanResults = wifiMgr.getScanResults();
                                        const wifiList = [];

                                        if (scanResults && typeof scanResults.size === 'function') {
                                            const size = scanResults.size();
                                            for (let i = 0; i < size; i++) {
                                                const scanResult = scanResults.get(i);
                                                if (scanResult && scanResult.SSID) {
                                                    const ssid = scanResult.SSID;
                                                    if (ssid && ssid.length > 0) {
                                                        wifiList.push({
                                                            SSID: ssid,
                                                            BSSID: scanResult.BSSID || '',
                                                            secure: scanResult.capabilities &&
                                                                (scanResult.capabilities.indexOf("WPA") >= 0 ||
                                                                    scanResult.capabilities.indexOf("WEP") >= 0)
                                                        });
                                                    }
                                                }
                                            }
                                        }

                                        nearbyWifiList.value = wifiList;
                                        isGettingWifi.value = false;

                                        if (wifiList.length === 0) {
                                            uni.showToast({
                                                title: '未检测到WiFi网络',
                                                icon: 'none'
                                            });
                                        }
                                    }
                                }, 1000);
                            }
                        }
                    }
                } catch (e) {
                    console.error('获取WiFi列表失败:', e);
                    isGettingWifi.value = false;
                    uni.showToast({
                        title: '获取WiFi列表失败',
                        icon: 'none'
                    });
                }
            } else {
                // iOS平台不支持获取WiFi列表
                uni.showToast({
                    title: '当前平台不支持获取WiFi列表',
                    icon: 'none'
                });
                isGettingWifi.value = false;
            }
        } else {
            uni.showToast({
                title: '当前环境不支持获取WiFi列表',
                icon: 'none'
            });
            isGettingWifi.value = false;
        }
    } catch (e) {
        console.error('获取WiFi列表出错:', e);
        isGettingWifi.value = false;
        uni.showToast({
            title: '获取WiFi列表失败',
            icon: 'none'
        });
    }
    // #endif

    // #ifdef MP-WEIXIN
    try {
        if (typeof wx !== 'undefined' && wx.startWifi) {
            uni.showLoading({
                title: '获取中...'
            });

            wx.startWifi({
                success: () => {
                    if (wx.getWifiList) {
                        wx.getWifiList({
                            success: () => {
                                // 监听获取到的WiFi列表
                                if (wx.onGetWifiList) {
                                    wx.onGetWifiList((res: any) => {
                                        uni.hideLoading();
                                        isGettingWifi.value = false;

                                        if (res && res.wifiList && res.wifiList.length > 0) {
                                            nearbyWifiList.value = res.wifiList.map((item: any) => ({
                                                SSID: item.SSID || '',
                                                BSSID: item.BSSID || '',
                                                secure: item.secure || false
                                            }));
                                        } else {
                                            uni.showToast({
                                                title: '未检测到WiFi网络',
                                                icon: 'none'
                                            });
                                        }
                                    });
                                }
                            },
                            fail: (err: any) => {
                                uni.hideLoading();
                                isGettingWifi.value = false;

                                // 如果是用户拒绝授权的情况
                                if (err && err.errCode === 12010) {
                                    uni.showModal({
                                        title: '提示',
                                        content: '请允许获取WiFi列表权限',
                                        confirmText: '去设置',
                                        success: (res) => {
                                            if (res.confirm) {
                                                uni.openSetting();
                                            }
                                        }
                                    });
                                } else {
                                    uni.showToast({
                                        title: '获取WiFi列表失败',
                                        icon: 'none'
                                    });
                                }
                            }
                        });
                    }
                },
                fail: () => {
                    uni.hideLoading();
                    isGettingWifi.value = false;
                    uni.showToast({
                        title: '初始化WiFi模块失败',
                        icon: 'none'
                    });
                }
            });
        } else {
            uni.showToast({
                title: '当前环境不支持获取WiFi列表',
                icon: 'none'
            });
            isGettingWifi.value = false;
        }
    } catch (e) {
        console.error('获取WiFi列表出错:', e);
        uni.hideLoading();
        isGettingWifi.value = false;
        uni.showToast({
            title: '获取WiFi列表失败',
            icon: 'none'
        });
    }
    // #endif

    // #ifndef APP-PLUS || MP-WEIXIN
    // 其他平台不支持获取WiFi列表
    uni.showToast({
        title: '当前平台不支持获取WiFi列表',
        icon: 'none'
    });
    isGettingWifi.value = false;
    // #endif
};

// 选择WiFi
const selectWifi = (wifi: any) => {
    if (wifi && wifi.SSID) {
        editForm.wifi_name = wifi.SSID;
    }
};

// 搜索处理
const handleSearch = () => {
    const mescroll = getMescroll();
    if (mescroll) {
        mescroll.resetUpScroll();
    }
};

// 删除处理
const handleDelete = (item: any) => {
    delWifiQrcode(item.id).then((res: any) => {
        if (res.code === 1) {
            uni.showToast({
                title: '删除成功',
                icon: 'success'
            });
            const mescroll = getMescroll();
            if (mescroll) {
                mescroll.resetUpScroll();
            }
        }
    });
};

// 编辑处理
const handleEdit = (item: any) => {
    // 设置当前编辑项
    currentEditId.value = item.id;
    editForm.wifi_name = item.wifi_name || '';
    editForm.wifi_password = item.wifi_password || ''; // 密码通常不会返回，需要用户重新输入
    editForm.name = item.name || '';
    editForm.closure = item.closure || ''; // 设置截流口令

    // 显示弹窗
    showEditPopup.value = true;
};

// 提交编辑
const submitEdit = () => {
    if (!editForm.wifi_name) {
        uni.showToast({
            title: 'WiFi名称不能为空',
            icon: 'none'
        });
        return;
    }

    // 构建请求参数
    const params: any = {
        wifi_name: editForm.wifi_name,
        name: editForm.name
    };

    // 如果有输入密码则添加
    if (editForm.wifi_password) {
        params.wifi_password = editForm.wifi_password;
    }

    // 如果有输入截流口令则添加
    if (editForm.closure) {
        params.closure = editForm.closure;
    }

    // 判断是新增还是编辑
    if (currentEditId.value) {
        // 编辑模式，添加ID
        params.id = currentEditId.value;

        // 发送编辑请求
        editeWifiQrcode(params)
            .then((res: any) => {
                if (res.code === 1) {
                    uni.showToast({
                        title: '修改成功',
                        icon: 'success'
                    });

                    // 关闭弹窗
                    showEditPopup.value = false;

                    // 刷新列表
                    const mescroll = getMescroll();
                    if (mescroll) {
                        mescroll.resetUpScroll();
                    }
                } else {
                    uni.showToast({
                        title: res.msg || '修改失败',
                        icon: 'none'
                    });
                }
            })
            .catch((err: any) => {
                uni.showToast({
                    title: '修改失败',
                    icon: 'none'
                });
            });
    } else {
        // 新增模式
        // 发送新增请求
        addWifi(params)
            .then((res: any) => {
                if (res.code === 1) {
                    uni.showToast({
                        title: '添加成功',
                        icon: 'success'
                    });

                    // 关闭弹窗
                    showEditPopup.value = false;

                    // 刷新列表
                    const mescroll = getMescroll();
                    if (mescroll) {
                        mescroll.resetUpScroll();
                    }
                } else {
                    uni.showToast({
                        title: res.msg || '添加失败',
                        icon: 'none'
                    });
                }
            })
            .catch((err: any) => {
                uni.showToast({
                    title: '添加失败',
                    icon: 'none'
                });
            });
    }
};

// 预览处理
const handlePreview = (item: any) => {
    // 设置预览信息
    previewInfo.id = item.id || '';
    previewInfo.name = item.name || '';
    previewInfo.wifi_name = item.wifi_name || '';
    previewInfo.wifi_password = item.wifi_password || '';
    previewInfo.qrcode = item.qrcode || '';
    previewInfo.closure = item.closure || '';

    // 显示预览弹窗
    showPreviewPopup.value = true;
};

// 下载二维码
const downloadQrcode = () => {
    if (!previewInfo.qrcode) {
        uni.showToast({
            title: '二维码不存在',
            icon: 'none'
        });
        return;
    }

    const qrcodeUrl = img(previewInfo.qrcode);

    // #ifdef MP-WEIXIN
    // 微信小程序环境下，使用微信的保存图片到相册API
    uni.showLoading({
        title: '正在保存...',
        mask: true
    });

    // 先下载图片到本地临时文件
    uni.downloadFile({
        url: qrcodeUrl,
        success: (res) => {
            if (res.statusCode === 200) {
                // 保存图片到相册
                uni.saveImageToPhotosAlbum({
                    filePath: res.tempFilePath,
                    success: () => {
                        uni.hideLoading();
                        uni.showToast({
                            title: '已保存到相册',
                            icon: 'success'
                        });
                    },
                    fail: (err) => {
                        uni.hideLoading();
                        console.error('保存到相册失败:', err);
                        // 如果是用户拒绝授权的情况，提示用户打开权限
                        if (err.errMsg.indexOf('auth deny') >= 0 || err.errMsg.indexOf('authorize') >= 0) {
                            uni.showModal({
                                title: '提示',
                                content: '请允许保存图片到相册的权限',
                                confirmText: '去设置',
                                success: (res) => {
                                    if (res.confirm) {
                                        uni.openSetting();
                                    }
                                }
                            });
                        } else {
                            uni.showToast({
                                title: '保存失败',
                                icon: 'none'
                            });
                        }
                    }
                });
            } else {
                uni.hideLoading();
                uni.showToast({
                    title: '下载图片失败',
                    icon: 'none'
                });
            }
        },
        fail: () => {
            uni.hideLoading();
            uni.showToast({
                title: '下载图片失败',
                icon: 'none'
            });
        }
    });
    // #endif

    // #ifndef MP-WEIXIN
    // 其他平台使用通用下载函数
    downloadFileEvent(qrcodeUrl)
        .then(() => {
            uni.showToast({
                title: '下载成功',
                icon: 'success'
            });
        })
        .catch((err: any) => {
            uni.showToast({
                title: '下载失败',
                icon: 'none'
            });
        });
    // #endif
};

// 添加WiFi处理
const handleAddWifi = () => {
    // 清空编辑表单
    currentEditId.value = "";
    editForm.wifi_name = "";
    editForm.wifi_password = "";
    editForm.name = "";
    editForm.closure = "";
    nearbyWifiList.value = [];

    // 显示编辑弹窗
    showEditPopup.value = true;
};

// 打印WiFi二维码
const handlePrint = (item: any) => {
    if (!item || !item.qrcode) {
        uni.showToast({
            title: '二维码不存在',
            icon: 'none'
        });
        return;
    }

    // 设置预览信息用于打印
    previewInfo.id = item.id || '';
    previewInfo.name = item.name || '';
    previewInfo.wifi_name = item.wifi_name || '';
    previewInfo.wifi_password = item.wifi_password || '';
    previewInfo.qrcode = img(item.qrcode) || '';
    previewInfo.closure = item.closure || '';

    // #ifdef MP-WEIXIN
    // 微信小程序环境下，使用蓝牙打印
    uni.showLoading({
        title: '准备打印...'
    });

    // 获取已连接的蓝牙设备
    uni.getBluetoothAdapterState({
        success: (res) => {
            if (res.available) {
                // 蓝牙适配器可用，开始搜索打印机
                searchBluetoothPrinters();
            } else {
                uni.hideLoading();
                uni.showModal({
                    title: '提示',
                    content: '请打开蓝牙后再试',
                    showCancel: false
                });
            }
        },
        fail: () => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '获取蓝牙状态失败',
                showCancel: false
            });
        }
    });
    // #endif

    // #ifdef H5
    uni.showToast({
        title: '当前环境不支持蓝牙打印',
        icon: 'none'
    });
    // #endif

    // #ifdef APP-PLUS
    uni.showActionSheet({
        itemList: ['蓝牙打印', '保存到相册'],
        success: (res) => {
            if (res.tapIndex === 0) {
                // 蓝牙打印
                uni.showToast({
                    title: '正在开发蓝牙打印功能',
                    icon: 'none'
                });
            } else if (res.tapIndex === 1) {
                // 保存到相册
                downloadQrcode();
            }
        }
    });
    // #endif
};

// 搜索蓝牙打印机
const searchBluetoothPrinters = () => {
    // #ifdef MP-WEIXIN
    uni.startBluetoothDevicesDiscovery({
        services: ['1812'], // 打印服务UUID，根据实际打印机调整
        success: () => {
            setTimeout(() => {
                // 停止搜索，获取搜索到的设备
                uni.stopBluetoothDevicesDiscovery({
                    success: () => {
                        uni.getBluetoothDevices({
                            success: (res) => {
                                uni.hideLoading();
                                const printers = res.devices.filter((device: any) => {
                                    // 根据设备名称或服务过滤打印机设备
                                    return device.name && (
                                        device.name.toLowerCase().includes('print') ||
                                        device.name.toLowerCase().includes('pos') ||
                                        device.name.toLowerCase().includes('thermal')
                                    );
                                });

                                if (printers.length > 0) {
                                    showPrinterList(printers);
                                } else {
                                    uni.showModal({
                                        title: '提示',
                                        content: '未找到打印设备，请确保打印机已开启并在范围内',
                                        showCancel: false
                                    });
                                }
                            },
                            fail: () => {
                                uni.hideLoading();
                                uni.showModal({
                                    title: '提示',
                                    content: '获取蓝牙设备列表失败',
                                    showCancel: false
                                });
                            }
                        });
                    }
                });
            }, 5000); // 搜索5秒
        },
        fail: (err) => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '搜索蓝牙设备失败，请确保已授权蓝牙权限',
                showCancel: false
            });
        }
    });
    // #endif
};

// 显示打印机列表
const showPrinterList = (printers: any[]) => {
    // #ifdef MP-WEIXIN
    const printerNames = printers.map((printer: any) => printer.name || printer.deviceId);

    uni.showActionSheet({
        itemList: printerNames,
        success: (res) => {
            const selectedPrinter = printers[res.tapIndex];
            connectToPrinter(selectedPrinter);
        }
    });
    // #endif
};

// 连接到打印机
const connectToPrinter = (printer: any) => {
    // #ifdef MP-WEIXIN
    uni.showLoading({
        title: '连接打印机...'
    });

    uni.createBLEConnection({
        deviceId: printer.deviceId,
        success: () => {
            // 获取打印机服务
            uni.getBLEDeviceServices({
                deviceId: printer.deviceId,
                success: (res) => {
                    // 查找打印服务
                    const printService = res.services.find((service: any) =>
                        service.uuid.toLowerCase().includes('1812') ||
                        service.uuid.toLowerCase().includes('ff00') ||
                        service.uuid.toLowerCase().includes('ae30')
                    );

                    if (printService) {
                        // 获取打印特征值
                        uni.getBLEDeviceCharacteristics({
                            deviceId: printer.deviceId,
                            serviceId: printService.uuid,
                            success: (res) => {
                                // 查找可写的特征值
                                const writableChar = res.characteristics.find((char: any) =>
                                    char.properties.write || char.properties.writeNoResponse
                                );

                                if (writableChar) {
                                    uni.hideLoading();
                                    // 准备打印数据
                                    preparePrintData(printer.deviceId, printService.uuid, writableChar.uuid);
                                } else {
                                    uni.hideLoading();
                                    uni.showModal({
                                        title: '提示',
                                        content: '未找到可用的打印特征值',
                                        showCancel: false
                                    });
                                }
                            },
                            fail: () => {
                                uni.hideLoading();
                                uni.showModal({
                                    title: '提示',
                                    content: '获取打印特征值失败',
                                    showCancel: false
                                });
                            }
                        });
                    } else {
                        uni.hideLoading();
                        uni.showModal({
                            title: '提示',
                            content: '未找到打印服务',
                            showCancel: false
                        });
                    }
                },
                fail: () => {
                    uni.hideLoading();
                    uni.showModal({
                        title: '提示',
                        content: '获取设备服务失败',
                        showCancel: false
                    });
                }
            });
        },
        fail: () => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '连接打印机失败',
                showCancel: false
            });
        }
    });
    // #endif
};

// 准备打印数据
const preparePrintData = (deviceId: string, serviceId: string, characteristicId: string) => {
    // #ifdef MP-WEIXIN
    uni.showLoading({
        title: '准备打印数据...'
    });

    // 下载二维码图片
    uni.downloadFile({
        url: previewInfo.qrcode, // 这里previewInfo.qrcode已经通过img()处理过
        success: (res) => {
            if (res.statusCode === 200) {
                // 获取图片信息
                uni.getImageInfo({
                    src: res.tempFilePath,
                    success: (imageInfo) => {
                        uni.hideLoading();
                        // 开始打印
                        startPrinting(deviceId, serviceId, characteristicId, res.tempFilePath, imageInfo);
                    },
                    fail: () => {
                        uni.hideLoading();
                        uni.showModal({
                            title: '提示',
                            content: '获取图片信息失败',
                            showCancel: false
                        });
                    }
                });
            } else {
                uni.hideLoading();
                uni.showModal({
                    title: '提示',
                    content: '下载二维码图片失败',
                    showCancel: false
                });
            }
        },
        fail: () => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '下载二维码图片失败',
                showCancel: false
            });
        }
    });
    // #endif
};

// 开始打印
const startPrinting = (deviceId: string, serviceId: string, characteristicId: string, imagePath: string, imageInfo: any) => {
    // #ifdef MP-WEIXIN
    uni.showLoading({
        title: '打印中...'
    });

    // 这里需要根据具体打印机型号和协议构建打印数据
    // 以下是一个简化的示例，实际应用中需要根据打印机协议调整

    // 1. 打印标题
    const titleData = new Uint8Array([
        0x1B, 0x40,  // 初始化打印机
        0x1B, 0x61, 0x01,  // 居中对齐
        0x1B, 0x21, 0x30,  // 设置字体大小
    ]);

    // 2. 打印WiFi信息
    const infoData = new Uint8Array([
        0x1B, 0x61, 0x00,  // 左对齐
        0x1B, 0x21, 0x00,  // 正常字体
    ]);

    // 3. 打印二维码（这部分需要根据具体打印机型号调整）
    const qrcodeData = new Uint8Array([
        0x1B, 0x61, 0x01,  // 居中对齐
        0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, 0x06,  // 设置二维码大小
        0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x45, 0x30,  // 设置纠错级别
    ]);

    // 4. 结束打印
    const endData = new Uint8Array([
        0x1B, 0x64, 0x02,  // 走纸2行
        0x1D, 0x56, 0x42, 0x00  // 切纸
    ]);

    // 依次发送数据
    sendPrintData(deviceId, serviceId, characteristicId, titleData)
        .then(() => sendPrintData(deviceId, serviceId, characteristicId, infoData))
        .then(() => sendPrintData(deviceId, serviceId, characteristicId, qrcodeData))
        .then(() => sendPrintData(deviceId, serviceId, characteristicId, endData))
        .then(() => {
            uni.hideLoading();
            uni.showToast({
                title: '打印完成',
                icon: 'success'
            });

            // 断开连接
            uni.closeBLEConnection({
                deviceId: deviceId
            });
        })
        .catch(() => {
            uni.hideLoading();
            uni.showModal({
                title: '提示',
                content: '打印过程中出错',
                showCancel: false
            });

            // 断开连接
            uni.closeBLEConnection({
                deviceId: deviceId
            });
        });
    // #endif
};

// 发送打印数据
const sendPrintData = (deviceId: string, serviceId: string, characteristicId: string, data: Uint8Array) => {
    // #ifdef MP-WEIXIN
    return new Promise((resolve, reject) => {
        uni.writeBLECharacteristicValue({
            deviceId: deviceId,
            serviceId: serviceId,
            characteristicId: characteristicId,
            value: data.buffer,
            success: resolve,
            fail: reject
        });
    });
    // #endif

    // #ifndef MP-WEIXIN
    return Promise.resolve();
    // #endif
};


</script>

<style lang="scss">
.iconfont {
    font-family: "iconfont" !important;
    font-style: normal;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

.icon-search:before {
    content: "\e8ef";
}

.icon-print:before {
    content: "\e742";
}

.icon-delete:before {
    content: "\e74b";
}

.icon-edit:before {
    content: "\e66e";
}

.icon-preview:before {
    content: "\e7b9";
}

.icon-more:before {
    content: "\e684";
}

.icon-share:before {
    content: "\e739";
}

.icon-wifi:before {
    content: "\e665";
}

.icon-add:before {
    content: "\e6da";
}

.max-h-80vh {
    max-height: 60vh;
}
</style>
