<template>
    <div class="main-container">
        <el-card class="box-card !border-none" shadow="never">

            <div class="flex justify-between items-center">
                <span class="text-lg">{{ pageName }}</span>
                <!-- <el-button type="primary" @click="addEvent">
                    {{ t('addTkwifiContact') }}
                </el-button> -->
            </div>

            <!-- 漏斗概览 -->
            <div class="grid grid-cols-2 md:grid-cols-5 gap-[12px] my-[12px]">
                <div class="funnel-card funnel-view">
                    <span class="funnel-label">看广告次数</span>
                    <span class="funnel-num">{{ funnel.view_num }}</span>
                </div>
                <div class="funnel-card funnel-complete">
                    <span class="funnel-label">完整看完</span>
                    <span class="funnel-num">{{ funnel.complete_num }}</span>
                </div>
                <div class="funnel-card funnel-reward">
                    <span class="funnel-label">已发放佣金(笔)</span>
                    <span class="funnel-num">{{ funnel.reward_num }}</span>
                </div>
                <div class="funnel-card funnel-skip">
                    <span class="funnel-label">未发放(笔)</span>
                    <span class="funnel-num">{{ funnel.skip_num }}</span>
                </div>
                <div class="funnel-card funnel-amount">
                    <span class="funnel-label">佣金合计(元)</span>
                    <span class="funnel-num">¥{{ (Number(funnel.own_total) + Number(funnel.first_total) + Number(funnel.second_total)).toFixed(2) }}</span>
                </div>
            </div>

            <el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
                <el-form :inline="true" :model="tkwifiContactTable.searchParam" ref="searchFormRef">
                    <el-form-item label="广告状态" prop="ad_status">
                        <el-select class="w-[160px]" v-model="tkwifiContactTable.searchParam.ad_status" clearable
                            placeholder="全部">
                            <el-option v-for="(label, val) in adStatusMap" :key="val" :label="label" :value="val" />
                        </el-select>
                    </el-form-item>
                    <el-form-item label="佣金状态" prop="reward_status">
                        <el-select class="w-[160px]" v-model="tkwifiContactTable.searchParam.reward_status" clearable
                            placeholder="全部">
                            <el-option v-for="(label, val) in rewardStatusMap" :key="val" :label="label" :value="val" />
                        </el-select>
                    </el-form-item>

                    <el-form-item :label="t('createTime')" prop="create_time">
                        <el-date-picker v-model="tkwifiContactTable.searchParam.create_time" type="datetimerange"
                            format="YYYY-MM-DD hh:mm:ss" :start-placeholder="t('startDate')"
                            :end-placeholder="t('endDate')" />
                    </el-form-item>

                    <el-form-item>
                        <el-button type="primary" @click="loadTkwifiContactList()">{{ t('search') }}</el-button>
                        <el-button @click="resetForm(searchFormRef)">{{ t('reset') }}</el-button>
                    </el-form-item>
                </el-form>
            </el-card>

            <div class="mt-[10px]">
                <el-table :data="tkwifiContactTable.data" size="large" v-loading="tkwifiContactTable.loading"
                    stripe border :header-cell-style="{ background: '#f5f7fa', color: '#303133', fontWeight: '600' }"
                    class="custom-table">
                    <template #empty>
                        <div class="py-[40px] flex flex-col items-center gap-[8px]">
                            <el-icon :size="48" class="text-gray-300"><DataAnalysis /></el-icon>
                            <span class="text-gray-400">{{ !tkwifiContactTable.loading ? t('emptyData') : '' }}</span>
                        </div>
                    </template>
                    <el-table-column prop="wifi_id_name" :label="t('wifiId')" min-width="120"
                        :show-overflow-tooltip="true">
                        <template #default="{ row }">
                            <el-tag type="primary" effect="light" round class="!font-medium">{{ row.wifi_id_name || '-' }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="wifi_name" :label="t('wifiName')" min-width="140"
                        :show-overflow-tooltip="true">
                        <template #default="{ row }">
                            <div class="flex items-center gap-[6px]">
                                <el-icon class="text-blue-500"><Connection /></el-icon>
                                <span class="font-medium">{{ row.wifi_name || '-' }}</span>
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column label="观看用户" min-width="120" :show-overflow-tooltip="true">
                        <template #default="{ row }">
                            <span>{{ row.view_member_name || (row.member_id ? ('ID:' + row.member_id) : '未登录') }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column label="广告状态" min-width="110" align="center">
                        <template #default="{ row }">
                            <el-tag :type="adTagType(row.ad_status)" effect="light" round>{{ row.ad_status_name || '-' }}</el-tag>
                        </template>
                    </el-table-column>

                    <el-table-column label="佣金状态" min-width="160" align="center">
                        <template #default="{ row }">
                            <el-tag :type="rewardTagType(row.reward_status)" effect="light" round>{{ row.reward_status_name || '-' }}</el-tag>
                            <div v-if="Number(row.reward_status) === 3" class="text-xs text-gray-400 mt-[4px] leading-tight">
                                {{ row.reason_desc || '-' }}
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column :label="t('ownProfit')" min-width="170" align="center">
                        <template #default="{ row }">
                            <div v-if="Number(row.own_fee || 0) > 0" class="profit-card profit-own">
                                <span class="text-xs text-gray-500 truncate max-w-full">{{ row.own_member_name || '-' }}</span>
                                <span class="text-base font-bold text-blue-600">¥{{ Number(row.own_fee).toFixed(2) }}</span>
                            </div>
                            <span v-else class="text-gray-300">-</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="t('firstProfit')" min-width="170" align="center">
                        <template #default="{ row }">
                            <div v-if="Number(row.first_fee || 0) > 0" class="profit-card profit-first">
                                <span class="text-xs text-gray-500 truncate max-w-full">{{ row.first_member_name || '-' }}</span>
                                <span class="text-base font-bold text-green-600">¥{{ Number(row.first_fee).toFixed(2) }}</span>
                            </div>
                            <span v-else class="text-gray-300">-</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="t('secondProfit')" min-width="170" align="center">
                        <template #default="{ row }">
                            <div v-if="Number(row.second_fee || 0) > 0" class="profit-card profit-second">
                                <span class="text-xs text-gray-500 truncate max-w-full">{{ row.second_member_name || '-' }}</span>
                                <span class="text-base font-bold text-orange-600">¥{{ Number(row.second_fee).toFixed(2) }}</span>
                            </div>
                            <span v-else class="text-gray-300">-</span>
                        </template>
                    </el-table-column>

                    <el-table-column :label="t('operation')" fixed="right" min-width="100" align="center">
                        <template #default="{ row }">
                            <!-- <el-button type="primary" link @click="editEvent(row)">{{ t('edit') }}</el-button> -->
                            <el-button type="danger" link :icon="Delete" @click="deleteEvent(row.id)">{{ t('delete') }}</el-button>
                        </template>
                    </el-table-column>

                </el-table>
                <div class="mt-[16px] flex justify-end">
                    <el-pagination v-model:current-page="tkwifiContactTable.page"
                        v-model:page-size="tkwifiContactTable.limit" layout="total, sizes, prev, pager, next, jumper"
                        :total="tkwifiContactTable.total" @size-change="loadTkwifiContactList()"
                        @current-change="loadTkwifiContactList" background />
                </div>
            </div>

            <edit ref="editTkwifiContactDialog" @complete="loadTkwifiContactList" />
        </el-card>
    </div>
</template>

<script lang="ts" setup>
import { reactive, ref, watch } from 'vue'
import { t } from '@/lang'
import { useDictionary } from '@/app/api/dict'
import { getTkwifiContactList, deleteTkwifiContact, getWithTkwifiListList, getTkwifiContactFunnel } from '@/addon/tk_wifi/api/tkwificontact'
import { img } from '@/utils/common'
import { ElMessageBox, FormInstance } from 'element-plus'
import { Connection, Delete, DataAnalysis } from '@element-plus/icons-vue'
import Edit from '@/addon/tk_wifi/views/tkwificontact/components/tkwificontact-edit.vue'
import { useRoute } from 'vue-router'
const route = useRoute()
const pageName = route.meta.title;

let tkwifiContactTable = reactive({
    page: 1,
    limit: 10,
    total: 0,
    loading: true,
    data: [],
    searchParam: {
        "wifi_id": "",
        "ad_status": "",
        "reward_status": "",
        "create_time": []
    }
})

// 广告/佣金状态字典(与后端 RewardReasonDict 对应)
const adStatusMap: Record<string, string> = {
    '1': '观看中', '2': '已看完', '3': '中途退出', '4': '无广告填充', '5': '广告异常放行', '6': '无需广告'
}
const rewardStatusMap: Record<string, string> = {
    '1': '已发放', '3': '未发放'
}
const adTagType = (s: any) => ({ 2: 'success', 3: 'danger', 4: 'info', 5: 'warning', 6: 'info', 1: 'warning' } as any)[Number(s)] || 'info'
const rewardTagType = (s: any) => Number(s) === 1 ? 'success' : (Number(s) === 3 ? 'danger' : 'info')

// 漏斗概览
const funnel = reactive({
    view_num: 0, complete_num: 0, reward_num: 0, skip_num: 0,
    own_total: 0, first_total: 0, second_total: 0
})
const loadFunnel = () => {
    getTkwifiContactFunnel({
        wifi_id: tkwifiContactTable.searchParam.wifi_id,
        create_time: tkwifiContactTable.searchParam.create_time
    }).then(res => {
        Object.assign(funnel, res.data || {})
    }).catch(() => { })
}

const searchFormRef = ref<FormInstance>()

// 选中数据
const selectData = ref<any[]>([])

// 字典数据


/**
 * 获取连接记录列表
 */
const loadTkwifiContactList = (page: number = 1) => {
    tkwifiContactTable.loading = true
    tkwifiContactTable.page = page

    getTkwifiContactList({
        page: tkwifiContactTable.page,
        limit: tkwifiContactTable.limit,
        ...tkwifiContactTable.searchParam
    }).then(res => {
        tkwifiContactTable.loading = false
        tkwifiContactTable.data = res.data.data
        tkwifiContactTable.total = res.data.total
    }).catch(() => {
        tkwifiContactTable.loading = false
    })
    loadFunnel()
}
loadTkwifiContactList()

const editTkwifiContactDialog: Record<string, any> | null = ref(null)

/**
 * 添加连接记录
 */
const addEvent = () => {
    editTkwifiContactDialog.value.setFormData()
    editTkwifiContactDialog.value.showDialog = true
}

/**
 * 编辑连接记录
 * @param data
 */
const editEvent = (data: any) => {
    editTkwifiContactDialog.value.setFormData(data)
    editTkwifiContactDialog.value.showDialog = true
}

/**
 * 删除连接记录
 */
const deleteEvent = (id: number) => {
    ElMessageBox.confirm(t('tkwifiContactDeleteTips'), t('warning'),
        {
            confirmButtonText: t('confirm'),
            cancelButtonText: t('cancel'),
            type: 'warning',
        }
    ).then(() => {
        deleteTkwifiContact(id).then(() => {
            loadTkwifiContactList()
        }).catch(() => {
        })
    })
}


const wifiIdList = ref([])
const setWifiIdList = async () => {
    wifiIdList.value = await (await getWithTkwifiListList({})).data
}
setWifiIdList()

const resetForm = (formEl: FormInstance | undefined) => {
    if (!formEl) return
    formEl.resetFields()
    loadTkwifiContactList()
}
</script>

<style lang="scss" scoped>
/* 自定义表格 */
.custom-table {
    border-radius: 8px;
    overflow: hidden;

    :deep(.el-table__header-wrapper) {
        th.el-table__cell {
            font-size: 14px;
        }
    }

    :deep(.el-table__row:hover > td.el-table__cell) {
        background-color: #f8fafc !important;
    }
}

/* 漏斗概览卡片 */
.funnel-card {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 14px 16px;
    border-radius: 10px;
    background: #f8fafc;
    border: 1px solid #eef2f7;
}

.funnel-label {
    font-size: 13px;
    color: #64748b;
}

.funnel-num {
    font-size: 22px;
    font-weight: 700;
    color: #1e293b;
}

.funnel-view { background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%); }
.funnel-complete { background: linear-gradient(135deg, #ecfeff 0%, #cffafe 100%); }
.funnel-reward { background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%); }
.funnel-skip { background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%); }
.funnel-amount { background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%); }

/* 分润卡片 */
.profit-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    padding: 6px 10px;
    border-radius: 6px;
    transition: all 0.25s ease;
    cursor: default;

    &:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
    }
}

.profit-own {
    background: linear-gradient(135deg, #eff6ff 0%, #dbeafe 100%);
}

.profit-first {
    background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
}

.profit-second {
    background: linear-gradient(135deg, #fff7ed 0%, #ffedd5 100%);
}

/* 多行超出隐藏 */
.multi-hidden {
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
</style>
