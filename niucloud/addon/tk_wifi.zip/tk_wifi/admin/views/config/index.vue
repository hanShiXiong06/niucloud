<template>
  <div class="main-container">
    <el-form :model="formData" label-width="150px" ref="ruleFormRef" :rules="rules" class="page-form"
      v-loading="loading">
      <el-card class="box-card !border-none z-0" shadow="never">
        <div style="width: 640px" class="mb-2">
          <el-alert type="info" title="请完成基础设置" :closable="false" show-icon />
        </div>
        <el-form-item label="连接类型" prop="type">
          <el-radio-group v-model="formData.type">
            <el-radio :label="'direct'">直接连接</el-radio>
            <el-radio :label="'adv'">看广告</el-radio>
            <!-- <el-radio :label="'pay'">支付费用</el-radio> -->
          </el-radio-group>
          <p class="ml-2 text-gray-400">用户扫广告码后连接wifi的类型</p>
        </el-form-item>
        <el-form-item prop="adv_id" v-if="formData.type === 'adv'" label="广告id">
          <el-input style="width: 240px;" v-model="formData.adv_id" placeholder="请输入广告id" />
          <span class="ml-2 text-gray-400">广告id</span>
        </el-form-item>
        <!-- <el-form-item label="广告图像" prop="add_banner">
          <upload-image v-model="formData.add_banner" />
          <span class="ml-2 text-gray-400">广告图像显示在新增wifi码页面</span>
        </el-form-item> -->
        <el-form-item label="选择链接" prop="link">
          <diy-link v-model="formData.link" />
          <span class="ml-2 text-gray-400">wifi连接成功跳转系统引流页面</span>
        </el-form-item>
        <el-form-item prop="is_fenxiao" label="地推分销">
          <el-radio-group v-model="formData.is_fenxiao">
            <el-radio :label="'0'">关闭</el-radio>
            <el-radio :label="'1'">开启</el-radio>
          </el-radio-group>
          <p class="ml-2 text-gray-400">开启分销后每次扫码连接会给推广员佣金</p>
        </el-form-item>
        <el-form-item v-if="formData.is_fenxiao == 1" prop="first_fee" label="一级分销">
          <el-input-number style="width: 240px;" v-model="formData.first_fee" placeholder="请输入一级分销佣金" />
          <span class="ml-2 text-gray-400">用户扫码连接后给一级分销推广员佣金</span>
        </el-form-item>
        <el-form-item v-if="formData.is_fenxiao == 1" prop="second_fee" label="二级分销">
          <el-input-number style="width: 240px;" v-model="formData.second_fee" placeholder="请输入二级分销佣金" />
          <span class="ml-2 text-gray-400">用户扫码连接后给二级分销推广员佣金</span>
        </el-form-item>
        <el-form-item prop="own_fee" label="商家佣金">
          <el-input-number style="width: 240px;" v-model="formData.own_fee" placeholder="请输入商家佣金" />
          <span class="ml-2 text-gray-400">用户扫码连接后给商家佣金</span>
        </el-form-item>
        <!-- <el-form-item label="推广员" prop="sharer_way">
          <el-radio-group v-model="formData.sharer_way">
            <el-radio :label="'direct'">无门槛</el-radio>
            <el-radio :label="'pay'">支付费用</el-radio>
          </el-radio-group>
          <p class="ml-2 text-gray-400">wifi码地推人员申请方式;无门槛代表自动成为地推人员</p>
        </el-form-item>
        <el-form-item prop="sharer_fee" v-if="formData.sharer_way === 'pay'" lable="推广者申请费用">
          <el-input-number style="width: 240px;" v-model="formData.sharer_fee" placeholder="请输入推广者申请费用" />
          <span class="ml-2 text-gray-400">推广者申请费用</span>
        </el-form-item> -->
        <el-form-item prop="sharer_content" label="申请推广员介绍">
          <div style="width: 640px">
            <editor v-model="formData.sharer_content" />
          </div>
        </el-form-item>
      </el-card>
    </el-form>
    <div class="fixed-footer-wrap">
      <div class="fixed-footer">
        <el-button type="primary" @click="onSave()">{{ t("save") }}</el-button>
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { reactive, ref, computed } from "vue";
import { t } from "@/lang";
import { FormInstance, ElMessage } from "element-plus";
import { CopyDocument } from '@element-plus/icons-vue'
import { getConfig, setConfig } from "@/addon/tk_wifi/api/config";
const loading = ref(true);
const ruleFormRef = ref<FormInstance>();
const formData = reactive({
  add_banner: "",
  type: "direct",
  link: "",
  wifi_fee: 0.1,
  adv_id: '',
  sharer_way: 'direct',//推广者申请方式
  sharer_fee: 0.1,//推广者申请费用
  sharer_content: '',//推广者申请内容
  is_auto_sharer: 0,
  is_fenxiao: 0,
  first_fee: 0.01,
  second_fee: 0.01,
  own_fee: 0.01,
});
const rules = computed(() => {
  return {
    add_banner: [{ required: true, message: '请上传广告图像' }],
    type: [{ required: true, message: '请输入连接类型' }],
    link: [{ required: true, message: '请输入选择链接' }],
    adv_id: [{ required: true, message: '请输入广告id' }],
    sharer_content: [{ required: true, message: '请输入推广介绍' }],
    is_auto_sharer: [{ required: true, message: '请选择成为推广员模式' }],
    is_fenxiao: [{ required: true, message: '请选择是否开启分销' }],
    first_fee: [{ required: true, message: '请输入一级分销佣金' }],
    second_fee: [{ required: true, message: '请输入二级分销佣金' }],
    own_fee: [{ required: true, message: '请输入商家佣金' }],
  }
})
const getData = async () => {
  const data = await getConfig();
  loading.value = false;
  for (const key in formData) {
    formData[key] = data.data[key];
  }
};
getData();
const onSave = async () => {
  await setConfig(formData);
  getData();
};
const copyCallbackUrl = () => {
  if (!formData.callback_url) {
    ElMessage.warning('回调地址为空')
    return
  }
  navigator.clipboard.writeText(formData.callback_url).then(() => {
    ElMessage.success('复制成功')
  }).catch(() => {
    ElMessage.error('复制失败')
  })
}
</script>

<style lang="scss" scoped></style>
