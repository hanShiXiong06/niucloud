<template>
    <div class="main-container">
        <el-card class="box-card !border-none" shadow="never">

            <div class="flex justify-between items-center">
                <span class="text-lg">{{ pageName }}</span>

            </div>

            <el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
                <el-form :inline="true" :model="memberTable.searchParam" ref="searchFormRef">


                    <el-form-item :label="t('status')" prop="status">
                        <el-select v-model="memberTable.searchParam.status" placeholder="请选择状态">
                            <block v-for="(item, index) in sharerStatus" :key="index">
                                <el-option :label="item" :value="index" />
                            </block>
                        </el-select>
                    </el-form-item>
                    <el-form-item :label="t('createTime')" prop="create_time">
                        <el-date-picker v-model="memberTable.searchParam.create_time" type="datetimerange"
                            format="YYYY-MM-DD hh:mm:ss" :start-placeholder="t('startDate')"
                            :end-placeholder="t('endDate')" />
                    </el-form-item>

                    <el-form-item>
                        <el-button type="primary" @click="loadMemberList()">{{ t('search') }}</el-button>
                        <el-button @click="resetForm(searchFormRef)">{{ t('reset') }}</el-button>
                    </el-form-item>
                </el-form>
            </el-card>

            <div class="mt-[10px]">
                <el-table :data="memberTable.data" size="large" v-loading="memberTable.loading">
                    <template #empty>
                        <span>{{ !memberTable.loading ? t('emptyData') : '' }}</span>
                    </template>
                    <el-table-column prop="member_id_name" :label="t('memberId')" min-width="120"
                        :show-overflow-tooltip="true" />

                    <el-table-column prop="pid_name" :label="t('pid')" min-width="120" :show-overflow-tooltip="true" />

                    <el-table-column prop="status_name" :label="t('status')" min-width="120"
                        :show-overflow-tooltip="true">
                        <template #default="{ row }">
                            <el-tag :type="row.status == 1 ? 'success' : 'danger'">
                                {{ row.status_name }}
                            </el-tag>
                        </template>
                    </el-table-column>
                    <!-- 
                    <el-table-column prop="code" :label="t('code')" min-width="120" :show-overflow-tooltip="true" /> -->

                    <el-table-column :label="t('operation')" fixed="right" min-width="120">
                        <template #default="{ row }">
                            <el-button type="primary" link @click="editEvent(row)">{{ t('edit') }}</el-button>
                            <el-button type="primary" link @click="deleteEvent(row.member_id)">{{ t('delete')
                            }}</el-button>
                        </template>
                    </el-table-column>

                </el-table>
                <div class="mt-[16px] flex justify-end">
                    <el-pagination v-model:current-page="memberTable.page" v-model:page-size="memberTable.limit"
                        layout="total, sizes, prev, pager, next, jumper" :total="memberTable.total"
                        @size-change="loadMemberList()" @current-change="loadMemberList" />
                </div>
            </div>

            <edit ref="editMemberDialog" @complete="loadMemberList" />
        </el-card>
    </div>
</template>

<script lang="ts" setup>
import { reactive, ref, watch } from 'vue'
import { t } from '@/lang'
import { useDictionary } from '@/app/api/dict'
import { getMemberList, deleteMember, getWithMemberList, getSharerStatus } from '@/addon/tk_wifi/api/member'
import { img } from '@/utils/common'
import { ElMessageBox, FormInstance } from 'element-plus'
import Edit from '@/addon/tk_wifi/views/member/components/member-edit.vue'
import { useRoute } from 'vue-router'
const route = useRoute()
const pageName = route.meta.title;
const sharerStatus = ref({})
getSharerStatus().then(res => {
    sharerStatus.value = res.data
})

let memberTable = reactive({
    page: 1,
    limit: 10,
    total: 0,
    loading: true,
    data: [],
    searchParam: {
        "site_id": "",
        "pid": "",
        "status": "",
        "create_time": []
    }
})

const searchFormRef = ref<FormInstance>()

// 选中数据
const selectData = ref<any[]>([])

// 字典数据


/**
 * 获取推广者列表
 */
const loadMemberList = (page: number = 1) => {
    memberTable.loading = true
    memberTable.page = page

    getMemberList({
        page: memberTable.page,
        limit: memberTable.limit,
        ...memberTable.searchParam
    }).then(res => {
        memberTable.loading = false
        memberTable.data = res.data.data
        memberTable.total = res.data.total
    }).catch(() => {
        memberTable.loading = false
    })
}
loadMemberList()

const editMemberDialog: Record<string, any> | null = ref(null)

/**
 * 添加推广者
 */
const addEvent = () => {
    editMemberDialog.value.setFormData()
    editMemberDialog.value.showDialog = true
}

/**
 * 编辑推广者
 * @param data
 */
const editEvent = (data: any) => {
    editMemberDialog.value.setFormData(data)
    editMemberDialog.value.showDialog = true
}

/**
 * 删除推广者
 */
const deleteEvent = (id: number) => {
    ElMessageBox.confirm(t('memberDeleteTips'), t('warning'),
        {
            confirmButtonText: t('confirm'),
            cancelButtonText: t('cancel'),
            type: 'warning',
        }
    ).then(() => {
        deleteMember(id).then(() => {
            loadMemberList()
        }).catch(() => {
        })
    })
}


const memberIdList = ref([])
const setMemberIdList = async () => {
    memberIdList.value = await (await getWithMemberList({})).data
}
setMemberIdList()
const pidList = ref([])
const setPidList = async () => {
    pidList.value = await (await getWithMemberList({})).data
}
setPidList()

const resetForm = (formEl: FormInstance | undefined) => {
    if (!formEl) return
    formEl.resetFields()
    loadMemberList()
}
</script>

<style lang="scss" scoped>
/* 多行超出隐藏 */
.multi-hidden {
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
</style>
