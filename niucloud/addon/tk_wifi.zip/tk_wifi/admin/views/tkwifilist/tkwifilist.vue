<template>
    <div class="main-container">
        <el-card class="box-card !border-none" shadow="never">

            <div class="flex justify-between items-center">
                <span class="text-lg">{{ pageName }}</span>
                <el-button type="primary" @click="createEvent">
                    生成空码
                </el-button>
            </div>

            <el-card class="box-card !border-none my-[10px] table-search-wrap" shadow="never">
                <el-form :inline="true" :model="tkwifiListTable.searchParam" ref="searchFormRef">

                    <el-form-item label="会员" prop="member_id">
                        <el-select class="input-width" v-model="tkwifiListTable.searchParam.member_id" clearable
                            :placeholder="t('memberIdPlaceholder')">
                            <div class="mt-2 mb-2 ml-4">
                                <el-input @change="change" v-model="keyword" style="width: 200px"
                                    placeholder="搜索会员支持昵称/会员名">
                                    <template #append>搜索 </template></el-input>
                            </div>
                            <el-option label="请选择" value=""></el-option>
                            <el-option v-for="(item, index) in memberIdList" :key="index" :label="item['nickname']"
                                :value="item['member_id']" />
                        </el-select>
                    </el-form-item>

                    <el-form-item :label="t('name')" prop="name">
                        <el-input v-model="tkwifiListTable.searchParam.name" :placeholder="t('namePlaceholder')" />
                    </el-form-item>
                    <el-form-item :label="t('wifiName')" prop="wifi_name">
                        <el-input v-model="tkwifiListTable.searchParam.wifi_name"
                            :placeholder="t('wifiNamePlaceholder')" />
                    </el-form-item>
                    <el-form-item :label="t('createTime')" prop="create_time">
                        <el-date-picker v-model="tkwifiListTable.searchParam.create_time" type="datetimerange"
                            format="YYYY-MM-DD hh:mm:ss" :start-placeholder="t('startDate')"
                            :end-placeholder="t('endDate')" />
                    </el-form-item>

                    <el-form-item>
                        <el-button type="primary" @click="loadTkwifiListList()">{{ t('search') }}</el-button>
                        <el-button @click="resetForm(searchFormRef)">{{ t('reset') }}</el-button>
                    </el-form-item>
                </el-form>
            </el-card>
            <el-button @click="deleteSelectEvent()">删除选中</el-button>
            <el-button @click="downloadEvent()">下载选中</el-button>
            <div class="mt-[10px]">
                <el-table @selection-change="handleSelectionChange" :data="tkwifiListTable.data" size="large"
                    v-loading="tkwifiListTable.loading">
                    <template #empty>
                        <span>{{ !tkwifiListTable.loading ? t('emptyData') : '' }}</span>
                    </template>
                    <el-table-column type="selection" width="85" />
                    <el-table-column prop="id" label="ID" min-width="120" :show-overflow-tooltip="true" />
                    <el-table-column prop="name" :label="t('name')" min-width="120" :show-overflow-tooltip="true" />
                    <el-table-column prop="member_id_name" :label="t('memberId')" min-width="120"
                        :show-overflow-tooltip="true" />
                    <el-table-column prop="wifi_name" label="WIFI信息" min-width="120" :show-overflow-tooltip="true">
                        <template #default="{ row }">
                            <div>名称:{{ row.wifi_name }}</div>
                            <div>密码:{{ row.wifi_password }}</div>
                        </template>
                    </el-table-column>

                    <el-table-column prop="closure" label="状态" min-width="120" :show-overflow-tooltip="true">
                        <template #default="{ row }">
                            <div>
                                <el-tag v-if="row.is_use == 1" type="danger">已绑定</el-tag>
                                <el-tag v-if="row.is_use == 0" type="success">未绑定</el-tag>
                            </div>
                            <div class="mt-2">
                                <el-tag v-if="row.is_export == 1" type="danger">已导出</el-tag>
                                <el-tag v-if="row.is_export == 0" type="success">未导出</el-tag>
                            </div>
                        </template>
                    </el-table-column>

                    <el-table-column prop="contact_num" :label="t('contactNum')" min-width="120"
                        :show-overflow-tooltip="true" />
                    <el-table-column prop="create_time" :label="t('createTime')" min-width="120"
                        :show-overflow-tooltip="true" />
                    <el-table-column :label="t('qrcode')" width="100" align="left">
                        <template #default="{ row }">
                            <el-avatar v-if="row.qrcode" :src="img(row.qrcode)" />
                            <el-avatar v-else icon="UserFilled" />
                        </template>
                    </el-table-column>
                    <el-table-column :label="t('operation')" fixed="right" min-width="120">
                        <template #default="{ row }">
                            <!-- <el-button type="primary" link @click="editEvent(row)">{{ t('edit') }}</el-button> -->
                            <el-button type="primary" link @click="deleteEvent(row.id)">{{ t('delete') }}</el-button>
                        </template>
                    </el-table-column>

                </el-table>
                <div class="mt-[16px] flex justify-end">
                    <el-pagination v-model:current-page="tkwifiListTable.page" v-model:page-size="tkwifiListTable.limit"
                        layout="total, sizes, prev, pager, next, jumper" :total="tkwifiListTable.total"
                        @size-change="loadTkwifiListList()" @current-change="loadTkwifiListList" />
                </div>
            </div>

            <edit ref="editTkwifiListDialog" @complete="loadTkwifiListList" />
        </el-card>
    </div>
    <el-dialog width="500px" title="生成空码" v-model="createDialog" @close="createDialog = false">
        <el-form>
            <el-form-item label="生成数量">
                <el-input v-model.number="num" placeholder="请输入生成数量" type="number" min="1" max="100" />
            </el-form-item>
            <el-form-item label="">
                <div class="text-sm text-red">每次最多生成100张空码</div>
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="createDialog = false">取消</el-button>
                <el-button type="primary" @click="confirmCreate" :loading="createLoading">生成</el-button>
            </span>
        </template>
    </el-dialog>
</template>

<script lang="ts" setup>
import { reactive, ref, watch } from 'vue'
import { t } from '@/lang'
import { useDictionary } from '@/app/api/dict'
import { getTkwifiListList, deleteTkwifiList, getWithMemberList, createQrcode, downloadQrcode, delselect } from '@/addon/tk_wifi/api/tkwifilist'
import { img } from '@/utils/common'
import { ElMessageBox, FormInstance, ElMessage } from 'element-plus'
import Edit from '@/addon/tk_wifi/views/tkwifilist/components/tkwifilist-edit.vue'
import { useRoute } from 'vue-router'
const route = useRoute()
const pageName = route.meta.title;
const createDialog = ref(false)
const createLoading = ref(false)
const createEvent = () => {
    createDialog.value = true
    num.value = 1
}
const num = ref(1)
const confirmCreate = async () => {
    if (!num.value || num.value < 1) {
        ElMessage.warning('请输入有效的生成数量')
        return
    }

    createLoading.value = true
    try {
        await createQrcode({ num: num.value })
        ElMessage.success('空码生成成功')
        createDialog.value = false
        loadTkwifiListList()
    } catch (error) {
        console.error('生成空码失败', error)
    } finally {
        createLoading.value = false
    }
}
let tkwifiListTable = reactive({
    page: 1,
    limit: 10,
    total: 0,
    loading: true,
    data: [],
    searchParam: {
        "member_id": "",
        "name": "",
        "wifi_name": "",
        "create_time": []
    }
})

const searchFormRef = ref<FormInstance>()

// 选中数据
const selectData = ref<any[]>([]);
const handleSelectionChange = (val: any[]) => {
    selectData.value = val.map((item: any) => item.id);
};
const downloadEvent = async () => {
    if (selectData.value.length > 0) {
        try {
            const res = await downloadQrcode(selectData.value);
            console.log(res);
            const url = img(res.data.url);
            // 在新窗口中打开下载链接
            window.open(url, '_blank');
            ElMessage.success("下载成功");
        } catch (error) {
            console.error('下载失败', error);
            ElMessage.error("下载失败");
        }
    } else {
        ElMessageBox.confirm("请先选择要下载的数据", t("warning"), {
            confirmButtonText: t("confirm"),
            cancelButtonText: t("cancel"),
            type: "warning",
        });
    }
};


const deleteSelectEvent = async () => {
    if (selectData.value.length > 0) {
        delselect(selectData.value).then((res) => {
            loadTkwifiListList();
        });
    } else {
        ElMessageBox.confirm("请先选择要删除的数据", t("warning"), {
            confirmButtonText: t("confirm"),
            cancelButtonText: t("cancel"),
            type: "warning",
        });
    }
};


// 字典数据


/**
 * 获取wifi列列表
 */
const loadTkwifiListList = (page: number = 1) => {
    tkwifiListTable.loading = true
    tkwifiListTable.page = page

    getTkwifiListList({
        page: tkwifiListTable.page,
        limit: tkwifiListTable.limit,
        ...tkwifiListTable.searchParam
    }).then(res => {
        tkwifiListTable.loading = false
        tkwifiListTable.data = res.data.data
        tkwifiListTable.total = res.data.total
    }).catch(() => {
        tkwifiListTable.loading = false
    })
}
loadTkwifiListList()

const editTkwifiListDialog: Record<string, any> | null = ref(null)

/**
 * 添加wifi列
 */
const addEvent = () => {
    editTkwifiListDialog.value.setFormData()
    editTkwifiListDialog.value.showDialog = true
}

/**
 * 编辑wifi列
 * @param data
 */
const editEvent = (data: any) => {
    editTkwifiListDialog.value.setFormData(data)
    editTkwifiListDialog.value.showDialog = true
}

/**
 * 删除wifi列
 */
const deleteEvent = (id: number) => {
    ElMessageBox.confirm(t('tkwifiListDeleteTips'), t('warning'),
        {
            confirmButtonText: t('confirm'),
            cancelButtonText: t('cancel'),
            type: 'warning',
        }
    ).then(() => {
        deleteTkwifiList(id).then(() => {
            loadTkwifiListList()
        }).catch(() => {
        })
    })
}
const change = () => {
    setMemberIdList();
};
const keyword = ref();
const memberIdList = ref([]);
const setMemberIdList = async () => {
    memberIdList.value = await (
        await getWithMemberList({ keyword: keyword.value })
    ).data.data;
};
setMemberIdList();

const resetForm = (formEl: FormInstance | undefined) => {
    if (!formEl) return
    formEl.resetFields()
    loadTkwifiListList()
}
</script>

<style lang="scss" scoped>
/* 多行超出隐藏 */
.multi-hidden {
    word-break: break-all;
    text-overflow: ellipsis;
    overflow: hidden;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
}
</style>
