
import request from '@/utils/request'

/***************************************************** 机构基础配置 ****************************************************//**
 * 配置信息
 * @returns
 */
export function getConfig() {
    return request.get('tk_wifi/getconfig')
}


/**
 *配置修改
 * @param params
 */
export function setConfig(params: Record<string, any>) {
    return request.post(`tk_wifi/setconfig`, params, { showSuccessMessage: true })
}

