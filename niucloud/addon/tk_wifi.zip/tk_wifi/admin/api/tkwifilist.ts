import request from '@/utils/request'
export function createQrcode(params: Record<string, any>) {
    return request.post('tk_wifi/createqrcode', params)
}

export function delselect(params: Record<string, any>) {
    return request.post(`tk_wifi/delwifiselect`, params, { showErrorMessage: true, showSuccessMessage: true })
}
export function downloadQrcode(params: Record<string, any>) {
    return request.post(`tk_wifi/downloadqrcode`, params)
}
// USER_CODE_BEGIN -- tkwifi_list
/**
 * 获取wifi列列表
 * @param params
 * @returns
 */
export function getTkwifiListList(params: Record<string, any>) {
    return request.get(`tk_wifi/tkwifilist`, { params })
}

/**
 * 获取wifi列详情
 * @param id wifi列id
 * @returns
 */
export function getTkwifiListInfo(id: number) {
    return request.get(`tk_wifi/tkwifilist/${id}`);
}

/**
 * 添加wifi列
 * @param params
 * @returns
 */
export function addTkwifiList(params: Record<string, any>) {
    return request.post('tk_wifi/tkwifilist', params, { showErrorMessage: true, showSuccessMessage: true })
}

/**
 * 编辑wifi列
 * @param id
 * @param params
 * @returns
 */
export function editTkwifiList(params: Record<string, any>) {
    return request.put(`tk_wifi/tkwifilist/${params.id}`, params, { showErrorMessage: true, showSuccessMessage: true })
}

/**
 * 删除wifi列
 * @param id
 * @returns
 */
export function deleteTkwifiList(id: number) {
    return request.delete(`tk_wifi/tkwifilist/${id}`, { showErrorMessage: true, showSuccessMessage: true })
}

export function getWithMemberList(params: Record<string, any>) {
    return request.get('tk_wifi/member_all', { params })
}

// USER_CODE_END -- tkwifi_list
