import request from '@/utils/request'
export function getSharerStatus() {
    return request.get('tk_wifi/sharerstatus')
}
// USER_CODE_BEGIN -- tkwifi_member
/**
 * 获取推广者列表
 * @param params
 * @returns
 */
export function getMemberList(params: Record<string, any>) {
    return request.get(`tk_wifi/member`, { params })
}

/**
 * 获取推广者详情
 * @param member_id 推广者member_id
 * @returns
 */
export function getMemberInfo(member_id: number) {
    return request.get(`tk_wifi/member/${member_id}`);
}

/**
 * 添加推广者
 * @param params
 * @returns
 */
export function addMember(params: Record<string, any>) {
    return request.post('tk_wifi/member', params, { showErrorMessage: true, showSuccessMessage: true })
}

/**
 * 编辑推广者
 * @param member_id
 * @param params
 * @returns
 */
export function editMember(params: Record<string, any>) {
    return request.put(`tk_wifi/member/${params.member_id}`, params, { showErrorMessage: true, showSuccessMessage: true })
}

/**
 * 删除推广者
 * @param member_id
 * @returns
 */
export function deleteMember(member_id: number) {
    return request.delete(`tk_wifi/member/${member_id}`, { showErrorMessage: true, showSuccessMessage: true })
}

export function getWithMemberList(params: Record<string, any>) {
    return request.get('tk_wifi/member_all', { params })
}

// USER_CODE_END -- tkwifi_member
