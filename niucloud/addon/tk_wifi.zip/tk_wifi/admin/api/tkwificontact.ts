import request from '@/utils/request'

// USER_CODE_BEGIN -- tkwifi_contact
/**
 * 获取连接记录列表
 * @param params
 * @returns
 */
export function getTkwifiContactList(params: Record<string, any>) {
    return request.get(`tk_wifi/tkwificontact`, {params})
}

/**
 * 获取连接记录详情
 * @param id 连接记录id
 * @returns
 */
export function getTkwifiContactInfo(id: number) {
    return request.get(`tk_wifi/tkwificontact/${id}`);
}

/**
 * 添加连接记录
 * @param params
 * @returns
 */
export function addTkwifiContact(params: Record<string, any>) {
    return request.post('tk_wifi/tkwificontact', params, { showErrorMessage: true, showSuccessMessage: true })
}

/**
 * 编辑连接记录
 * @param id
 * @param params
 * @returns
 */
export function editTkwifiContact(params: Record<string, any>) {
    return request.put(`tk_wifi/tkwificontact/${params.id}`, params, { showErrorMessage: true, showSuccessMessage: true })
}

/**
 * 删除连接记录
 * @param id
 * @returns
 */
export function deleteTkwifiContact(id: number) {
    return request.delete(`tk_wifi/tkwificontact/${id}`, { showErrorMessage: true, showSuccessMessage: true })
}

export function getWithTkwifiListList(params: Record<string,any>){
    return request.get('tk_wifi/tkwifi_list_all', {params})
}

/**
 * 漏斗概览(曝光/看完/已发放/未发放/佣金合计)
 * @param params
 */
export function getTkwifiContactFunnel(params: Record<string, any>) {
    return request.get('tk_wifi/tkwificontact_funnel', { params })
}

// USER_CODE_END -- tkwifi_contact
