<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\validate\tkwificontact;
use core\base\BaseValidate;
/**
 * 连接记录验证器
 * Class TkwifiContact
 * @package addon\tk_wifi\app\validate\tkwificontact
 */
class TkwifiContact extends BaseValidate
{

       protected $rule = [
            
        ];

       protected $message = [
            
        ];

       protected $scene = [
            "add" => ['wifi_id'],
            "edit" => ['wifi_id']
        ];

}
