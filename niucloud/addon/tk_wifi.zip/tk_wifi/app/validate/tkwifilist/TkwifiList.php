<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\validate\tkwifilist;
use core\base\BaseValidate;
/**
 * wifi列验证器
 * Class TkwifiList
 * @package addon\tk_wifi\app\validate\tkwifilist
 */
class TkwifiList extends BaseValidate
{

       protected $rule = [
            
        ];

       protected $message = [
            
        ];

       protected $scene = [
            "add" => ['member_id', 'name', 'wifi_name', 'wifi_password', 'closure', 'contact_num', 'qrcode'],
            "edit" => ['member_id', 'name', 'wifi_name', 'wifi_password', 'closure', 'contact_num', 'qrcode']
        ];

}
