<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\validate\member;
use core\base\BaseValidate;
/**
 * 推广者验证器
 * Class Member
 * @package addon\tk_wifi\app\validate\member
 */
class Member extends BaseValidate
{

       protected $rule = [
            
        ];

       protected $message = [
            
        ];

       protected $scene = [
            "add" => ['pid', 'status', 'code'],
            "edit" => ['pid', 'status', 'code']
        ];

}
