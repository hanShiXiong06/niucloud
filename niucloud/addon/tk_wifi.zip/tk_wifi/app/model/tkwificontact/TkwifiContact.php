<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\model\tkwificontact;

use core\base\BaseModel;
use think\model\concern\SoftDelete;
use think\model\relation\HasMany;
use think\model\relation\HasOne;

use addon\tk_wifi\app\model\tkwifilist\TkwifiList;
use addon\tk_wifi\app\dict\tkwificontact\RewardReasonDict;
use app\model\member\Member;

/**
 * 连接记录模型
 * Class TkwifiContact
 * @package addon\tk_wifi\app\model\tkwificontact
 */
class TkwifiContact extends BaseModel
{

    

    /**
     * 数据表主键
     * @var string
     */
    protected $pk = 'id';

    /**
     * 模型名称
     * @var string
     */
    protected $name = 'tkwifi_contact';

    

    

    /**
     * 搜索器:连接记录wifi码
     * @param $value
     * @param $data
     */
    public function searchWifiIdAttr($query, $value, $data)
    {
       if ($value) {
            $query->where("wifi_id", $value);
        }
    }
    
    /**
     * 搜索器:广告状态
     */
    public function searchAdStatusAttr($query, $value, $data)
    {
        if ($value !== '' && $value !== null) {
            $query->where("ad_status", $value);
        }
    }

    /**
     * 搜索器:佣金状态
     */
    public function searchRewardStatusAttr($query, $value, $data)
    {
        if ($value !== '' && $value !== null) {
            $query->where("reward_status", $value);
        }
    }

    /**
     * 搜索器:观看用户
     */
    public function searchMemberIdAttr($query, $value, $data)
    {
        if ($value) {
            $query->where("member_id", $value);
        }
    }

    /**
     * 读取器:广告状态文案
     */
    public function getAdStatusNameAttr($value, $data)
    {
        return RewardReasonDict::getAdStatus($data['ad_status'] ?? 0);
    }

    /**
     * 读取器:佣金状态文案
     */
    public function getRewardStatusNameAttr($value, $data)
    {
        return RewardReasonDict::getRewardStatus($data['reward_status'] ?? 0);
    }

    /**
     * 读取器:原因文案
     */
    public function getReasonDescAttr($value, $data)
    {
        return RewardReasonDict::getReason($data['reason'] ?? '');
    }

    /**
     * 搜索器:连接记录创建时间
     * @param $value
     * @param $data
     */
    public function searchCreateTimeAttr($query, $value, $data)
    {
        $start = empty($value[0]) ? 0 : strtotime($value[0]);
        $end = empty($value[1]) ? 0 : strtotime($value[1]);
        if ($start > 0 && $end > 0) {
             $query->where([["create_time", "between", [$start, $end]]]);
        } else if ($start > 0 && $end == 0) {
            $query->where([["create_time", ">=", $start]]);
        } else if ($start == 0 && $end > 0) {
            $query->where([["create_time", "<=", $end]]);
        }
    }
    
    

    

    
    public function tkwifiList(){
       return $this->hasOne(TkwifiList::class, 'id', 'wifi_id')->joinType('left')->withField('name,id,wifi_name,member_id')->bind(['wifi_id_name'=>'name', 'wifi_name'=>'wifi_name']);
    }

    public function viewMember(){
       return $this->hasOne(Member::class, 'member_id', 'member_id')->joinType('left')->withField('member_id,nickname,username,mobile')->bind(['view_member_name'=>'nickname']);
    }

    public function ownMember(){
       return $this->hasOne(Member::class, 'member_id', 'own_member_id')->joinType('left')->withField('member_id,nickname,username,mobile')->bind(['own_member_name'=>'nickname']);
    }

    public function firstMember(){
       return $this->hasOne(Member::class, 'member_id', 'first_member_id')->joinType('left')->withField('member_id,nickname,username,mobile')->bind(['first_member_name'=>'nickname']);
    }

    public function secondMember(){
       return $this->hasOne(Member::class, 'member_id', 'second_member_id')->joinType('left')->withField('member_id,nickname,username,mobile')->bind(['second_member_name'=>'nickname']);
    }

}
