<?php

namespace addon\tk_wifi\app\api\controller\config;

use addon\tk_wifi\app\service\core\config\ConfigService;
use core\base\BaseAdminController;

class Config extends BaseAdminController
{
    /**
     * 接口数据
     */
    public function getConfig()
    {
        return success("操作成功", (new ConfigService())->getConfig());
    }
}
