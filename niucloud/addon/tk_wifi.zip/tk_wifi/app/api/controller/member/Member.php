<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\api\controller\member;

use addon\tk_wifi\app\dict\sharer\SharerDict;
use core\base\BaseApiController;
use addon\tk_wifi\app\service\api\member\MemberService;


/**
 * 推广者控制器
 */
class Member extends BaseApiController
{
      public function stat()
      {
          return success((new MemberService())->stat());
      }
}
