<?php

// +----------------------------------------------------------------------
// | Author: TK
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\api\controller;

use addon\tk_wifi\app\service\api\ShareService;
use addon\tk_wifi\app\service\api\WeappService;
use app\dict\common\ChannelDict;
use core\base\BaseApiController;


/**
 * 分享订单
 */
class Share extends BaseApiController
{
    public function getShareInfo(){
        return success((new ShareService())->getShareInfo());
    }
    public function getShortLink()
    {
        $data = $this->request->params([
            ["path", ""],
            ["title", ""]
        ]);
        $site_id = $this->request->siteId();
        $link = '';
        if ($this->request->getChannel() == ChannelDict::WEAPP) {
            $res = (new WeappService())->getShortLink($site_id, $data['path'], $data['title']);
            if ($res == false) {
                $link = '';
            } else {
                $link = $res['link'];
            }
        }
        return success(['link' => $link]);
    }
}
