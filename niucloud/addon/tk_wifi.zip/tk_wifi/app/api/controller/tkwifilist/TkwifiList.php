<?php
// +----------------------------------------------------------------------
// | Author: TK
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\api\controller\tkwifilist;

use core\base\BaseApiController;
use addon\tk_wifi\app\service\api\tkwifilist\TkwifiListService;


/**
 * wifi列控制器
 * Class TkwifiList
 * @package addon\tk_wifi\app\adminapi\controller\tkwifilist
 */
class TkwifiList extends BaseApiController
{
    public function addContact($id)
    {
        return success((new TkwifiListService())->addContact($id));
    }

    /**
     * 广告链路上报
     * action: view=开始观看 complete=看完 exit=中途退出 nofill=无广告填充 fallback=异常放行
     * @param int $id wifi_id
     * @return \think\Response
     */
    public function reportAd($id)
    {
        $action = $this->request->param('action', 'complete');
        return success((new TkwifiListService())->reportAd($id, $action));
    }
    public function checkPartner()
    {
        return success((new TkwifiListService())->checkPartner());
    }

    /**
     * 获取wifi列列表
     * @return \think\Response
     */
    public function lists()
    {
        $data = $this->request->params([
            ["member_id", ""],
            ["name", ""],
            ["wifi_name", ""],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiListService())->getPage($data));
    }
    public function createLists()
    {
        $data = $this->request->params([
            ["member_id", ""],
            ["name", ""],
            ["wifi_name", ""],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiListService())->getCreatePage($data));
    }

    /**
     * wifi列详情
     * @param int $id
     * @return \think\Response
     */
    public function info(int $id)
    {
        return success((new TkwifiListService())->getInfo($id));
    }

    /**
     * 添加wifi列
     * @return \think\Response
     */
    public function add()
    {
        $data = $this->request->params([
            ["member_id", 0],
            ["name", ""],
            ["wifi_name", ""],
            ["wifi_password", ""],
            ["closure", ""],
            ["contact_num", 0],
            ["qrcode", ""],
        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\tkwifilist\TkwifiList.add');
        $id = (new TkwifiListService())->add($data);
        return success('ADD_SUCCESS', ['id' => $id]);
    }

    /**
     * wifi列编辑
     * @return \think\Response
     */
    public function edit(int $id)
    {
        $data = $this->request->params([
            ["member_id", 0],
            ["name", ""],
            ["wifi_name", ""],
            ["wifi_password", ""],
            ["closure", ""],
            ["contact_num", 0],
            ["qrcode", ""],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\tkwifilist\TkwifiList.edit');
        (new TkwifiListService())->edit($id, $data);
        return success('EDIT_SUCCESS');
    }

    /**
     * wifi列删除
     * @return \think\Response
     */
    public function del(int $id)
    {
        (new TkwifiListService())->del($id);
        return success('DELETE_SUCCESS');
    }


    public function getMemberAll()
    {
        return success((new TkwifiListService())->getMemberAll());
    }
    public function checkSharer()
    {
        $data = $this->request->params([
            ["pid", "0"],
        ]);
        return success((new TkwifiListService())->checkSharer($data));
    }
    public function apply()
    {
        $data = $this->request->params([
            ["pid", "0"],
        ]);
        return success((new TkwifiListService())->apply($data));
    }
}
