<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\api\controller\tkwificontact;

use core\base\BaseApiController;
use addon\tk_wifi\app\service\api\tkwificontact\TkwifiContactService;

/**
 * 连接记录收益控制器
 * 参考 adminapi/controller/tkwificontact 结构
 * 店主收益(own_fee/own_member_id) 直推收益(first_fee/first_member_id) 间推收益(second_fee/second_member_id)
 * Class TkwifiContact
 * @package addon\tk_wifi\app\api\controller\tkwificontact
 */
class TkwifiContact extends BaseApiController
{
    /**
     * 收益统计
     * @return \think\Response
     */
    public function stat()
    {
        return success((new TkwifiContactService())->stat());
    }

    /**
     * 收益明细列表
     * @return \think\Response
     */
    public function lists()
    {
        $data = $this->request->params([
            ["type", "all"],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiContactService())->getPage($data));
    }

    /**
     * 我的WIFI码连接/看广告明细(含未发放及原因)
     * @return \think\Response
     */
    public function records()
    {
        $data = $this->request->params([
            ["reward_status", ""],
            ["ad_status", ""],
        ]);
        return success((new TkwifiContactService())->getAdRecords($data));
    }

    /**
     * 我的WIFI码漏斗概览
     * @return \think\Response
     */
    public function funnel()
    {
        return success((new TkwifiContactService())->funnel());
    }
}
