<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

use app\api\middleware\ApiCheckToken;
use app\api\middleware\ApiLog;
use app\api\middleware\ApiChannel;
use think\facade\Route;


/**
 * WIFI一键连
 */
Route::group('tk_wifi', function () {
    //wifi列列表
    Route::get('tkwifilist', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@lists');
    //添加wifi列
    Route::post('tkwifilist', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@add');
    //编辑wifi列
    Route::put('tkwifilist/:id', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@edit');
    //删除wifi列
    Route::delete('tkwifilist/:id', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@del');
    //检查是否店主
    Route::get('check/partner', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@checkPartner');
    //检查是否是推广者
    Route::post('check/sharer', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@checkSharer');
    //申请推广者
    Route::post('apply/sharer', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@apply');
    //分销推广统计
    Route::get('member/stat', 'addon\tk_wifi\app\api\controller\member\Member@stat');
    //收益统计
    Route::get('fee/stat', 'addon\tk_wifi\app\api\controller\tkwificontact\TkwifiContact@stat');
    //收益明细列表
    Route::get('fee/lists', 'addon\tk_wifi\app\api\controller\tkwificontact\TkwifiContact@lists');
    //我的码 连接/看广告明细(含未发放原因)
    Route::get('fee/records', 'addon\tk_wifi\app\api\controller\tkwificontact\TkwifiContact@records');
    //我的码 漏斗概览
    Route::get('fee/funnel', 'addon\tk_wifi\app\api\controller\tkwificontact\TkwifiContact@funnel');
    Route::get('getshortlink', 'addon\tk_wifi\app\api\controller\Share@getShortLink');
    //获取邀请海报列表
    Route::get('getshare', 'addon\tk_wifi\app\api\controller\Share@getShareInfo');
    //推广者创建列表
    Route::get('tkwifilist/create', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@createLists');
})->middleware(ApiChannel::class)
    ->middleware(ApiCheckToken::class, true) //false表示不验证登录
    ->middleware(ApiLog::class);

Route::group('tk_wifi', function () {
    Route::get('getconfig', 'addon\tk_wifi\app\api\controller\config\Config@getConfig');
    //添加连接记录(兼容旧入口:普通模式/H5直接连接)
    Route::get('addcontact/:id', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@addContact');
    //广告链路上报(view=开始 complete=看完 exit=中途退出 nofill=无广告 fallback=异常放行)
    Route::get('ad/report/:id', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@reportAd');
    //wifi列详情
    Route::get('tkwifilist/:id', 'addon\tk_wifi\app\api\controller\tkwifilist\TkwifiList@info');
})->middleware(ApiChannel::class)
    ->middleware(ApiCheckToken::class, false) //表示验证登录
    ->middleware(ApiLog::class);

