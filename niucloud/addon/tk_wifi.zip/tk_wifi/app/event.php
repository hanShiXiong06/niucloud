<?php

return [
    'bind' => [

    ],
    'listen' => [
        //主题色加载
        'ThemeColor' => ['addon\tk_wifi\app\listener\diy\ThemeColorListener'],
        //获取海报数据
        'GetPosterType' => ['addon\tk_wifi\app\listener\poster\TkWifiPosterType'],
        'GetPosterData' => ['addon\tk_wifi\app\listener\poster\TkWifiPoster'],
        //增加导航
        'BottomNavigation' => [ 'addon\tk_wifi\app\listener\BottomNavigationListener' ],

    ],
    'subscribe' => [
    ],
];