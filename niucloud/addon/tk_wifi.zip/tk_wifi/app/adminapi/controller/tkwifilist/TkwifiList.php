<?php

// +----------------------------------------------------------------------
// | Author: TK
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\adminapi\controller\tkwifilist;

use app\service\admin\member\MemberService;
use core\base\BaseAdminController;
use addon\tk_wifi\app\service\admin\tkwifilist\TkwifiListService;
use Exception;


/**
 * wifi列控制器
 * Class TkwifiList
 * @package addon\tk_wifi\app\adminapi\controller\tkwifilist
 */
class TkwifiList extends BaseAdminController
{
    public function createQrcode()
    {
        $data = $this->request->params([
            ["num", 0],
        ]);
        if ($data['num'] > 100) throw new Exception('单次生成数量不能超过100');
        (new TkwifiListService())->createQrcode($data['num']);
        return success('ADD_SUCCESS');
    }

    /**
     * 获取wifi列列表
     * @return \think\Response
     */
    public function lists()
    {
        $data = $this->request->params([
            ["member_id", ""],
            ["name", ""],
            ["wifi_name", ""],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiListService())->getPage($data));
    }

    /**
     * wifi列详情
     * @param int $id
     * @return \think\Response
     */
    public function info(int $id)
    {
        return success((new TkwifiListService())->getInfo($id));
    }

    /**
     * 添加wifi列
     * @return \think\Response
     */
    public function add()
    {
        $data = $this->request->params([
            ["member_id", 0],
            ["name", ""],
            ["wifi_name", ""],
            ["wifi_password", ""],
            ["closure", ""],
            ["contact_num", 0],
            ["qrcode", ""],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\tkwifilist\TkwifiList.add');
        $id = (new TkwifiListService())->add($data);
        return success('ADD_SUCCESS', ['id' => $id]);
    }

    /**
     * wifi列编辑
     * @return \think\Response
     */
    public function edit(int $id)
    {
        $data = $this->request->params([
            ["member_id", 0],
            ["name", ""],
            ["wifi_name", ""],
            ["wifi_password", ""],
            ["closure", ""],
            ["contact_num", 0],
            ["qrcode", ""],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\tkwifilist\TkwifiList.edit');
        (new TkwifiListService())->edit($id, $data);
        return success('EDIT_SUCCESS');
    }

    /**
     * wifi列删除
     * @return \think\Response
     */
    public function del(int $id)
    {
        (new TkwifiListService())->del($id);
        return success('DELETE_SUCCESS');
    }


    public function getMemberAll()
    {
        $data = $this->request->params([
            ['keyword', ''],
            ['register_type', ''],
            ['register_channel', ''],
            ['create_time', []],
            ['member_label', 0],
            ['member_level', 0],
        ]);
        return success((new MemberService())->getPage($data));
    }
    public function downloadQrcode()
    {
        $data = $this->request->post();
        return success((new TkwifiListService())->downloadQrcode($data));
    }
    public function delselect()
    {
        $data = $this->request->post();
        (new TkwifiListService())->delselect($data);
        return success('DELETE_SUCCESS');
    }
}
