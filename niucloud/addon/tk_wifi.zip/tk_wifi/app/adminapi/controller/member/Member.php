<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\adminapi\controller\member;

use addon\tk_wifi\app\dict\sharer\SharerDict;
use core\base\BaseAdminController;
use addon\tk_wifi\app\service\admin\member\MemberService;


/**
 * 推广者控制器
 * Class Member
 * @package addon\tk_wifi\app\adminapi\controller\member
 */
class Member extends BaseAdminController
{
    public function getSharerStatus()
    {
        return success(SharerDict::getSharerStatus());
    }
   /**
    * 获取推广者列表
    * @return \think\Response
    */
    public function lists(){
        $data = $this->request->params([
             ["pid",""],
             ["status",""],
             ["create_time",["",""]]
        ]);
        return success((new MemberService())->getPage($data));
    }

    /**
     * 推广者详情
     * @param int $id
     * @return \think\Response
     */
    public function info(int $id){
        return success((new MemberService())->getInfo($id));
    }

    /**
     * 添加推广者
     * @return \think\Response
     */
    public function add(){
        $data = $this->request->params([
             ["pid",0],
             ["status",0],
             ["code",""],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\member\Member.add');
        $id = (new MemberService())->add($data);
        return success('ADD_SUCCESS', ['id' => $id]);
    }

    /**
     * 推广者编辑
     * @param $id  推广者id
     * @return \think\Response
     */
    public function edit(int $id){
        $data = $this->request->params([
             ["pid",0],
             ["status",0],
             ["code",""],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\member\Member.edit');
        (new MemberService())->edit($id, $data);
        return success('EDIT_SUCCESS');
    }

    /**
     * 推广者删除
     * @param $id  推广者id
     * @return \think\Response
     */
    public function del(int $id){
        (new MemberService())->del($id);
        return success('DELETE_SUCCESS');
    }

    
    public function getMemberAll(){
         return success(( new MemberService())->getMemberAll());
    }

}
