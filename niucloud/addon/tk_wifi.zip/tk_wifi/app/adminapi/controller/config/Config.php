<?php

namespace addon\tk_wifi\app\adminapi\controller\config;

use addon\tk_wifi\app\service\core\config\ConfigService;
use core\base\BaseAdminController;

class Config extends BaseAdminController
{
    public function setConfig()
    {
        $data = $this->request->params([
            ['link', []],
            ['type', 'direct'],
            ['add_banner', ''],
            ['wifi_fee', ''],
            ['adv_id', ''],
            ['sharer_way', 'direct'],
            ['sharer_fee', ''],
            ['sharer_content', ''],
            ['is_auto_sharer', ''],
            ['is_fenxiao', '0'],
            ['first_fee', '0.02'],
            ['second_fee', '0.01'],
            ['own_fee', '0.01']
        ]);
        (new ConfigService())->setConfig($data);
        return success('操作成功');
    }

    /**
     * 接口数据
     */
    public function getConfig()
    {
        return success("操作成功", (new ConfigService())->getConfig());
    }
}
