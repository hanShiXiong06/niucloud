<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\adminapi\controller\tkwificontact;

use addon\tk_wifi\app\service\admin\tkwifilist\TkwifiListService;
use core\base\BaseAdminController;
use addon\tk_wifi\app\service\admin\tkwificontact\TkwifiContactService;


/**
 * 连接记录控制器
 * Class TkwifiContact
 * @package addon\tk_wifi\app\adminapi\controller\tkwificontact
 */
class TkwifiContact extends BaseAdminController
{
    /**
     * 获取连接记录列表
     * @return \think\Response
     */
    public function lists()
    {
        $data = $this->request->params([
            ["wifi_id", ""],
            ["member_id", ""],
            ["ad_status", ""],
            ["reward_status", ""],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiContactService())->getPage($data));
    }

    /**
     * 漏斗概览(曝光/看完/已发放/未发放/佣金合计)
     * @return \think\Response
     */
    public function funnel()
    {
        $data = $this->request->params([
            ["wifi_id", ""],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiContactService())->funnel($data));
    }

    /**
     * 连接记录详情
     * @param int $id
     * @return \think\Response
     */
    public function info(int $id)
    {
        return success((new TkwifiContactService())->getInfo($id));
    }

    /**
     * 添加连接记录
     * @return \think\Response
     */
    public function add()
    {
        $data = $this->request->params([
            ["wifi_id", 0],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\tkwificontact\TkwifiContact.add');
        $id = (new TkwifiContactService())->add($data);
        return success('ADD_SUCCESS', ['id' => $id]);
    }

    /**
     * 连接记录编辑
     * @param $id  连接记录id
     * @return \think\Response
     */
    public function edit(int $id)
    {
        $data = $this->request->params([
            ["wifi_id", 0],

        ]);
        $this->validate($data, 'addon\tk_wifi\app\validate\tkwificontact\TkwifiContact.edit');
        (new TkwifiContactService())->edit($id, $data);
        return success('EDIT_SUCCESS');
    }

    /**
     * 连接记录删除
     * @param $id  连接记录id
     * @return \think\Response
     */
    public function del(int $id)
    {
        (new TkwifiContactService())->del($id);
        return success('DELETE_SUCCESS');
    }

    public function getTkwifiListAll()
    {
        $data = $this->request->params([
            ["member_id", ""],
            ["name", ""],
            ["wifi_name", ""],
            ["create_time", ["", ""]]
        ]);
        return success((new TkwifiListService())->getPage($data));
    }

}
