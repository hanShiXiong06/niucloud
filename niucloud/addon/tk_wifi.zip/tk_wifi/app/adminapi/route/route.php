<?php

// +----------------------------------------------------------------------
// | Author: TK
// +----------------------------------------------------------------------

use think\facade\Route;

use app\adminapi\middleware\AdminCheckRole;
use app\adminapi\middleware\AdminCheckToken;
use app\adminapi\middleware\AdminLog;

/**
 * WIFI一键连
 */
Route::group('tk_wifi', function () {

     /***************************************************** tk wifi 配置接口 ****************************************************/
    //设置获取
    Route::get('getconfig', 'addon\tk_wifi\app\adminapi\controller\config\Config@getConfig');
    //设置参数
    Route::post('setconfig', 'addon\tk_wifi\app\adminapi\controller\config\Config@setConfig');

})->middleware([
    AdminCheckToken::class,
    AdminCheckRole::class,
    AdminLog::class
]);
// USER_CODE_BEGIN -- tkwifi_list

Route::group('tk_wifi', function () {

    //wifi列列表
    Route::get('tkwifilist', 'addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@lists');
    //wifi列详情
    Route::get('tkwifilist/:id', 'addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@info');
    //添加wifi列
    Route::post('tkwifilist', 'addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@add');
    //编辑wifi列
    Route::put('tkwifilist/:id', 'addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@edit');
    //删除wifi列
    Route::delete('tkwifilist/:id', 'addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@del');
    
    Route::get('member_all','addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@getMemberAll');
    //生成空码
    Route::post('createqrcode','addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@createQrcode');
    //下载空码
    Route::post('downloadqrcode','addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@downloadQrcode');
    Route::post('delwifiselect', 'addon\tk_wifi\app\adminapi\controller\tkwifilist\TkwifiList@delselect');
})->middleware([
    AdminCheckToken::class,
    AdminCheckRole::class,
    AdminLog::class
]);
// USER_CODE_END -- tkwifi_list

// USER_CODE_BEGIN -- tkwifi_contact

Route::group('tk_wifi', function () {

    //连接记录列表
    Route::get('tkwificontact', 'addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@lists');
    //漏斗概览(曝光/看完/已发放/未发放)
    Route::get('tkwificontact_funnel', 'addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@funnel');
    //连接记录详情
    Route::get('tkwificontact/:id', 'addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@info');
    //添加连接记录
    Route::post('tkwificontact', 'addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@add');
    //编辑连接记录
    Route::put('tkwificontact/:id', 'addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@edit');
    //删除连接记录
    Route::delete('tkwificontact/:id', 'addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@del');
    
    Route::get('tkwifi_list_all','addon\tk_wifi\app\adminapi\controller\tkwificontact\TkwifiContact@getTkwifiListAll');

})->middleware([
    AdminCheckToken::class,
    AdminCheckRole::class,
    AdminLog::class
]);
// USER_CODE_END -- tkwifi_contact

// USER_CODE_BEGIN -- tkwifi_member

Route::group('tk_wifi', function () {

    //推广者列表
    Route::get('member', 'addon\tk_wifi\app\adminapi\controller\member\Member@lists');
    //推广者详情
    Route::get('member/:id', 'addon\tk_wifi\app\adminapi\controller\member\Member@info');
    //添加推广者
    Route::post('member', 'addon\tk_wifi\app\adminapi\controller\member\Member@add');
    //编辑推广者
    Route::put('member/:id', 'addon\tk_wifi\app\adminapi\controller\member\Member@edit');
    //删除推广者
    Route::delete('member/:id', 'addon\tk_wifi\app\adminapi\controller\member\Member@del');
    //推广者状态
    Route::get('sharerstatus','addon\tk_wifi\app\adminapi\controller\member\Member@getSharerStatus');
})->middleware([
    AdminCheckToken::class,
    AdminCheckRole::class,
    AdminLog::class
]);
// USER_CODE_END -- tkwifi_member
