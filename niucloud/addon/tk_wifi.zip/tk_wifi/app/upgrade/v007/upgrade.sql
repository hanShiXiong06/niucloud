ALTER TABLE tkwifi_contact
    ADD COLUMN own_member_id INT(13) DEFAULT null COMMENT '店主',
    ADD COLUMN first_member_id INT(13) DEFAULT null COMMENT '一级推广',
    ADD COLUMN second_member_id INT(13) DEFAULT null COMMENT '二级推广';
