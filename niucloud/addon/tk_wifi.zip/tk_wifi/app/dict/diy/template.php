<?php

return [
    'DIY_TK_WIFI_INDEX' => [
        'title' => 'WIFI首页',
        'page' => '/addon/tk_wifi/pages/index/index',
        'action' => 'decorate',
        'type' => 'index'
    ],
    'DIY_TK_WIFI_MEMBER_INDEX' => [
        'title' => 'WIFI个人中心',
        'page' => '/addon/tk_wifi/pages/member/index',
        'action' => 'decorate',
        'type' => 'member_index'
    ],
];