<?php

return [
    'TK_WIFI' => [
        'key' => 'tk_wifi',
        'addon_title' => 'WIFI码',
        'title' => 'WIFI码',
        'child_list' => [
            [
                'name' => 'TK_WIFI_INDEX',
                'title' => '首页',
                'url' => '/addon/tk_wifi/pages/index/index',
                'is_share' => 1,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_MEMBER_INDEX',
                'title' => '个人中心',
                'url' => '/addon/tk_wifi/pages/member/index',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_APPLY',
                'title' => '申请地推',
                'url' => '/addon/tk_wifi/pages/wifi/apply',
                'is_share' => 1,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_ADD',
                'title' => '添加WIFI码',
                'url' => '/addon/tk_wifi/pages/wifi/add',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_LIST',
                'title' => 'WIFI码列表',
                'url' => '/addon/tk_wifi/pages/wifi/list',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_CREATE_LIST',
                'title' => '我创建',
                'url' => '/addon/tk_wifi/pages/wifi/create_list',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_STAT',
                'title' => '数据统计',
                'url' => '/addon/tk_wifi/pages/wifi/stat',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_SHARE',
                'title' => '推广中心',
                'url' => '/addon/tk_wifi/pages/wifi/share',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_FEE_OWN',
                'title' => '商家收益',
                'url' => '/addon/tk_wifi/pages/fee/own',
                'is_share' => 0,
                'action' => 'decorate'
            ],
            [
                'name' => 'TK_WIFI_FEE_FENXIAO',
                'title' => '推广收益',
                'url' => '/addon/tk_wifi/pages/fee/fenxiao',
                'is_share' => 0,
                'action' => 'decorate'
            ]
        ]
    ],

];