<?php

namespace addon\tk_wifi\app\dict\config;
class ConfigDict
{
    /**
     * @Notes:通用类型配置
     * @Interface getType
     * @return string
     * @author: TK
     * @Time: 2025/3/5 20:54
     */
    public static function getType()
    {
        return 'TK_WIFI_CONFIG';
    }

}
