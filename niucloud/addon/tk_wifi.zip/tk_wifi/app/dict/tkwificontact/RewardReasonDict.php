<?php
// +----------------------------------------------------------------------
// | tk_wifi 佣金发放/未发放原因 与 广告状态 枚举
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\dict\tkwificontact;

/**
 * 佣金原因 / 广告状态字典
 * 用于把「看广告 -> 连接 -> 发佣金」整条链路的结果落库，消除黑盒。
 */
class RewardReasonDict
{
    /* -------- 广告状态 ad_status -------- */
    const AD_UNKNOWN   = 0; // 未知
    const AD_SHOWN     = 1; // 已展示(开始观看)
    const AD_COMPLETE  = 2; // 完整看完
    const AD_EXIT      = 3; // 中途退出
    const AD_NOFILL    = 4; // 无广告填充(拉取失败)
    const AD_FALLBACK  = 5; // 广告异常,放行
    const AD_NONEED    = 6; // 无需广告(普通模式/H5)

    /* -------- 佣金状态 reward_status -------- */
    const REWARD_PENDING = 0; // 待处理
    const REWARD_DONE    = 1; // 已发放
    const REWARD_PART    = 2; // 部分发放
    const REWARD_SKIP    = 3; // 跳过未发

    /* -------- 原因码 reason -------- */
    const R_WATCHING     = 'watching';            // 观看中,尚未结算
    const R_REWARDED     = 'rewarded';            // 正常发放
    const R_DUPLICATE    = 'duplicate';           // 1小时内重复连接,不重复计佣
    const R_NO_PROMOTER  = 'no_promoter';         // 该wifi码无推广人(pid=0)
    const R_PROMOTER_UNAPPROVED = 'promoter_unapproved'; // 推广人未通过审核
    const R_FENXIAO_OFF  = 'fenxiao_off';         // 未开启地推分销
    const R_OWN_FEE_ZERO = 'own_fee_zero';        // 商家佣金为0(未设置)
    const R_NOT_WEAPP    = 'not_weapp';           // 非微信小程序渠道,不结算
    const R_AD_UNFINISHED = 'ad_unfinished';      // 广告未看完
    const R_NO_LOGIN     = 'no_login';            // 用户未登录
    const R_LEGACY       = 'legacy';              // 历史数据

    /**
     * 广告状态文案
     */
    public static function getAdStatus($status = '')
    {
        $data = [
            self::AD_UNKNOWN  => '未知',
            self::AD_SHOWN    => '观看中',
            self::AD_COMPLETE => '已看完',
            self::AD_EXIT     => '中途退出',
            self::AD_NOFILL   => '无广告填充',
            self::AD_FALLBACK => '广告异常放行',
            self::AD_NONEED   => '无需广告',
        ];
        if ($status !== '') {
            return $data[$status] ?? '未知';
        }
        return $data;
    }

    /**
     * 佣金状态文案
     */
    public static function getRewardStatus($status = '')
    {
        $data = [
            self::REWARD_PENDING => '待处理',
            self::REWARD_DONE    => '已发放',
            self::REWARD_PART    => '部分发放',
            self::REWARD_SKIP    => '未发放',
        ];
        if ($status !== '') {
            return $data[$status] ?? '待处理';
        }
        return $data;
    }

    /**
     * 原因文案(用户/管理员可读)
     */
    public static function getReason($reason = '')
    {
        $data = [
            self::R_WATCHING     => '观看中,尚未结算',
            self::R_REWARDED     => '已发放佣金',
            self::R_DUPLICATE    => '1小时内重复连接,本次不重复计佣',
            self::R_NO_PROMOTER  => '该WIFI码未绑定推广人,无推广分成',
            self::R_PROMOTER_UNAPPROVED => '推广人未通过审核,暂不结算分成',
            self::R_FENXIAO_OFF  => '未开启地推分销,无推广分成',
            self::R_OWN_FEE_ZERO => '商家佣金未设置(为0)',
            self::R_NOT_WEAPP    => '非微信小程序渠道,不结算佣金',
            self::R_AD_UNFINISHED => '广告未完整观看,不结算佣金',
            self::R_NO_LOGIN     => '用户未登录,无法结算',
            self::R_LEGACY       => '历史数据',
            ''                   => '-',
        ];
        if ($reason !== '') {
            // 支持逗号分隔的多原因(如 own_fee_zero,no_promoter)
            if (strpos($reason, ',') !== false) {
                $parts = array_filter(explode(',', $reason));
                $texts = array_map(function ($r) use ($data) {
                    return $data[$r] ?? $r;
                }, $parts);
                return implode('；', $texts);
            }
            return $data[$reason] ?? $reason;
        }
        return $data;
    }
}
