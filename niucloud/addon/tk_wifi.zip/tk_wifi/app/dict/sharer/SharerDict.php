<?php

namespace addon\tk_wifi\app\dict\sharer;
class SharerDict
{
    const WAIT = 0; //待审核
    const PASS = 1;
    const REJECT = 2;

    public static function getSharerStatus($status = '')
    {
        $data = [
            self::WAIT => '待审核',
            self::PASS => '审核通过',
            self::REJECT => '审核拒绝',
        ];
        if ($status !== '') {
            return $data[$status];
        }
        return $data;
    }
}
