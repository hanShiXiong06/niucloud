<?php

use app\dict\member\MemberAccountTypeDict;

return [
    //会员佣金
    MemberAccountTypeDict::COMMISSION => [
        'tk_wifi_sharer' => [
            //名称
            'name' => 'WIFI地推连接激励',
            //是否增加
            'inc' => 1,
            //是否减少
            'dec' => 1,
        ],
        'tk_wifi_own' => [
            //名称
            'name' => 'WIFI连接激励',
            //是否增加
            'inc' => 1,
            //是否减少
            'dec' => 1,
        ],
    ]
];
