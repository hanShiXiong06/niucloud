<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\admin\tkwificontact;

use addon\tk_wifi\app\model\tkwificontact\TkwifiContact;
use addon\tk_wifi\app\model\tkwifilist\TkwifiList;
use addon\tk_wifi\app\dict\tkwificontact\RewardReasonDict;

use core\base\BaseAdminService;


/**
 * 连接记录服务层
 * Class TkwifiContactService
 * @package addon\tk_wifi\app\service\admin\tkwificontact
 */
class TkwifiContactService extends BaseAdminService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new TkwifiContact();
    }

    /**
     * 获取连接记录列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'id,site_id,wifi_id,member_id,ad_status,reward_status,reason,channel,create_time,update_time,own_fee,first_fee,second_fee,own_member_id,first_member_id,second_member_id';
        $order = 'create_time desc';

        $search_model = $this->model->where([ [ 'site_id' ,"=", $this->site_id ] ])
            ->withSearch(["wifi_id", "create_time", "ad_status", "reward_status", "member_id"], $where)
            ->with(['tkwifiList.member', 'viewMember', 'ownMember', 'firstMember', 'secondMember'])
            ->append(['ad_status_name', 'reward_status_name', 'reason_desc'])
            ->field($field)->order($order);
        $list = $this->pageQuery($search_model);
        return $list;
    }

    /**
     * 漏斗概览(站点维度):曝光/看完/已发放/未发放/佣金合计
     * @param array $where
     * @return array
     */
    public function funnel(array $where = [])
    {
        $base = function () use ($where) {
            $q = $this->model->where([['site_id', '=', $this->site_id]])->withSearch(["wifi_id", "create_time"], $where);
            return $q;
        };

        return [
            'view_num'     => $base()->where([['ad_status', '>=', RewardReasonDict::AD_SHOWN]])->count(),
            'complete_num' => $base()->where([['ad_status', '=', RewardReasonDict::AD_COMPLETE]])->count(),
            'reward_num'   => $base()->where([['reward_status', '=', RewardReasonDict::REWARD_DONE]])->count(),
            'skip_num'     => $base()->where([['reward_status', '=', RewardReasonDict::REWARD_SKIP]])->count(),
            'own_total'    => round((float)$base()->sum('own_fee'), 2),
            'first_total'  => round((float)$base()->sum('first_fee'), 2),
            'second_total' => round((float)$base()->sum('second_fee'), 2),
        ];
    }

    /**
     * 获取连接记录信息
     * @param int $id
     * @return array
     */
    public function getInfo(int $id)
    {
        $field = 'id,site_id,wifi_id,create_time';

        $info = $this->model->field($field)->where([['id', "=", $id]])->with(['tkwifiList'])->findOrEmpty()->toArray();
        return $info;
    }

    /**
     * 添加连接记录
     * @param array $data
     * @return mixed
     */
    public function add(array $data)
    {
        $data['site_id'] = $this->site_id;
        $res = $this->model->create($data);
        return $res->id;

    }

    /**
     * 连接记录编辑
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function edit(int $id, array $data)
    {

        $this->model->where([['id', '=', $id],['site_id', '=', $this->site_id]])->update($data);
        return true;
    }

    /**
     * 删除连接记录
     * @param int $id
     * @return bool
     */
    public function del(int $id)
    {
        $model = $this->model->where([['id', '=', $id],['site_id', '=', $this->site_id]])->find();
        $res = $model->delete();
        return $res;
    }
    
    public function getTkwifiListAll(){
       $tkwifiListModel = new TkwifiList();
       return $tkwifiListModel->where([["site_id","=",$this->site_id]])->select()->toArray();
    }

}
