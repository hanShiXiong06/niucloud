<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\admin\member;

use addon\tk_wifi\app\dict\sharer\SharerDict;
use addon\tk_wifi\app\model\member\Member;
use app\model\member\Member as BaseMemberModel;

use core\base\BaseAdminService;


/**
 * 推广者服务层
 * Class MemberService
 * @package addon\tk_wifi\app\service\admin\member
 */
class MemberService extends BaseAdminService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new Member();
    }

    /**
     * 获取推广者列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'member_id,site_id,pid,status,code,create_time';
        $order = 'create_time desc';
        $search_model = $this->model->where([ [ 'site_id' ,"=", $this->site_id ] ])->withSearch(["member_id","pid","status","create_time"], $where)->with(['member','pmember'])->field($field)->order($order);
        $list = $this->pageQuery($search_model);
        foreach ($list['data'] as $k=>$v){
            $list['data'][$k]['status_name'] = SharerDict::getSharerStatus($v['status']);
        }
        return $list;
    }

    /**
     * 获取推广者信息
     * @param int $id
     * @return array
     */
    public function getInfo(int $id)
    {
        $field = 'member_id,site_id,pid,status,code,create_time';

        $info = $this->model->field($field)->where([['member_id', "=", $id]])->with(['member','pmember'])->findOrEmpty()->toArray();
        return $info;
    }

    /**
     * 添加推广者
     * @param array $data
     * @return mixed
     */
    public function add(array $data)
    {
        $data['site_id'] = $this->site_id;
        $res = $this->model->create($data);
        return $res->member_id;

    }

    /**
     * 推广者编辑
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function edit(int $id, array $data)
    {

        $this->model->where([['member_id', '=', $id],['site_id', '=', $this->site_id]])->update($data);
        return true;
    }

    /**
     * 删除推广者
     * @param int $id
     * @return bool
     */
    public function del(int $id)
    {
        $model = $this->model->where([['member_id', '=', $id],['site_id', '=', $this->site_id]])->find();
        $res = $model->delete();
        return $res;
    }
    
    public function getMemberAll(){
       $memberModel = new BaseMemberModel();
       return $memberModel->where([["site_id","=",$this->site_id]])->select()->toArray();
    }


}
