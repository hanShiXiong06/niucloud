<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\admin\tkwifilist;

use addon\tk_wifi\app\dict\sharer\SharerDict;
use addon\tk_wifi\app\model\tkwificontact\TkwifiContact;
use addon\tk_wifi\app\model\tkwifilist\TkwifiList;
use addon\tk_wifi\app\service\core\CommonService;
use app\model\member\Member;

use core\base\BaseAdminService;
use think\Exception;


/**
 * wifi列服务层
 * Class TkwifiListService
 * @package addon\tk_wifi\app\service\admin\tkwifilist
 */
class TkwifiListService extends BaseAdminService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new TkwifiList();
    }

    public function downloadQrcode($ids)
    {
        $res = $this->model
            ->where('is_export', '=', 0)
            ->where('id', 'in', $ids)->select();
        if ($res->isEmpty()) {
            throw new Exception('请选择需要导出的二维码');
        }
        $weapp_qrcode = [];
        foreach ($res as $item) {
            $weapp_qrcode[] = $item['qrcode'];
        }

        // 创建临时目录存放要打包的文件
        $temp_dir = runtime_path() . 'temp/' . uniqid('qrcode_');
        $weapp_dir = $temp_dir . '/weapp/';
        // 创建目录
        if (!is_dir($weapp_dir)) {
            mkdir($weapp_dir, 0755, true);
        }
        // 复制文件到临时目录
        foreach ($weapp_qrcode as $key => $qrcode) {
            $file_path = public_path() . $qrcode;
            if (file_exists($file_path)) {
                $filename = 'weapp_qrcode_' . ($key + 1) . '.png';
                copy($file_path, $weapp_dir . $filename);
            }
        }
        // 打包目录
        $zip_name = 'qrcode_' . date('YmdHis') . '.zip';
        $zip_path = public_path() . 'upload/tk_wifi_qrcode/' . $this->site_id . '/' . $zip_name;
        $zip_dir = dirname($zip_path);

        // 确保目录存在
        if (!is_dir($zip_dir)) {
            mkdir($zip_dir, 0755, true);
        }

        // 创建zip文件
        $zip = new \ZipArchive();
        if ($zip->open($zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) === TRUE) {
            $this->addFileToZip($zip, $temp_dir, '');
            $zip->close();

            // 清理临时目录
            $this->deleteDir($temp_dir);

            // 更新导出状态为已导出
            $this->model->where('id', 'in', $ids)->update(['is_export' => 1]);

            // 返回下载链接
            return [
                'url' => 'upload/tk_wifi_qrcode/' . $this->site_id . '/' . $zip_name,
                'path' => $zip_path,
                'name' => $zip_name
            ];
        } else {
            // 清理临时目录
            $this->deleteDir($temp_dir);
            throw new Exception('创建ZIP文件失败');
        }
    }

    /**
     * 递归添加文件到ZIP
     * @param \ZipArchive $zip
     * @param string $path 要添加的文件路径
     * @param string $zip_path 在ZIP中的路径
     */
    private function addFileToZip($zip, $path, $zip_path)
    {
        $handler = opendir($path);
        while (($filename = readdir($handler)) !== false) {
            if ($filename == '.' || $filename == '..') {
                continue;
            }

            $file_path = $path . '/' . $filename;
            $zip_file_path = $zip_path == '' ? $filename : $zip_path . '/' . $filename;

            if (is_dir($file_path)) {
                $zip->addEmptyDir($zip_file_path);
                $this->addFileToZip($zip, $file_path, $zip_file_path);
            } else {
                $zip->addFile($file_path, $zip_file_path);
            }
        }
        closedir($handler);
    }

    /**
     * 递归删除目录
     * @param string $dir 要删除的目录
     */
    private function deleteDir($dir)
    {
        if (!is_dir($dir)) {
            return;
        }

        $files = scandir($dir);
        foreach ($files as $file) {
            if ($file == '.' || $file == '..') {
                continue;
            }

            $path = $dir . '/' . $file;
            if (is_dir($path)) {
                $this->deleteDir($path);
            } else {
                unlink($path);
            }
        }

        rmdir($dir);
    }

    public function createQrcode($num)
    {
        for ($i = 0; $i < $num; $i++) {
            $data['site_id'] = $this->site_id;
            $data['member_id'] = 0;
            $data['pid'] = 0;
            $res = $this->model->create($data);
            $qrcode = $this->buildQrcode($res->id);
            $this->model->where([['id', '=', $res->id]])
                ->update(['qrcode' => $qrcode]);
        }
        return true;
    }

    public function buildQrcode($id)
    {
        $url = (new CommonService())->getUrl($this->site_id);
        $qrcode_image = qrcode(
            $url,
            'addon/tk_wifi/pages/wifi/contact',
            [
                [
                    'key' => 'id',
                    'value' => $id,
                ],
            ],
            $this->site_id,
            '',
            'weapp',
        );
        return $qrcode_image;
    }

    /**
     * 获取wifi列列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'id,site_id,member_id,name,wifi_name,wifi_password,closure,contact_num,qrcode,create_time,is_use,is_export';
        $order = 'create_time desc';

        $search_model = $this->model->where([['site_id', "=", $this->site_id]])->withSearch(["member_id", "name", "wifi_name", "create_time"], $where)->with(['member'])->field($field)->order($order);
        $list = $this->pageQuery($search_model);
        $contactModel = new TkwifiContact();
        foreach ($list['data'] as $k => $v) {
            $list['data'][$k]['contact_num'] = $contactModel
                ->where([['wifi_id', '=', $v['id']]])->count();
        }
        return $list;
    }

    /**
     * 获取wifi列信息
     * @param int $id
     * @return array
     */
    public function getInfo(int $id)
    {
        $field = 'id,site_id,member_id,name,wifi_name,wifi_password,closure,contact_num,qrcode,create_time';

        $info = $this->model->field($field)->where([['id', "=", $id]])->with(['member'])->findOrEmpty()->toArray();
        return $info;
    }

    /**
     * 添加wifi列
     * @param array $data
     * @return mixed
     */
    public function add(array $data)
    {
        $data['site_id'] = $this->site_id;
        $res = $this->model->create($data);
        return $res->id;

    }

    /**
     * wifi列编辑
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function edit(int $id, array $data)
    {

        $this->model->where([['id', '=', $id], ['site_id', '=', $this->site_id]])->update($data);
        return true;
    }

    /**
     * 删除wifi列
     * @param int $id
     * @return bool
     */
    public function del(int $id)
    {
        $model = $this->model->where([['id', '=', $id], ['site_id', '=', $this->site_id]])->find();
        $res = $model->delete();
        return $res;
    }

    public function getMemberAll()
    {
        $memberModel = new Member();
        return $memberModel->where([["site_id", "=", $this->site_id]])->select()->toArray();
    }

    public function delselect($ids)
    {
        $res = $this->model->where('id', 'in', $ids)->delete();
        return $res;
    }
}
