<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\api\tkwificontact;

use addon\tk_wifi\app\model\tkwificontact\TkwifiContact;
use addon\tk_wifi\app\model\tkwifilist\TkwifiList;
use addon\tk_wifi\app\dict\tkwificontact\RewardReasonDict;
use core\base\BaseApiService;

/**
 * 连接记录收益服务层
 * Class TkwifiContactService
 * @package addon\tk_wifi\app\service\api\tkwificontact
 */
class TkwifiContactService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new TkwifiContact();
    }

    /**
     * 收益统计
     * 店主收益(own_fee/own_member_id) 直推收益(first_fee/first_member_id) 间推收益(second_fee/second_member_id)
     * 店主收益与推广收益(直推+间推)分开统计
     * @return array
     */
    public function stat()
    {
        // 店主收益：当前会员作为 wifi 店主获得的收益
        $own_total = $this->model->where([
            ['site_id', '=', $this->site_id],
            ['own_member_id', '=', $this->member_id],
        ])->sum('own_fee');

        $own_num = $this->model->where([
            ['site_id', '=', $this->site_id],
            ['own_member_id', '=', $this->member_id],
        ])->count();

        // 直推收益：当前会员作为一级推广者获得的收益
        $first_total = $this->model->where([
            ['site_id', '=', $this->site_id],
            ['first_member_id', '=', $this->member_id],
        ])->sum('first_fee');

        $first_num = $this->model->where([
            ['site_id', '=', $this->site_id],
            ['first_member_id', '=', $this->member_id],
        ])->count();

        // 间推收益：当前会员作为二级推广者获得的收益
        $second_total = $this->model->where([
            ['site_id', '=', $this->site_id],
            ['second_member_id', '=', $this->member_id],
        ])->sum('second_fee');

        $second_num = $this->model->where([
            ['site_id', '=', $this->site_id],
            ['second_member_id', '=', $this->member_id],
        ])->count();

        // 推广收益合计 = 直推 + 间推
        $fenxiao_total = round((float)$first_total + (float)$second_total, 2);
        $fenxiao_num = $first_num + $second_num;

        return [
            // 店主收益
            'own_total' => round((float)$own_total, 2),
            'own_num' => $own_num,
            // 推广收益(直推+间推合计)
            'fenxiao_total' => $fenxiao_total,
            'fenxiao_num' => $fenxiao_num,
            // 直推收益
            'first_total' => round((float)$first_total, 2),
            'first_num' => $first_num,
            // 间推收益
            'second_total' => round((float)$second_total, 2),
            'second_num' => $second_num,
            // 总计
            'all_total' => round((float)$own_total + (float)$first_total + (float)$second_total, 2),
            'all_num' => $own_num + $fenxiao_num,
        ];
    }

    /**
     * 收益明细列表
     * @param array $where type: own=店主 first=直推 second=间推 fenxiao=推广(直推+间推) all=全部
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'id,site_id,wifi_id,create_time,own_fee,first_fee,second_fee,own_member_id,first_member_id,second_member_id';
        $order = 'create_time desc';

        $query = $this->model->where([['site_id', '=', $this->site_id]]);

        $type = $where['type'] ?? 'all';
        if ($type == 'own') {
            // 店主收益
            $query = $query->where([['own_member_id', '=', $this->member_id], ['own_fee', '>', 0]]);
        } elseif ($type == 'first') {
            // 直推收益
            $query = $query->where([['first_member_id', '=', $this->member_id], ['first_fee', '>', 0]]);
        } elseif ($type == 'second') {
            // 间推收益
            $query = $query->where([['second_member_id', '=', $this->member_id], ['second_fee', '>', 0]]);
        } elseif ($type == 'fenxiao') {
            // 推广收益：直推或间推命中当前会员
            $query = $query->where(function ($q) {
                $q->where(function ($q1) {
                    $q1->where('first_member_id', $this->member_id)->where('first_fee', '>', 0);
                })->whereOr(function ($q2) {
                    $q2->where('second_member_id', $this->member_id)->where('second_fee', '>', 0);
                });
            });
        } else {
            // 全部：当前会员参与的所有收益记录
            $query = $query->where(function ($q) {
                $q->where(function ($q1) {
                    $q1->where('own_member_id', $this->member_id)->where('own_fee', '>', 0);
                })->whereOr(function ($q2) {
                    $q2->where('first_member_id', $this->member_id)->where('first_fee', '>', 0);
                })->whereOr(function ($q3) {
                    $q3->where('second_member_id', $this->member_id)->where('second_fee', '>', 0);
                });
            });
        }

        $search_model = $query->with(['tkwifiList', 'ownMember', 'firstMember', 'secondMember'])->field($field)->order($order);
        $list = $this->pageQuery($search_model);
        return $list;
    }

    /**
     * 我的WIFI码上的连接/看广告明细(含未发放及原因)
     * 维度:当前会员作为「店主(member_id)」或「推广人(pid)」名下的所有码。
     * 用于回答「用户在我的码上看了广告,我为什么没拿到佣金」。
     * @param array $where reward_status: ''=全部 1=已发放 3=未发放; ad_status 可选
     * @return array
     */
    public function getAdRecords(array $where = [])
    {
        // 找到我名下(店主)或我推广(pid)的所有码
        $wifiModel = new TkwifiList();
        $wifiIds = $wifiModel->where([['site_id', '=', $this->site_id]])
            ->where(function ($q) {
                $q->where('member_id', $this->member_id)->whereOr('pid', $this->member_id);
            })->column('id');

        $field = 'id,site_id,wifi_id,member_id,ad_status,reward_status,reason,channel,create_time,update_time,own_fee,first_fee,second_fee,own_member_id,first_member_id,second_member_id';
        $query = $this->model->where([['site_id', '=', $this->site_id]]);

        if (empty($wifiIds)) {
            // 没有任何码:用一个不可能命中的条件,返回空分页结构
            $query = $query->where([['id', '=', 0]]);
        } else {
            $query = $query->whereIn('wifi_id', $wifiIds);
        }

        $reward_status = $where['reward_status'] ?? '';
        if ($reward_status !== '') {
            $query = $query->where([['reward_status', '=', $reward_status]]);
        }
        $ad_status = $where['ad_status'] ?? '';
        if ($ad_status !== '') {
            $query = $query->where([['ad_status', '=', $ad_status]]);
        }

        $search_model = $query->with(['tkwifiList', 'viewMember', 'ownMember', 'firstMember', 'secondMember'])
            ->append(['ad_status_name', 'reward_status_name', 'reason_desc'])
            ->field($field)->order('create_time desc');
        return $this->pageQuery($search_model);
    }

    /**
     * 我的WIFI码漏斗概览:曝光(看广告)/看完/已发放/未发放
     * @return array
     */
    public function funnel()
    {
        $wifiModel = new TkwifiList();
        $wifiIds = $wifiModel->where([['site_id', '=', $this->site_id]])
            ->where(function ($q) {
                $q->where('member_id', $this->member_id)->whereOr('pid', $this->member_id);
            })->column('id');

        if (empty($wifiIds)) {
            return ['view_num' => 0, 'complete_num' => 0, 'reward_num' => 0, 'skip_num' => 0];
        }

        $base = function () use ($wifiIds) {
            return $this->model->where([['site_id', '=', $this->site_id]])->whereIn('wifi_id', $wifiIds);
        };

        return [
            // 看过广告(已展示及以上)的次数
            'view_num'     => $base()->where([['ad_status', '>=', RewardReasonDict::AD_SHOWN]])->count(),
            'complete_num' => $base()->where([['ad_status', '=', RewardReasonDict::AD_COMPLETE]])->count(),
            'reward_num'   => $base()->where([['reward_status', '=', RewardReasonDict::REWARD_DONE]])->count(),
            'skip_num'     => $base()->where([['reward_status', '=', RewardReasonDict::REWARD_SKIP]])->count(),
        ];
    }
}
