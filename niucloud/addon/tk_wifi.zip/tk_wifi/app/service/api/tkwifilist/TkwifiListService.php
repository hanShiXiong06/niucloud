<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\api\tkwifilist;

use addon\tk_wifi\app\dict\sharer\SharerDict;
use addon\tk_wifi\app\dict\tkwificontact\RewardReasonDict;
use addon\tk_wifi\app\model\tkwificontact\TkwifiContact;
use addon\tk_wifi\app\model\tkwifilist\TkwifiList;
use addon\tk_wifi\app\service\core\CommonService;
use addon\tk_wifi\app\service\core\config\ConfigService;
use app\dict\common\ChannelDict;
use app\dict\member\MemberAccountTypeDict;
use app\model\member\Member;
use addon\tk_wifi\app\model\member\Member as ApiMemberModel;
use app\service\core\member\CoreMemberAccountService;
use app\service\core\site\CoreSiteService;
use core\base\BaseApiService;
use core\exception\CommonException;
use think\Exception;
use think\facade\Db;


/**
 * wifi列服务层
 * Class TkwifiListService
 * @package addon\tk_wifi\app\service\admin\tkwifilist
 */
class TkwifiListService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new TkwifiList();
    }

    /**
     * 兼容旧入口 GET addcontact/:id
     * 普通(非广告)模式或H5直接连接时调用,视为一次"无需广告"的连接结算。
     * @param int $id wifi_id
     * @return array
     */
    public function addContact($id)
    {
        return $this->reportAd($id, 'connect');
    }

    /**
     * 广告/连接 全链路上报统一入口(消除黑盒)
     * 每一次「看广告 -> 连接 -> 结算」都会落库,并写入广告状态/发放结果/原因。
     *
     * @param int    $id     wifi_id
     * @param string $action view=开始观看 complete=看完 exit=中途退出 nofill=无广告填充 fallback=广告异常放行 connect=普通连接
     * @return array  本次结算结果(record_id / ad_status / reward_status / reason 及文案)
     */
    public function reportAd($id, string $action = 'complete')
    {
        $contactModel = new TkwifiContact();
        $channel = $this->request->getChannel();
        $now = time();

        $adStatusMap = [
            'view'     => RewardReasonDict::AD_SHOWN,
            'complete' => RewardReasonDict::AD_COMPLETE,
            'exit'     => RewardReasonDict::AD_EXIT,
            'nofill'   => RewardReasonDict::AD_NOFILL,
            'fallback' => RewardReasonDict::AD_FALLBACK,
            'connect'  => RewardReasonDict::AD_NONEED,
        ];
        $adStatus = $adStatusMap[$action] ?? RewardReasonDict::AD_UNKNOWN;

        // 复用同用户/同码 1 小时内的会话记录,避免一次连接产生多行
        $row = $contactModel->where([
            ['site_id', '=', $this->site_id],
            ['member_id', '=', $this->member_id],
            ['wifi_id', '=', $id],
            ['create_time', '>', $now - 3600],
        ])->order('id desc')->findOrEmpty();

        // 未登录:也落一行,标记原因,便于排查
        if (!$this->member_id) {
            if ($row->isEmpty()) {
                $row = $contactModel->create([
                    'site_id' => $this->site_id, 'member_id' => 0, 'wifi_id' => $id,
                    'ad_status' => $adStatus, 'reward_status' => RewardReasonDict::REWARD_SKIP,
                    'reason' => RewardReasonDict::R_NO_LOGIN, 'channel' => $channel,
                    'create_time' => $now, 'update_time' => $now,
                ]);
            }
            return $this->reportResult($row->id ?? 0, RewardReasonDict::REWARD_SKIP, RewardReasonDict::R_NO_LOGIN, $adStatus);
        }

        // 阶段一:开始观看 —— 建/更新记录,先不结算
        if ($action === 'view') {
            if ($row->isEmpty()) {
                $row = $contactModel->create([
                    'site_id' => $this->site_id, 'member_id' => $this->member_id, 'wifi_id' => $id,
                    'ad_status' => $adStatus, 'reward_status' => RewardReasonDict::REWARD_PENDING,
                    'reason' => RewardReasonDict::R_WATCHING, 'channel' => $channel,
                    'create_time' => $now, 'update_time' => $now,
                ]);
            } else {
                $contactModel->where(['id' => $row->id])->update([
                    'ad_status' => max((int)$row->ad_status, $adStatus), 'update_time' => $now,
                ]);
            }
            return $this->reportResult($row->id, RewardReasonDict::REWARD_PENDING, RewardReasonDict::R_WATCHING, $adStatus);
        }

        // 阶段二:终态(complete/exit/nofill/fallback/connect)
        if ($row->isEmpty()) {
            $row = $contactModel->create([
                'site_id' => $this->site_id, 'member_id' => $this->member_id, 'wifi_id' => $id,
                'ad_status' => $adStatus, 'reward_status' => RewardReasonDict::REWARD_PENDING,
                'reason' => '', 'channel' => $channel,
                'create_time' => $now, 'update_time' => $now,
            ]);
        } else {
            $contactModel->where(['id' => $row->id])->update([
                'ad_status' => $adStatus, 'channel' => $channel, 'update_time' => $now,
            ]);
        }

        // 已结算过则不重复处理
        if (in_array((int)$row->reward_status, [RewardReasonDict::REWARD_DONE, RewardReasonDict::REWARD_PART], true)) {
            return $this->reportResult($row->id, $row->reward_status, $row->reason, $adStatus);
        }

        // 中途退出 / 广告未看完 —— 不结算
        if ($action === 'exit') {
            $contactModel->where(['id' => $row->id])->update([
                'reward_status' => RewardReasonDict::REWARD_SKIP,
                'reason' => RewardReasonDict::R_AD_UNFINISHED, 'update_time' => $now,
            ]);
            return $this->reportResult($row->id, RewardReasonDict::REWARD_SKIP, RewardReasonDict::R_AD_UNFINISHED, $adStatus);
        }

        // 渠道校验:仅微信小程序结算
        if (ChannelDict::WEAPP != $channel) {
            $contactModel->where(['id' => $row->id])->update([
                'reward_status' => RewardReasonDict::REWARD_SKIP,
                'reason' => RewardReasonDict::R_NOT_WEAPP, 'update_time' => $now,
            ]);
            return $this->reportResult($row->id, RewardReasonDict::REWARD_SKIP, RewardReasonDict::R_NOT_WEAPP, $adStatus);
        }

        // 1 小时内已有"已发放"记录(同用户同码) —— 本次去重,不重复计佣
        $rewarded = $contactModel->where([
            ['site_id', '=', $this->site_id],
            ['member_id', '=', $this->member_id],
            ['wifi_id', '=', $id],
            ['reward_status', '=', RewardReasonDict::REWARD_DONE],
            ['create_time', '>', $now - 3600],
            ['id', '<>', $row->id],
        ])->findOrEmpty();
        if (!$rewarded->isEmpty()) {
            $contactModel->where(['id' => $row->id])->update([
                'reward_status' => RewardReasonDict::REWARD_SKIP,
                'reason' => RewardReasonDict::R_DUPLICATE, 'update_time' => $now,
            ]);
            return $this->reportResult($row->id, RewardReasonDict::REWARD_SKIP, RewardReasonDict::R_DUPLICATE, $adStatus);
        }

        // 正式结算
        $result = $this->awardEvent($id, $row->id);
        return $this->reportResult($row->id, $result['reward_status'], $result['reason'], $adStatus);
    }

    /**
     * 统一返回结构
     */
    private function reportResult($recordId, $rewardStatus, $reason, $adStatus)
    {
        return [
            'record_id'          => $recordId,
            'ad_status'          => $adStatus,
            'ad_status_name'     => RewardReasonDict::getAdStatus($adStatus),
            'reward_status'      => $rewardStatus,
            'reward_status_name' => RewardReasonDict::getRewardStatus($rewardStatus),
            'reason'             => $reason,
            'reason_desc'        => RewardReasonDict::getReason($reason),
        ];
    }

    /**
     * 结算佣金,并把发放结果/原因写回记录行。
     * @param int $id         wifi_id
     * @param int $contact_id 记录行 id
     * @return array ['reward_status'=>, 'reason'=>]
     */
    public function awardEvent($id, $contact_id)
    {
        $contactModel = new TkwifiContact();
        $now = time();

        $wifi = $this->model->where([['id', '=', $id]])->findOrEmpty();
        if ($wifi->isEmpty()) {
            $contactModel->where(['id' => $contact_id])->update([
                'reward_status' => RewardReasonDict::REWARD_SKIP, 'reason' => 'wifi_missing', 'update_time' => $now,
            ]);
            return ['reward_status' => RewardReasonDict::REWARD_SKIP, 'reason' => 'wifi_missing'];
        }

        $member_id = $wifi['member_id']; // 店主/商家
        $site_id   = $wifi['site_id'];
        $config    = (new ConfigService())->getConfigBySiteId($site_id);

        $paid   = false;
        $update = ['update_time' => $now];
        $skip   = [];

        // 1) 商家(店主)佣金
        if (isset($config['own_fee']) && $config['own_fee'] > 0 && $member_id > 0) {
            (new CoreMemberAccountService())->addLog(
                $site_id, $member_id, MemberAccountTypeDict::COMMISSION,
                $config['own_fee'], 'tk_wifi_own', "WIFI码用户连接激励"
            );
            $update['own_fee'] = $config['own_fee'];
            $update['own_member_id'] = $member_id;
            $paid = true;
        } else {
            $skip[] = RewardReasonDict::R_OWN_FEE_ZERO;
        }

        // 2) 地推分销(直推/间推)
        if (!isset($config['is_fenxiao']) || $config['is_fenxiao'] != 1) {
            $skip[] = RewardReasonDict::R_FENXIAO_OFF;
        } elseif ($wifi['pid'] <= 0) {
            $skip[] = RewardReasonDict::R_NO_PROMOTER;
        } else {
            $pid = $wifi['pid'];
            $sharerModel = new ApiMemberModel();
            $sharer = $sharerModel->where([['site_id', '=', $site_id], ['member_id', '=', $pid], ['status', '=', SharerDict::PASS]])->findOrEmpty();
            if ($sharer->isEmpty()) {
                $skip[] = RewardReasonDict::R_PROMOTER_UNAPPROVED;
            } else {
                // 一级
                if ($config['first_fee'] > 0) {
                    (new CoreMemberAccountService())->addLog(
                        $site_id, $pid, MemberAccountTypeDict::COMMISSION,
                        $config['first_fee'], 'tk_wifi_sharer', "WIFI码地推一级激励"
                    );
                    $update['first_fee'] = $config['first_fee'];
                    $update['first_member_id'] = $pid;
                    $paid = true;
                }
                // 二级
                if ($config['second_fee'] > 0 && $sharer['pid'] > 0) {
                    $ppsharer = $sharerModel->where([['site_id', '=', $site_id], ['member_id', '=', $sharer['pid']], ['status', '=', SharerDict::PASS]])->findOrEmpty();
                    if (!$ppsharer->isEmpty()) {
                        (new CoreMemberAccountService())->addLog(
                            $site_id, $ppsharer['member_id'], MemberAccountTypeDict::COMMISSION,
                            $config['second_fee'], 'tk_wifi_ppsharer', "WIFI码地推二级激励"
                        );
                        $update['second_fee'] = $config['second_fee'];
                        $update['second_member_id'] = $ppsharer['member_id'];
                        $paid = true;
                    }
                }
            }
        }

        if ($paid) {
            $update['reward_status'] = RewardReasonDict::REWARD_DONE;
            $update['reason'] = RewardReasonDict::R_REWARDED;
        } else {
            $update['reward_status'] = RewardReasonDict::REWARD_SKIP;
            $update['reason'] = $skip ? implode(',', array_unique($skip)) : RewardReasonDict::R_OWN_FEE_ZERO;
        }
        $contactModel->where(['id' => $contact_id])->update($update);

        return ['reward_status' => $update['reward_status'], 'reason' => $update['reason']];
    }

    public function apply($data)
    {
        $sharerModel = new ApiMemberModel();
        $sharer = $sharerModel->where([['site_id', '=', $this->site_id], ['member_id', '=', $this->member_id]])->findOrEmpty();
        if (!$sharer->isEmpty()) throw new CommonException('您已经推广员');
        $config = (new ConfigService())->getConfig();
        $status = SharerDict::WAIT;
        if (!isset($config['is_auto_sharer'])) throw new CommonException('管理员未完成基础设置');
        if ($config['is_auto_sharer'] == 1) {
            $status = SharerDict::PASS;
        }
        $sharerModel->create([
            'site_id' => $this->site_id,
            'member_id' => $this->member_id,
            'pid' => $data['pid'] ?? 0,
            'status' => $status,
            'create_time' => time(),
        ]);
        return true;
    }

    public function checkSharer($data)
    {
        $sharerModel = new ApiMemberModel();
        $sharer = $sharerModel->where([['site_id', '=', $this->site_id], ['member_id', '=', $this->member_id]])->findOrEmpty();
        if ($sharer->isEmpty()) {
            $config = (new ConfigService())->getConfig();
            if (!isset($config['is_auto_sharer'])) throw new CommonException('管理员未完成基础设置');
            if ($config['is_auto_sharer'] == 1) {
                $sharerModel->create([
                    'site_id' => $this->site_id,
                    'member_id' => $this->member_id,
                    'pid' => $data['pid'] ?? 0,
                    'status' => SharerDict::PASS,
                    'create_time' => time(),
                ]);
            } else {
                return [
                    'is_sharer' => 0,
                    'msg' => '未申请'
                ];
            }
        }
        if ($sharer['status'] == SharerDict::REJECT) {
            return [
                'is_sharer' => 2,
                'msg' => '申请被拒绝,请联系平台客服'
            ];
        }
        if ($sharer['status'] == SharerDict::WAIT) {
            return [
                'is_sharer' => 2,
                'msg' => '您的推广权限暂未通过,请等待管理员审核'
            ];
        }
        return [
            'is_sharer' => 1,
            'msg' => '已经是推广员工'
        ];
    }

    public function checkPartner()
    {
        //检查应用权限
        $addons = (new CoreSiteService())->getAddonKeysBySiteId($this->site_id);
        if (!in_array('tk_partner', $addons)) return false;
        //查询店主信息
        $info = Db::name('tkpartner_member')->where([['site_id', '=', $this->site_id], ['member_id', '=', $this->member_id]])->findOrEmpty();
        if ($info->isEmpty()) return false;
        return true;
    }

    /**
     * 获取wifi列列表
     * @param array $where
     * @return array
     */
    public function getPage(array $where = [])
    {
        $field = 'id,site_id,member_id,name,wifi_name,wifi_password,closure,contact_num,qrcode,create_time';
        $order = 'create_time desc';
        $search_model = $this->model
            ->where(['member_id' => $this->member_id])
            ->where([['site_id', "=", $this->site_id]])->withSearch(["member_id", "name", "wifi_name", "create_time"], $where)->with(['member'])->field($field)->order($order);
        $list = $this->pageQuery($search_model);
        $contactModel = new TkwifiContact();
        foreach ($list['data'] as $k => $v) {
            $list['data'][$k]['contact_num'] = $contactModel
                ->where([['wifi_id', '=', $v['id']]])->count();
        }
        return $list;
    }

    public function getCreatePage(array $where = [])
    {
        $field = 'id,site_id,member_id,name,wifi_name,wifi_password,closure,contact_num,qrcode,create_time,is_use';
        $order = 'create_time desc';
        $search_model = $this->model
            ->where(['pid' => $this->member_id])
            ->where([['site_id', "=", $this->site_id]])->withSearch(["member_id", "name", "wifi_name", "create_time"], $where)->with(['member'])->field($field)->order($order);
        $list = $this->pageQuery($search_model);
        return $list;
    }

    /**
     * 获取wifi列信息
     * @param int $id
     * @return array
     */
    public function getInfo(int $id)
    {
        $info = $this->model->where([['id', "=", $id]])->with(['member'])->findOrEmpty()->toArray();
        if (!$info) throw new CommonException('wifi码已清除');
        $info['is_bind'] = 1;
        if (!$info['member_id'] > 0) {
            if ($this->member_id == 0) {
                throw new CommonException('请先登录完成WIFI码绑定和配置');
            }
            $this->model
                ->where([['id', "=", $id]])->update([
                    'member_id' => $this->member_id,
                    'is_use' => 1,
                    'is_export' => 1,
                ]);
            $info['member_id'] = $this->member_id;
            $qrcode = $this->createQrcode($info['id']);
            $this->model->where([['id', '=', $info['id']]])
                ->update(['qrcode' => $qrcode]);
            $info['is_bind'] = 0;
        }
        return $info;
    }

    /**
     * 添加wifi列
     * @param array $data
     * @return mixed
     */
    public function add(array $data)
    {
        //检查当前用户权限
        $sharerModel = new ApiMemberModel();
        $sharer = $sharerModel->where([
            ['site_id', '=', $this->site_id],
            ['member_id', '=', $this->member_id],
        ])->findOrEmpty();
        if ($sharer->isEmpty()) throw new CommonException('您不是推广员');
        if ($sharer['status'] == SharerDict::REJECT) throw new CommonException('您的推广员申请被拒绝');
        if ($sharer['status'] == SharerDict::WAIT) throw new CommonException('请等待审核通过再创建');
        $data['site_id'] = $this->site_id;
        $data['pid'] = $this->member_id;
        $res = $this->model->create($data);
        $qrcode = $this->createQrcode($res->id);
        $this->model->where([['id', '=', $res->id]])
            ->update(['qrcode' => $qrcode]);
        return true;
    }

    public function createQrcode($id)
    {
        $url = (new CommonService())->getUrl($this->site_id);
        $qrcode_image = qrcode(
            $url,
            'addon/tk_wifi/pages/wifi/contact',
            [
                [
                    'key' => 'id',
                    'value' => $id,
                ],
                [
                    'key' => 'mid',
                    'value' => $this->member_id,
                ],
            ],
            $this->site_id,
            '',
            'weapp',
        );
        return $qrcode_image;
    }

    /**
     * wifi列编辑
     * @param int $id
     * @param array $data
     * @return bool
     */
    public function edit(int $id, array $data)
    {
        $data['member_id'] = $this->member_id;
        $qrcode = $this->createQrcode($id);
        $data['qrcode'] = $qrcode;
        $this->model->where([['id', '=', $id], ['site_id', '=', $this->site_id]])->update($data);
        return true;
    }

    /**
     * 删除wifi列
     * @param int $id
     * @return bool
     */
    public function del(int $id)
    {
        $model = $this->model->where([['id', '=', $id], ['site_id', '=', $this->site_id]])->find();
        $res = $model->delete();
        return $res;
    }

    public function getMemberAll()
    {
        $memberModel = new Member();
        return $memberModel->where([["site_id", "=", $this->site_id]])->select()->toArray();
    }
}
