<?php
// +----------------------------------------------------------------------
// | Author: TK
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\api;

use addon\tk_wifi\app\service\core\CommonService;
use app\model\sys\Poster;
use app\service\core\weapp\CoreWeappConfigService;
use core\base\BaseApiService;
use think\Exception;

class ShareService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
    }
    public function getShareInfo()
    {
        $post_list = (new Poster())->where(['site_id' => $this->site_id, 'type' => 'tk_wifi_poster'])->select()->toArray();
        if (empty($post_list)) throw new Exception('管理员未配置海报模板');
        $poster = [];
        foreach ($post_list as $post) {
            $data = [
                'id' => $post['id'],
                'type' => 'tk_wifi_poster',
                'channel' => $this->request->getChannel(),
                'param' => [
                    'member_id' => $this->member_id,
                ]
            ];
            $poster[] = poster($this->request->siteId(), ...$data);
        }
        $core_weapp_service = new CoreWeappConfigService();
        $weapp_config = $core_weapp_service->getWeappConfig($this->site_id);
        $weapp_appid = $weapp_config['app_id'];
        $weapp_original_id = $weapp_config['weapp_original'];
        $params = [
            'appid' => $weapp_appid,
            'original_id' => $weapp_original_id,
            'poster' => $poster,
            'mid' => $this->member_id,
            'url' => (new CommonService())->getUrl($this->site_id) . '/addon/tk_wifi/pages/index/index?mid=' . $this->member_id,
        ];
        return $params;
    }
}
