<?php

// +----------------------------------------------------------------------
// | Author: TK
// +----------------------------------------------------------------------

namespace addon\tk_wifi\app\service\api\member;

use addon\tk_wifi\app\dict\sharer\SharerDict;
use addon\tk_wifi\app\model\member\Member;
use app\model\member\Member as BaseMemberModel;

use core\base\BaseApiService;


/**
 * 推广者服务层
 * Class MemberService
 * @package addon\tk_wifi\app\service\admin\member
 */
class MemberService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
        $this->model = new Member();
    }
    public function stat()
    {
        $firstFenxiao = $this->model
            ->where(['site_id' => $this->site_id, 'pid' => $this->member_id])
            ->column('member_id');
        return [
            'first_num' => count($firstFenxiao),
            'second_num' => $this->model->where(['site_id' => $this->site_id])->whereIn('pid', $firstFenxiao)->count(),
        ];
    }
}
