<?php

namespace addon\tk_wifi\app\service\core\config;

use addon\tk_wifi\app\dict\config\ConfigDict;
use app\service\core\sys\CoreConfigService;
use core\base\BaseAdminService;

/**
 * 配置信息服务层
 */
class ConfigService extends BaseAdminService
{
    public function __construct()
    {
        parent::__construct();

    }

    /**
     * 获取配置信息
     * @param $site_id
     * @param string $config_key
     */
    public function getConfig()
    {
        $info = (new CoreConfigService())->getConfig($this->site_id, ConfigDict::getType());
        if (empty($info)) {
            $info['value']['add_banner'] = '';
            $info['value']['link'] = [
                "name" => ""
            ];
            $info['value']['type'] = 'direct';//直接连接
        }
        return $info['value'];
    }


    public function setConfig($value)
    {
        (new CoreConfigService())->setConfig($this->site_id, ConfigDict::getType(), $value);
        return true;
    }
    public function getConfigBySiteId($site_id)
    {
        $info = (new CoreConfigService())->getConfig($site_id, ConfigDict::getType());
        if (empty($info)) {
            $info['value']['add_banner'] = '';
            $info['value']['link'] = [
                "name" => ""
            ];
            $info['value']['type'] = 'direct';//直接连接
        }
        return $info['value'];
    }

}