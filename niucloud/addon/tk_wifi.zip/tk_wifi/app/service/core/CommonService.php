<?php

namespace addon\tk_wifi\app\service\core;

use app\model\dict\Dict;
use app\service\core\sys\CoreConfigService;
use app\service\core\sys\CoreSysConfigService;
use core\base\BaseApiService;
use core\exception\CommonException;
use think\Exception;

/**
 * 公共服务层
 */
class CommonService extends BaseApiService
{
    public function __construct()
    {
        parent::__construct();
    }


    public function getUrl($site_id)
    {
        $wap_url = (new CoreSysConfigService())->getSceneDomain($site_id)['wap_url'];
        return $wap_url;
    }

    public function getFileUrl($url)
    {
        $domain = $this->getDomainUrl();
        if (strpos($url, $domain) === 0) {
            return $url;
        }
        if (strpos($url, 'http') === false) {
            return $domain . '/' . ltrim($url, '/');
        }
        return $url;
    }

    public function getDomainUrl()
    {
        $isSecure = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on';
        $domain = $_SERVER['HTTP_HOST'];
        if ($isSecure) {
            $url = 'https://' . $domain;
        } else {
            $url = 'http://' . $domain;
        }
        return $url;
    }

}