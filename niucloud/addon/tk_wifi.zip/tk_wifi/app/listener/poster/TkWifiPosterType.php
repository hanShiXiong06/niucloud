<?php
declare (strict_types = 1);

namespace addon\tk_wifi\app\listener\poster;



/**
 * 商品海报类型
 */
class TkWifiPosterType
{
    /**
     * 商品海报
     * @param $data
     * @return void
     */
    public function handle($data = [])
    {
        return [
            [
                'type' => 'tk_wifi_poster',
                'addon' => 'tk_wifi',
                'name' => '地推推广员海报',
                'decs' => '地推推广员海报',
                'icon' => 'addon/tk_wifi/icon.png'
            ]
        ];
    }
}
