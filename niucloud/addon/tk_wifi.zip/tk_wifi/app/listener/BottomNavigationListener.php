<?php

namespace addon\tk_wifi\app\listener;

use app\service\core\addon\CoreAddonService;
use app\service\core\site\CoreSiteService;

/**
 * 底部导航
 */
class BottomNavigationListener
{
    /**
     * @param array $params
     * @return array|void
     */
    public function handle($params = [])
    {
        $key = 'tk_wifi';

        $site_addon = (new CoreSiteService())->getAddonKeysBySiteId(request()->siteId());
        if (!in_array($key, $site_addon)) return;

        if (!empty($params)&& !empty($params['key']) && $params['key'] != $key) return;

        $core_addon_service = new CoreAddonService();
        $addon_info = $core_addon_service->getAddonConfig($key);

        return [
            'key' => $key,
            'info' => $addon_info,
            'value' => [
                "backgroundColor" =>"#ffffff",
                "textColor" =>"#333333",
                "textHoverColor" =>"#0057FE",
                "type" =>1,
                "list" =>[
                    [
                        "text" =>"首页",
                        "link" => [
                            "parent" =>"TK_WIFI",
                            "name" =>"TK_WIFI_INDEX",
                            "title" =>"首页",
                            "url" =>"/addon/tk_wifi/pages/index/index",
                            "action" =>"decorate"
                        ],
                        "iconPath" =>"https://saasr2.sotui.top/upload/attachment/image/100000/202507/12/17523082508c86b06f7163537e3986ae48fde2973c_tk_s3.png",
                        "iconSelectPath" =>"https://saasr2.sotui.top/upload/attachment/image/100000/202507/12/1752308250f25c5fc808e3d917e01fec0ddd8a0425_tk_s3.png"
                    ],
                    [
                        "text" =>"我的",
                        "link" => [
                            "parent" =>"TK_WIFI",
                            "name" =>"TK_WIFI_MEMBER_INDEX",
                            "title" =>"个人中心",
                            "url" =>"/addon/tk_wifi/pages/member/index",
                            "action" =>"decorate"
                        ],
                        "iconSelectPath" =>"https://saasr2.sotui.top/upload/attachment/image/100000/202507/12/1752308250a4f02a1f0f3bda443d7d5576634fa2fd_tk_s3.png",
                        "iconPath" =>"https://saasr2.sotui.top/upload/attachment/image/100000/202507/12/1752308250e41c87bddc08e16bee32a03c181832ec_tk_s3.png"
                    ]
                ]
            ]
        ];


    }
}
