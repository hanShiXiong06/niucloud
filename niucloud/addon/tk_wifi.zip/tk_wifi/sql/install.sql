-- ----------------------------
-- Table structure for {{prefix}}tkwifi_contact
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}tkwifi_contact`;
CREATE TABLE `{{prefix}}tkwifi_contact`
(
    `id`               int(11) NOT NULL AUTO_INCREMENT,
    `site_id`          int(11) NULL DEFAULT NULL COMMENT '站点ID',
    `member_id`        int(11) NULL DEFAULT NULL COMMENT '会员ID(观看广告/连接的用户)',
    `wifi_id`          int(13) NULL DEFAULT NULL COMMENT 'wifi码',
    `ad_status`        tinyint(2) NULL DEFAULT 0 COMMENT '广告状态:0未知/1已展示/2看完/3中途退出/4无广告填充/5异常放行/6无需广告',
    `reward_status`    tinyint(2) NULL DEFAULT 0 COMMENT '佣金状态:0待处理/1已发放/2部分发放/3跳过未发',
    `reason`           varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '未发放/跳过原因码',
    `channel`          varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT '' COMMENT '渠道',
    `first_fee`        decimal(10, 2) NULL DEFAULT 0.00 COMMENT '一级推广金',
    `second_fee`       decimal(10, 2) NULL DEFAULT 0.00 COMMENT '二级推广金',
    `own_fee`          decimal(10, 2) NULL DEFAULT 0.00 COMMENT '商家推广金',
    `own_member_id`    int(13) DEFAULT NULL COMMENT '商家',
    `first_member_id`  int(11) DEFAULT NULL COMMENT '一级推广',
    `second_member_id` int(11) DEFAULT NULL COMMENT '二级推广',
    `create_time`      int(13) NULL DEFAULT NULL COMMENT '创建时间',
    `update_time`      int(13) NULL DEFAULT 0 COMMENT '更新时间',
    PRIMARY KEY (`id`) USING BTREE,
    INDEX `idx_site_wifi_member` (`site_id`, `wifi_id`, `member_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '连接记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}tkwifi_list
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}tkwifi_list`;
CREATE TABLE `{{prefix}}tkwifi_list`
(
    `id`            int(11) NOT NULL AUTO_INCREMENT,
    `site_id`       int(11) NULL DEFAULT NULL COMMENT '站点ID',
    `member_id`     int(11) NULL DEFAULT NULL COMMENT '会员',
    `pid`           int(11) NULL DEFAULT 0,
    `name`          varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
    `wifi_name`     varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'wifi名称',
    `wifi_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'wifi密码',
    `closure`       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '截流口令',
    `contact_num`   int(11) NULL DEFAULT 0 COMMENT '连接数量',
    `qrcode`        varchar(800) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '二维码',
    `is_use`        int(11) NULL DEFAULT 0 COMMENT '物料使用',
    `is_export`     int(11) NULL DEFAULT 0 COMMENT '导出物料',
    `create_time`   int(13) NULL DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 150 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'wifi码列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}tkwifi_member
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}tkwifi_member`;
CREATE TABLE `{{prefix}}tkwifi_member`
(
    `member_id`   int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '会员id',
    `site_id`     int(11) NOT NULL DEFAULT 0 COMMENT '站点id',
    `pid`         int(11) NULL DEFAULT 0 COMMENT '推荐会员id(分销)',
    `status`      int(11) NULL DEFAULT 0 COMMENT '状态',
    `code`        varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '推荐码',
    `create_time` int(11) NULL DEFAULT 0 COMMENT '创建时间',
    PRIMARY KEY (`member_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '推广者' ROW_FORMAT = DYNAMIC;

