-- ============================================================
-- tk_wifi 升级脚本 v2：广告链路 + 佣金原因记录
-- 适用于「已安装」的站点，给 tkwifi_contact 表补字段。
-- 注意：默认表前缀为 saas_ ，如你的前缀不同请整体替换。
-- 可重复执行（MySQL 8.0+ 支持 IF NOT EXISTS；
--   若为 5.7 请手动去掉已存在的列再执行，或忽略 1060 重复列错误）。
-- ============================================================

ALTER TABLE `saas_tkwifi_contact`
    ADD COLUMN IF NOT EXISTS `ad_status`     tinyint(2)  NULL DEFAULT 0  COMMENT '广告状态:0未知/1已展示/2看完/3中途退出/4无广告填充/5异常放行/6无需广告' AFTER `wifi_id`,
    ADD COLUMN IF NOT EXISTS `reward_status` tinyint(2)  NULL DEFAULT 0  COMMENT '佣金状态:0待处理/1已发放/2部分发放/3跳过未发' AFTER `ad_status`,
    ADD COLUMN IF NOT EXISTS `reason`        varchar(50) NULL DEFAULT '' COMMENT '未发放/跳过原因码' AFTER `reward_status`,
    ADD COLUMN IF NOT EXISTS `channel`       varchar(30) NULL DEFAULT '' COMMENT '渠道' AFTER `reason`,
    ADD COLUMN IF NOT EXISTS `update_time`   int(13)     NULL DEFAULT 0  COMMENT '更新时间' AFTER `create_time`;

-- 历史数据回填：已有佣金的记为「已发放看完」，其余记为「无需广告/正常连接」
UPDATE `saas_tkwifi_contact`
SET `reward_status` = 1, `ad_status` = 2, `reason` = 'rewarded'
WHERE (`own_fee` > 0 OR `first_fee` > 0 OR `second_fee` > 0)
  AND (`reason` IS NULL OR `reason` = '');

UPDATE `saas_tkwifi_contact`
SET `reward_status` = 3, `ad_status` = 6, `reason` = 'legacy'
WHERE `own_fee` = 0 AND `first_fee` = 0 AND `second_fee` = 0
  AND (`reason` IS NULL OR `reason` = '');

-- 索引（若已存在会报 1061，可忽略）
ALTER TABLE `saas_tkwifi_contact`
    ADD INDEX `idx_site_wifi_member` (`site_id`, `wifi_id`, `member_id`) USING BTREE;
