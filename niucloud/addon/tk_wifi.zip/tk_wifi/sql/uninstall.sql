-- ----------------------------
-- Table structure for {{prefix}}tkwifi_contact
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}tkwifi_contact`;
CREATE TABLE `{{prefix}}tkwifi_contact`
(
    `id`          int(11) NOT NULL AUTO_INCREMENT,
    `site_id`     int(11) NULL DEFAULT NULL COMMENT '站点ID',
    `member_id`   int(11) NULL DEFAULT NULL COMMENT '会员ID',
    `wifi_id`     int(13) NULL DEFAULT NULL COMMENT 'wifi码',
    `first_fee`   decimal(10, 2) NULL DEFAULT 0.00 COMMENT '一级推广金',
    `second_fee`  decimal(10, 2) NULL DEFAULT 0.00 COMMENT '二级推广金',
    `own_fee`     decimal(10, 2) NULL DEFAULT 0.00 COMMENT '商家推广金',
    `create_time` int(13) NULL DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '连接记录' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}tkwifi_list
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}tkwifi_list`;
CREATE TABLE `{{prefix}}tkwifi_list`
(
    `id`            int(11) NOT NULL AUTO_INCREMENT,
    `site_id`       int(11) NULL DEFAULT NULL COMMENT '站点ID',
    `member_id`     int(11) NULL DEFAULT NULL COMMENT '会员',
    `pid`           int(11) NULL DEFAULT 0,
    `name`          varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '名称',
    `wifi_name`     varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'wifi名称',
    `wifi_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT 'wifi密码',
    `closure`       text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL COMMENT '截流口令',
    `contact_num`   int(11) NULL DEFAULT 0 COMMENT '连接数量',
    `qrcode`        varchar(800) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '二维码',
    `is_use`        int(11) NULL DEFAULT 0 COMMENT '物料使用',
    `is_export`     int(11) NULL DEFAULT 0 COMMENT '导出物料',
    `create_time`   int(13) NULL DEFAULT NULL COMMENT '创建时间',
    PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 150 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = 'wifi码列表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Table structure for {{prefix}}tkwifi_member
-- ----------------------------
DROP TABLE IF EXISTS `{{prefix}}tkwifi_member`;
CREATE TABLE `{{prefix}}tkwifi_member`
(
    `member_id`   int(10) UNSIGNED NOT NULL DEFAULT 0 COMMENT '会员id',
    `site_id`     int(11) NOT NULL DEFAULT 0 COMMENT '站点id',
    `pid`         int(11) NULL DEFAULT 0 COMMENT '推荐会员id(分销)',
    `status`      int(11) NULL DEFAULT 0 COMMENT '状态',
    `code`        varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NULL DEFAULT NULL COMMENT '推荐码',
    `create_time` int(11) NULL DEFAULT 0 COMMENT '创建时间',
    PRIMARY KEY (`member_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_general_ci COMMENT = '推广者' ROW_FORMAT = DYNAMIC;

