<?php
return [
    'pages' => <<<EOT
        // PAGE_BEGIN
		// *********************************** WIFI一键连 ***********************************
		{
			"root": "addon/tk_wifi",
			"pages": [
				{
					"path": "pages/index/index",
					"style": {
						"navigationBarTitleText": "首页",
						// #ifndef H5
						"navigationStyle": "custom",
						"app-plus": {
							"titleView": false
						}
						// #endif 
					}
				},
				{
					"path": "pages/member/index",
					"style": {
						"navigationBarTitleText": "个人中心",
						// #ifndef H5
						"navigationStyle": "custom",
						"app-plus": {
							"titleView": false
						}
						// #endif 
					}
				},
				{
					"path": "pages/wifi/add",
					"style": {
						"navigationBarTitleText": "新增wifi码"
					},
					"needLogin": true
				},
				{
					"path": "pages/wifi/list",
					"style": {
						"navigationBarTitleText": "wifi码列表"
					},
					"needLogin": true
				},
				{
					"path": "pages/wifi/create_list",
					"style": {
						"navigationBarTitleText": "我创建WIFI"
					},
					"needLogin": true
				},
				{
					"path": "pages/wifi/contact",
					"style": {
						"navigationBarTitleText": "wifi一键连接"
					}
			},
			{
				"path": "pages/wifi/apply",
				"style": {
					"navigationBarTitleText": "申请推广码"
				},
				"needLogin": true
			},
			{
				"path": "pages/wifi/stat",
				"style": {
					"navigationBarTitleText": "推广统计"
				},
				"needLogin": true
			},
			{
				"path": "pages/wifi/share",
				"style": {
					"navigationBarTitleText": "推广中心"
				},
				"needLogin": true
			},
			{
				"path": "pages/fee/own",
				"style": {
					"navigationBarTitleText": "商户收益"
				},
				"needLogin": true
			},
			{
				"path": "pages/fee/fenxiao",
				"style": {
					"navigationBarTitleText": "推广收益"
				},
				"needLogin": true
			}
			]
		},
		// PAGE_END
EOT
];