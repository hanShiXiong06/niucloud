<?php
return [
    [
        'menu_name' => '代客下单',
        'menu_key' => 'shop_replace_buy',
        'menu_short_name' => '代客下单',
        'parent_key' => 'addon',
        'menu_type' => '0',
        'icon' => 'iconfont iconyingyongshichang',
        'api_url' => '',
        'router_path' => 'shop_replace_buy/index',
        'view_path' => '',
        'methods' => '',
        'sort' => '46',
        'status' => '1',
        'is_show' => '1',
        'children' => [
            [
                'menu_name' => '代客下单',
                'menu_key' => 'shop_replace_buy_index',
                'menu_short_name' => '代客下单',
                'menu_type' => '1',
                'icon' => 'iconfont icondiscount',
                'api_url' => '',
                'router_path' => 'shop_replace_buy/index',
                'view_path' => 'index',
                'methods' => 'get',
                'sort' => '100',
                'status' => '1',
                'is_show' => '1',
            ],
            [
                'menu_name' => '确认订单',
                'menu_key' => 'shop_replace_buy_order',
                'menu_short_name' => '确认订单',
                'menu_type' => '1',
                'icon' => 'iconfont icondiscount',
                'api_url' => '',
                'router_path' => 'shop_replace_buy/order',
                'view_path' => 'order',
                'methods' => 'get',
                'sort' => '90',
                'status' => '1',
                'is_show' => '0',
            ]
        ]
    ]
];
