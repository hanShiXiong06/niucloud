<?php

return [
    //订单来源
    'order_from' => [
        'replace_buy' => '代客下单',
    ],
];
