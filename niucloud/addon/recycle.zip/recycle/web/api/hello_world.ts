
/**
 * hello world
 */
export function getHelloWorld() {
    return request.get('recycle/hello_world')
}

