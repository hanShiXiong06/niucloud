export default [
    {
        path: "/recycle/hello_world/index",
        component: () => import('~/addon/recycle/pages/hello_world/index.vue')
    }
]
