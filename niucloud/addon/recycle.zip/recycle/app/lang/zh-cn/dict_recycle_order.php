<?php
return [
    'order_type' => '手机回收订单',
    
    // 订单状态
    'status_pending' => '待处理',
    'status_pending_confirm' => '待平台签收',
    'status_pending_check' => '待质检',
    'status_checking' => '质检中',
    'status_checked' => '质检完成',
    'status_pending_payment' => '待打款',
    'status_completed' => '已完成',
    'status_closed' => '已关闭',
];
