<?php
// +----------------------------------------------------------------------
// | Niucloud-admin 企业快速开发的多应用管理平台
// +----------------------------------------------------------------------
// | 官方网址：https://www.niucloud.com
// +----------------------------------------------------------------------
// | niucloud团队 版权所有 开源版本可自由商用
// +----------------------------------------------------------------------
// | Author: Niucloud Team
// +----------------------------------------------------------------------

namespace addon\recycle\app\validate\recycle_category;
use core\base\BaseValidate;
/**
 * 二手机分类验证器
 * Class RecycleCategory
 * @package addon\recycle\app\validate\recycle_category
 */
class RecycleCategory extends BaseValidate
{

    //    protected $rule = [
    //         'category_name' => 'require',
            
    //         'images' => 'require'
    //     ];

    //    protected $message = [
    //         'category_name.require' => ['common_validate.require', ['category_name']],
           
    //         'images.require' => ['common_validate.require', ['images']]
    //     ];

    //    protected $scene = [
    //         "add" => ['category_name', 'image', 'level', 'pid', 'category_full_name', 'is_show', 'sort', 'images'],
    //         "edit" => ['category_name', 'image', 'level', 'pid', 'category_full_name', 'is_show', 'sort', 'images']
    //     ];

}
