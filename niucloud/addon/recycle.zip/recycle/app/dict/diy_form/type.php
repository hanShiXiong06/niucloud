<?php

return [
    'DIY_FORM_RECYCLE_DETAIL' => [
        'title' => get_lang('验机表单'),
        'preview' => 'addon/recycle/diy_form/recycle_detail_preview.jpg', // 预览图
        'sort' => 10005,
        'addon'=>'recycle'
    ],
    // 'DIY_FROM_ORDER_PAYMENT' => [
    //     'title' => get_lang('dict_diy_form.type_order_payment'),
    //     'preview' => 'addon/phone_shop/diy_form/order_payment_preview.jpg', // 预览图
    //     'sort' => 10006,
    //     'addon'=>'shop'
    // ],
];
