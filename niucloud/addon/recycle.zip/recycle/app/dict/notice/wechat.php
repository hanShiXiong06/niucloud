<?php
return [

    'recycle_order_sign' => [
        'temp_key' => '57446',
        'content' => [
            // 'content' => [
                ['快速公司', '{delivery_type}', 'thing7'],
                ['快递单号', '{delivery_id}', 'character_string1'],
            // ],
        ],
        'keyword_name_list' => ["快递公司", "快递单号"],
        'tips' => '使用该消息请将微信公众号服务类目选择为：物流服务——>查件'
    ],
];
