<?php

return [
    'DIY_RECYCLE_INDEX' => [
        'title' => '回收主页',
        'page' => '/addon/recycle/pages/index',
        'action' => 'decorate',
        'type' => 'index'
    ],
    // 'DIY_RUNNING_MEMBER_INDEX' => [
    //     // 'title' => get_lang('dict_diy.page_RUNNING_member_index'),
    //     'title' => '跑腿个人中心',
    //     'page' => '/addon/running/pages/member/index',
    //     'action' => 'decorate',
    //     'type' => 'member_index'
    // ],
    // 'DIY_RUNNING_POINT_INDEX' => [
    //     'title' => ,
    //     'page' => '/addon/shop/pages/point/index',
    //     'action' => 'decorate',
    //     'type' => ''
    // ],
];
