<?php

namespace Xpyun\model;
class XPYunRespContent
{
    var $code;
    var $msg;
    var $data;
    var $serverExecutedTime;
}

?>