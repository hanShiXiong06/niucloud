<?php

namespace Xpyun\model;
class PrinterRequest extends RestRequest
{

    /**
     * 打印机编号
     */
    var $sn;
}

?>