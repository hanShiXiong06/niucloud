<?php

namespace Xpyun\model;
class AddPrinterRequest extends RestRequest
{
    var $items;
}

?>