<?php

namespace addon\recycle\app\printer\PrinterLib\model;

class XPYunResp
{
    public $httpStatusCode;

    public $content;
}

?>