<?php

namespace Xpyun\model;
class UpdPrinterRequest extends RestRequest
{

    /**
     * 打印机编号
     */
    var $sn;
    /**
     * 打印机名称
     */
    var $name;
}

?>