<?php

namespace Xpyun\model;
class DelPrinterRequest extends RestRequest
{
    /**
     * 打印机编号集合
     */
    var $snlist;

}

?>