<?php

namespace Xpyun\model;
class QueryOrderStateRequest extends RestRequest
{

    /**
     * 订单编号
     */
    var $orderId;
}

?>