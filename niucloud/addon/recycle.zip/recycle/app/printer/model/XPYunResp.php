<?php

namespace Xpyun\model;

class XPYunResp
{
    /**
     * HTTP协议状态码
     */
    public $httpStatusCode;

    /**
     * API返回内容，JSON对象
     */
    public $content;
} 