

DROP TABLE IF EXISTS `{{prefix}}recycle_order`;
DROP TABLE IF EXISTS `{{prefix}}recycle_device`;
DROP TABLE IF EXISTS `{{prefix}}recycle_return_order`;
DROP TABLE IF EXISTS `{{prefix}}recycle_return_device`;
DROP TABLE IF EXISTS `{{prefix}}recycle_category`;
DROP TABLE IF EXISTS `{{prefix}}recycle_category_config`;
DROP TABLE IF EXISTS `{{prefix}}recycle_shop_address`;
DROP TABLE IF EXISTS `{{prefix}}payment_info`;
DROP TABLE IF EXISTS `{{prefix}}recycle_user_address`;
DROP TABLE IF EXISTS `{{prefix}}recycle_device_log`;
DROP TABLE IF EXISTS `{{prefix}}recycle_order_log`;
DROP TABLE IF EXISTS `{{prefix}}recycle_printer`;


